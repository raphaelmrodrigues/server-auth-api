var we="",showTrial="";const aa={player:{key:"",oq:0,Ed:"",supportDevelopersPlease:"",language:"en"},an:{kq:!1,Vp:!1,wins:0},Dd:{Gn:!1},workbench:{enable:!1,Xp:10,rq:1,repairArena:!0,repairTurma:!0,itemList1:[],itemList2:[]},packages:{type:[],quality:[],Qq:!1,useCloths:!1},H:{enable:!1,vn:!1,Rn:[1],Wo:3,so:3,To:3,Vo:3,co:3,mp:3},Mp:{}};function ea(){const x=document.querySelector('meta[name="csrf-token"]');return x?x.content:null}
function I(x){let N=`${window.location.origin}/game/index.php?`;Object.entries(x).forEach((O,V)=>{N+=(0==V?"":"&")+O[0]+"="+O[1]});return N}function T(x){let N=`${window.location.origin}/game/ajax.php?`;Object.entries(x).forEach((O,V)=>{N+=(0==V?"":"&")+O[0]+"="+O[1]});return N}async function fa(x,N){N=await ia(x,N);if(!N)return!1;N.slot&&sa(N.slot,x.dataset.itemId||x.parentNode.dataset.containerNumber);ua(x,N.x,N.y);return!0}
async function wa(x,N){var O=document.getElementById("inv");if(O&&N){var V=N.x;N=N.y;(O=jQuery(O).offset())?(V=Math.ceil(O.left+32*V+16),N=Math.ceil(O.top+32*N+16),console.log(`Dragging item to: x=${V}, y=${N}`),ua(x,V,N)):console.error("Grid offset could not be determined.")}else console.error("Invalid target grid or slot coordinates.")}
async function ua(x,N,O){var V=jQuery(x).offset();V={x:V.left,y:V.top};Ba(x,"mousedown",{clientX:V.x-window.scrollX,clientY:V.y-window.scrollY});Ba(document,"mousemove",{clientX:N-window.scrollX,clientY:O-window.scrollY});Ba(document,"mouseup",{clientX:N-window.scrollX,clientY:O-window.scrollY});setTimeout(()=>{window.scroll(scroll.x,scroll.y)},0)}function Ca(x){x=x.getAttribute("data-quality");return null!=x?x:"0"}function Ea(x){return Ra(x).split("-")[0]}
function wb(x){return parseInt(x.getAttribute("data-amount"),10)}function xb(x){return x.getAttribute("data-content-type")}function yb(x){return x.getAttribute("data-level")}function Ra(x){return x.getAttribute("data-basis")}
function Gb(x,N){var O=[248,284,275,269,283,282,272,194,259,261,241,166,266,246,258,277,247,270,202,243,242,279,254,274,256,245,250,268,244,281,257,263,278,276,289,262,280,286,267,271,252,255,288,260,264,265];x=parseInt(x.split("-")[0],10);if(![1,2,3,4,5,6,8,9,20].includes(x))return!1;N=N.split("-");x=parseInt(N[6],36);return-1<[173,156,158,182,175,168,180,178,177,162,179,174,172,155,171,183,167,159,166,176,164,157,181,169,161,163,165].indexOf(parseInt(N[5],36))||-1<O.indexOf(x)}
function Hb(x){return parseInt(x.getAttribute("data-measurement-x"),10)*parseInt(x.getAttribute("data-measurement-y"),10)}function Ib(x){x=x.getAttribute("data-tooltip");x=x.substring(4,x.indexOf(",")).replace('"',"");return unescape(JSON.parse('"'+x+'"'))}function Jb(x){x=x.getAttribute("data-tooltip");return parseInt(x.replace(/\./g,"").match(/(\d+) (<img|<div class=\\"icon_gold\\")/i)[1],10)}
function $b(x){x=parseInt(x.getAttribute("data-basis").split("-")[0],10);return-1<[1,2,3,4,5,6,8,9].indexOf(x)}function ac(x){for(var N=0,O=0;O<x.length;O++){var V=x[O];N+=V.ul*V.w}return N}function bc(x){if("string"!==typeof x)return"";x=x.split(" ");return x[x.length-1]}
async function dc(x,N,O){return new Promise((V,U)=>{async function ja(za){if(za>=F.length)U(Error("No empty spot found"));else{var va=await fetch(F[za],{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":ea()},body:new URLSearchParams({})}).then(cc=>cc.text());va=jQuery("<div>").append(va)[0];va=ec(va);va=fc(ma[0],ma[1],va);(va=nc(N,x,va))?(V({spot:va,bag:za+512}),O&&"function"===typeof O&&O(va,za+512)):ja(za+1)}}const F=[];for(const za of[512,
513,514,515])F.push(T({mod:"inventory",submod:"loadBag",shopType:0,bag:za,sh:W("sh")}));const ma=[5,8];ja(0)})}var Jc=[],Kc={};function sa(x,N){if("inv"==x.target||"shop"==x.target){var O=Lc(x.target),V=[];for(let U=0;U<x.w;U++)for(let ja=0;ja<x.ul;ja++)V.push(O+"<"+(x.x+U)+","+(x.y+ja)+">");V.forEach(U=>{Jc.includes(U)||Jc.push(U)});N&&(Mc(N),Kc[N]=V)}}function Mc(x){x&&Kc.hasOwnProperty(x)&&(Kc[x].forEach(N=>{N=Jc.indexOf(N);-1<N&&Jc.splice(N,1)}),delete Kc[x])}
function Lc(x){let N=document.getElementById(x);return N?"inv"==x?N.parentNode.getElementsByClassName("awesome-tabs current")[0].dataset.Ip:"inv"==x?N.dataset.containerNumber:x:x}
function Nc(x,N){var O=x.querySelectorAll('.ui-draggable:not([style*="display: none"])');x=Array(5).fill(null).map(()=>Array(8).fill(!1));const V=parseInt(N.getAttribute("data-measurement-x"),10);N=parseInt(N.getAttribute("data-measurement-y"),10);for(var U of O){O=parseInt(U.getAttribute("data-position-x"),10)-1;var ja=parseInt(U.getAttribute("data-position-y"),10)-1,F=parseInt(U.getAttribute("data-measurement-x"),10),ma=parseInt(U.getAttribute("data-measurement-y"),10);for(let za=0;za<F;za++)for(let va=
0;va<ma;va++)0<=O+za&&8>O+za&&0<=ja+va&&5>ja+va&&(x[ja+va][O+za]=!0)}for(U=0;5>U;U++)for(O=0;8>O;O++){ja=!0;for(F=0;F<V;F++){for(ma=0;ma<N;ma++)if(8<=O+F||5<=U+ma||x[U+ma][O+F]){ja=!1;break}if(!ja)break}if(ja)return{x:O,y:U}}return null}
async function ia(x,N){if("shop"==N){var O=document.getElementById("shop");var V=[Math.round(O.clientHeight/32),6]}else if("inv-guild"==N)Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));else if("inv"==N)O=document.getElementById("inv"),V=[5,8];else{if("market"==N){O=document.getElementById("market_sell");var U=jQuery(O).offset();return{x:Math.ceil(U.left+32+8),y:Math.ceil(U.top+32+8),parent:O}}if("avatar"==N)return O=document.getElementById("avatar"),
U=jQuery(O).offset(),{x:Math.ceil(U.left+84),y:Math.ceil(U.top+97),parent:O};if("char"==N)for(var ja=document.getElementById("char").children,F=Number(x.dataset.contentType||"0"),ma=0;ma<ja.length;ma++){var za=ja[ma];if(Number(za.getAttribute("data-content-type-accept")||"0")==F&&0==ja[ma].children.length)return U=jQuery(za).offset(),{x:U.left+5,y:U.top+5}}else return!1}ja=ec(O);F=parseInt(x.dataset.measurementX,10);ma=parseInt(x.dataset.measurementY,10);try{var va="shop"!=N&&Oc(x,ja)||nc(ma,F,fc(V[0],
V[1],ja));if(!va)return!1;U=jQuery(O).offset();U={x:U.left,y:U.top};return va={x:Math.ceil(U.x+32*va.x+8),y:Math.ceil(U.y+32*va.y+8),parent:O,slot:{target:N,x:va.x,y:va.y,ul:ma,w:F}}}catch{return!1}}
function ec(x){if(!x)return[];var N=[];x=x.getElementsByClassName("ui-draggable");for(var O=0;O<x.length;O++)N.push({y:parseInt(x[O].style.top,10)/32,x:parseInt(x[O].style.left,10)/32,ul:parseInt(x[O].dataset.measurementY,10),w:parseInt(x[O].dataset.measurementX,10),basis:x[O].dataset.basis,hash:x[O].dataset.hash,amount:parseInt(x[O].dataset.amount,10)});return N}
function fc(x,N,O){var V,U,ja=[];for(V=0;V<x;V++)for(ja.push([]),U=0;U<N;U++)ja[V].push(!1);for(x=O.length-1;0<=x;x--)for(V=0;V<O[x].ul;V++)for(U=0;U<O[x].w;U++)ja[O[x].y+V][O[x].x+U]=!0;return ja}function Oc(x,N){let O=x.dataset.amount?parseInt(x.dataset.amount,10):1;for(var V=0;V<N.length;V++)if(N[V].hash==x.dataset.hash&&100>=N[V].amount+O)return{y:N[V].y,x:N[V].x};return!1}
function nc(x,N,O){var V,U,ja,F,ma=!1;for(V=0;V<=O[0].length-N;V++){for(U=0;U<=O.length-x;U++){if(ma=!0,1==x)0==O[U][V]?ma=!0:0==O[U][V+1]?V++:ma=!1;else for(ja=0;ja<N;ja++){for(F=0;F<x;F++)if(1==O[U+F][V+ja]){ma=!1;break}if(!ma)break}if(ma){for(ja=0;ja<N;ja++)for(F=0;F<x;F++)O[U+F][V+ja]=!0;ma={y:U,x:V};break}}if(ma)break;1==x&&V++}return ma}
function Ba(x,N,O){var V="mousemove"!==N,U=window;var ja=O.clientX;O=O.clientY;var F=document.createEvent("MouseEvents");F.initMouseEvent(N,!0,V,U,0,0,0,ja,O,!1,!1,!1,!1,0,document.body.parentNode);x.dispatchEvent(F)}
function sf(){new Promise(x=>{let N=2,O=()=>{--N;0===N&&x()};if(tf.includes("mod=auction")&&tf.includes("ttype=3")){var V=uf();(V<localStorage.getItem("auctionMStatus")&&vf("AuctionMEmpty")||4===V&&vf("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",V);O()}else tf.includes("mod=auction")?(V=uf(),(V<localStorage.getItem("auctionStatus")&&vf("AuctionEmpty")||4===V&&vf("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",0),localStorage.setItem("auctionStatus",
V),O()):(fetch(I({mod:"auction",ttype:3,itemLevel:999,itemQuality:2,sh:W("sh")}),{method:"GET",headers:{"x-csrf-token":ea()},credentials:"include"}).then(U=>U.text()).then(U=>{U=uf(jQuery(U));(U<localStorage.getItem("auctionMStatus")&&vf("AuctionMEmpty")||4===U&&vf("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",U);O()}),fetch(I({mod:"auction",itemLevel:999,itemQuality:2,sh:W("sh")}),{method:"GET",headers:{"x-csrf-token":ea()},credentials:"include"}).then(U=>
U.text()).then(U=>{U=uf(jQuery(U));(U<localStorage.getItem("auctionStatus")&&vf("AuctionEmpty")||4===U&&vf("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",0);localStorage.setItem("auctionStatus",U);O()}))})}function wf(x){if(document.querySelector("#inv div.spinner-img"))return setTimeout(()=>{wf(x)},500),!1;x&&x();return!0}var xf=new URLSearchParams(window.location.search);function W(x){return xf.get(x)}
var tf=window.location.search.match(/mod=.*&sh/)?window.location.search.match(/mod=.*&sh/)[0].slice(0,-3):null,Kf=window.location.hostname.split(/\./)?window.location.hostname.split(/\./)[0]:null,Lf={Cq:{l:"muito longo",h:"longo",i:"m\u00e9dio",j:"curto",m:"muito curto"},Dq:{l:"foarte lung",h:"lung",i:"mijlociu",j:"scurt",m:"foarte scurt"},Iq:{l:"ve\u013emi dlho",h:"dlho",i:"stredne",j:"kr\u00e1tko",m:"ve\u013emi kr\u00e1tko"},Tq:{l:"jako dugo",h:"dugo",i:"srednje",j:"kratko",m:"jako kratko"},Yp:{l:"hyvin pitk\u00e4",
h:"pitk\u00e4",i:"keskim\u00e4\u00e4r\u00e4inen",j:"lyhyt",m:"hyvin lyhyt"},Fq:{l:"mycket l\u00e5ng",h:"l\u00e5ng",i:"medel",j:"kort",m:"mycket kort"},Lq:{l:"\u00e7ok uzun",h:"uzun",i:"orta",j:"k\u0131sa",m:"\u00e7ok k\u0131sa"},Dp:{l:"\u0637\u0648\u064a\u0644 \u062c\u062f\u0627\u064b",h:"\u0637\u0648\u064a\u0644",i:"\u0645\u0646\u062a\u0635\u0641",j:"\u0642\u0635\u064a\u0631",m:"\u0642\u0635\u064a\u0631\u0629 \u062c\u062f\u0627\u064b"},jq:{l:"\u05d0\u05e8\u05d5\u05da \u05de\u05d0\u05d5\u05d3",h:"\u05d0\u05e8\u05d5\u05da",
i:"\u05d1\u05d9\u05e0\u05d5\u05e0\u05d9",j:"\u05e7\u05e6\u05e8",m:"\u05e7\u05e6\u05e8 \u05de\u05d0\u05d5\u05d3"},gr:{l:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",h:"\u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",i:"m\u03ad\u03c3\u03b7",j:"\u03bc\u03b9\u03ba\u03c1\u03ae",m:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b9\u03ba\u03c1\u03ae"},Jp:{l:"\u043c\u043d\u043e\u0433\u043e \u0434\u044a\u043b\u044a\u0433",h:"\u0434\u044a\u043b\u044a\u0433",i:"\u0441\u0440\u0435\u0434\u0435\u043d",j:"\u043a\u044a\u0441",
m:"\u043c\u043d\u043e\u0433\u043e \u043a\u044a\u0441"},Eq:{l:"\u043e\u0447\u0435\u043d\u044c \u043c\u043d\u043e\u0433\u043e",h:"\u043c\u043d\u043e\u0433\u043e",i:"\u0441\u0440\u0435\u0434\u043d\u0435",j:"\u043c\u0430\u043b\u043e",m:"\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e"},Kp:{l:"muito tempo",h:"longo",i:"m\u00e9dio",j:"curto",m:"bastante curto"},Pp:{l:"velmi dlouh\u00e1",h:"dlouh\u00e1",i:"st\u0159edn\u00ed",j:"kr\u00e1tk\u00e1",m:"velmi kr\u00e1tk\u00e1"},Rp:{l:"meget lang tid",
h:"lang tid",i:"halv tid",j:"kort tid",m:"meget kort tid"},Qp:{l:"sehr lange",h:"lange",i:"mittel",j:"kurz",m:"sehr kurz"},Sp:{l:"v\u00e4ga pikk",h:"pikk",i:"keskmine",j:"l\u00fchike",m:"v\u00e4ga l\u00fchike"},Tp:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},Pq:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},Fp:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},Wp:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},uq:{l:"muy largo",h:"largo",i:"medio",
j:"corto",m:"muy corto"},Zp:{l:"tr\u00e8s longtemps",h:"longtemps",i:"moyen",j:"court",m:"tr\u00e8s court"},nq:{l:"lunghissima",h:"lunga",i:"media",j:"breve",m:"brevissima"},qq:{l:"\u013coti gar\u0161",h:"gar\u0161",i:"vid\u0113js",j:"\u012bss",m:"\u013coti \u012bss"},pq:{l:"labai ilgai",h:"ilgai",i:"vidutini\u0161kai",j:"trumpai",m:"labai trumpai"},iq:{l:"nagyon hossz\u00fa",h:"hossz\u00fa",i:"k\u00f6zepes",j:"r\u00f6vid",m:"nagyon r\u00f6vid"},vq:{l:"heel lang",h:"lang",i:"gemiddeld",j:"kort",m:"zeer kort"},
vj:{l:"veldig lenge",h:"lenge",i:"medium",j:"kortvarig",m:"veldig kort"},Bq:{l:"bardzo d\u0142ugi",h:"d\u0142ugi",i:"\u015bredni",j:"kr\u00f3tki",m:"bardzo kr\u00f3tki"},Nq:{l:"\u8d85\u9577",h:"\u8f03\u9577",i:"\u5e38\u898f\u6642\u9593",j:"\u8f03\u77ed",m:"\u8d85\u77ed"}},uf=(x=document)=>{x=jQuery(".description_span_right",x).text().trim().toLowerCase();for(const N in Lf){const O=Lf[N],V=Object.values(O);for(const U in O)if(O[U].toLowerCase()===x)return V.indexOf(O[U])}return-1};
async function Mf(x="-1",N=""){const O=I({mod:"packages",submod:"sort",page:"1",sh:W("sh")}),V=new URLSearchParams({packageSorting:"in_desc"});fetch(O,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":ea()},body:V}).then(U=>U.text());return Promise.all(Array.from({length:2},(U,ja)=>ja+1).map(async U=>await Nf(x,N,U))).then(U=>U.reduce((ja,F)=>ja.concat(F),[]))}
async function Nf(x="-1",N="",O){x=await fetch(I({mod:"packages",f:"0",fq:x||-1,qry:N||"",page:O,sh:W("sh")}),{method:"GET",headers:{"x-csrf-token":ea()},credentials:"include"}).then(V=>V.text());return Array.from(jQuery(x).find(".packageItem"))}function Of(x){setTimeout(()=>{window.location.reload(!1)},x)}function Pf(x){window.location.href=`${window.location.origin}/game/index.php?${x}&sh=${W("sh")}`}function Ih(x){x&&(x.classList.contains("disabled")?window.location.reload():x.click())}
function Jh(){return{o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,"")),yo:document.querySelectorAll("#cooldown_bar_expedition .cooldown_bar_fill_ready")[0],wo:document.querySelectorAll("#cooldown_bar_dungeon .cooldown_bar_fill_ready")[0],Mq:document.querySelectorAll("#cooldown_bar_ct .cooldown_bar_fill_ready")[0],Ha:document.getElementById("expeditionpoints_value_point").innerText,vo:document.getElementById("dungeonpoints_value_point").innerText,
Gp:document.querySelectorAll("#cooldown_bar_arena .cooldown_bar_fill_ready")[0],Mn:parseInt(document.getElementById("sstat_ruby_val").innerText,10),level:parseInt(document.getElementById("header_values_level").innerText,10)}}function vf(x){let N=(new Date).getTime(),O=localStorage.getItem(x+".timeOut");null===O?(localStorage.setItem(x+".timeOut",0),O=0):O=parseInt(O,10);return O<=N?!0:!1}
function Kh(){let x=0;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(N=>{x+=Math.round(.04*N.price)});return Jh().gold>=x?!0:!1}function Lh(x,N){N-=x;let O=.04*x;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(V=>{O+=Math.round(.04*V.price)});return N>=O}function Y(x,N){localStorage.setItem(x+".timeOut",(new Date).getTime()+Math.floor(6E4*(N?N:5)))};(async function(){function x(){const b=document.querySelector('meta[name="csrf-token"]');return b?b.content:null}function N(){const b=document.getElementById("mainnav");return b?!!b.querySelector('a[href*="mod=dungeon"], a[href*="submod=showDungeons"]'):!1}function O(){var b=document.getElementById("mainnav");return b?b.querySelector('a[href*="submod=showExpeditions"]')||(b=b.querySelector('a[href*="mod=location&loc="]'))&&(b=b.getAttribute("href").match(/loc=([^&]+)/))&&!isNaN(parseInt(b[1],10))?
!0:!1:!1}function V(){var b=document.getElementById("mainnav");if(!b)return!1;b=b.querySelector('a[href*="mod=location&loc="]');return b?(b=b.getAttribute("href").match(/loc=([^&]+)/))?isNaN(parseInt(b[1],10)):!1:!1}function U(){yf=setInterval(function(){zf++;5>=zf?location.reload():clearInterval(yf)},12E4)}function ja(){function b(l){const h=l.innerHTML,k=h.match(/<font color="green">(\d+)<\/font>/);return k&&0<k[1]||h.includes('color="green"')||h.includes("Nowe")||h.includes("Yeni")||h.includes("New")||
h.includes('color="yellow"')||h.includes("Yeni")||h.includes("Nowe")||h.includes("New")||(l=l.innerText.match(/Pantheon \((\d+)\)/))&&0<l[1]?(localStorage.setItem("nextQuestTime",0),localStorage.setItem("nextQuestTime.timeOut",0),c(),!0):!1}function c(){const l=window.location.href;["index.php?mod=arena","index.php?mod=location","index.php?mod=dungeon","index.php?mod=reports","index.php?mod=quests"].some(h=>l.includes(h))&&window.location.reload()}var e="Pantheon;Panteon;Gudarnas tempel;\u0628\u0627\u0646\u062a\u064a\u0648\u0646;\u041f\u0430\u043d\u0442\u0435\u043e\u043d;Panth\u00e9on;\u795e\u8aed;\u05e4\u05e0\u05ea\u05d9\u05d0\u05d5\u05df".split(";");
let g=null;for(let l of e)if(g=document.querySelector(`a[title="${l}"]`))break;return g&&da.o>=Number(localStorage.getItem("healPercentage"))?(e=b(g),(new MutationObserver(l=>{l.forEach(h=>{"childList"!==h.type&&"subtree"!==h.type||b(g)})})).observe(g,{childList:!0,subtree:!0,characterData:!0}),e):!1}function F(b){function c(h){let k=localStorage.getItem(h);k&&(k=JSON.parse(k),localStorage.setItem(h,JSON.stringify(k.slice(-20))))}var e=document.querySelector("#logEntriesContainer");if(e){var g=new Date,
l=`${g.getHours().toString().padStart(2,"0")}:${g.getMinutes().toString().padStart(2,"0")}`;g=document.createElement("p");g.style.margin="0";g.style.padding="0";g.style.fontSize="12px";b=`[${l}] ${b}`;g.textContent=b;e.prepend(g);(e=localStorage.getItem("savedLogs"))?e=JSON.parse(e):e=[];e.unshift(b);30<e.length&&e.pop();localStorage.setItem("savedLogs",JSON.stringify(e));c("bidList");c("smeltedItems");c("MarketboughtItems")}}function ma(b,c){if(ta)switch(b){case "itemRepaired":oa.Sm++;break;case "itemReset":oa.Tm++;
break;case "goldCycled":oa.Qm++;break;case "arenaAttacks":oa.Em++;break;case "circusAttacks":oa.Hm++;break;case "dungeonAttacks":oa.Km++;break;case "expeditionAttacks":oa.Mm++;break;case "itemSmelted":oa.Um++;break;case "underworldAttacks":oa.bn++;break;case "arenaMoney":oa.om+=c;break;case "circusMoney":oa.pm+=c}localStorage.setItem("userStats",JSON.stringify(oa))}function za(){gb||(gb=document.createElement("div"),gb.className="confirmation-popup",gb.innerHTML='\n                <p>Are you sure you want to reset the bot?</p>\n                <button id="confirmReset">Yes</button>\n                <button id="cancelReset">No</button>\n            ',
document.body.appendChild(gb),document.getElementById("confirmReset").addEventListener("click",function(){const b="tkz_lcr Username tkn nana_lcn license_remaining trlky_lcr gladiatusCrazyAddonData gladiatusCrazyAddonData_".split(" ");let c=[];for(let e=0;e<localStorage.length;e++){const g=localStorage.key(e);!g||b.includes(g)||g.startsWith("gladiatusCrazyAddonData_")||c.push(g)}for(const e of c)localStorage.removeItem(e);window.location.reload();gb.style.display="none"}),document.getElementById("cancelReset").addEventListener("click",
function(){gb.style.display="none"}));gb.style.display="block"}function va(b,c){return null==b?"":b.split("").map(e=>String.fromCharCode(e.charCodeAt(0)+c)).join("")}async function cc(b,c,e,g){g=va(g,3);const l={action:"vx",data:{token:b,refreshToken:c,playerId:e,Up:g}};try{const h=await Promise.race([new Promise((k,q)=>{chrome.runtime.sendMessage(l,n=>{chrome.runtime.Ro||!n?q(chrome.runtime.Ro||"No response"):k(n)})}),new Promise(k=>setTimeout(()=>k("timeout"),6E4))]);if("timeout"===h)await new Promise(k=>
setTimeout(k,1E3)),window.location.reload();else if(h.success||h.s){const k=h.data||h.d;if(k.valid&&!k.expired)return aa.player.key=k.playerId,aa.player.supportDevelopersPlease=k.supportDevs,"true"!==localStorage.getItem("nana_lcn")&&localStorage.setItem("nana_lcn","true"),k.announcement&&0<=k.announcement.length&&localStorage.getItem("latestAnnouncement")!==k.announcement&&localStorage.setItem("latestAnnouncement",k.announcement),await Th(k.supportDevs).then(q=>{aa.player.Ed=q}),!0;if(k.expired&&
(sessionStorage.setItem("autoGoActive","false"),k.newToken))return k.newToken&&(localStorage.setItem("token",k.newToken+1),localStorage.setItem("nana_lcn","false"),aa.player.key=gc()+"l",hb()),!1}else new Promise(k=>setTimeout(()=>k("timeout"),3E4))}catch(h){return window.location.reload(),!1}}function Uh(b){return((localStorage.getItem("playerId")|0)+5|0)%100===b}async function Th(b){function c(k){const q=[];for(let n=0;n<k.length;n+=2)q.push(parseInt(k.substr(n,2),16));return new Uint8Array(q)}
const [e,g]=b.split(":");b=c(e);const l=c(g),h=await window.crypto.subtle.importKey("raw",c("46d9ef519c1474cf8699ba24ab2a726a"),{name:"AES-CBC"},!1,["decrypt"]);b=await window.crypto.subtle.decrypt({name:"AES-CBC",iv:b},h,l);b=(new TextDecoder).decode(new Uint8Array(b));b=new Date(b);b.setHours(0,0,0,0);return b}function Vh(b){(b.target.classList.contains("licotok-close")||"licotok"===b.target.id)&&document.getElementById("licotok").remove()}async function Wh(){gc();const b=document.getElementById("licotok-input").value.trim(),
c=localStorage.getItem("playerId"),e=document.getElementById("status_message");const u=localStorage.getItem("idkps");let response=null;try{response=await fetch('https://gldbotserver.com/validate-license',{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idkps:u,license:b}),});const data=await response.json();if(data.valid){localStorage.setItem("nana_lcn","true"),localStorage.setItem("tkz_lcr",data.token),localStorage.setItem("license_remaining",data.expirationDate),localStorage.setItem("globalAnnouncement",data.globalAnnouncement),localStorage.setItem("tkn",data.refreshToken),localStorage.setItem("we",data.p),localStorage.setItem("pid",c),aa.player.key=c,window.location.reload()
}else{e.textContent=data.message||"Invalid license key or token! Just purchased? Wait 10 minutes before activating the key.";e.style.display="block";}}catch(error){alert("Erro no servidor de autenticação");}}function Ya(b){var c=
document.createElement("div");c.setAttribute("id","licotok");c.innerHTML=`
        <style>
            .licotok-popup {
            background: #ddd5b4; /* Beige background */
            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            color: #333; /* Darker text color for better contrast */
            padding: 20px;
            border: 1px solid #c4ac70; /* Golden border */
            font-family: Arial, sans-serif; /* Optional: Change the font */
            }
        
            .licotok-popup h2 {
            color: #333;
            text-shadow: none; /* Removing text shadow for better readability */
            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */
            padding: 10px;
            margin: -20px; /* To offset the padding of the parent */
            margin-bottom: 15px;
            border-radius: 10px 10px 0 0; /* Rounded corners on the top */
            }
        
            .licotok-popup a {
            text-decoration: none;
            color: #fff; /* White text for buttons */
            background-color: #c4ac70; /* Golden background */
            border-radius: 5px;
            padding: 5px 10px;
            margin-right: 10px;
            transition: background-color 0.3s ease;
            }
        
            .licotok-popup a:hover {
            background-color: #b3a369; /* Darker shade on hover */
            }
        
            .licotok-popup input {
            width: calc(100% - 10px); /* Full width minus padding */
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #c4ac70; /* Border color similar to the theme */
            border-radius: 5px;
            }
        

            
            .licotok-popup #status_message {
            margin-top: 10px;
            }
        </style>
        <div class="licotok-popup">
        <h2>Warning</h2>
        <span style="color: #bfae54" class="span-new">${b}</span>
        <p>
        <button id="licotok-close" class="awesome-button">Close</button>
        <div id="status_message"></div>
    </div>
        
        `;document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);c.querySelector("#licotok-close").addEventListener("click",function(){c.remove()})}function Xh(){var b=document.createElement("div");b.setAttribute("id","licotok");b.innerHTML = '\n        <style>\n            .licotok-popup {\n            background: #ddd5b4; /* Beige background */\n            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n            border-radius: 10px;\n            color: #333; /* Darker text color for better contrast */\n            padding: 20px;\n            border: 1px solid #c4ac70; /* Golden border */\n            font-family: Arial, sans-serif; /* Optional: Change the font */\n            }\n        \n            .licotok-popup h2 {\n            color: #333;\n            text-shadow: none; /* Removing text shadow for better readability */\n            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */\n            padding: 10px;\n            margin: -20px; /* To offset the padding of the parent */\n            margin-bottom: 15px;\n            border-radius: 10px 10px 0 0; /* Rounded corners on the top */\n            }\n        \n            .licotok-popup a {\n            text-decoration: none;\n            color: #fff; /* White text for buttons */\n            background-color: #c4ac70; /* Golden background */\n            border-radius: 5px;\n            padding: 5px 10px;\n            margin-right: 10px;\n            transition: background-color 0.3s ease;\n            }\n        \n            .licotok-popup a:hover {\n            background-color: #b3a369; /* Darker shade on hover */\n            }\n        \n            .licotok-popup input {\n            width: calc(100% - 10px); /* Full width minus padding */\n            padding: 5px;\n            margin-bottom: 10px;\n            border: 1px solid #c4ac70; /* Border color similar to the theme */\n            border-radius: 5px;\n            }\n        \n\n            \n            .licotok-popup #status_message {\n            margin-top: 10px;\n            }\n        </style>\n        <div class="licotok-popup">\n            <h2>Enter Your License Key</h2>\n            <input id="licotok-input" type="text" placeholder="License Key">\n            &nbsp<a href="https://gldbotserver.com/home-gld" target="_blank">Buy GLDbot license</a>\n                        <a href="https://sgldbot.gumroad.com/l/gladiatusbot" target="_blank">Gumroad official page</a>\n                        <p>\n            <a href="#" id="get-trial-key-a">Get a Trial Key</a>\n            <a href="" target="_blank">Discord</a>\n                       <div id="alertMessage" class="alert-message" style="display: none; font-weight: bold;"></div>\n\n      <hr>      <li>\n             <span style="color: class="span-new">[BRASIL] Experimente o teste gratuito de 1 dia. A licença ficará salva na aba “Extras” caso você esqueça. Se você limpar a cache ou reinstalar o navegador. Você deve inserir sua chave novamente para ativar o bot.</span>\n            </li>\n      <hr>      <li>\n            <span style="color: class="span-new">[ENGLISH] Try 1 day free trial. The license will be saved in the "Extras" tab in case you forget it. If you clear your caches or reinstall the browser. You have to enter your key again to enable the bot.</span>\n     <hr>       </li>\n            <p>\n            <span style="color: class="span-new">If you have some questions or suggestions, contact us E-mail: <strong>gldbotsuport@gmail.com</strong></span>\n\n  <br>          <button class="awesome-button licotok-submit">Submit</button>\n            <button class="awesome-button licotok-close">Close</button>\n            <div id="status_message"></div>\n        </div>\n        ';
document.getElementById("header_game").insertBefore(b,document.getElementById("header_game").children[0]);b.addEventListener("click",Vh);b.querySelector(".licotok-submit").addEventListener("click",Wh);let c=localStorage.getItem("idkps");if(null==c)try{gc(),c=localStorage.getItem("idkps")}catch{}b.querySelector("#get-trial-key-a").addEventListener("click",function(){async function e(g){return fetch(g,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({playerId:c})}).then(l=>
l.json()).then(l=>{var h=document.getElementById("alertMessage");l.success?(h.textContent="Your 1 day trial key : "+l.trialKey,h.style.display="block",showTrial=l.trialKey, localStorage.setItem("showTrial",l.trialKey)):(h.textContent=l.message,h.style.display="block")})}e("https://gldbotserver.com/get-trial").catch(()=>e("https://gldbotserver.com/get-trial")).catch(()=>{})})}
function gc(){let b;if(!b){const c=/var playerId\s*=\s*(\d+);/;Array.from(document.getElementsByTagName("script")).some(e=>(e=c.exec(e.textContent||e.innerText))&&e[1]?(b=e[1],!0):!1)}if(!b){const c=document.getElementById("content");c&&c.querySelectorAll('section[style="display: block;"]').forEach(e=>{Array.from(e.getElementsByTagName("p")).forEach(g=>{Array.from(g.getElementsByTagName("b")).forEach(l=>{l=l.textContent.trim();l.includes("gladiatus.gameforge.com/game/index.php?mod=player&")&&(b=(new URLSearchParams((new URL(l)).search)).get("p"))})})})}b||
(document.cookie.split("; ").forEach(c=>{c.trim().startsWith("gladiatus")&&!b&&(c=decodeURIComponent(c.split("=")[1]).match(/^\d+/))&&(b=c[0])}),document.cookie.split("; ").forEach(c=>{c.trim().startsWith("GB_")&&!b&&(c=c.split("=")[1].split("_"),b=0<c.length&&!isNaN(c[0])?c[0]:null)}));let cc=b;return b?(localStorage.setItem("playerId",18835),localStorage.setItem("pid",18835),localStorage.setItem("idkps",cc),18835):null}function Yh(){let b=document.querySelector(".playername")||document.querySelector(".playername_achievement");b&&(b=b.textContent.trim(),
localStorage.setItem("Username",b))}async function rest(){const autoGoButton=document.getElementById("autoGoButton");if(autoGoButton)autoGoButton.remove();const customButtons=document.querySelectorAll(".customButton2");customButtons.forEach(button=>button.remove());sessionStorage.setItem("autoGoActive",!1);}async function pt(){gc();const idkps=localStorage.getItem("idkps");try{const response=await fetch('https://gldbotserver.com/validate-key',{method:'POST',headers:{'Content-Type':'application/json',},body:JSON.stringify({idkps}),});const d=await response.json();if(d.valid){localStorage.setItem("we",d.p);localStorage.setItem("globalAnnouncement",d.globalAnnouncement);localStorage.setItem("tkz_lcr",d.token);localStorage.setItem("license_remaining",d.expirationDate);localStorage.setItem("tkn",d.refreshToken);Gf();}else{rest().then(()=>{hb();}).catch(error =>{console.error("rest:",error);});}}catch(error){alert("Erro ao conectar com o servidor de autenticação");}}async function Af(){try{const b=await fetch(I({mod:"premium",submod:"centurio",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(c=>c.text());return(new DOMParser).parseFromString(b,"text/html").querySelector("#premium_duration")?!1:!0}catch(b){}}function ob(b,c,e){var g="";e&&(g=new Date,g.setTime(g.getTime()+864E5*e),g="; expires="+g.toUTCString());document.cookie=b+"="+(c||
"")+g+"; path=/; domain=.gameforge.com"}function pb(b){b+="=";for(var c=document.cookie.split(";"),e=0;e<c.length;e++){for(var g=c[e];" "===g.charAt(0);)g=g.substring(1,g.length);if(0===g.indexOf(b))return g.substring(b.length,g.length)}return null}function Bf(b){document.cookie=`glautologin=${b?"true":"false"}; path=/; domain=.gameforge.com; samesite=strict`}function Pc(){let z5=localStorage.getItem("we");we=new Date(z5);return"true"===localStorage.getItem("nana_lcn")&&Cf&&aa.player.Ed>=new Date&&we>=new Date&&ya===Qc&&aa.player.key===ya}function Rc(b,c){b.style.border=
"1px solid #c4ac70";b.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";b.style.color="#bfae54";b.style.padding="5px 10px";b.style.cursor="pointer";b.style.borderRadius="5px";b.style.flexGrow="1";b.style.marginRight="5px";b.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";b.style.fontFamily="Arial, sans-serif";b.style.transition="background-color 0.2s"}function Df(){localStorage.setItem("logMenuHeight",ra.style.height)}function Zh(){var b=document.querySelector(".playername.ellipsis");const c=ya;b&&(b=`${b.textContent.trim()}-${c}`,localStorage.setItem("Username",b),document.cookie=
`gllastusername=${b}; path=/; domain=.gameforge.com; samesite=strict`)}async function $h(){var b={async Zm(){var c=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${localStorage.getItem("filterGM")}&p=1`;if(tf!==c)Pf(c);else try{const q=localStorage.getItem("guildPackHour");let n=JSON.parse(localStorage.getItem("packagesPurchased")||"[]");if(n.length){var e=n[0],g=await Mf(e.quality,e.itemName);g=g.filter(m=>{m=m.querySelector(".ui-draggable");return e.itemLevel===yb(m)&&e.itemName===Ib(m)&&e.basis===
Ra(m)&&e.quality===Ca(m)&&e.amount===wb(m)});if(g.length&&g[0].querySelector(".ui-draggable")){const m=g[0].querySelector(".ui-draggable");yb(m);Ib(m);Ra(m);Ca(m);wb(m);var l=parseInt(m.getAttribute("data-measurement-x"),10),h=parseInt(m.getAttribute("data-measurement-y"),10),k=g[0].querySelector("input").value;let {spot:r,bag:w}=await dc(l,h);const v=T({mod:"inventory",submod:"move",from:"-"+k,fromX:1,fromY:1,to:w,toX:r.x+1,toY:r.y+1,amount:e.amount}),y=new URLSearchParams({a:(new Date).getTime(),
sh:W("sh")}),D=await fetch(v,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:y}).then(E=>E.text()),C=JSON.parse(D).to.data.itemId;c=0;if(2>c||D.includes("containerNumber")){const E=I({mod:"guildMarket",sh:W("sh")}),t=new URLSearchParams({sellid:C,preis:e.price,dauer:q||3,sell_mode:0,anbieten:"Offer",csrf_token:x()});if((await fetch(E,{method:"POST",credentials:"include",body:t}).then(u=>u.text())).includes("<!DOCTYPE HTML>"))F("Item "+
e.itemName+" sold for "+e.price+" gold"),ma("goldCycled",0),n.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(n)),window.location.reload();else if(c++,2>c)await this.Zm();else{const u=JSON.parse(localStorage.getItem("Timers"));Y("gold",u.GuildMarket||2);window.location.reload()}}}else n.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(n)),window.location.reload()}}catch(q){F("Empty first slots of the first inventory at least 2x3."),window.location.reload()}},async jo(c,
e){let g=c.shift();var l=!1;const h={GUILD_TOOLS:["2097152","1048576","8388608","4194304"],GUILD_FORGE_RESOURCES:["32768"],GUILD_WEAPONS:["2"],GUILD_SHIELD:["4"],GUILD_CHEST:["8"],GUILD_HELMET:["1"],GUILD_GLOVES:["256"],GUILD_SHOES:["512"],GUILD_RINGS:["48"],GUILD_AMULETS:["1024"],GUILD_USABLES:["4096"],GUILD_FOOD:["64"],GUILD_UPGRADES:["4096"],GUILD_RECIPES:["8192"],GUILD_MERCENARY:["16384"],GUILD_SCROLLS:["64"],GUILD_REINFORCEMENTS:["4096"]};let k=JSON.parse(localStorage.getItem("itemsToResetGuild")||
"[]");for(k=k.map(q=>!q.startsWith("GUILD_")&&h["GUILD_"+q]?"GUILD_"+q:q);g;){const q=g.type;if((0===k.length||k.some(n=>h[n]?.includes(q)))&&Lh(g.price,e)&&e>=g.price){e-=g.price;l=I({mod:"guildMarket",sh:W("sh")});const n=new URLSearchParams({csrf_token:x(),buyid:g.id,f:0,fl:0,fq:-1,p:1,buy:"Buy"});await fetch(l,{method:"POST",credentials:"include",body:n}).then(m=>m.text());l=JSON.parse(localStorage.getItem("packagesPurchased")||"[]");l.push(g);localStorage.setItem("packagesPurchased",JSON.stringify(l));
F("Item Bought: "+g.itemName+" for "+g.price);l=!0}g=c.shift()}return l},async buy(){const c=localStorage.getItem("filterGM"),e=JSON.parse(localStorage.getItem("Timers"));let g=Number(localStorage.getItem("currentPage")||1);var l=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${g}`;if(tf!==l)Pf(l);else if(!(da.gold<=Number(localStorage.getItem("KasaHoldGold")))){var h=document.querySelectorAll("#market_item_table tr"),k=document.querySelectorAll("#market_item_table input[name=buyid]");l=[];
for(let q=1;q<h.length;q++){let n=h[q].querySelectorAll("td"),m=n[0].querySelector("div"),r=Number(n[2].innerText.replace(/\./g,"")),w=n[5].querySelector("input");"cancel"===w.name||w.classList.contains("disabled")||r<Number(localStorage.getItem("minimumGoldAmount"))||r>Jh().gold-Number(localStorage.getItem("KasaHoldGold"))||l.push({id:k[q-1].value,itemLevel:yb(m),itemName:Ib(m),basis:Ra(m),type:xb(m),quality:Ca(m),amount:wb(m),sellerName:n[1].querySelector("span").innerText,price:r})}h=Jh().gold-
Number(localStorage.getItem("KasaHoldGold")||0);if(l.length&&Kh())await this.jo(l,h)||Y("gold",e.GuildMarket||2),window.location.reload();else try{const q=document.querySelector(".standalone").textContent.match(/(\d+)\s*\/\s*(\d+)/);g<(q?parseInt(q[2],10):1)?(localStorage.setItem("currentPage",g+1),Pf(`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${g+1}`)):(localStorage.setItem("currentPage",1),Y("gold",e.GuildMarket||2),window.location.reload())}catch(q){F("No items to buy in guild market today. :/"),
localStorage.setItem("currentPage",1),Y("gold",e.GuildMarket||2),window.location.reload()}}}};0<JSON.parse(localStorage.getItem("packagesPurchased")||"[]").length?await b.Zm():da.gold>Number(localStorage.getItem("minimumGoldAmount"))+Number(localStorage.getItem("KasaHoldGold")||0)?await b.buy():(b=JSON.parse(localStorage.getItem("Timers")),Y("gold",b.GuildMarket||2),window.location.reload())}function ai(){var b=document.getElementById("submenuhead1"),c=document.getElementById("submenu1"),e=document.getElementById("submenuhead2"),
g=document.getElementById("submenu2"),l=document.getElementById("main");l&&(l.style.height="950px",l.style.minHeight="950px");b&&(b.style.display="block");c&&(c.style.display="block");e&&(e.style.display="none");g&&(g.style.display="none")}function Sc(){var b=localStorage.getItem("premiumDicesLeft");b=parseInt(b,10);return isNaN(b)?0:b}function bi(){var b=document.querySelector(".contentboard_footer_long .contentboard_inner");if(b){b.style.position="relative";b.style.overflowX="visible";b.style.overflowY=
"visible";b.style.height="auto";b.style.minHeight="450px !important";var c=document.createElement("div");c.id="customContainer";c.style.cssText="border: 2px solid #BA9700; padding: 10px; margin-top: 20px;  border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5); text-align: center; width: 100%; box-sizing: border-box; min-height: 400px;";b.appendChild(c);b=document.createElement("button");b.textContent="Start";b.className="button1";b.style.marginTop="10px";c.appendChild(b);var e=document.createElement("button");
e.textContent="Stop";e.className="button1";e.style.marginTop="10px";c.appendChild(e);var g=document.createElement("div");g.id="dicesLeft";var l=Sc();g.textContent=`Dices left: ${l}`;g.style.fontWeight="bold";g.style.marginTop="10px";c.appendChild(g);g=document.createElement("div");g.textContent='GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.';g.style.marginTop="5px";c.appendChild(g);g=document.createElement("div");
g.id="results";g.style.cssText="display: flex; flex-wrap: wrap; justify-content: center; gap: 5px; margin-top: 10px; overflow-x: hidden; overflow-y: auto; max-height: 400px;";c.appendChild(g);var h=document.createElement("div");h.id="progressIndicator";h.textContent="Ready to start.";h.style.marginTop="10px";c.appendChild(h);b.addEventListener("click",async function(){h.textContent="Processing...";await ci()});e.addEventListener("click",function(){h.textContent="Process stopped by user. Completed!";
window.location.reload()});di()}}function di(){let b;var c=document.querySelector(".mysterybox_count");c=c?parseInt(c.textContent,10):0;localStorage.setItem("chestsLeft",c);var e=document.getElementById("mysterybox_luck");if(e)for(var g of e.childNodes)if(g.nodeType!==Node.TEXT_NODE&&g.nodeType===Node.ELEMENT_NODE)if("IMG"===g.tagName&&(g.currentSrc.includes("4197f09a37be7d221c34f3e0d957e7.png")||g.currentSrc.includes("res3")))break;else"INPUT"===g.tagName&&"button"===g.type&&(e=g.getAttribute("onclick").match(/tokenAmount=(\d+)/))&&
e[1]&&(b=parseInt(e[1],10));g=document.getElementById("dicesLeft");e=Sc();g.textContent=0>b?"Dices left: Cannot determine. Please refresh the page.":`Dices left: ${e}`;localStorage.setItem("chestsLeft",c);localStorage.setItem("premiumDicesLeft",b)}async function ci(){0>=parseInt(localStorage.getItem("premiumDicesLeft"),10)?alert("No dices left!"):await Tc()}async function Tc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");
if(!b||0>=b&&0>=c)e.textContent="All actions completed: No dices or chests left.";else if(!b||0>=b)e.textContent="No dices left. Trying to open remaining chests...",await hc();else if(!c||0>=c)e.textContent="No chests left!";else{e.textContent="Refreshing mystery box...";var g=(new URL(window.location.href)).searchParams.get("sh")||"",l=document.querySelectorAll(".mysterybox_reward_item_pool"),h="Vulcano;Junos;Bergzorns;Weitsicht;Eole;Junon;Armure;Masque;Vulcain;Neptuno;Eolo;Armatura;Sguardo;Olhos;Alento;Nettuno;Respiro;Soffio;mortal de;Aliento;Armadura;Vista;Zbroja;Orli;Neptuna;Feronii;Wulkana;Wrath;Eagle;Pluto;Neptune;Vulcanus;Junosa;Plutosa;Ajolos;Vulcano;Feronia;Feronias;Plutos;Neptun;Aeolus;Pluton;Juno;Ejderha;Kartal;nefesi".split(";"),
k=!1;for(let q of l){const n=q.getAttribute("data-tooltip");if(h.some(m=>n.includes(m))){k=!0;break}}if(k)await hc();else try{const q=await fetch(I({mod:"mysterybox",submod:"refresh",Kq:b,sh:g}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(w=>w.text());b--;localStorage.setItem("premiumDicesLeft",b);const n=document.getElementById("dicesLeft"),m=Sc();n.textContent=`Dices left: ${m}`;const r=(new DOMParser).parseFromString(q,
"text/html").querySelectorAll(".mysterybox_reward_item_pool");g="Vulcano Feronia Neptun Aeolus Pluton Juno Ejderha Kartal nefesi".split(" ");l=!1;for(let w of r){const v=w.getAttribute("data-tooltip");if(v&&g.some(y=>v.includes(y))){l=!0;break}}l?await hc():0<b?setTimeout(Tc,1E3):0<c?await hc():(e.textContent="Completed all possible actions.",F("No more actions possible: No premium dices or chests left."))}catch(q){F("Error refreshing mystery box. Please try again.")}}}async function hc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),
10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");if(!c||0>=c)e.textContent="No chests left to open!";else{e.textContent="Opening chest...";var g=(new URL(window.location.href)).searchParams.get("sh")||"",l=(new Date).getTime();try{const h=await fetch(T({mod:"mysterybox",submod:"pick",sh:g,a:l}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(k=>k.text());b--;c--;localStorage.setItem("premiumDicesLeft",
b);localStorage.setItem("chestsLeft",c);(new DOMParser).parseFromString(h,"text/html");ei(h);0<b||0<c?(e.textContent="Chest opened. Checking for more actions...",setTimeout(Tc,1E3)):e.textContent="All dices and chests used up."}catch(h){F("Error opening chest. Please try again.")}}}function ei(b){var c=document.querySelector(`.mysterybox_reward_item_pool img[alt="${b}"]`);if(c){b=document.createElement("div");b.className="result-item";b.style.border="1px solid #ccc";b.style.borderRadius="5px";b.style.padding=
"2px";b.style.margin="1px";b.style.textAlign="center";b.style.backgroundColor="#fff";b.style.boxSizing="border-box";b.style.flex="1 0 20%";const e=document.createElement("img");e.src=c.src;e.alt="Item Image";e.className="result-image";e.style.maxWidth="50px";e.style.display="block";e.style.margin="0 auto";const g=document.createElement("span");c=c.closest(".mysterybox_reward_item_pool").getAttribute("data-tooltip").match(/"([^"]+)"/);g.textContent=c?c[1]:"Unknown Item";g.style.display="block";g.style.marginTop=
"5px";g.style.fontSize="12px";b.appendChild(e);b.appendChild(g);document.querySelector("#results").appendChild(b)}}function Wa(){Uc.length=0;document.querySelectorAll(".rule-row").forEach(b=>{const c=b.querySelector(".rule-condition-select").value;var e=b.querySelector(".rule-prefix-input"),g=b.querySelector(".rule-suffix-input");e=e?e.value:"";g=g?g.value:"";const l=b.querySelector(".rule-level").value,h=Array.from(b.querySelectorAll(".item-icon.selected")).map(n=>n.dataset.type),k=Array.from(b.querySelectorAll(".color-circle.selected")).map(n=>
n.dataset.color),q=b.querySelector(".rule-hammer-selection img.selected");b=b.querySelector(".rule-checkbox");Uc.push({condition:c,prefix:e,suffix:g,colors:k,itemTypes:h,hammerState:q?q.dataset.hammer:"none",level:l,isEnabled:b?b.checked:!0})});localStorage.setItem("smeltingSettings",JSON.stringify(Uc))}function fi(){document.querySelectorAll(".item-icon").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function gi(){document.querySelectorAll(".color-circle").forEach(b=>
{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function hi(){document.querySelectorAll(".rule-row .rule-hammer-selection img").forEach(b=>{b.addEventListener("click",function(){const c=this.closest(".rule-hammer-selection").querySelectorAll("img");this.classList.contains("selected")?this.classList.remove("selected"):(c.forEach(e=>e.classList.remove("selected")),this.classList.add("selected"));Wa()})})}function ii(){document.querySelectorAll(".rule-condition-select").forEach(b=>
{b.addEventListener("change",function(){const c=this.closest(".rule-row").querySelector(".rule-prefix-input"),e=this.closest(".rule-row").querySelector(".rule-suffix-input");"nameContains"===this.value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");Wa()})})}function ji(){document.querySelectorAll(".rule-prefix-input, .rule-level").forEach(b=>{b.addEventListener("input",Wa)});document.querySelectorAll(".rule-suffix-input, .rule-level").forEach(b=>
{b.addEventListener("input",Wa)})}function ki(){document.querySelectorAll(".rule-row .remove-rule-btn").forEach(b=>{b.addEventListener("click",function(){b.closest(".rule-row").remove();Wa()})})}function Ef(){const b=document.querySelector(".rule-row-template").cloneNode(!0);b.classList.remove("rule-row-template");b.classList.add("rule-row");b.style.display="block";b.querySelector(".rule-prefix-input").value="";b.querySelector(".rule-suffix-input").value="";b.querySelector(".rule-level").value="";
b.querySelector(".rule-checkbox").checked=!0;b.querySelectorAll(".selected").forEach(g=>g.classList.remove("selected"));const c=b.querySelector(".rule-prefix-input"),e=b.querySelector(".rule-suffix-input");"nameContains"===b.querySelector(".rule-condition-select").value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");document.querySelector(".rule-container").insertBefore(b,document.querySelector(".add-rule-btn"));Ff();Wa()}function li(){document.querySelectorAll(".rule-checkbox").forEach(b=>
{b.addEventListener("change",Wa)});document.querySelectorAll(".rule-checkbox-wrapper").forEach(b=>{b.addEventListener("click",function(){const c=this.querySelector(".rule-checkbox");c.checked=!c.checked;Wa()})})}function Ff(){ii();fi();gi();hi();ki();ji();li()}function mi(b){const c="white green blue purple orange red".split(" ");return b.sort((e,g)=>c.indexOf(e)-c.indexOf(g))}function ni(){const b=document.querySelector(".rule-row-template");var c=JSON.parse(localStorage.getItem("smeltingSettings"))||
[];document.querySelectorAll(".rule-row").forEach(e=>{e.remove()});if(0===c.length){c=b.cloneNode(!0);c.classList.remove("rule-row-template");c.classList.add("rule-row");c.style.display="block";const e=c.querySelector(".rule-suffix-input");c.querySelector(".rule-prefix-input").style.display="block";e.style.display="block";document.querySelector(".rule-container").insertBefore(c,document.querySelector(".add-rule-btn"))}else c.forEach(e=>{const g=b.cloneNode(!0);g.classList.remove("rule-row-template");
g.classList.add("rule-row");g.style.display="block";g.querySelector(".rule-condition-select").value=e.condition;var l=g.querySelector(".rule-prefix-input");const h=g.querySelector(".rule-suffix-input");"nameContains"===e.condition?(l.style.display="block",l.value=e.prefix,h.style.display="block",h.value="undefined"===typeof e.suffix?null:e.suffix):(l.style.display="none",h.style.display="none");g.querySelector(".rule-level").value=e.level;e.itemTypes.forEach(k=>{(k=g.querySelector(`.item-icon[data-type="${k}"]`))&&
k.classList.add("selected")});e.colors.forEach(k=>{(k=g.querySelector(`.color-circle[data-color="${k}"]`))&&k.classList.add("selected")});"none"!==e.hammerState&&(l=g.querySelector(`.rule-hammer-selection img[data-hammer="${e.hammerState}"]`))&&l.classList.add("selected");g.querySelector(".rule-checkbox").checked=!1!==e.isEnabled;document.querySelector(".rule-container").insertBefore(g,document.querySelector(".add-rule-btn"))});Ff()}function Vc(){Da.colors=mi(Da.colors);localStorage.setItem("smeltRandomlySettings",
JSON.stringify(Da))}function oi(){document.querySelectorAll(".item-icon2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.type;this.classList.contains("selected")?(this.classList.remove("selected"),Da.itemTypes=Da.itemTypes.filter(e=>e!==c)):(this.classList.add("selected"),Da.itemTypes.push(c));Vc()})});document.querySelectorAll(".rule-color-selection2 .color-circle2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.color;this.classList.contains("selected")?
(this.classList.remove("selected"),Da.colors=Da.colors.filter(e=>e!==c)):(this.classList.add("selected"),Da.colors.push(c));Vc()})});document.querySelectorAll(".rule-color-resetColors .color-circle3").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),ic.colors=ic.colors.filter(e=>e!==c)):(this.classList.add("selected"),ic.colors.push(c));localStorage.setItem("resetColors",JSON.stringify(ic))})});document.querySelectorAll(".rule-hammer-selection2 img").forEach(b=>
{b.addEventListener("click",function(){this.classList.contains("selected")?(this.classList.remove("selected"),Da.hammerState="none"):(document.querySelectorAll(".rule-hammer-selection2 img").forEach(c=>c.classList.remove("selected")),this.classList.add("selected"),Da.hammerState=this.dataset.hammer);Vc()})})}function pi(){const b=JSON.parse(localStorage.getItem("resetColors"))||{};b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-resetColors .color-circle3[data-color="${c}"]`))&&
c.classList.add("selected")})}function qi(){var b=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{};b.itemTypes&&b.itemTypes.forEach(c=>{(c=document.querySelector(`.item-icon2[data-type="${c}"]`))&&c.classList.add("selected")});b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-selection2 .color-circle2[data-color="${c}"]`))&&c.classList.add("selected")});b.hammerState&&"none"!==b.hammerState&&(b=document.querySelector(`.rule-hammer-selection2 img[data-hammer="${b.hammerState}"]`))&&
b.classList.add("selected")}async function Wc(b){function c(u){let A=u.target.name;u=Number(u.target.value);let B=JSON.parse(localStorage.getItem("gods"));B||={Wo:3,so:3,To:3,Vo:3,co:3,mp:3};B[A]=u;localStorage.setItem("gods",JSON.stringify(B))}function e(){document.getElementById("items-repaired").textContent=oa.Sm;document.getElementById("items-reset").textContent=oa.Tm;document.getElementById("gold-cycled").textContent=oa.Qm;document.getElementById("arena-attacks").textContent=oa.Em;document.getElementById("circus-attacks").textContent=
oa.Hm;document.getElementById("dungeons-attacked").textContent=oa.Km;document.getElementById("expeditions-attacked").textContent=oa.Mm;document.getElementById("items-smelted").textContent=oa.Um;document.getElementById("underworld-attacks").textContent=oa.bn;document.getElementById("arena-money").textContent=Math.floor(oa.om).toLocaleString();document.getElementById("circus-money").textContent=Math.floor(oa.pm).toLocaleString()}function g(){var u=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||
[],A=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];h("IgnoredprefixList",u,"IgnoredPrefixes");h("IgnoredsuffixList",A,"IgnoredSuffixes");u=JSON.parse(localStorage.getItem("auctionPrefixes"))||[];A=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];h("AuctionprefixList",u,"auctionPrefixes");h("AuctionsuffixList",A,"auctionSuffixes");var B=JSON.parse(localStorage.getItem("smeltedItems"))||[];A=document.getElementById("smeltedList");let H=JSON.parse(localStorage.getItem("bidList"))||[];
for(u=document.getElementById("bidList");A.firstChild;)A.firstChild.remove();for(var G of B)B=document.createElement("li"),B.textContent=G,A.appendChild(B);for(;u.firstChild;)u.firstChild.remove();for(let K of H)G=document.createElement("li"),G.textContent=K,u.appendChild(G)}function l(u,A,B){""!==A.trim()&&(u=JSON.parse(localStorage.getItem(B))||[],u.push(A),localStorage.setItem(B,JSON.stringify(u)),g())}function h(u,A,B){let H=document.getElementById(u);H.innerHTML="";A.forEach((G,K)=>{let L=document.createElement("li");
L.textContent=G;L.draggable=!0;L.setAttribute("data-index",K);K=document.createElement("button");K.textContent="X";K.style.marginLeft="10px";K.addEventListener("click",function(){let M=A.indexOf(G);-1<M&&(A.splice(M,1),localStorage.setItem(B,JSON.stringify(A)),h(u,A,B))});L.appendChild(K);H.appendChild(L)});k(H,A,B)}function k(u,A,B){let H=-1;u.addEventListener("dragstart",G=>{H=parseInt(G.target.getAttribute("data-index"),10)});u.addEventListener("dragover",G=>{G.preventDefault()});u.addEventListener("drop",
G=>{G.preventDefault();G=parseInt(G.target.closest("li").getAttribute("data-index"),10);0<=G&&0<=H&&([A[H],A[G]]=[A[G],A[H]],localStorage.setItem(B,JSON.stringify(A)),h(u.id,A,B));g()})}function q(){setInterval(()=>{if(vf("randomPause")){const u=localStorage.getItem("selectedPauseDuration");n(u)}},6E4)}function n(u){let A,B;switch(u){case "1":B=8;A={mod:"work",submod:"start",sh:W("sh"),qm:1,Am:B,um:2};break;case "2":B=6;A={mod:"work",submod:"start",sh:W("sh"),qm:1,Am:B,um:3};break;case "3":B=3;A=
{mod:"work",submod:"start",sh:W("sh"),qm:1,Am:B,um:4};break;case "4":B=10;A={mod:"work",submod:"start",sh:W("sh"),qm:1,Am:B,um:5};break;case "5":B=4,A={mod:"work",submod:"start",sh:W("sh"),qm:1,Am:B,um:6}}$.post(T({}),A).done(()=>{setTimeout(()=>{location.reload()},6E4*(B+1));Y("randomPause",Math.floor(1440*Math.random())+600)}).fail(()=>{})}const m=b.dataset.target;document.querySelectorAll(".popup-tab").forEach(u=>{u.classList.remove("active")});b.classList.add("active");document.querySelectorAll(".popup-box").forEach(u=>
{u.classList.remove("active")});document.getElementById(m).classList.add("active");document.querySelectorAll("input[type=radio]").forEach(u=>{u.addEventListener("change",c);let A=JSON.parse(localStorage.getItem("gods"));A&&void 0!==A[u.name]&&(u.checked=u.value==A[u.name])});document.getElementById("reset-stats-button").addEventListener("click",()=>{oa.Sm=0;oa.Tm=0;oa.Qm=0;oa.Em=0;oa.Hm=0;oa.Km=0;oa.Mm=0;oa.Um=0;oa.bn=0;oa.om=0;oa.pm=0;localStorage.setItem("userStats",JSON.stringify(oa));e()});e();
b=document.querySelector(".add-rule-btn");b.removeEventListener("click",Ef);b.addEventListener("click",Ef);ni();pi();qi();document.getElementById("smeltLootbox").checked="true"===localStorage.getItem("smeltLootbox");document.getElementById("smeltLootbox").addEventListener("change",function(){localStorage.setItem("smeltLootbox",this.checked)});document.getElementById("smelteverything3").checked="true"===localStorage.getItem("smelteverything3");document.getElementById("smelteverything3").addEventListener("change",
function(){localStorage.setItem("smelteverything3",this.checked)});document.getElementById("smelthighercolors").checked="true"===localStorage.getItem("smelthighercolors");document.getElementById("smelthighercolors").addEventListener("change",function(){localStorage.setItem("smelthighercolors",this.checked)});document.getElementById("smeltAnything").checked="true"===localStorage.getItem("smeltAnything");document.getElementById("smeltAnything").addEventListener("change",function(){localStorage.setItem("smeltAnything",
this.checked)});document.getElementById("RepairBeforeSmelt").checked="true"===localStorage.getItem("RepairBeforeSmelt");document.getElementById("RepairBeforeSmelt").addEventListener("change",function(){localStorage.setItem("RepairBeforeSmelt",this.checked)});const r=document.getElementById("expeditionSearchTypeX");if(b=localStorage.getItem("nestSearchType"))r.value=b;r.addEventListener("change",()=>{localStorage.setItem("nestSearchType",r.value)});const w=document.getElementById("NestDelay");w.addEventListener("change",
function(){localStorage.setItem("NestDelay",w.value)});const v=document.getElementById("runNestUnderworld");v.addEventListener("change",function(){localStorage.setItem("runNestUnderworld",v.checked)});const y=document.getElementById("runNestEvent");y.addEventListener("change",function(){localStorage.setItem("runNestEvent",y.checked)});const D=document.getElementById("runNestDungeon");D.addEventListener("change",function(){localStorage.setItem("runNestDungeon",D.checked)});const C=document.getElementById("runNestExpedition");
C.addEventListener("change",function(){localStorage.setItem("runNestExpedition",C.checked)});document.getElementById("NestDelay").value=localStorage.getItem("NestDelay")||200;document.getElementById("runNestUnderworld").checked="true"===localStorage.getItem("runNestUnderworld");document.getElementById("runNestEvent").checked="true"===localStorage.getItem("runNestEvent");document.getElementById("runNestDungeon").checked="true"===localStorage.getItem("runNestDungeon");document.getElementById("runNestExpedition").checked=
"true"===localStorage.getItem("runNestExpedition");document.getElementById("IgnoredaddPrefixButton").onclick=function(){let u=document.getElementById("newIgnoredPrefixInput").value;l("IgnoredprefixList",u,"IgnoredPrefixes")};document.getElementById("IgnoredaddSuffixButton").onclick=function(){let u=document.getElementById("newIgnoredSuffixInput").value;l("IgnoredsuffixList",u,"IgnoredSuffixes")};document.getElementById("clearSmeltedItemsHistory").addEventListener("click",function(){localStorage.setItem("smeltedItems",
JSON.stringify([]));g()});g();document.getElementById("clearBidItemsHistory").addEventListener("click",function(){localStorage.setItem("bidList",JSON.stringify([]));g()});document.getElementById("AuctionaddPrefixButton").onclick=function(){let u=document.getElementById("AuctionnewPrefixInput").value;l("AuctionprefixList",u,"auctionPrefixes")};document.getElementById("AuctionaddSuffixButton").onclick=function(){let u=document.getElementById("AuctionnewSuffixInput").value;l("AuctionsuffixList",u,"auctionSuffixes")};
document.getElementById("pauseDuration").addEventListener("change",u=>{u=u.target.value;localStorage.setItem("selectedPauseDuration",u);localStorage.setItem("randomPause.timeOut",0);"0"!==u&&(Y("randomPause",Math.floor(1440*Math.random())),q())});document.getElementById("exportBtn").addEventListener("click",function(u){u.preventDefault();if(!u.target.getAttribute("data-clicked")){u.target.setAttribute("data-clicked","true");u={};var A="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");
for(var B in localStorage)A.includes(B)||(u[B]=localStorage.getItem(B));B=JSON.stringify(u);B=URL.createObjectURL(new Blob([B],{type:"application/json"}));u=document.createElement("a");u.href=B;u.download="GladBotSettings.json";u.click()}},{once:!0});b=document.getElementById("importFileBtn");const E=document.getElementById("importBtn"),t=document.getElementById("importStatus");b&&E&&t&&(b.addEventListener("click",function(){E.click()}),E.addEventListener("change",function(u){if(u=u.target.files[0]){var A=
new FileReader;A.onload=function(B){try{const H=JSON.parse(B.target.result);B="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");for(let G in H)B.includes(G)||localStorage.setItem(G,H[G]);t.textContent="Import successful! Please refresh the page."}catch(H){t.textContent="Import failed. Please check the input file and try again."}};
A.readAsText(u)}}));b=document.createElement("div");b.id="loadingSpinner";b.innerHTML='\n                <div class="spinner"></div>\n                <div class="loading-text">0</div>\n              ';document.querySelector("#selectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(u=>{u.checked=!0;u.dispatchEvent(new Event("change"))})});document.querySelector("#unselectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(u=>
{u.checked=!1;u.dispatchEvent(new Event("change"))})})}function ri(){const b=document.getElementById("expeditionLocation"),c=document.getElementById("dungeonLocation");var e=document.querySelectorAll("#submenu2 a");const g=[];for(let l=1;l<e.length;l++)e[l].classList.contains("glow")||g.push(e[l]);g.forEach(l=>{const h=document.createElement("option");h.innerText=l.innerText;h.value=(new URLSearchParams(l.href)).get("loc");b.appendChild(h);c.appendChild(h.cloneNode(!0))});if(e=localStorage.getItem("expeditionLocation"))b.value=
e;if(e=localStorage.getItem("dungeonLocation"))c.value=e}function qb(b,c,e){const g=document.createElement("li"),l="object"===typeof b?b.playerName:b;g.textContent=l;b=document.createElement("button");b.textContent="X";b.style.marginLeft="10px";b.addEventListener("click",()=>{g.remove();var h=JSON.parse(localStorage.getItem(e))||[];h=e.includes("ServerList")?h.filter(k=>"object"===typeof k&&k.playerName!==l):h.filter(k=>k!==l);localStorage.setItem(e,JSON.stringify(h))});g.appendChild(b);(c=document.getElementById(c))&&
c.appendChild(g)}function jc(b,c,e){qb(b,c,e);c=JSON.parse(localStorage.getItem(e))||[];e.includes("ServerList")?c.push({playerName:b}):c.push(b);localStorage.setItem(e,JSON.stringify(c))}function si(){const b=JSON.parse(localStorage.getItem("autoAttackList"))||[],c=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],e=JSON.parse(localStorage.getItem("avoidAttackList"))||[],g=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[],l=JSON.parse(localStorage.getItem("autoAttackCircusList"))||
[],h=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[];b.forEach(k=>qb(k,"autoAttackList","autoAttackList"));c.forEach(k=>qb(k,"autoAttackServerList","autoAttackServerList"));e.forEach(k=>qb(k,"avoidAttackList","avoidAttackList"));g.forEach(k=>qb(k,"avoidAttackCircusList","avoidAttackCircusList"));l.forEach(k=>qb(k,"autoAttackCircusList","autoAttackCircusList"));h.forEach(k=>qb(k,"autoAttackCircusServerList","autoAttackCircusServerList"))}function Gf(){sessionStorage.setItem("autoGoActive",
"true");document.getElementById("autoGoButton").innerHTML='<span style="position: relative; top: -9px;">&#9724;</span>';document.getElementById("autoGoButton").removeEventListener("click",Gf);document.getElementById("autoGoButton").addEventListener("click",Hf);location.reload()}function Hf(){sessionStorage.setItem("autoGoActive","false");window.location.reload()}function kc(){const b=document.getElementById("popup-header"),c=document.getElementById("overlayBack");b&&(localStorage.setItem("AucTab",
!0),b.remove());c&&c.remove()}function lc(){function b(t,u,A,B){$(`${t}_true`).click(()=>u(A));$(`${t}_false`).click(()=>u(B))}function c(t){Fa=t;localStorage.setItem("doExpedition",t)}function e(t){Ga=t;localStorage.setItem("doDungeon",t)}function g(t){Ha=t;localStorage.setItem("doArena",t)}function l(t){Ma=t;localStorage.setItem("doCircus",t)}function h(t){Sa=t;localStorage.setItem("doQuests",t)}function k(t){Ia=t;localStorage.setItem("doEventExpedition",t)}function q(t){ib=t;localStorage.setItem("AutoAuction",
t)}function n(t){rb=t;localStorage.setItem("doKasa",t)}function m(t){$(".monster-button").removeClass("active");$(`#set_dungeon_difficulty_${t}`).addClass("active")}function r(t){mc=t;localStorage.setItem("eventMonsterId",t);kc();lc()}function w(){var t=localStorage.getItem("doExpedition");null!==t&&(Fa=JSON.parse(t));1==Fa?$("#doExpedition").prop("checked",!0):$("#doExpedition").prop("checked",!1);t=localStorage.getItem("doDungeon");null!==t&&(Ga=JSON.parse(t));1==Ga?$("#doDungeon").prop("checked",
!0):$("#doDungeon").prop("checked",!1);t=localStorage.getItem("doArena");null!==t&&(Ha=JSON.parse(t));1==Ha?$("#doArena").prop("checked",!0):$("#doArena").prop("checked",!1);t=localStorage.getItem("doCircus");null!==t&&(Ma=JSON.parse(t));1==Ma?$("#doCircus").prop("checked",!0):$("#doCircus").prop("checked",!1);t=localStorage.getItem("doQuests");null!==t&&(Sa=JSON.parse(t));1==Sa?$("#doQuests").prop("checked",!0):$("#doQuests").prop("checked",!1);t=localStorage.getItem("AutoAuction");null!==t&&(ib=
JSON.parse(t));1==ib?$("#activateAutoBid").prop("checked",!0):$("#activateAutoBid").prop("checked",!1);t=localStorage.getItem("doKasa");null!==t&&(rb=JSON.parse(t));1==rb?$("#doKasa").prop("checked",!0):$("#doKasa").prop("checked",!1);t=localStorage.getItem("doEventExpedition");null!==t&&(Ia=JSON.parse(t));1==Ia?$("#doEventExpedition").prop("checked",!0):$("#doEventExpedition").prop("checked",!1);$("#expedition_settings").addClass(Fa?"active":"inactive");$(`#do_expedition_${Fa}`).addClass("active");
$(`#set_monster_id_${Xc}`).addClass("active");$("#dungeon_settings").addClass(Ga?"active":"inactive");$(`#do_dungeon_${Ga}`).addClass("active");$(`#set_dungeon_difficulty_${Kb}`).addClass("active");$("#arena_settings").addClass(Ha?"active":"inactive");$(`#do_arena_${Ha}`).addClass("active");$(`#set_arena_opponent_level_${If}`).addClass("active");$("#circus_settings").addClass(Ma?"active":"inactive");$(`#do_circus_${Ma}`).addClass("active");$(`#set_circus_opponent_level_${Jf}`).addClass("active");
$("#quests_settings").addClass(Sa?"active":"inactive");$(`#do_quests_${Sa}`).addClass("active");for(const u in Na)Na[u]&&$(`#do_${u}_quests`).addClass("active");$("#auto_auction_settings").addClass(ib?"active":"inactive");$("#event_expedition_settings").addClass(Ia?"active":"inactive");$(`#do_event_expedition_${Ia}`).addClass("active");$(`#set_event_monster_id_${mc}`).addClass("active")}var v=document.getElementById("popup-header"),y=document.getElementById("overlayBack");v&&v.remove();y&&y.remove();
v=document.createElement("div");v.setAttribute("id","popup-header");y=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio! | Active the Bot!";v.innerHTML=`
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

            <div id="popupSmelt" class="popup">
                <div class="smelt-instructions" style="text-align: left; padding-left: 5px;">
                    <ul style="list-style-position: inside;">
                        <li>1. ${d.Vj}</li>
                        <li>2. ${d.Wj}</li>
                        <li>3. ${d.Xj}</li>
                        <li>4. ${d.Yj}</li>

                        <br>${d.Zj}</br>
                        <br>${d.$j}</br>
                    </ul>
                </div>
                <img src="https://raw.githubusercontent.com/fociisoftware/glbt/refs/heads/main/Smelt2.gif" alt="Smelt Info" style="width: 350px; height: auto;">
            </div>

            <div id="announcement" class="announcement">
                ${y}
            </div>

            <div class="popup-menu">
                <div class="popup-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Version 1.1.8</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Contact us</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Update</a></span>
                <div style="display: flex; justify-content: space-between; align-items: right;">    
                <div class="menu-type logo" style="width: 48px; height: 48px; margin-right: 250px;"></div>
            
              </div>

              <span id="settingsLanguage" style="margin-left: 300px; right: 17px; top: 32px;">          
                <img class="menu-type GB" id="languageGB"> 
                <img class="menu-type PL" id="languagePL"> 
                <img class="menu-type ES" id="languageES"> 
                <img class="menu-type TR" id="languageTR">
                <img class="menu-type FR" id="languageFR">
                <img class="menu-type HG" id="languageHG">
                <img class="menu-type BR" id="languageBR">
                <br>
                <a style="color: white" href="https://gldbotserver.com/home-gld">Donate</a>
                 - 
                 <a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank"> Tutorial</a>
                 -
                <span style="color: white;">Made with <span style="color: red;">&#10084;</span></span>
                 </span>
              
              </div><span id="settingsLanguage"></span>

              <div class="popup-content">
                <ul class="popup-tabs">
                
                <li class="popup-tab" data-target="expedition_settings">
                    <div class="headericon_big" id="icon_expeditionpoints" style="margin-left: 4px;"></div>

                    ${d.expedition}
                    <div class="toggle-switch">
                    <input type="checkbox" id="doExpedition">
                    <label class="switch" for="doExpedition"></label>
                    </div>
                </li>

                  <li class="popup-tab" data-target="dungeon_settings">
                  <div class="headericon_big" id="icon_dungeonpoints" style="margin-left: 4px;"></div>
                  ${d.dungeon}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doDungeon">
                      <label class="switch" for="doDungeon"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="arena_settings">
                  <div class="headericon_big" id="icon_arena" style="margin-left: 4px;"></div>
                  ${d.arena}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doArena">
                      <label class="switch" for="doArena"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="circus_settings">
                  <div class="headericon_big" id="icon_grouparena" style="margin-left: 4px;"></div>
                  ${d.circusTurma}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doCircus">
                      <label class="switch" for="doCircus"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="underworld_settings">
                  <div class="quest-type underworld" style="margin-left: 4px;"></div>
                  ${d.yi}
                    <div class="toggle-switch">
                      <input type="checkbox" id="autoEnterHell">
                      <label class="switch" for="autoEnterHell"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="quests_settings">
                  <div class="quest-type menu"></div>
                  ${d.Ij}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doQuests">
                      <label class="switch" for="doQuests"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="heal_settings">
                  <div class="quest-type potion"></div>
                  ${d.jj}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doHeal">
                      <label class="switch" for="doHeal"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="event_expedition_settings">
                  <div class="quest-type event"></div>${d.eventExpedition}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doEventExpedition">
                      <label class="switch" for="doEventExpedition"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_auction_settings">
                  <div class="quest-type search"></div>
                  ${d.A}
                  
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateAutoBid">
                      <label class="switch" for="activateAutoBid">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_auction2_settings">
                    <div class="quest-type auction"></div>
                    ${d.Nd}
                    <div class="toggle-switch ">
                      <input type="checkbox" id="activateAuction2">
                      <label class="switch" for="activateAuction2">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_smelt_settings">
                  <div class="quest-type smelt"></div>${d.Gh}
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateSmelt">
                      <label class="switch" for="activateSmelt">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_repair_settings">
                  <div class="quest-type repair"></div>
                  ${d.Pb}
                  <div class="toggle-switch">
                    <input type="checkbox" id="activateRepair">
                    <label class="switch" for="activateRepair">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="Market">
                  <div class="quest-type market"></div>
                  ${d.ig}
                  <div class="toggle-switch">
                  <div class="toggle-bg"></div>
                  </div>
                  </li>

                  <li class="popup-tab" data-target="guild_settings">
                    <div class="quest-type guild"></div>
                    ${d.fj}
                    <div class="toggle-bg"></div>
                  </li>
                  
                 
                  <li class="popup-tab" data-target="Timers">
                    <div class="quest-type timer"></div>
                    ${d.$b} 
                    <div class="toggle-switch">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="other_settings2">
                  <div class="quest-type reset">
                  </div>${d.mh}
                  </li>
                  

                  <li class="popup-tab" data-target="other_settings">
                  <div class="quest-type settings"></div>
                  ${d.Lg}
                  <div class="toggle-bg"></div>
                  </li>

                  


                  <li class="popup-tab" data-target="Extra">
                  <div class="quest-type extra">
                  </div>${d.qb}
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div> </li>

                </ul>

            <div class="popup-box" id="expedition_settings">

                <div class="settings-tab">
                    <div class="settings_tab_title">${d.aj}</div>
                    <div class="setting-row">
                        <label for="expeditionLocation">${d.Se}</label>
                        <select id="expeditionLocation"></select>
                    </div>

                    <div class="setting-row">
                        <label for="autoCollectBonuses">${d.Rd}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoCollectBonuses">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="enemySelection" class="setting-row">
                        <label for="enemySelect">${d.Lj}:</label>
                        <select id="enemySelect">
                            <option value="0">1</option>
                            <option value="1">2</option>
                            <option value="2">3</option>
                            <option value="3">Boss</option>
                        </select>
                    </div>

                    <div id="expeditionSearchType" class="setting-row">
                        <label for="expeditionSearchTypeX">${d.sj}:</label>
                        <select id="expeditionSearchTypeX">
                            <option value="" selected disabled>Select an option</option>
                            <option value="nothing">${d.qj}</option>
                            <option value="quick">${d.rj}</option>
                            <option value="thorough">${d.tj}</option>
                        </select>
                        <hr>

                        <div>
                            <label for="NestDelay">Delay to click nest (Suggested MS:200):</label>
                            <input type="number" id="NestDelay" value="200" min="0" style="width: 80px;" />
                        </div>

                        <div>
                            <label><input type="checkbox" id="runNestUnderworld" />Underworld</label>
                            <label><input type="checkbox" id="runNestEvent" />Event</label>
                            <label><input type="checkbox" id="runNestDungeon" />Dungeon</label>
                            <label><input type="checkbox" id="runNestExpedition" />Expedition</label>
                        </div>

                        <hr>

                        <!-- Existing tutorial span -->
                        <span class="span-new">${d.uj}</span>

                    </div>

                </div>
  
            </div>
            
                <div class="popup-box" id="dungeon_settings">
                  <div class="settings_tab_title">${d.Xi}</div>
                  <div class="settings-tab">
                    <div class="setting-row">      
                      <label for="dungeonLocation">${d.pe}</label>
                      <select id="dungeonLocation"></select>
                    </div>

                    <div class="setting-row">
                      <span class="span-new">${d.Wi}</span>
                        <div id="set_dungeon_difficulty_normal" class="monster-button">
                          ${d.wj}
                        </div>
                        <div id="set_dungeon_difficulty_advanced" class="monster-button">
                          ${d.advanced}
                        </div>
                    </div>

                    <div class="setting-row">
                      <label for="skipBossToggle">${d.Fh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipBossToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="resetIfLoseToggle">${d.nh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="resetIfLoseToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonAB">${d.Jd}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonAB">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonFocusQuest">${d.$e}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonFocusQuest">
                        <span class="switch"></span>
                      </label>
                    </div>
                    <span class="span-new">${d.ah}</span>  

                  
                    </div>
                      <div class="tutorial-container">
                        <span class="span-new">${d.Yi}</span>  
                      </div>
                    </div>

                  <!-- ARENA -->
  
                  <div class="popup-box" id="arena_settings">
                  <div class="settings_tab_title">Arena</div>
                  <span class="span-new">${d.Ya}</span>

                  
                  <div class="settings_tab_title2">
                    <button id="tabA" class="tab-button active">Arena Local Server</button>
                    <button id="tabB" class="tab-button">Arena Other Servers</button>
                  </div>

                  <!-- Tab A Content -->
                  <div id="contentA" class="setting-row">
                    <div class="avoid-attack">
                      <div class="top-section">
                      <h3>${d.ja}</h3>
                        <div class="switch-field2">
                          <input type="text" id="autoAttackInput" placeholder="${d.ia}">
                          <button id="addAutoAttack" class="awesome-button">${d.ha}</button>
                          <button id="ClearAttackList" class="awesome-button">Clear List</button>
                        </div>
                      </div>
                      <ul id="autoAttackList" class="scrollable-list"></ul>
                    </div>
                  </div>

                  <!-- Tab B Content -->
                  <div id="contentB" class="setting-row" style="display: none;">
                    <div class="avoid-attack">
                      <div class="top-section">
                        <h3>${d.ja}</h3>
                        </div>
                        <button id="ClearOtherAttackList" class="awesome-button">Clear List</button>
                        <ul id="autoAttackServerList" class="scrollable-list"></ul>
                      </div>
                  </div>

                  <div class="setting-row">
                    <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.fc}</h3>
                            <div class="switch-field2">
                                <input type="text" id="avoidAttackInput" placeholder="${d.ia}">
                                <button id="addAvoidAttack" class="awesome-button">${d.ha}</button>
                                <button id="ClearAvoidList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="avoidAttackList" class="scrollable-list"></ul>
                        ${d.hc}
                    </div>
                  </div>

                  <!--
                  <div class="setting-row" data-tooltip="${d.Hj}">
                    <label for="enableArenaSimulator">Enable Simulator Attack [Premium]</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="enableArenaSimulator">
                        <span class="switch"></span>
                    </label>    
                  </div>


                 <div class="setting-row">
                      <label for="ArenaSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                      <div class="switch-field3">
                        <input type="number" id="ArenaSimulatorAmount" min="1" max="100" value="${localStorage.getItem("ArenaSimulatorAmount")||60}">
                      </div>
                </div>
                -->

                  <div class="setting-row">
                    <label for="arenaAttackGM">${d.Ua}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="arenaAttackGM">
                      <span class="switch"></span>
                    </label>    
                  </div>

                    <div class="setting-row" data-tooltip="${d.ec}">
                        <label for="onlyArena">${d.Sg}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="onlyArena">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row" data-tooltip="${d.dc}">
                        <label for="onlyPlayerListArena">${d.cc}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="onlyPlayerListArena">
                            <span class="switch"></span>
                        </label>    
                    </div>

                <div class="setting-row">
                    <label for="attackRandomly">${d.Li}</label>
                    
                    <label class="toggle-switch">
                    <input type="checkbox" id="attackRandomly">
                    <span class="switch"></span>
                    </label>    
                    <h3>${d.Mi}</h3>
                </div>

                  <div class="setting-row">
                    <div class="switch-field3">
                    <input type="number" id="autoAddArenaAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddArenaAmount")||0}">
                    </div>
                      <label for="autoAddArena">${d.Sa}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="autoAddArena">
                        <span class="switch"></span>
                      </label>
                  </div>
  
                  <div class="setting-row">
                    <label for="autoAvoidArena">${d.Ta}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="autoAvoidArena">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="scoreboard-attack">
                    <div class="settings_tab_title">${d.Tb}</div>
                    <div class="setting-row">
                    <label for="scoreboardattackenable">${d.pb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="scoreboardattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="scoreRange">${d.Rb}</label>
                    <select id="scoreRange" class="input">
                      <option value="1">1-50</option>
                      <option value="2">51-100</option>
                      <option value="3">101-150</option>
                      <option value="4">151-200</option>
                      <option value="5">201-250</option>
                      <option value="6">251-300</option>
                      <option value="7">301-350</option>
                      <option value="8">351-400</option>
                      <option value="9">401-450</option>
                      <option value="10">451-500</option>
                      <option value="11">501-550</option>
                      <option value="12">551-600</option>
                      <option value="13">601-650</option>
                      <option value="14">651-700</option>
                      <option value="15">701-750</option>
                      <option value="16">751-800</option>
                      <option value="17">801-850</option>
                      <option value="18">851-900</option>
                      <option value="19">901-950</option>
                      <option value="20">951-1000</option>
                      <!-- Add more options as needed -->
                    </select>
                  </div>
                  </div>
                  <span class="span-new">${d.Sb}</span>
                  
                  <div class="settings_tab_title">${d.rb}</div>

                  <div class="setting-row">
                  <label for="leagueattackenable">${d.ob}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leagueattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguerandom">${d.Nb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguerandom">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguelowtohigh">${d.Ob}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguelowtohigh">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <span class="span-new">${d.sb}</span>

                </div>

  
                  <!-- Circus -->

                  <div class="popup-box" id="circus_settings">
                    <div class="settings_tab_title">Circus</div>
                    <span class="span-new">${d.Ya}</span>

                    <div class="settings_tab_title2">
                        <button id="tabACircus" class="tab-button active">Circus Local Server</button>
                        <button id="tabBCircus" class="tab-button">Circus Other Servers</button>
                    </div>

                    <!-- Tab A Content -->
                    <div id="contentACircus" class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.ja}</h3>
                            <div class="switch-field2">
                            <input type="text" id="autoAttackCircusInput" placeholder="${d.ia}">
                            <button id="addAutoCircusAttack" class="awesome-button">${d.ha}</button>
                            <button id="ClearCircusAttackList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="autoAttackCircusList" class="scrollable-list"></ul>
                        </div>
                    </div>

                    <!-- Tab B Content -->
                    <div id="contentBCircus" class="setting-row" style="display: none;">
                        <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.ja}</h3>
                            </div>
                            <button id="ClearOtherCircusAttackList" class="awesome-button">Clear List</button>
                            <ul id="autoAttackCircusServerList" class="scrollable-list"></ul>
                        </div>
                    </div>

                        <div class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.fc}</h3>
                        <div class="switch-field2">
                            <input type="text" id="avoidAttackCircusInput" placeholder="${d.ia}">
                            <button class="awesome-button" id="addAvoidCircusAttack">${d.ha}</button>
                            <button class="awesome-button" id="ClearCircusAvoidList">Clear List</button>
                        </div>
                        </div>
                            <ul id="avoidAttackCircusList" class="scrollable-list"></ul>
                            ${d.hc}
                        </div>
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusWithoutHeal">${d.Ri}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusWithoutHeal">
                                <span class="switch"></span>
                            </label>    
                        </div>

                        <!--
                        <div class="setting-row">
                            <label for="enableCircusSimulator">Enable Simulator Attack [Premium]</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusSimulator">
                                <span class="switch"></span>
                            </label>    
                        </div>

                    <div class="setting-row">
                    <label for="CircusSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                    <div class="switch-field3">
                        <input type="number" id="CircusSimulatorAmount" min="1" max="100" value="${localStorage.getItem("CircusSimulatorAmount")||60}">
                    </div>
                </div>

                -->

                    <div class="setting-row">
                        <label for="circusAttackGM">${d.Ua}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="circusAttackGM">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row" data-tooltip="${d.ec}">
                            <label for="onlyCircus">${d.Tg}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="onlyCircus">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row" data-tooltip="${d.dc}">
                        <label for="onlyPlayerListCircus">${d.cc}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="onlyPlayerListCircus">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row">
                    <label for="attackRandomlyCircus">Attack Randomly in Provinciarum?</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="attackRandomlyCircus">
                        <span class="switch"></span>
                    </label>    
                    <h3>Also disable "Sort players in arena by level" setting in crazy-addon.</h3>
                    </div>

                        <div class="setting-row">
                        <div class="switch-field3">
                        <input type="number" id="autoAddCircusAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddCircusAmount")||0}">
                        </div>
                            <label for="autoAddCircus">${d.Sa}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="autoAddCircus">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="autoAvoidCircus">${d.Ta}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoAvoidCircus">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="scoreboard-attack">
                        <div class="settings_tab_title">${d.Tb}</div>
                        <div class="setting-row">
                        <label for="scoreboardcircusenable">${d.pb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="scoreboardcircusenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="scoreRangeCircus">${d.Rb}</label>
                            <select id="scoreRangeCircus" class="input">
                            <option value="1">1-50</option>
                            <option value="2">51-100</option>
                            <option value="3">101-150</option>
                            <option value="4">151-200</option>
                            <option value="5">201-250</option>
                            <option value="6">251-300</option>
                            <option value="7">301-350</option>
                            <option value="8">351-400</option>
                            <option value="9">401-450</option>
                            <option value="10">451-500</option>
                            <option value="11">501-550</option>
                            <option value="12">551-600</option>
                            <option value="13">601-650</option>
                            <option value="14">651-700</option>
                            <option value="15">701-750</option>
                            <option value="16">751-800</option>
                            <option value="17">801-850</option>
                            <option value="18">851-900</option>
                            <option value="19">901-950</option>
                            <option value="20">951-1000</option>
                            <!-- Add more options as needed -->
                            </select>
                        </div>
                        </div>
                        <span class="span-new"> ${d.Sb} </span>
                        
                        <div class="settings_tab_title">${d.rb}</div>

                        <div class="setting-row">
                        <label for="leaguecircusattackenable">${d.ob}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusattackenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="leaguecircusrandom">${d.Nb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusrandom">
                            <span class="switch"></span>
                        </label>
                        </div>
    
                        <div class="setting-row">
                        <label for="leaguecircuslowtohigh">${d.Ob}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircuslowtohigh">
                            <span class="switch"></span>
                        </label>
                        </div>
                        <span class="span-new">${d.sb}</span>

                  </div>

                  <div class="popup-box" id="underworld_settings">

                    <div class="settings_tab_title">${d.ff}</div>
                        <span class="span-new"> ${d.gf}</span>
                        <div class="setting-row">
                            <label for="hellDifficulty">${d.df}</label>
                            <select id="hellDifficulty">
                                <option value="0">${d.Vi}</option>
                                <option value="1">${d.Ui}</option>
                                <option value="2">${d.Ti}</option>
                            </select>
                        </div>

                    <div class="setting-row">
                        <label for="hellEnterHP">${d.ve}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellEnterHP" min="1" max="99" value="${localStorage.getItem("hellEnterHP")||75}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="HellHealHP">${d.Ok}</label>
                        <div class="switch-field3">
                            <input type="number" id="HellHealHP" min="1" max="99" value="${localStorage.getItem("HellHealHP")||10}">
                        </div>
                    </div>
                    
                    <div class="setting-row" data-tooltip="${d.mj}">
                        <label for="autoEnterHell">${d.Ud} Info</label>
                    </div>

                    <div class="setting-row" data-tooltip="${d.le}">
                        <label for="dontEnterUnderworld">${d.me}</label>
                        <label class="toggle-switch">
                        
                            <input type="checkbox" id="dontEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="EnableArenaHell">${d.qe}</label>
                        <label class="toggle-switch">
                    
                        <input type="checkbox" id="EnableArenaHell">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderworldUseMobi">${d.Ei}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderworldUseMobi">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderWorldUseRuby">${d.Ii}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderWorldUseRuby">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="useSacrifice">${d.Gi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useSacrifice">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="usePray">${d.yk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="usePray">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="useClothToEnterUnderworld">${d.uk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useClothToEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="exitUnderworld">${d.ye}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="exitUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="settings_tab_title">${d.pi}</div>

                    <div class="setting-row">
                        <label for="useGodPowers">${d.si}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useGodPowers">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Multi-Selection for Gods -->
                    <div class="setting-row" id="godPowersSection" style="display: none;">
                        <label>${d.ti}</label>
                        <div class="god-selection">
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Minerva" id="godMinerva">
                                <img src="//gf3.geo.gfsrv.net/cdn8a/72919cc6b457bf475fb81cc7de8863.png" title="Minerva">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Diana" id="godDiana">
                                <img src="//gf2.geo.gfsrv.net/cdn70/026bb622a42b4d00abc74c67f28d63.png" title="Diana">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Vulcan" id="godVulcan">
                                <img src="//gf3.geo.gfsrv.net/cdn5c/6fbd05e43d699e65fc40cc92a17c51.png" title="Vulcan">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mars" id="godMars">
                                <img src="//gf2.geo.gfsrv.net/cdn76/5fd915f85b3e5e71b64632af0c6543.png" title="Mars">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Apollo" id="godApollo">
                                <img src="//gf3.geo.gfsrv.net/cdn8f/bb75bf0df76de3ec421bbfb0eac3c5.png" title="Apollo">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mercury" id="godMercury">
                                <img src="//gf3.geo.gfsrv.net/cdnbe/5e272e2aade20b4a266e48663421ce.png" title="Mercury">
                            </label>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="weaponBuff">${d.ui}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="weaponBuff">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Armor Buff Section -->
                    <div class="setting-row">
                        <label>${d.vi}</label>
                        <div class="armor-selection">
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Armor" id="armorBuffArmor"> ${d.O}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Helmet" id="armorBuffHelmet"> ${d.S}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Gloves" id="armorBuffGloves"> ${d.R}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Boots" id="armorBuffBoots"> ${d.P}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Shield" id="armorBuffShield"> ${d.U}
                            </label>
                        </div>
                    </div>

                    <!-- Farm Section (As Is) -->
                    <div class="settings_tab_title">${d.Xe}</div>
                    <span class="span-new">${d.Ye}: </span>
                    <div class="setting-row">
                        <label for="farmEnable">${d.v}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="farmEnable">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="farmLocation">${d.We}</label>
                        <select id="farmLocation">
                            <option value="0">Entrance</option>
                            <option value="1">Court of the Dead</option>
                            <option value="2">Tartarus</option>
                            <option value="3">Erebus</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="farmEnemy">${d.Ve}:</label>
                        <select id="farmEnemy">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">Boss</option>
                        </select>
                    </div>

                    <div class="setting-row" data-tooltip="${d.lj}">
                          <label for="useVillaMedici">${d.re}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="EnableHellLimit">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="hellLimit">${d.kj}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellLimit" min="1" max="200" value="${localStorage.getItem("hellLimit")||5}">
                        </div>
                    </div>

                    <div class="settings_tab_title">${d.ef}</div>
                    <div class="setting-row">
                          <label for="useVillaMedici">${d.Hi}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useVillaMedici">
                              <span class="switch"></span>
                          </label>
                    </div>
                    
                    <div class="setting-row">
                        <label for="useHealingPotion">${d.Fi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useHealingPotion">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <span class="span-new"> ${d.ri}</span>
                    <span class="span-new">${d.zi}</span>

                    <div class="settings_tab_title">${d.Sd}</div>
                    <span class="span-new">Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.</span>
                    <div class="setting-row">
                          <label for="useCostume">${d.Di}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useCostume">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="wearUnderworld">${d.Ji}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="wearUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    
                    <div id="costumeUnderworldWrapper" style="display:none;">
                      <div class="setting-row">
                          <label for="costumeUnderworld">${d.ee}</label>
                          <select id="costumeUnderworld">
                              <option value="9">Dis Pater Normal</option>
                              <option value="10">Dis Pater Medium</option>
                              <option value="11">Dis Pater Hard</option>
                          </select>
                      </div>
                    </div>                

                    <div class="setting-row">
                      <label for="costumeBasic">${d.Xd}</label>
                      <select id="costumeBasic">
                          <option value="1">${d.$a}</option>
                          <option value="2">${d.eb}</option>
                          <option value="3">${d.fb}</option>
                          <option value="4">${d.gb}</option>
                          <option value="5">${d.hb}</option>
                          <option value="6">${d.ib}</option>
                          <option value="7">${d.jb}</option>
                          <option value="8">${d.kb}</option>
                          <option value="12">${d.lb}</option>
                          <option value="13">${d.ab}</option>
                          <option value="14">${d.bb}</option>
                          <option value="15">${d.cb}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <label for="costumeDungeon">${d.oe}</label>
                      <select id="costumeDungeon">
                          <option value="1">${d.$a}</option>
                          <option value="2">${d.eb}</option>
                          <option value="3">${d.fb}</option>
                          <option value="4">${d.gb}</option>
                          <option value="5">${d.hb}</option>
                          <option value="6">${d.ib}</option>
                          <option value="7">${d.jb}</option>
                          <option value="8">${d.kb}</option>
                          <option value="12">${d.lb}</option>
                          <option value="13">${d.ab}</option>
                          <option value="14">${d.bb}</option>
                          <option value="15">${d.cb}</option>
                      </select>
                    </div>
                    <span class="span-new">${d.Td}</span>

                </div>
                  
                  <div class="popup-box" id="quests_settings">

                    <div class="settings_tab_title">Quests</div>

                    <div class="setting-row">
                      <div class="monster-buttons">
                        <span class="span-new">${d.type}</span>
                        <div class="quest-container">
                          <div id="do_combat_quests" class="settingsButton quest-type combat"></div>
                          <div id="do_arena_quests" class="settingsButton quest-type arena"></div>
                          <div id="do_circus_quests" class="settingsButton quest-type circus"></div>
                          <div id="do_expedition_quests" class="settingsButton quest-type expedition"></div>
                          <div id="do_dungeon_quests" class="settingsButton quest-type dungeon"></div>
                          <div id="do_items_quests" class="settingsButton quest-type items"></div>
                        </div>
                      </div>
                    </div>

                    <div class="settings_tab_title">Quest Settings</div>

                    <div class="setting-row">
                      <label for="skipTimeQuests">Arena ${d.Ea}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipTimeQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeCircusQuests">Circus ${d.Ea}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeCircusQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeOtherQuests">Other ${d.Ea}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeOtherQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                      <label for="UnderworldQuests">${d.xi}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="UnderworldQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row" id="underworldKeywordSection" style="display: none;">
                    ${d.wi}
                    <div class="input-container">
                        <input type="text" id="underworldKeywordInput" placeholder="${d.X}">
                        <button class="awesome-button" id="addUnderworldKeywordBtn">${d.K}</button>
                    </div>
                    <div id="underworldKeywordList"></div>
                </div>

                    <div class="setting-row">
                    <label for="acceptnotfilter">${d.Vg}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="acceptnotfilter">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="settings_tab_title">${d.bh}</div>
                      <div class="setting-row">
                        ${d.Ug}
                        <select id="questSpeed">
                        <option value="0">5x</option>
                        <option value="1">4x</option>
                        <option value="2">3x</option>
                        <option value="3">2x</option>
                        <option value="4">1x</option>
                      </select>
                    </div>
                    <div class="settings_tab_title">${d.Zg}</div>

                    <div class="setting-row">
                      ${d.Yg}
                      <div class="input-container">
                      <input type="text" id="keywordInput" placeholder="${d.X}">
                      <button class="awesome-button" id="addKeywordBtn">${d.K}</button>
                      </div>
                      <div id="keywordList"></div>
                    </div>
                    
                    <div class="settings_tab_title">${d.Wg}</div>

                    <div class="setting-row">
                        ${d.Xg}
                        <div class="input-container">
                            <input type="text" id="keywordAcceptInput" placeholder="${d.X}">
                            <button class="awesome-button" id="addKeywordAcceptBtn">${d.K}</button>
                        </div>
                        <div id="keywordAcceptList"></div>
                    </div>      

                    <div class="setting-row">
                        <label for="questrewardvalue">${d.oh}</label>
                        <div class="switch-field3">
                            <input type="number" id="questrewardvalue" min="1" max="99999" value="${localStorage.getItem("questrewardvalue")||2E3}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label>${d.$g}</label>
                        <div class="input-container">
                            <label><input type="checkbox" id="questTypeMercury"> Mercury</label>
                            <label><input type="checkbox" id="questTypeApollo"> Apollo</label>
                            <label><input type="checkbox" id="questTypeDiana"> Diana</label>
                            <label><input type="checkbox" id="questTypeMinerva"> Minerva</label>
                            <label><input type="checkbox" id="questTypeVulcan"> Vulcan</label>
                            <label><input type="checkbox" id="questTypeMars"> Mars</label>
                        </div>
                    </div>

                    
                    </div>


                <div class="popup-box" id="heal_settings">
                  <div class="monster-buttons">
                  </div>
                  <div class="settings_tab_title">${d.ij}</div>

                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; margin-right: 50px;">
                  </div>

                  <div class="setting-row">
                  <label for="healPercentage">${d.hj}</label>
                  <div class="switch-field3">
                    <input type="number" id="healPercentage" min="1" max="99" value="${localStorage.getItem("healPercentage")||75}">
                  </div>
                </div>

                  <div class="setting-row">
                  <img style="margin-top: -10px" src="https://gf3.geo.gfsrv.net/cdneb/91e0372cccc24f52758be611a10a3b.png">
                  <label for="HealClothToggle">${d.rh}</label>
                  
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealClothToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="HealRubyToggle">${d.dm}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealRubyToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healShopToggle">${d.wk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healShopToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healfrompackage">${d.xk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healfrompackage">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="HealPickBag">${d.cf}</label>
                     <select id="HealPickBag" class="input">
                     <option value="1">
                        1
                      </option>
                      <option value="2">
                        2
                      </option>
                      <option value="3">
                        3
                      </option>
                      <option value="4">
                        4
                      </option>
                      <option value="5">
                        5
                      </option>
                      <option value="6">
                        6
                      </option>
                      <option value="7">
                        7
                      </option>
                      <option value="8">
                      8
                    </option>
                    </select>
                  </div>
                  
                  <div class="setting-row">
                  <label for="FoodAmount">${d.gj}</label>
                   <select id="FoodAmount" class="input">
                   <option value="1">
                      1
                    </option>
                    <option value="2">
                      2
                    </option>
                    <option value="3">
                      3
                    </option>
                    <option value="4">
                      4
                    </option>
                    <option value="5">
                      5
                    </option>
                    <option value="6">
                      6
                    </option>
                    <option value="7">
                      7
                    </option>
                    <option value="8">
                    8
                  </option>
                  </select>
                </div>   
                  
                <div class="setting-row" data-tooltip="${d.Qi}">
                <label for="healcervisia">${d.tk}</label>
                <label class="toggle-switch">
                    <input type="checkbox" id="healcervisia">
                    <span class="switch"></span>
                </label>
                </div>

                  <div class="setting-row">
                  <label for="HealEggs">${d.vk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealEggs">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="settings_tab_title">${d.hf}</div>
                  <span class="span-new">${d.Ig}</span>
                  <div class="setting-row" data-tooltip="${d.xj}>
                  <label for="OilEnable">${d.ue}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="OilEnable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-right: 50px;">
                        <table style="width: 100%">
                            <tbody>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Minerva:</td>
                                <td style="text-align: right;">
                                    <div class="radio-group">
                                    <input type="radio" name="minerva" value="0"><span class="span-new">I</span>
                                    <input type="radio" name="minerva" value="1"><span class="span-new">II</span>
                                    <input type="radio" name="minerva" value="2"><span class="span-new">III</span>
                                    <input type="radio" name="minerva" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Diana:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="diana" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="diana" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="diana" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="diana" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Mars:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="mars" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="mars" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="mars" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="mars" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Merkur:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="merkur" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="merkur" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="merkur" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="merkur" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Apollo:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="apollo" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="apollo" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="apollo" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="apollo" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Vulcanus:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="vulcanus" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="vulcanus" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="vulcanus" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="vulcanus" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                            </table>
                        </div>

                        <hr>
                        <!-- Container for Oil Usage Table (hidden by default if oils are disabled) -->
                        <div id="oilUsageSettings" class="oil-usage-settings" style="display: none;">
                        <h4>Oil Usage Options</h4>
                        <hr>
                        <table>
                            <thead>
                            <tr>
                                <th>Oil</th>
                                <th>Rings</th>
                                <th>Necklace</th>
                                <th>Weapons</th>
                                <th>Armor</th>
                            </tr>
                            </thead>
                            <tbody>
                            <!-- Blue Oil (only rings, necklace) -->
                            <tr>
                                <td>Blue Oil</td>
                                <td><input type="checkbox" id="blue-oil-rings"></td>
                                <td><input type="checkbox" id="blue-oil-necklace"></td>
                                <!-- Weapons & Armor not allowed for Blue Oil, so disabled -->
                                <td><input type="checkbox" disabled></td>
                                <td><input type="checkbox" disabled></td>
                            </tr>

                            <!-- Yellow Oil (rings, necklace, weapons, armor) -->
                            <tr>
                                <td>Yellow Oil</td>
                                <td><input type="checkbox" id="yellow-oil-rings"></td>
                                <td><input type="checkbox" id="yellow-oil-necklace"></td>
                                <td><input type="checkbox" id="yellow-oil-weapons"></td>
                                <td><input type="checkbox" id="yellow-oil-armor"></td>
                            </tr>

                            <!-- Orange Oil (only rings, necklace) -->
                            <tr>
                                <td>Orange Oil</td>
                                <td><input type="checkbox" id="orange-oil-rings"></td>
                                <td><input type="checkbox" id="orange-oil-necklace"></td>
                                <td><input type="checkbox" disabled></td>
                                <td><input type="checkbox" disabled></td>
                            </tr>

                            <!-- Green Oil (rings, necklace, weapons, armor) -->
                            <tr>
                                <td>Green Oil</td>
                                <td><input type="checkbox" id="green-oil-rings"></td>
                                <td><input type="checkbox" id="green-oil-necklace"></td>
                                <td><input type="checkbox" id="green-oil-weapons"></td>
                                <td><input type="checkbox" id="green-oil-armor"></td>
                            </tr>

                            <!-- Purple Oil (rings, necklace, weapons, armor) -->
                            <tr>
                                <td>Purple Oil</td>
                                <td><input type="checkbox" id="purple-oil-rings"></td>
                                <td><input type="checkbox" id="purple-oil-necklace"></td>
                                <td><input type="checkbox" id="purple-oil-weapons"></td>
                                <td><input type="checkbox" id="purple-oil-armor"></td>
                            </tr>

                            <tr>
                                <td>Red Oil</td>
                                <td><input type="checkbox" id="red-oil-rings"></td>
                                <td><input type="checkbox" id="red-oil-necklace"></td>
                                <td><input type="checkbox" id="red-oil-weapons"></td>
                                <td><input type="checkbox" id="red-oil-armor"></td>
                            </tr>
                            </tbody>
                        </table>
                        </div>
                    </div>
<div class="settings_tab_title">${d.Xa}</div>
<span class="span-new">Bot will use buffs when available.</span>

<div class="setting-row" data-tooltip="${d.Oi}>
    <label for="BuffsEnable">Enable ${d.Xa}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffsEnable">
        <span class="switch"></span>
    </label>
</div>

<div class="setting-row">
    <label for="BuffUnderworldOnly">${d.be}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffUnderworldOnly">
        <span class="switch"></span>
    </label>
</div>


<div class="setting-row">
    <div class="buff-group">
        <label>Health:</label>
        <input type="checkbox" id="HealthBuff1"> Gingko
        <input type="checkbox" id="HealthBuff2"> Taigaroot
        <input type="checkbox" id="HealthBuff3"> Hawthorn
    </div>

    <div class="buff-group">
        <label>Strength:</label>
        <input type="checkbox" id="StrengthBuff1"> Flask
        <input type="checkbox" id="StrengthBuff2"> Ampulla
        <input type="checkbox" id="StrengthBuff3"> Flacon
        <input type="checkbox" id="StrengthBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Dexterity:</label>
        <input type="checkbox" id="DexterityBuff1"> Flask
        <input type="checkbox" id="DexterityBuff2"> Ampulla
        <input type="checkbox" id="DexterityBuff3"> Flacon
        <input type="checkbox" id="DexterityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Agility:</label>
        <input type="checkbox" id="AgilityBuff1"> Flask
        <input type="checkbox" id="AgilityBuff2"> Ampulla
        <input type="checkbox" id="AgilityBuff3"> Flacon
        <input type="checkbox" id="AgilityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Constitution:</label>
        <input type="checkbox" id="ConstitutionBuff1"> Flask
        <input type="checkbox" id="ConstitutionBuff2"> Ampulla
        <input type="checkbox" id="ConstitutionBuff3"> Flacon
        <input type="checkbox" id="ConstitutionBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Charisma:</label>
        <input type="checkbox" id="CharismaBuff1"> Flask
        <input type="checkbox" id="CharismaBuff2"> Ampulla
        <input type="checkbox" id="CharismaBuff3"> Flacon
        <input type="checkbox" id="CharismaBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Intelligence:</label>
        <input type="checkbox" id="IntelligenceBuff1"> Flask
        <input type="checkbox" id="IntelligenceBuff2"> Ampulla
        <input type="checkbox" id="IntelligenceBuff3"> Flacon
        <input type="checkbox" id="IntelligenceBuff4"> Bottle
    </div>
</div>
                  </div>

                  <div class="popup-box" id="event_expedition_settings">
                    <div class="settings_tab_title">${d.eventExpedition}</div>

                    <div class="setting-row">
                        <div id="set_event_monster_id_0" class="monster-button">1</div>
                        <div id="set_event_monster_id_1" class="monster-button">2</div>
                        <div id="set_event_monster_id_2" class="monster-button">3</div>
                        <div id="set_event_monster_id_3" class="monster-button">Boss</div>
                    </div>
                    <div class="setting-row">
                        <label for="EventAutoMonsterSwitch">${d.we}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="EventAutoMonsterSwitch">
                            <span class="switch"></span>
                        </label>
                    </div>
                    <div id="clear_next_event_expedition_time" class="awesome-button">${d.eh}</div> <!-- New Button -->

                      
                      <div class="setting-row">
                      <label for="renewEvent">${d.hh}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="renewEvent">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <label for="throwDice">${d.Nh}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="throwDice">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <span class="span-new">${d.Oh}<span class="span-new">
                      
                                          </div>
                      <div class="setting-row">
                    <span class="span-new">${d.xe}<span class="span-new">
                    
                                        </div>
                    </div>

                  <div class="popup-box" id="auto_auction_settings">
                

                    <div class="settings_tab_title">${d.Pd}</div>
                    <span class="span-new">To open search panels including Unique shop items, enable this option.<span class="span-new">
                    <div class="setting-row">
                    <label for="AuctionItemLevel2">${d.Ag}</label>
                      <div class="switch-field2">
                        <input type="text" id="search_input" placeholder="${d.Cd}">
                      </div>
                    </div>

                    <div class="setting-row">
                      <label for="AuctionItemLevel2">${d.ba}</label>
                      <div class="switch-field3">
                        <input type="number" id="AuctionItemLevel2" min="1" max="1000" value="5">
                      </div>
                    </div>   

                    <div class="setting-row">
                      <label for="SearchQuality">${d.Ba}</label>
                      <select id="SearchQuality" class="input">
                          <option value="-1">
                          ${d.Ga}
                          </option>
                            <option value="0">
                            ${d.C}
                            </option>
                            <option value="1">
                            ${d.B}
                            </option>
                            <option value="2">
                            ${d.D}
                            </option>
                          </option>
                      </select>
                    </div> 

                    <div class="setting-row">
                      <label>${d.na}</label>
                      <div class="equipment-search-selection">
                          <label><input type="checkbox" class="equipment-search-option" value="2"> ${d.ga}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="4"> ${d.da}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="8"> ${d.W}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1"> ${d.Z}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="256"> ${d.Y}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="512"> ${d.ea}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="48"> ${d.ca}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1024"> ${d.V}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="9999"> ${d.Ja}</label>
                      </div>
                    </div>

                    <button class="awesome-button" id="search_button" type="button">${d.Cd}</button>
                    <button class="awesome-button" id="search_reset" type="button">${d.Id}</button>
       
                    <div class="setting-row">
                    <ul id="search_list"></ul>
                    <span class="span-new">${d.Kd}</span>
                    </div>

                    <div class="settings_tab_title">${d.vh}</div>
                    <div class="setting-row">

                      <!-- Title & Instructions -->
                      <div style="margin-bottom: 20px;">
                          <h2>${d.xh}</h2>
                          <p>${d.wh}</p>
                      </div>
                    </div>
                    <!-- Item Input Section -->

                        <div class="setting-row">
                          <label for="clothCount">${d.yh}</label>
                          <div class="switch-field2">
                              <input type="number" id="clothCount" placeholder="${d.zh}">
                          </div>
                        </div>

                        <hr class="section-separator">

                        <div class="setting-row">
                              <label for="newItem">${d.fa}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItem" placeholder="${d.fa}">
                          </div>
                        </div>

                        <div class="setting-row">
                          <label for="newItemLevel">Min ${d.Wb}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItemLevel" placeholder="Min ${d.Wb}">
                          </div>
                        </div>
                
                        <div class="setting-row">
                          <label for="itemQuality">Min ${d.Bh}:</label>
                          <select id="itemQuality">
                              <option value="0">${d.C}</option>
                              <option value="1">${d.B}</option>
                              <option value="2">${d.D}</option>
                              <option value="3">${d.J}</option>
                              <option value="4">${d.T}</option>
                          </select>
                        </div>

                        <!-- New Stat Selection with Combo Box -->
                        <div class="setting-row">
                        <label for="shopitemstat">Stat:</label>
                        <select id="shopitemstat">
                            <option value="none">NONE</option>
                            <option value="str">Strength</option>
                            <option value="dex">Dexterity</option>
                            <option value="agi">Agility</option>
                            <option value="cot">Constitution</option>
                            <option value="chr">Charisma</option>
                            <option value="int">Intelligence</option>
                        </select>
                        </div>

                        <div class="setting-row" id="statValueRow" style="display: none;">
                        <label for="statValue">Value:</label>
                        <div class="switch-field2">
                            <input type="number" id="statValue" placeholder="0">
                        </div>
                        </div>
                        

                        <div style="text-align: right;">
                        <button class="awesome-button" id="addItemButton">${d.K}</button>
                      </div>

                      <div class="setting-row">
                        <div id="itemsList" style="margin-bottom: 10px;">
                        <!-- Example item -->
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="flex: 1;">${d.Ah}</span>
                            <button onclick="removeItem('uniqueItemID')">X</button>
                        </div>
                        <!-- Add more items similarly -->
                        </div>
                      </div>  
                  
                      <!-- Search Buttons -->
                      <div style="display: flex; justify-content: space-between; gap: 10px; margin-bottom: 20px;">
                        <button class="awesome-button" id="startSearchButton">${d.Ch}</button>
                        <button class="awesome-button" id="skipSearchButton" style="display: none;">${d.Dh}</button>
                        <button class="awesome-button" id="stopSearchButton">${d.Eh}</button>
                      </div>
                      <div class="setting-row">
                      <!-- Progress Bar -->
                      <div style="margin-bottom: 20px;">
                          <label>${d.uh}:</label>
                          <div id="progressBarOuter" style="width: 100%; height: 20px; background-color: grey; border-radius: 10px;">
                              <div id="progressBarInner" style="height: 100%; width: 0%; background-color: green; border-radius: 10px;"></div>
                          </div>
                      </div>
                  
                      <!-- Found Items Container -->
                      <div id="foundItemsContainer"></div>
                    </div>
                </div>

                <div class="popup-box" id="auto_auction2_settings">

                <div class="settings_tab_title">${d.Mh}</div>
           
                <div class="setting-row" data-tooltip="${d.Od}">
                <label for="storeGoldinAuction">${d.v}</label>
                  <label class="toggle-switch">
                  <input type="checkbox" id="storeGoldinAuction">
                  <span class="switch"></span>
                  </label>
                  </div>

                <div class="setting-row">
                  <label for="itemsToReset2">${d.Da}</label>
                  <div id="itemsToReset2" class="items-reset-list">
                      <div class="item-reset"><input type="checkbox" id="WEAPONS2" value="WEAPONS2"><label for="WEAPONS">${d.pa}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHIELD2" value="SHIELD2"><label for="SHIELD">${d.U}</label></div>
                      <div class="item-reset"><input type="checkbox" id="CHEST2" value="CHEST2"><label for="CHEST">${d.O}</label></div>
                      <div class="item-reset"><input type="checkbox" id="HELMET2" value="HELMET2"><label for="HELMET">${d.S}</label></div>
                      <div class="item-reset"><input type="checkbox" id="GLOVES2" value="GLOVES2"><label for="GLOVES">${d.R}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHOES2" value="SHOES2"><label for="SHOES">${d.P}</label></div>
                      <div class="item-reset"><input type="checkbox" id="RINGS2" value="RINGS2"><label for="RINGS">${d.oa}</label></div>
                      <div class="item-reset"><input type="checkbox" id="AMULETS2" value="AMULETS2"><label for="AMULETS">${d.la}</label></div>
                  </div>
                </div>

                <div class="setting-row">
                    <label for="storeInShopQuality">${d.Ba}</label>
                    <select id="storeInShopQuality" class="input">
                    <option value="0">
                    ${d.C}
                    </option><!-- Add more options as needed -->
                        <option value="1">
                        ${d.B}
                        </option>
                        <option value="2">
                        ${d.D}
                        </option>
                  </select>
                

                </div>

                <div class="setting-row">
                <label for="storeGoldinAuctionmaxGold">${d.pg}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionmaxGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionmaxGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
                <label for="storeGoldinAuctionholdGold">${d.aa}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionholdGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionholdGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
              <label for="AuctionGoldCover">${d.mb}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="AuctionGoldCover">
                <span class="switch"></span>
              </label>
            </div>

                <span class="span-new">${d.ph}</span>
                  
                    <div class="settings_tab_title">${d.Fg}</div>
                    <span class="span-new">${d.Qd}</span>
                    
                    <div class="setting-row">
                      <div class="table-container">
                          <table class="styled-table">
                            <thead>
                              <tr>
                                <th>Prefix</th>
                                <th>Suffix</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="AuctionprefixList"></ul>
                                </td>
                                <td>
                                  <ul class="styled-list" id="AuctionsuffixList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                 
                                    <input type="text" class="styled-input" id="AuctionnewPrefixInput">
                                    <input type="button" id="AuctionaddPrefixButton" value="${d.Qa}">
                                  </div>
                                </td>
                                <td>
                                  <div class="list-options">
                                    <input type="text" class="styled-input" id="AuctionnewSuffixInput">
                                    <input type="button" id="AuctionaddSuffixButton" value="${d.Ra}">
                                  </div>
                                </td>

                              </tr>
                            </tbody>
                          </table>
                          
                      </div>
                      
                    </div>
                  
                    <div class="setting-row">
                        <label>${d.na}</label>
                        <div class="equipment-selection">
                            <label><input type="checkbox" class="equipment-option" value="2"> ${d.ga}</label>
                            <label><input type="checkbox" class="equipment-option" value="4"> ${d.da}</label>
                            <label><input type="checkbox" class="equipment-option" value="8"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option" value="1"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option" value="256"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option" value="512"> ${d.ea}</label>
                            <label><input type="checkbox" class="equipment-option" value="48"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option" value="1024"> ${d.V}</label>
                            <label><input type="checkbox" class="equipment-option" value="9999"> ${d.Ja}</label>
                        </div>
                    </div>

                      <div class="setting-row" data-tooltip="${d.sk}">
                        <label for="auctionTURBO">Turbo Mode Speed >> </label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionTURBO">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctiongladiatorenable">${d.qh}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctiongladiatorenable">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctionmercenaryenable">${d.th}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionmercenaryenable">
                          <span class="switch"></span>
                         </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Md}>
                        <label for="ignorePS">${d.lf}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="ignorePS">
                            <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Va}>
                        <label for="bidFood">${d.Yd}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="bidFood">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Ld}>
                      <label for="AuctionCover">${d.mb}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="AuctionCover">
                        <span class="switch"></span>
                      </label>
                    </div>

                      <div class="setting-row" data-tooltip="${d.Va}>
                        <label for="bidfood">${d.qg}</label>
                        <div class="switch-field3">
                          <input type="number" id="maximumBid" min="1" max="1000000" value="25">
                        </div>
                      </div>

                      <div class="setting-row">
                        <label for="aunctionMinQuality">${d.Ba}</label>
                         <select id="auctionMinQuality" class="input">
                          <option value="2">
                          ${d.D}
                          </option>
                          <option value="1">
                          ${d.B}
                          </option>
                          <option value="0">
                          ${d.C}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                    <div class="setting-row">
                      <label for="auctionminlevel">${d.ba}</label>
                      <div class="switch-field3">
                        <input type="number" id="auctionminlevel" min="1" max="1000" value="0">
                      </div>
                    </div>

                      <div class="setting-row">
                        <label for="bidStatus">${d.Zd}</label>
                         <select id="bidStatus" class="input">
                          <option value="4">
                          ${d.bc}
                          </option>
                          <option value="3">
                          ${d.Yb}
                          </option>
                          <option value="2">
                          ${d.Kb}
                          </option>
                          <option value="1">
                          ${d.Cb}
                          </option>
                          <option value="0">
                          ${d.ac}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                      <div class="setting-row">
                        <label for="enableMercenarySearch">${d.$i}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="enableMercenarySearch">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="mercenarySearchOptions" style="display:none">
                        <div class="setting-row">
                        
                            <label for="minDexterity">Min: ${d.Dexterity}</label>
                            <div class="switch-field3">
                                <input type="number" id="minDexterity" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minAgility">Min: ${d.Agility}</label>
                            <div class="switch-field3">
                                <input type="number" id="minAgility" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minIntelligence">Min: ${d.Intelligence}</label>
                            <div class="switch-field3">
                                <input type="number" id="minIntelligence" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <span class="span-new">Enter 0 to ignore stats.</span>
                    </div>
                      
                      <div class="setting-row">
                        <h4>${d.$d}</h4>
                        <div class="table-container">
                          <table class="styled-table">
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="bidList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                    <input type="button" class="awesome-button" id="clearBidItemsHistory" value="${d.Za}">
                                  </div>
                                  
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                  </div>

                <div class="popup-box" id="auto_smelt_settings">
                    <div class="settings_tab_title" style="position: relative;">
                        Auto Smelt (Tutorial/Yardim/ajuda) -->
                        <i class="fas fa-info-circle" id="autoSmeltInfo" style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 22px; color: black;"></i>

                    
                    </div>


                    <div class="rule-container">
                    <!-- Rule Row Template -->
                    <div class="rule-row-template" style="display: none;">
                        <!-- Top row (Condition, Prefix, Scroll, Level) -->
                        <div class="rule-top-row">
     
                            <label class="rule-checkbox-wrapper">
        
                                <input type="checkbox" class="rule-checkbox">
                                <span class="checkbox-icon"></span>
                                
                            </label>

                            &nbsp

                            <!-- Condition Combo Box -->
                            <select class="rule-condition-select">
                                <option value="nameContains">${d.Eg}</option>
                                <option value="isUnderworldItem">${d.isUnderworldItem}</option>
                            </select>

                            <!-- Text input appears only for 'Name contains' -->
                            <input type="text" class="rule-prefix-input" placeholder="${d.Mb}" />
                            <input type="text" class="rule-suffix-input" placeholder="${d.Zb}" />

                            <!-- Scroll Combo Box 
                            <select class="rule-scroll-select">
                                <option value="noScroll">No scroll</option>
                                <option value="anyScroll">Has any scroll</option>
                            </select>
                            -->

                            <input type="number" class="rule-level" placeholder="lvl>">
                        </div>

                        <!-- Second row (Item Types, Colors, Hammer) -->
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection">
                                <span class="color-circle white" data-color="white"></span>
                                <span class="color-circle green" data-color="green"></span>
                                <span class="color-circle blue" data-color="blue"></span>
                                <span class="color-circle purple" data-color="purple"></span>
                                 <span class="color-circle orange" data-color="orange"></span>
                                <span class="color-circle red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

                            <button class="remove-rule-btn">X</button>
                        </div>
                    </div>

                    <!-- Add Rule Button -->
                    <button class="add-rule-btn">${d.Gg}</button>
                    <hr style="border: 1px solid #c4ac70; margin: 10px 0;">
                </div>



                    <!-- Condition Selection  
                    <div class="setting-row">
                        <label for="smeltCondition">Condition:</label>
                        <select id="smeltCondition" class="styled-select" style="width:200px">
                            <option value="name_contains">Name contains</option>
                            <option value="name_word">Name contains word</option>
                            <option value="color">Item color is</option>
                            <option value="underworld_prefix_suffix">Item has underworld prefix/suffix</option>
                        </select>
                    </div>
                    
                    <div class="setting-row" id="filterNameRow">
                        <label for="filterNameInput">Filter Profile Name:</label>
                        <input type="text" id="filterNameInput" class="styled-input3" placeholder="Enter profile name" />
                    </div>

                    <div class="setting-row" id="itemNameRow" style="display: none;">
                        <label for="itemNameInput">Item Name:</label>
                        <input type="text" id="itemNameInput" class="styled-input" placeholder="Enter item name" />
                    </div>
                    
                    <div class="setting-row" id="colorRow" style="display: none;">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                

                    <div class="setting-row">
                        <h4>Added Filters</h4>
                        <div id="filtersList" class="filter-list"></div>
                    </div>


                    <div class="setting-row">
                        <h4>Saved Items</h4>
                        <div id="savedItemsList" class="filter-list"></div>
                    </div>

                    

                    <div class="setting-row">
                        <label>${d.na}</label>
                        <div class="equipment-selection-smelt">
                            <label><input type="checkbox" class="equipment-option-smelt" value="2"> ${d.ga}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="4"> ${d.da}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="8"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="256"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="512"> ${d.ea}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="48"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1024"> ${d.V}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="9999"> ${d.Ja}</label>
                        </div>
                    </div>
                  

                    <div class="setting-row" id="colorRowOriginal">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                    

                    <div class="setting-row">
                        <label for="smeltUnderworld">Smelt only Underworld/Hell items?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="smeltUnderworld">
                        <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="smeltLootbox">${d.Sj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="smeltLootbox">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltIgnorePS">${d.Rj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltIgnorePS">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->

                    <div class="setting-row">
                      <label for="smeltAnything">${d.Ih}</label>
                      
                      <label class="toggle-switch" data-tooltip="${d.Tj}">
                        <input type="checkbox" id="smeltAnything">
                        <span class="switch"></span>
                      </label>
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection2">
                                <span class="color-circle2 white" data-color="white"></span>
                                <span class="color-circle2 green" data-color="green"></span>
                                <span class="color-circle2 blue" data-color="blue"></span>
                                <span class="color-circle2 purple" data-color="purple"></span>
                                 <span class="color-circle2 orange" data-color="orange"></span>
                                <span class="color-circle2 red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection2">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

        
                        </div>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Uj}">
                      <label for="smelteverything3">${d.bk}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smelteverything3">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="smelthighercolors">${d.ck}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smelthighercolors">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="RepairBeforeSmelt">${d.Kj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="RepairBeforeSmelt">
                        <span class="switch"></span>
                      </label>
                        <div class="setting-row">
                        <label for="repairBeforeSmeltMaxQuality">${d.Rc}</label>
                            <select id="repairBeforeSmeltMaxQuality" class="input">
                                    <option value="3">
                                    ${d.J}
                                    </option>
                                    <option value="2">
                                    ${d.D}
                                    </option>
                                    <option value="1">
                                    ${d.B}
                                    </option>
                                    <option value="0">
                                    ${d.C}
                                    </option>
                                    <option value="-1">
                                    ${d.Ga}
                                    </option>
                            </select>
                        </div>
                        <div class="setting-row">
                        <label for="PartialOrFull">${d.Mg}</label>
                            <select id="PartialOrFull" class="input">
                                    <option value="0">
                                    ${d.Ng}
                                    </option>
                                    <option value="1">
                                    ${d.af}
                                    </option>
                            </select>
                        </div>
                    </div>

                    
                    <div class="setting-row">
                        <label for="smeltTab">${d.Jh}</label>
                        <select id="smeltTab" class="input">
                        <option value="6">
                            8
                        </option>
                            <option value="5">
                                7
                            </option>
                            <option value="4">
                                6
                            </option>
                            <option value="3">
                                5
                            </option>
                            <option value="2">
                                4
                            </option>
                            <option value="1">
                                3
                            </option>
                            <option value="0">
                                2
                            </option>
                        </select>
                    </div>


                    <div class="settings_tab_title">${d.Hh}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                <thead>
                                    <tr>
                                    <th>${d.Mb}</th>
                                    <th>${d.Zb}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td>
                                        <ul class="styled-list" id="IgnoredprefixList"></ul>
                                    </td>
                                    <td>
                                        <ul class="styled-list" id="IgnoredsuffixList"></ul>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredPrefixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddPrefixButton" value="${d.Qa}">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredSuffixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddSuffixButton" value="${d.Ra}">
                                        </div>
                                    </td>
                                    </tr>
                                </tbody>
                                </table>          
                        </div>
                    </div>
                    
                    <!-- Smelted Items List -->
                  
                    <div class="settings_tab_title">${d.ak}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                    <tbody>
                                    <tr>
                                        <td>
                                        <ul class="styled-list" id="smeltedList"></ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <div class="list-options">
                                            <input type="button" class="awesome-button" id="clearSmeltedItemsHistory" value="${d.Za}">
                                            
                                        </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>    
                        </div>
                    </div>
                </div>

                
                <div class="popup-box" id="auto_repair_settings">
                <div class="settings_tab_title">${d.Pb}</div>
                <div class="setting-row">

                    <div class="inventory gladiator-inventory">
                        <h3>Gladiator</h3>
                        <!-- Inventory Rows for Gladiator -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weapon">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmet">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armor">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shield">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="gloves">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoes">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklace">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>

                        </div>
                    </div>

                    <div class="inventory mercenary-inventory">
                        <h3>Mercenary</h3>
                        <!-- Inventory Rows for Mercenary -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weaponM">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmetM">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armorM">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shieldM">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="glovesM">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoesM">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1M">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2M">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklaceM">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>
                        </div>
                    </div>

                    <div class="instructions" style="clear: both;">
                            <span class="span-new">${d.ic}</span><br>
                            <span class="span-new">${d.ih}</span>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="repairGladiator">${d.Fa} Gladiator?</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="repairGladiator">
                            <span class="switch"></span>
                        </label>
                    </div>
                  
                    <div class="setting-row">
                        <label for="repairMercenary">${d.Fa} Mercenary?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="repairMercenary">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="repairPercentage">${d.Bg}</label>
                        <select id="repairPercentage" class="input">
                        <option value="3">%10</option>
                        <option value="2">%20</option>
                        <option value="1">%30</option>
                        <option value="0">%40</option>
                        <option value="-1">%50</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="repairMaxQuality">${d.Rc}</label>
                        <select id="repairMaxQuality" class="input">
                                <option value="3">
                                ${d.J}
                                </option>
                                <option value="2">
                                ${d.D}
                                </option>
                                <option value="1">
                                ${d.B}
                                </option>
                                <option value="0">
                                ${d.C}
                                </option>
                                <option value="-1">
                                ${d.Ga}
                                </option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="currentWorkbenchItem">${d.ge}</label>
                        <span id="currentWorkbenchItem"></span> <!-- Item name will be displayed here -->
                    </div>

                    <div class="setting-row">
                        <div id="clear_repair" style="display:flex;" class="awesome-button">${d.zk}</div>
                    </div>

                    <div class="setting-row" id="ignoreMaterialsSection" style="margin-top: 10px; border-top: 1px solid #b3a77a; padding-top: 10px; background: linear-gradient(to right, #e8e1c8, #dacfa1); border-radius: 8px;">
                        <h3 style="color: #5a5a5a; font-family: 'Arial', sans-serif; text-align: center; text-transform: uppercase; letter-spacing: 2px;">${d.kf}</h3>
                        
                        <!-- Scrollable list of materials -->
                        <div id="ignoreMaterialsList" style="border-radius: 4px; padding: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); height: 300px; max-height: 300px; overflow-y: auto; display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                            <!-- Base Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Base Materials</h4>
                                <label><input type="checkbox" value="1"> ${d.Pc}</label><br>
                                <label><input type="checkbox" value="2"> ${d.Fc}</label><br>
                                <label><input type="checkbox" value="3"> ${d.Jc}</label><br>
                                <label><input type="checkbox" value="4"> ${d.Lc}</label><br>
                            </div>

                            <!-- Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Materials</h4>
                                <label><input type="checkbox" value="13"> ${d.Qc}</label><br>
                                <label><input type="checkbox" value="14 Wool"> ${d.Gc}</label><br>
                                <label><input type="checkbox" value="15"> ${d.Ic}</label><br>
                                <label><input type="checkbox" value="16"> ${d.Hc}</label><br>
                                <label><input type="checkbox" value="17"> ${d.Mc}</label><br>
                                <label><input type="checkbox" value="18"> ${d.Kc}</label><br>
                                <label><input type="checkbox" value="19"> ${d.Oc}</label><br>
                                <label><input type="checkbox" value="20"> ${d.Nc}</label><br>
                            </div>

                            <!-- Monster Parts category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Monster Parts</h4>
                                <label><input type="checkbox" value="5"> ${d.Yc}</label><br>
                                <label><input type="checkbox" value="6"> ${d.Sc}</label><br>
                                <label><input type="checkbox" value="7"> ${d.ad}</label><br>
                                <label><input type="checkbox" value="8"> ${d.Vc}</label><br>
                                <label><input type="checkbox" value="9"> ${d.Xc}</label><br>
                                <label><input type="checkbox" value="10> ${d.Wc}</label><br>
                                <label><input type="checkbox" value="11"> ${d.Tc}</label><br>
                                <label><input type="checkbox" value="12"> ${d.$c}</label><br>
                                <label><input type="checkbox" value="55"> ${d.Uc}</label><br>
                                <label><input type="checkbox" value="58"> ${d.Zc}</label><br>
                                <label><input type="checkbox" value="62"> ${d.bd}</label><br>
                                <label><input type="checkbox" value="64"> ${d.cd}</label><br>
                            </div>

                            <!-- Gemstones category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Gemstones</h4>
                                <label><input type="checkbox" value="21"> ${d.Cc}</label><br>
                                <label><input type="checkbox" value="22"> ${d.wc}</label><br>
                                <label><input type="checkbox" value="23"> ${d.vc}</label><br>
                                <label><input type="checkbox" value="24"> ${d.xc}</label><br>
                                <label><input type="checkbox" value="25"> ${d.Dc}</label><br>
                                <label><input type="checkbox" value="26"> ${d.Ac}</label><br>
                                <label><input type="checkbox" value="27"> ${d.zc}</label><br>
                                <label><input type="checkbox" value="28"> ${d.yc}</label><br>
                                <label><input type="checkbox" value="59"> ${d.Bc}</label><br>
                                <label><input type="checkbox" value="63"> ${d.Ec}</label><br>
                            </div>

                            <!-- Flasks category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Flasks</h4>
                                <label><input type="checkbox" value="37"> ${d.qc}</label><br>
                                <label><input type="checkbox" value="38"> ${d.tc}</label><br>
                                <label><input type="checkbox" value="39"> ${d.mc}</label><br>
                                <label><input type="checkbox" value="40"> ${d.lc}</label><br>
                                <label><input type="checkbox" value="41"> ${d.sc}</label><br>
                                <label><input type="checkbox" value="42"> ${d.pc}</label><br>
                                <label><input type="checkbox" value="43"> ${d.nc}</label><br>
                                <label><input type="checkbox" value="44"> ${d.oc}</label><br>
                                <label><input type="checkbox" value="53"> ${d.uc}</label><br>
                                <label><input type="checkbox" value="61"> ${d.rc}</label><br>
                            </div>

                            <!-- Runes category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Runes</h4>
                                <label><input type="checkbox" value="29"> ${d.Bd}</label><br>
                                <label><input type="checkbox" value="30"> ${d.vd}</label><br>
                                <label><input type="checkbox" value="31"> ${d.td}</label><br>
                                <label><input type="checkbox" value="32"> ${d.Ad}</label><br>
                                <label><input type="checkbox" value="33"> ${d.zd}</label><br>
                                <label><input type="checkbox" value="34"> ${d.xd}</label><br>
                                <label><input type="checkbox" value="35"> ${d.ud}</label><br>
                                <label><input type="checkbox" value="36"> ${d.yd}</label><br>
                                <label><input type="checkbox" value="60"> ${d.wd}</label><br>
                            </div>

                            <!-- Ores category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Ores</h4>
                                <label><input type="checkbox" value="45"> ${d.gd}</label><br>
                                <label><input type="checkbox" value="46"> ${d.fd}</label><br>
                                <label><input type="checkbox" value="47"> ${d.ld}</label><br>
                                <label><input type="checkbox" value="48"> ${d.od}</label><br>
                                <label><input type="checkbox" value="49"> ${d.pd}</label><br>
                                <label><input type="checkbox" value="50"> ${d.jd}</label><br>
                                <label><input type="checkbox" value="51"> ${d.nd}</label><br>
                                <label><input type="checkbox" value="52"> ${d.md}</label><br>
                                <label><input type="checkbox" value="54"> ${d.ed}</label><br>
                                <label><input type="checkbox" value="56"> ${d.hd}</label><br>
                                <label><input type="checkbox" value="57"> ${d.kd}</label><br>
                            </div>

                            <!-- Fragments category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Fragments</h4>
                                <label><input type="checkbox" value="65"> Material Fragment</label><br>
                                <label><input type="checkbox" value="66"> Monster Piece</label><br>
                                <label><input type="checkbox" value="67"> Gemstone Shard</label><br>
                                <label><input type="checkbox" value="68"> Flask Component</label><br>
                                <label><input type="checkbox" value="69"> Rune Splinter</label><br>
                                <label><input type="checkbox" value="70"> Ore Sample}</label><br>
                                <label><input type="checkbox" value="71"> Scroll Fragment</label><br>

                            </div>
                        </div>

                    </div>

                </div>


                <div class="popup-box" id="guild_settings">

                    <!-- Guld stuff comes here -->

                    <div class="settings_tab_title">${d.Lh}</div>

                        <span class="span-new">${d.Zi}:</span>
                        <span class="span-new">${d.vf}</span>
                  
                        <div class="setting-row">
                            <label for="doKasa">${d.v}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="doKasa">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="AuctionItemLevel2">${d.Cg}</label>
                            <div class="switch-field2">
                            <input type="number" id="minimumGoldAmount" placeholder="Amount" value="${localStorage.getItem("minimumGoldAmount")||0}">         
                            </div>
                        </div>

                        <div class="setting-row">
                            <label for="filterGM">${d.Ze}</label>
                            <select id="filterGM">
                            <option value="" disabled>${d.Da}</option>
                            <option value="pd">${d.Dg}</option>
                            <option value="p">${d.de}</option>
        
                            </select>
                        </div>

                        <div class="setting-row">
                            <label for="guildPackHour">${d.Ub}</label>
                            <select id="guildPackHour">
                            <option value="" disabled>${d.Ub}</option>
                            <option value="1">2 hr</option>
                            <option value="2">8 hr</option>
                            <option value="3">24 hr</option>
                            </select>
                        </div>

                        <div class="setting-row">
                        <label for="KasaHoldGold">${d.aa}</label>
                            <div class="switch-field3">
                            <input type="number" id="KasaHoldGold" placeholder="Amount" value="${localStorage.getItem("KasaHoldGold")||0}">       
                                </div>
                        </div>

                        <div class="setting-row">
                            <label for="itemsToResetGuild">${d.Da}</label>
                            <div id="itemsToResetGuild" class="items-reset-list">
                                <div class="item-reset"><input type="checkbox" id="GUILD_WEAPONS" value="GUILD_WEAPONS"><label for="GUILD_WEAPONS">${d.pa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHIELD" value="GUILD_SHIELD"><label for="GUILD_SHIELD">${d.U}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_CHEST" value="GUILD_CHEST"><label for="GUILD_CHEST">${d.O}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_HELMET" value="GUILD_HELMET"><label for="GUILD_HELMET">${d.S}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_GLOVES" value="GUILD_GLOVES"><label for="GUILD_GLOVES">${d.R}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHOES" value="GUILD_SHOES"><label for="GUILD_SHOES">${d.P}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RINGS" value="GUILD_RINGS"><label for="GUILD_RINGS">${d.oa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_AMULETS" value="GUILD_AMULETS"><label for="GUILD_AMULETS">${d.la}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FOOD" value="GUILD_FOOD"><label for="GUILD_FOOD">${d.Ka}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_USABLES" value="GUILD_USABLES"><label for="GUILD_USABLES">${d.qd}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_UPGRADES" value="GUILD_UPGRADES"><label for="GUILD_UPGRADES">${d.Pa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RECIPES" value="GUILD_RECIPES"><label for="GUILD_RECIPES">${d.Ma}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_MERCENARY" value="GUILD_MERCENARY"><label for="GUILD_MERCENARY">${d.La}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SCROLLS" value="GUILD_SCROLLS"><label for="GUILD_SCROLLS">${d.Na}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_REINFORCEMENTS" value="GUILD_REINFORCEMENTS"><label for="GUILD_REINFORCEMENTS">${d.sd}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_TOOLS" value="GUILD_TOOLS"><label for="GUILD_TOOLS">${d.Oa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FORGE_RESOURCES" value="GUILD_FORGE_RESOURCES"><label for="GUILD_FORGE_RESOURCES">${d.rd}</label></div>
                            </div>
                        </div>

                    <div class="settings_tab_title">${d.dj}</div>

                            
                            <div class="setting-row">
                                <label for="guildBattleEnable">${d.v}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleEnable">
                                    <span class="switch"></span>
                                </label>          
                            </div>

                            <div class="setting-row">
                             <label for="guildBattleRandom">${d.cj}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleRandom">
                                    <span class="switch"></span>
                                </label>
                            </div>

                            <div class="setting-row">
                                ${d.ej}
                                <div class="input-container">
                                <input type="text" id="keywordGuildInput" placeholder="${d.X}">
                                <button class="awesome-button" id="addGuildKeywordBtn">${d.K}</button>
                                </div>
                                <div id="keywordGuildList"></div>
                            </div>

                    <div class="settings_tab_title">${d.nb}</div>

                        <div class="setting-row">
                            <label for="GuildEnable">${d.v}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="GuildEnable">
                                <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        
                            <label for="GuildDonateAmount">${d.jf}</label>
                            <div class="switch-field3">
                                <input type="number" id="GuildDonateAmount" min="0" value="${localStorage.getItem("GuildDonateAmount")||0}">      
                            </div> 

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateMore">${d.ke}</label>
                                <div class="switch-field3">
                                    <input type="number" id="GuildDonateMore" min="0" value="${localStorage.getItem("GuildDonateMore")||0}">                         
                                </div>

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateLess">${d.wf}</label>
                            <div class="switch-field3">
                            <input type="number" id="GuildDonateLess" min="0" value="${localStorage.getItem("GuildDonateLess")||0}">       
                            </div>                  
                        </div>

                        <span class="span-new">${d.je}</span>
                        
                    </div>

                <div class="popup-box" id="other_settings2">

                    <div class="settings_tab_title">${d.jh}</div>


                    <div class="setting-row">
                    <span class="span-new">${d.kh}</span>
                    <div class="instructionsReset">
                    
                    <span class="span-new">${d.Qb}</span>
                    </div>
                 
                    </div>
                    
                    <div class="setting-row">
                      <label for="resetExpiredItems">${d.v}</label>
                      <label class="toggle-switch">
                          <input type="checkbox" id="resetExpiredItems">
                          <span class="switch"></span>
                      </label>
                    </div>
                    <div class="setting-row">
                    <label for="resetColors">Select Colors</label>
                            <div class="rule-color-resetColors">
                                <span class="color-circle3 white" data-color="-1"></span>
                                <span class="color-circle3 green" data-color="0"></span>
                                <span class="color-circle3 blue" data-color="1"></span>
                                <span class="color-circle3 purple" data-color="2"></span>
                                <span class="color-circle3 orange" data-color="3"></span>
                                <span class="color-circle3 red" data-color="4"></span>
                            </div>
                    </div>


                    <div class="setting-row">
 
                        <label for="resetDays">${d.lh}</label>
                        <select id="resetDays" style="margin-left: 5px;">
                            <option value="1">1 day</option>
                            <option value="2">2 days</option>
                            <option value="3">3 days</option>
                            <option value="4">4 days</option>
                        </select>
                    </div>
                    
                    <div class="setting-row">
                        <label for="itemsToReset">${d.Zk}</label>
                        <button id="selectAllItems" title="Select All">
                            <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                                <polyline points="20 6 9 17 4 12"></polyline> 
                            </svg>
                        </button>
                        <div id="itemsToReset" class="items-reset-list">
                        
                            <div class="item-reset"><input type="checkbox" id="WEAPONS" value="WEAPONS"><label for="WEAPONS">${d.pa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHIELD" value="SHIELD"><label for="SHIELD">${d.U}</label></div>
                            <div class="item-reset"><input type="checkbox" id="CHEST" value="CHEST"><label for="CHEST">${d.O}</label></div>
                            <div class="item-reset"><input type="checkbox" id="HELMET" value="HELMET"><label for="HELMET">${d.S}</label></div>
                            <div class="item-reset"><input type="checkbox" id="GLOVES" value="GLOVES"><label for="GLOVES">${d.R}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHOES" value="SHOES"><label for="SHOES">${d.P}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RINGS" value="RINGS"><label for="RINGS">${d.oa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="AMULETS" value="AMULETS"><label for="AMULETS">${d.la}</label></div>
                            <div class="item-reset"><input type="checkbox" id="FOOD" value="FOOD"><label for="FOOD">${d.Ka}</label></div>
                            <div class="item-reset"><input type="checkbox" id="USABLES" value="USABLES"><label for="USABLES">${d.qd}</label></div>
                            <div class="item-reset"><input type="checkbox" id="UPGRADES" value="UPGRADES"><label for="UPGRADES">${d.Pa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RECIPES" value="RECIPES"><label for="RECIPES">${d.Ma}</label></div>
                            <div class="item-reset"><input type="checkbox" id="MERCENARY" value="MERCENARY"><label for="MERCENARY">${d.La}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SCROLLS" value="SCROLLS"><label for="SCROLLS">${d.Na}</label></div>
                            <div class="item-reset"><input type="checkbox" id="REINFORCEMENTS" value="REINFORCEMENTS"><label for="REINFORCEMENTS">${d.sd}</label></div>
                            <div class="item-reset"><input type="checkbox" id="TOOLS" value="TOOLS"><label for="TOOLS">${d.Oa}</label></div>
                            
                        </div>

                        <div class="setting-row">
                            <label for="resetUnderworld">${d.$k}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="resetUnderworld">
                                <span class="switch"></span>
                            </label>
                        </div>
                    </div>
                    
                    <hr style="border: none; border-top: 1px solid black; margin: 10px 0px;">

                    <div class="setting-row">
                        <label for="pauseDuration">${d.Qg} </label>
                        <select id="pauseDuration">
                        <option value="0">No pause</option>
                        <option value="1">Stable Boy</option>
                        <option value="2">Farmer</option>
                        <option value="3">Butcher</option>
                        <option value="4">Fisherman</option>
                        <option value="5">Baker</option>
                        </select>
                    </div>
                     
              </div>

                <div class="popup-box" id="Timers">
                <div class="settings_tab_title">${d.$b}</div>
                <span class="span-new">${d.Timers}</span>

                <div class="setting-row">
                    <div class="timer-list" style="display: grid; grid-template-columns: repeat(2, 5fr); gap: 10px;">

                    <div class="timer-item">
                        <label for="smelting-timer" style="font-weight: bold;">${d.hi}</label>
                        <p class="description">${d.fi}</p>
                        <input type="number" id="smelting-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Smelting||10}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-nogold" style="font-weight: bold;">${d.gi}</label>
                        <p class="description">${d.ci}</p>
                        <input type="number" id="smelting-timer-nogold" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-noitem" style="font-weight: bold;">${d.di}</label>
                        <p class="description">${d.ei}</p>
                        <input type="number" id="smelting-timer-noitem" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoItem||15}">
                    </div>

                    <div class="timer-item">
                        <label for="repair-timer" style="font-weight: bold;">${d.Fa}</label>
                        <p class="description">${d.Yh}</p>
                        <input type="number" id="repair-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Repair||10}">
                    </div>

                    <div class="timer-item">
                        <label for="guild-market-timer" style="font-weight: bold;">${d.Wh}</label>
                        <p class="description">${d.Xh}</p>
                        <input type="number" id="guild-market-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildMarket||2}">
                    </div>

                    <div class="timer-item">
                        <label for="auction-hold-timer" style="font-weight: bold;">${d.Sh}</label>
                        <p class="description">${d.Th}</p>
                        <input type="number" id="auction-hold-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionHoldGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="arena-timer" style="font-weight: bold;">Arena:</label>
                        <p class="description">${d.Ph}</p>
                        <input type="number" id="arena-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Arena||10}">
                    </div>

                    <div class="timer-item">
                        <label for="circus-turma-timer" style="font-weight: bold;">Circus Turma:</label>
                        <p class="description">${d.Uh}</p>
                        <input type="number" id="circus-turma-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).CircusTurma||10}">
                    </div>

                    <div class="timer-item">
                        <label for="training-timer" style="font-weight: bold;">${d.ki}</label>
                        <p class="description">${d.li}</p>
                        <input type="number" id="training-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Training||2}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-expired-timer" style="font-weight: bold;">${d.Zh}</label>
                        <p class="description">${d.$h}</p>
                        <input type="number" id="reset-expired-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).ResetExpired||10}">
                    </div>

                    <div class="timer-item">
                        <label for="store-forge-timer" style="font-weight: bold;">${d.ii}</label>
                        <p class="description">${d.ji}</p>
                        <input type="number" id="store-forge-timer" class="timer-input" style="width: 60px;" min="5" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).StoreForge||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-auction-timer" style="font-weight: bold;">${d.Qh}</label>
                        <p class="description">${d.Rh}</p>
                        <input type="number" id="reset-auction-timer" class="timer-input" style="width: 60px;" min="1" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionCheck||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-search-timer" style="font-weight: bold;">${d.ai}</label>
                        <p class="description">${d.bi}</p>
                        <input type="number" id="reset-search-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SearchTimer||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guilddonate-timer" style="font-weight: bold;">${d.nb}</label>
                        <p class="description">${d.Vh}</p>
                        <input type="number" id="reset-guilddonate-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildDonate||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guildattack-timer" style="font-weight: bold;">Guild Attack</label>
                        <p class="description">Sets timer for guild attack</p>
                        <input type="number" id="reset-guildattack-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).guildBattleEnable||120}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-buff-timer" style="font-weight: bold;">Buffs</label>
                        <p class="description">Buff timer</p>
                        <input type="number" id="reset-buff-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Buffs||60}">
                    </div>

                    </div>
                </div>
                </div>


                  <div class="popup-box" id="other_settings">

                <div class="settings_tab_title">${d.Gd}</div>

                <div class="setting-row">
                ${d.Hd}
                    <select id="delaySelect">
                    <option value="0">0 seconds</option>
                    <option value="1">1 second</option>
                    <option value="5">1 to 5 seconds</option>
                    <option value="10">5 to 10 seconds</option>
                    <option value="15">10 to 15 seconds</option>
                    <option value="30">15 to 30 seconds</option>
                    <option value="60">30 to 60 seconds</option>
                    <option value="160">1 to 60 seconds</option>
                    <option value="120">1 to 2 minutes</option>
                    </select>
                </div>
                <div class="setting-row">
                    <label for="timeConditions">Bot Auto Start/Stop Schedule:</label>
                    <div id="timeConditions"></div>
                    <br>
                    <button id="addCondition" class="awesome-button btn">Add Condition</button>
                    <br><br>
                    <button id="pauseButton" class="pause-button">Pause?</button>
                </div>
                  
                <div class="settings_tab_title">${d.qk}</div>

                <div class="setting-row">
                  <label for="storeResource">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="storeResource">
                    <span class="switch"></span>
                    </label>
                </div>

                <div class="settings_tab_title">${d.se}</div>

                <div class="setting-row">
                  <label for="HighlightUnderworldItems">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="HighlightUnderworldItems">
                    <span class="switch"></span>
                    </label>
                </div>
                    
                <div class="settings_tab_title">${d.mi}</div>
                <div class="setting-row">

                      <div class="setting-row">
                        <label for="trainEnable">${d.v}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainEnable">
                          <span class="switch"></span>
                          </label>
                      </div>

                      <div class="setting-row">
                        <label for="trainPickGold">${d.rk}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainPickGold">
                          <span class="switch"></span>
                          </label>
                      </div>

                          ${d.oi}
                      <div class="stat-container">




                        <table id="statTable">
                        <thead>
                            <tr>
                                <th>${d.v}</th>
                                <th>${d.Kh}</th>
                                <th>${d.Rg}</th>
                                <th>${d.Ca}</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                                                                                                        

                        <div class="setting-row">
                            
                            <label for="TrainingHoldGold">${d.aa}</label>

                            <div class="switch-field3">
                            <input type="number" id="TrainingHoldGold" min="0" value="${localStorage.getItem("TrainingHoldGold")||0}">                         
                            </div>  
                  
                        </div>

                                  <span class="span-new">${d.ni}</span>        

                      </div>  
                    </div>
        
                </div>

            <div class="popup-box" id="Extra">
            <div class="settings_tab_title">${d.qb}</div>

              <div class="setting-row">
                
                    <span style="color:red" class="span-new">1 Day Trial Key : </span>
                    <span id="kydt" style="color:red"></span>
                    <br>
                    <span style="color:red" class="span-new">${d.Te} : </span>
                    <span id="kydtexp" style="color:red"></span>
                    
                    <ul>
                    <p>
                    <b>3.4.5 Update</b>
                    <div class="scrollable-list">
                        <ul>
                        <li>Please contact us via <strong>Email: "gldbotsuport@gmail.com"</strong> for problems with links or patch notes</li>
                        </ul>
                    </div>

                </div>

                <div class="settings_tab_title">Stats</div>
                    <div class="setting-row">
                        <div id="stats">
                            <p>${d.lk} <span id="items-repaired">0</span></p>
                            <p>${d.mk} <span id="items-reset">0</span></p>
                            <p>${d.kk} <span id="gold-cycled">0</span></p>
                            <p>${d.ek} <span id="arena-attacks">0</span></p>
                            <p>${d.gk} <span id="circus-attacks">0</span></p>
                            <p>${d.ik} <span id="dungeons-attacked">0</span></p>
                            <p>${d.jk} <span id="expeditions-attacked">0</span></p>
                            <p>${d.nk} <span id="items-smelted">0</span></p>
                            <p>${d.pk} <span id="underworld-attacks">0</span></p>
                            <p>${d.fk} <span id="arena-money">0</span></p>
                            <p>${d.hk} <span id="circus-money">0</span></p>
                        </div>
                        <button class="awesome-button" id="reset-stats-button">${d.Pi}</button>
                    </div>
           

            <div class="settings_tab_title">${d.mf}</div>
            
            <div class="setting-row">
              <button class="awesome-button" id="exportBtn">${d.Ue}</button>
              <input type="file" id="importBtn" style="display: none;">
              <button class="awesome-button" id="importFileBtn">${d.nf}</button>
              <p id="importStatus"></p>
              <p>
            </div>

            <div class="settings_tab_title">${d.Vd}</div>

            <div class="setting-row">
            <span class="span-new">${d.Wd}</span>
              <br></br>
              <label for="autologinenable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="autologinenable">
                <span class="switch"></span>
              </label>
            </div>

            <div class="settings_tab_title">${d.Og}</div>
                <div class="setting-row">
                <label for="pauseBotEnable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="pauseBotEnable">
                <span class="switch"></span>
                </label>
            </div>
            
            <div class="setting-row">
                <label for="pauseBot">${d.Pg}</label>
                <div class="switch-field3"> 
                <input type="number" id="pauseBot" placeholder="Minutes" value="${Math.round((localStorage.getItem("pauseBot.timeOut")-Date.now())/6E4)||0}">
                </div>
                </label>
            </div>

            <div class="settings_tab_title">UI Settings</div>

                <div class="setting-row">
                    <label for="disableBG">${d.Pj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableBG">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="disableLogMenu">${d.ie}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableLogMenu">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="MoveButtons">${d.Qj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="MoveButtons">
                        <span class="switch"></span>
                    </label>
                </div>
                
            
    
            <div class="settings_tab_title">${d.tg}</div>
                <div class="setting-row">
                    <span class="span-new">${d.ug}</span>
                    <textarea id="messageInput" rows="4" cols="50" placeholder="${d.vg}" style="width: 350px; height: 50px;"></textarea>
                    <button class="awesome-button" id="messageButton">${d.xg}</button>
                    <button class="awesome-button"id="showPlayersButton">${d.yg}</button>
                    <button class="awesome-button" id="selectAllButton">${d.wg}</button>
                    <button class="awesome-button" id="unselectAllButton">${d.zg}</button>
                    <div id="messageStatus"></div>
                    <div id="playerList" style="display: none;"></div>
                    <div id="loadingContainer"></div>
                    <br>
                    ${d.he}
                </div>        
            </div>

                  <div class="popup-box" id="Market">
                  <div class="settings_tab_title">Market Buy</div>
        
                    <span class="span-new">${d.dg}</span>

                    <div class="setting-row">
                      <label for="enableMarketSearch">${d.te}
                        <label class="toggle-switch">
                        <input type="checkbox" id="enableMarketSearch">
                        <span class="switch"></span>
                      </label>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label>${d.eg}</label>
                    <span style="font-weight: normal">${d.fg}</span>
                    <input type="text" id="MarketSearchInterval" placeholder="Market Search Interval - Minutes" value="${localStorage.getItem("MarketSearchInterval")||""}">

                    </div>



                    <div class="setting-row">
                    <div class="setting-row">
                        <label for="marketOnlyFood">${d.Jg}
                        <label class="toggle-switch">
                        <input type="checkbox" id="marketOnlyFood">
                        <span class="switch"></span>
                        </label>
                        </label>
                    </div>
                      <span class="span-new">${d.Kg}</span>
                      
                      <label for="MaxTotalGold">${d.Jb} : </label><input type="number" id="MarketMaxFoodPrice" placeholder="${d.Jb}" value="${localStorage.getItem("MarketMaxFoodPrice")||""}">
                    
                      <label for="MaxPerFood">${d.Ib} : </label><input type="number" id="MarketMaxPerFoodPrice" placeholder="${d.Ib}" value="${localStorage.getItem("MarketMaxPerFoodPrice")||""}">

                      <label for="MinItemLevel">${d.ba} : </label><input type="number" id="MarketMinItemLevel" placeholder="${d.ba}" value="${localStorage.getItem("MarketMinItemLevel")||""}">
                    

                    </div>

                    <div class="setting-row">
                    <label>${d.rf}</label>
                      <input type="text" id="itemToBuy" placeholder="${d.pf}">
                    </div>

                    <div class="setting-row">
                      <input type="number" id="maxPrice" placeholder="${d.G}">
                    </div>

                    <div class="setting-row">
                    
                      <label>${d.sf}</label>
                      <select id="marketItemType">
                        <option value="WEAPON">${d.pa}</option>
                        <option value="SHIELD">${d.U}</option>
                        <option value="CHEST">${d.O}</option>
                        <option value="HELMET">${d.S}</option>
                        <option value="GLOVES">${d.R}</option>
                        <option value="SHOES">${d.P}</option>
                        <option value="RINGS">${d.oa}</option>
                        <option value="AMULETS">${d.la}</option>
                        <option value="USABLES">${d.Ka}</option></option>
                        <option value="BOOSTS">${d.yj}</option></option>
                        <option value="UPGRADES">${d.Pa}</option></option>
                        <option value="RECIPES">${d.Ma}</option></option>
                        <option value="MERCENARY">${d.La}</option></option>
                        <option value="FORGINGGOODS">${d.rd}</option></option>
                        <option value="btools">${d.Oa}</option></option>
                        <option value="SCROLLS">${d.Na}</option></option>
                      </select>

                      <label>${d.qf}</label>
                      <select id="rarity">
                        <option value="White">${d.qa}</option>
                        <option value="Green">${d.C}</option>
                        <option value="Blue">${d.B}</option>
                        <option value="Purple">${d.D}</option>
                        <option value="Orange">${d.J}</option>
                        <option value="Red">${d.T}</option>
                      </select>

                      <label>${d.ce}</label>
                      <select id="itemsoulbound">
                        <option value="BuySoulbound">${d.Ki}</option>
                        <option value="DontBuySoulbound">${d.Hg}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <button class="awesome-button" id="addItemBtn">${d.K}</button>
                    </div>

                    <div class="setting-row">
                      <label for="itemList">${d.uf}</label>
                      <select id="itemList" size="10"></select>
                      <button class="awesome-button" id="removeItemBtn">${d.gh}</button>
                    </div>

                    <div class="setting-row">
                      <label for="usePacks">${d.tf}
                      <label class="toggle-switch">
                        <input type="checkbox" id="usePacks">
                        <span class="switch"></span>
                        </label>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="MarketboughtItems">${d.ae}</label>
                      <select id="MarketboughtItems" size="5"></select>
                      <button class="awesome-button" id="MarketremoveItemBtn">${d.fe}</button>
                    </div>

                    <div class="setting-row">
                    <label for="MarketHoldGold">${d.aa}</label>
                    <input type="number" id="MarketHoldGold" min="0" value="${localStorage.getItem("MarketHoldGold")||0}">
                    </div>
                  
                    </div>   
                  </div>
                </div>
              </div>
            </div>

              `;document.getElementById("header_game").insertBefore(v,document.getElementById("header_game").children[0]);v=document.createElement("div");y=document.getElementById("wrapper_game").clientHeight;v.setAttribute("id","overlayBack");v.setAttribute("style",`height: ${y}px; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 198;`);v.addEventListener("click",kc);document.getElementsByTagName("body")[0].appendChild(v);(function(){var t=localStorage.getItem("lastActiveTab");t?(t=
document.querySelector(`.popup-tab[data-target="${t}"]`))&&Wc(t):(t=document.querySelector(".popup-tab"))&&Wc(t)})();v=localStorage.getItem("we");null!==v&&(v=(new Date(v)).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),document.getElementById("kydtexp").textContent=v,v=localStorage.getItem("showTrial"),null!==v&&(document.getElementById("kydt").textContent=v));ri();(function(){document.querySelectorAll(".setting-row").forEach(function(t){t.addEventListener("mouseenter",
function(){var u=this.getAttribute("data-tooltip");if(u&&""!==u.trim()){const A=document.createElement("div");A.className="custom-tooltip";A.innerHTML=u;document.body.appendChild(A);u=this.getBoundingClientRect();A.style.left=u.left+u.width/2-A.offsetWidth/2+"px";A.style.top=u.top-A.offsetHeight+"px";this.Cm=A}});t.addEventListener("mouseleave",function(){this.Cm&&(document.body.removeChild(this.Cm),this.Cm=null)})})})();document.querySelectorAll(".popup-tab").forEach(t=>{t.addEventListener("click",
()=>{Wc(t);localStorage.setItem("lastActiveTab",t.dataset.target)})});const D=document.querySelectorAll(".popup-tab"),C=document.querySelectorAll(".popup-box"),E=document.querySelector(`#${document.querySelector(".popup-tab.active").dataset.target}`);E.classList.add("active");C.forEach(t=>{t!==E&&(t.style.display="none")});D.forEach(t=>{t.addEventListener("click",()=>{D.forEach(u=>u.classList.remove("active"));t.classList.add("active");C.forEach(u=>{u.style.display="none"});document.querySelector(`#${t.dataset.target}`).style.display=
"block"})});"GB PL ES TR FR HG BR".split(" ").forEach(t=>{$(`#language${t}`).click(()=>{localStorage.setItem("settings.language",t);switch(t){case "EN":d={...Mh};break;case "PL":d={...Nh};break;case "ES":d={...Oh};break;case "TR":d={...Ph};break;case "FR":d={...Qh};break;case "HG":d={...Rh};break;case "BR":d={...Sh};break;default:d={...Mh}}kc();lc()})});b("#do_expedition",c,!0,!1);b("#do_dungeon",e,!0,!1);b("#do_arena",g,!0,!1);b("#do_circus",l,!0,!1);b("#do_quests",h,!0,!1);b("#do_event_expedition",
k,!0,!1);[0,1,2,3].forEach(t=>{$(`#set_monster_id_${t}`).click(()=>{var u=`${t}`;Xc=u;localStorage.setItem("monsterId",u)})});["normal","advanced"].forEach(t=>{$(`#set_dungeon_difficulty_${t}`).click(()=>{Kb=t;localStorage.setItem("dungeonDifficulty",t);m(t)})});(v=localStorage.getItem("dungeonDifficulty"))&&m(v);"combat arena circus expedition dungeon items".split(" ").forEach(t=>{$(`#do_${t}_quests`).click(()=>{Na[t]=!Na[t];localStorage.setItem("questTypes",JSON.stringify(Na));kc();lc()})});b("#do_auto_auction",
q,!0,!1);b("#do_kasa",n,!0,!1);$(document).ready(function(){function t(z){var J=z.split(". "),P="<ol>";J.forEach(function(Q,S){""!==Q.trim()&&(S!==J.length-1||Q.endsWith(".")||(Q+="."),P+="<li>"+Q+"</li>")});return P+="</ol>"}function u(z){const J={"guild-market-timer":"GuildMarket","smelting-timer":"Smelting","smelting-timer-nogold":"SmeltingNoGold","smelting-timer-noitem":"SmeltingNoItem","repair-timer":"Repair","auction-hold-timer":"AuctionHoldGold","arena-timer":"Arena","circus-turma-timer":"CircusTurma",
"training-timer":"Training","reset-expired-timer":"ResetExpired","store-forge-timer":"StoreForge","reset-auction-timer":"AuctionCheck","reset-search-timer":"SearchTimer","reset-guilddonate-timer":"GuildDonate","reset-guildattack-timer":"guildBattleEnable","reset-buff-timer":"BuffTimer"};return J[z]?J[z]:z.replace(/-([a-z])/g,function(P){return P[1].toUpperCase()}).replace("-timer","")}function A(){Za.forEach(z=>{const J=document.getElementById(`${z}Priority`);(z=Xa[z])?(J.textContent=`${d.Ca}: ${z}`,
J.dataset.priority=z):(J.textContent=`${d.Vb}`,J.dataset.priority="None")})}function B(){sb=Za.map(z=>{const J=document.getElementById(`${z}Count`),P=document.getElementById(`${z}Enable`);return{stat:z,count:J?parseInt(J.value):0,priority:null!==Xa[z]?Xa[z]:"None",mn:P?P.checked:!1}});localStorage.setItem("statSettings",JSON.stringify(sb))}function H(){Za.forEach(z=>{document.getElementById(`${z}Priority`).addEventListener("click",()=>{let J=Xa[z],P=J?J+1:1;P>Za.length&&(P=1);let Q=null;for(let S of Za)if(S!==
z&&Xa[S]===P){Q=S;break}Q&&(Xa[Q]=J||null);Xa[z]=P;A();B()})});document.querySelectorAll(".stat-count").forEach(z=>{z.addEventListener("change",B)});Za.forEach(z=>{document.getElementById(`${z}Enable`).addEventListener("change",B)})}function G(z,J){JSON.parse(localStorage.getItem(J)||"[]").forEach(P=>K(P,z,J))}function K(z,J,P){const Q=document.createElement("div");Q.className="keyword-item";var S=document.createElement("span");S.textContent=z;Q.appendChild(S);S=document.createElement("span");S.className=
"remove-keyword";S.textContent="X";S.addEventListener("click",function(){Q.remove();let na=JSON.parse(localStorage.getItem(P)||"[]");const X=na.indexOf(z);-1<X&&(na.splice(X,1),localStorage.setItem(P,JSON.stringify(na)))});Q.appendChild(S);J.appendChild(Q)}function L(z,J){const P=JSON.parse(localStorage.getItem(J)||"[]");P.push(z);localStorage.setItem(J,JSON.stringify(P))}function M(z,J,P){const Q=document.createElement("li");Q.textContent=z;Q.style.padding="10px";Q.style.border="1px solid #ccc";
Q.style.borderColor="#cea429";Q.style.borderRadius="5px";Q.style.marginBottom="5px";Q.style.display="flex";Q.style.justifyContent="space-between";const S=document.createElement("button");S.textContent="X";S.style.textAlign="center";S.addEventListener("click",()=>{Q.remove();const na=(JSON.parse(localStorage.getItem(P))||[]).filter(X=>!(X[0]===z[0]&&X[1]===z[1]));localStorage.setItem(P,JSON.stringify(na))});Q.appendChild(S);document.getElementById(J).appendChild(Q)}function Z(){jb=jb.map(z=>{z.Om=
!1;z.Jm=null;return z})}function ba(){document.getElementById("startSearchButton").innerText="Start Search";oc=!1}function ha(){const z=document.getElementById("clothCount");var J=parseInt(z.value,10);isNaN(J)&&(J=0);--J;0>=J&&(J=0);return z.value=J}function ka(){const z=document.getElementById("itemsList");z.innerHTML="";jb.forEach((J,P)=>{const Q=document.createElement("div");Q.style.display="flex";Q.style.flexDirection="column";Q.style.border="1px solid #d2b97f";Q.style.padding="10px";Q.style.marginBottom=
"10px";Q.style.borderRadius="5px";Q.style.backgroundColor="#faf2dd";var S=document.createElement("div");S.style.display="flex";S.style.justifyContent="space-between";S.style.alignItems="center";const na=document.createElement("span");na.innerHTML=`<strong>${J.name}</strong> (${J.qualityName}) - Level: [${J.Bn}]`;na.style.color="#5d432c";const X=document.createElement("button");X.innerText="Remove";X.style.backgroundColor="#af552e";X.style.color="white";X.style.border="none";X.style.padding="5px 10px";
X.style.cursor="pointer";X.style.borderRadius="3px";X.onclick=()=>{jb.splice(P,1);ka();qa()};S.appendChild(na);S.appendChild(X);Q.appendChild(S);J.mm&&J.zm&&(S=document.createElement("div"),S.style.marginTop="5px",S.style.fontStyle="italic",S.style.color="#7d5b3e",S.innerText=`Stat: ${J.mm.toUpperCase()} - Value: ${J.zm}`,Q.appendChild(S));z.appendChild(Q)})}function qa(){localStorage.setItem("itemsToSearch",JSON.stringify(jb))}function ca(z,J){const P=document.getElementById("foundItemsContainer");
P.style.display="flex";P.style.flexWrap="wrap";P.style.justifyContent="center";P.style.alignItems="center";P.style.$p="10px";const Q=document.createElement("div");Q.className="notification-item";Q.style.border="1px solid #d2b97f";Q.style.borderRadius="4px";Q.style.padding="10px";Q.style.margin="5px";Q.style.textAlign="center";Q.style.backgroundColor="#faf2dd";Q.style.boxShadow="0 2px 4px rgba(0, 0, 0, 0.1)";Q.style.boxSizing="border-box";Q.style.flex="0 1 calc(20% - 10px)";Q.style.display="flex";
Q.style.flexDirection="column";Q.style.alignItems="center";Q.style.transition="all 0.3s ease-in-out";const S=document.createElement("span"),na=document.createElement("span");switch(Number(z.Jm.getAttribute("data-quality"))){case 0:na.style.color="green";break;case 1:na.style.color="blue";break;case 2:na.style.color="purple";break;case 3:na.style.color="orange";break;case 4:na.style.color="red";break;default:na.style.color="#333"}na.innerText=z.name;na.style.fontWeight="bold";na.style.fontSize="12px";
na.style.marginBottom="5px";S.appendChild(na);const X=document.createElement("div");X.style.marginTop="5px";X.style.padding="10px";X.style.borderRadius="5px";X.style.display="flex";X.style.justifyContent="center";X.style.alignItems="center";X.style.transition="transform 0.3s ease-in-out";X.onmouseover=()=>{X.style.transform="scale(1.1)"};X.onmouseout=()=>{X.style.transform="scale(1)"};z=z.Jm.cloneNode(!0);z.style.position="static";z.style.transform="none";z.style.margin="0";X.appendChild(z);z=document.createElement("a");
z.href=J;z.style.textDecoration="none";z.style.cursor="pointer";z.onmouseover=()=>{na.style.textDecoration="underline"};z.onmouseout=()=>{na.style.textDecoration="none"};z.appendChild(S);z.appendChild(X);Q.appendChild(z);P.appendChild(Q);pc.style.display="block"}async function pa(){var z=!1;if(!oc)return!1;const J=await Qf();var P=jb.filter(X=>!X.Om);for(let X of P)for(const Yc of J){P=Yc.querySelectorAll("#shop .ui-draggable");for(const Ta of P){var Q=JSON.parse(Ta.getAttribute("data-tooltip").replace(/&quot;/g,
'"')),S=parseInt(Ra(Ta).split("-")[0],10);P=15==S?parseInt(Ta.getAttribute("data-tooltip").split(",")[5].match(/\d+/)[0],10):0;let ti=15==S?parseInt(Ta.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,ui=15==S?parseInt(Ta.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,vi=15==S?parseInt(Ta.getAttribute("data-tooltip").split(",")[11].match(/\d+/)[0],10):0,wi=15==S?parseInt(Ta.getAttribute("data-tooltip").split(",")[13].match(/\d+/)[0],10):0;S=15==S?parseInt(Ta.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],
10):0;var na=Ta.getAttribute("data-quality");Q=Q[0][0][0];const xi=Ta.getAttribute("data-level");if(Number(xi)>=Number(X.Bn)&&Q.toLowerCase().includes(X.name.toLowerCase())&&(na>=X.quality||!na&&"0"==X.quality)){if(X.mm&&X.zm&&"none"!==X.mm&&(na=!1,(P={str:P,dex:ti,agi:ui,cot:vi,chr:wi,"int":S}[X.mm])&&P>=X.zm&&(na=!0),!na))continue;X.Jm=Ta.cloneNode(!0);ca(X,Yc.Wm||Yc.querySelector("a.shopLink").href);z=X.Om=!0}}}P=jb.filter(X=>!X.Om);if(0===P.length||z)return ba(),!0;z=ha();$a();if(0>=z)return ba(),
!1;await xa();return pa()}async function xa(){var z=new URL(window.location.href);const J=z.origin;z=z.searchParams.get("sh")||"";await fetch(`${J}/game/index.php?mod=inventory&sub=2&subsub=0&sh=${z}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({bestechen:"New goods"})})}function $a(){var z=parseInt(document.getElementById("clothCount").getAttribute("data-total"),10);const J=parseInt(document.getElementById("clothCount").value,10);z=(z-J)/z*
100;document.getElementById("progressBarInner").style.width=`${isNaN(z)?100:z}%`}function zb(){const z=[...Zc].filter(J=>J.checked).map(J=>J.value);localStorage.setItem("equipmentSelectionSmelt",JSON.stringify(z))}function Ua(){const z=[...$c].filter(J=>J.checked).map(J=>J.value);localStorage.setItem("equipmentSelection",JSON.stringify(z))}function kb(){localStorage.setItem("timeConditions",JSON.stringify(Lb))}function qc(z={}){const J=document.createElement("div");J.classList.add("condition-row");
J.innerHTML=`
                    <input type="time" class="awesome-button start-time" value="${z.start||""}" required> to
                    <input type="time" class="awesome-button end-time" value="${z.end||""}" required>
                    <br>
                    <select class="bot-action">
                        <option value="start" ${"start"===z.action?"selected":""}>Start Bot</option>
                        <option value="stop" ${"stop"===z.action?"selected":""}>Stop Bot</option>
                    </select>
                    <button class="awesome-button remove-condition">Remove</button>
                `;kb();J.querySelector(".remove-condition").addEventListener("click",()=>{Rf.removeChild(J);Lb=Lb.filter(P=>P!==z);kb()});J.querySelector(".start-time").addEventListener("change",P=>{z.start=P.target.value;kb()});J.querySelector(".end-time").addEventListener("change",P=>{z.end=P.target.value;kb()});J.querySelector(".bot-action").addEventListener("change",P=>{z.action=P.target.value;kb()});Rf.appendChild(J)}function rc(){document.getElementById("mercenarySearchOptions").style.display=
sc.checked?"block":"none"}function Mb(z){document.querySelectorAll('#itemsToReset input[type="checkbox"]').forEach(J=>{J.checked=z});Ja()}function ad(){localStorage.setItem("marketItems",JSON.stringify(lb));bd.innerHTML="";Sf.innerHTML="";for(var z of Nb){var J=document.createElement("option");J.textContent=z;Sf.appendChild(J)}for(z=0;z<lb.length;z++)J=document.createElement("option"),J.value=z,J.text=lb[z].itemToBuy+" (Rarity: "+lb[z].rarity+", Max price: "+lb[z].maxPrice+" "+lb[z].Soulbound+")",
bd.appendChild(J)}function Tf(z,J,P){J[z.id]&&z.classList.add("active");z.addEventListener("click",function(Q){Q.preventDefault();this.classList.contains("active")?(this.classList.remove("active"),J[this.id]=!1):(this.classList.add("active"),J[this.id]=!0);localStorage.setItem(P,JSON.stringify(J))})}function Uf(z,J,P,Q){P.forEach(S=>{S in J||(J[S]=!1)});localStorage.setItem(Q,JSON.stringify(J))}function Vf(){const z=tc.checked;yi.style.display=z?"block":"none";zi.style.display=z?"block":"none"}const Ai=
document.getElementById("doExpedition"),Bi=document.getElementById("doDungeon"),Ci=document.getElementById("doArena"),Di=document.getElementById("doCircus"),Ei=document.getElementById("doQuests"),Fi=document.getElementById("doEventExpedition"),Gi=document.getElementById("activateAutoBid"),Hi=document.getElementById("doKasa"),uc=document.querySelector("#healPercentage"),cd=document.querySelector("#HealClothToggle"),dd=document.querySelector("#hellEnterHP"),ed=document.querySelector("#HellHealHP"),
fd=document.querySelector("#HealRubyToggle"),gd=document.querySelector("#storeResource"),hd=document.querySelector("#HighlightUnderworldItems");uc.value=localStorage.getItem("healPercentage")||25;cd.checked="true"===localStorage.getItem("HealClothToggle")||!1;fd.checked="true"===localStorage.getItem("HealRubyToggle")||!1;gd.checked="true"===localStorage.getItem("storeResource")||!1;hd.checked="true"===localStorage.getItem("HighlightUnderworldItems")||!1;const Wf=document.getElementById("minimumGoldAmount");
Wf.addEventListener("change",()=>{localStorage.setItem("minimumGoldAmount",Wf.value)});const Xf="true"===localStorage.getItem("useGodPowers");document.getElementById("useGodPowers").checked=Xf;document.getElementById("godPowersSection").style.display=Xf?"block":"none";const Ii=JSON.parse(localStorage.getItem("GodPowersHell"))||[];document.querySelectorAll(".god-power-checkbox").forEach(z=>{z.checked=Ii.includes(z.value)});const Ji="true"===localStorage.getItem("useWeaponBuff");document.getElementById("weaponBuff").checked=
Ji;const Ki=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||[];document.querySelectorAll(".armor-checkbox").forEach(z=>{z.checked=Ki.includes(z.value)});document.getElementById("useGodPowers").addEventListener("change",function(){const z=this.checked;localStorage.setItem("useGodPowers",z);document.getElementById("godPowersSection").style.display=z?"block":"none"});document.querySelectorAll(".god-power-checkbox").forEach(z=>{z.addEventListener("change",function(){const J=Array.from(document.querySelectorAll(".god-power-checkbox:checked")).map(P=>
P.value);localStorage.setItem("GodPowersHell",JSON.stringify(J))})});document.getElementById("weaponBuff").addEventListener("change",function(){localStorage.setItem("useWeaponBuff",this.checked)});document.querySelectorAll(".armor-checkbox").forEach(z=>{z.addEventListener("change",function(){const J=Array.from(document.querySelectorAll(".armor-checkbox:checked")).map(P=>P.value);localStorage.setItem("ArmorBuffsHell",JSON.stringify(J))})});const Ob=document.getElementById("OilEnable"),Yf=document.getElementById("oilUsageSettings"),
Zf={oilEnable:!1,blueRings:!1,blueNecklace:!1,yellowRings:!1,yellowNecklace:!1,yellowWeapons:!1,yellowArmor:!1,orangeRings:!1,orangeNecklace:!1,greenRings:!1,greenNecklace:!1,greenWeapons:!1,greenArmor:!1,purpleRings:!1,purpleNecklace:!1,purpleWeapons:!1,purpleArmor:!1},Li=JSON.parse(localStorage.getItem("oilUsagePrefs"))||Zf,Ab={...Zf,...Li},$f={blueRings:document.getElementById("blue-oil-rings"),blueNecklace:document.getElementById("blue-oil-necklace"),yellowRings:document.getElementById("yellow-oil-rings"),
yellowNecklace:document.getElementById("yellow-oil-necklace"),yellowWeapons:document.getElementById("yellow-oil-weapons"),yellowArmor:document.getElementById("yellow-oil-armor"),orangeRings:document.getElementById("orange-oil-rings"),orangeNecklace:document.getElementById("orange-oil-necklace"),greenRings:document.getElementById("green-oil-rings"),greenNecklace:document.getElementById("green-oil-necklace"),greenWeapons:document.getElementById("green-oil-weapons"),greenArmor:document.getElementById("green-oil-armor"),
purpleRings:document.getElementById("purple-oil-rings"),purpleNecklace:document.getElementById("purple-oil-necklace"),purpleWeapons:document.getElementById("purple-oil-weapons"),purpleArmor:document.getElementById("purple-oil-armor"),redRings:document.getElementById("red-oil-rings"),redNecklace:document.getElementById("red-oil-necklace"),redWeapons:document.getElementById("red-oil-weapons"),redArmor:document.getElementById("red-oil-armor")};Ob.checked=Ab.oilEnable;Yf.style.display=Ob.checked?"block":
"none";for(const [z,J]of Object.entries($f))J&&(J.checked=!!Ab[z]);Ob.addEventListener("change",()=>{Ab.oilEnable=Ob.checked;localStorage.setItem("oilUsagePrefs",JSON.stringify(Ab));Yf.style.display=Ob.checked?"block":"none"});for(const [z,J]of Object.entries($f))J&&J.addEventListener("change",()=>{Ab[z]=J.checked;localStorage.setItem("oilUsagePrefs",JSON.stringify(Ab))});const ag=document.getElementById("autoSmeltInfo"),Bb=document.getElementById("popupSmelt");ag.addEventListener("mouseenter",function(){Bb.style.display=
"block";const z=document.querySelector(".popup-menu").getBoundingClientRect();Bb.style.position="fixed";Bb.style.width="350px";Bb.style.left=`${z.right+10}px`;Bb.style.top=`${z.top}px`});ag.addEventListener("mouseleave",function(){Bb.style.display="none"});var jd=document.getElementById("tabA"),kd=document.getElementById("tabB"),bg=document.getElementById("contentA"),cg=document.getElementById("contentB"),ld=document.getElementById("tabACircus"),md=document.getElementById("tabBCircus"),dg=document.getElementById("contentACircus"),
eg=document.getElementById("contentBCircus");jd.addEventListener("click",function(){bg.style.display="block";cg.style.display="none";jd.classList.add("active");kd.classList.remove("active")});kd.addEventListener("click",function(){cg.style.display="block";bg.style.display="none";kd.classList.add("active");jd.classList.remove("active")});ld.addEventListener("click",function(){dg.style.display="block";eg.style.display="none";ld.classList.add("active");md.classList.remove("active")});md.addEventListener("click",
function(){eg.style.display="block";dg.style.display="none";md.classList.add("active");ld.classList.remove("active")});const Mi=t(d.ic),Ni=t(d.Qb);document.querySelector(".instructions .span-new").innerHTML=Mi;document.querySelector(".instructionsReset .span-new").innerHTML=Ni;const nd=document.getElementById("announcement"),od=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio! | Active the Bot!";od&&""!==od?(nd.style.display="block",nd.innerHTML=od):nd.style.display="none";const Oi=[{id:"Health",buffs:["Gingko","Taigaroot",
"Hawthorn"]},{id:"Strength",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Dexterity",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Agility",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Constitution",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Charisma",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Intelligence",buffs:["Flask","Ampulla","Flacon","Bottle"]}];(function(){const z=JSON.parse(localStorage.getItem("buffSelections"))||{};Oi.forEach(J=>{z[J.id]=z[J.id]||[];J.buffs.forEach((P,
Q)=>{const S=document.getElementById(`${J.id}Buff${Q+1}`);S.checked=z[J.id].includes(P);S.addEventListener("change",()=>{S.checked?z[J.id].push(P):z[J.id]=z[J.id].filter(na=>na!==P);localStorage.setItem("buffSelections",JSON.stringify(z))})})})})();let pd=document.getElementById("BuffsEnable");pd.checked="true"===localStorage.getItem("BuffsEnable");pd.addEventListener("change",()=>{localStorage.setItem("BuffsEnable",pd.checked)});let qd=document.getElementById("BuffUnderworldOnly");qd.checked="true"===
localStorage.getItem("BuffUnderworldOnly");qd.addEventListener("change",()=>{localStorage.setItem("BuffUnderworldOnly",qd.checked)});document.querySelectorAll(".timer-input").forEach(z=>{z.addEventListener("change",function(){var J=parseInt(this.min,10);let P=parseInt(this.value,10);P<J&&(this.value=P=J);J=JSON.parse(localStorage.getItem("Timers"))||{};const Q=u(this.id);J[Q]=P;localStorage.setItem("Timers",JSON.stringify(J))})});const Za="Strength Dexterity Agility Constitution Charisma Intelligence".split(" ");
let Xa={},sb=JSON.parse(localStorage.getItem("statSettings"))||[];Za.forEach(z=>{const J=sb.find(P=>P.stat===z);Xa[z]=J?"None"!==J.priority?parseInt(J.priority):null:null});(function(){const z=document.querySelector("#statTable tbody");z.innerHTML="";Za.forEach(J=>{const P=document.createElement("tr");var Q=document.createElement("td"),S=document.createElement("input");S.type="checkbox";S.id=`${J}Enable`;S.checked=sb.find(X=>X.stat===J)?.mn||!1;Q.appendChild(S);P.appendChild(Q);Q=document.createElement("td");
S=document.createElement("label");S.htmlFor=`${J}$`;S.textContent=d[J];Q.appendChild(S);P.appendChild(Q);Q=document.createElement("td");S=document.createElement("input");S.type="number";S.min="0";S.id=`${J}Count`;S.value=sb.find(X=>X.stat===J)?.count||0;S.classList.add("stat-count");Q.appendChild(S);P.appendChild(Q);Q=document.createElement("td");S=document.createElement("button");S.type="button";S.id=`${J}Priority`;S.classList.add("priority-btn");S.dataset.stat=J;const na=Xa[J];S.textContent=na?
`${d.Ca}: ${na}`:`${d.Vb}`;S.dataset.priority=na||"None";Q.appendChild(S);P.appendChild(Q);z.appendChild(P)});H()})();(function(){sb=JSON.parse(localStorage.getItem("statSettings"))||[];Za.forEach(z=>{const J=sb.find(P=>P.stat===z);Xa[z]=J?"None"!==J.priority?parseInt(J.priority):null:null});A()})();Array.from(document.getElementsByClassName("stat-count")).forEach(z=>{z.addEventListener("change",()=>{B()})});document.getElementById("clear_next_event_expedition_time").addEventListener("click",function(){localStorage.setItem("eventPoints_",
16);alert("Done!")});let ab=localStorage.getItem("workbenchItem");ab=ab?JSON.parse(ab):{};ab.selectedItem&&ab.selectedItem.item?document.getElementById("currentWorkbenchItem").textContent=ab.selectedItem.item.name:document.getElementById("currentWorkbenchItem").textContent="No item";document.getElementById("clear_repair").addEventListener("click",function(){ab.selectedItem&&(ab.selectedItem={},Object.assign(ab.selectedItem,{selectedItem:!1}),localStorage.removeItem("workbenchItem"),localStorage.removeItem("activeItems"),
localStorage.removeItem("activeItemsGladiator"),localStorage.removeItem("activeItemsMercenary"),document.getElementById("currentWorkbenchItem").textContent="No item")});document.getElementById("ClearAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackList",JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearOtherAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackServerList",
JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackList",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});
document.getElementById("ClearOtherCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusServerList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackCircusList",JSON.stringify([]));window.location.reload()});const fg=document.getElementById("keywordAcceptInput"),Pi=document.getElementById("addKeywordAcceptBtn"),
gg=document.getElementById("keywordAcceptList"),vc=document.getElementById("underworldKeywordSection"),hg=document.getElementById("underworldKeywordInput"),Qi=document.getElementById("addUnderworldKeywordBtn"),ig=document.getElementById("underworldKeywordList");let rd=document.getElementById("skipTimeQuests");rd.checked="true"===localStorage.getItem("skipTimeQuests");rd.addEventListener("change",()=>{localStorage.setItem("skipTimeQuests",rd.checked)});let sd=document.getElementById("skipTimeCircusQuests");
sd.checked="true"===localStorage.getItem("skipTimeCircusQuests");sd.addEventListener("change",()=>{localStorage.setItem("skipTimeCircusQuests",sd.checked)});let td=document.getElementById("skipTimeOtherQuests");td.checked="true"===localStorage.getItem("skipTimeOtherQuests");td.addEventListener("change",()=>{localStorage.setItem("skipTimeOtherQuests",td.checked)});"Mercury Apollo Diana Minerva Vulcan Mars".split(" ").forEach(z=>{let J=document.getElementById(`questType${z}`);J.checked="true"===localStorage.getItem(`questType${z}`);
J.addEventListener("change",()=>{localStorage.setItem(`questType${z}`,J.checked)})});let Pb=document.getElementById("UnderworldQuests");Pb.checked="true"===localStorage.getItem("UnderworldQuests");Pb.addEventListener("change",()=>{localStorage.setItem("UnderworldQuests",Pb.checked);Pb.checked||"true"===localStorage.getItem("UnderworldQuests")?vc.style.display="block":vc.style.display="none"});Pb.checked||"true"===localStorage.getItem("UnderworldQuests")?vc.style.display="block":vc.style.display="none";
let ud=document.getElementById("acceptnotfilter");ud.checked="true"===localStorage.getItem("acceptnotfilter");ud.addEventListener("change",()=>{localStorage.setItem("acceptnotfilter",ud.checked)});const vd=document.getElementById("keywordInput"),Ri=document.getElementById("addKeywordBtn"),jg=document.getElementById("keywordList"),Si=document.getElementById("keywordGuildInput"),Ti=document.getElementById("addGuildKeywordBtn"),kg=document.getElementById("keywordGuildList");G(kg,"guildKeywords");Ti.addEventListener("click",
function(){const z=Si.value.trim();""!==z&&(K(z,kg,"guildKeywords"),L(z,"guildKeywords"),vd.value="")});G(jg,"questKeywords");G(ig,"underworldQuestKeywords");Ri.addEventListener("click",function(){const z=vd.value.trim();""!==z&&(K(z,jg,"questKeywords"),L(z,"questKeywords"),vd.value="")});G(gg,"acceptQuestKeywords");Pi.addEventListener("click",function(){const z=fg.value.trim();""!==z&&(K(z,gg,"acceptQuestKeywords"),L(z,"acceptQuestKeywords"),fg.value="")});Qi.addEventListener("click",function(){const z=
hg.value.trim();""!==z&&(K(z,ig,"underworldQuestKeywords"),L(z,"underworldQuestKeywords"),hg.value="")});let wd=document.getElementById("renewEvent");wd.checked="true"===localStorage.getItem("renewEvent");wd.addEventListener("change",()=>{localStorage.setItem("renewEvent",wd.checked)});let xd=document.getElementById("EventAutoMonsterSwitch");xd.checked="true"===localStorage.getItem("EventAutoMonsterSwitch");xd.addEventListener("change",()=>{localStorage.setItem("EventAutoMonsterSwitch",xd.checked)});
let yd=document.getElementById("throwDice");yd.checked="true"===localStorage.getItem("throwDice");yd.addEventListener("change",()=>{localStorage.setItem("throwDice",yd.checked)});let zd=document.getElementById("useCostume");zd.checked="true"===localStorage.getItem("useCostume");zd.addEventListener("change",()=>{localStorage.setItem("useCostume",zd.checked)});let Qb=document.getElementById("wearUnderworld"),lg=document.getElementById("costumeUnderworldWrapper");Qb.checked="true"===localStorage.getItem("wearUnderworld");
lg.style.display=Qb.checked?"block":"none";Qb.addEventListener("change",()=>{localStorage.setItem("wearUnderworld",Qb.checked);lg.style.display=Qb.checked?"block":"none"});document.getElementById("costumeUnderworld").addEventListener("change",function(){localStorage.setItem("costumeUnderworld",this.value)});const Ui=document.getElementById("costumeUnderworld"),mg=localStorage.getItem("costumeUnderworld");null!==mg&&(Ui.value=mg);const Vi=document.getElementById("costumeBasic"),ng=localStorage.getItem("costumeBasic");
document.getElementById("costumeBasic").addEventListener("change",function(){localStorage.setItem("costumeBasic",this.value)});null!==ng&&(Vi.value=ng);document.getElementById("costumeDungeon").addEventListener("change",function(){localStorage.setItem("costumeDungeon",this.value)});const Wi=document.getElementById("costumeDungeon"),og=localStorage.getItem("costumeDungeon");null!==og&&(Wi.value=og);const Xi=document.getElementById("search_input"),Yi=document.getElementById("search_reset"),Zi=document.getElementById("search_button");
let wc=JSON.parse(localStorage.getItem("searchTerms")||"[]");wc.forEach(z=>{M(z,"search_list","searchTerms")});Zi.addEventListener("click",function(){const z=Xi.value.trim();""===z||wc.includes(z)||(wc.push(z),localStorage.setItem("searchTerms",JSON.stringify(wc)),M(z,"search_list","searchTerms"))});const Ad=document.querySelector(".equipment-search-selection");Ad.addEventListener("change",()=>{const z=Array.from(Ad.querySelectorAll(".equipment-search-option:checked")).map(J=>J.value);localStorage.setItem("SearchTypes",
JSON.stringify(z))});JSON.parse(localStorage.getItem("SearchTypes")||"[]").forEach(z=>{if(z=Ad.querySelector(`.equipment-search-option[value="${z}"]`))z.checked=!0});let jb=JSON.parse(localStorage.getItem("itemsToSearch"))||[];document.getElementById("addItemButton").addEventListener("click",function(){const z=document.getElementById("newItem").value,J=document.getElementById("itemQuality").value,P=document.getElementById("newItemLevel").value,Q=document.getElementById("shopitemstat").value,S=document.getElementById("statValue").value;
jb.push({name:z,quality:J,Bn:P,qualityName:$i[J],mm:"none"!==Q?Q:null,zm:"none"!==Q?S:null});ka();qa()});document.getElementById("startSearchButton").addEventListener("click",async function(){oc=!0;pc.style.display="none";document.getElementById("clothCount").setAttribute("data-total",document.getElementById("clothCount").value);document.getElementById("startSearchButton").innerText="Searching...";await pa()});document.getElementById("stopSearchButton").addEventListener("click",ba);document.getElementById("shopitemstat").addEventListener("change",
function(){document.getElementById("statValueRow").style.display="none"===this.value?"none":"block"});const pc=document.getElementById("skipSearchButton");pc.addEventListener("click",async function(){const z=document.getElementById("foundItemsContainer");for(;z.firstChild;)z.removeChild(z.firstChild);Z();oc=!0;pc.style.display="none";ha();$a();await xa();await pa()});let oc=!0;const $i={0:"Green",1:"Blue",2:"Purple",3:"Orange",4:"Red"};ka();oi();const Zc=document.querySelectorAll(".equipment-option-smelt");
Zc.forEach(z=>{z.addEventListener("change",zb)});(JSON.parse(localStorage.getItem("equipmentSelectionSmelt"))||[]).forEach(z=>{const J=[...Zc].find(P=>P.value===z);J&&(J.checked=!0)});const $c=document.querySelectorAll(".equipment-option");$c.forEach(z=>{z.addEventListener("change",Ua)});(JSON.parse(localStorage.getItem("equipmentSelection"))||[]).forEach(z=>{const J=[...$c].find(P=>P.value===z);J&&(J.checked=!0)});Yi.addEventListener("click",function(){localStorage.setItem("AuctionSearch.timeOut",
0);localStorage.setItem("ShopSearch.timeOut",0);location.reload()});let Bd=document.getElementById("trainPickGold");Bd.checked="true"===localStorage.getItem("trainPickGold");Bd.addEventListener("change",()=>{localStorage.setItem("trainPickGold",Bd.checked)});let Cd=document.getElementById("trainEnable");Cd.checked="true"===localStorage.getItem("trainEnable");Cd.addEventListener("change",()=>{localStorage.setItem("trainEnable",Cd.checked)});let Dd=document.getElementById("EnableArenaHell");Dd.checked=
"true"===localStorage.getItem("EnableArenaHell");Dd.addEventListener("change",()=>{localStorage.setItem("EnableArenaHell",Dd.checked)});let Ed=document.getElementById("dungeonAB");Ed.checked="true"===localStorage.getItem("dungeonAB");Ed.addEventListener("change",()=>{localStorage.setItem("dungeonAB",Ed.checked)});let Fd=document.getElementById("dungeonFocusQuest");Fd.checked="true"===localStorage.getItem("dungeonFocusQuest");Fd.addEventListener("change",()=>{localStorage.setItem("dungeonFocusQuest",
Fd.checked)});(function(){const z=document.getElementById("autologinenable"),J="true"===localStorage.getItem("AutoLogin");z.checked=J;Bf(J);z.addEventListener("change",function(){const P=this.checked;localStorage.setItem("AutoLogin",P);Bf(P)})})();const Rf=document.getElementById("timeConditions"),aj=document.getElementById("addCondition");let Lb=JSON.parse(localStorage.getItem("timeConditions"))||[];Lb.forEach(qc);aj.addEventListener("click",()=>{const z={start:"",end:"",action:"stop"};Lb.push(z);
qc(z);kb()});const Gd=document.getElementById("pauseButton");let Rb="true"===localStorage.getItem("botPaused");Gd.textContent=Rb?"Paused":"Pause?";Gd.addEventListener("click",function(){Rb=!Rb;Gd.textContent=Rb?"Paused":"Pause?";localStorage.setItem("botPaused",Rb.toString())});let Hd=document.getElementById("enableCircusWithoutHeal");Hd.checked="true"===localStorage.getItem("enableCircusWithoutHeal");Hd.addEventListener("change",()=>{localStorage.setItem("enableCircusWithoutHeal",Hd.checked)});let Id=
document.getElementById("arenaAttackGM");Id.checked="true"===localStorage.getItem("arenaAttackGM");Id.addEventListener("change",()=>{localStorage.setItem("arenaAttackGM",Id.checked)});let Jd=document.getElementById("onlyArena");Jd.checked="true"===localStorage.getItem("onlyArena");Jd.addEventListener("change",()=>{localStorage.setItem("onlyArena",Jd.checked)});let Kd=document.getElementById("onlyPlayerListArena");Kd.checked="true"===localStorage.getItem("onlyPlayerListArena");Kd.addEventListener("change",
()=>{localStorage.setItem("onlyPlayerListArena",Kd.checked)});let Ld=document.getElementById("onlyPlayerListCircus");Ld.checked="true"===localStorage.getItem("onlyPlayerListCircus");Ld.addEventListener("change",()=>{localStorage.setItem("onlyPlayerListCircus",Ld.checked)});let Md=document.getElementById("onlyCircus");Md.checked="true"===localStorage.getItem("onlyCircus");Md.addEventListener("change",()=>{localStorage.setItem("onlyCircus",Md.checked)});let Nd=document.getElementById("attackRandomly");
Nd.checked="true"===localStorage.getItem("attackRandomly");Nd.addEventListener("change",()=>{localStorage.setItem("attackRandomly",Nd.checked)});let Od=document.getElementById("attackRandomlyCircus");Od.checked="true"===localStorage.getItem("attackRandomlyCircus");Od.addEventListener("change",()=>{localStorage.setItem("attackRandomlyCircus",Od.checked)});let Pd=document.getElementById("circusAttackGM");Pd.checked="true"===localStorage.getItem("circusAttackGM");Pd.addEventListener("change",()=>{localStorage.setItem("circusAttackGM",
Pd.checked)});let Qd=document.getElementById("auctionmercenaryenable");Qd.checked="true"===localStorage.getItem("auctionmercenaryenable");Qd.addEventListener("change",()=>{localStorage.setItem("auctionmercenaryenable",Qd.checked)});let Rd=document.getElementById("auctionTURBO");Rd.checked="true"===localStorage.getItem("auctionTURBO");Rd.addEventListener("change",()=>{localStorage.setItem("auctionTURBO",Rd.checked)});let Sd=document.getElementById("auctiongladiatorenable");Sd.checked="true"===localStorage.getItem("auctiongladiatorenable");
Sd.addEventListener("change",()=>{localStorage.setItem("auctiongladiatorenable",Sd.checked)});let Td=document.getElementById("bidFood");Td.checked="true"===localStorage.getItem("bidFood");Td.addEventListener("change",()=>{localStorage.setItem("bidFood",Td.checked)});let Ud=document.getElementById("ignorePS");Ud.checked="true"===localStorage.getItem("ignorePS");Ud.addEventListener("change",()=>{localStorage.setItem("ignorePS",Ud.checked)});let Vd=document.getElementById("auctionminlevel");Vd.value=
localStorage.getItem("auctionminlevel")||"";Vd.addEventListener("input",()=>{localStorage.setItem("auctionminlevel",Vd.value)});let Wd=document.getElementById("AuctionCover");Wd.checked="true"===localStorage.getItem("AuctionCover");Wd.addEventListener("change",()=>{localStorage.setItem("AuctionCover",Wd.checked)});let Xd=document.getElementById("AuctionGoldCover");Xd.checked="true"===localStorage.getItem("AuctionGoldCover");Xd.addEventListener("change",()=>{localStorage.setItem("AuctionGoldCover",
Xd.checked)});let Yd=document.getElementById("maximumBid");Yd.value=localStorage.getItem("maximumBid")||"";Yd.addEventListener("input",()=>{localStorage.setItem("maximumBid",Yd.value)});let Zd=document.getElementById("activateAuction2");Zd.checked="true"===localStorage.getItem("activateAuction2");Zd.addEventListener("change",()=>{localStorage.setItem("activateAuction2",Zd.checked)});let $d=document.getElementById("AuctionItemLevel2");$d.value=localStorage.getItem("AuctionItemLevel2")||"";$d.addEventListener("input",
()=>{localStorage.setItem("AuctionItemLevel2",$d.value)});let sc=document.getElementById("enableMercenarySearch"),ae=document.getElementById("minDexterity"),be=document.getElementById("minAgility"),ce=document.getElementById("minIntelligence");sc.checked="true"===localStorage.getItem("enableMercenarySearch");ae.value=localStorage.getItem("minDexterity")||0;be.value=localStorage.getItem("minAgility")||0;ce.value=localStorage.getItem("minIntelligence")||0;rc();sc.addEventListener("change",()=>{localStorage.setItem("enableMercenarySearch",
sc.checked);rc()});ae.addEventListener("input",()=>{localStorage.setItem("minDexterity",ae.value)});be.addEventListener("input",()=>{localStorage.setItem("minAgility",be.value)});ce.addEventListener("input",()=>{localStorage.setItem("minIntelligence",ce.value)});const de=document.getElementById("SearchQuality"),pg=localStorage.getItem("SearchQuality");pg&&(de.value=pg);de.addEventListener("change",()=>{localStorage.setItem("SearchQuality",de.value)});const ee=document.getElementById("HealPickBag"),
qg=localStorage.getItem("HealPickBag");qg&&(ee.value=qg);ee.addEventListener("change",()=>{localStorage.setItem("HealPickBag",ee.value)});const fe=document.getElementById("FoodAmount"),rg=localStorage.getItem("FoodAmount");rg&&(fe.value=rg);fe.addEventListener("change",()=>{localStorage.setItem("FoodAmount",fe.value)});const sg=document.getElementById("questrewardvalue");sg.addEventListener("change",()=>{localStorage.setItem("questrewardvalue",sg.value)});const ge=document.getElementById("smeltTab"),
tg=localStorage.getItem("smeltTab");tg&&(ge.value=tg);ge.addEventListener("change",()=>{localStorage.setItem("smeltTab",ge.value)});const he=document.getElementById("repairMaxQuality"),ie=document.getElementById("repairBeforeSmeltMaxQuality"),je=document.getElementById("PartialOrFull");let xc=localStorage.getItem("repairMaxQuality"),yc=localStorage.getItem("repairBeforeSmeltMaxQuality"),zc=localStorage.getItem("PartialOrFull");xc||(xc="1",localStorage.setItem("repairMaxQuality",xc));yc||(yc="1",localStorage.setItem("RSMaxQuality",
yc));zc||(zc="0",localStorage.setItem("PartialOrFull",zc));he.value=xc;ie.value=yc;he.addEventListener("change",()=>{localStorage.setItem("repairMaxQuality",he.value)});ie.addEventListener("change",()=>{localStorage.setItem("repairBeforeSmeltMaxQuality",ie.value)});je.addEventListener("change",()=>{localStorage.setItem("PartialOrFull",je.value)});je.value=zc;var Ac=document.getElementById("repairPercentage");(function(){var z=localStorage.getItem("repairPercentage");if(null!==z)for(var J=0;J<Ac.options.length;J++)if(Ac.options[J].text.replace("%",
"")===z){Ac.selectedIndex=J;break}})();Ac.addEventListener("change",function(){var z=this.options[this.selectedIndex].text.replace("%","");localStorage.setItem("repairPercentage",z)});const ke=document.getElementById("bidStatus"),ug=localStorage.getItem("bidStatus");ug&&(ke.value=ug);ke.addEventListener("change",()=>{localStorage.setItem("bidStatus",ke.value)});const le=document.getElementById("auctionMinQuality"),vg=localStorage.getItem("auctionMinQuality");vg&&(le.value=vg);le.addEventListener("change",
()=>{localStorage.setItem("auctionMinQuality",le.value)});const me=document.getElementById("storeInShopQuality"),wg=localStorage.getItem("storeInShopQuality");wg&&(me.value=wg);me.addEventListener("change",()=>{localStorage.setItem("storeInShopQuality",me.value)});const Ja=function(z,J){let P;return function(){const Q=this,S=arguments;clearTimeout(P);P=setTimeout(()=>z.apply(Q,S),J)}}(function(){const z=document.getElementById("resetExpiredItems").checked,J=document.getElementById("resetUnderworld").checked,
P=document.getElementById("resetDays").value,Q=Array.from(document.querySelectorAll('#itemsToReset input[type="checkbox"]:checked')).map(X=>X.value),S=Array.from(document.querySelectorAll('#itemsToReset2 input[type="checkbox"]:checked')).map(X=>X.value),na=Array.from(document.querySelectorAll('#itemsToResetGuild input[type="checkbox"]:checked')).map(X=>X.value);localStorage.setItem("resetExpiredItems",z);localStorage.setItem("resetUnderworld",J);localStorage.setItem("resetDays",P);localStorage.setItem("itemsToReset",
JSON.stringify(Q));localStorage.setItem("itemsToReset2",JSON.stringify(S));localStorage.setItem("itemsToResetGuild",JSON.stringify(na))},250);document.getElementById("resetExpiredItems").addEventListener("change",Ja);document.getElementById("resetUnderworld").addEventListener("change",Ja);document.getElementById("resetDays").addEventListener("change",Ja);document.getElementById("itemsToReset").addEventListener("change",Ja);document.getElementById("itemsToReset2").addEventListener("change",Ja);document.getElementById("itemsToResetGuild").addEventListener("change",
Ja);document.getElementById("resetExpiredItems").addEventListener("touchend",Ja);document.getElementById("resetUnderworld").addEventListener("touchend",Ja);document.getElementById("resetDays").addEventListener("touchend",Ja);document.getElementById("itemsToReset").addEventListener("touchend",Ja);document.getElementById("itemsToReset2").addEventListener("touchend",Ja);document.getElementById("itemsToResetGuild").addEventListener("touchend",Ja);document.getElementById("selectAllItems").addEventListener("click",
function(){let z="true"!==this.dataset.checked;this.innerHTML=(this.dataset.checked=z)?'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <polyline points="20 6 9 17 4 12"></polyline>\n                    </svg>':'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line> \n                    </svg>';
Mb(z)});(function(){const z="true"===localStorage.getItem("resetExpiredItems"),J="true"===localStorage.getItem("resetUnderworld"),P=localStorage.getItem("resetDays"),Q=JSON.parse(localStorage.getItem("itemsToReset")||"[]"),S=JSON.parse(localStorage.getItem("itemsToReset2")||"[]"),na=JSON.parse(localStorage.getItem("itemsToResetGuild")||"[]");document.getElementById("resetExpiredItems").checked=z;document.getElementById("resetUnderworld").checked=J;document.getElementById("resetDays").value=P;Q.forEach(X=>
{if(X=document.getElementById(X))X.checked=!0});S.forEach(X=>{if(X=document.getElementById(X))X.checked=!0});na.forEach(X=>{if(X=document.getElementById(X))X.checked=!0})})();const ne=document.getElementById("guildPackHour"),xg=localStorage.getItem("guildPackHour");xg&&(ne.value=xg);ne.addEventListener("change",()=>{localStorage.setItem("guildPackHour",ne.value)});const oe=document.getElementById("filterGM"),yg=localStorage.getItem("filterGM");yg&&(oe.value=yg);oe.addEventListener("change",()=>{localStorage.setItem("filterGM",
oe.value)});const tb=document.getElementById("delaySelect"),zg=localStorage.getItem("DELAY");if(zg)for(let z=0;z<tb.options.length;z++)if(tb.options[z].text===zg){tb.value=tb.options[z].value;break}tb.addEventListener("change",()=>{localStorage.setItem("DELAY",tb.options[tb.selectedIndex].text)});const pe=document.getElementById("questSpeed"),Ag=localStorage.getItem("questSpeed");Ag&&(pe.value=Ag);pe.addEventListener("change",()=>{localStorage.setItem("questSpeed",pe.value)});let Bg=document.getElementById("itemToBuy"),
Cg=document.getElementById("rarity"),Dg=document.getElementById("marketItemType"),Eg=document.getElementById("itemsoulbound"),Fg=document.getElementById("maxPrice"),bj=document.getElementById("addItemBtn"),cj=document.getElementById("removeItemBtn"),dj=document.getElementById("MarketremoveItemBtn"),bd=document.getElementById("itemList"),Sf=document.getElementById("MarketboughtItems"),Nb=localStorage.getItem("MarketboughtItems");Nb?Nb=JSON.parse(Nb):Nb=[];const Gg=document.getElementById("MarketSearchInterval");
Gg.addEventListener("change",()=>{localStorage.setItem("MarketSearchInterval",Gg.value)});document.getElementById("MarketSearchInterval").addEventListener("input",function(){3>parseInt(this.value,10)&&(this.value=3)});const Hg=document.getElementById("MarketMaxPerFoodPrice");Hg.addEventListener("change",()=>{localStorage.setItem("MarketMaxPerFoodPrice",Hg.value)});const Ig=document.getElementById("MarketMaxFoodPrice");Ig.addEventListener("change",()=>{localStorage.setItem("MarketMaxFoodPrice",Ig.value)});
const Jg=document.getElementById("MarketMinItemLevel");Jg.addEventListener("change",()=>{localStorage.setItem("MarketMinItemLevel",Jg.value)});let qe=document.getElementById("marketOnlyFood");qe.checked="true"===localStorage.getItem("marketOnlyFood");qe.addEventListener("change",()=>{localStorage.setItem("marketOnlyFood",qe.checked)});let lb=JSON.parse(localStorage.getItem("marketItems"))||[];bj.onclick=function(){lb.push({itemToBuy:Bg.value||1,rarity:Cg.value||4,maxPrice:Fg.value||4,itemType:Dg.value||
4,Soulbound:Eg.value||2});Bg.value="";Cg.value="White";Fg.value="";Dg.value="WEAPONS";Eg.value="DontBuySoulbound";ad()};cj.onclick=function(){lb.splice(bd.value,1);ad()};dj.onclick=function(){document.getElementById("MarketboughtItems").innerHTML="";localStorage.setItem("MarketboughtItems",JSON.stringify([]))};ad();let re=document.getElementById("enableMarketSearch");re.checked="true"===localStorage.getItem("enableMarketSearch");re.addEventListener("change",()=>{localStorage.setItem("enableMarketSearch",
re.checked)});let se=document.getElementById("usePacks");se.checked="true"===localStorage.getItem("usePacks");se.addEventListener("change",()=>{localStorage.setItem("usePacks",se.checked)});const te=document.getElementById("scoreRange"),Kg=localStorage.getItem("scoreRange");Kg&&(te.value=Kg);te.addEventListener("change",()=>{localStorage.setItem("scoreRange",te.value)});const ue=document.getElementById("scoreRangeCircus"),Lg=localStorage.getItem("scoreRangeCircus");Lg&&(ue.value=Lg);ue.addEventListener("change",
()=>{localStorage.setItem("scoreRangeCircus",ue.value)});let ve=document.getElementById("scoreboardattackenable");ve.checked="true"===localStorage.getItem("scoreboardattackenable");ve.addEventListener("change",()=>{localStorage.setItem("scoreboardattackenable",ve.checked)});let we=document.getElementById("scoreboardcircusenable");we.checked="true"===localStorage.getItem("scoreboardcircusenable");we.addEventListener("change",()=>{localStorage.setItem("scoreboardcircusenable",we.checked)});let xe=document.getElementById("leagueattackenable");
xe.checked="true"===localStorage.getItem("leagueattackenable");xe.addEventListener("change",()=>{localStorage.setItem("leagueattackenable",xe.checked)});let Sb=document.getElementById("leaguerandom");Sb.checked="true"===localStorage.getItem("leaguerandom");Sb.addEventListener("change",()=>{localStorage.setItem("leaguerandom",Sb.checked);Sb.checked&&(Tb.checked=!1,localStorage.setItem("leaguelowtohigh",!1))});let Tb=document.getElementById("leaguelowtohigh");Tb.checked="true"===localStorage.getItem("leaguelowtohigh");
Tb.addEventListener("change",()=>{localStorage.setItem("leaguelowtohigh",Tb.checked);Tb.checked&&(Sb.checked=!1,localStorage.setItem("leaguerandom",!1))});let ye=document.getElementById("leaguecircusattackenable");ye.checked="true"===localStorage.getItem("leaguecircusattackenable");ye.addEventListener("change",()=>{localStorage.setItem("leaguecircusattackenable",ye.checked)});let Ub=document.getElementById("leaguecircusrandom");Ub.checked="true"===localStorage.getItem("leaguecircusrandom");Ub.addEventListener("change",
()=>{localStorage.setItem("leaguecircusrandom",Ub.checked);Ub.checked&&(Vb.checked=!1,localStorage.setItem("leaguecircuslowtohigh",!1))});let Vb=document.getElementById("leaguecircuslowtohigh");Vb.checked="true"===localStorage.getItem("leaguecircuslowtohigh");Vb.addEventListener("change",()=>{localStorage.setItem("leaguecircuslowtohigh",Vb.checked);Vb.checked&&(Ub.checked=!1,localStorage.setItem("leaguecircusrandom",!1))});let ze=document.getElementById("autoAddArena");ze.checked="true"===localStorage.getItem("autoAddArena");
ze.addEventListener("change",()=>{localStorage.setItem("autoAddArena",ze.checked)});let Ae=document.getElementById("autoAvoidArena");Ae.checked="true"===localStorage.getItem("autoAvoidArena");Ae.addEventListener("change",()=>{localStorage.setItem("autoAvoidArena",Ae.checked)});const Mg=document.getElementById("autoAddArenaAmount");Mg.addEventListener("change",()=>{localStorage.setItem("autoAddArenaAmount",Mg.value)});let Be=document.getElementById("autoAddCircus");Be.checked="true"===localStorage.getItem("autoAddCircus");
Be.addEventListener("change",()=>{localStorage.setItem("autoAddCircus",Be.checked)});let Ce=document.getElementById("autoAvoidCircus");Ce.checked="true"===localStorage.getItem("autoAvoidCircus");Ce.addEventListener("change",()=>{localStorage.setItem("autoAvoidCircus",Ce.checked)});const Ng=document.getElementById("autoAddCircusAmount");Ng.addEventListener("change",()=>{localStorage.setItem("autoAddCircusAmount",Ng.value)});let De=document.getElementById("UnderWorldUseRuby");De.checked="true"===localStorage.getItem("UnderWorldUseRuby");
De.addEventListener("change",()=>{localStorage.setItem("UnderWorldUseRuby",De.checked)});let Ee=document.getElementById("useSacrifice");Ee.checked="true"===localStorage.getItem("useSacrifice");Ee.addEventListener("change",()=>{localStorage.setItem("useSacrifice",Ee.checked)});let Fe=document.getElementById("usePray");Fe.checked="true"===localStorage.getItem("usePray");Fe.addEventListener("change",()=>{localStorage.setItem("usePray",Fe.checked)});let Ge=document.getElementById("UnderworldUseMobi");
Ge.checked="true"===localStorage.getItem("UnderworldUseMobi");Ge.addEventListener("change",()=>{localStorage.setItem("UnderworldUseMobi",Ge.checked)});let He=document.getElementById("exitUnderworld");He.checked="true"===localStorage.getItem("exitUnderworld");He.addEventListener("change",()=>{localStorage.setItem("exitUnderworld",He.checked)});let Ie=document.getElementById("autoEnterHell");Ie.checked="true"===localStorage.getItem("autoEnterHell");Ie.addEventListener("change",()=>{localStorage.setItem("autoEnterHell",
Ie.checked)});let Je=document.getElementById("dontEnterUnderworld");Je.checked="true"===localStorage.getItem("dontEnterUnderworld");Je.addEventListener("change",()=>{localStorage.setItem("dontEnterUnderworld",Je.checked)});let Ke=document.getElementById("disableLogMenu");Ke.checked="true"===localStorage.getItem("disableLogMenu");Ke.addEventListener("change",()=>{localStorage.setItem("disableLogMenu",Ke.checked)});let Le=document.getElementById("disableBG");Le.checked="true"===localStorage.getItem("disableBG");
Le.addEventListener("change",()=>{localStorage.setItem("disableBG",Le.checked)});let Me=document.getElementById("MoveButtons");Me.checked="true"===localStorage.getItem("MoveButtons");Me.addEventListener("change",()=>{localStorage.setItem("MoveButtons",Me.checked)});let Ne=document.getElementById("pauseBotEnable");Ne.checked="true"===localStorage.getItem("pauseBotEnable");Ne.addEventListener("change",()=>{localStorage.setItem("pauseBotEnable",Ne.checked)});const Og=document.getElementById("pauseBot");
Og.addEventListener("change",()=>{Y("pauseBot",Og.value)});let Oe=document.getElementById("storeGoldinAuction");Oe.checked="true"===localStorage.getItem("storeGoldinAuction");Oe.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuction",Oe.checked)});const Pg=document.getElementById("storeGoldinAuctionmaxGold");Pg.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuctionmaxGold",Pg.value)});const Qg=document.getElementById("storeGoldinAuctionholdGold");Qg.addEventListener("change",
()=>{localStorage.setItem("storeGoldinAuctionholdGold",Qg.value)});const Rg=document.getElementById("TrainingHoldGold");Rg.addEventListener("change",()=>{localStorage.setItem("TrainingHoldGold",Rg.value)});const Sg=document.getElementById("MarketHoldGold");Sg.addEventListener("change",()=>{localStorage.setItem("MarketHoldGold",Sg.value)});const Tg=document.getElementById("KasaHoldGold");Tg.addEventListener("change",()=>{localStorage.setItem("KasaHoldGold",Tg.value)});let Pe=document.getElementById("guildBattleEnable");
Pe.checked="true"===localStorage.getItem("guildBattleEnable");Pe.addEventListener("change",()=>{localStorage.setItem("guildBattleEnable",Pe.checked)});let Qe=document.getElementById("guildBattleRandom");Qe.checked="true"===localStorage.getItem("guildBattleRandom");Qe.addEventListener("change",()=>{localStorage.setItem("guildBattleRandom",Qe.checked)});let Re=document.getElementById("GuildEnable");Re.checked="true"===localStorage.getItem("GuildEnable");Re.addEventListener("change",()=>{localStorage.setItem("GuildEnable",
Re.checked)});const Ug=document.getElementById("GuildDonateAmount");Ug.addEventListener("change",()=>{localStorage.setItem("GuildDonateAmount",Ug.value)});const Vg=document.getElementById("GuildDonateMore");Vg.addEventListener("change",()=>{localStorage.setItem("GuildDonateMore",Vg.value)});const Wg=document.getElementById("GuildDonateLess");Wg.addEventListener("change",()=>{localStorage.setItem("GuildDonateLess",Wg.value)});document.getElementById("hellDifficulty").addEventListener("change",function(){localStorage.setItem("hellDifficulty",
this.value)});const ej=document.getElementById("hellDifficulty"),Xg=localStorage.getItem("hellDifficulty");null!==Xg&&(ej.value=Xg);let Se=document.getElementById("useVillaMedici");Se.checked="true"===localStorage.getItem("useVillaMedici");Se.addEventListener("change",()=>{localStorage.setItem("useVillaMedici",Se.checked)});let Te=document.getElementById("useHealingPotion");Te.checked="true"===localStorage.getItem("useHealingPotion");Te.addEventListener("change",()=>{localStorage.setItem("useHealingPotion",
Te.checked)});const Ue=document.getElementById("repairMercenary");Ue.checked="true"===localStorage.getItem("repairMercenary");Ue.addEventListener("change",()=>{localStorage.setItem("repairMercenary",Ue.checked)});const Ve=document.getElementById("repairGladiator");Ve.checked="true"===localStorage.getItem("repairGladiator");Ve.addEventListener("change",()=>{localStorage.setItem("repairGladiator",Ve.checked)});let We=document.getElementById("activateRepair");We.checked="true"===localStorage.getItem("activateRepair");
We.addEventListener("change",()=>{localStorage.setItem("activateRepair",We.checked)});const fj=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(z=>{z.checked=fj.includes(z.value)});document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(z=>{z.addEventListener("change",()=>{const J=[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(P=>{P.checked&&J.push(P.value)});
localStorage.setItem("ignoredMaterials",JSON.stringify(J))})});const Yg=document.querySelectorAll(".gladiator-inventory .inventory-item"),Zg=document.querySelectorAll(".mercenary-inventory .inventory-item"),$g=JSON.parse(localStorage.getItem("activeItemsGladiator"))||{},ah=JSON.parse(localStorage.getItem("activeItemsMercenary"))||{};Yg.forEach(z=>{Tf(z,$g,"activeItemsGladiator")});Zg.forEach(z=>{Tf(z,ah,"activeItemsMercenary")});Uf(Yg,$g,"helmet necklace weapon armor shield gloves shoes rings1 rings2".split(" "),
"activeItemsGladiator");Uf(Zg,ah,"helmetM necklaceM weaponM armorM shieldM glovesM shoesM rings1M rings2M".split(" "),"activeItemsMercenary");const bh=document.getElementById("expeditionLocation");bh.addEventListener("change",()=>{localStorage.setItem("expeditionLocation",bh.value)});const ch=document.getElementById("dungeonLocation");ch.addEventListener("change",()=>{localStorage.setItem("dungeonLocation",ch.value)});const Bc=document.getElementById("autoCollectBonuses");Bc.checked="true"===localStorage.getItem("autoCollectBonuses");
document.getElementById("enemySelection").style.display=Bc.checked?"none":"block";Bc.addEventListener("change",()=>{localStorage.setItem("autoCollectBonuses",Bc.checked)});const Xe=document.getElementById("skipBossToggle");Xe.checked="true"===localStorage.getItem("skipBoss");Xe.addEventListener("change",()=>{localStorage.setItem("skipBoss",Xe.checked)});const Ye=document.getElementById("resetIfLoseToggle");Ye.checked="true"===localStorage.getItem("resetIfLose");Ye.addEventListener("change",()=>{localStorage.setItem("resetIfLose",
Ye.checked)});const Ze=document.getElementById("activateSmelt");Ze.checked="true"===localStorage.getItem("EnableSmelt");Ze.addEventListener("change",()=>{localStorage.setItem("EnableSmelt",Ze.checked)});const $e=document.getElementById("EnableHellLimit"),dh=document.getElementById("hellLimit").closest(".setting-row"),eh="true"===localStorage.getItem("EnableHellLimit"),fh=localStorage.getItem("hellLimit")||5;$e.checked=eh;document.getElementById("hellLimit").value=fh;dh.style.display=eh?"block":"none";
$e.addEventListener("change",function(){const z=$e.checked;localStorage.setItem("EnableHellLimit",z);dh.style.display=z?"block":"none"});document.getElementById("hellLimit").addEventListener("input",function(){const z=document.getElementById("hellLimit").value;1<=z&&200>=z?localStorage.setItem("hellLimit",z):document.getElementById("hellLimit").value=fh});const tc=document.getElementById("farmEnable"),yi=document.getElementById("farmLocation").closest(".setting-row"),zi=document.getElementById("farmEnemy").closest(".setting-row"),
gj="true"===localStorage.getItem("farmEnable"),gh=localStorage.getItem("farmLocation"),hh=localStorage.getItem("farmEnemy");tc.checked=gj;gh&&(document.getElementById("farmLocation").value=gh);hh&&(document.getElementById("farmEnemy").value=hh);Vf();tc.addEventListener("change",function(){localStorage.setItem("farmEnable",tc.checked);Vf()});document.getElementById("farmLocation").addEventListener("change",function(){localStorage.setItem("farmLocation",this.value)});document.getElementById("farmEnemy").addEventListener("change",
function(){localStorage.setItem("farmEnemy",this.value)});const af=document.getElementById("doHeal");af.checked="true"===localStorage.getItem("HealEnabled");af.addEventListener("change",()=>{localStorage.setItem("HealEnabled",af.checked)});const bf=document.getElementById("healShopToggle");bf.checked="true"===localStorage.getItem("HealShop");bf.addEventListener("change",()=>{localStorage.setItem("HealShop",bf.checked)});const cf=document.getElementById("healfrompackage");cf.checked="true"===localStorage.getItem("HealPackage");
cf.addEventListener("change",()=>{localStorage.setItem("HealPackage",cf.checked)});const df=document.getElementById("healcervisia");df.checked="true"===localStorage.getItem("HealCervisia");df.addEventListener("change",()=>{localStorage.setItem("HealCervisia",df.checked)});const ef=document.getElementById("HealEggs");ef.checked="true"===localStorage.getItem("HealEggs");ef.addEventListener("change",()=>{localStorage.setItem("HealEggs",ef.checked)});const ff=document.getElementById("OilEnable");ff.checked=
"true"===localStorage.getItem("OilEnable");ff.addEventListener("change",()=>{localStorage.setItem("OilEnable",ff.checked)});document.getElementById("enemySelect").addEventListener("change",function(){localStorage.setItem("selectedEnemy",this.value)});const hj=document.getElementById("enemySelect"),ih=localStorage.getItem("selectedEnemy");null!==ih&&(hj.value=ih);document.getElementById("autoCollectBonuses").addEventListener("change",function(){document.getElementById("enemySelection").style.display=
this.checked?"none":"block"});Ai.addEventListener("change",function(){this.checked?(c(!0),Fa=!0):(c(!1),Fa=!1);localStorage.setItem("doExpedition",Fa);w()});Bi.addEventListener("change",function(){this.checked?(e(!0),Ga=!0):(e(!1),Ga=!1);localStorage.setItem("doDungeon",Ga);w()});Ci.addEventListener("change",function(){this.checked?(g(!0),Ha=!0):(g(!1),Ha=!1);localStorage.setItem("doArena",Ha);w()});document.getElementById("addAutoAttack").addEventListener("click",()=>{const z=document.getElementById("autoAttackInput").value.trim();
z&&jc(z,"autoAttackList","autoAttackList")});document.getElementById("addAvoidAttack").addEventListener("click",()=>{const z=document.getElementById("avoidAttackInput").value.trim();z&&jc(z,"avoidAttackList","avoidAttackList")});document.getElementById("addAutoCircusAttack").addEventListener("click",()=>{const z=document.getElementById("autoAttackCircusInput").value.trim();z&&jc(z,"autoAttackCircusList","autoAttackCircusList")});document.getElementById("addAvoidCircusAttack").addEventListener("click",
()=>{const z=document.getElementById("avoidAttackCircusInput").value.trim();z&&jc(z,"avoidAttackCircusList","avoidAttackCircusList")});si();Di.addEventListener("change",function(){this.checked?(l(!0),Ma=!0):(l(!1),Ma=!1);localStorage.setItem("doCircus",Ma);w()});Ei.addEventListener("change",function(){this.checked?(h(!0),Sa=!0):(h(!1),Sa=!1);localStorage.setItem("doQuests",Sa);w()});Hi.addEventListener("change",function(){this.checked?(n(!0),rb=!0):(n(!1),rb=!1);localStorage.setItem("doKasa",rb);
w()});Gi.addEventListener("change",function(){this.checked?(q(!0),ib=!0):(q(!1),ib=!1);localStorage.setItem("AutoAuction",ib);w()});Fi.addEventListener("change",function(){this.checked?(k(!0),Ia=!0):(k(!1),Ia=!1);localStorage.setItem("doEventExpedition",Ia);w()});uc.addEventListener("input",()=>{let z=parseInt(uc.value,10);1>z?z=1:99<z&&(z=99);uc.value=z;localStorage.setItem("healPercentage",z)});dd.addEventListener("input",()=>{let z=parseInt(dd.value,10);1>z?z=1:99<z&&(z=99);dd.value=z;localStorage.setItem("hellEnterHP",
z)});ed.addEventListener("input",()=>{let z=parseInt(ed.value,10);1>z?z=1:99<z&&(z=99);ed.value=z;localStorage.setItem("HellHealHP",z)});cd.addEventListener("change",()=>{localStorage.setItem("HealClothToggle",cd.checked)});fd.addEventListener("change",()=>{localStorage.setItem("HealRubyToggle",fd.checked)});gd.addEventListener("change",()=>{localStorage.setItem("storeResource",gd.checked)});hd.addEventListener("change",()=>{localStorage.setItem("HighlightUnderworldItems",hd.checked)});const gf=document.querySelectorAll(".stat-checkbox"),
ij=localStorage.getItem("selectedStat");for(const z of gf)z.checked=z.id===ij;for(const z of gf)z.addEventListener("change",()=>{if(z.checked){for(const J of gf)J!==z&&(J.checked=!1);localStorage.setItem("selectedStat",z.id);localStorage.setItem("statID",z.getAttribute("data-skill"))}else localStorage.removeItem("selectedStat")})});$("#set_event_monster_id_0").click(function(){r("0")});$("#set_event_monster_id_1").click(function(){r("1")});$("#set_event_monster_id_2").click(function(){r("2")});$("#set_event_monster_id_3").click(function(){r("3")});
w()}async function jj(){if("true"===localStorage.getItem("storeResource")){var b=new URL(window.location.href),c=b.origin;b=b.searchParams.get("sh")||"";const e=Date.now();c=`${c}/game/ajax.php?mod=forge&submod=storageIn`;const g=new FormData;g.append("inventory","1");g.append("packages","1");g.append("sell","1");g.append("a",e);g.append("sh",b);b=JSON.parse(localStorage.getItem("Timers"));Y("storeForgeResources",b.StoreForge||60);try{(await fetch(c,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:g})).ok?F(`${d.Gf}`):window.location.reload()}catch(l){window.location.reload()}}}async function kj(){var b=new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=JSON.parse(localStorage.getItem("statSettings"))||[];const g=JSON.parse(localStorage.getItem("Timers"))||{},l="true"===localStorage.getItem("trainPickGold"),h={Strength:1,Dexterity:2,Agility:3,Constitution:4,Charisma:5,Intelligence:6};b.forEach(r=>{r.ym=h[r.stat]});b.sort((r,w)=>"None"===
r.priority?1:"None"===w.priority?-1:parseInt(r.priority,10)-parseInt(w.priority,10));c=await (await fetch(`${c}/game/index.php?mod=training&sh=${e}`)).text();const k=[];(new DOMParser).parseFromString(c,"text/html").querySelectorAll("#training_box .training_inner").forEach((r,w)=>{w+=1;var v=r.nextElementSibling?.querySelector(".training_link .training_button");v=v?v.getAttribute("href"):null;(r=(r=(r=r.nextElementSibling?.querySelector(".training_costs"))?r.textContent.trim():null)?parseInt(r.replace(/[^\d]/g,
""),10):null)&&v?k.push({ym:w,tn:r,Sn:v}):k.push({ym:w,tn:r,Sn:v})});for(const r of b){c=r.stat;const w=r.ym;var q=r.priority;if(!(1>Number(r.count)||"None"===q)){var n=k.find(v=>v.ym===w);if(n){q=n.tn;var m=n.Sn;n=parseInt(localStorage.getItem("TrainingHoldGold"),10)||0;if(da.gold>=q+n){await fetch(m);--r.count;r.count=Math.max(0,r.count);localStorage.setItem("statSettings",JSON.stringify(b));F(`Trained ${c} for ${q} gold`);Y("Training",g.Training||2);return}if(l){m=await fetch(I({mod:"packages",
f:14,fq:-1,qry:"",page:1,sh:e}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(E=>E.text());m=jQuery(m).find(".packageItem");let v=q+n-da.gold;if(0>=v){F("Already have enough gold, no need to pick from packages");return}let y=0;const D=[];m.each((E,t)=>{E=jQuery(t);t=parseInt(E.find(".ui-draggable").attr("data-price-gold"),10);!isNaN(t)&&0<t&&(D.push({element:E,Oo:t}),y+=t);if(y>=v)return!1});if(y<v){F(`${d.Fd}: ${c} (Not enough gold in packages)`);
Y("Training",g.Training||2);return}async function C(E){return new Promise((t,u)=>{dc(1,1,async(A,B)=>{try{const H=E.element.find('input[name="packages[]"]').val(),G=E.element.find(".ui-draggable").attr("data-position-x"),K=E.element.find(".ui-draggable").attr("data-position-y"),L=T({mod:"inventory",submod:"move",from:"-"+H,fromX:G,fromY:K,to:B,toX:A.x+1,toY:A.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:e});await fetch(L,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:new URLSearchParams({})}).then(M=>M.text());t(E.Oo)}catch(H){u(H)}})})}try{c=0;for(const E of D)if(c+=await C(E),c>=v)break;F(`Moved ${c} gold to inventory for training`);localStorage.setItem("Training",0);window.location.reload()}catch(E){F(`Error moving gold: ${E.message}`)}}else F(`${d.Fd}`)}else F(`No training available for ${c}`)}}Y("Training",g.Training||2)}function lj(){const b=JSON.parse(localStorage.getItem("statSettings"));for(let c=0;c<b.length;c++)if("0"!==b[c].count||
b[c].mn)return!0;return!1}function mj(){var b=new URL(window.location.href),c=localStorage.getItem("scoreboardattackenable"),e=localStorage.getItem("scoreboardcircusenable");if(document.querySelector(".reportWin")){var g=document.querySelector(".report_reward");g&&(g=g.querySelector('img[src*="71e68d38f81ee6f96a618f33c672e0.gif"]'))&&(g=g.previousSibling)&&g.nodeType===Node.TEXT_NODE&&(g=g.textContent.trim().match(/(\d+(?:\.\d+)?)/))&&(g=parseFloat(g[1]),b.href.includes("&t=2")?ma("arenaMoney",g):
b.href.includes("&t=3")&&ma("circusMoney",g))}if(b.href.includes("submod=showCombatReport")&&b.href.includes("&t=1"))(c=document.getElementById("reportHeader"))&&(c.classList.contains("reportWin")||"true"!==sessionStorage.getItem("autoGoActive")?localStorage.setItem("loose","false"):localStorage.setItem("loose","true"));else if(b.href.includes("submod=showCombatReport")){let k=document.querySelector("p > a + img");var l=document.querySelector("#defenderAvatar11 .playername_achievement");null===l&&
(l=document.querySelector("#defenderAvatar11 .playername.ellipsis "));(g=document.getElementById("reportHeader"))&&!g.classList.contains("reportWin")&&(localStorage.setItem("nextQuestTime.timeOut",0),localStorage.setItem("nextQuestTime",0));g=0;if(l&&(l=l.innerText.trim(),!l.includes("#"))){try{var h=k.previousSibling.nodeValue.trim();h=h.split(" ").pop();h=h.replace(".","");h=h.replace(",",".");g=parseFloat(h)}catch(q){}b.href.includes("&t=2")?(e=document.getElementById("reportHeader").classList.contains("reportWin"),
b=JSON.parse(localStorage.getItem("tempOpponentDetails")),h=Kf.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidArena")||e||mb("avoidAttackList",l),"true"===localStorage.getItem("autoAddArena")&&Number(g)>=Number(localStorage.getItem("autoAddArenaAmount"))&&b&&b.serverId&&(h===b.serverId?(mb("autoAttackList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===c&&l!=b.playerName?mb("autoAttackList",l):h!==b.serverId&&mb("autoAttackServerList",b))):b.href.includes("&t=3")&&
(c=document.getElementById("reportHeader").classList.contains("reportWin"),b=JSON.parse(localStorage.getItem("tempOpponentDetails")),h=Kf.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidCircus")||c||mb("avoidAttackCircusList",l),"true"===localStorage.getItem("autoAddCircus")&&g>=Number(localStorage.getItem("autoAddCircusAmount"))&&b&&b.serverId&&(h===b.serverId?(mb("autoAttackCircusList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===e&&l!=b.playerName?mb("autoAttackCircusList",
l):h!==b.serverId&&mb("autoAttackCircusServerList",b)))}}}function mb(b,c){let e=JSON.parse(localStorage.getItem(b))||[];if("object"===typeof c&&null!==c){let g=c.playerName;e.some(l=>l.playerName===g&&l.serverId===c.serverId)||e.push(c)}else"string"===typeof c&&(e.includes(c)||e.push(c));localStorage.setItem(b,JSON.stringify(e))}async function jh(b){var c=new URL(window.location.href),e=c.origin,g=c.searchParams;c=localStorage.getItem("AuctionItemLevel2")||"";const l=g.get("itemType")||"",h=localStorage.getItem("SearchQuality")||
"";g=g.get("sh")||"";e=new URL(`${e}/game/index.php?mod=auction&qry=&itemLevel=${c}&itemType=${l}&itemQuality=${h}&sh=${g}`);e.searchParams.set("mod","auction");e.searchParams.set("itemLevel",c);e.searchParams.set("itemType",l);e.searchParams.set("itemQuality",h);e.searchParams.set("sh",g);b&&e.searchParams.set("ttype",b);b=await (await fetch(e.href)).text();return(new DOMParser).parseFromString(b,"text/html")}async function Qf(){var b=new URL(window.location.href);const c=b.origin,e=b.searchParams.get("sh")||
"";b=Array.from({length:5},(l,h)=>[new URL(`${c}/game/index.php?mod=inventory&sub=${h+1}&subsub=0&sh=${e}`),new URL(`${c}/game/index.php?mod=inventory&sub=${h+1}&subsub=1&sh=${e}`)]).flat();const g=async l=>{var h=await (await fetch(l.href)).text();h=(new DOMParser).parseFromString(h,"text/html");h.Wm=l.href;return h};return await Promise.all(b.map(l=>g(l)))}function hf(b){return JSON.parse(b.replace(/&quot;/g,'"'))[0][0][0]}async function nj(b){b=(new TextEncoder).encode(b.toString());b=await crypto.subtle.digest("SHA-256",
b);return Array.from(new Uint8Array(b)).map(c=>c.toString(16).padStart(2,"0")).join("")}function hb(){(function(b){const c=setInterval(()=>{const e=document.getElementById("mainmenu");e&&(clearInterval(c),b(e))},500)})(b=>{if(!document.querySelector(".customButtonm")){var c=document.createElement("button");c.className="customButtonm";c.innerHTML='\n            <style>\n            .customButtonm {\n                vertical-align: middle;\n                width: 179px;\n                height: 50px;\n                background-image: linear-gradient(135deg, #f29b20 0%, #b18026 100%);\n                border: 2px solid #000;\n                color: white;\n                text-align: center;\n                text-decoration: none;\n                border-radius: 5px;\n                display: inline-block;\n                font-size: 16px;\n                margin: 4px auto;\n                cursor: pointer;\n                box-shadow: 5px 2px 5px rgba(0, 0, 0, 0.3), inset 0 1px 1px rgba(255, 255, 255, 0.4), inset 0 -1px 1px rgba(0, 0, 0, 0.3);\n                padding: 18px 34px;\n                transition-duration: 0.4s;\n            }\n        \n            .customButtonm span {\n                top: 50%;\n                position: relative;\n                transform: translateY(-50%);\n                display: block;\n                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);\n            }\n            </style>\n\n            <span class="span-new">License expired or Server Error. Check Discord</span>\n\n        ';
b.insertBefore(c,b.children[0]);Of(45E3)}});return!1}async function oj(b,c,e){function g(l){const h=[];for(let k=0;k<l.length;k+=2)h.push(parseInt(l.substr(k,2),16));return new Uint8Array(h)}try{if(!e)return!1;const [l,h]=e.split(":"),k=g(l),q=g(h);if(b!==ya)return!1;const n=await window.crypto.subtle.importKey(String.fromCharCode(114,97,119),g("46d9ef519c1474cf8699ba24ab2a726a"),{name:String.fromCharCode(65,69,83)+"-CBC"},!1,[String.fromCharCode(100,101,99,114,121,112,116)]),m=await window.crypto.subtle.decrypt({name:String.fromCharCode(65,
69,83)+"-CBC",iv:k},n,q),r=(new TextDecoder).decode(new Uint8Array(m)),w=new Date(r);w.setHours(0,0,0,0);if(!0!==c)return!1;const v=new Date,y=new Date(v.setMonth(v.getMonth()+13));return w>y||r<v?!1:!0}catch{throw hb(),Error("supportDev");}}function pj(){function b(h,k){ub?alert("A repair process is already running."):(l.Kn=k,jQuery(".gladbot-worbench-button").addClass("disabled"),l.u(),l.Jn=[],l.queue=0,jQuery(document.body).addClass("workbench-cursor"),jQuery(document.body).on("contextmenu",function(q){q.preventDefault();
jQuery(document.body).removeClass("workbench-cursor");jQuery(document.body).off("contextmenu")}),jQuery("#inv .ui-draggable, #char .ui-draggable").mouseup(async q=>{q=q.target;var n=q.className.match(/item-i-(\d+)-\d+/)[1],m=document.querySelector(".charmercsel.active").getAttribute("onclick").toString().match(/doll=(\d+)/),r=l.freeSlots.shift()["forge_slots.slot"];m=m[1];r={item:{type:n,name:Ib(q),quality:Ca(q),slot:r,container:q.getAttribute("data-container-number"),doll:m},spot:{bag:q.getAttribute("data-container-number"),
x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")}};localStorage.setItem("workbench_itemList1",JSON.stringify(r));if(jQuery(q).parents("#char").length)if(ub)alert("A repair process is already running.");else{if(n=document.querySelector("#inventory_nav .awesome-tabs.current"))n=n.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",n);var {spot:w,bag:v}=await dc(2,3);l.ra={bag:v,x:w.x+1,y:w.y+1};l.Pn(q);l.Vm(q,0,m);ub=!0}else if(jQuery(q).parents("#inv").length){if(m=
document.querySelector("#inventory_nav .awesome-tabs.current"))m=m.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",m);l.ra={bag:q.getAttribute("data-container-number"),x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")};ub?alert("A repair process is already running."):(l.Pn(q),q=q.getAttribute("data-item-id"),l.pj(q),ub=!0)}else l.queue++,l.cp(q),l.$m(n)}))}function c(h,k,q){k=jQuery("<button>").html(k).addClass(q);jQuery(h).append(k);return k}async function e(){try{const h=
new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")}),k=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:h}).then(q=>q.text());l.slots=JSON.parse(k).slots;l.spaces=l.slots.filter(q=>"closed"===q["forge_slots.state"]).length;l.freeSlots=l.slots.filter(q=>"closed"===q["forge_slots.state"])}catch(h){}}async function g(){try{const h=W("sh"),k=document.querySelectorAll("#inv .ui-draggable"),
q=[512,256,2,8,4,1,1024,48];let n=5;bb("Sending items to packages...");await e();if(0<l.spaces){for(let m of l.slots)if("closed"===m["forge_slots.state"]){n=m["forge_slots.slot"];break}for(let m of k){const r=parseInt(m.getAttribute("data-content-type"),10);if(q.includes(r)){const w=m.getAttribute("data-item-id"),v=Ib(m),y=parseInt(m.getAttribute("data-amount"),10)||1,D=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:n,iid:w,amount:y,a:Date.now(),sh:h});await fetch(T({}),
{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:D}).then(t=>t.text());const C=new URLSearchParams({mod:"forge",submod:"rent",mode:"workbench",slot:n,rent:2,item:w,a:Date.now(),sh:h});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:C}).then(t=>t.text());const E=new URLSearchParams({mod:"forge",submod:"cancel",mode:"workbench",slot:n,a:Date.now(),
sh:h});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:E}).then(t=>t.text());bb(`Item name : ${v} has been sent to the packages.`);await new Promise(t=>setTimeout(t,500))}}window.location.reload()}else bb("No available slots in the workbench.")}catch(h){}}const l={Kn:"full",async start(){let {itemList1:h,itemList2:k,repairArena:q,repairTurma:n}=aa.workbench,m=aa.workbench.selectedItem;m?this.u(()=>{switch(m.status){case "toWorkbench":l.pj(m.iid);
break;case "toFillGoods":l.kc(m.slot);break;case "toPackage":l.dd(m.slot);break;case "toBag":l.Ia();break;case "toInv":l.hm()}}):q&&0<h.length?"mod=overview&doll=1"!=tf?Pf("mod=overview&doll=1"):this.u(()=>{0<l.spaces&&this.vm(aa.workbench.itemList1)}):n&&0<k.length&&("mod=overview&doll=2"!=tf?Pf("mod=overview&doll=2"):this.u(()=>{0<l.spaces&&this.vm(aa.workbench.itemList2)}))},u(h=!1){const k=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});
fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:k}).then(q=>q.text()).then(q=>{l.slots=JSON.parse(q).slots;l.spaces=0;l.freeSlots=[];for(let n of l.slots)"closed"==n["forge_slots.state"]&&(l.spaces++,l.freeSlots.push(n));h&&h()})},vm(h){let k=h.shift();dc(k.zn,k.An,(q,n)=>{const m=T({mod:"inventory",submod:"move",from:k.container,fromX:1,fromY:1,to:n,toX:q.x+1,toY:q.y+1,amount:1,doll:k.doll}),r=new URLSearchParams({a:(new Date).getTime(),
sh:W("sh")});fetch(m,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:r}).then(w=>w.text()).then(w=>{let v={item:k,iid:JSON.parse(w).to.data.itemId,status:"toWorkbench",spot:q,bag:n};localStorage.setItem("workbench_selectedItem",JSON.stringify(v));this.pj(JSON.parse(w).to.data.itemId)})})},async Vm(h,k=0,q){var n=[512,513,514,515];if(!(k>=n.length)){n=n[k];var m=document.getElementById("inv");if(m=Nc(m,h))try{const w=T({mod:"inventory",
submod:"move",from:h.getAttribute("data-container-number"),fromX:1,fromY:1,to:n,toX:m.x+1,toY:m.y+1,amount:1,doll:q}),v=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")}),y=await fetch(w,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:v}).then(C=>C.text()),D=JSON.parse(y);if(D.error)this.Vm(h,k+1,q);else{var r={item:h,iid:D.to.data.itemId,status:"toWorkbench",spot:m,bag:n};localStorage.setItem("workbench_selectedItem",
JSON.stringify(r));localStorage.setItem("workbench_itemBag",JSON.stringify(r.bag));await this.pj(D.to.data.itemId)}}catch(w){}else this.Vm(h,k+1)}},async pj(h){qj();F(`${d.Ab}`);let k=5;for(var q of l.slots)"closed"==q["forge_slots.state"]&&(k=q["forge_slots.slot"]);q=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:k,iid:h,amount:1,a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:q}).then(n=>n.text()).then(n=>{l.needed=JSON.parse(n).slots[k].formula.needed;Jh().gold>JSON.parse(n).slots[k].formula.rent[2]?(n=new URLSearchParams({mod:"forge",submod:"rent",mode:"workbench",slot:k,rent:2,item:h,a:(new Date).getTime(),sh:W("sh")}),fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:n}).then(m=>m.text()).then(()=>{"full"==l.Kn?(localStorage.setItem("workbench_selectedItem",
JSON.stringify({slot:k,status:"toFillGoods"})),l.kc(k)):(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:k,status:"toFillPartial"})),l.bj(k))})):(F("Not enough gold to rent the workbench"),bb("Not enough gold to rent the workbench"))})},kc(h,k=-1,q=!0){F(`${d.Qf}`,k);const n=new URLSearchParams({mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:h,quality:k,a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:n}).then(m=>m.text()).then(()=>{if(k<Number(localStorage.getItem("repairMaxQuality")))l.kc(h,++k,q);else{const m=new URLSearchParams({mod:"forge",submod:"start",mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:m}).then(r=>r.text()).then(()=>{q?(localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"})),l.u(()=>
{l.dd(h)})):(l.queue--,0==l.queue&&window.location.reload())})}})},dd(h){let k=1E3*l.slots[h].formula.duration||1E4;F(`${d.bg}`,k);1==l.cancel?this.u(()=>{setTimeout(()=>{const q=new URLSearchParams({mod:"forge",submod:"cancel",mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:q}).then(n=>n.text()).then(n=>{if("document.location.href=document.location.href;"==
n)return window.location.reload();localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));l.Ia()})},k)}):this.u(()=>{setTimeout(()=>{const q=new URLSearchParams({mod:"forge",submod:"lootbox",mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:q}).then(n=>n.text()).then(n=>{if("document.location.href=document.location.href;"==n)return window.location.reload();
localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));l.Ia()})},k)})},async Ia(h=1){var k=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");var {item:q}=k;k=!1;var n=new URL(window.location.href),m=n.origin;n=n.searchParams.get("sh")||"";m=new URL(`${m}/game/index.php?mod=packages&qry=&f=${q.type}&page=${h}&sh=${n}`);m.searchParams.set("mod","packages");m.searchParams.set("f",q.type);m.searchParams.set("page",h);m.searchParams.set("sh",
n);m=await (await fetch(m.href)).text();m=(new DOMParser).parseFromString(m,"text/html");var r=m.querySelector(".ui-draggable");n=Ea(r);Ca(r);r=Ib(r);q.name==r&&q.type==n&&(k=!0,q=T({mod:"inventory",submod:"move",from:m.querySelector("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:l.ra.bag,toX:l.ra.x,toY:l.ra.y,amount:1}),m=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")}),fetch(q,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:m}).then(w=>w.text()).then(()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));l.hm()}));k||this.Ia(++h)},hm(){JSON.parse(localStorage.getItem("workbench_selectedItem"));var h=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");({item:h}=h);h=T({mod:"inventory",submod:"move",from:l.ra.bag,fromX:l.ra.x,fromY:l.ra.y,to:h.container,toX:1,toY:1,amount:1,doll:h.doll});const k=new URLSearchParams({a:(new Date).getTime(),
sh:W("sh")});fetch(h,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:k}).then(q=>q.text()).then(()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));F(`${d.Tf}`);ub=!1;window.location.reload()})},Fn(h){h=jQuery(h);h=jQuery("<div>").addClass("gbot-overlay").width(h.width()).height(h.height()).offset(h.offset()).append(jQuery('<div class="gbot-spinner"></div>'));jQuery(document.body).append(h)},
Dm(h,k,q){k=jQuery("<button>").html(k).addClass(q);jQuery(h).append(k);return k},Gq(){let h=0;for(let k of l.slots)if("finished-succeeded"==k["forge_slots.state"]){h++;const q=new URLSearchParams({mod:"forge",submod:"lootbox",mode:"workbench",slot:k["forge_slots.slot"],a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:q}).then(n=>n.text()).then(n=>{h--;if("document.location.href=document.location.href;"==
n||0==h)return window.location.reload()})}},cp(h){$b(h)&&(l.Fn(h),l.Jn.push(h))},Pn(h){$b(h)&&l.Fn(h)},$m(h,k,q){let n=l.freeSlots.shift()["forge_slots.slot"],m=l.Jn.shift(),r=null!==k?k:m.getAttribute("data-item-id"),w=null!==q?q:{bag:m.getAttribute("data-container-number"),x:m.getAttribute("data-position-x"),y:m.getAttribute("data-position-y")};k=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:n,iid:r,amount:1,a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",
credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:k}).then(v=>v.text()).then(v=>{let y=JSON.parse(v).slots[n].formula.needed;Jh().gold>JSON.parse(v).slots[n].formula.rent[2]&&(v=new URLSearchParams({mod:"forge",submod:"rent",mode:"workbench",slot:n,rent:2,item:r,a:(new Date).getTime(),sh:W("sh")}),fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:v}).then(D=>
D.text()).then(()=>{"full"==h?l.kc(n,w,!0):"partial"==h&&l.bj(n,w,y)}))})},bj(h,k,q){let n=[];q=l.needed;for(let m in q){const r=parseInt(m,10);0<q[m].amount&&!storedMaterials.some(w=>parseInt(w,10)+18E3===r)&&n.push({type:r,amount:q[m].amount})}l.Kl(n,(m,r)=>{m&&r?l.Ll(k,m,r,w=>{w||console.warn("pickMaterialFromPack did not return an iid. Skipping material picking.");w=new URLSearchParams({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:h,iid:w||"defaultIid",amount:1,a:(new Date).getTime(),
sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:w}).then(v=>v.text()).then(()=>{const v=new URLSearchParams({mod:"forge",submod:"start",mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")});fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:v}).then(y=>y.text()).then(()=>{l.queue--;localStorage.setItem("workbench_selectedItem",
JSON.stringify({status:"toPackage"}));l.u(()=>{l.dd(h)});0==l.queue&&window.location.reload()})})}):(l.cancel=!0,l.u(()=>{l.dd(h)}))})},Kl(h,k=!1,q=0,n=-1){if(q==h.length)if(1>n)q=0,n++;else return k&&k(null,null);jQuery.post(T({mod:"forge",submod:"storageOut"}),{type:h[q],quality:n,amount:1,a:(new Date).getTime(),sh:W("sh")}).done(()=>k&&k(h[q],n)).fail(()=>l.Kl(h,k,++q,n))},Ll(h,k,q,n=!1,m=1){let r=!1;fetch(I({mod:"packages",f:18,fq:q,qry:"",page:1,sh:W("sh")}),{method:"GET",credentials:"include",
headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(w=>w.text()).then(w=>{jQuery(w).find(".packageItem").each((v,y)=>{var D=jQuery(y).find(".ui-draggable");v=D.context.querySelector("input").getAttribute("value");y=Ra(D[0]).split("-")[1];D=Ca(D[0]);k==y&&q==D&&(r=!0,v=T({mod:"inventory",submod:"move",from:"-"+v,fromX:1,fromY:1,to:l.ra.bag,toX:l.ra.x,toY:l.ra.y,amount:1}),y=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")}),fetch(v,{method:"POST",credentials:"include",
headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:y}).then(C=>C.text()).then(C=>{n&&n(JSON.parse(C).to.data.itemId)}))});r||l.Ll(h,k,q,n,++m)})}};jQuery("#inv").after('\n              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n    \n                <fieldset id="gladbot-workbench" style="\n                  padding: 10px;\n                  margin: 10px 20px;\n                  text-align: center;\n                  display: flex;\n                  flex-direction: row;\n                  flex-wrap: wrap;\n                  align-items: center;\n                  justify-content: space-around;\n                  border: 2px solid darkred;\n                  border-radius: 8px;\n                  width: 235px;">\n                  <legend style="\n                    padding: 0 10px;\n                    color: darkred;\n                    font-weight: bold;">GLDbot Workbench Area</legend>\n                    <span class="span-new">Make sure last workbench slot is available, and make sure there\'s 3x3 space available. *Full repair uses any kind of material!!!* Install Crazy-Addon to see equipment panel.</span>\n                </fieldset>');
c("#gladbot-workbench",'<i class="fa fa-wrench"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for full repair. You can only repair one item at a time.").mouseup(h=>{b(h,"full")});c("#gladbot-workbench",'<i class="fa fa-hammer"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for partial repair. You can only repair one item at a time.").mouseup(h=>{b(h,"partial")});c("#gladbot-workbench",'<i class="fa fa-undo"></i>',
"gladbot-button gladbot-worbench-button-reset gladbot-stylish-button").attr("title","If an item is stuck and not repairing, click this button to reset.").mouseup(()=>{ub=!1});c("#gladbot-workbench","Send items in the current inventory to packages","gladbot-button gladbot-inventory-send-button gladbot-stylish-button").attr("title","Click this button to send items from the current inventory to packages.").mouseup(async()=>{await g()})}function bb(b){const c=document.createElement("div");c.className=
"notification-popup";c.innerText=b;c.style.position="fixed";c.style.bottom="20px";c.style.right="20px";c.style.padding="10px 20px";c.style.backgroundColor="rgba(0, 0, 0, 0.8)";c.style.color="white";c.style.borderRadius="5px";c.style.fontSize="14px";c.style.zIndex="9999";document.body.appendChild(c);setTimeout(()=>{c.remove()},3E3)}function kh(b,c,e,g,l,h){const k=document.createElement("span");k.className=c;k.innerHTML=b;k.title=h;k.style.cursor=e;k.style.fontSize=g;k.style.top="70px";k.style.position=
"absolute";k.style.right=l;return k}function lh(b,c){try{var e=JSON.parse(b.replace(/&quot;/g,'"'))}catch(q){return{}}b=e[0]?e[0][0]:null;e=e[0]?e[0][0][0]:null;var g=b[0];g="string"!==typeof g?"":g.split(" ")[0];const l=bc(b[0]),h=c.getAttribute("data-quality"),k=c.getAttribute("data-content-type");c=c.getAttribute("data-level");return{itemName:b,xn:g,yn:l,itemColor:{"-1":"white",0:"green",1:"blue",2:"purple",3:"orange",4:"red"}[h]||"white",itemType:k,itemLevel:c,rn:e}}async function qj(){const b=
I({mod:"packages",submod:"sort",page:"1",sh:W("sh")}),c=new URLSearchParams({packageSorting:"in_desc"});return await fetch(b,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(e=>e.text())}async function rj(){var b=localStorage.getItem("PackageSort")||"in_desc",c=await la.sm();let e=[];var g=Math.min(10,c);if("del_asc"===b||"in_asc"===b)for(c=1;c<=g;c++)e.push(c);else for(b=c;b>c-g;b--)e.push(b);g=[];for(const l of e)try{const h=
await fetch(I({mod:"packages",f:"0",fq:"-1",qry:"",page:l.toString(),sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(k=>k.text());g.push(h)}catch(h){F(`Error fetching pages ${l}: ${h.message}`)}return g.flat()}async function sj(b,c){if("mod=guildMarket"!=tf)Pf("mod=guildMarket");else{F(`${d.zf}`);var e={TOOLS:["2097152","1048576","8388608","4194304"],WEAPONS:["2"],SHIELD:["4"],CHEST:["8"],HELMET:["1"],GLOVES:["256"],
SHOES:["512"],RINGS:["48"],AMULETS:["1024"],USABLES:["4096","32768"],FOOD:["64"],UPGRADES:["4096"],RECIPES:["8192"],MERCENARY:["16384"],SCROLLS:["64"],REINFORCEMENTS:["4096"]},g=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]},l="true"===localStorage.getItem("resetUnderworld"),h=(await rj()).map(y=>jQuery(y).find(".packageItem").toArray()).flat();b=24*b;var k=!1;for(const y of h){h=y.querySelector("span[data-ticker-type]");if(!h)continue;h=h.getAttribute("data-ticker-time-left");if(!h)continue;
h=h/1E3/60/60;var q=y.querySelector("div[data-content-type]");const D=q?q.getAttribute("data-content-type"):null;q=(q=y.querySelector(".ui-draggable"))?q.getAttribute("data-basis"):null;if(("64"!==D||!q||c.includes("SCROLLS")&&q.startsWith("20")||c.includes("FOOD")&&q.startsWith("7")||c.includes("REINFORCEMENTS")&&q.startsWith("11"))&&h<=b&&(c.some(C=>e[C].includes(D))||l)){q=y.querySelector("div[data-container-number]");var n=void 0,m=void 0;h=(m=y.querySelector("div[data-amount]"))?m.getAttribute("data-amount"):
null;var r=m?m.getAttribute("data-quality"):null;l&&(n=m?m.getAttribute("data-basis"):null,m=m?m.getAttribute("data-hash"):null,n=Gb(n,m));if(!l||n)if(!(null!==r&&0<g.colors.length)||g.colors.includes(r)){q=q?q.getAttribute("data-container-number"):null;r=y.querySelector("div[data-measurement-x]").getAttribute("data-measurement-x");m=y.querySelector("div[data-measurement-y]").getAttribute("data-measurement-y");k=y.querySelector("div[data-tooltip]").getAttribute("data-tooltip");var w=hf(k);k=!0;await new Promise(C=>
setTimeout(C,200));await tj(y,q,w,h,r,m);h=W("sh");h=`${window.location.origin}/game/index.php?mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=p&p=1&&sh=${h}`;q=await (await fetch(h)).text();q=(new DOMParser).parseFromString(q,"text/html").querySelectorAll("#market_table tr");if((r=document.querySelector('input[type="submit"][name="anbieten"][value="Offer"]'))&&r.disabled)h=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",h.ResetExpired||10),F(`${d.Hf}`);else for(r=1;r<q.length;r++){var v=
q[r];m=v.querySelectorAll("td")[2];w=v.querySelector('input[name="cancel"]');v=(v=v.querySelector("div[data-item-id]"))?v.getAttribute("data-item-id"):null;w&&Number(m.textContent.replace(/\./g,""))===Number(mh)&&(m={csrf_token:x(),buyid:v,qry:"",seller:"",f:0,fl:0,fq:-1,s:"",p:1,cancel:"Cancel"},await fetch(h,{method:"POST",credentials:"include",body:new URLSearchParams(m)}),F(`${d.Af}`),ma("itemReset",0))}}}}if(!k||k)c=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",c.ResetExpired||
10),window.location.reload()}}async function tj(b,c,e,g,l,h){let {spot:k,bag:q}=await dc(l,h);try{const n=T({mod:"inventory",submod:"move",from:c,fromX:1,fromY:1,to:q,toX:k.x+1,toY:k.y+1,amount:g}),m=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")}),r=await fetch(n,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:m}).then(w=>w.text());if(r){const w=Math.floor(41*Math.random())+10;mh=w;const v=JSON.parse(r).to.data.itemId;
await uj(c,w,v)}}catch(n){F(`${d.Bf}`),b=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",b.ResetExpired||10),window.location.reload()}}async function uj(b,c,e){b=I({mod:"guildMarket",sh:W("sh")});c=new URLSearchParams({sellid:e,preis:c,dauer:1,sell_mode:0,anbieten:"Offer",csrf_token:x()});await fetch(b,{method:"POST",credentials:"include",body:c}).then(g=>g.text())}async function vj(){const b=JSON.parse(localStorage.getItem("Timers"));!1===JSON.parse(localStorage.getItem("underworld")||
"{}").isUnderworld&&"true"===localStorage.getItem("BuffUnderworldOnly")&&Y("BuffCheck",b.BuffTimer||10);"mod=overview&doll=1"!=tf&&Pf("mod=overview&doll=1");const c={"11-23":{type:"Health",item:"Gingko"},"11-22":{type:"Health",item:"Taigaroot"},"11-21":{type:"Health",item:"Hawthorn"},"11-1":{type:"Strength",item:"Flask"},"11-2":{type:"Strength",item:"Ampulla"},"11-3":{type:"Strength",item:"Flacon"},"11-4":{type:"Strength",item:"Bottle"},"11-13":{type:"Constitution",item:"Flask"},"11-14":{type:"Constitution",
item:"Ampulla"},"11-15":{type:"Constitution",item:"Flacon"},"11-16":{type:"Constitution",item:"Bottle"},"11-9":{type:"Agility",item:"Flask"},"11-10":{type:"Agility",item:"Ampulla"},"11-11":{type:"Agility",item:"Flacon"},"11-12":{type:"Agility",item:"Bottle"},"11-17":{type:"Charisma",item:"Flask"},"11-18":{type:"Charisma",item:"Ampulla"},"11-19":{type:"Charisma",item:"Flacon"},"11-20":{type:"Charisma",item:"Bottle"},"11-24":{type:"Intelligence",item:"Flask"},"11-25":{type:"Intelligence",item:"Ampulla"},
"11-26":{type:"Intelligence",item:"Flacon"},"11-27":{type:"Intelligence",item:"Bottle"},"11-5":{type:"Dexterity",item:"Flask"},"11-6":{type:"Dexterity",item:"Ampulla"},"11-7":{type:"Dexterity",item:"Flacon"},"11-8":{type:"Dexterity",item:"Bottle"}},e=JSON.parse(localStorage.getItem("buffs"))||{},g=JSON.parse(localStorage.getItem("buffSelections"))||{};for(const h in g){var l=g[h];let k=null;if(0<l.length)for(let q of l)if(Object.entries(c).find(([,n])=>n.type===h&&n.item===q)&&!Object.keys(e).find(n=>
n.includes(h)&&n.includes(q)&&0<e[n].timeLeft))try{let n=!1,m=null;for(l=1;3>=l;l++){const r=await fetch(I({mod:"packages",f:11,fq:-1,qry:"",page:l,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(w=>w.text());jQuery(r).find(".packageItem").each(function(w,v){w=jQuery(v).find(".ui-draggable").attr("data-basis");if((w=c[w])&&w.type===h&&w.item===q){const y=w.item;k=y;if(Object.keys(e).some(D=>D.includes(h)&&D.includes(y)))return!0;
n=!0;m=jQuery(v);return!1}});if(n)break}if(n&&m)try{await dc(1,1,async(r,w)=>{var v=m.find('input[name="packages[]"]').val();const y=m.find(".ui-draggable").attr("data-position-x"),D=m.find(".ui-draggable").attr("data-position-y");await new Promise(C=>setTimeout(C,250));v=T({mod:"inventory",submod:"move",from:"-"+v,fromX:y,fromY:D,to:w,toX:r.x+1,toY:r.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")});await fetch(v,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:new URLSearchParams({})}).then(C=>C.text());F(`${h} buff (${q}) has been moved to the inventory.`);await new Promise(C=>setTimeout(C,250));r=T({mod:"inventory",submod:"move",from:w,fromX:r.x+1,fromY:r.y+1,to:8,toX:1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")});await fetch(r,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(C=>C.text());e[`${h} - ${k}`]={timeLeft:m.find(".ticker").attr("data-ticker-time-left")/
6E4};localStorage.setItem("buffs",JSON.stringify(e))})}catch(r){Y("BuffCheck",b.BuffTimer||60),F(`Error moving or using ${h} buff (${q}):`,r)}else Y("BuffCheck",b.BuffTimer||60),F(`No ${h} buff found for ${q}.`)}catch(n){Y("BuffCheck",b.BuffTimer||60),F("Error fetching buffs from packages:",n)}}}function wj(){const b=Date.now(),c=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),e=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||
"{}"),l=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}");Object.entries(e).forEach(([h,k])=>{3E5<b-k&&(c[h]=!0,delete e[h])});Object.entries(l).forEach(([h,k])=>{3E5<b-k&&(g[h]=!0,delete l[h])});localStorage.setItem("activeItemsGladiator",JSON.stringify(c));localStorage.setItem("disabledTimeGladiator",JSON.stringify(e));localStorage.setItem("activeItemsMercenary",JSON.stringify(g));localStorage.setItem("disabledTimeMercenary",JSON.stringify(l))}function xj(b){if(!b||"string"!==typeof b||
!/\d/.test(b))return NaN;b=b.split(":").map(c=>parseInt(c,10));if(3===b.length){const [c,e,g]=b;return 1E3*(3600*c+60*e+g)}if(2===b.length){const [c,e]=b;return 1E3*(60*c+e)}return NaN}function nh(){let b=document.getElementById("nextActionWindow");if(!b){b=document.createElement("div");b.id="nextActionWindow";b.setAttribute("style",'\n            display: flex;\n            align-items: center;\n            justify-content: center;\n            position: absolute;\n            top: -3px;\n            left: 50%;\n            transform: translateX(-50%);\n            height: 50px;\n            width: 190px;\n            background: linear-gradient(\n              180deg,\n              #c4ac70 0%, \n              #e5d7a2 100%  \n            );\n            border: 2px solid #8b6b0b;\n            border-radius: 6px;\n            color: #2b2b2b;\n            font-family: "Georgia", "Times New Roman", serif; \n            font-size: 11px;\n            line-height: 1.2;\n            text-align: center;\n            z-index: 1999;\n          ');
const c=document.getElementById("header_game");c&&c.insertBefore(b,c.children[0])}return b}function oh(){var b=[];for(var c of yj)if(c.enabled){var e=Infinity;if(c.ml){var g=document.querySelector(c.ml);g&&(e=xj(g.innerText),e=isNaN(e)?0:e)}else if(g=localStorage.getItem("eventPoints.timeOut"))e=Number(g)-Date.now(),e=0<e?e:0;b.push({...c,timeLeft:e})}c=null;for(var l of b)if(!c||l.timeLeft<c.timeLeft)c=l;c?(Ka.N=c,Ka.wm=c.timeLeft,0>=c.timeLeft&&c.im()&&c.lm()&&console.debug(`[AutoClick] Performed action: ${c.name}`)):
(Ka.N=null,Ka.wm=0);Ka.km||(Ka.km=nh());!Ka.N||isNaN(Ka.wm)?Ka.km.innerHTML="\n        <span>Please select an action. [Exp|Dungeon|Arena|Circus]</span>":(b=Ka.wm,!b||1E3>b?b="0:00:00":(b=Math.round(b/1E3),l=b%60,c=Math.floor(b%3600/60),b=`${Math.floor(b/3600)}:${10>c?"0"+c:c}:${10>l?"0"+l:l}`),Ka.km.innerHTML=`
        <div style="text-align: center;">
          <div style="color: black; margin-bottom: 5px;">${d.N} ${d[Ka.N.name]||"Unknown Action"}</div>
          <div style="color: black; margin-bottom: 2px;">${d.nj}: ${b}</div>
        </div>
      `)}function jf(){let z4=localStorage.getItem("we");we=new Date(z4);if(aa?.player?.Ed<new Date||we<new Date)throw hb(),Error("SupportDevs");Ka.km=nh();oh();setInterval(oh,1E3)}const Ka={N:null,wm:0,km:null};(function(){if("true"===localStorage.getItem("disableBG")){var b=document.getElementById("wrapper_game");b&&(b.style.backgroundImage="none",b.style.backgroundColor="black")}let c=setTimeout(()=>{chrome.runtime.sendMessage({yq:!0})},1E4);window.onload=function(){clearTimeout(c);chrome.runtime.sendMessage({zq:!0})};let e=!1;document.addEventListener("touchstart",
function(l){function h(q){setTimeout(function(){var n=new MouseEvent("click",{bubbles:!0,cancelable:!0,view:window});q.dispatchEvent(n)},150)}var k=l.target;try{if("AuctionaddPrefixButton"==k.id||"AuctionaddSuffixButton"==k.id||"Strength"==k.htmlFor||"Dexterity"==k.htmlFor||"Agility"==k.htmlFor||"Constitution"==k.htmlFor||"Charisma"==k.htmlFor||"Intelligence"==k.htmlFor||"costumes_button_left"===k.offsetParent.id||"costumes_button_right"===k.offsetParent.id||"buy_rubies_link"===k.offsetParent.id||
"footer_inner"===k.offsetParent.id||"footer_logos"===k.offsetParent.id||"content"===k.id||"sidebar"===k.id||"char"===k.id||"a.menuitem.advanced_menu_link"==k.className||"a.menuitem.advanced_menu_link active"==k.className||"a.menuitem.advanced_menu_link active"==k.className||"menuitem"==k.className||"menuitem "==k.className||"menuitem advanced_menu_link"==k.className||"menuitem active advanced_menu_link_active"==k.className||"set_dungeon_difficulty_normal"!=k.id&&"set_dungeon_difficulty_advanced"!=
k.id&&"set_event_monster_id_0"!=k.id&&"set_event_monster_id_1"!=k.id&&"set_event_monster_id_2"!=k.id&&"set_event_monster_id_3"!=k.id&&"do_combat_quests"!=k.id&&"do_arena_quests"!=k.id&&"do_circus_quests"!=k.id&&"do_expedition_quests"!=k.id&&"do_dungeon_quests"!=k.id&&"do_items_quests"!=k.id&&"ConstitutionPriority"!=k.id&&"CharismaPriority"!=k.id&&"IntelligencePriority"!=k.id&&"StrengthPriority"!=k.id&&"DexterityPriority"!=k.id&&"AgilityPriority"!=k.id&&"shoes-image"!=k.className&&"ring1-image"!=k.className&&
"ring2-image"!=k.className&&"helmet-image"!=k.className&&"necklace-image"!=k.className&&"sword-image"!=k.className&&"chest-image"!=k.className&&"shield-image"!=k.className&&"gloves-image"!=k.className&&("div"==k.localName&&"overlayBack"!==k.id||"div"==k.localName&&"licotok"!==k.id))return}catch{}e||"checkbox"===k.type&&"switch"===k.className||(e=!0,h(k),"submit"!==k.type&&"checkbox"!==k.type&&"switch"!==k.className||l.preventDefault());e=!1},{passive:!1});try{chrome&&chrome.runtime&&chrome.runtime.sendMessage&&
"true"===sessionStorage.getItem("autoGoActive")&&(chrome.runtime.sendMessage({Hn:!0,Fm:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"}),chrome.runtime.sendMessage({keepAlive:!0},()=>{}));let l=localStorage.getItem("activeItemsMercenary"),h=localStorage.getItem("activeItemsGladiator");null!==l&&l!==JSON.stringify([])||localStorage.setItem("activeItemsMercenary",JSON.stringify({}));null!==h&&h!==JSON.stringify([])||localStorage.setItem("activeItemsGladiator",JSON.stringify({}));
chrome.runtime.onMessage.addListener(k=>{k.Hn&&k.Fm&&"true"===sessionStorage.getItem("autoGoActive")&&(k=new Audio(k.Fm),k.loop=!0,k.volume=0,k.play().catch(()=>{}))})}catch{console.log("Could not play the audio")}const g="true"===sessionStorage.getItem("autoGoActive")?!0:!1;(b=JSON.parse(localStorage.getItem("timeConditions"))||[],1>b.length)&&!window.location.href.includes("/index.php?mod=hermit&submod=travel")&&!window.location.href.includes("/index.php?mod=packages")&&!window.location.href.includes("/index.php?mod=forge")?
setTimeout(function(){g&&window.location.reload()},36E4):window.location.href.includes("/index.php?mod=hermit&submod=travel")||window.location.href.includes("/index.php?mod=packages")||window.location.href.includes("/index.php?mod=forge")?setTimeout(function(){g&&window.location.reload()},6E5):setTimeout(function(){g&&window.location.reload()},36E4)})();const zj={start(){const b=async()=>{const g=pb("gf-token-production");console.log("GF Token:",g);return g?{"Content-Type":"application/json",headers:{Hp:`Bearer ${g}`}}:
{}},c=async()=>{try{chrome.runtime.sendMessage({queryButtonClickedState:!0},async g=>{if(!g.state){g=(g=document.cookie.split("; ").find(n=>n.startsWith("gllastusername=")))?g.split("=")[1]:null;let k=null,q=null;g&&([k,q]=g.split("-"));g=[];try{var l=await (await fetch("/api/users/me/accounts",await b())).json();g=Array.isArray(l)?l:[]}catch(n){}g=g.sort((n,m)=>new Date(m.So)-new Date(n.So));l=null;k&&q&&(l=g.find(n=>n.name===k&&String(n.id)===q));!l&&0<g.length&&(l=g[0]);if(l){if(g=document.getElementById("accountlist")){g=
g.getElementsByClassName("rt-tr");for(var h of g){g=h.querySelector(".player-cell");const n=h.querySelector(".btn.btn-primary");if(g&&n&&g.textContent.trim()===l.name){n.click();sessionStorage.setItem("loggedIn","true");return}}}}else if(h=document.getElementById("accountlist"))if(h=h.getElementsByClassName("btn btn-primary"),h[0]){h[0].click();sessionStorage.setItem("loggedIn","true");return}sessionStorage.setItem("loggedIn","false")}})}catch(g){sessionStorage.setItem("loggedIn","false")}},e=async()=>
{chrome.runtime.sendMessage({action:"ctab"},g=>{if(!g||!g.gr){g=document.querySelectorAll(".registerForm");if(0<document.querySelectorAll(".loginRegister").length||0<g.length)return!1;window.location.href.includes("/accounts")?c():window.location.href="https://lobby.gladiatus.gameforge.com/en_GB/accounts"}})};(()=>{if(!window.location.href.includes("game/index.php")){const g=document.cookie.split("; ").find(h=>h.startsWith("glautologin=")),l=g?g.split("=")[1]:null;chrome.runtime.sendMessage({action:"ctab"},
h=>{h.gr||window.location.href.includes("forum.gladiatus")||!window.location.href.includes("lobby")||"true"!==l||setTimeout(e,3500)})}})();(()=>{var g=document.querySelectorAll('h1, h2, .error-code, h1[jstcache="0"], #main-frame-error');let l=!1;for(const h of g){g=h.textContent||"";if(g.includes("503")||g.includes("500")){l=!0;break}if("main-frame-error"===h.id||h.hasAttribute("jstcache")){l=!0;break}}l&&(console.warn("Error detected on page. Reloading..."),setTimeout(()=>{location.reload()},3E3))})()}};
window.location.href.includes("index.php?mod=overview&submod=achievements")||window.location.href.includes("index.php?mod=overview&submod=stats")||zj.start();const ph=localStorage.getItem("underworld"),Cb=ph?JSON.parse(ph):null,qh=document.querySelector('input[name="cancelTravel"]');try{document.querySelector("#header_LoginBonus")&&!qh&&Cb&&!window.location.href.includes("/index.php?mod=hermit")&&!1===Cb.isUnderworld&&document.querySelector("#linkLoginBonus").click()}catch{}let rh=document.getElementById("wrapper_game"),
kf=rh&&"underworld"===rh.className;if(kf){const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else{const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!1;localStorage.setItem("underworld",JSON.stringify(b))}try{if((window.location.href.includes("/index.php?mod=hermit&submod=travel")||qh||window.location.href.includes("/index.php?mod=hermit&submod=enterUnderworld"))&&"true"===sessionStorage.getItem("autoGoActive")&&
"true"===localStorage.getItem("autoEnterHell")){const b=document.querySelector('span[data-ticker-type="countdown"]');if(b){const c=parseInt(b.getAttribute("data-ticker-time-left"),10);await new Promise(e=>setTimeout(e,c-7E3||358E3))}else await new Promise(c=>setTimeout(c,3E5));Pf("mod=overview")}}catch(b){F(`Error in underworld wait: ${b.message}`)}let th="true"===localStorage.getItem("nestSearchType");"nothing"!==localStorage.getItem("nestSearchType")&&(th=!0);const Aj=localStorage.getItem("NestDelay")||
250;th&&window.location.href.includes("/index.php?mod=reports")&&await new Promise(b=>setTimeout(b,Aj));let lf=!0;const cb=new URL(window.location.href);let uh=document.createElement("style");uh.innerHTML="\n    #logMenu {\n      resize: vertical;\n      overflow: auto;\n      max-height: 500px;\n    }\n  ";document.head.appendChild(uh);let yf=null,zf=0;null===localStorage.getItem("HealClothToggle")&&localStorage.setItem("HealClothToggle","false");window.location.href.includes("mod=auction")&&U();
const oa=JSON.parse(localStorage.getItem("userStats"))||{Sm:0,Tm:0,Qm:0,Em:0,Hm:0,Km:0,Mm:0,Um:0,bn:0,om:0,pm:0};let gb;localStorage.getItem("playerId")&&Uh((localStorage.getItem("playerId")|0)%100|0);(function(){var b="true"===localStorage.getItem("MoveButtons");let c=document.createElement("button");c.className="menuitem breathing-light";c.innerHTML="GLDbot License";c.setAttribute("id","lico");c.addEventListener("click",Xh);b?((b=document.getElementById("lico"))&&b.remove(),c.style.position="fixed",
c.style.left="13px",c.style.bottom="60px",c.style.zIndex="1000",document.body.appendChild(c)):(b=document.getElementById("mainmenu"))&&b.children[0]&&b.insertBefore(c,b.children[0]);c=document.createElement("style");c.innerHTML = "\n        @keyframes breathing-light {\n            0%, 100% {\n                box-shadow: 0 0 11px 5px rgba(255, 255, 0, 0.7);\n            }\n            50% {\n                box-shadow: 0 0 11px 10px rgba(255, 255, 0, 0.5);\n            }\n        }\n    \n        .breathing-light {\n            animation: breathing-light 2s ease-in-out infinite;\n        }";document.head.appendChild(c)})();await async function(){var b="true"===localStorage.getItem("runNestDungeon");const c="true"===localStorage.getItem("runNestExpedition"),e="true"===localStorage.getItem("runNestEvent"),g="true"===localStorage.getItem("runNestUnderworld");var l=document.querySelector('span[data-ticker-type="countdown"]');
if(window.location.href.includes("/index.php?mod=reports")&&!l||window.location.href.includes("/index.php?mod=guildMarket")&&!l||window.location.href.includes("/index.php?mod=quests")&&!l){l=document.getElementById("blackoutDialog");var h=document.getElementById("blackoutDialognotification");const k=document.getElementById("blackoutDialogLoginBonus");if(null!==l&&"none"!==window.getComputedStyle(l).display){h=localStorage.getItem("nestSearchType");const q=document.querySelector("#blackoutDialog.loot-modal"),
n="true"===sessionStorage.getItem("autoGoActive");if(h&&q&&n&&((JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld&&g||N()&&b||V()&&e||O()&&c||!(b||e||c||g))){b=null;b=l.querySelectorAll(".action_buttons button");switch(h){case "quick":F("Quick Search clicked");b=b[1];break;case "thorough":F("Thorough Search clicked");b=b[2];break;case "nothing":F("Return to Safety clicked");b=b[0];break;default:F("Thorough Search clicked"),b=b[2]}b&&b.click()}}else null!==k&&Cb&&!1===Cb.isUnderworld?
setTimeout(()=>{k.getElementsByTagName("input")[0]?.click()},100):null!==h&&"none"!==window.getComputedStyle(h).display&&setTimeout(()=>{const q=document.getElementById("breakDiv");q&&q.click()},100)}}();if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll")){var mf=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),vb=mf.textContent.trim();if(2<vb.length){var nf=document.getElementById("char");
function b(e,g,l,h){if(null!==document.getElementById("container_start")){var k=window.location.href.split("p=")[1].split("&")[0],q=window.location.href.match(/s(\d+)-\w\w/),n=window.location.href.match(/s\d+-(\w\w)/);g={playerName:g,aType:h,opponentId:k,serverId:q?q[1]:null,country:n?n[1]:null};l=2===h?"arenacrosslist":"circuscrosslist";var m=2===h?"removeArenaList":"removeCircusList";q=JSON.parse(pb(l)||"[]");var r=JSON.parse(pb(m)||"[]");n=q.findIndex(v=>v.opponentId===k);var w=r.findIndex(v=>
v.opponentId===k);-1!==n?(q.splice(n,1),-1===w&&(r.push(g),ob(m,JSON.stringify(r),7)),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+(2===h?"Arena":"Circus"))):(q.push(g),-1!==w&&(r.splice(w,1),ob(m,JSON.stringify(r),7)),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+(2===h?"Arena":"Circus")));ob(l,JSON.stringify(q),7)}else q=JSON.parse(localStorage.getItem(l))||[],n=q.indexOf(g),-1!==n?(q.splice(n,1),e.classList.remove("added"),e.setAttribute("data-tooltip",
"Add to "+("autoAttackList"===l?"Arena":"Circus"))):(q.push(g),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+("autoAttackList"===l?"Arena":"Circus"))),localStorage.setItem(l,JSON.stringify(q))}function c(e,g,l,h,k){var q=document.createElement("a");q.className="gladbot-button gladbot-"+e;q.textContent=g;q.setAttribute("data-tooltip",l);nf.appendChild(q);(JSON.parse(localStorage.getItem(h))||[]).includes(vb)&&(q.classList.add("added"),q.setAttribute("data-tooltip","Remove from "+
("autoAttackList"===h?"Arena":"Circus")));q.addEventListener("click",function(){b(q,vb,h,k)})}c("arena","A","GladB: Add to Arena List","autoAttackList",2);c("circus","C","GladB: Add to Circus List","autoAttackCircusList",3)}}const Bj=localStorage.getItem("Username"),ya=localStorage.getItem("pid"),idkps=localStorage.getItem("idkps");let Cj=localStorage.getItem("tkz_lcr");const Dj=localStorage.getItem("tkn"),Cf=await cc(Cj,Dj,ya,Bj);window.location.href.includes("/index.php?mod")&&sessionStorage.setItem("loggedIn","false");if(window.location.href.includes("/index.php?mod=overview")){const b=
[3,4,5,2,9,10,6,7,11],c=[1,2,4,8,48,256,512,1024];Yh();(function(){const l={dbfa266e60c28ce109de4d9c216a2a:"Health - Gingko Leaves","25925f7ce7c04483a3b4527846c04b":"Health - Taigaroot","79e62e1e04445d354bcc955bb8baeb":"Health - Hawthorn","93820f465cb02d5d8828ee9a14f5fe":"Charisma - Flask",b5e7e6f2cd2ea3d86143894e5f9ade:"Charisma - Flacon",ddd6bc43a13d444409087b99b9f142:"Charisma - Ampulla","37fc8feb4ead7f2e59c026af4228b3":"Charisma - Bottle","00ef972a002dc3040447e5cc0eb77d":"Dexterity - Ampulla",
"43ac2597d30a099dd7033273ac29c1":"Dexterity - Flask","352a093dc497a9ec659f217dc7d374":"Dexterity - Flacon","967321edb226ea075ac63acc701eea":"Dexterity - Bottle",bd48bef94e6d066a8bfef716dd959a:"Constitution - Ampulla",ce03a66b17f81394722a3fc2335a1d:"Constitution - Flacon",ee80ae69b48ebbeb81e52c20113709:"Constitution - Flask","5368deb7929c8853843b420fb439ac":"Constitution - Bottle",b306d3f65b14cb91c0f0c9de871e0a:"Strength - Flask","2e8f9fc0f9b101f7ba49152cbe9779":"Strength - Flacon",ce6fe5171b946cd26d5b21e87efb5d:"Strength - Ampulla",
"1c344cf484e5a87731eaf906ffd993":"Strength - Bottle","887d1152e2f7cba339a0a4675b3b5e":"Agility - Flask","453199ebfb25d62f83af27b0187088":"Agility - Ampulla","3b52078b78637bd54fed2e4cfb951b":"Agility - Flacon",d2df53b4e64ad33dc301b6bf125fd2:"Agility - Bottle",a2ef931eff7cce75e07baa9ae2ac97:"Intelligence - Flacon","48331278d1b0391f74ba54b4cac6d4":"Intelligence - Ampulla","2bf8795edae428b4646f8d6fd6dc4c":"Intelligence - Flask","8971734256abbbe0fea2bb40721953":"Intelligence - Bottle"},h=document.querySelectorAll("#buffbar_old .buff_inner");
let k=JSON.parse(localStorage.getItem("buffs"))||{},q=new Set;h.forEach(n=>{var m=n.querySelector("img");m=(m=m?m.getAttribute("src"):null)?m.split("/").pop().split(".")[0]:null;if(m=l[m])if(n=(n=n.parentElement.querySelector(".ticker"))?n.getAttribute("data-ticker-time-left"):null)k[m]={timeLeft:Math.round(Number(n)/6E4)},q.add(m)});Object.keys(k).forEach(n=>{q.has(n)||delete k[n]});localStorage.setItem("buffs",JSON.stringify(k))})();const e=document.getElementById("char");if(e){const l=document.createElement("button"),
h=document.createElement("span");l.textContent="\u21d3";l.className="put-down awesome-button";l.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 170px; font-size: 12px; cursor: pointer;";l.classList.add("tooltip");l.appendChild(h);l.onclick=async function(){let n=Array.from(document.querySelectorAll("#char .ui-droppable")).filter(m=>b.includes(parseInt(m.dataset.containerNumber,10)||"0"));for(let m=0;m<n.length;m++)await new Promise(r=>setTimeout(r,100)),fa(n[m],"inv");await new Promise(m=>
setTimeout(m,500))};e.appendChild(l);const k=document.createElement("button"),q=document.createElement("span");k.textContent="\u21d1";k.className="put-up awesome-button";k.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 192px; font-size: 12px; cursor: pointer;";k.classList.add("tooltip");k.appendChild(q);k.onclick=async function(){let n=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(m=>c.includes(parseInt(m.dataset.contentType,10)));for(let m=0;m<n.length;m++)await new Promise(r=>
setTimeout(r,100)),fa(n[m],"char");await new Promise(m=>setTimeout(m,500))};e.appendChild(k)}if(document.getElementById("inv")){async function l(n,m,r,w,v,y){n=T({mod:"inventory",submod:"move",from:y,fromX:m+1,fromY:r+1,to:y,toX:w+1,toY:v+1,amount:n.dataset.amount||1,doll:1,a:(new Date).getTime(),sh:W("sh")});await fetch(n,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(D=>D.text())}const h=document.createElement("button");
h.id="sort-button";h.textContent="Sort Inventory";h.className="sort-button awesome-button";h.style="padding: 5px; margin: 5px; cursor: pointer;";const k=document.createElement("span");k.id="loading-indicator";k.style="margin-left: 10px; display: none;";const q=document.querySelector(".contentItem");q&&(q.insertAdjacentElement("afterend",h),h.insertAdjacentElement("afterend",k));h.addEventListener("click",async function(){function n(E,t,u){for(let A=0;5>A;A++)for(let B=0;8>B;B++)if(!v[A][B]){let H=
!0;for(let G=A;G<A+t&&H;G++)for(let K=B;K<B+E;K++)if(5<=G||8<=K||v[G][K])H=!1;if(H){if(u){E=[{x:B-1,y:A},{x:B+E,y:A},{x:B,y:A-1},{x:B,y:A+t}];for(const G of E)if(0<=G.x&&8>G.x&&0<=G.y&&5>G.y&&w.find(K=>{const L=parseInt(K.style.top,10)/32;return parseInt(K.style.left,10)/32===G.x&&L===G.y&&K.dataset.basis.split("-")[0]===u}))break}return{x:B,y:A}}}return null}var m=document.getElementById("inv");document.getElementById("sort-button");var r=document.getElementById("loading-indicator");r.textContent=
"Sorting...";r.style.display="inline-block";const w=Array.from(m.getElementsByClassName("ui-draggable"));w.sort((E,t)=>{const u=parseInt(E.dataset.basis.split("-")[0],10)||0,A=parseInt(t.dataset.basis.split("-")[0],10)||0;return u!==A?u-A:(parseInt(E.dataset.measurementX,10)*parseInt(E.dataset.measurementY,10)||1)-(parseInt(t.dataset.measurementX,10)*parseInt(t.dataset.measurementY,10)||1)});const v=Array.from({length:5},()=>Array(8).fill(!1));w.forEach(E=>{const t=parseInt(E.style.left,10)/32,u=
parseInt(E.style.top,10)/32,A=parseInt(E.dataset.measurementX,10);E=parseInt(E.dataset.measurementY,10);for(let B=u;B<u+E;B++)for(let H=t;H<t+A;H++)v[B][H]=!0});for(m=0;m<w.length;m++){var y=w[m];r=parseInt(y.dataset.measurementX,10);const E=parseInt(y.dataset.measurementY,10);var D=y.dataset.basis.split("-")[0];const t=parseInt(y.style.left,10)/32,u=parseInt(y.style.top,10)/32;var C=n(r,E,D);if(C&&(D=C.x,C=C.y,t!==D||u!==C)){await l(y,t,u,D,C,y.dataset.containerNumber);for(y=C;y<C+E;y++)for(let A=
D;A<D+r;A++)v[y][A]=!0;for(D=u;D<u+E;D++)for(y=t;y<t+r;y++)v[D][y]=!1}}window.location.reload()})}const g=JSON.parse(localStorage.getItem("underworld"))||{};try{const l=document.querySelector("#avatar .ui-droppable");if(l){const h=l.getAttribute("data-tooltip");h&&h.toLowerCase().includes("pater")?(g.oj=!0,localStorage.setItem("underworld",JSON.stringify(g)),Y("CheckDolls",15)):(g.oj=!1,localStorage.setItem("underworld",JSON.stringify(g)))}}catch{}}let Qc=localStorage.getItem("playerId");gc();let ub=
!1,ta="true"===sessionStorage.getItem("autoGoActive")?!0:!1,da;try{da={level:parseInt(document.getElementById("header_values_level").innerText,10)||50,o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,""))}}catch(b){da={level:50}}const db=document.createElement("div");db.style.position="fixed";db.style.right="10px";db.style.top="50px";db.style.zIndex="99999";document.body.appendChild(db);const ra=document.createElement("div");ra.id=
"logMenu";ra.style.width="190px";ra.style.height="210px";ra.style.overflowY="hidden";ra.style.backgroundColor="rgba(221, 213, 180, 0.8)";ra.style.border="1px solid #c4ac70";ra.style.borderRadius="10px";ra.style.fontFamily="Arial, sans-serif";ra.style.color="#333";db.appendChild(ra);const eb=document.createElement("h2");eb.textContent="Log Menu";eb.style.backgroundColor="rgba(196, 172, 112, 0.8)";eb.style.color="#333";eb.style.margin="0";eb.style.padding="10px 20px";eb.style.borderTopLeftRadius="10px";
eb.style.borderTopRightRadius="10px";ra.appendChild(eb);const Db=document.createElement("div");Db.id="logEntriesContainer";Db.style.color="#bfae54";Db.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";Db.style.overflowY="scroll";Db.style.height="calc(100% - 60px)";Db.style.padding="10px 20px";ra.appendChild(Db);const Oa=document.createElement("div");Oa.style.display="flex";Oa.style.justifyContent="space-between";Oa.style.marginTop="10px";Oa.style.top="calc(300px + 10px)";Oa.style.width="155px";Oa.style.padding="0 10px";Oa.style.zIndex="99999";Oa.style.left="0";db.appendChild(Oa);
const La=document.createElement("button");La.id="clearLogsButton";La.textContent="Clear Logs";Rc(La,"rgba(221, 213, 180, 0.8)");Oa.appendChild(La);La.addEventListener("click",function(){const b=document.querySelector("#logMenu");if(b){for(;b.firstChild;)b.removeChild(b.firstChild);localStorage.removeItem("savedLogs")}});const Wb=document.createElement("button");Wb.id="resetBOT";Wb.textContent="Reset Bot";Rc(Wb,"rgba(221, 213, 180, 0.8)");Oa.appendChild(Wb);Wb.addEventListener("click",function(){za()});
const Pa=document.createElement("button");Pa.textContent="Sort Logs";Rc(Pa,"rgba(221, 213, 180, 0.8)");Oa.appendChild(Pa);Pa.addEventListener("click",function(){let b=localStorage.getItem("savedLogs");if(b){b=JSON.parse(b);b.sort((e,g)=>{e=e.split(" ")[0];g=g.split(" ")[0];return lf?e.localeCompare(g):g.localeCompare(e)});lf=!lf;for(var c=document.querySelector("#logMenu");c.firstChild;)c.removeChild(c.firstChild);for(let e of b){const g=document.createElement("p");g.style.margin="0";g.style.padding=
"0";g.style.fontSize="12px";g.textContent=e;c.appendChild(g)}localStorage.setItem("savedLogs",JSON.stringify(b))}});ra.style.transition="height 0.1s ease";const vh=localStorage.getItem("logMenuVisible"),wh="true"===localStorage.getItem("disableLogMenu");null===vh?localStorage.setItem("logMenuVisible","true"):1==wh?(ra.style.display="none;",ra.style.height="0px",ra.style.width="0px",ra.style.border="0px",La.style.display="none",La.style.height="0px",La.style.width="0px",La.style.border="0px",Pa.style.display=
"none",Pa.style.height="0px",Pa.style.width="0px",Pa.style.border="0px"):"true"===vh?localStorage.getItem("logMenuHeight"):ra.style.height="38px";window.location.href.includes("/hub")&&(ra.style.display="none;",ra.style.height="0px",ra.style.width="0px",ra.style.border="0px",La.style.display="none",La.style.height="0px",La.style.width="0px",La.style.border="0px",Pa.style.display="none",Pa.style.height="0px",Pa.style.width="0px",Pa.style.border="0px");eb.addEventListener("click",function(){if("38px"!==
ra.style.height)ra.style.height="38px",localStorage.setItem("logMenuVisible","false");else{const b=localStorage.getItem("logMenuHeight")||"210px";ra.style.height=b;localStorage.setItem("logMenuVisible","true")}});ra.addEventListener("resize",Df);"38px"!==ra.style.height&&Df();if(Pc()){const b="true"===localStorage.getItem("MoveButtons");let c=document.getElementById("mainmenu"),e=document.createElement("button");e.id="autoGoButton";e.className="customButton";e.innerHTML=`<span style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;">${ta?
"&#9724;":"&#9658;"}</span>`;e.addEventListener("click",ta?Hf:pt);let g=document.createElement("button");g.className="customButton2";g.innerHTML='<span style="position: relative; top: -12px;">&#9881;</span>';g.addEventListener("click",lc);b?(g.style.position="fixed",g.style.bottom="10px",g.style.left="10px",g.style.zIndex="1000",e.style.position="fixed",e.style.bottom="10px",e.style.left="105px",e.style.zIndex="1000",document.body.appendChild(g),document.body.appendChild(e)):c&&(c.insertBefore(g,
c.children[0]),c.insertBefore(e,c.children[1]))}else return hb(),!1;(function(){try{if("mod=arena&submod=serverArena&aType=2"==tf||"mod=arena&submod=serverArena&aType=3"==tf){let k=JSON.parse(localStorage.getItem("autoAttackList"))||[],q=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],n=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[],m=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[],r=JSON.parse(localStorage.getItem("avoidAttackList"))||[],w=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||
[],v=[...k,...q,...n,...m].map(C=>{if(!C)return"";if("string"!==typeof C)if("object"===typeof C&&C.playerName)C=C.playerName;else return"";return C.trim().toLowerCase()}).filter(C=>""!==C),y=[...r,...w].map(C=>{if(!C)return"";if("string"!==typeof C)if("object"===typeof C&&C.playerName)C=C.playerName;else return"";return C.trim().toLowerCase()}).filter(C=>""!==C);const D=(new URLSearchParams(window.location.search)).get("aType");Array.from(document.querySelectorAll("2"===D?"#own2 tr":"#own3 tr")).forEach(C=>
{if(C=C.querySelector("a")){var E=C.innerText.trim().toLowerCase();const t=v.includes(E);E=y.includes(E);t&&(C.style.color="orange",C.style.fontWeight="bold",C.style.textShadow="1px 1px 2px #000000");E&&(C.style.color="red",C.style.fontWeight="bold",C.style.textShadow="1px 1px 2px #000000",C.style.textDecoration="line-through")}})}var b=JSON.parse(pb("arenacrosslist")||"[]"),c=JSON.parse(pb("circuscrosslist")||"[]"),e=JSON.parse(pb("removeArenaList")||"[]"),g=JSON.parse(pb("removeCircusList")||"[]"),
l=JSON.parse(localStorage.getItem("autoAttackServerList")||"[]"),h=JSON.parse(localStorage.getItem("autoAttackCircusServerList")||"[]");0<b.length&&(b.forEach(k=>{l.some(q=>q.opponentId===k.opponentId)||l.push(k)}),localStorage.setItem("autoAttackServerList",JSON.stringify(l)),ob("arenacrosslist",JSON.stringify([]),7));0<c.length&&(c.forEach(k=>{h.some(q=>q.opponentId===k.opponentId)||h.push(k)}),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(h)),ob("circuscrosslist",JSON.stringify([]),
7));if(0<e.length||0<g.length)l=l.filter(k=>!e.some(q=>q.opponentId===k.opponentId)),h=h.filter(k=>!g.some(q=>q.opponentId===k.opponentId)),localStorage.setItem("autoAttackServerList",JSON.stringify(l)),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(h)),ob("removeArenaList",JSON.stringify([]),7),ob("removeCircusList",JSON.stringify([]),7)}catch(k){F("Something is wrong with HandlePlayers"+k)}})();"mod=overview"==tf&&Zh();if("mod=location"!==tf&&"mod=arena"!==tf&&0==localStorage.getItem("eventPoints_")){const b=
document.getElementById("ServerQuestTime");if(b){const c=b.querySelector("span");c&&localStorage.setItem("eventPoints_",c.textContent)}}let Sa=!0;localStorage.getItem("doQuests")&&(Sa="true"===localStorage.getItem("doQuests")?!0:!1);let Na={combat:!0,arena:!0,circus:!0,expedition:!0,dungeon:!0,items:!0};localStorage.getItem("questTypes")&&(Na=JSON.parse(localStorage.getItem("questTypes")));let Xb=0;localStorage.getItem("nextQuestTime")&&(Xb=Number(localStorage.getItem("nextQuestTime")));let Fa=!0;
localStorage.getItem("doExpedition")&&(Fa="true"===localStorage.getItem("doExpedition")?!0:!1);let Xc=0;localStorage.getItem("monsterId")&&(Xc=Number(localStorage.getItem("monsterId")));let Ga=!0;localStorage.getItem("doDungeon")&&(Ga="true"===localStorage.getItem("doDungeon")?!0:!1,kf&&(Ga=!1));10>da.level&&(Ga=!1);let Kb="advanced"===localStorage.getItem("dungeonDifficulty")?"advanced":"normal",Ha=!0;localStorage.getItem("doArena")&&(Ha="true"===localStorage.getItem("doArena")?!0:!1,kf&&"false"===
localStorage.getItem("EnableArenaHell")&&(Ha=!1));2>da.level&&(Ha=!1);let If="min";localStorage.getItem("arenaOpponentLevel")&&(If=localStorage.getItem("arenaOpponentLevel"));let Ma=!0;localStorage.getItem("doCircus")&&(Ma="true"===localStorage.getItem("doCircus")?!0:!1);10>da.level&&(Ma=!1);let Jf="min";localStorage.getItem("circusOpponentLevel")&&(Jf=localStorage.getItem("circusOpponentLevel"));let Ia=!0;localStorage.getItem("doEventExpedition")&&(Ia="true"===localStorage.getItem("doEventExpedition")?
!0:!1);try{document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0]||(Ia=!1)}catch{}let mc=0;localStorage.getItem("eventMonsterId")&&(mc=Number(localStorage.getItem("eventMonsterId")));let ib=!1;localStorage.getItem("AutoAuction")&&(ib="true"===localStorage.getItem("AutoAuction")?!0:!1);localStorage.getItem("DoOther")&&localStorage.getItem("DoOther");let rb=!1;localStorage.getItem("doKasa")&&(rb="true"===localStorage.getItem("doKasa")?!0:!1);const yj=[{name:"expedition",enabled:Fa,
ml:"#cooldown_bar_text_expedition",im:()=>{var b=document.getElementById("cooldown_bar_expedition");return b&&"none"!==b.style.display?(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):!1},lm:()=>{var b=document.getElementById("cooldown_bar_expedition");if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&b.click();return!!b}},{name:"dungeon",enabled:Ga,ml:"#cooldown_bar_text_dungeon",im:()=>{var b=document.getElementById("cooldown_bar_dungeon");return b&&"none"!==b.style.display?
(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):!1},lm:()=>{var b=document.getElementById("cooldown_bar_dungeon");if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&b.click();return!!b}},{name:"arena",enabled:Ha,ml:"#cooldown_bar_text_arena",im:()=>{var b=document.getElementById("cooldown_bar_arena");return b&&"none"!==b.style.display?(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):!1},lm:()=>{var b=document.getElementById("cooldown_bar_arena");
if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&b.click();return!!b}},{name:"circusTurma",enabled:Ma,ml:"#cooldown_bar_text_ct",im:()=>{var b=document.getElementById("cooldown_bar_ct");return b&&"none"!==b.style.display?(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):!1},lm:()=>{var b=document.getElementById("cooldown_bar_ct");if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&b.click();return!!b}},{name:"eventExpedition",enabled:Ia,ml:null,im:()=>Ia&&vf("eventPoints")&&
da.o>(Number(localStorage.getItem("healPercentage"))||25),lm:()=>{try{const b=document.getElementById("submenu2")?.getElementsByClassName("menuitem glow")[0];if(b)return b.click(),!0}catch(b){}return!1}}];let d;switch(localStorage.getItem("settings.language")){case "EN":d={...Mh};break;case "PL":d={...Nh};break;case "ES":d={...Oh};break;case "TR":d={...Ph};break;case "FR":d={...Qh};break;case "HG":d={...Rh};break;case "BR":d={...Sh};break;default:d={...Mh}}let z1=localStorage.getItem("we");we=new Date(z1);if(!window.location.href.includes("lobby")&&
aa.player.Ed<new Date&&we<new Date)sessionStorage.setItem("autoGoActive","false"),hb();else{if("true"===localStorage.getItem("activateAuction2")){function b(n){n.style.position="flex";n.style.width="150px";n.style.marginLeft="8px";n.style.marginTop="10px";n.style.height="16px";n.style.backgroundColor="rgba(221, 213, 180, 0.8)";n.style.border="1px solid #c4ac70";n.style.padding="10px";n.style.borderRadius="10px";n.style.fontFamily="Arial, sans-serif";n.style.color="#333";n.style.textAlign="center";n.style.zIndex=
"1000"}const c=document.createElement("div");c.id="auctionMPopup";b(c,"calc(55px + 200px + 100px + 10px + 10px + -5px)");c.addEventListener("click",async()=>{Pf("mod=auction&ttype=3")});const e=document.createElement("div");e.id="auctionPopup";b(e,"calc(100px + 200px + 100px + 10px)");e.addEventListener("click",async()=>{Pf("mod=auction")});function g(n,m){return`${m}: ${[d.ac,d.Cb,d.Kb,d.Yb,d.bc][n]||"Unknown"}`}const l=document.createElement("h3"),h=document.createElement("h3");db.appendChild(e);
db.appendChild(c);const k=localStorage.getItem("auctionStatus"),q=localStorage.getItem("auctionMStatus");null!==k?(l.textContent=g(parseInt(k,10),"Gladiator"),e.appendChild(l),e.style.display="block"):e.style.display="none";null!==q?(h.textContent=g(parseInt(q,10),"Mercenary"),c.appendChild(h),c.style.display="block"):c.style.display="none";wh&&(e.style.display="none",e.style.height="0px",c.style.display="none",c.style.height="0px")}var Cc=localStorage.getItem("savedLogs");Cc&&(Cc=JSON.parse(Cc),
Cc.forEach(b=>{const c=document.createElement("p");c.style.margin="0";c.style.padding="0";c.style.fontSize="12px";c.textContent=b;Db.appendChild(c)}));var Aa={async start(){return new Promise(()=>{Aa.sl=Jh().gold;Aa.form=document.querySelectorAll("#auction_table form");Aa.I=[];const b=localStorage.getItem("auctiongladiatorenable"),c=localStorage.getItem("auctionmercenaryenable"),e=localStorage.getItem("bidFood"),g=localStorage.getItem("bidStatus"),l=localStorage.getItem("auctionStatus"),h=localStorage.getItem("auctionMStatus"),
k=localStorage.getItem("auctionminlevel")||0;let q="true"===localStorage.getItem("enableMercenarySearch");const n=JSON.parse(localStorage.getItem("Timers")),m=async(w,v)=>{try{F(`${d.xf}`);const y=await (await fetch(w)).text(),D=(new DOMParser).parseFromString(y,"text/html");await Aa.lo(D);0<Aa.I.length?(F(`${d.yf}`),"auction"===v?await Aa.jn(2,Aa.I.length):await Aa.jn(3,Aa.I.length)):("auction"===v?Y("auction",n.AuctionCheck||10):Y("auctionM",n.AuctionCheck||10),window.location.reload());1!=localStorage.getItem("AuctionTurbo")&&
Y("AuctionEmpty",1)}catch(y){window.location.reload()}},r=async()=>{var w=JSON.parse(localStorage.getItem("auctionPrefixes"))||[];let v=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],y;var D=(new URL(window.location.href)).origin;try{1===w.length?y=bc(w[0]):1===v.length&&(y=bc(v[0]))}catch(C){y=""}if(q&&Number(l)>=Number(g)&&vf("auction")||"true"==e&&Number(l)>=Number(g)&&vf("auction"))tf!=`mod=auction&itemType=0&itemLevel=${k}`&&(D=`${D}/game/index.php?mod=auction&itemType=0&itemLevel=${k}&sh=${W("sh")}`,
m(D,"auction"));else if((1==w.length||1==v.length)&&"true"==b&&Number(l)>=Number(g)&&"false"==e&&vf("auction"))w=`mod=auction&qry=${encodeURIComponent(y)}&itemType=0&itemLevel=${k}`,tf!==w&&(D=`${D}/game/index.php?${w}&sh=${W("sh")}`,m(D,"auction"));else if(q&&Number(l)>=Number(g)&&"true"==e&&vf("auction"))tf!=`mod=auction&itemType=0&itemLevel=${k}`&&(D=`${D}/game/index.php?mod=auction&itemType=0&itemLevel=${k}&sh=${W("sh")}`,m(D,"auction"));else if((1==w.length||1==v.length)&&"true"==c&&Number(h)>=
Number(g)&&"false"==e&&vf("auctionM"))tf!=`mod=auction&qry=${encodeURIComponent(y)}&itemType=0&ttype=3&itemLevel=${k}`&&(D=`${D}/game/index.php?mod=auction&qry=${y}&itemType=0&ttype=3&itemLevel=${k}&sh=${W("sh")}`,m(D,"auctionM"));else if(("true"===b||"true"===e)&&!q&&Number(l)>=Number(g)&&vf("auction"))if("true"===e&&1>w.length&&1>v.length)tf!=`mod=auction&itemType=7&itemLevel=${k}`&&(D=`${D}/game/index.php?mod=auction&itemType=7&itemLevel=${k}&sh=${W("sh")}`,m(D,"auction"));else{if(("true"===b||
"true"===e)&&!q&&Number(l)>=Number(g)&&vf("auction"))if("true"===e&&"false"===b&&(0<w.length||0<v.length))tf!=`mod=auction&itemType=7&itemLevel=${k}`&&(D=`${D}/game/index.php?mod=auction&itemType=7&itemLevel=${k}&sh=${W("sh")}`,m(D,"auction"));else if("true"===e&&(0<w.length||0<v.length))tf!=`mod=auction&itemType=0&itemLevel=${k}`&&(D=`${D}/game/index.php?mod=auction&itemType=0&itemLevel=${k}&sh=${W("sh")}`,m(D,"auction"));else if(tf!=`mod=auction&itemType=0&itemLevel=${k}`&&0<w.length||tf!=`mod=auction&itemType=0&itemLevel=${k}`&&
0<v.length)D=`${D}/game/index.php?mod=auction&itemType=0&itemLevel=${k}&sh=${W("sh")}`,m(D,"auction")}else if("true"==c&&Number(h)>=Number(g)&&(0<w.length||0<v.length)&&vf("auctionM")){if(tf!=`mod=auction&itemType=0&ttype=3&itemLevel=${k}`&&0<w.length||tf!=`mod=auction&itemType=0&ttype=3&itemLevel=${k}`&&0<v.length)D=`${D}/game/index.php?mod=auction&itemType=0&ttype=3&itemLevel=${k}&sh=${W("sh")}`,m(D,"auctionM")}else q?tf!=`mod=auction&itemType=15&itemLevel=${k}`&&(D=`${D}/game/index.php?mod=auction&itemType=15&itemLevel=${k}&sh=${W("sh")}`,
m(D,"auction")):setTimeout(r,3E3)};r()})},ko(b){const c="true"===localStorage.getItem("AuctionCover");b=b.querySelector("span");if(!b||!b.getAttribute("style"))return!0;b=b.getAttribute("style");return c&&b.includes("green")?!1:!c&&b.includes("green")?!0:b.includes("blue")?!1:!0},async lo(b){this.form=b.querySelectorAll("#auction_table form");for(let e of this.form){var c=e.querySelector(".auction_bid_div");b=e.querySelector(".ui-draggable");let g=c.querySelector("input").value;c=this.ko(c);let l=
Ib(b),h=xb(b),k=JSON.parse(localStorage.getItem("equipmentSelection")||"[]"),q=localStorage.getItem("maximumBid"),n=localStorage.getItem("auctiongladiatorenable"),m=localStorage.getItem("auctionmercenaryenable"),r=Ca(b),w=localStorage.getItem("auctionMinQuality")||0,v=localStorage.getItem("bidFood"),y=parseInt(Ra(b).split("-")[0],10),D=15==y?parseInt(b.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,C=15==y?parseInt(b.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):
0,E=15==y?parseInt(b.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],10):0,t=!1,u="true"===localStorage.getItem("enableMercenarySearch"),A=parseInt(localStorage.getItem("minDexterity"),10)||0,B=parseInt(localStorage.getItem("minAgility"),10)||0,H=parseInt(localStorage.getItem("minIntelligence"),10)||0,G=!1,K=!1,L,M,Z;Z=localStorage.getItem("ignorePS")||"false";L=JSON.parse(localStorage.getItem("auctionPrefixes")||"[]");M=JSON.parse(localStorage.getItem("auctionSuffixes")||"[]");L.some(ba=>
l.toLowerCase().includes(ba.toLowerCase())?G=!0:!1);M.some(ba=>{let ha=l.toLowerCase();ba=ba.toLowerCase();return ha.endsWith(" "+ba)||ha===ba?K=!0:!1});if("true"===Z){if(G||K)t=!0}else if(G&&K||G&&0===M.length||K&&0===L.length)t=!0;"string"===typeof h&&(h=[h]);null==w&&(w=5);t=t&&0===k.length||t&&k.includes("9999")||t&&k.some(ba=>h.includes(ba))?!0:!1;"true"===v&&7==y&&g<da.gold&&(t=!0);if(Number(r)<w){if("true"!==v||7!=y)t=!1}else"true"===v&&7==y&&(t=!0);"false"!==n||"false"!==m||"true"===v&&7==
y||(t=!1);1E3>da.gold&&(Y("AuctionEmpty",1),Y("AuctionMEmpty",1));l.includes("Samnit")||l.includes("Thracian");c&&u&&Number(r)>=Number(w)&&15==y&&Number(g)<Number(q)&&(0==A||D>=A)&&(0==B||C>=B)&&(0==H||E>=H)&&(t=!0);t&&c&&Number(g)<Number(q)&&this.I.push([{itemLevel:yb(b),itemName:l,basis:Ra(b),quality:Ca(b),price:g},g,e.getAttribute("action"),{auctionid:e.querySelector("input[name=auctionid]").value,qry:e.querySelector("input[name=qry]").value,itemType:e.querySelector("input[name=itemType]").value,
itemLevel:e.querySelector("input[name=itemLevel]").value,itemQuality:e.querySelector("input[name=itemQuality]").value,buyouthd:e.querySelector("input[name=buyouthd]").value,bid_amount:g,bid:e.querySelector("input[name=bid]").value}])}},async jn(b){async function c(l){if(Number(l[1])>Aa.sl)throw Error("Not enough gold");Aa.sl-=Number(l[1]);var h=new URLSearchParams({...l[3],csrf_token:x()});(await fetch(l[2],{method:"POST",credentials:"include",body:h})).ok&&(h=JSON.parse(localStorage.getItem("bidList"))||
[],h.push(l[0].itemName),localStorage.setItem("bidList",JSON.stringify(h)))}async function e(){for(;0<Aa.I.length;){const l=Aa.I.splice(0,3).map(h=>c(h));try{await Promise.all(l)}catch(h){"Not enough gold"===h.message&&(2===b?(Y("AuctionEmpty",1),Y("auction",g.AuctionCheck||10)):(Y("AuctionMEmpty",1),Y("auctionM",g.AuctionCheck||10)))}await new Promise(h=>setTimeout(h,500))}}localStorage.getItem("auctionStatus");localStorage.getItem("auctionMStatus");const g=JSON.parse(localStorage.getItem("Timers"));
if(Aa.I&&0!==Aa.I.length)try{await e()}finally{Y("AuctionEmpty",1),Y("AuctionMEmpty",1),window.location.reload()}else Y("AuctionEmpty",1),Y("AuctionMEmpty",1),window.location.reload()}},la={bag:null,g:null,Gn:null,Jq:localStorage.getItem("smeltIgnorePS"),async start(){var b="true"===localStorage.getItem("RepairBeforeSmelt"),c="513";c=(c=localStorage.getItem("smeltTab"))?(513+parseInt(c,10)).toString():"513";c=document.querySelector(`[data-bag-number="${c}"]`);if("mod=forge&submod=smeltery"!=tf)Pf("mod=forge&submod=smeltery");
else if(c.classList.contains("current")&&wf()){this.slots=await this.u();const e=this.slots.filter(h=>"closed"===h["forge_slots.state"]);this.Ym(this.slots);await this.Gm(this.slots);const g=JSON.parse(localStorage.getItem("Timers")),l="true"===localStorage.getItem("smelteverything3");c="true"===localStorage.getItem("smeltAnything")?this.Mo():"true"===localStorage.getItem("smelteverything3")?this.No():this.Lo();if(0<c.length){for(let {id:h,slot:k,hammerState:q}of c)try{if(b){const n=await Ej.gp(h);
if(n&&0!=n)try{await la.xm(k,n,q,h)}catch{await la.xm(k,h,q,h)}else await la.xm(k,h,q,h)}else await la.xm(k,h,q,h)}catch(n){}F("Smelting completed. Reloading page");b=JSON.parse(localStorage.getItem("Timers"));Y("smelt",b.SmeltingNoItem||10);window.location.reload()}else 1>c.length&&1==l?(F("No items to smelt, reloading page"),Y("smelt",g.SmeltingNoItem||10),window.location.reload()):0<e.length?await this.pickItems():0<e.length&&"true"===localStorage.getItem("smelteverything3")?la.move():(F("No free slots, reloading page"),
Y("smelt",g.SmeltingNoItem||10),window.location.reload())}else c.click(),wf(()=>this.start())},ep(b,c){b=JSON.parse(localStorage.getItem("smeltedItems"))||[];b.push(c);localStorage.setItem("smeltedItems",JSON.stringify(b))},Lo(){const b=this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let g of c){if(c=this.tm(g)){let l=b.shift();void 0!==l&&e.push({id:g.getAttribute("data-item-id"),
slot:l,hammerState:c.hammerState||"none",matchingRule:c})}if(0===b.length)break}return e},Mo(){const b=this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let g of c){if(c=this.tm(g)){let l=b.shift();void 0!==l&&e.push({id:g.getAttribute("data-item-id"),slot:l,hammerState:c.hammerState||"none",matchingRule:c})}if(0===b.length)break}return e},No(){const b=[2,4,8,1,256,512,48,1024],c=this.slots.filter(e=>
"closed"===e["forge_slots.state"]).map(e=>e["forge_slots.slot"]);return Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(e=>{if(!$b(e))return!1;e=e.getAttribute("data-content-type");return b.includes(Number(e))}).map(e=>({id:e.getAttribute("data-item-id"),slot:c.shift()})).filter(({slot:e})=>void 0!==e)},async xm(b,c,e,g){try{var l=new URLSearchParams({mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:W("sh")});const q=await fetch(T({}),
{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:l}).then(r=>r.text());let n;try{var h=JSON.parse(q);if(h.slots[b]&&h.slots[b].formula&&h.slots[b].formula.rent[2])n=h.slots[b].formula.rent[2];else{for(l=0;l<h.slots.length;l++)if(h.slots[l].formula&&h.slots[l].formula.rent[2]){n=h.slots[l].formula.rent[2];break}n||=3E3}}catch(r){n=3E3}const m=Ib(document.querySelector(`[data-item-id='${g}']`));try{if(e&&"none"!==e){const r={bronze:"19-10",
silver:"19-11",gold:"19-12"}[e];if(r){var k=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));const w=k.findIndex(y=>y.classList.contains("current")),v=k.slice(w).concat(k.slice(0,w));g=!1;h=null;for(k=0;k<v.length;k++){let y=v[k];if("false"===y.getAttribute("data-available"))continue;y.click();await new Promise(C=>setTimeout(C,250));const D=document.querySelector(`.item-i-${r}`);if(D){g=!0;h=D;break}}if(g&&h){const y=h.getAttribute("data-container-number"),D=h.getAttribute("data-position-x"),
C=h.getAttribute("data-position-y"),E=T({mod:"inventory",submod:"move",from:y,fromX:D,fromY:C,to:773,toX:b+1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")});await fetch(E,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(t=>t.text());F(`Hammer (${e}) moved to inventory.`)}else F(`Hammer (${e}) not found in any inventory bag.`),F("Proceeding to smelt without a hammer.")}else F("Proceeding to smelt without a hammer.")}}catch(r){}if(n<
Jh().gold){const r=T({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")});await fetch(r,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(w=>w.text());this.ep(c,m);ma("itemSmelted",0);F(`${d.Vf}`+m);await new Promise(w=>setTimeout(w,250))}else{F(`${d.Bb}`+n);const r=JSON.parse(localStorage.getItem("Timers"));Y("smelt",r.Smelting||10);window.location.reload()}}catch(q){location.reload()}},
async ip(b,c){var e=new URLSearchParams({mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:W("sh")});e=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:e}).then(g=>g.text());e=JSON.parse(e).slots[b].formula.rent[2];e<Jh().gold?jQuery.post(T({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")})).done(function(){var g=
JSON.parse(localStorage.getItem("smeltery_itemList1"));({item:g}=g);F(`${d.Wf}`+g.name);window.location.reload()}).fail(function(){F("Problem with smelting, maybe there is not enough space.");window.location.reload()}):(F(`${d.Bb}`+e),b=JSON.parse(localStorage.getItem("Timers")),Y("smelt",b.SmeltingNoGold||5),window.location.reload())},init:function(){jQuery("#inv").after('\n                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n\n                        <fieldset id="gladbot-workbench" style="\n                        padding: 10px;\n                        margin: 10px 20px;\n                        text-align: center;\n                        display: flex;\n                        flex-direction: row;\n                        flex-wrap: wrap;\n                        align-items: center;\n                        justify-content: space-around;\n                        border: 2px solid darkred;\n                        border-radius: 8px;\n                        width: 235px;">\n                        <legend style="\n                            padding: 0 10px;\n                            color: darkred;\n                            font-weight: bold;">GLDbot Smeltery Area</legend>\n                        </fieldset>');
la.Dm("#gladbot-workbench",'<i class="fa fa-fire"></i>',"gladbot-button gladbot-smelter-button-smelt gladbot-stylish-button").mouseup(b=>{la.en(b)});la.Dm("#gladbot-workbench","RESET","gladbot-button gladbot-smelter-button-reset gladbot-stylish-button").mouseup(()=>{localStorage.setItem("activateSmeltMode",!1)});jQuery("#gladbot-workbench").append('<p style="font-size: 0.8em; color: darkred;">Right click to reset smelt mode.</p>')},en:async function(){jQuery(document.body).addClass("fire-smelt-cursor");
jQuery(document.body).on("contextmenu",function(b){b.preventDefault();jQuery(document.body).removeClass("fire-smelt-cursor");jQuery(document.body).off("contextmenu");localStorage.setItem("activateSmeltMode",!1)});this.slots=await this.u();localStorage.setItem("activateSmeltMode",!0);jQuery("#inv .ui-draggable, #char .ui-draggable").off("mouseup.smelt").on("mouseup.smelt",async b=>{var c=b.target,e=c.className.match(/item-i-(\d+)-\d+/)[1];(b=this.slots.filter(g=>"closed"===g["forge_slots.state"])[0])?
(e={item:{type:e,name:Ib(c),quality:Ca(c),slot:b,container:c.getAttribute("data-container-number")},spot:{bag:c.getAttribute("data-container-number"),x:c.getAttribute("data-position-x"),y:c.getAttribute("data-position-y")}},localStorage.setItem("smeltery_itemList1",JSON.stringify(e)),jQuery(c).parents("#char").length?setTimeout(()=>{},1E3):(this.slots=await this.u(),await this.Gm(this.slots),this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]),c=c.getAttribute("data-item-id"),
e&&await la.ip(b["forge_slots.slot"],c))):console.log("No free slot available")})},async u(){try{const b=new URLSearchParams({mod:"forge",submod:"getSmeltingPreview",mode:"smelting",a:(new Date).getTime(),sh:W("sh")}),c=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(e=>e.text());return JSON.parse(c).slots}catch(b){console.log(b)}},async Ym(b){if("undefined"!==typeof b){let e=[];for(var c=0;c<b.length;c++)if("undefined"!==
typeof b[c]["forge_slots.uend"]){let g=1E3*b[c]["forge_slots.uend"];"finished-succeeded"===b[c]["forge_slots.state"]&&(g=0);e.push([g,b[c].item.name])}localStorage.setItem("smelt.timer",JSON.stringify(e))}},async Gm(b){const c="true"===localStorage.getItem("smeltLootbox");Array.isArray(b)&&(b=b.filter(e=>"finished-succeeded"===e.state).map(e=>e["forge_slots.slot"]),0<b.length&&!c?(await Promise.all(b.map(e=>la.Zo(e))),await this.u()):0<b.length&&c&&(await Promise.all(b.map(e=>la.$o(e))),await this.u()))},
async $o(b){b=new URLSearchParams({mod:"forge",submod:"lootbox",mode:"smelting",slot:b,a:(new Date).getTime(),sh:W("sh")});return await fetch("ajax.php",{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(c=>c.text())},async Zo(b){b=new URLSearchParams({mod:"forge",submod:"storeSmelted",mode:"smelting",slot:b,a:(new Date).getTime(),sh:W("sh")});return await fetch("ajax.php",{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:b}).then(c=>c.text())},ln(){var b=localStorage.getItem("smelt.timer");if(!b)return!0;b=JSON.parse(b).sort((c,e)=>c[0]-e[0]);return 6>b.length||b[0][0]+6E4<(new Date).getTime()},async pickItems(){F(`${d.Xf}`);la.bag=document.getElementById("inv");la.g=[];aa.Dd.Gn&&window.location.reload();var b=JSON.parse(localStorage.getItem("smeltingSettings"))||[],c=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{};const e=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||
"[]")),g=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]")),l="true"===localStorage.getItem("smelthighercolors");var h=!1;try{for(let m of b){if(!1===m.isEnabled)continue;if("isUnderworldItem"!==m.condition&&2>m.prefix.length&&2>m.suffix.length)continue;let r=[];var k="";"nameContains"===m.condition&&2<m.prefix.length&&""!==m.prefix.trim()?k=m.prefix.trim():!m.prefix&&"nameContains"===m.condition&&2<m.suffix.length&&""!==m.suffix.trim()&&(k=m.suffix.trim());"nameContains"===
m.condition&&m.rm&&2<m.rm.length&&(k=m.rm.trim());const w={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};if(m.colors&&0<m.colors.length){let v=[...m.colors];l&&v.sort((y,D)=>w[D]-w[y]);v.forEach(y=>{y=w[y];void 0!==y&&r.push(y)})}else r=Object.values(w),l&&r.sort((v,y)=>y-v);var q=0,n=[];if(2<k.length){for(let v of r){await new Promise(D=>setTimeout(D,270));const y=await this.sn(1,v,k,0);n.push(...y);5<=q&&(localStorage.setItem("smelt.timeOut",0),window.location.reload())}1<=q&&(Y("smelt",
0),window.location.reload());k=n;for(let v of k){if(5<=q)break;const y=v.item,D=Ib(v.item);la.g.some(C=>C.id===v.id)||e.has(D)||g.has(D)||!this.tm(y,m,b,c)||(la.g.push({item:y,id:v.id,hammerState:m.hammerState||"none",matchingRule:m}),q++,h=!0)}if(5<=q)break}else if("isUnderworldItem"===m.condition){F("Looking for underworld items...");q=0;for(let v of r){if(5<=q)break;const y=await this.sm(v);k=[];for(n=1;n<=Math.min(y,5);n++)k.push(n);for(n=0;n<k.length&&!(5<=q);n+=2){const D=k.slice(n,n+2).map(async E=>
{try{return await this.sn(E,v)}catch(t){return[]}}),C=await Promise.all(D);for(let E of C){if(5<=q)break;for(let t of E){const u=t.item;let A=this.tm(u,m);if(A&&(la.g.push({item:u,id:t.id,hammerState:A.hammerState||"none",matchingRule:A}),q++,5<=q))break}}}}}}if(!h&&"true"===localStorage.getItem("smeltAnything")){const m=c.itemTypes||[],r=c.hammerState||"none",w={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};let v=(c.colors||[]).map(E=>w[E]);0===v.length&&(v=Object.values(w));b=0;const y=
await this.sm(v[0]),D=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||[],C=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];for(c=1;c<=y&&!(5<=b);c++){const E=await this.Jo(c,v[0]);for(let t of E){if(5<=b)break;const u=t.item,A=Ib(u),B=parseInt(Ca(u),10),H=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]")),G=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"));if(!(D.some(K=>A.includes(K))||C.some(K=>A.includes(K))||H.has(A)||G.has(A))){if(Da.colors&&
0<Da.colors.length){const K={white:-1,green:0,blue:1,purple:2,orange:3,red:4},L=Object.keys(K).find(M=>K[M]===B);if(!Da.colors.includes(L))continue}m.includes(u.getAttribute("data-content-type"))&&(la.g.push({item:u,id:t.id,hammerState:r}),b++,h=!0)}}if(5<=b)break}}if(h&&0<la.g.length)await la.move(la.g);else{F("No items found for smelting.");const m=JSON.parse(localStorage.getItem("Timers"));Y("smelt",m.SmeltingNoItem||15);window.location.reload()}}catch(m){F("Error looking for items for smelting. If you have too many conditions, please reduce them."),
h=JSON.parse(localStorage.getItem("Timers")),Y("smelt",h.SmeltingError||15),window.location.reload()}},async bq(b,c){b=await fetch(I({mod:"packages",f:"0",fq:c,qry:"",page:b,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(g=>g.text());const e=[];jQuery(b).find(".packageItem").each((g,l)=>{g=l.querySelector("input").value;(l=jQuery(l).find(".ui-draggable")[0])&&e.push({id:g,item:l})});return e},Ho(b){return b.getAttribute("data-hammer-state")||
"none"},async sn(b,c=null,e="",g="0"){b={mod:"packages",f:g,page:b,sh:W("sh")};null!==c&&(b.fq=c);e&&""!==e.trim()&&(b.qry=e.trim());c=await fetch(I(b),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(h=>h.text());const l=[];jQuery(c).find(".packageItem").each((h,k)=>{h=k.querySelector("input").value;(k=jQuery(k).find(".ui-draggable")[0])&&l.push({id:h,item:k})});return l},async Jo(b,c=null,e=""){b={mod:"packages",f:"0",fq:null!==
c?c:-1,page:b,sh:W("sh")};e&&""!==e.trim()&&(b.qry=e.trim());e=await fetch(I(b),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(m=>m.text());e=jQuery(e).find(".packageItem");const g=[],l=(JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{}).itemTypes||[],h=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]")),k=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]")),q=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||
[],n=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];e.each((m,r)=>{const w=r.querySelector("input").value;if(m=jQuery(r).find(".ui-draggable")[0]){var v=Ib(m);r=m.getAttribute("data-content-type");g.some(y=>y.id===w)||q.some(y=>v.includes(y))||n.some(y=>v.includes(y))||h.has(v)||k.has(v)||l.includes(r)&&g.push({item:m,id:w})}});return g},async sm(b=null,c="",e="0"){b={mod:"packages",f:e,fq:b||-1,qry:"",page:1,sh:W("sh")};c&&""!==c.trim()&&(b.qry=c.trim());c=await fetch(I(b),{method:"GET",
headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},credentials:"include"}).then(g=>g.text());b=jQuery(c).find(".paging_right_full");c=1;0<b.length&&(b=b.last().attr("href"))&&(b=b.match(/page=(\d+)(?!.*page=)/))&&b[1]&&(c=parseInt(b[1],10));return c},tm(b){const c="true"===localStorage.getItem("smeltAnything"),e=JSON.parse(localStorage.getItem("smeltingSettings"))||[],g=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||[],l=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||
[],h=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];if(!c&&!c&&0===e.length)return!1;const k=Ib(b),q=parseInt(b.getAttribute("data-level"),10),n=xb(b),m=parseInt(Ca(b),10);var r=this.Ho(b),w=b.getAttribute("data-basis");r=b.getAttribute("data-hash");b.getAttribute("data-level");w=Gb(w,r);r=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]"));const v=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"));if(r.has(k)||v.has(k)||l.some(y=>k.includes(y))||h.some(y=>
k.includes(y)))return!1;for(let y of e)if(r=y.hammerState||"none",!1!==y.isEnabled&&this.uo(b,y,{itemName:k,itemLevel:q,itemType:n,itemQuality:m,itemHammerState:r,isUnderworldItem:w}))return y;if(c){if(g.itemTypes&&0<g.itemTypes.length&&!g.itemTypes.map(y=>parseInt(y,10)).includes(parseInt(n,10)))return!1;if(g.colors&&0<g.colors.length){const y={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(y).find(D=>y[D]===m);if(!g.colors.includes(b))return!1}return g}return null},uo(b,c,e){let {itemName:g,
itemLevel:l,itemType:h,itemQuality:k,isUnderworldItem:q}=e;if("nameContains"===c.condition){b=!0;if(0===c.prefix.length&&0===c.suffix.length)return!1;c.prefix&&0<c.prefix.length&&g&&0<g.length&&!g.toLowerCase().includes(c.prefix.toLowerCase())&&(b=!1);c.suffix&&0<c.suffix.length&&g&&0<g.length&&!g.toLowerCase().includes(c.suffix.toLowerCase())&&(b=!1);c.prefix&&0<c.prefix.length&&c.suffix&&0<c.suffix.length&&(!(g&&0<g.length)||g.toLowerCase().includes(c.prefix.toLowerCase())&&g.toLowerCase().includes(c.suffix.toLowerCase())||
(b=!1));if(!b)return!1}else if("isUnderworldItem"===c.condition&&!q)return!1;if(!(l<(c.level?parseInt(c.level,10):0))&&c.itemTypes&&0<c.itemTypes.length){if(!c.itemTypes.includes("9999")&&!c.itemTypes.map(n=>parseInt(n)).includes(parseInt(h,10)))return!1}else return!1;k||=0;if(c.colors&&0<c.colors.length){const n={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(n).find(m=>n[m]===k);if(!c.colors.includes(b))return!1}else return!1;return c},Dm:function(b,c,e){c=jQuery("<button>").html(c).addClass(e);
jQuery(b).append(c);return c},async move(){var b="513";b=(b=localStorage.getItem("smeltTab"))?(513+parseInt(b,10)).toString():"513";this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]).shift();try{let g=la.g.pop();var c=ec(la.bag);let l=fc(5,8,c),h=parseInt(g.item.getAttribute("data-measurement-x")),k=parseInt(g.item.getAttribute("data-measurement-y")),q=nc(k,h,l);c=b;if(q){const n=T({mod:"inventory",submod:"move",from:"-"+g.id,fromX:"1",fromY:"1",to:c,toX:q.x+1,toY:q.y+
1,amount:"1"}),m=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")});await fetch(n,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:m}).then(r=>r.text());var e=jQuery(g.item).css({left:32*q.x,top:32*q.y});la.bag.appendChild(e[0]);0<la.g.length||g?(localStorage.setItem("smeltCheck.timeOut",0),await new Promise(r=>setTimeout(r,500)),await this.move()):window.location.reload()}else if(0<la.g.length&&!q){F(`${d.Lb}`);await new Promise(m=>
setTimeout(m,500));await this.move();const n=JSON.parse(localStorage.getItem("Timers"));Y("smelt",n.SmeltingNoItem||15)}else{F(`${d.Lb}`);const n=JSON.parse(localStorage.getItem("Timers"));Y("smelt",n.SmeltingNoItem||15);window.location.reload()}}catch(g){localStorage.setItem("smeltCheck.timeOut",0),window.location.reload()}}};window.location.href.includes("index.php?mod=mysterybox")&&(ai(),bi());window.location.href.includes("/index.php?mod=forge&submod=smeltery")&&(la.init(),la.slots=await la.u(),
await la.Ym(la.slots),"true"==localStorage.getItem("activateSmeltMode")&&la.en());try{window.location.href.includes("/index.php?mod=location&submod=serverQuest")&&(window.location.href.includes("submod=serverQuestHighscore&loc=hadrians_wall")||localStorage.setItem("eventPoints_",parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10)))}catch{localStorage.setItem("doEventExpedition",!1);Pf("mod=overview");return}try{if(window.location.href.includes("/index.php?mod=work")){let b=
document.querySelector('span[data-ticker-type="countdown"]');if(b){let c=b.innerText.split(":"),e=6E4*(60*parseInt(c[0],10)+parseInt(c[1],10));await new Promise(g=>setTimeout(g,e))}}}catch{Pf("mod=overview");return}var Fj={async start(){const b=await Promise.all([new Promise(c=>{fetch(I({mod:"overview",doll:"1",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(e=>e.text()).then(e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");
c(!e)})}),new Promise(c=>{fetch(I({mod:"overview",doll:"2",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(e=>e.text()).then(e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");c(!e)})})]);b[0]&&Y("CheckDolls",1);b[1]&&Y("CheckDolls",1)}},of={async check(b=!1){return new Promise(async c=>{await new Promise(e=>{fetch(I({mod:"overview",doll:"1",sh:W("sh")}),{method:"GET",credentials:"include",
headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(g=>g.text()).then(g=>{localStorage.setItem("arenaCostumeEquiped",jQuery(g).find(".avatar")[0].classList.contains("avatar_costume_part"));e()})});b&&await b();c()})},async start(){if("mod=costumes"!=tf)Pf("mod=costumes");else{let e=localStorage.getItem("costumeUnderworld"),g=localStorage.getItem("costumeUnderworld");const l="true"===localStorage.getItem("wearUnderworld");var b=!1;let h=document.querySelectorAll(".costumes_box"),
k=!1,q;const n=localStorage.getItem("costumeUnderworld");b=["9","10","11"];const m=JSON.parse(localStorage.getItem("underworld"));for(var c of b)try{const r=h[Number(c)-1].querySelector(".costumes_button_single").getAttribute("onclick");if(r&&!r.includes("dropCostume")){k=!0;break}}catch(r){}0<h.length&&null!==n&&(c=Number(n)-1,0<=c&&c<h.length&&(c=h[c].querySelector(".costumes_button_single")||h[c].querySelector(".costumes_button_active_single"))&&(q=c.getAttribute("onclick")));["9","10","11"].includes(e)&&
q&&q.includes("dropCostume")?(b=!0,m.oj=!0,localStorage.setItem("underworld",JSON.stringify(m)),Y("CheckDolls",15)):(b=!1,m.oj=!1,localStorage.setItem("underworld",JSON.stringify(m)));b?(Y("CheckDolls",30),window.location.reload()):await this.check(async()=>{let r=[];if(l){let w=0;const v=["9","10","11"];for(let y of v)try{const D=h[Number(y)-1].querySelector(".costumes_button_single")?.getAttribute("onclick");if(D&&!D.includes("dropCostume")){k=!0;const C=Number(n)-1;0<=C&&C<h.length&&(k=h[C].querySelector(".costumes_button_single")||
h[C].querySelector(".costumes_button_active_single")?!0:!1);if(k&&"9"===g&&2>=Number(Jh().Ha)){r.push({doll:1,setId:Number(g)+2});break}if(k&&"10"===g&&2>=Number(Jh().vo)){r.push({doll:1,setId:Number(g)+2});break}if(k&&"11"===g){r.push({doll:1,setId:Number(g)+2});break}}}catch(D){w++}w===v.length&&F(`${d.Df}`)}try{if(!k){const w=h[Number(localStorage.getItem("costumeBasic")-1)].querySelector("#costumes_button_left input"),v=w.getAttribute("onclick");w.classList.contains("disabled")||v.includes("dropCostume")||
(12===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-3}):13===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-3}):14===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-3}):15===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-3}):r.push({doll:1,setId:localStorage.getItem("costumeBasic")}));
if(8>=Number(localStorage.getItem("costumeDungeon"))){const y=h[Number(localStorage.getItem("costumeDungeon")-1)].querySelector("#costumes_button_right input"),D=y.getAttribute("onclick");y.classList.contains("disabled")||D.includes("dropCostume")||(12===Number(localStorage.getItem("costumeDungeon"))?r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-3}):13===Number(localStorage.getItem("costumeDungeon"))?r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-3}):14===Number(localStorage.getItem("costumeDungeon"))?
r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-3}):15===Number(localStorage.getItem("costumeDungeon"))?r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-3}):r.push({doll:2,setId:localStorage.getItem("costumeDungeon")}))}}if(0<r.length){let {doll:w,setId:v}={...r.pop()};(await fetch(I({mod:"costumes",submod:"changeCostume",doll:w,setId:v,sh:W("sh")}))).ok&&0<r.length&&9>Number(v)&&await of.pn(r);Y("CheckDolls",30)}else Y("CheckDolls",15);window.location.reload()}catch{Y("CheckDolls",
15),window.location.reload(),F("Problem occurred while wearing a costume.")}})}},async pn(b,c=!1){let {doll:e,setId:g}={...b.pop()};await new Promise(l=>{fetch(I({mod:"costumes",submod:"changeCostume",doll:e,setId:g,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(h=>h.text()).then(()=>{0<b.length?of.pn(b,c):(Y("CheckDolls",15),l())})})}};let z2=localStorage.getItem("we");we=new Date(z2);aa.player.Ed<new Date&&we<new Date&&aa.player.key!=ya&&hb();if(ta&&"true"===localStorage.getItem("guildBattleEnable")&&
vf("guildBattleEnable"))try{const b="true"===localStorage.getItem("guildBattleRandom"),c=JSON.parse(localStorage.getItem("guildKeywords"))||[],e=await fetch(I({mod:"guild_warcamp",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(q=>q.text()),g=(new DOMParser).parseFromString(e,"text/html"),l=g.querySelectorAll('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]'),h=g.querySelectorAll("table.section-like tr:not(:first-child)");
let k=null;0<h.length&&0<c.length?h.forEach(q=>{const n=q.querySelector('td a[href*="mod=guild"]');q=q.querySelector('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]');if(n&&q){const m=n.textContent.trim().toLowerCase();c.some(r=>m.includes(r.toLowerCase()))&&(k=q.getAttribute("href"))}}):b&&(k=l[Math.floor(Math.random()*l.length)].getAttribute("href"));if(k){const q=new URLSearchParams(k),n=q.get("gid"),m=q.get("sh");try{const r=I({mod:"guild_warcamp",submod:"guild_combat",gid:n,sh:m}),w=new URLSearchParams({combat:"Attack!"});
await fetch(r,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:w}).then(y=>y.text());F(`Guild attack initiated against guild ID: ${n}`);const v=JSON.parse(localStorage.getItem("Timers"))||{};Y("guildBattleEnable",v.guildBattleEnable||120)}catch(r){F("Error initiating guild attack")}}else F("No matching guilds found for the provided guild names.")}catch(b){F("Error loading guild warcamp page")}if(ta&&"true"===localStorage.getItem("GuildEnable")&&
vf("GuildDonate")){const b=parseInt(localStorage.getItem("GuildDonateMore")||0,10),c=parseInt(localStorage.getItem("GuildDonateLess")||0,10),e=parseInt(localStorage.getItem("GuildDonateAmount")||0,10);if(da.gold>=b&&da.gold<=c){const g=I({mod:"guildBankingHouse",submod:"donate",sh:W("sh")}),l=new URLSearchParams({donation:e,doDonation:"Donate"});await fetch(g,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:l}).then(k=>k.text());
F(`${d.Ff} ${e}.`);const h=JSON.parse(localStorage.getItem("Timers"));Y("GuildDonate",h.GuildDonate||5)}}if("true"===localStorage.getItem("throwDice")&&"true"===localStorage.getItem("doEventExpedition")&&vf("throwDice")&&"true"===sessionStorage.getItem("autoGoActive"))try{const b=await fetch(I({mod:"craps",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(e=>e.text()),c=jQuery(b).find("#tossAinfo_freeplay");if(0<
c.length)if((c.attr("style")||"").includes("display: block")){const e=new URLSearchParams({type:"1",a:(new Date).getTime(),sh:W("sh")});await fetch(window.location.protocol+"//"+window.location.host+"/game/ajax/craps.php",{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:e}).then(g=>g.text());F(`${d.Ef}`)}else F("Used all the free dices today.");else F("Used all the free dices today.");Y("throwDice",10)}catch(b){F("Please turn off throw dice feature."),
localStorage.setItem("throwDice",!1)}if(vf("sortSettings")&&"true"==sessionStorage.getItem("autoGoActive"))try{const b=await (await fetch(I({mod:"settings",submod:"gameSettings",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}})).text(),c=(new DOMParser).parseFromString(b,"text/html").querySelector('select[name="packageSorting"]');let e="in_desc";if(c){const g=c.querySelector("option[selected]");e=g?g.value:"in_desc"}Y("sortSettings",
30);localStorage.setItem("PackageSort",e)}catch(b){console.error("Fetch Error:",b)}if(window.location.href.includes("index.php?mod=location&loc=")){let b=0,c=!1;const e=()=>{fetch(window.location.href).then(n=>n.text()).then(n=>{n=(new DOMParser).parseFromString(n,"text/html");if(n=Array.from(n.querySelectorAll("img[data-tooltip]")).find(m=>{const r=m.getAttribute("data-tooltip").toLowerCase();return["owned","sahip","propri","posiad","posees"].some(w=>r.includes(w))}))n=(n=n.getAttribute("data-tooltip").match(/(Owned|Sahip[^:]*|Propri[^:]*|Posiad[^:]*|Posees[^:]*): (\d+)/i))?
parseInt(n[2],10):100,document.getElementById("hourglassesLeft").textContent=n,localStorage.setItem("hourglassesLeft",n)}).catch(()=>{F("No hourglass left")})},g=(n,m,r,w,v,y)=>{function D(B){return new Promise((H,G)=>{fetch(`${E}/game/index.php?mod=premium&submod=inventory&sh=${t}`).then(K=>K.text()).then(K=>{if(K=(new DOMParser).parseFromString(K,"text/html").querySelector(`div.premiumfeature_picture > img[src*="${B}"] + .premiumfeature_tokencount`))return K.textContent.trim();throw Error("Token value not found!");
}).then(K=>fetch(`${E}/game/index.php?mod=premium&submod=inventoryActivate&feature=${"5fd403b4efa8ea7bc3ca5a852bfce9"===B?18:5}&token=${K}&sh=${t}`)).then(()=>{H()}).catch(K=>{G(K)})})}if(!c||b>=y)h();else{var C=new URL(window.location.href),E=C.origin,t=C.searchParams.get("sh")||"",u=document.getElementById("useLifePotion").checked;w=document.getElementById("useMobilizationExp2").checked;var A=parseInt(document.getElementById("healPercentage2").value,10);C=new URLSearchParams({mod:"location",submod:"attack",
location:n,stage:m,premium:r?1:0,a:Date.now(),sh:t});fetch(`${E}/game/ajax.php?${C.toString()}`).then(B=>B.text()).then(()=>{(u||w)&&fetch(window.location.href).then(B=>B.text()).then(async B=>{B=(new DOMParser).parseFromString(B,"text/html");if(u){const H=parseInt(B.getElementById("header_values_hp_percent").textContent,10);if(Number(H)<Number(A))return await D("5fd403b4efa8ea7bc3ca5a852bfce9")}if(w&&(B=B.getElementById("expeditionpoints_value_point").innerText,0===Number(parseInt(B.replace("%",
""),10))))return await D("c9ce614bbc67a9e85aa0ee87cf2bb7")}).then(async()=>{b++;b>=Number(y)?(h(),window.location.reload()):(document.getElementById("attacksPerformed").textContent=b,localStorage.setItem("attackCount",b),await e(),setTimeout(async()=>{await g(n,m,r,w,v,y)},1E3*v))}).catch(()=>{})})}},l=async()=>{c=!0;document.getElementById("startExpedition").style.display="none";document.getElementById("stopExpedition").style.display="block";const n=(new URLSearchParams(window.location.search)).get("loc"),
m=document.getElementById("monsterSelection").value,r=document.getElementById("useHourglass").checked,w=document.getElementById("attackInterval").value,v=document.getElementById("numberOfAttacks").value;await g(n,m,r,useMobilizationExp2,w,v)},h=()=>{c=!1;document.getElementById("startExpedition").style.display="block";document.getElementById("stopExpedition").style.display="none"},k=()=>{var n=document.createElement("div");n.innerHTML=`
    <div class="expedition-settings">
      <h2 class="section-header">${d.Re}</h2>
      <div class="expedition-settings-content">
        <div>
            <label>${d.Oe}: </label>
            <select id="monsterSelection">
            <option value="1">${d.Ge}</option>
            <option value="2">${d.He}</option>
            <option value="3">${d.Ie}</option>
            <option value="4">${d.Je}</option>
            </select>
            <br>
            <label>${d.Ce}: </label>
            <input type="checkbox" id="useHourglass">
            <br>
            <label>${d.Fe}: </label>
            <input type="checkbox" id="useMobilizationExp2">
            <br>
            <label>${d.Ee}: </label>
            <input type="checkbox" id="useLifePotion">
            <br>
            <label>${d.Be}: </label>
            <input type="number" id="healPercentage2" value="25" min="1" max="99">
            <br>
            <label>${d.Me}: </label>
            <input type="number" id="numberOfAttacks" value="${document.getElementById("expeditionpoints_value_point").textContent||"0"}" min="1" max="36">
            <br>
            <label>${d.De}: </label>
            <input type="number" id="attackInterval" value="5" min="1" max="60">
            <br>
            <button id="startExpedition" class="expedition-button">${d.Pe}</button>
            <button id="resetAttacks" class="expedition-button reset-button">${d.Ne}</button>
            <button id="stopExpedition" class="expedition-button" style="display: none;">${d.Qe}</button>
            <div id="attackLog"></div>
        </div>
      </div>
    </div>
  `;var m=document.querySelector(".section-header");m.parentNode.insertBefore(n,m);n.querySelector(".section-header").addEventListener("click",()=>{const r=document.querySelector(".expedition-settings-content"),w="none"===r.style.display;r.style.display=w?"block":"none";localStorage.setItem("expeditionSettingsHidden",w?"false":"true")});n=n.querySelector(".expedition-settings-content");m="true"===localStorage.getItem("expeditionSettingsHidden");n.style.display=m?"none":"block";document.getElementById("resetAttacks").addEventListener("click",
()=>{b=0;localStorage.removeItem("attackCount");document.getElementById("attacksPerformed").textContent=b});document.getElementById("startExpedition").addEventListener("click",l);document.getElementById("stopExpedition").addEventListener("click",h);b=parseInt(localStorage.getItem("attackCount")||"0");document.getElementById("attackLog").innerHTML=`
            ${d.ze}: <span id="attacksPerformed">${b}</span><br>
            ${d.Ae}: <span id="hourglassesLeft">${localStorage.getItem("hourglassesLeft")||"0"}</span><br>
            <span class="span-new">${d.Ke}</span><br>
            <span class="span-new">${d.Le}</span>

            `};if(window.location.href.includes("index.php?mod=location&loc=")&&!window.location.href.includes("location&loc=nile_bank")&&!window.location.href.includes("index.php?mod=location&loc=false")&&!window.location.href.includes("location&loc=desert")){const n=document.querySelector("#wrapper_game.underworld");(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld||n||k()}const q=document.createElement("style");q.innerHTML="\n  .expedition-settings {\n    border: 2px solid #4CAF50;\n    padding: 10px;\n    margin: 10px 0;\n    background-color: #d3c195;\n    border-radius: 5px;\n  }\n  .expedition-button {\n    border: none;\n    padding: 10px 20px;\n    text-align: center;\n    text-decoration: none;\n    display: inline-block;\n    font-size: 16px;\n    margin: 10px;\n    background-color: #a09270;\n    cursor: pointer;\n    border-radius: 5px;\n  }\n\n  .reset-button {\n    background-color: #f44336; /* Red color */\n  }\n\n  .expedition-button:disabled {\n    background-color: #ccc;\n    cursor: not-allowed;\n  }\n";
document.head.appendChild(q)}if(window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&submod=showDungeons")||window.location.href.includes("index.php?mod=reports&submod=showArena")||window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")){let b=document.createElement("div");b.id="ReportSearchUI";b.innerHTML='\n        <div class="setting-row">\n            <h5>GLDbot - Search in Reports</h5>\n            <span>Searches for reports containing the specified keyword and gold amount. Limit 15 pages.</span>\n            <br>\n            <div class="input-container">\n                <input type="text" id="searchReports" placeholder="Enter keyword">\n                <input type="number" id="goldFilter" placeholder="Minimum gold">\n                <button class="awesome-button" id="searchReportsButton">Search</button>\n            </div>\n        </div>\n    ';
const c=document.querySelector("#content");c.insertBefore(b,c.firstChild);document.getElementById("searchReportsButton").addEventListener("click",async()=>{const h=document.getElementById("searchReports").value,k=parseInt(document.getElementById("goldFilter").value,10)||0,q=document.getElementById("searchReportsButton");q.disabled=!0;try{await e(h,k)}finally{q.disabled=!1}});async function e(h,k){let q=1;var n=await fetch(window.location.href,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()}}).then(r=>r.text());n=jQuery(n).find(".paging_right_full");0<n.length&&(n=n.last().attr("href"))&&(n=n.match(/page=(\d+)(?!.*page=)/))&&n[1]&&(q=parseInt(n[1],10));n=[];for(let r=1;r<=q&&15>=r;r++){var m=await g(r);m=l(m,h,k);0<m.length&&(n=n.concat(m))}if(0<n.length){const r=document.querySelector(".table-container tbody");r.innerHTML="";n.forEach(w=>{r.appendChild(w)})}}async function g(h){let k="";window.location.href.includes("index.php?mod=reports&submod=showArena")?k="showArena":
window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")?k="showCircusTurma":window.location.href.includes("index.php?mod=reports&submod=showDungeons")?k="showDungeons":window.location.href.includes("index.php?mod=reports&showExpeditions")&&(k="showExpeditions");h=I({mod:"reports",submod:k,page:h,sh:W("sh")});return await fetch(h,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(q=>q.text())}function l(h,
k,q){let n=[];jQuery(h).find(".table-container tr").each((m,r)=>{var w=jQuery(r);m=window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&showDungeons")?w.find("td").eq(1).text().trim():w.find("td").eq(1).find("a").first().text().trim();w=w.find("td").eq(2).text().trim().replace(/[.,]/g,"");w=parseInt(w,10)||0;m.toLowerCase().includes(k.toLowerCase())&&w>=q&&n.push(r)});return n}}if(window.location.href.includes("/index.php?mod=overview&doll=2")){const b=
Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(g=>Ib(g)).filter(g=>null!==g&&void 0!==g),c=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"),e=new Set([...c,...b]);try{localStorage.setItem("mercenaryEquipmentIDs",JSON.stringify([...e]))}catch{}}else if(window.location.href.includes("/index.php?mod=overview")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(g=>Ib(g)).filter(g=>null!==g&&void 0!==g),c=JSON.parse(localStorage.getItem("playerEquipmentIDs")||
"[]"),e=new Set([...c,...b]);try{localStorage.setItem("playerEquipmentIDs",JSON.stringify([...e]))}catch{}}if(window.location.href.includes("/index.php?mod=inventory&sub")&&document.querySelector('td[valign="top"]')){let b=!0;async function c(){var m=document.getElementById("sortCriteria");let r=Array.from(m.selectedOptions).map(D=>D.value),w=document.getElementById("shop");m=Array.from(w.querySelectorAll(".ui-draggable")).map(D=>{let C=Ib(D),E=parseInt(D.getAttribute("data-level"),10)||0,t=D.getAttribute("data-basis")||
"",u=parseInt(t.split("-")[1],10)||0,A=parseInt(D.getAttribute("data-quality"),10)||0,B=parseInt(D.getAttribute("data-content-type"),10)||0,H=parseInt(D.getAttribute("data-measurement-x"),10)||1,G=parseInt(D.getAttribute("data-measurement-y"),10)||1;return{element:D,name:C,level:E,jc:t,type:B,nn:u,quality:A,measurementX:H,measurementY:G,wq:parseInt(D.getAttribute("data-position-x"),10),xq:parseInt(D.getAttribute("data-position-y"),10)}});m.sort((D,C)=>{for(let E of r){let t;switch(E){case "name":t=
D.name.localeCompare(C.name);break;case "level":t=D.level-C.level;break;case "data-basis":t=D.nn-C.nn;break;case "quality":t=D.quality-C.quality;break;case "type":t=D.type-C.type;break;default:t=0}if(0!==t)return t}return 0});let v=0,y=0;for(let D of m)D.element.setAttribute("data-position-x",v+1),D.element.setAttribute("data-position-y",y+1),D.element.style.left=`${32*v}px`,D.element.style.top=`${32*y}px`,v+=D.measurementX,6<=v&&(v=0,y+=1);w.innerHTML="";m.forEach(D=>{w.appendChild(D.element)})}
(function(){let m=`
                <section class="merchant-settings" style="display: block;">
                    <div class="sorting-options">
                        <label for="sortCriteria">Sort Items By:</label>
                        <select id="sortCriteria">
                            <option value="name">Name</option>
                            <option value="level">Level</option>
                            <option value="data-basis">Base</option>
                            <option value="type">Type</option>
                            <option value="quality">Quality</option>
                        </select>
                        <button class="awesome-button" type="button" id="sortItemsButton">Sort Items</button>
                        
                    </div>
                    <p>
                    <div class="actions">
                        <button class="awesome-button" type="button">${d.Mj}</button>
                        <button class="awesome-button" type="button">${d.Nj}</button>
                        <button class="awesome-button" type="button">Buy All</button>
                        <button class="awesome-button" type="button">Buy 10</button>
                    </div>
                    <ul class="compact-list">
                        <li><input type="checkbox" id="chkWeapons"><label for="chkWeapons">${d.ga}</label></li>
                        <li><input type="checkbox" id="chkShields"><label for="chkShields">${d.da}</label></li>
                        <li><input type="checkbox" id="chkChestArmour"><label for="chkChestArmour">${d.W}</label></li>
                        <li><input type="checkbox" id="chkHelmets"><label for="chkHelmets">${d.Z}</label></li>
                        <li><input type="checkbox" id="chkGloves"><label for="chkGloves">${d.Y}</label></li>
                        <li><input type="checkbox" id="chkShoes"><label for="chkShoes">${d.ea}</label></li>
                        <li><input type="checkbox" id="chkRings"><label for="chkRings">${d.ca}</label></li>
                        <li><input type="checkbox" id="chkAmulets"><label for="chkAmulets">${d.V}</label></li>
                        <li><input type="checkbox" id="chkUsable"><label for="chkUsable">${d.Ci}</label></li>
                        <li><input type="checkbox" id="chkUpgrades"><label for="chkUpgrades">${d.Bi}</label></li>
                        <li><input type="checkbox" id="chkRecipes"><label for="chkRecipes">${d.dh}</label></li>
                        <li><input type="checkbox" id="chkMercenary"><label for="chkMercenary">${d.sg}</label></li>
                        <li><input type="checkbox" id="chkScroll"><label for="chkScroll">Scroll</label></li>
                        <li><input type="checkbox" id="chkReinforcements"><label for="chkReinforcements">${d.fh}</label></li>
                    </ul>
                </section>
                `;document.getElementById("inv").insertAdjacentHTML("afterend",m)})();async function e(){if(b){var m=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(r=>{r=r.getAttribute("data-content-type");if(document.getElementById("chkWeapons").checked&&"2"==r||document.getElementById("chkShields").checked&&"4"==r||document.getElementById("chkChestArmour").checked&&"8"==r||document.getElementById("chkHelmets").checked&&"1"==r||document.getElementById("chkGloves").checked&&"256"==
r||document.getElementById("chkShoes").checked&&"512"==r||document.getElementById("chkRings").checked&&"48"==r||document.getElementById("chkAmulets").checked&&"1024"==r||document.getElementById("chkUsable").checked&&"4096"==r||document.getElementById("chkUpgrades").checked&&"4096"==r||document.getElementById("chkRecipes").checked&&"8192"==r||document.getElementById("chkMercenary").checked&&"16384"==r||document.getElementById("chkScroll").checked&&"64"==r||document.getElementById("chkReinforcements").checked&&
"4096"==r)return!0;if(b)return!1});for(let r=0;r<m.length&&b;r++)await new Promise(w=>setTimeout(w,200)),fa(m[r],"shop")}}async function g(){if(b){var m=document.querySelectorAll("#inv .ui-draggable");for(let r=0;r<m.length;r++)await new Promise(w=>setTimeout(w,200)),fa(m[r],"shop")}}async function l(){if(b){var m=document.querySelectorAll("#shop .ui-draggable");for(let r=0;r<m.length;r++)await new Promise(w=>setTimeout(w,200)),fa(m[r],"inv")}}async function h(){if(b){var m=document.querySelectorAll("#shop .ui-draggable");
for(let r=0;10>r;r++)await new Promise(w=>setTimeout(w,200)),fa(m[r],"inv")}}let k=document.querySelector(".actions .awesome-button:nth-child(2)"),q=document.querySelector(".actions .awesome-button:nth-child(3)"),n=document.querySelector(".actions .awesome-button:nth-child(4");document.querySelector(".actions .awesome-button:nth-child(1)").addEventListener("click",async()=>{b=!0;await new Promise(m=>setTimeout(m,500));g()});k.addEventListener("click",async()=>{b=!0;await new Promise(m=>setTimeout(m,
500));e()});q.addEventListener("click",async()=>{await new Promise(m=>setTimeout(m,500));l()});n.addEventListener("click",async()=>{await new Promise(m=>setTimeout(m,500));h()});document.getElementById("sortItemsButton").addEventListener("click",async()=>{await new Promise(m=>setTimeout(m,500));await c()})}if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll"))if(mf=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),
vb=mf.textContent.trim(),2<vb.length){nf=document.getElementById("char");function b(c,e,g,l){var h=document.createElement("a");h.className="gladbot-button gladbot-"+c;h.textContent=e;h.setAttribute("data-tooltip",g);nf.appendChild(h);(JSON.parse(localStorage.getItem(l))||[]).includes(vb)&&(h.classList.add("added"),h.setAttribute("data-tooltip","Remove from "+("autoAttackList"===l?"Arena":"Circus")));h.addEventListener("click",function(){var k=vb,q=JSON.parse(localStorage.getItem(l))||[],n=q.indexOf(k);
-1!==n?(q.splice(n,1),h.classList.remove("added"),h.setAttribute("data-tooltip","Add to "+("autoAttackList"===l?"Arena":"Circus"))):(q.push(k),h.classList.add("added"),h.setAttribute("data-tooltip","Remove from "+("autoAttackList"===l?"Arena":"Circus")));localStorage.setItem(l,JSON.stringify(q))})}b("arena","A","GladB: Add to Arena List","autoAttackList");b("circus","C","GladB: Add to Circus List","autoAttackCircusList")}var Uc=JSON.parse(localStorage.getItem("smeltingSettings"))||[],Da=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||
{itemTypes:[],colors:[],hammerState:"none",enabled:!1},ic=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]};"true"==localStorage.getItem("pauseBotEnable")&&vf("pauseBot")&&(sessionStorage.setItem("autoGoActive","false"),localStorage.setItem("pauseBotEnable","false"),alert("Bot has been paused!"),window.location.reload());1==ta&&vf("storeForgeResources")&&jj();!0===ta&&vf("Training")&&"true"==localStorage.getItem("trainEnable")&&lj()&&await kj();"true"===sessionStorage.getItem("autoGoActive")&&
cb.href.includes("submod=showCombatReport")&&mj();if("true"===localStorage.getItem("HighlightUnderworldItems")){function b(e){e.querySelectorAll("div[data-basis]").forEach(g=>{const l=g.getAttribute("data-basis"),h=g.getAttribute("data-hash");g.getAttribute("data-level");null!=l&&Gb(l,h)&&(g.style.boxShadow="0 0 0.1px 2px red")})}b(document);const c=new MutationObserver(e=>{e.forEach(g=>{g.addedNodes&&g.addedNodes.forEach(l=>{1===l.nodeType&&b(l)})});c.disconnect()});c.observe(document.body,{childList:!0,
subtree:!0});document.querySelectorAll(".awesome-tabs").forEach(e=>{e.addEventListener("click",()=>{setTimeout(()=>{b(document)},500)})})}if("true"==localStorage.getItem("AutoAuction")){const b=JSON.parse(localStorage.getItem("searchTerms")||"[]"),c=JSON.parse(localStorage.getItem("SearchTypes")||"[]"),e=JSON.parse(localStorage.getItem("Timers")),g=new DOMParser;function l(n,m,r){let w=[],v=[];Array.from(n).forEach(y=>{const D=y.getAttribute("data-tooltip");var C=y.getAttribute("data-content-type");
const E=y.getAttribute("data-quality"),t=m.some(u=>{const A=hf(D);return A?A.toLowerCase().split(/\s+/).includes(u.toLowerCase()):!1});C=r.includes("9999")||r.includes(C);"2"==E||"3"==E?v.push(y):t&&C&&w.push(y)});return{Qn:w,Tn:v}}if(vf("ShopSearch")){const n=await Qf();let m=[],r=[];for(const y of n){const D=l(y.querySelectorAll("#shop .ui-draggable"),b,c);D.Qn.forEach(C=>{C.setAttribute("data-original-url",y.Wm)});D.Tn.forEach(C=>{C.setAttribute("data-original-url",y.Wm)});m=m.concat(D.Qn);r=r.concat(D.Tn)}const w=
m.map(y=>y.outerHTML);localStorage.setItem("MatchingShopItems",JSON.stringify(w));const v=r.map(y=>y.outerHTML);localStorage.setItem("UniqueShopResults",JSON.stringify(v));Y("ShopSearch",e.SearchTimer||5)}if(vf("AuctionSearch")){const n=await jh(),m=await jh(3),r=y=>Array.from(y.querySelectorAll('#auction_table [class^="item-i-"]')).filter(D=>{const C=D.getAttribute("data-tooltip");var E=D.getAttribute("data-content-type");D=b.some(t=>{const u=hf(C);return u?u.toLowerCase().split(/\s+/).includes(t.toLowerCase()):
!1});E=c.includes("9999")||c.includes(E);return D&&E}),w=r(n);localStorage.setItem("MatchingAuctionItems",JSON.stringify(w.map(y=>y.outerHTML)));const v=r(m);localStorage.setItem("MatchingMercAuctionItems",JSON.stringify(v.map(y=>y.outerHTML)));Y("AuctionSearch",e.SearchTimer||5)}function h(n,m,r){const w=document.createElement("div");w.setAttribute("id",r);w.classList.add("search_results_panel");var v=document.createElement("div");v.classList.add("panel-header");v.innerHTML=`<h2>${n}</h2>`;w.appendChild(v);
w.style.cssText="\n                position: fixed;\n                left: 0;\n                top: 0;\n                width: 300px;\n                height: 400px; /* Set a default height */\n                overflow-y: auto; /* Allow both vertical and horizontal scrolling if needed */\n                overflow-x: hidden;\n                z-index: 500;\n                box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n                font-family: 'Arial', sans-serif;\n                background: rgba(221, 213, 180, 0.95);\n                background-size: cover;\n                border-radius: 8px;\n            ";
n=w.querySelector(".panel-header");n.style.cssText=`
                background-color: ${"auction_items_panel"===r?"#bead79":"#8b6a45"};
                padding: 10px;
                cursor: move; /* Set cursor to move only on the header */
                user-select: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            `;n.querySelector("h2").style.cssText="\n                margin: 0;\n                font-size: 16px;\n                color: #fff;\n            ";n=localStorage.getItem(`${r}_top`);v=localStorage.getItem(`${r}_left`);let y=localStorage.getItem(`${r}_width`),D=localStorage.getItem(`${r}_height`);n&&v?(w.style.top=n+"px",w.style.left=v+"px"):"auction_items_panel"===r?(w.style.top="50px",w.style.left="20px"):"shop_items_panel"===r&&(w.style.top="50px",w.style.left="350px");y&&(w.style.width=
y+"px");D&&(w.style.height=D+"px");q(w,r);m=k(m);w.appendChild(m);document.body.appendChild(w);w.style.maxHeight=`${window.innerHeight-100}px`}function k(n){const m=document.createElement("div");m.classList.add("items-container");n.forEach(({key:r,label:w})=>{const v=document.createElement("div");v.classList.add("section-header");v.textContent=w;m.appendChild(v);const y=document.createElement("div");y.classList.add("grid-container");y.style.display="grid";y.style.gridTemplateColumns="repeat(auto-fill, minmax(50px, 1fr))";
y.style.cq="5px";y.style.padding="10px";w=localStorage.getItem(r);(JSON.parse(w)||[]).forEach(D=>{const C=g.parseFromString(D,"text/html").body.firstChild.cloneNode(!0);C.style.left="";C.style.top="";C.style.position="relative";D=C.getAttribute("data-tooltip");var E=JSON.parse(D.replace(/&quot;/g,'"'));D=E[0][0][1].split(";")[0];const t=encodeURIComponent(E[0][0][0].split(" ")[0]);E=new URL(window.location.href);const u=E.origin,A=E.searchParams.get("sh")||"";E=document.createElement("div");E.classList.add("auction_item_div");
E.appendChild(C);E.style.border="2px solid "+D;E.style.borderRadius="4px";E.style.padding="2px";E.style.boxSizing="border-box";E.style.cursor="pointer";E.style.transform="scale(0.8)";E.addEventListener("click",()=>{var B=C.getAttribute("data-hash");localStorage.setItem("highlightedItemHash",B);if(["UniqueShopResults","MatchingShopItems"].includes(r)){if(B=C.getAttribute("data-original-url"))location.href=B}else B=`${u}/game/index.php?mod=auction&qry=${t}&itemLevel=1&itemType=0&itemQuality=-1&sh=${A}`,
"MatchingMercAuctionItems"===r&&(B+="&ttype=3"),location.href=B});y.appendChild(E)});m.appendChild(v);m.appendChild(y)});return m}function q(n,m){const r=n.querySelector(".panel-header");$(n).draggable({handle:r,Op:"window",stop:function(w,v){localStorage.setItem(`${m}_top`,v.position.top);localStorage.setItem(`${m}_left`,v.position.left)}});$(n).resizable({gq:"n, e, s, w, ne, se, sw, nw",stop:function(w,v){localStorage.setItem(`${m}_width`,v.size.width);localStorage.setItem(`${m}_height`,v.size.height)}})}
(function(){document.querySelectorAll(".search_results_panel").forEach(n=>n.remove());h(`${d.Wa}`,[{key:"MatchingAuctionItems",label:`${d.Wa}`},{key:"MatchingMercAuctionItems",label:`${d.rg}`}],"auction_items_panel");h(`${d.Xb}`,[{key:"MatchingShopItems",label:`${d.Xb}`},{key:"UniqueShopResults",label:`${d.Ai}`}],"shop_items_panel")})()}setInterval(()=>{if(document.hidden)try{chrome.runtime.sendMessage({Hn:!0,Fm:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"}),console.log("Wake up.")}catch(b){}},
6E4);var Gj=btoa("autoGoActive"),Hj=btoa("false");await async function(){"1dff7ed808095f0b0d0f84a12076237eb57f5a41e0fa08ae62fc1c8d3156a004"!==await nj(cc)&&sessionStorage.setItem(atob(Gj),atob(Hj))}();setInterval(()=>{const b=JSON.parse(localStorage.getItem("timeConditions"))||[];var c="true"===localStorage.getItem("botPaused");if(b&&0<b.length&&!c&&Pc()){c=new Date;const e=`${String(c.getHours()).padStart(2,"0")}:${String(c.getMinutes()).padStart(2,"0")}`;b.forEach(g=>{g.start&&g.end&&(g.start>g.end?
e>=g.start||e<=g.end:e>=g.start&&e<=g.end)&&("stop"===g.action?sessionStorage.setItem("autoGoActive","false"):"start"===g.action&&"false"===sessionStorage.getItem("autoGoActive")&&(sessionStorage.setItem("autoGoActive","true"),jf()))})}},15E3);var Yb=(new Date).getTime();if(!ya!==Qc){"true"===localStorage.getItem("activateAuction2")&&sf();var pf={gn(b){let c=localStorage.getItem("MarketboughtItems");c?c=JSON.parse(c):c=[];c.push(b);localStorage.setItem("MarketboughtItems",JSON.stringify(c))},Oq(){var b=
localStorage.getItem("boughtItems");b?b=JSON.parse(b):b=[];let c=document.getElementById("boughtItems");for(;c.firstChild;)c.removeChild(c.firstChild);for(let e of b)b=document.createElement("option"),b.textContent=e,c.appendChild(b)},async mo(){var b=new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=parseInt(localStorage.getItem("MarketHoldGold"))||0;let g=localStorage.getItem("marketItems");g=g?JSON.parse(g):[];const l={Cp:"1",yp:"2",qp:"3",tp:"4",sp:"5",zp:"8",wp:"6",
op:"9",Bp:"7",pp:"11",Ap:"12",vp:"13",up:"15",rp:"18",Lp:"19",xp:"20"},h={bo:"-1",Wn:"0",Un:"1",Yn:"2",Xn:"3",Zn:"4"};F(`${d.Cf}`);const k={};if("true"===localStorage.getItem("marketOnlyFood"))c=await this.qn(c,e,"-1"),await this.In([],7,1,c,b);else{for(var q of g){const n=`${l[q.itemType]||"0"}-${h[q.rarity]||"0"}`;k[n]||(k[n]=[]);k[n].push(q)}q=g.map(n=>h[n.rarity]||"0");q=Math.min(...q);c=await this.qn(c,e,q);for(const [n,m]of Object.entries(k)){const [r,w]=n.split("-");await this.In(m,r,w,c,b)}}},
async qn(b,c,e){const g="true"===localStorage.getItem("marketOnlyFood");let l=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=0&fq=${e}`;g&&(l=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=7&fq=${e}`);c=await fetch(l).then(E=>E.text());b=new DOMParser;e=b.parseFromString(c,"text/html").querySelector(".standalone");c=1;e&&(c=parseInt(e.textContent.split("/")[1],10));e=[];const h=localStorage.getItem("MarketMaxFoodPrice")||1E5,k=localStorage.getItem("MarketMaxPerFoodPrice")||
1E3,q=localStorage.getItem("MarketMinItemLevel")||1;let n=0;for(let E=1;E<=c;E++){var m=`${l}&p=${E}`;await new Promise(t=>setTimeout(t,250));m=await (await fetch(m)).text();await new Promise(t=>setTimeout(t,250));m=b.parseFromString(m,"text/html").querySelectorAll("#market_item_table tr");for(let t of m){var r=t.querySelectorAll("td");if(r&&0<r.length&&(m=r[0].querySelector("div"))){var w=xb(m),v=Ca(m),y=Ib(m),D=yb(m);let u=m.getAttribute("data-item-id"),A=m.getAttribute("data-soulbound-to");r=parseInt(r[2].innerText.replace(/\./g,
""),10);var C=parseInt(m.getAttribute("data-amount"),10)||1;C=r/C;if(g&&"64"===w&&r<=k&&(!A||null===A)&&Number(D)>=Number(q)){if(n+r>h)break;n+=r;e.push({itemRarity:v,itemName:y,itemDataId:u,itemSoulbound:A,itemPrice:r,pricePerItem:C,page:E})}else g||(w=Ca(m),v=Ib(m),y=m.getAttribute("data-item-id"),D=m.getAttribute("data-soulbound-to"),m=parseInt(m.getAttribute("data-amount"),10)||1,e.push({itemRarity:w,itemName:v,itemDataId:y,itemSoulbound:D,itemPrice:r,pricePerItem:r/m,page:E}))}}if(g&&n>=h)break}return e},
async In(b,c,e,g,l){for(const h of g){const k=h.itemName;g=h.itemDataId;const q=h.itemSoulbound,n=h.itemPrice,m=h.pricePerItem,r=h.page,w={bo:"-1",Wn:"0",Un:"1",Yn:"2",Xn:"3",Zn:"4"},v=localStorage.getItem("usePacks")||"false";if("true"===localStorage.getItem("marketOnlyFood"))da.gold>=n+l&&(!q||null===q)&&await fetch(I({mod:"market",buyid:g,sh:W("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()}}).then(y=>y.text()).then(y=>{y=(new DOMParser).parseFromString(y,"text/html").getElementById("sstat_gold_val").innerText;y=parseInt(y.replace(/\./g,""),10);if(document.getElementById("sstat_gold_val").innerText=y)da.gold=y;pf.gn(k);F(`Bought ${k} for ${n} gold`)});else try{b.some(y=>{const D=w[y.rarity]||"0";return k.trim().toLowerCase().includes(y.itemToBuy.trim().toLowerCase())&&e==D&&da.gold>=n+l&&(!q||null===q||"BuySoulbound"===y.Soulbound&&q||"DontBuySoulbound"===y.Soulbound&&
!q)&&(Number(y.maxPrice)>=n||"true"==v&&Number(y.maxPrice)>=m&&da.gold>=n)})&&await fetch(I({mod:"market",buyid:g,sh:W("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(y=>y.text()).then(y=>{y=(new DOMParser).parseFromString(y,"text/html").getElementById("sstat_gold_val").innerText;y=parseInt(y.replace(/\./g,""),10);if(document.getElementById("sstat_gold_val").innerText=
y)da.gold=y;pf.gn(k);F(`Bought ${k} for ${n} gold`)})}catch(y){F(`${d.cg}`),await new Promise(D=>setTimeout(D,2E3)),window.location.reload()}}F(`${d.yb} in Market`)}};(window.location.href.includes("/index.php?mod=forge&submod=workbench")||window.location.href.includes("/index.php?mod=forge&doll=1&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=2&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=3&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=4&submod=workbench")||
window.location.href.includes("index.php?mod=forge&doll=5&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=6&submod=workbench"))&&pj();var Ij={async start(){try{const b=aa.workbench.repairArena,c=aa.workbench.repairTurma;let e=this.F(),g=this.Fo(e),l=this.Cn("itemList1"),h=this.Cn("itemList2");const k=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];g?(await this.u(),await this.bp(g,k)):b&&0<l.length?await this.un("mod=overview&doll=1",aa.workbench.itemList1):c&&
0<h.length&&await this.un("mod=overview&doll=2",aa.workbench.itemList2)}catch(b){this.handleError()}},F(){let b=localStorage.getItem("workbenchItem");return b?JSON.parse(b):{selectedItem:{}}},Fo(b){try{return b.selectedItem&&0<Object.keys(b.selectedItem).length?b.selectedItem:!1}catch(c){return null}},Cn(b){return(b=localStorage.getItem(b))?this.hp(b):[]},hp(b){try{let c=JSON.parse(b);return Array.isArray(c)&&c.every(e=>void 0===e)?[]:c}catch(c){return[]}},async un(b,c){tf!==b?Pf(b):(await this.u(),
0<this.F().spaces?await this.vm(c):this.Nn("workbench"))},Nn(b){"space"===b?F("Not enough inventory space for repair. Retrying in 10 minutes."):"workbench"===b?F("Not enough empty slots in workbench. Retrying in 10 minutes."):"material"===b?F(`${d.ua}`):F("Repair: Retrying in 10 minutes.");b=JSON.parse(localStorage.getItem("Timers"));Y("repair",b.Repair||10);window.location.reload()},async bp(b,c,e){switch(b.status){case "toWorkbench":await this.pj(b.iid);break;case "toFillGoods":0<c.length&&e.workbenchneededitems?
await this.bj(b.slot,-1,e.workbenchneededitems):await this.kc(b.slot);break;case "toPackage":await this.dd(b.slot);break;case "toBag":await this.Ia();break;case "toInv":await this.hm();break;case "workbenchToBag":await this.Dn(b.slot)}},handleError(){localStorage.removeItem("workbenchItem");const b=JSON.parse(localStorage.getItem("Timers"));Y("repair",b.Repair||10);window.location.reload()},async u(){try{const b=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),
sh:W("sh")}),c=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(g=>g.text());let e=this.F();e.slots=JSON.parse(c).slots;e.spaces=e.slots.filter(g=>"closed"===g["forge_slots.state"]).length;e.freeSlots=e.slots.filter(g=>"closed"===g["forge_slots.state"]);localStorage.setItem("workbenchItem",JSON.stringify(e))}catch(b){}},async vm(b){try{let c=b.shift();F(`${d.Sf}${c.name}`);F(`${d.wa}`);let {spot:e,
bag:g}=await dc(c.zn,c.An);const l=T({mod:"inventory",submod:"move",from:c.container,fromX:1,fromY:1,to:g,toX:e.x+1,toY:e.y+1,amount:1,doll:c.doll,a:(new Date).getTime(),sh:W("sh")}),h=await fetch(l,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(q=>q.text());let k=this.F();k.selectedItem||(k.selectedItem={});Object.assign(k.selectedItem,{item:c,iid:JSON.parse(h).to.data.itemId,status:"toWorkbench",
spot:e,bag:g});localStorage.setItem("workbenchItem",JSON.stringify(k));await this.pj(JSON.parse(h).to.data.itemId)}catch{F("Error repairing the item."),localStorage.setItem("workbenchItem",JSON.stringify({})),window.location.reload()}},async pj(b){try{F(`${d.Ab}`);let c=this.F(),e=0;for(let h of c.slots||[])if("closed"===h["forge_slots.state"]){e=h["forge_slots.slot"];break}const g=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:e,iid:b,amount:1,a:(new Date).getTime(),
sh:W("sh")}),l=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:g}).then(h=>h.text());c.slots=JSON.parse(l).slots;c.spaces=0;c.freeSlots=[];for(let h of c.slots)"closed"===h["forge_slots.state"]&&(c.spaces++,c.freeSlots.push(h));e=c.freeSlots.shift()["forge_slots.slot"];c.workbenchneededitems=JSON.parse(l).slots[e].formula.needed;c.workbenchneededitems||(F(`${d.ua}`),Object.assign(c.selectedItem,{status:"toBag"}),
F("Error moving the item to the workbench."),localStorage.setItem("workbenchItem",JSON.stringify(c)),window.location.reload());Object.assign(c.selectedItem,{slot:e,status:"toFillGoods"});localStorage.setItem("workbenchItem",JSON.stringify(c));await this.fp(e,b)}catch(c){F("Error moving the item to the workbench."+c),window.location.reload()}},async fp(b,c){c=new URLSearchParams({mod:"forge",submod:"rent",mode:"workbench",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")});await fetch(T({}),{method:"POST",
credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(e=>e.text());c=this.F();Object.assign(c.selectedItem,{slot:b,status:"toFillGoods"});localStorage.setItem("workbenchItem",JSON.stringify(c));0<(JSON.parse(localStorage.getItem("ignoredMaterials"))||[]).length?await this.bj(b,-1,c.workbenchneededitems):await this.kc(b)},async bj(b,c,e){c=[];const g=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let l in e){const h=parseInt(l,
10);0<e[l].amount&&!g.some(k=>parseInt(k,10)+18E3===h)&&c.push({type:h,amount:e[l].amount})}await this.Kl(c,-1,b);await new Promise(l=>setTimeout(l,2E3));e=T({mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")});await fetch(e,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(l=>l.text());e=this.F();e.selectedItem.status="toPackage";localStorage.setItem("workbenchItem",
JSON.stringify(e));await this.dd(b)},async Kl(b,c=-1,e){let g=!0;for(let k=0;k<b.length;k++){var l=c;let q=!1,n=b[k].amount;b[k].type=b[k].type-18E3;let m=await this.Io(b[k].type);const r=Number(localStorage.getItem("repairMaxQuality"));for(;l<=r&&0<n;l++){var h=m[l]||0;if(0!==h){h=Math.min(n,h);n-=h;try{const w=T({mod:"forge",submod:"storageOut",type:b[k].type,quality:l,amount:h,a:(new Date).getTime(),sh:W("sh")});await fetch(w,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:new URLSearchParams({})}).then(v=>v.text());await new Promise(v=>setTimeout(v,500));await this.Ll(b[k].type,l,e,h);q=!0;if(0>=n)break}catch(w){console.error(w)}}}if(!q||0<n)g=!1}return g},async Io(b){let c={};try{const e=await fetch(I({mod:"forge",submod:"storage",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(l=>l.text()),g=jQuery(e).find("#change-resource-amount").attr("data-max");if(g){const l=
JSON.parse(g.replace(/&quot;/g,'"'));l[b]&&(c=l[b])}}catch(e){console.error("Failed to fetch material quantities:",e)}return c},async Ll(b,c,e,g){let l=1,h=!1,k=this.F(),{bag:q,spot:n}=k.selectedItem||{};for(;!h&&5>=l;)try{const m=await fetch(I({mod:"packages",f:18,fq:c,qry:"",page:l,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(w=>w.text()),r=jQuery(m).find(".packageItem");0===r.length?l++:(r.each(async(w,v)=>
{try{let y=jQuery(v).find(".ui-draggable"),D=Ra(y[0]).split("-")[1],C=Ca(y[0]),E=y.context.querySelector("input").getAttribute("value");if(Number(D)==Number(b)&&Number(C)==Number(c)){h=!0;try{const t=T({mod:"inventory",submod:"move",from:"-"+E,fromX:1,fromY:1,to:q,toX:n.x+1,toY:n.y+1,amount:g}),u=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")}),A=await fetch(t,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:u}).then(H=>
H.text()),B=JSON.parse(A).to.data.itemId;try{const H=T({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:B,amount:g,a:(new Date).getTime(),sh:W("sh")});await fetch(H,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(G=>G.text())}catch(H){F(`Error moving material to workbench: ${H}`)}}catch(t){F(`Error moving material from package to bag: ${t}`)}return!1}}catch(y){F(`Error processing package item: ${y}`)}}),
h||l++)}catch(m){F(`Error fetching materials from the package on page ${l}: ${m}`),l++}h||F(`Material of type ${b} and quality ${c} not found in packages.`)},async kc(b,c=-1){let e=this.F();const g=new URLSearchParams({mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:W("sh")});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:g}).then(l=>l.text());c<Number(localStorage.getItem("repairMaxQuality"))?
await this.kc(b,++c):(c=new URLSearchParams({mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}),await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(l=>l.text()),e.selectedItem.status="toPackage",localStorage.setItem("workbenchItem",JSON.stringify(e)),await this.dd(b))},async dd(b){F(`${d.Rf}`);let c=this.F();c.selectedItem.status="workbenchToBag";localStorage.setItem("workbenchItem",
JSON.stringify(c));let e;try{(e=1100*c.slots[b].formula.duration)||(e=12E3)}catch(g){e=12E3}await new Promise(g=>setTimeout(g,e));await this.Dn(b)},async Dn(b){let c=this.F();const e=new URLSearchParams({mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")});(await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:e}).then(g=>g.text())).includes("document.location.href=document.location.href")?
(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c))):(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c)),b=new URLSearchParams({mod:"forge",submod:"cancel",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}),await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(g=>g.text()));await this.Ia()},async tq(b=
1){F(`${d.wa}`);let c=await this.F(),{item:e,bag:g,spot:l}=c.selectedItem,h=!1;try{const v=await fetch(I({mod:"packages",f:-1,fq:e.quality,qry:e.name,page:b,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(D=>D.text());let y=jQuery(v).find(".packageItem").toArray();0===y.length&&F(`No package items found on page: ${b}`);for(let D of y){let C=D.querySelector(".ui-draggable");Ea(C);var k=Ca(C),q=Ib(C);D.getAttribute("data-soulbound-to");
var n=C.getAttribute("data-measurement-x"),m=C.getAttribute("data-measurement-y"),r=D.querySelector("[data-container-number]").getAttribute("data-container-number"),w=D.querySelector('input[name="packages[]"]').value;if(q===e.name&&e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===k)h=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.En(D,g,l,r,n,m)}3<b?this.handleError():h||await this.Ia(++b,!0)}catch(v){F(`Error repairing the item. ${v}`),
this.Ln(),window.location.reload()}},async Ia(b=1){F(`${d.wa}`);let c=await this.F(),{item:e,bag:g,spot:l}=c.selectedItem,h=!1;e.quality=e?.quality??0;try{const v=await fetch(I({mod:"packages",f:-1,fq:e.quality,qry:e.name,page:b,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(D=>D.text());let y=jQuery(v).find(".packageItem").toArray();0===y.length&&F(`No package items found on page: ${b}`);for(let D of y){let C=
D.querySelector(".ui-draggable");Ea(C);var k=Ca(C)??0,q=Ib(C);D.getAttribute("data-soulbound-to");var n=C.getAttribute("data-measurement-x"),m=C.getAttribute("data-measurement-y"),r=D.querySelector("[data-container-number]").getAttribute("data-container-number"),w=D.querySelector('input[name="packages[]"]').value;if(q===e.name&&e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===k)h=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),
await this.En(D,g,l,r,n,m)}3<b?this.handleError():h||await this.Ia(++b,!0)}catch(v){F(`Error repairing the item. ${v}`),this.Ln(),window.location.reload()}},async En(b,c,e,g,l,h){await dc(l,h,async(k,q)=>{const n=new URLSearchParams({mod:"inventory",submod:"move",from:g,fromX:1,fromY:1,to:q,toX:k.x+1,toY:k.y+1,amount:1,a:(new Date).getTime(),sh:W("sh")});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:n}).then(m=>
m.text());await this.hm(g,k,q)})},async hm(b,c,e){F("Trying to move repaired item to the equpiment.");b=this.F();let {item:g}=b.selectedItem;c=new URLSearchParams({mod:"inventory",submod:"move",from:e,fromX:c.x+1,fromY:c.y+1,to:g.container,toX:1,toY:1,amount:1,doll:g.doll,a:(new Date).getTime(),sh:W("sh")});c=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(l=>l.text());c.includes(`"data":{"containerNumber":${g.container}`)?
(Object.assign(b.selectedItem,{status:"toInv"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),await this.Do(c,g)):(Object.assign(b.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),window.location.reload())},async Do(b,c){let e,g,l=localStorage.getItem("repairPercentage")||10;try{e=JSON.parse(b).to.data.tooltip.pop().pop()[0].match(/\d+/g),g=Number(e[0])/Number(e[1])*100}catch(h){location.reload()}g<parseInt(l,10)?(this.kp(c.container,2===c.doll),F(`${d.ua}`)):
(F(`${d.Uf}`),ma("itemRepaired",0));b=this.F();delete b.selectedItem;localStorage.setItem("workbenchItem",JSON.stringify(b));window.location.reload()},kp(b,c=!1){const e=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),l=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),h=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}"),k={2:"helmet",11:"necklace",3:"weapon",5:"armor",4:"shield",9:"gloves",
10:"shoes",6:"rings1",7:"rings2"},q={2:"helmetM",11:"necklaceM",3:"weaponM",5:"armorM",4:"shieldM",9:"glovesM",10:"shoesM",6:"rings1M",7:"rings2M"};b=c?q[b]:k[b];c?g[b]&&(g[b]=!1,h[b]=Date.now(),localStorage.setItem("activeItemsMercenary",JSON.stringify(g)),localStorage.setItem("disabledTimeMercenary",JSON.stringify(h))):e[b]&&(e[b]=!1,l[b]=Date.now(),localStorage.setItem("activeItemsGladiator",JSON.stringify(e)),localStorage.setItem("disabledTimeGladiator",JSON.stringify(l)))},Ln(){this.Nn()}},Ej=
{jm:[],async gp(b){try{let e;const g=parseInt(localStorage.getItem("smeltTab"),10)||1;F("Repairing before smelting, please wait...");1===g?e=514:2===g?e=515:3===g?e=516:4===g?e=517:5===g?e=518:6===g&&(e=519);const l=await this.Co(b);if(l){var c=await this.Xo(b);if(null===c)console.error("Failed to move item to workbench.");else return await this.$m(c),await this.np(c),await this.oo(c,e,l)}else console.error(`Item with ID ${b} not found in inventory.`)}catch(e){}},async Co(b){let c=null;document.querySelectorAll("#inv .ui-draggable").forEach(e=>
{if(e.getAttribute("data-item-id")===b){const g=parseInt(e.getAttribute("data-position-x"),10)+1,l=parseInt(e.getAttribute("data-position-y"),10)+1,h=Ca(e);e=Ib(e).toLowerCase();c={container:"inv",x:g,y:l,quality:h,name:e};return!1}});return c},async Xo(b){const c=await this.Eo();if(null===c)return F("No available workbench slots. Continuing without repair."),!1;var e=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:c,iid:b,amount:1,a:(new Date).getTime(),sh:W("sh")});
e=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:e}).then(g=>g.text());if("0"===(localStorage.getItem("PartialOrFull")||"0"))try{this.jm=JSON.parse(e).slots[c].formula.needed}catch{F("Error getting needed items for repair.")}b=new URLSearchParams({mod:"forge",submod:"rent",mode:"workbench",slot:c,rent:2,item:b,a:(new Date).getTime(),sh:W("sh")});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:b}).then(g=>g.text());return c},async Eo(){var b=new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});b=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(e=>e.text());b=JSON.parse(b).slots;let c=null;for(let e of b)if("closed"===e["forge_slots.state"]){c=e["forge_slots.slot"];break}return c},async $m(b){"0"===(localStorage.getItem("PartialOrFull")||
"0")&&0<Object.keys(this.jm).length?await this.bj(b):await this.Bo(b);b=new URLSearchParams({mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(c=>c.text())},async Bo(b){const c=localStorage.getItem("repairBeforeSmeltMaxQuality")||1;b=new URLSearchParams({mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,
quality:c,a:(new Date).getTime(),sh:W("sh")});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(e=>e.text())},async bj(b){let c=[];const e=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let g in this.jm){const l=parseInt(g,10);0<this.jm[g].amount&&!e.some(h=>parseInt(h,10)+18E3===l)&&c.push({type:l,amount:this.jm[g].amount})}await this.Kl(c,-1,b)},async Kl(b,c=-1,e){for(let g=0;g<b.length;g++){let l=
c,h=0,k=1;2>=b[g].amount&&(k=1);for(b[g].type=b[g].type-18E3;l<=Number(localStorage.getItem("repairMaxQuality"))&&h<k;)try{const q=T({mod:"forge",submod:"storageOut",type:b[g].type,quality:l,amount:1,a:(new Date).getTime(),sh:W("sh")});await fetch(q,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(n=>n.text());await this.Ll(b[g].type,l,e,1);h++;if(h<=k)break}catch(q){if(l++,l>Number(localStorage.getItem("repairMaxQuality")))break}}},
async Ll(b,c,e,g){let l=1,h=!1,{spot:k,bag:q}=await dc(1,1);for(;!h&&5>=l;)try{const n=await fetch(I({mod:"packages",f:18,fq:c,qry:"",page:l,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(w=>w.text()),m=jQuery(n).find(".packageItem");if(0===m.length){l++;continue}let r=!1;m.each((w,v)=>{try{let y=jQuery(v).find(".ui-draggable"),D=Ra(y[0]).split("-")[1],C=Ca(y[0]),E=y.context.querySelector("input").getAttribute("value");
if(D==b&&C==c){r=h=!0;const t=T({mod:"inventory",submod:"move",from:"-"+E,fromX:1,fromY:1,to:q,toX:k.x+1,toY:k.y+1,amount:g}),u=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")});fetch(t,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:u}).then(A=>A.text()).then(A=>{try{const B=JSON.parse(A).to.data.itemId,H=T({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:B,amount:g,a:(new Date).getTime(),sh:W("sh")});fetch(H,
{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).catch(()=>{})}catch(B){}}).catch(()=>{});return!1}}catch(y){}});r||l++}catch(n){F(`Error fetching materials from the package on page ${l}: ${n}`),l++}h||F(`Material of type ${b} and quality ${c} not found in packages.`)},async np(b){let c=1E3,e=await this.Ko(b);if(null===e||void 0===e)e=6;c=1E3;await new Promise(g=>setTimeout(g,1100*e+c))},async Ko(b){var c=
new URLSearchParams({mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});c=await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(e=>e.text());return(c=JSON.parse(c).slots.find(e=>e["forge_slots.slot"]===b))&&c.formula&&c.formula.duration?c.formula.duration:6},async oo(b,c,e){b=new URLSearchParams({mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),
sh:W("sh")});await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(g=>g.text());return await this.Yo(c,e)},async Yo(b,c){let e=1;var g=!1;let l;for(;!g&&5>=e;){var h=await fetch(I({mod:"packages",f:0,fq:c.quality,qry:c.name,page:e,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(k=>k.text());h=jQuery(h).find(".packageItem").toArray();
for(let k of h){jQuery(k).find(".ui-draggable");g=new URLSearchParams({mod:"inventory",submod:"move",from:"-"+k.querySelector("input").value,fromX:1,fromY:1,to:b,toX:c.x-1,toY:c.y-1,amount:1,a:(new Date).getTime(),sh:W("sh")});l=(await fetch(T({}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:g}).then(q=>q.json())).to.data.itemId;g=!0;break}g||e++}if(!g)throw Error("Repaired item not found in packages.");return l}},R={Im:!1,
Nm:!0,spot:1,bag:512,start(){this.pack=function(b,c,e){if(!e)return e;var g=0,l=b+c.slice([e.split("^")[1]]);for(b=0;b<l.length;b++)c=l.charCodeAt(b),g=(g<<5)-g+c,g|=0;return e.split("^")[0]==g};this.storage=JSON.parse(localStorage.getItem("packages"))||{packages:{}};this.createFunctions()},createFunctions(){function b(c){var e=c.getAttribute("data-button");const g=c.getAttribute("data-name");c.getAttribute("data-value");const l=c.classList.toggle("selected");"packageAll"===e?document.querySelectorAll(`.color-box[data-name="${g}"]`).forEach(k=>
{k!==c&&k.classList.toggle("selected",l)}):(l||document.querySelector(`.color-box.select-all[data-name="${g}"]`)?.classList.remove("selected"),Array.from(document.querySelectorAll(`.color-box[data-name="${g}"]`)).filter(k=>k!==c&&"packageAll"!==k.getAttribute("data-button")).every(k=>k.classList.contains("selected"))&&document.querySelector(`.color-box.select-all[data-name="${g}"]`)?.classList.add("selected"));e=Array.from(document.querySelectorAll(`.color-box.selected[data-name="${g}"]`)).map(k=>
k.getAttribute("data-value"));const h=JSON.parse(localStorage.getItem("packages")||"{}");h[g]=e;localStorage.setItem("packages",JSON.stringify(h))}document.getElementById("ConfirmGetGold").addEventListener("click",async function(){async function c(m,r){r=T({mod:"inventory",submod:"move",from:m[0].closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+r,toY:21,amount:1});const w=new URLSearchParams({a:(new Date).getTime(),sh:l});r=await fetch(r,{method:"POST",
credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:w}).then(v=>v.text());m[0].closest(".packageItem").remove();m=JSON.parse(r).header.gold.text||"0";m=parseInt(m.replace(/[^0-9]/g,""),10);q+=m-k;k=m;document.getElementById("goldMovedIndicator").textContent=`Gold moved: ${q.toLocaleString()}`}async function e(){var m=await fetch(I({mod:"packages",f:"14",fq:-1,qry:"",page:h,sh:l}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()}}).then(w=>w.text());let r=jQuery(m).find(".ui-draggable").filter((w,v)=>(w=parseInt(jQuery(v).attr("data-price-gold"),10))&&w<=n-k).get();for(let [w,v]of r.entries())if(await c(jQuery(v),w),k>=n){document.getElementById("goldMovedIndicator").textContent+=" - Completed";return}h++;m=(m=jQuery(m).find(".paging_right_full")[0])?parseInt(m.href.match(/\d+$/)[0],10):1;h<m?await e():document.getElementById("goldMovedIndicator").textContent=`Not enough gold found. Only ${q.toLocaleString()} moved.`}
let g=parseInt(document.getElementById("getGold").value.replace(/[^0-9]/g,""),10);if(isNaN(g)||0>=g)alert("Please enter a valid amount greater than 0.");else{var l=W("sh"),h=0,k=0,q=0;k=parseInt(document.getElementById("sstat_gold_val").textContent.replace(/[^0-9]/g,""),10);var n=k+g;document.getElementById("goldMovedIndicator").textContent="Starting...";await e()}});document.querySelector("h2").addEventListener("click",()=>{jQuery(".custom_packages").toggle();let c=jQuery(".custom_packages").is(":hidden");
localStorage.setItem("packages_hidden",c)});jQuery(".custom_packages").mouseup(async c=>{var e=c.target;c=e.getAttribute("data-button");var g=JSON.parse(localStorage.getItem("packages")),l=g.quality;const h=g.type;if(!e.getAttribute("disabled")){switch(c){case "pickAll":confirm("Pick all?")&&this.pickItems(!0);break;case "pickAllSelected":-1<aa.packages.type.indexOf(14)&&confirm("Pick gold");this.pickItems(!1);break;case "sellThisPage":if(!g||!g.quality||!g.type){Ya("Please select a valid package with both quality and type.");
break}0<l.length&&0<h.length?this.jp():(this.Lm=!0,Ya("Please select both quality and type to sell."));break;case "SARTH":this.sarth();break;case "SASTM":if(!g||!g.quality||!g.type){Ya("Please select a valid package with both quality and type.");break}0<l.length&&0<h.length?this.sastm():(this.Lm=!0,Ya("Please select both quality and type to sell."));break;case "stop":this.stop=!0;break;case "switch":e=document.querySelector('input[data-name="useSmeltFilter"]');g=document.querySelector('input[data-name="sellUnderworld"]');
l=document.querySelector('input[data-name="UCOTH"]');e.checked="true"===localStorage.getItem("useTriggerSmeltFilter");g.checked="true"===localStorage.getItem("packageSellUnderworld");l.checked="true"===localStorage.getItem("useTriggerCloths");e.addEventListener("change",function(){localStorage.setItem("useTriggerSmeltFilter",this.checked)});g.addEventListener("change",function(){localStorage.setItem("packageSellUnderworld",this.checked)});l.addEventListener("change",function(){localStorage.setItem("useTriggerCloths",
this.checked)});break;default:return}"stop"!=c&&"switch"!=c&&(this.Lm?this.Lm=!1:(this.stop=!1,jQuery("[pakageCmd]").attr("disabled","")))}});document.querySelector(".custom_packages").addEventListener("click",c=>{var e=c.target.closest(".item-checkbox");if(e){var g=e.getAttribute("data-button");c=e.getAttribute("data-name");if(g&&c){var l=Array.from(document.querySelectorAll(`[data-name="${c}"][data-button="package"]`)),h=document.querySelector(`[data-name="${c}"][data-button="packageAll"]`),k=e.classList.toggle("selected");
"packageAll"===g?l.forEach(q=>q.classList.toggle("selected",k)):"package"===g&&(!k&&h&&h.classList.remove("selected"),l.every(q=>q.classList.contains("selected"))&&h&&h.classList.add("selected"));e=l.filter(q=>q.classList.contains("selected")).map(q=>q.getAttribute("data-value"));g=JSON.parse(localStorage.getItem("packages")||"{}");g[c]=e;localStorage.setItem("packages",JSON.stringify(g))}}});document.querySelectorAll(".color-box").forEach(c=>{const e=()=>b(c);c.addEventListener("touchstart",e,{passive:!0});
c.addEventListener("click",e)});document.querySelectorAll(".item-checkbox img").forEach(c=>{var e=window.getComputedStyle(c);const g=parseInt(e.width,10);e=parseInt(e.height,10);if(64<=g&&96<=e)c.style.transform="scale(0.5)",c.style.width="64px",c.style.height="64px",c.style.transformOrigin="top left";else if(32<g||32<e)c.style.width="64px",c.style.height="64px",c.style.transform="scale(0.5)",c.style.transformOrigin="top left";else if(32==g||32==e)c.style.transform="scale(1)",c.style.transformOrigin=
"top left"});(()=>{var c=JSON.parse(localStorage.getItem("packages")||"{}");for(const [l,h]of Object.entries(c))h.forEach(k=>{(k=document.querySelector(`[data-name="${l}"][data-value="${k}"]`))&&k.classList.add("selected")}),(c=document.querySelector(`[data-name="${l}"][data-button="packageAll"]`))&&Array.from(document.querySelectorAll(`[data-name="${l}"][data-button="package"]`)).every(k=>k.classList.contains("selected"))&&c.classList.add("selected");var e=document.querySelector('input[data-name="useSmeltFilter"]');
c=document.querySelector('input[data-name="sellUnderworld"]');const g=document.querySelector('input[data-name="UCOTH"]');if(e){const l="true"===localStorage.getItem("useTriggerSmeltFilter");e.checked=l}c&&(e="true"===localStorage.getItem("packageSellUnderworld"),c.checked=e);g&&(g.checked="true"===localStorage.getItem("useTriggerCloths"))})()},enableButtons(){jQuery("[pakageCmd]").removeAttr("disabled")},pickItems(b,c){aa.packages=JSON.parse(localStorage.getItem("packages")||"{}");const e=aa.packages.type,
g=aa.packages.quality;if(b||0!=e.length&&0!=g.length){var l=["12"];this.arr=Array.from(document.querySelectorAll("#packages .ui-draggable")).filter(h=>{const k=Ra(h),[q]=k.split("-").map(Number);var n=parseInt(Ca(h),10);if(b)return!0;h=e.some(m=>l.includes(String(q))?m===k||m===String(q):m===k||m===String(q)||k.startsWith(`${m}-`));n=g.map(Number).includes(Number(n));return h&&n}).sort((h,k)=>Hb(k)-Hb(h));R.move();c&&c()}else Ya("No package types or qualities selected")},async moveGold(b,c){c=T({mod:"inventory",
submod:"move",from:b.closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+c,toY:21,amount:1});const e=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")});c=await fetch(c,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:e}).then(g=>g.text());b.closest(".packageItem").remove();document.getElementById("sstat_gold_val").innerText=JSON.parse(c).header.gold.text||0},move(){var b=
document.getElementById("inv"),c=ec(b);let e=Math.min(40-ac(c),this.arr.length);b=this.arr.shift();0<e&&!R.stop?((c=Oc(b,c))?wa(b,c):fa(b,"inv"),setTimeout(()=>{R.move()},100)):setTimeout(R.enableButtons,100)},sarth:function(){const b=new URLSearchParams({lq:0,packages:1,Zm:1,a:(new Date).getTime(),sh:W("sh")});fetch(T({mod:"forge",submod:"storageIn"}),{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:b}).then(c=>c.text()).then(()=>
{window.location.reload(!0)})},async sastm(){R.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),this.nm={},this.pack&&this.Rm(this.cn))},async jp(){R.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),R.Im=!0,this.nm={},this.pack&&this.Rm(this.cn))},async cn(b){if(R.stop)window.location.reload();else if(R.nm=b,b=Object.values(b).every(c=>c.items.length>=c.Bm),R.ao=document.querySelector('input[data-name="UCOTH"]'),
b&&!R.ao.checked){if(b=document.getElementById("sellspinner"),b.classList.add("hidden"),!document.getElementById("shops-full-message")){const c=document.createElement("div");c.id="shops-full-message";c.classList.add("message-container");c.textContent="Shops are full! Please refresh the shops or select refresh shops automatically.";b.insertAdjacentElement("afterend",c);R.enableButtons()}}else dc(2,3,R.Vn)},async Vn(b,c){R.stop&&window.location.reload();try{R.ho=Object.assign(b,{b:c})}catch(y){Ya("Please empty your inventory to have 3x3 space")}document.querySelectorAll("#inventory_nav a")[c-
512].click();R.inv=document.getElementById("inv");const e=JSON.parse(localStorage.getItem("packages"))||{};b=(new URL(window.location.href)).searchParams;b.get("f");b.get("fq");let g={mod:"packages",f:"0",fq:e.quality[0]||-1,qry:"",page:1,sh:W("sh")};b=await fetch(I(g),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(y=>y.text());b=jQuery(b).find(".paging_right_full")[0]?.href.match(/\d+$/)?.[0]||1;console.log(`Max page determined: ${b}`);
R.g=[];R.ma=[];const l="true"===localStorage.getItem("useTriggerSmeltFilter"),h="true"===localStorage.getItem("packageSellUnderworld");let k=JSON.parse(localStorage.getItem("smeltingSettings"))||[];var q=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],n=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];const m=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]")),r=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"));let w=!1;if(R.Im)R.Im&&(R.stop&&
window.location.reload(),v=document.querySelectorAll("#packages .packageItem"),b=document.getElementById("sellspinner"),b.classList.remove("hidden"),c=document.getElementById("statusMessage"),c||(c=document.createElement("div"),c.id="statusMessage",c.classList.add("status-message"),b.insertAdjacentElement("afterend",c)),0<v.length?(c.textContent=`Processing ${v.length} items from the current page...`,v=Array.from(v).map(async y=>{var D=y.querySelector("input").value,C=y.querySelector(".ui-draggable");
const E=C.getAttribute("data-basis");var t=C.getAttribute("data-hash"),u=Ra(C).split("-");const A=parseInt(u[0]);var B=u[1]?parseInt(u[1]):null;u=Gb(E,t);t=14===A;var H=Hb(C);const G=Ib(C);var K=wb(C);const L=["12"];L.includes(String(A));y={p:y,yl:C,s:H,id:D,q:K,eo:A,fo:B,name:G,Qo:E};D=e.type.some(M=>L.includes(String(A))?M===E:M===E||M===String(A)||E.startsWith(`${M}-`));C=e.quality.map(Number).includes(Number(Ca(C)));u=!h&&u;if(m.has(G)||r.has(G))w=!0;K=k.some(M=>{var Z=M.prefix&&2<M.prefix.length?
M.prefix.toLowerCase():null;M=M.suffix&&2<M.suffix.length?M.suffix.toLowerCase():null;const ba=G.toLowerCase();Z=Z&&ba.includes(Z);M=M&&ba.includes(M);return Z||M});B=q.some(M=>G.toLowerCase().includes(M.toLowerCase()));H=n.some(M=>G.toLowerCase().includes(M.toLowerCase()));K=l&&K;l?!D||!C||K||w||B||H||u?D&&t&&!w&&!u&&R.g.push(y):R.g.push(y):D&&C&&!w&&!u?R.g.push(y):D&&t&&!w&&!u&&R.g.push(y)}),await Promise.all(v),0<R.g.length?(c.textContent=`Selling ${R.g.length} items...`,await R.$n()):(c.textContent=
"No items to sell. Please refresh the page.",b.classList.add("hidden"),R.enableButtons()),R.g=[]):(c.textContent="No items found in the current page.",b.classList.add("hidden")));else{c=document.getElementById("sellspinner");c.classList.remove("hidden");var v=document.getElementById("statusMessage");v||(v=document.createElement("div"),v.id="statusMessage",v.classList.add("status-message"),c.insertAdjacentElement("afterend",v));let y=0;for(let D=1;D<=Number(b);D+=10){const C=Array.from({length:Math.min(10,
b-D+1)},(E,t)=>D+t);console.log(`Fetching batch pages: ${C.join(", ")}`);v.textContent=`Reading pages ${C[0]} to ${C[C.length-1]}...`;await Promise.all(C.map(async E=>{g.page=E;try{const t=await fetch(I(g),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(A=>A.text()),u=jQuery(t).find(".packageItem");0<u.length&&(y+=u.length,u.each((A,B)=>{var H=jQuery(B).find("input").val(),G=jQuery(B).find(".ui-draggable")[0];const K=G.getAttribute("data-basis");
A=G.getAttribute("data-hash");var L=Ra(G).split("-");const M=parseInt(L[0]);var Z=L[1]?parseInt(L[1]):null;L=Gb(K,A);A=14===M;var ba=Hb(G),ha=wb(G);const ka=Ib(G).toLowerCase(),qa=["12"];qa.includes(String(M));B={p:B,yl:G,s:ba,id:H,q:ha,eo:M,fo:Z,name:ka,Qo:K};H=e.type.some(ca=>qa.includes(String(M))?ca===K:ca===K||ca===String(M)||K.startsWith(`${ca}-`));G=e.quality.map(Number).includes(Number(Ca(G)));L=!h&&L;if(m.has(ka)||r.has(ka))w=!0;ha=k.some(ca=>{var pa=ca.prefix&&2<ca.prefix.length?ca.prefix.toLowerCase():
null;ca=ca.suffix&&2<ca.suffix.length?ca.suffix.toLowerCase():null;const xa=ka.toLowerCase();pa=pa&&xa.includes(pa);ca=ca&&xa.includes(ca);return pa||ca});Z=q.some(ca=>ka.toLowerCase().includes(ca.toLowerCase()));ba=n.some(ca=>ka.toLowerCase().includes(ca.toLowerCase()));ha=l&&ha;l?!H||!G||w||ha||Z||ba||L?H&&A&&!w&&!L&&R.g.push(B):R.g.push(B):H&&!w&&G&&!L?R.g.push(B):H&&A&&!w&&!L&&R.g.push(B)}))}catch(t){}}));await new Promise(E=>setTimeout(E,1E3))}v.textContent=0<y?`Found ${y} items. Preparing to sell...`:
"No items found. Please adjust your filters.";0<R.g.length?(v.textContent=`Selling ${R.g.length} items...`,R.sellItems()):(c.classList.add("hidden"),v.textContent="No items to sell. Please change your selections and refresh the page.")}},sellItems(){R.stop&&window.location.reload();let b,c,e;const g=document.getElementById("sellspinner");g.classList.remove("hidden");let l=document.getElementById("statusMessage");l||(l=document.createElement("div"),l.id="statusMessage",l.classList.add("status-message"),
g.insertAdjacentElement("afterend",l));var h=document.getElementById("itemPreview");h||(h=document.createElement("div"),h.id="itemPreview",h.classList.add("item-preview"),l.insertAdjacentElement("afterend",h));try{b=R.g.shift(),c=R.ho,e=R.dn(b.yl)}catch{0<R.ma.length&&!e?R.useCloths():(g.classList.add("hidden"),l.textContent="All items sold. Reloading...",setTimeout(()=>window.location.reload(),2E3));return}if(e){var k=Ib(b.yl);l.textContent=`Selling: ${k} (${R.g.length} items left)`;h.innerHTML=
"";h.appendChild(b.p.cloneNode(!0));h=T({mod:"inventory",submod:"move",from:"-"+b.id,fromX:"1",fromY:"1",to:c.b,toX:c.x+1,toY:c.y+1,amount:b.q});k=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")});fetch(h,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:k}).then(q=>q.text()).then(()=>{var q=jQuery(b.yl).css({left:32*c.x,top:32*c.y});R.inv.appendChild(q[0]);q=T({mod:"inventory",submod:"move",from:c.b,fromX:c.x+1,fromY:c.y+
1,to:e.On,toX:e.spot.x+1,toY:e.spot.y+1,amount:b.q,doll:"1"});const n=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")});fetch(q,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:n}).then(m=>m.text()).then(m=>{jQuery(b.yl).remove();try{document.getElementById("sstat_gold_val").innerText=JSON.parse(m).header.gold.text}catch{}0<R.g.length?R.sellItems():(g.classList.add("hidden"),l.textContent="All items sold successfully!",
setTimeout(()=>0<R.ma.length?R.useCloths():window.location.reload(),2E3))})})}else 0<R.g.length?(R.ma.push(b),R.sellItems()):(g.classList.add("hidden"),l.textContent="All items sold. Reloading...",setTimeout(()=>0<R.ma.length?R.useCloths():window.location.reload(),2E3))},async useCloths(){if("true"===localStorage.getItem("useTriggerCloths")&&0<R.ma.length){R.g=R.ma;R.ma=[];var b=await fetch(I({mod:"inventory",sub:"1",subsub:"2",sh:W("sh")}),{method:"GET",credentials:"include"}).then(e=>e.text());
b=jQuery(b);if(b.find("#content form img")[0].src.includes("8.png")){var c=b.find("#content form input")[0];b=I({mod:"inventory",sub:"1",subsub:"2",sh:W("sh")});c=new URLSearchParams({[c.name]:c.value});await fetch(b,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(e=>e.text());await new Promise((e,g)=>{R.Rm(l=>{(R.nm=l)&&0<Object.keys(l).length?e():g("Failed to load shop grid data.")})});R.sellItems()}else window.location.reload()}else window.location.reload()},
async $n(){if(!R.stop){for(;0<R.g.length;){if(R.Nm){var b=await dc(2,3);R.spot=b.spot;R.bag=b.bag;R.Nm=!1}await new Promise(c=>setTimeout(c,10));b=R.g.splice(0,1).map(async c=>{var e=R.dn(c.yl);if(e){var g=T({mod:"inventory",submod:"move",from:"-"+c.id,fromX:"1",fromY:"1",to:R.bag,toX:R.spot.x+1,toY:R.spot.y+1,amount:c.q});const l=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")});g=await fetch(g,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:l}).then(h=>h.text());if(g.includes("Not possible")||g.includes("error"))R.Nm=!0;else if(e=T({mod:"inventory",submod:"move",from:R.bag,fromX:R.spot.x+1,fromY:R.spot.y+1,to:e.On,toX:e.spot.x+1,toY:e.spot.y+1,amount:c.q,doll:"1"}),g=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")}),e=await fetch(e,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:g}).then(h=>h.text())){jQuery(c.element).remove();
try{const h=JSON.parse(e).header.gold.text;document.getElementById("sstat_gold_val").innerText=h||""}catch(h){}}}else 0<R.g.length?R.ma.push(c):0<R.ma.length?await R.useCloths():window.location.reload()});await Promise.all(b);R.g=R.g.filter(c=>!R.ma.includes(c));await new Promise(c=>setTimeout(c,10))}0===R.g.length&&window.location.reload()}},dn(b){var c=parseInt(b.getAttribute("data-measurement-x"),10);b=parseInt(b.getAttribute("data-measurement-y"),10);for(var e in R.nm){var g=R.nm[e];if(!(isNaN(parseInt(e,
10))||1>g.Bm)){var l=nc(b,c,g.grid);if(l)return g.Bm-=c*b,g.items.push({y:l.y,x:l.x,ul:b,w:c}),g.grid=fc(8,6,g.items),{spot:l,On:e}}}},Rm(b){const c=[{sub:1,subsub:2},{sub:2,subsub:2},{sub:3,subsub:1},{sub:3,subsub:2},{sub:4,subsub:0},{sub:4,subsub:1},{sub:4,subsub:2},{sub:5,subsub:0},{sub:5,subsub:1},{sub:5,subsub:2},{sub:6,subsub:0},{sub:6,subsub:1},{sub:6,subsub:2}].map(g=>I({mod:"inventory",sh:W("sh"),...g})),e={};Promise.all(c.map((g,l)=>new Promise((h,k)=>{fetch(g,{method:"GET",credentials:"include",
headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(q=>q.text()).then(q=>{try{const n=jQuery(q).find("#shop")[0],m=n.getAttribute("data-container-number"),r=ec(n);e[m]={Bm:48-ac(r),grid:fc(8,6,r),items:r};h()}catch(n){k(n)}}).catch(q=>{k(Error(`Error loading shop grid ${l}: ${q}`))})}))).then(()=>{0<Object.keys(e).length&&b(e)}).catch(g=>console.error("Error in gsgriz:",g))}};if(window.location.href.includes("/index.php?mod=market")){let b=[];const c=document.querySelector("#market_filter");
if(c){const E=document.createElement("div");E.innerHTML=`
    <div class="custom-market-section">
        <div class="custom-market-header">${d.Fb}</div>
        <div class="custom-market-content">
            <div class="item-sell-form" id="item-sell-form">
                <span class="custom-market-footer">${d.kg}</span>
                <span class="custom-market-footer">${d.jg}</span>
    
                <div>
                    <label>${d.fa}:</label>
                    <input type="text" id="item-name" placeholder="${d.fa}">
                </div>
                <div>
                    <label>${d.Db}:</label>
                    <select id="item-color">
                        <option value="-1">${d.qa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.J}</option>
                        <option value="4">${d.T}</option>
                    </select>
                </div>
                <div>
                    <label>${d.L}:</label>
                    <input type="text" id="item-howmany" placeholder="${d.L}?">
                </div>
                <div>
                    <label>${d.M}:</label>
                    <input type="number" id="price-min" placeholder="${d.M}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="time-2h" value="1">2h</button>
                    <button id="time-8h" value="2">8h</button>
                    <button id="time-24h" value="3">24h</button>
                    <button id="time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Eb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="search-inventory"> &nbsp;${d.gg}</label>&nbsp;
                    <label><input type="checkbox" id="search-packages"> &nbsp;${d.lg}</label>&nbsp;
                </div>
    
                <button id="sell-item-btn">${d.Fb}</button>
                <div class="spinner3 hidden" id="loadingSpinner3"></div>
            </div>
    
            <!-- Material Sell Form -->
            <div class="material-sell-form hidden" id="material-sell-form">
                <div>
                    <label>Select Material:</label>
                        <select id="material-select">
                            <!-- Base Materials -->
                            <option value="1">${d.Pc}</option>
                            <option value="2">${d.Fc}</option>
                            <option value="4">${d.Jc}</option>
                            <option value="3">${d.Lc}</option>

                            <!-- Materials -->
                            <option value="13">${d.Qc}</option>
                            <option value="14">${d.Gc}</option>
                            <option value="15">${d.Ic}</option>
                            <option value="16">${d.Hc}</option>
                            <option value="17">${d.Mc}</option>
                            <option value="18">${d.Kc}</option>
                            <option value="19">${d.Oc}</option>
                            <option value="20">${d.Nc}</option>

                            <!-- Monster Parts -->
                            <option value="5">${d.Yc}</option>
                            <option value="6">${d.Sc}</option>
                            <option value="7">${d.ad}</option>
                            <option value="8">${d.Vc}</option>
                            <option value="9">${d.Xc}</option>
                            <option value="10">${d.Wc}</option>
                            <option value="11">${d.Tc}</option>
                            <option value="12">${d.$c}</option>
                            <option value="55">${d.Uc}</option>
                            <option value="58">${d.Zc}</option>
                            <option value="62">${d.bd}</option>
                            <option value="64">${d.cd}</option>

                            <!-- Gemstones -->
                            <option value="21">${d.Cc}</option>
                            <option value="22">${d.wc}</option>
                            <option value="23">${d.vc}</option>
                            <option value="24">${d.xc}</option>
                            <option value="25">${d.Dc}</option>
                            <option value="26">${d.Ac}</option>
                            <option value="27">${d.zc}</option>
                            <option value="28">${d.yc}</option>
                            <option value="59">${d.Bc}</option>
                            <option value="63">${d.Ec}</option>

                            <!-- Flasks -->
                            <option value="37">${d.qc}</option>
                            <option value="38">${d.tc}</option>
                            <option value="39">${d.mc}</option>
                            <option value="40">${d.lc}</option>
                            <option value="41">${d.sc}</option>
                            <option value="42">${d.pc}</option>
                            <option value="43">${d.nc}</option>
                            <option value="44">${d.oc}</option>
                            <option value="53">${d.uc}</option>
                            <option value="61">${d.rc}</option>

                            <!-- Runes -->
                            <option value="29">${d.Bd}</option>
                            <option value="30">${d.vd}</option>
                            <option value="31">${d.td}</option>
                            <option value="32">${d.Ad}</option>
                            <option value="33">${d.zd}</option>
                            <option value="34">${d.xd}</option>
                            <option value="35">${d.ud}</option>
                            <option value="36">${d.yd}</option>
                            <option value="60">${d.wd}</option>

                            <!-- Ores -->
                            <option value="45">${d.gd}</option>
                            <option value="46">${d.fd}</option>
                            <option value="47">${d.ld}</option>
                            <option value="48">${d.od}</option>
                            <option value="49">${d.pd}</option>
                            <option value="50">${d.jd}</option>
                            <option value="51">${d.nd}</option>
                            <option value="52">${d.md}</option>
                            <option value="54">${d.ed}</option>
                            <option value="56">${d.hd}</option>
                            <option value="57">${d.kd}</option>

                            <!-- Fragments -->
                            <option value="65">Material Fragment</option>
                            <option value="66">Monster Piece</option>
                            <option value="67">Gemstone Shard</option>
                            <option value="68">Flask Component</option>
                            <option value="69">Rune Splinter</option>
                            <option value="70">Ore Sample</option>
                            <option value="71">Scroll Fragment</option>

                        </select>
                </div>
                <div>
                    <label>${d.hg}:</label>
                    <select id="material-color">
                        <option value="-1">${d.qa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.J}</option>
                        <option value="4">${d.T}</option>
                    </select>
                </div>
                <div>
                    <label>${d.L}:</label>
                    <input type="text" id="mat-item-howmany" placeholder="${d.L}?">
                </div>
                <div>
                    <label>${d.M}:</label>
                    <input type="number" id="material-price-min" placeholder="${d.M}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="material-price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="material-time-2h" value="1">2h</button>
                    <button id="material-time-8h" value="2">8h</button>
                    <button id="material-time-24h" value="3">24h</button>
                    <button id="material-time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Eb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="material-search-warehouse"> &nbsp;${d.og}</label>&nbsp;
                </div>
    
                <button id="sell-material-btn">${d.ng}</button>
                <div class="spinner2 hidden" id="loadingSpinner2"></div>
            </div>
    
            <!-- Food Sell Form -->
            <div class="food-sell-form hidden" id="food-sell-form">
                <label>Level Range:</label>
                <div style="display: flex; gap: 5px;">
                    <input type="number" id="food-level-min" placeholder="Min Level" style="width: 100%;">
                    <input type="number" id="food-level-max" placeholder="Max Level" style="width: 100%;">
                </div>
                <div>
                    <label>${d.Db}:</label>
                    <select id="food-quality">
                        <option value="-1">${d.qa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.J}</option>
                        <option value="4">${d.T}</option>
                    </select>
                </div>
                <div>
                    <label>${d.L}:</label>
                    <input type="text" id="food-howmany" placeholder="${d.L}?">
                </div>
                <div>
                    <label>${d.M}:</label>
                    <input type="number" id="food-price-min" placeholder="${d.M}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="food-price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="food-time-2h" value="1">2h</button>
                    <button id="food-time-8h" value="2">8h</button>
                    <button id="food-time-24h" value="3">24h</button>
                    <button id="food-time-48h" value="4">48h</button>
                </div>
    
                <button id="sell-food-btn">${d.mg}</button>
                <div class="spinner3 hidden" id="loadingSpinner4"></div>
            </div>
    
            <div class="switch-section">${d.Aa}</div>
        </div>
    </div>
            `;c.insertAdjacentElement("afterend",E);document.getElementById("sell-item-btn").addEventListener("click",y);document.getElementById("sell-material-btn").addEventListener("click",D);document.getElementById("sell-food-btn").addEventListener("click",w);document.querySelector(".custom-market-header").addEventListener("click",l);document.querySelector(".switch-section").addEventListener("click",k);document.querySelectorAll(".time-selection button").forEach(t=>{t.addEventListener("click",function(){h(t,
t.textContent)})})}let e=["item-sell-form","material-sell-form","food-sell-form"],g=0;function l(){const E=document.querySelector(".custom-market-content"),t=document.querySelector(".custom-market-header");t.classList.toggle("collapsed");E.style.display=t.classList.contains("collapsed")?"none":"block";localStorage.setItem("sellItemsSectionCollapsed",t.classList.contains("collapsed"))}function h(E,t){E.parentElement.querySelectorAll("button").forEach(u=>{u.classList.remove("selected")});E.classList.add("selected");
localStorage.setItem("selectedTime_"+E.closest("div").parentElement.id,t)}function k(){e.forEach(t=>{document.getElementById(t).classList.add("hidden")});g=(g+1)%e.length;document.getElementById(e[g]).classList.remove("hidden");const E=document.querySelector(".switch-section");"item-sell-form"===e[g]?E.textContent=`${d.Aa}`:"material-sell-form"===e[g]?E.textContent=`${d.Gb}`:"food-sell-form"===e[g]&&(E.textContent=`${d.Hb}`);localStorage.setItem("currentSection",e[g])}async function q(E,t,u){return new Promise(async A=>
{let B=!1;const H=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));let G=0;for(let L=0;L<H.length&&!(G>=parseInt(u,10));L++){var K=H[L];if("false"!==K.getAttribute("data-available")){K.click();await new Promise(M=>setTimeout(M,175));K=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let M of K){if(G>=parseInt(u))break;M.getAttribute("data-basis");K=Ib(M);const Z=M.getAttribute("data-item-id"),ba=Ca(M);if(K.toLowerCase()===E.toLowerCase()&&t===ba){b.push(Z);B=!0;
G++;break}}if(B)break}}A(B)})}async function n(E,t,u,A,B){try{let H=1,G=parseInt(u,10);for(u=!1;1<=H&&2>=H&&!(0>=G);){const K=await fetch(I({mod:"packages",f:A?"18":"0",fq:t,qry:A?"":E,page:H.toString(),sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(M=>M.text()),L=Array.from(jQuery(K).find(".packageItem"));for(let M of L){if(0>=G)break;const Z=M.querySelector("[data-content-type]"),ba=M.querySelector("[data-container-number]"),
ha=Z.getAttribute("data-measurement-x"),ka=Z.getAttribute("data-measurement-y");let qa=Z.getAttribute("data-quality");const ca=Z.getAttribute("data-tooltip"),pa=ba.getAttribute("data-container-number"),xa=Ib(Z).toLowerCase();qa||(ca.includes("white")&&(qa="-1"),ca.includes("lime")&&(qa="0"));const $a=xa===E.toLowerCase()&&t===qa;if(A){const zb=Z.getAttribute("data-basis"),Ua=zb.startsWith("18")&&zb.split("-")[1]===B.toString();t===qa&&Ua&&(await v(pa,ha,ka),u=!0,G--)}else $a&&(await v(pa,ha,ka),u=
!0,G--)}H++}return u}catch(H){return!1}}async function m(E,t=-1,u){try{let A=!0,B=0;for(let H=0;H<parseInt(u,10)&&!(B>=u);H++){for(;B<parseInt(u,10);)try{const G=T({mod:"forge",submod:"storageOut",type:E,quality:t,amount:1,a:(new Date).getTime(),sh:W("sh")});await fetch(G,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(K=>K.text());await n(E,t,1,!0,E);B++;if(B>=parseInt(u,10))break}catch(G){B++}A=
!0}return A}catch(A){return!1}}async function r(E,t,u,A){try{let B=1,H=parseInt(A,10);for(A=!1;1<=B&&10>=B&&!(0>=H);){const G=await fetch(I({mod:"packages",f:"7",fq:u,qry:"",page:B.toString(),sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(L=>L.text()),K=Array.from(jQuery(G).find(".packageItem"));for(let L of K){if(0>=H)break;const M=L.querySelector("[data-content-type]"),Z=L.querySelector("[data-container-number]"),
ba=M.getAttribute("data-measurement-x"),ha=M.getAttribute("data-measurement-y"),ka=yb(M),qa=Ca(M);if(parseInt(ka)>=E&&parseInt(ka)<=t&&qa===u){const ca=Z.getAttribute("data-container-number");await v(ca,ba,ha);A=!0;H--}}B++}return A}catch(B){return!1}}async function w(){var E=parseInt(document.getElementById("food-level-min").value,10);const t=parseInt(document.getElementById("food-level-max").value,10),u=document.getElementById("food-quality").value,A=parseInt(document.getElementById("food-howmany").value,
10),B=parseInt(document.getElementById("food-price-min").value,10),H=parseInt(document.getElementById("food-price-max").value,10),G=document.getElementById("loadingSpinner4");if(isNaN(E)||isNaN(t)||E>t||isNaN(B)||isNaN(H)||B>H||1>A)alert(`${d.xa}`);else{G.style.display="block";try{let ba=!1;if(ba=await r(E,t,u,A)){var K=document.querySelector("#food-sell-form .time-selection button.selected"),L=K?parseInt(K.value,10):2,M=document.querySelector('input[name="anbieten"]'),Z=M?M.value:"Offer";for(E=0;E<
b.length;E++){const ha=b[E],ka=B===H?B:Math.floor(Math.random()*(H-B+1))+B,qa=I({mod:"market",sh:W("sh")}),ca=new URLSearchParams({sellid:ha,preis:ka,dauer:L,anbieten:Z});await fetch(qa,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:ca}).then(pa=>pa.text())}b=[];alert(`${d.za}`);await new Promise(ha=>setTimeout(ha,250));Pf("mod=market&f=7")}else alert(`${d.ya}`)}catch(ba){}finally{G.style.display="none"}}}async function v(E,
t,u){try{let {spot:A,bag:B}=await dc(t,u);const H=T({mod:"inventory",submod:"move",from:E,fromX:1,fromY:1,to:B,toX:A.x+1,toY:A.y+1,amount:1,a:(new Date).getTime(),sh:W("sh")}),G=await fetch(H,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(L=>L.text()),K=JSON.parse(G).to.data.itemId;b.push(K);return!0}catch(A){return!1}}async function y(){const E=document.getElementById("item-name").value;var t=
document.getElementById("item-color").value;const u=document.getElementById("item-howmany").value,A=parseInt(document.getElementById("price-min").value,10),B=parseInt(document.getElementById("price-max").value,10),H=document.getElementById("loadingSpinner3"),G=document.getElementById("search-inventory").checked,K=document.getElementById("search-packages").checked;if(!E||isNaN(A)||isNaN(B)||A>B||1>u)alert(`${d.xa}`);else{H.style.display="block";try{let ha=!1;G&&(ha=await q(E,t,u));!ha&&K&&(ha=await n(E,
t,u));if(ha){var L=document.querySelector(".time-selection button.selected"),M=L?parseInt(L.value,10):2,Z=document.querySelector('input[name="anbieten"]'),ba=Z?Z.value:"Offer";for(t=0;t<b.length;t++){const ka=b[t],qa=A===B?A:Math.floor(Math.random()*(B-A+1))+A,ca=I({mod:"market",sh:W("sh")}),pa=new URLSearchParams({sellid:ka,preis:qa,dauer:M,anbieten:ba});await fetch(ca,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:pa}).then(xa=>
xa.text())}b=[];alert(`${d.za}`);await new Promise(ka=>setTimeout(ka,250));Pf("mod=market&qry="+E)}else alert(`${d.ya}`)}catch(ha){}finally{H.style.display="none"}}}async function D(){var E=document.getElementById("material-select").value,t=document.getElementById("material-select");t=t.options[t.selectedIndex].textContent;const u=document.getElementById("material-color").value,A=document.getElementById("mat-item-howmany").value,B=parseInt(document.getElementById("material-price-min").value,10),H=
parseInt(document.getElementById("material-price-max").value,10),G=document.getElementById("loadingSpinner2"),K=document.getElementById("material-search-warehouse").checked;if(!E||isNaN(B)||isNaN(H)||B>H||1>A)alert(`${d.xa}`);else{G.style.display="block";try{let ha=!1;K&&(ha=await m(E,u,A));if(ha){var L=document.querySelector("#material-sell-form .time-selection button.selected"),M=L?parseInt(L.value,10):2,Z=document.querySelector('input[name="anbieten"]'),ba=Z?Z.value:"Offer";for(E=0;E<b.length;E++){const ka=
b[E],qa=B===H?B:Math.floor(Math.random()*(H-B+1))+B,ca=I({mod:"market",sh:W("sh")}),pa=new URLSearchParams({sellid:ka,preis:qa,dauer:M,anbieten:ba});await fetch(ca,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:pa}).then(xa=>xa.text())}b=[];alert(`${d.za}`);await new Promise(ka=>setTimeout(ka,250));Pf("mod=market&qry="+t)}else alert(`${d.ya}`)}catch(ha){}finally{G.style.display="none"}}}const C=localStorage.getItem("currentSection");
if(C&&e.includes(C)){e.forEach(t=>{document.getElementById(t).classList.add("hidden")});document.getElementById(C).classList.remove("hidden");g=e.indexOf(C);const E=document.querySelector(".switch-section");"item-sell-form"===e[g]?E.textContent=`${d.Aa}`:"material-sell-form"===e[g]?E.textContent=`${d.Gb}`:"food-sell-form"===e[g]&&(E.textContent=`${d.Hb}`)}else document.getElementById("item-sell-form").classList.remove("hidden"),g=0;e.forEach(E=>{const t=localStorage.getItem("selectedTime_"+E);t&&
document.querySelectorAll("#"+E+" .time-selection button").forEach(u=>{u.textContent===t&&u.classList.add("selected")})});"true"===localStorage.getItem("sellItemsSectionCollapsed")&&(document.querySelector(".custom-market-header").classList.add("collapsed"),document.querySelector(".custom-market-content").style.display="none")}if(window.location.href.includes("/index.php?mod=guild")){const b=document.querySelectorAll("form");for(const c of b){const e=c.getAttribute("action");e&&e.includes("submod=create")&&
localStorage.setItem("resetExpiredItems","false")}}if(window.location.href.includes("/index.php?mod=packages&")){let b=jQuery(".section-header").first();b&&(function(){var c="true"===localStorage.getItem("packages_hidden");let e=`

<section class="custom_packages" style="display: block; box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
<div style="text-align: center">
    <button class="awesome-button" packageCmd data-button="pickAll">
    ${d.zj}
    </button>
    <button class="awesome-button" packageCmd data-button="pickAllSelected">
    ${d.Aj}
    </button>
    <button class="awesome-button" pakageCmd data-button="sellThisPage">
    ${d.Dj}
    </button>
    <button
    class="awesome-button" data-button="SASTM" pakageCmd data-name="SASTM"
>
${d.Bj}
</button>
    <button class="awesome-button" data-button="stop">${d.Fj}</button>
    <button class="awesome-button" packageCmd data-button="SARTH">
    ${d.Ej}
    </button>
</div>

<style>

    .awesome-button:hover {
        background-color: #444;
        color: #fff; 
    }

    .progress-container {
      width: 100%;
      height: 20px;
      background-color: #f3f3f3;
      position: relative;
      border-radius: 15px;
      margin: 10px 0;
    }
  
    .progress-bar {
      width: 0;
      height: 100%;
      background-color: #4caf50;
      position: absolute;
      border-radius: 15px;
      transition: width 0.4s ease-in-out;
    }
  
    .page-indicator {
      text-align: center;
      position: absolute;
      width: 100%;
      top: 50%;
      transform: translateY(-50%);
      font-size: 12px;
    }

</style>

    <fieldset style="box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
        <legend>${d.Cj}</legend>
        <table style="width: 100%; text-align: center">
            <tbody>
                <tr>
                    <td>
                    </td>
                    

                    <div id="sellspinner" class="spinnerNew hidden"></div>
                    <div id="statusMessage" class="status-message">Status</div>
                    <div id="itemPreview" class="item-preview">
                        <div class="item"></div>
                    </div>

                    <td>
                        <input
                            type="checkbox"
                            data-button="switch"
                            data-name-ek="packages"
                            data-name="UCOTH"
                            style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        /><span class="span-new">${d.Jj}</span>
                        <hr>
                        <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="useSmeltFilter"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       /><span class="span-new">${d.ne}</span>
                       <hr>
                       <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="sellUnderworld"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       />
                       <span class="span-new">${d.Oj}</span>
                       <hr>
                        <div class="setting-row">
                        <label for="getGold">${d.Si}</label>
                        <div class="switch-field3">
                          
                          <input type="number" id="getGold" min="1000" max="200000000" placeholder="Amount">
                          <button id="ConfirmGetGold" class="awesome-button">OK</button>
                          <span class="span-new" id="goldMovedIndicator">${d.bf}: 0</span>
                        </div>
                      </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </fieldset>
    <fieldset>
        <legend>${d.na}</legend>
    <table>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="1" title="Weapons">
      <img class="item-i-1-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="2" title="Shields">
      <img class="item-i-2-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="3" title="Armor">
      <img class="item-i-3-3">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="4" title="Helmets">
      <img class="item-i-4-7">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="5" title="Gloves">
      <img class="item-i-5-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="8" title="Boots">
      <img class="item-i-8-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="6" title="Rings">
      <img class="item-i-6-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="9" title="Necklaces">
      <img class="item-i-9-1">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="7" title="Food">
      <img class="item-i-7-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12" title="Upgrades">
      <img class="item-i-12-2">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="13" title="Recipes">
      <img class="item-i-13-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="15" title="Mercenaries">
      <img class="item-i-15-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="19" title="Tools">
      <img class="item-i-19-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="20" title="Scrolls">
      <img class="item-i-20-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="11" title="Reinforcements">
      <img class="item-i-11-17">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="21" title="Event Items">
      <img class="item-i-21-1">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="18" title="Forging Goods">
      <img class="item-i-18-1">
    </td>

    <!-- Powders -->
    
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-10" title="Green Powder">
      <img class="item-i-12-10">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-6" title="Blue Powder">
      <img class="item-i-12-6">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-17" title="Red Powder">
      <img class="item-i-12-17">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-14" title="Purple Powder">
      <img class="item-i-12-14">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-8" title="Yellow Powder">
      <img class="item-i-12-8">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-12" title="Orange Powder">
      <img class="item-i-12-12">
    </td>

    <!-- Dust -->
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-7" title="Yellow Powder">
      <img class="item-i-12-7">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-5" title="Blue Powder">
      <img class="item-i-12-5">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-16" title="Red Powder">
      <img class="item-i-12-16">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-9" title="Green Powder">
      <img class="item-i-12-9">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-11" title="Orange Powder">
      <img class="item-i-12-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-13" title="Purple Powder">
      <img class="item-i-12-13">
    </td>

    <!-- Oils -->
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-18" title="Purple Oil">
      <img class="item-i-12-18">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-19" title="Yellow Oil">
      <img class="item-i-12-19">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-20" title="Orange Oil">
      <img class="item-i-12-20">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-21" title="Green Oil">
      <img class="item-i-12-21">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-22" title="Blue Oil">
      <img class="item-i-12-22">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-23" title="Red Oil">
      <img class="item-i-12-23">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="14" title="Gold">
      <img class="item-i-14-1">
    </td>

      <td class="item-checkbox select-all" data-button="packageAll" data-name="type" title="Select All">
        <div class="select-all-content">
          <span class="select-all-text">ALL</span>
        </div>
      </td>

</table>

    </fieldset>
    <fieldset>
        <legend>Quality</legend>
        <table style="width: 100% box-shadow: 0px 5px 10px rgba(0,0,0,0.15);">
            <tbody>
              <tr>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="-1" title="White" style="background-color: white; "></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="0" title="Green" style="background-color: green;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="1" title="Blue" style="background-color: blue;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="2" title="Purple" style="background-color: purple;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="3" title="Orange" style="background-color: orange;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="4" title="Red" style="background-color: red;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box select-all" data-button="packageAll" data-name="quality" data-value="99" title="All" style="background: linear-gradient(45deg, red, orange, yellow, green, blue, purple); border: 1px solid #ccc;"></div>
                </td>
                </tr>
            </tbody>
        </table>
    </fieldset>
</section>
`;b.before(`
                <h2 class="section-header" style="cursor: pointer" id="hidePackges">
                ${d.Gj}
                </h2>`);b.before(e);c&&(c=document.querySelector(".custom_packages"),c.style.display="none"===c.style.display?"block":"none")}(),$(".custom-button:contains('sell all selected to merchants')").click(async function(){await R.sastm()}));R.start()}if(window.location.href.includes("mod=auction")){localStorage.getItem("auctionPrefixes")||localStorage.setItem("auctionPrefixes",JSON.stringify([]));localStorage.getItem("prefixes")||localStorage.setItem("prefixes",JSON.stringify([]));localStorage.getItem("searchTerms")||
localStorage.setItem("searchTerms",JSON.stringify([]));const b=document.getElementById("auction_table");let c;b&&(c=b.querySelectorAll(".auction_item_div"));const e=localStorage.getItem("highlightedItemHash");if(e){const g=document.querySelector(`form:has(div[data-hash="${e}"])`);g&&(g.style.outline="3px solid red",g.style.outlineOffset="4px",g.style.boxShadow="0 0 10px rgba(0, 0, 0, 0.5)",g.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"}),localStorage.removeItem("highlightedItemHash"))}if(!c||
0===c.length)return;c.forEach(g=>{g.style.position="relative";g.style.height="106px";const l=document.createElement("span");l.className="auction-icon";l.innerHTML="\ud83d\udd28";l.title="Add to Auction List";l.style.cursor="pointer";l.style.fontSize="16px";l.style.marginTop="88px";l.style.display="inline-block";l.style.marginRight="-25px";const h=document.createElement("span");h.className="smelt-icon";h.innerHTML="\ud83d\udd25";h.title="Add to Smelting List";h.style.cursor="pointer";h.style.fontSize=
"16px";h.style.marginTop="88px";h.style.display="inline-block";let k=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],q=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],n=JSON.parse(localStorage.getItem("smeltingSettings"))||[];const m=g.querySelector("[data-tooltip]"),r=m?m.getAttribute("data-tooltip"):null;if(r){var {itemName:w,xn:v,yn:y,itemColor:D,itemType:C,itemLevel:E,rn:t}=lh(r,m);try{JSON.parse(r.replace(/&quot;/g,'"'))}catch(u){return}w&&(k.includes(v)&&q.includes(y)&&(l.innerHTML=
"\u2705"),n.some(u=>{const A=""===u.prefix||v.includes(u.prefix),B=""===u.suffix||y.includes(u.suffix);u="white"===D||u.colors.includes(D);return A&&B&&u})&&(h.innerHTML="\u2705"),l.addEventListener("click",()=>{let u=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],A=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];JSON.parse(localStorage.getItem("searchTerms"));u.includes(v)||(u.push(v),localStorage.setItem("auctionPrefixes",JSON.stringify(u)));A.includes(y)||(A.push(y),localStorage.setItem("auctionSuffixes",
JSON.stringify(A)));bb(`Item "${w[0]}" added to the auction list!`);l.innerHTML="\u2705";setTimeout(()=>{l.innerHTML="\ud83d\udd28"},1E3)}),h.addEventListener("click",()=>{const u={condition:"nameContains",prefix:v,suffix:y,rm:t,colors:["white","green"],itemTypes:[C],hammerState:"none",level:E,isEnabled:!0};let A=JSON.parse(localStorage.getItem("smeltingSettings"))||[];A.push(u);localStorage.setItem("smeltingSettings",JSON.stringify(A));bb(`Item "${w[0]}" added to the smelting list!`);h.innerHTML=
"\u2705"}),g.appendChild(h),g.appendChild(l))}})}if(window.location.href.includes("mod=packages")){await new Promise(e=>setTimeout(e,1E3));["auctionPrefixes","prefixes","searchTerms"].forEach(e=>{localStorage.getItem(e)||localStorage.setItem(e,JSON.stringify([]))});const b=document.getElementById("packages");if(!b)return;const c=b.querySelectorAll(".packageItem");if(!c||0===c.length)return;c.forEach(e=>{const g=kh("\ud83d\udd28","auction-icon","pointer","16px","1px",`${d.Ni}`),l=kh("\ud83d\udd25",
"smelt-icon","pointer","16px","40px",`${d.dk}`),h=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],k=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],q=JSON.parse(localStorage.getItem("smeltingSettings"))||[],n=e.querySelector("[data-tooltip]"),m=n?n.getAttribute("data-tooltip"):null;if(m){var {itemName:r,xn:w,yn:v,itemColor:y,itemType:D,itemLevel:C,rn:E}=lh(m,n);if(r){if(h.includes(w)||k.includes(v))g.innerHTML="\u2705";q.some(t=>{const u=""===t.prefix||w.includes(t.prefix),A=""===
t.suffix||v.includes(t.suffix);t="white"===y||t.colors.includes(y);return u&&A&&t})&&(l.innerHTML="\u2705");g.addEventListener("click",()=>{let t=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],u=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];t.includes(w)||(t.push(w),localStorage.setItem("auctionPrefixes",JSON.stringify(t)));u.includes(v)||(u.push(v),localStorage.setItem("auctionSuffixes",JSON.stringify(u)));bb(`Item "${r[0]}" added to the auction list!`);g.innerHTML="\u2705"});
l.addEventListener("click",()=>{const t={condition:"nameContains",prefix:w,suffix:v,rm:E,colors:"white"===y?["white","green"]:[y],itemTypes:[D],hammerState:"none",level:C||1,isEnabled:!0},u=JSON.parse(localStorage.getItem("smeltingSettings"))||[];u.push(t);localStorage.setItem("smeltingSettings",JSON.stringify(u));bb(`Item "${r[0]}" added to the smelting list!`);l.innerHTML="\u2705"});if(e=e.querySelector('[data-no-combine="true"]'))e.appendChild(g),e.appendChild(l)}}})}var nb={A:{async start(){const b=
JSON.parse(localStorage.getItem("Timers"));if(!W("mod")||"auction"!==W("mod")){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(g=>c[g]).filter(g=>void 0!==g);if(0<e.length){Pf(`mod=auction&itemType=${e[0]}`);return}}nb.A.I=[];nb.A.sl=Math.floor(Jh().gold-Number(localStorage.getItem("storeGoldinAuctionholdGold")));nb.A.form=document.querySelectorAll("#auction_table form");nb.A.sl&&await this.list(async()=>
{0<this.I.length?await this.buy():this.ap(b)})},async ap(b){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(q=>c[q]).filter(q=>void 0!==q);0===e.length&&(F("Auction Store: No valid auction types selected."),Y("enableHideGold",b.AuctionHoldGold||5),window.location.reload());const g=parseInt(W("itemType"),10),l=W("ttype"),h=e.indexOf(g),k=h===e.length-1;"3"===l?k?(F("Auction Store: Last type reached, reloading and setting timeout for next cycle."),
Y("enableHideGold",b.AuctionHoldGold||5),window.location.reload()):Pf(`mod=auction&itemType=${e[h+1]}`):-1!==h&&(F("Auction Store: Toggling to mercenary mode for current type:",g),Pf(`mod=auction&itemType=${g}&ttype=3`))},async list(b=!1){F(`${d.Nf}`);var c=this.sl;const e="true"===localStorage.getItem("AuctionGoldCover");let g=[];const l=localStorage.getItem("storeInShopQuality")||-1;for(let q=0;q<this.form.length;q++){let n=this.form[q];var h=n.querySelector(".ui-draggable"),k=n.querySelector(".auction_bid_div");
k=(k=k?k.querySelector('input[type="text"], input[type="number"]'):null)?Number(k.value):0;h=h?Jb(h):0;k<=h&&k<=c&&g.push({ka:n,price:parseInt(k,10),value:h})}g.sort((q,n)=>n.price-q.price);for(let q of g)if(c=q.ka.querySelector(".ui-draggable").getAttribute("data-quality"),!(Number(c)<Number(l))){if(c=(c=(c=q.ka.querySelector(".auction_bid_div"))?c.querySelector("div > a"):null)?c.querySelector("span"):null){c=c.getAttribute("style");if(e&&c&&c.includes("green"))continue;if(!e&&c&&c.includes("green"))return!0;
if(c&&c.includes("blue"))continue}nb.A.I.push([q.ka.getAttribute("action"),{auctionid:q.ka.querySelector('input[name="auctionid"]').value,qry:q.ka.querySelector('input[name="qry"]').value,itemType:q.ka.querySelector('input[name="itemType"]').value,itemLevel:q.ka.querySelector('input[name="itemLevel"]').value,itemQuality:q.ka.querySelector('input[name="itemQuality"]').value,buyouthd:q.ka.querySelector('input[name="buyouthd"]').value,bid_amount:q.price,bid:q.ka.querySelector('input[name="bid"]').value}])}b&&
await b()},async buy(){let b=nb.A.I.pop();const c=new URLSearchParams({...b[1],csrf_token:x()});await fetch(b[0],{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(e=>e.text());0<nb.A.I.length?(await new Promise(e=>setTimeout(e,100)),await this.buy()):window.location.reload()}}},xh=localStorage.getItem("OillastRan"),yh=Date.now(),Qa={H:"minerva diana vulcanus mars apollo merkur".split(" "),qo:[20,60,150,0],kn:[],async start(){"mod=gods"!=
tf?Pf("mod=gods"):Qa.Xm(0)},no(){let b=(new Date).getTime(),c=aa.H.Rn?aa.H.Rn:[1];if(5>c.length)return!0;for(let e=0;e<c.length;e++)if(c[e]&&c[e]<b||!c[e]&&(0==aa.H[Qa.H[e]]&&!aa.H.vn||1==aa.H[Qa.H[e]]||2==aa.H[Qa.H[e]])||!c[e]&&aa.H.vn&&Va.isUnderworld()&&1<=aa.an.wins)return!0;return!1},async Ao(){var b=cb.origin;const c=cb.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);return(new DOMParser).parseFromString(await b.text(),"text/html")},async Xm(b,c){if(c){var e=
JSON.parse(localStorage.getItem("gods")),g=this.H[b],l=c.getElementById(g);l&&(c=parseInt(l.querySelector(".god_points").innerText.match(/\d+/)[0],10),l=l.querySelector(".god_cooldown span")?parseInt(l.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0,e=e[g],g=this.qo[e],c>=g&&0==l&&0<g&&0<=e&&(Qa.kn.push(!1),fetch(I({mod:"gods",submod:"activateBlessing",god:b+1,rank:e+1,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()}}).then(h=>h.text()).then(()=>{Qa.kn.push(!1);5>b&&Qa.Xm(++b)})))}},Aq(b){b=b.getAttribute("data-tooltip");return b?(b=b.match(/(\d{1,2}):(\d{2})\s?h/))?(parseInt(b[1],10)||0)+(parseInt(b[2],10)||0)/60:0:0},mq(b){const c=JSON.parse(localStorage.getItem("oilCooldowns")||"{}");return c[b]?Date.now()<c[b]:!1},Hq(b,c){const e=JSON.parse(localStorage.getItem("oilCooldowns")||"{}");e[b]=Date.now()+36E5*c;localStorage.setItem("oilCooldowns",JSON.stringify(e))},zo(b){b=b.match(/new\s+BagLoader\([\s\S]*?JSON\.parse\(\s*'([^']*)'\s*\)/);
if(!b)return console.log("Could not find JSON.parse(...) in the overview HTML"),null;b=b[1];b=b.replace(/\\"/g,'"');b=b.replace(/\\\\/g,"\\");let c=null;try{c=JSON.parse(b)}catch(e){return console.error("Error parsing bagData JSON:",e),null}return c},async Go(){let b=[];const c={"12-18":"purple","12-19":"yellow","12-20":"orange","12-21":"green","12-22":"blue","12-23":"red"};try{const e=await fetch(I({mod:"overview",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()}}).then(k=>k.text()),g=this.zo(e);if(!g)return F("No bagData found in overview"),b;const l=g.flat(5),h=Object.keys(c);l.forEach(k=>{if("string"===typeof k&&h.some(n=>k.includes(`data-basis="${n}"`))){var q=jQuery(k).filter(function(){const n=jQuery(this).attr("data-basis");return h.includes(n)});q.length&&b.push(...q.toArray())}})}catch(e){F(`Error in getInventoryOilsFromOverview: ${e}`)}F(`Found ${b.length} oil items in inventory`);return b},async hn(b,c){try{const e=jQuery(b).attr("data-container-number"),
g=jQuery(b).attr("data-position-x"),l=jQuery(b).attr("data-position-y");await new Promise(k=>setTimeout(k,250));const h=T({mod:"inventory",submod:"move",from:e,fromX:g,fromY:l,to:c,toX:1,toY:1,amount:1,doll:1,a:Date.now(),sh:W("sh")});await fetch(h,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(k=>k.text());F(`Applied oil (basis=${jQuery(b).attr("data-basis")}) to slot container=${c}`);return!0}catch(e){return F(`Error applying oil to container ${c}: ${e}`),
!1}},wn(b,c){return(b=b.find(e=>e.po===c))?b.Po?!1:!0:!0},async aq(){var b=await fetch(I({mod:"overview",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(e=>e.text());b=jQuery(b).find("#char");if(!b.length)return console.log("No #char found in overview"),[];let c=[];b.find(".item-i-").each(function(){var e=jQuery(this);const g=e.attr("data-container-number")||"",l=e.attr("data-basis")||"";e=e.attr("data-tooltip")||
"";const h=e.includes("data-ticker-time-left");c.push({containerNumber:g,io:l,tooltip:e,hq:h})});return c},async Pm(){var b=await fetch(I({mod:"overview",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(e=>e.text());b=jQuery(b).find("#char");if(!b.length)return F("No #char found in overview"),[];const c=[];b.find('[class^="item-i-"]').each(function(){var e=jQuery(this);const g=e.attr("data-container-number")||"",
l=e.attr("data-basis")||"";e=e.attr("data-tooltip")||"";const h=e.includes("data-ticker-time-left");c.push({po:g,io:l,tooltip:e,Po:h})});return c},async Ep(b,c){try{const e=b.getAttribute("data-container-number"),g=b.getAttribute("data-position-x"),l=b.getAttribute("data-position-y");await new Promise(k=>setTimeout(k,250));const h=T({mod:"inventory",submod:"move",from:e,fromX:parseInt(g,10),fromY:parseInt(l,10),to:c,toX:1,toY:1,amount:1,doll:1,a:Date.now(),sh:W("sh")});await fetch(h,{method:"POST",
credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(k=>k.text());F(`Applied oil from inventory to slot ${c}`);return!0}catch(e){return F(`Error applying oil from inventory: ${e}`),!1}},async lp(){const b=JSON.parse(localStorage.getItem("oilUsagePrefs")||"{}");if(b.oilEnable){var c={"12-18":"purple","12-19":"yellow","12-20":"orange","12-21":"green","12-22":"blue","12-23":"red"},e={purple:{rings:"purpleRings",necklace:"purpleNecklace",
weapon:"purpleWeapons",armor:"purpleArmor"},Sq:{rings:"yellowRings",necklace:"yellowNecklace",weapon:"yellowWeapons",armor:"yellowArmor"},orange:{rings:"orangeRings",necklace:"orangeNecklace"},green:{rings:"greenRings",necklace:"greenNecklace",weapon:"greenWeapons",armor:"greenArmor"},blue:{rings:"blueRings",necklace:"blueNecklace"},red:{rings:"redRings",necklace:"redNecklace"}},g=await this.Pm(),l=await this.Go();for(const q of l){l=jQuery(q);var h=l.attr("data-basis"),k=c[h];h=!1;if(!k)continue;
const n=e[k];if(n){k=Object.keys(n);for(const m of k)if(b[n[m]]){if("rings"===m){k=["6","7"];for(const r of k)if(this.wn(g,r)&&await this.hn(l,r)){h=!0;g=await this.Pm();break}}else{k=null;switch(m){case "armor":k="5";break;case "weapon":k="3";break;case "necklace":k="11"}if(!k)continue;if(!this.wn(g,k))continue;await this.hn(l,k)&&(h=!0,g=await this.Pm())}if(h)break}}else F(`No slot mapping for oil color: ${k}`)}F("Done attempting to apply oils.")}else F("Oil usage not enabled, skipping...")},async sq(b,
c){try{const e=b.closest(".packageItem").find('input[name="packages[]"]').val(),g=b.getAttribute("data-position-x"),l=b.getAttribute("data-position-y");let {spot:h,bag:k}=await dc(1,1);await new Promise(m=>setTimeout(m,250));const q=T({mod:"inventory",submod:"move",from:"-"+e,fromX:g,fromY:l,to:k,toX:h.x+1,toY:h.y+1,amount:1,doll:1,a:Date.now(),sh:W("sh")});await fetch(q,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(m=>
m.text());await new Promise(m=>setTimeout(m,250));const n=T({mod:"inventory",submod:"move",from:k,fromX:h.x+1,fromY:h.y+1,to:c,toX:1,toY:1,amount:1,doll:1,a:Date.now(),sh:W("sh")});await fetch(n,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(m=>m.text());F("Oil items used on equipments.");return!0}catch(e){F(`Error in this.moveAndApplyOil: ${e}`)}},async Np(){var b=cb.origin,c=cb.searchParams.get("sh")||
"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);c=new DOMParser;await new Promise(e=>setTimeout(e,800));b=c.parseFromString(await b.text(),"text/html");c=JSON.parse(localStorage.getItem("gods"));for(let e in c)if((c=b.getElementById(e))&&0===(c.querySelector(".god_cooldown span")?parseInt(c.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0))return!0;return!1}},mh,Jj={async start(){const b=localStorage.getItem("healPercentage")||25;var c=JSON.parse(localStorage.getItem("underworld")).isUnderworld;
const e=localStorage.getItem("HealEnabled"),g=localStorage.getItem("HellHealHP")||15,l=localStorage.getItem("useVillaMedici"),h=localStorage.getItem("useHealingPotion"),k="true"===localStorage.getItem("usePray");if("true"==e&&da.o<=Number(b)||"true"==e&&da.o<=parseInt(g)||"true"==l&&aa.player.key==ya&&da.o<=b&&1==c||e&&"true"==h&&da.o<=b&&1==c||e&&!c&&3>=Number(Jh().Ha)&&localStorage.getItem("autoEnterHell")&&da.o<=localStorage.getItem("hellEnterHP")){c=document.createElement("div");c.setAttribute("id",
"lowHealth");c.setAttribute("style","\n                display: block;\n                position: absolute;\n                top: 140px;\n                left: 50%;\n                transform: translateX(-30%);\n                width: 115px;\n                color: rgba(234, 20, 20, 0.9);\n                background-color: rgba(0, 0, 0, 0.8);\n                font-size: 20px;\n                border-radius: 5px;\n                border-left: 10px solid rgba(234, 20, 20, 0.9);\n                border-right: 10px solid rgba(234, 20, 20, 0.9);\n                will-change: transform, opacity;\n                z-index: 999;\n            ");
c.innerHTML='<span class="span-new">Low Health!</span>';document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);async function q(){if("inventoryPage"!==document.body.id)Pf("mod=inventory&sub=3&subsub=1");else{await new Promise(L=>setTimeout(L,500));var C=Array.from(document.querySelectorAll("#shop .ui-draggable"));const t=da.gold,u=cb.searchParams.get("doll")||"";let A=!1,B=0,H=!1,G;var E=localStorage.getItem("HealPickBag");E&&(G=511+Number(E)||512);
for(const L of C){if(B>=Number(localStorage.getItem("FoodAmount")))break;C=parseInt(L.getAttribute("data-price-gold"),10);(E=(E=L.getAttribute("data-basis"))&&"7"===E.split("-")[0])&&(A=!0);if(t>=C&&E){A=!0;localStorage.removeItem("healingStateX");C=Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));if(G&&(E=document.querySelector(`#inventory_nav a.awesome-tabs[data-bag-number="${G}"]`)))if(E.click(),await new Promise(M=>setTimeout(M,370)),E=document.getElementById("inv"),
Nc(E,L)){fa(L,"inv");B++;await new Promise(M=>setTimeout(M,370));if(B>=Number(localStorage.getItem("FoodAmount"))&&"1"!==u){Pf("mod=overview&doll=1");return}continue}else H=!0;if(H||!G)for(const M of C){if(B>=Number(localStorage.getItem("FoodAmount")))break;M.click();await new Promise(Z=>setTimeout(Z,500));C=document.getElementById("inv");if(Nc(C,L)&&(fa(L,"inv"),B++,await new Promise(Z=>setTimeout(Z,370)),B>=Number(localStorage.getItem("FoodAmount"))&&"1"!==u)){Pf("mod=overview&doll=1");return}}}}A?
(F(`${d.ub}`),localStorage.removeItem("healingStateX"),await new Promise(L=>setTimeout(L,3E4)),window.location.reload()):"true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")?await K():(F(`${d.ub}`),localStorage.removeItem("healingStateX"),await new Promise(L=>setTimeout(L,3E4)),window.location.reload());async function K(){if("true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")){if(Array.from(document.getElementsByTagName("img")).some(ba=>
ba.src.includes("8.png"))){var L=jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),M=L.attr("action");L=L.find('input[name="bestechen"]')[0];var Z=W("sh");"";M=`${M}?mod=inventory&sub=3&subsub=1&sh=${Z}`;L=new URLSearchParams({bestechen:L.value});await fetch(M,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:L}).then(ba=>ba.text())?F(`${d.wb}`):F(`${d.xb}`)}else 0<Jh().Mn&&"true"===localStorage.getItem("HealRubyToggle")&&
!Array.from(document.getElementsByTagName("img")).some(ba=>ba.src.includes("8.png"))?(L=jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),M=L.attr("action"),L=L.find('input[name="bestechen"]')[0],Z=W("sh"),M=`${M}?mod=inventory&sub=3&subsub=1&sh=${Z}`,L=new URLSearchParams({bestechen:L.value}),await fetch(M,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:L}).then(ba=>ba.text())?F(`${d.wb}`):F(`${d.xb}`)):(F(`${d.Kf}`),
localStorage.setItem("HealClothToggle","false"),localStorage.setItem("HealRubyToggle","false"));window.location.reload()}else localStorage.removeItem("healingStateX"),setTimeout(()=>{window.location.reload()},6E4)}return!1}}async function n(){if("guild"==W("mod"))localStorage.setItem("useVillaMedici","false"),Pf("mod=overview");else if("guild_medic"!=W("mod"))Pf("mod=guild_medic");else{var C=Array.from(document.querySelectorAll("#content a")).filter(({href:E})=>E.includes("mod=guild_medic"));0<C.length?
window.location.href=C[0].href:(C=Math.min(...Array.from(document.querySelectorAll("span[data-ticker-time-left]")).map(E=>parseInt(E.getAttribute("data-ticker-time-left"),10))),isFinite(C)&&Y("VillaMedici",Math.ceil(C/6E4)),k?(F(`${d.va}`),Pf("mod=underworld&submod=prayStart")):window.location.reload())}}async function m(){let C=!1;if("mod=premium&submod=inventory"!=tf)Pf("mod=premium&submod=inventory");else{await new Promise(E=>setTimeout(E,500));for(let E=0,t=document.querySelectorAll(".contentboard_paper_repeat");E<
t.length;E++)if(t[E].querySelector("img").src&&t[E].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")||t[E].querySelector("img").src&&t[E].querySelector("img").src.includes("token/18")||t[E].querySelector("img").src.includes("18.jpg")){C=!0;t[E].querySelector("input").click();Of(1E3);return}C||(localStorage.setItem("useHealingPotion","false"),k?(F(`${d.va}`),Pf("mod=underworld&submod=prayStart")):Of(1E3))}}async function r(){try{let H=document.getElementById("inv"),G=0,K;var C=localStorage.getItem("HealPickBag")||
2,E=localStorage.getItem("PackageSort")||"del_asc";K=C?511+Number(C)||512:512;var t=Array.from(document.querySelectorAll(`#inventory_nav a.awesome-tabs[data-bag-number="${K}"]`));0<t.length&&t[0].click();t=1;let L=0,M=!1;C=[];const Z=Number(localStorage.getItem("FoodAmount"))||1;var u=I({mod:"packages",submod:"sort",page:"1",sh:W("sh")}),A=new URLSearchParams({packageSorting:"del_asc"});await fetch(u,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()},body:A}).then(ka=>ka.text());u=!1;t=await la.sm(-1,"",7);for(u=!0;!M&&5>L;){const ka=await fetch(I({mod:"packages",f:"7",fq:"-1",qry:"",page:t.toString(),sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(ca=>ca.text()),qa=jQuery(ka).find(".packageItem");if(0===qa.length)L++,u?t--:t++;else{C=[];for(A=0;A<qa.length;A++){const ca=qa[A],pa=ca.querySelector("[data-content-type]"),xa=parseInt(pa.getAttribute("data-soulbound-to"),
10),$a=parseInt(pa.getAttribute("data-basis").split("-")[1],10);(![30,35].includes($a)&&isNaN(xa)||![30,35].includes($a)&&xa===Number(idkps))&&C.push(ca)}0<C.length?M=!0:(F(`${d.yb} (Page ${t})`),L++,u?t--:t++)}}var B=I({mod:"packages",submod:"sort",page:"1",sh:W("sh")});const ba=new URLSearchParams({packageSorting:E});await fetch(B,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:ba}).then(ka=>ka.text());if(!M)return localStorage.setItem("healingStateX",
"true"),F(`${d.zb}`),!1;E=[5,8];const ha=ec(H);for(B=0;G<Z&&B<C.length;){const ka=C[B],qa=ka.querySelector("[data-content-type]"),ca=ka.querySelector("input").getAttribute("value"),pa=parseInt(qa.getAttribute("data-measurement-x"),10),xa=parseInt(qa.getAttribute("data-measurement-y"),10),$a=parseInt(qa.getAttribute("data-amount"),10),zb=fc(E[0],E[1],ha),Ua=nc(xa,pa,zb);if(Ua){ha.push({x:Ua.x,y:Ua.y,ul:xa,w:pa});const kb=T({mod:"inventory",submod:"move",from:"-"+ca,fromX:1,fromY:1,to:K,toX:Ua.x+1,
toY:Ua.y+1,amount:$a}),qc=new URLSearchParams({a:(new Date).getTime(),sh:W("sh")});await fetch(kb,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:qc}).then(Mb=>Mb.text());G++;const rc=jQuery(qa).css({left:32*Ua.x,top:32*Ua.y});H.appendChild(rc[0]);F(`${d.If}`);await new Promise(Mb=>setTimeout(Mb,500))}else{F(`${d.Jf}`);break}B++}if(0<G)return G>=Z?F(`${d.Lf}`):F(`${d.Mf}`),!0;F(`${d.zb}`);return!1}catch(H){return F(`Error in pickFood(): ${H}`),
!1}}async function w(){var C=document.querySelector("#header_values_hp_bar");const E=parseInt(C.getAttribute("data-value"),10);C=parseInt(C.getAttribute("data-max-value"),10);return{ro:E,Uo:C}}async function v(){var C=JSON.parse(localStorage.getItem("underworld")).isUnderworld,E="true"===localStorage.getItem("useSacrifice");const t="true"===localStorage.getItem("HealShop"),u=localStorage.getItem("HellHealHP")||15,A="true"===localStorage.getItem("healingStateX"),B="true"===localStorage.getItem("HealPackage"),
H=document.getElementById("sstat_ruby_val");let G=0;H&&(G=H.textContent.trim().replace(/\./g,""),G=parseInt(G,10));if(A&&t)await q()?await v():(localStorage.removeItem("healingStateX"),await D());else if(!0===C||"true"===h&&!0===C||!0===E&&!0===C)"true"===localStorage.getItem("useVillaMedici")&&vf("VillaMedici")?n():"true"===localStorage.getItem("useHealingPotion")?await m():E&&5<=Number(G)?(F("Sacrificing for heal."),Pf("mod=underworld&submod=offering")):k&&"mod=underworld&submod=pray"!=tf&&("true"===
localStorage.getItem("HealEnabled")?da.o<=Number(u):1)?(F(`${d.va}`),Pf("mod=underworld&submod=prayStart")):k&&"mod=underworld&submod=pray"==tf&&("true"===localStorage.getItem("HealEnabled")?da.o<=Number(u):1)?(await new Promise(K=>setTimeout(K,6E4)),F(`${d.Yf}`),window.location.reload()):(F(`${d.Zf}`),Of(6E4));else if(0==C)if("1"!==((new URL(window.location.href)).searchParams.get("doll")||""))"mod=overview&doll=1"!=tf&&Pf("mod=overview&doll=1");else if(E=await D(),!E&&da.o<=Number(b)||!E&&!C&&3>=
Number(Jh().Ha)&&localStorage.getItem("autoEnterHell")&&da.o<=localStorage.getItem("hellEnterHP"))B?(C=await r(),!C&&t?(localStorage.setItem("healingStateX","true"),q()):(C||(F(`${d.vb}`),await new Promise(K=>setTimeout(K,3E4))),window.location.reload())):t?(localStorage.setItem("healingStateX","true"),q()):(F(`${d.vb}`),await new Promise(K=>setTimeout(K,3E4)),window.location.reload())}async function y(C,E,t){let u=null,A=0,B=Infinity;const H=localStorage.getItem("idkps")||0,G="true"===localStorage.getItem("HealCervisia"),
K="true"===localStorage.getItem("HealEggs");let L=!1;G&&(L=await Af());C.forEach(M=>{var Z=M.getAttribute("data-basis");const ba=parseInt(M.getAttribute("data-soulbound-to"),10);var ha=(ha=M.getAttribute("data-tooltip").match(/Heals ([\d,\.]+) of life/))?parseInt(ha[1].replace(/\./g,""),10):0;const ka=t-(E+ha);if(!ba||ba===parseInt(H,10)){if(Z.startsWith("7-")){Z=parseInt(Z.split("-")[1],10);if(!K&&23<=Z&&34>=Z||!G&&35===Z)return;if(G&&35===Z&&L)L=!0;else if(35===Z&&G&&!L)return}0<=ka&&ka<B?(u=M,
B=ka):0>ka&&ha>A&&(A=ha,u=M)}});return u}async function D(){return new Promise(async C=>{let E=!1;const {ro:t,Uo:u}=await w();var A=new URL(window.location.href);const B=A.origin;A=A.searchParams.get("sh");if("mod=overview&doll=1"!=tf)Pf("mod=overview&doll=1");else{const Z="true"===localStorage.getItem("HealPackage"),ba="true"===localStorage.getItem("HealShop"),ha="true"===localStorage.getItem("HealCervisia"),ka="true"===localStorage.getItem("HealEggs");let qa=!1;ha&&(qa=await Af());var H=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs")),
G=H.findIndex(ca=>ca.classList.contains("current"));H=H.slice(G).concat(H.slice(0,G));for(G=0;G<H.length;G++){var K=H[G];if("false"!==K.getAttribute("data-available")&&(await new Promise(ca=>setTimeout(ca,175)),K.click(),K.classList.contains("current"))){K=document.querySelectorAll("#inv .ui-draggable");K=Array.from(K).filter(ca=>{const pa=ca.getAttribute("data-basis");ca=parseInt(ca.getAttribute("data-soulbound-to"),10);const xa=parseInt(pa.split("-")[1],10);if(!ca||ca===parseInt(idkps,10)){if(pa.startsWith("7-")){if(!ka&&
23<=xa&&34>=xa||!ha&&35===xa)return;if(qa&&ha&&35===xa)qa=!0;else if(35===xa&&ha&&!qa)return}return pa&&"7"===pa.split("-")[0]}});var L=void 0,M=!1;if(100<=da.level&&Va.cooldown()&&"true"==localStorage.getItem("autoEnterHell")){L=await (await fetch(`${B}/game/index.php?mod=hermit&sh=${A}`)).text();L=(new DOMParser).parseFromString(L,"text/html");L=Array.from(L.querySelectorAll('div[style="margin:20px"]'));for(let ca of L)if(ca.querySelector('a[href^="index.php?mod=hermit&submod=underworld&sh="]')){M=
!0;break}}if(M){M=0;L=localStorage.getItem("idkps");for(const ca of K)if(K=parseInt(ca.getAttribute("data-soulbound-to"),10),(!K||K===parseInt(L,10))&&"true"===localStorage.getItem("autoEnterHell"))if(ca)await new Promise(pa=>setTimeout(pa,250)),await fa(ca,"avatar"),await new Promise(pa=>setTimeout(pa,450)),F(`${d.tb}`),M++,2<=M&&window.location.reload();else{K=!1;Z&&(K=await r());if(!K&&ba)return localStorage.setItem("healingStateX","true"),q(),!0;window.location.reload()}}else for(const ca of K){E=
!0;if(M=await y(K,t,u))await new Promise(pa=>setTimeout(pa,250)),await fa(M,"avatar"),await new Promise(pa=>setTimeout(pa,450)),F(`${d.tb}`);else if(M=!1,Z&&(M=await r()),!M&&ba){localStorage.setItem("healingStateX","true");q();return}window.location.reload()}}}C(E)}})}await v()}}},Va={isUnderworld(){if("underworld"==document.getElementById("wrapper_game").className){var b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else b=
JSON.parse(localStorage.getItem("underworld")||"{}"),b.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(b));return(b=document.querySelector("#submenu2 a"))&&b.href.match(/mod=.*&sh/)&&"mod=underworld&submod=leave"===b.href.match(/mod=.*&sh/)[0].slice(0,-3)?!0:!1},oj(){return!0!==(JSON.parse(localStorage.getItem("underworld"))||{}).oj},cooldown(){var b=(new Date).getTime();let c=JSON.parse(localStorage.getItem("underworld"))||{};c.cooldown=b;localStorage.setItem("underworld",JSON.stringify(c));
let e=document.getElementById("submenu2");e&&e.innerHTML.includes("index.php?mod=underworld")?c.isUnderworld=!0:c.isUnderworld=!1;if(aa.an.cooldown&&aa.an.cooldown>b)return!1;if(b=document.querySelectorAll(".buff-clickable"))for(let g of b)if(g.getAttribute("data-link")=="index.php?mod=location&sh="+W("sh"))return!1;return!0},async start(){function b(){var u=`expedition_info${parseInt(localStorage.getItem("farmEnemy"),10)||1}`,A=document.getElementById(u);if(!A)return!1;u=A.querySelector(".expedition_picture img");
A=A.querySelector(".expedition_picture .avatar_costume_animation");if(!u&&!A)return!1;if(u){var B=u.getAttribute("src");if(!B)return!1;B=!B.includes("904194973d21066c96cb414d04d676")}A&&(B=A.style.backgroundImage.match(/url\("(.+?)"\)/),u=null,B&&B[1]&&(u=B[1]),B=!u.includes("904194973d21066c96cb414d04d676"));return B}async function c(u=!1){if(Va.isUnderworld||!y){0<(JSON.parse(localStorage.getItem("GodPowersHell"))||[]).length&&0==u&&await e();Y("underworldArmorBuffs",15);var A="true"===localStorage.getItem("useWeaponBuff"),
B=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||[];u=[];A&&u.push({type:"weapon",jc:"12-1",gm:[3]});if(0<B.length){const H={Helmet:2,Armor:5,Shield:4,Boots:10,Gloves:9};A=B.map(G=>H[G]).filter(G=>G);0<A.length&&u.push({type:"armor",jc:"12-3",gm:A})}0<u.length&&await g(u);localStorage.setItem("usedGodPowers","true")}}async function e(){if("true"===localStorage.getItem("useGodPowersHell")){var u=JSON.parse(localStorage.getItem("GodPowersHell"))||[],A="Minerva Diana Vulcan Mars Apollo Mercury".split(" ");
for(let B of u)if(u=A.indexOf(B),-1<u)try{await fetch(I({mod:"gods",submod:"activateBlessing",god:u+1,rank:1,sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(H=>H.text()),F(`${B} power activated`)}catch(H){}}}async function g(u){var A=u.map(H=>H.jc);const B={};A=await l(A);Object.assign(B,A);for(let H of u.slice())if(A=B[H.jc])await q(A,H.gm),u=u.filter(G=>G.jc!==H.jc),F(`${H.type.charAt(0).toUpperCase()+H.type.slice(1)} buff equipped on slots ${H.gm.join(", ")}`);
0<u.length&&await h(u)}async function l(u){return new Promise(async A=>{const B={};var H=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));for(let G of H)if("false"!==G.getAttribute("data-available")){G.click();await new Promise(K=>setTimeout(K,200));H=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let K of H)if(H=K.getAttribute("data-basis"),u.includes(H)&&!B[H]){const L=parseInt(K.getAttribute("data-position-x"),10),M=parseInt(K.getAttribute("data-position-y"),
10),Z=parseInt(K.getAttribute("data-container-number"),10);B[H]={fromX:L,fromY:M,from:Z};if(Object.keys(B).length===u.length){A(B);return}}}A(B)})}async function h(u){try{let A=1;for(;1<=A&&7>=A&&0<u.length;){const B=await fetch(I({mod:"packages",f:"12",page:A.toString(),csrf_token:x(),sh:W("sh")}),{method:"GET",credentials:"include"}).then(G=>G.text()),H=Array.from(jQuery(B).find(".packageItem"));for(let G of H){const K=G.querySelector("[data-content-type]"),L=G.querySelector("[data-container-number]");
K.getAttribute("data-measurement-x");K.getAttribute("data-measurement-y");const M=K.getAttribute("data-basis");L.getAttribute("data-container-number");const Z=L.getAttribute("data-container-number"),ba=u.find(ha=>ha.jc===M);if(ba&&await k(Z,ba.gm)&&(F(`${ba.type.charAt(0).toUpperCase()+ba.type.slice(1)} buff equipped on slots ${ba.gm.join(", ")}`),u=u.filter(ha=>ha.jc!==M),0===u.length))return}A++}if(0<u.length)for(let B of u)F(`Could not find ${B.type} buff to equip.`)}catch(A){}}async function k(u,
A){return new Promise((B,H)=>{dc(1,1,async(G,K)=>{try{const L=T({mod:"inventory",submod:"move",from:u,fromX:1,fromY:1,to:K,toX:G.x+1,toY:G.y+1,amount:1,a:(new Date).getTime(),sh:W("sh")});await fetch(L,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(Z=>Z.text());const M={fromX:G.x+1,fromY:G.y+1,from:K};await q(M,A);B(M)}catch(L){console.error("Error moving item to inventory and equipping:",L),
H(L)}})})}async function q(u,A){for(let B of A)await n(u.from,u.fromX,u.fromY,B,1,1,!0),await new Promise(H=>setTimeout(H,200))}async function n(u,A,B,H,G,K,L=!1){u={mod:"inventory",submod:"move",from:u,fromX:A,fromY:B,to:H,toX:G,toY:K,amount:1,a:(new Date).getTime(),sh:W("sh")};L&&(u.doll=1);L=T(u);await fetch(L,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:new URLSearchParams({})}).then(M=>M.text())}this.location=Array.from(document.querySelectorAll("#submenu2 a")).pop().href;
var m="true"===localStorage.getItem("farmEnable"),r=localStorage.getItem("farmLocation")||1;const w=localStorage.getItem("farmEnemy")||1;var v="true"===localStorage.getItem("useGodPowersHell");const y="true"===localStorage.getItem("usedGodPowers");var D=localStorage.getItem("hellLimit")||0;const C="true"===localStorage.getItem("EnableHellLimit");if(v&&!y){if("mod=overview&doll=1"!=tf){Pf("mod=overview&doll=1");return}await c()}if(vf("underworldArmorBuffs")){if("mod=overview&doll=1"!=tf){Pf("mod=overview&doll=1");
return}await c(!0)}let E;m&&(E=b());v=localStorage.getItem("HellHealHP")||15;da.o>=Number(v)&&await fetch(I({mod:"underworld",submod:"prayEnd",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(u=>u.text());if("true"==localStorage.getItem("exitUnderworld")&&0==Number(Jh().Ha))D=JSON.parse(localStorage.getItem("underworld")),D.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(D)),await fetch(I({mod:"underworld",
submod:"exit",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(u=>u.text()),F(`${d.$f}`),location.reload();else{if(0==Number(Jh().Ha)&&"true"==localStorage.getItem("UnderworldUseMobi")){if("mod=premium&submod=inventory"!==tf){Pf("mod=premium&submod=inventory");return}v=document.querySelectorAll(".contentboard_paper_repeat");for(var t=0;t<v.length;){v[t].querySelector("img").src&&(v[t].querySelector("img").src.includes("5.jpg")||
v[t].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7"))?v[t].querySelector("input").click():localStorage.setItem("UnderworldUseMobi","false");Of(500);return}}t=document.querySelector("#submenu2");v=t.querySelector(`#location_inactive_${r}`);t=t.querySelector(`a[href*="loc=${r}"]`);v=v&&v.classList.contains("inactive");if(!m||v&&!t||tf===`mod=location&loc=${r}`)if(m&&tf==`mod=location&loc=${r}`&&E&&(!C||C&&0<D))m=parseInt(w,10),r=document.getElementsByClassName("expedition_button"),
C&&(D--,localStorage.setItem("hellLimit",D)),r[m-1].click(),Of(5E3);else if(window.location.href!=this.location)window.location.href=this.location;else{await fetch(I({mod:"underworld",submod:"prayEnd",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(A=>A.text());let u=0;Array.from(document.querySelectorAll(".expedition_box")).forEach(A=>{A.querySelector(".expedition_picture img")&&A.querySelector("img").src.includes("enemy_unknown.jpg")&&
u++});document.querySelector("#content .icon_expeditionpoints")&&0<Number(Jh().Ha)||"true"==localStorage.getItem("UnderWorldUseRuby")&&"0"==Jh().Ha?(ma("underworldAttacks",0),document.querySelectorAll(".expedition_button")[Math.floor(3-u)].click()):(F(`${d.ag}`),await new Promise(A=>setTimeout(A,6E4)),Of())}else Pf(`mod=location&loc=${r}`)}},async xo(){let b=0;var c=["normal","medium","hard"][parseInt(localStorage.getItem("hellDifficulty"),10)||0];const e=I({mod:"hermit",submod:"enterUnderworld",
sh:W("sh")});c=new URLSearchParams({[`difficulty_${c}`]:c.charAt(0).toUpperCase()+c.slice(1)});try{fetch(e,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:c}).then(g=>g.text()),localStorage.setItem("usedGodPowers","false"),await new Promise(g=>{const l=++b;var h=!document.hidden;let k=1;var q=jQuery("#server-time");0<q.length&&(q=q.next().html())&&(q=q.match(/x(\d+)$/)||["0","1"],q=parseInt(q[1],10),0<q&&(k=5/q));h=h?400:400*
k;if("undefined"!==typeof Worker){const n=URL.createObjectURL(new Blob(["\n                            const timers = {};\n                            self.onmessage = function(event) {\n                                const { type, id, delay } = event.data;\n                                if (type === 'setTimeout') {\n                                    timers[id] = setTimeout(() => {\n                                        self.postMessage({ type: 'timeout', id });\n                                        delete timers[id];\n                                    }, delay);\n                                }\n                                if (type === 'clearTimeout') {\n                                    if (timers[id]) {\n                                        clearTimeout(timers[id]);\n                                        delete timers[id];\n                                    }\n                                }\n                            };\n                        "],
{type:"application/javascript"})),m=new Worker(n),r=w=>{"timeout"===w.data.type&&w.data.id===l&&(g(),m.removeEventListener("message",r),m.terminate(),URL.revokeObjectURL(n))};m.addEventListener("message",r);m.postMessage({type:"setTimeout",id:l,delay:h})}else setTimeout(()=>{g()},h)}),window.location.reload()}catch(g){}}};null===localStorage.getItem("DELAY")&&localStorage.setItem("DELAY","0 seconds");var Dc=localStorage.getItem("DELAY");if(Dc.includes("to")){const b=Dc.split(" "),c=parseInt(b[0],
10);var Zb=Math.floor(Math.random()*(parseInt(b[2],10)-c+1))+c}else Zb=parseInt(Dc.split(" ")[0],10);Dc.includes("minute")&&(Zb*=60);var Ec=1E3*Zb,Kj=localStorage.getItem("costumeUnderworld"),Lj=["9","10","11"],Fc="true"===localStorage.getItem("activateAuction2"),zh="true"===localStorage.getItem("auctionTURBO"),Gc="true"===localStorage.getItem("bidFood"),Ah=4<da.level,Bh="true"===localStorage.getItem("enableCircusWithoutHeal"),Mj="true"===localStorage.getItem("resetUnderworld"),Ch="true"===localStorage.getItem("auctiongladiatorenable"),
Dh="true"===localStorage.getItem("auctionmercenaryenable"),Hc="true"===localStorage.getItem("enableMercenarySearch"),qf="true"===localStorage.getItem("EnableArenaHell"),Nj="true"===localStorage.getItem("dontEnterUnderworld"),Ic=0<JSON.parse(localStorage.getItem("auctionPrefixes")).length||0<JSON.parse(localStorage.getItem("auctionSuffixes")).length,Eb=localStorage.getItem("auctionStatus")>=localStorage.getItem("bidStatus"),Eh=localStorage.getItem("auctionMStatus")>=localStorage.getItem("bidStatus"),
fb=JSON.parse(localStorage.getItem("underworld")),Fb=vf("auction"),Fh=vf("auctionM"),Gh=localStorage.getItem("MarketlastRan"),Oj=localStorage.getItem("MarketSearchInterval")||5,Pj=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),Qj=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),Hh=JSON.parse(localStorage.getItem("itemsToReset")||"[]"),rf=fb.oj;rf=rf?!1:!0;ta&&"true"===localStorage.getItem("activateRepair")&&wj();0<Ec&&(F(`Waiting for ${Zb} seconds...`),await new Promise(b=>
setTimeout(b,Ec)));if(ta&&(0<Object.keys(Pj).length||0<Object.keys(Qj).length)&&"true"===localStorage.getItem("activateRepair")&&vf("repair")&&!window.location.href.includes("/index.php?mod=hermit&submod=underworld")&&aa.player.key==ya&&2E3<Jh().gold&&("true"===localStorage.getItem("HealEnabled")?da.o>Number(localStorage.getItem("healPercentage")):1)){const b="true"===localStorage.getItem("repairGladiator"),c="true"===localStorage.getItem("repairMercenary");let e=[],g=[];const l=JSON.parse(localStorage.getItem("activeItemsGladiator")||
"{}"),h=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}");async function k(v,y,D){const C=localStorage.getItem("repairPercentage"),E=null!==C?parseInt(C,10)/100:.1;v=await (await fetch(`${v}/game/index.php?mod=overview&doll=${y}&sh=${D}`)).text();v=(new DOMParser).parseFromString(v,"text/html").getElementById("char").querySelectorAll("div[data-tooltip]");D=(D=localStorage.getItem("workbenchItem"))?JSON.parse(D):{};D.selectedItem=D.selectedItem||{};let t=[];v.forEach(u=>{if(u.classList.contains("ui-draggable")){let A=
Ib(u),B=u.getAttribute("data-container-number"),H=u.getAttribute("data-measurement-x"),G=u.getAttribute("data-measurement-y"),K=JSON.parse(u.getAttribute("data-tooltip")).pop().pop()[0].match(/\d+/g);null!=K&&K[0]/K[1]<E&&t.push({type:Ea(u),quality:Ca(u),name:A,doll:y,container:B,zn:H,An:G})}});return t}const q=cb.origin,n=cb.searchParams.get("sh")||"";let m=localStorage.getItem("workbenchItem");m=m?JSON.parse(m):{};b&&(e=await k(q,1,n),localStorage.setItem("itemList1",JSON.stringify(e)),aa.workbench.itemList1=
e);c&&(g=await k(q,2,n),localStorage.setItem("itemList2",JSON.stringify(g)),aa.workbench.itemList2=g);const r=JSON.parse(localStorage.getItem("Timers"));m.selectedItem||(b&&c?0===e.length&&0===g.length&&Y("repair",r.Repair||10):b?0===e.length&&Y("repair",r.Repair||10):c?0===g.length&&Y("repair",r.Repair||10):Y("repair",r.Repair||10));function w(v,y,D){return Array.isArray(v)&&0!==v.length?v.filter(C=>{const E=Object.keys(y).find(t=>y[t]===C.container);return E?!1!==D[E]:!0}):v}e=w(e,{helmet:"2",necklace:"11",
weapon:"3",armor:"5",shield:"4",gloves:"9",shoes:"10",rings1:"6",rings2:"7"},l);g=w(g,{helmetM:"2",necklaceM:"11",weaponM:"3",armorM:"5",shieldM:"4",glovesM:"9",shoesM:"10",rings1M:"6",rings2M:"7"},h);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(g));aa.workbench.itemList1=e;aa.workbench.itemList2=g;if(m.selectedItem&&!0===m.selectedItem.enable){let v=e.findIndex(y=>y.name===m.selectedItem.item.name);-1!==v&&e.splice(v,1);v=g.findIndex(y=>y.name===
m.selectedItem.item.name);-1!==v&&g.splice(v,1);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(g))}if(b&&0<e.length||c&&0<g.length||m.selectedItem&&0<Object.keys(m.selectedItem).length)await Ij.start();else{const v=JSON.parse(localStorage.getItem("Timers"));Y("repair",v.Repair||10);window.location.reload()}}else if(0==await oj(ya,Cf,aa.player.supportDevelopersPlease))hb();else if((Fc||Gc||Hc)&&zh&&Fc&&ta&&Ah&&(Ch&&Ic&&Eb&&Fb&&vf("AuctionEmpty")||
Gc&&Eb&&Fb&&vf("AuctionEmpty")||Hc&&Eb&&Fb&&vf("AuctionMEmpty")||Dh&&Ic&&Eh&&Fh&&vf("AuctionMEmpty")))await Aa.start();else if(ta&&Kh()&&"true"===localStorage.getItem("doKasa")&&vf("gold")&&Jh().gold>Math.floor(localStorage.getItem("KasaHoldGold")))await $h();else if(ta&&"true"===localStorage.getItem("EnableSmelt")&&la.ln()&&1E3<da.gold&&vf("smelt"))vf("smeltCheck")&&(la.slots=await la.u(),await la.Gm(la.slots),await la.Ym(la.slots),"true"===localStorage.getItem("EnableSmelt")&&1E3<da.gold&la.ln()&&
vf("smelt")&&await la.start());else if(ta&&3>=Number(Jh().Ha)&&!0===Fa&&"true"===localStorage.getItem("autoEnterHell")&&100<=da.level&&8E3<=da.gold&&da.o>Number(localStorage.getItem("hellEnterHP"))&&Va.cooldown()&&(Nj?rf:1))await Va.xo();else if(ta&&(!0===Sa&&ja()&&aa.player.key==ya||!0===Sa&&("true"===localStorage.getItem("HealEnabled")?da.o>Number(localStorage.getItem("healPercentage")):1)&&Xb<Yb&&aa.player.key==ya)){localStorage.setItem("nextQuestTime.timeOut",0);localStorage.setItem("nextQuestTime",
0);function b(l){const h={Diana:"diana",Apollo:"apollo",Vulcan:"vulcan",Minerva:"minerva",Mercury:"mercury",Mars:"mars"};l=l.querySelectorAll(".quest_slot_reward img");for(const k of l){l=k.getAttribute("src");for(const [q,n]of Object.entries(h))if(l.includes(n)&&"true"===localStorage.getItem(`questType${q}`))return!0}}function c(l){var h=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]").map(q=>q.toLowerCase());const k=parseInt(localStorage.getItem("questrewardvalue"),10);if(l=$(l).find(".quest_slot_reward_item")[0]){const q=
l.outerHTML.toLowerCase();if(h.some(n=>q.includes(n))&&(h=q.match(/(\d+\.\d+)/))&&parseFloat(h[0].replace(".",""))>=k)return!0}return!1}async function e(){var l=cb.origin,h=$("#content .contentboard_slot a.quest_slot_button_accept"),k="true"===localStorage.getItem("skipTimeQuests");const q="true"===localStorage.getItem("skipTimeCircusQuests"),n="true"===localStorage.getItem("skipTimeOtherQuests"),m="true"===localStorage.getItem("acceptnotfilter"),r="true"===localStorage.getItem("UnderworldQuests"),
w=JSON.parse(localStorage.getItem("questKeywords")||"[]"),v=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]"),y=JSON.parse(localStorage.getItem("underworldQuestKeywords")||"[]"),D=JSON.parse(localStorage.getItem("underworld")||"{}");var C=$("#content .contentboard_slot_inactive").toArray();if(h.length){function E(t){return t.includes("icon_combat_inactive")?"combat":t.includes("icon_arena_inactive")?"arena":t.includes("icon_grouparena_inactive")?"circus":t.includes("icon_expedition_inactive")?
"expedition":t.includes("icon_dungeon_inactive")?"dungeon":t.includes("icon_item")?"items":null}h=!1;for(const t of C){let u=t.getElementsByClassName("quest_slot_title")[0].innerText;C=E(t.getElementsByClassName("quest_slot_icon")[0].style.backgroundImage);if(!(k&&0<t.getElementsByClassName("quest_slot_time").length&&"arena"==C||q&&0<t.getElementsByClassName("quest_slot_time").length&&"circus"==C||n&&0<t.getElementsByClassName("quest_slot_time").length&&"circus"!==C&&"arena"!==C)){if(1==D.isUnderworld&&
r&&!h&&0<y.length&&Na[C]&&r){const A=$(t).find(".quest_slot_reward_item img[data-tooltip]")[0];if(A){C=A.getAttribute("data-tooltip");const B=JSON.parse(C.replace(/&quot;/g,'"'))[0][0][0].toLowerCase();if(y.some(H=>B.includes(H.toLowerCase()))){k=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await fetch(k,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(H=>H.text());h=!0;break}else continue}}w.some(A=>
u.includes(A))||(Na[C]&&b(t)&&(h=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),await fetch(h,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(A=>A.text()),h=!0),Na[C]&&c(t)&&!m&&(h=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),await fetch(h,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(A=>
A.text()),h=!0),Na[C]&&v.some(A=>u.includes(A))&&(h=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),await fetch(h,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(A=>A.text()),h=!0),!h&&Na[C]&&m||h||!Na[C]||m||0!==v.length||(C=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),await fetch(C,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded",
"x-csrf-token":x()}}).then(A=>A.text()),h=!0))}}if(h)return;l=`${l}/game/index.php?mod=quests&submod=resetQuests&sh=${W("sh")}`;await fetch(l,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(t=>t.text());window.location.reload()}g()}async function g(){var l=$("#quest_header_cooldown");let h;switch(localStorage.getItem("questSpeed")){case "0":h=15E4;break;case "1":h=2E5;break;case "2":h=25E4;break;case "3":h=3E5;break;case "4":h=
4E5;break;default:h=3E5}l.length?(l=Number($("#quest_header_cooldown b span").attr("data-ticker-time-left")),Xb=Yb+l):Xb=Yb+h;localStorage.setItem("nextQuestTime",Xb);window.location.reload()}await async function(){if("mod=quests"!=tf)Pf("mod=quests");else{let l=[];const h=[],k=[];document.querySelectorAll("a.quest_slot_button_finish").forEach(m=>{m.href&&l.push(m.href)});document.querySelectorAll(".quest_slot_button_restart").forEach(m=>{m.href&&h.push(m.href)});document.querySelectorAll(".quest_slot_button_accept").forEach(m=>
{m.href&&k.push(m.href)});async function q(m){try{m<l.length&&(await fetch(l[m],{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(r=>r.text()),await q(m+1))}catch(r){}}async function n(m){try{m<h.length&&(await fetch(h[m],{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(r=>r.text()),await n(m+1))}catch(r){}}await async function(){0<l.length&&await q(0);
0<h.length&&await n(0);0<k.length&&await e();await g()}()}}()}else if(1==ta&&"true"===localStorage.getItem("OilEnable")&&Qa.no()&&(!xh||36E5<=yh-xh)){F(`${d.Of}`);localStorage.setItem("OillastRan",yh.toString());const b=await Qa.Ao();for(let c=0;c<Qa.H.length;c++)await Qa.Xm(c,b);await Qa.lp();F(`${d.Pf}`);jf()}else if(ta&&vf("circus")&&!0===Ma&&9<da.level&&(da.o>Number(localStorage.getItem("healPercentage"))||"true"===localStorage.getItem("enableCircusWithoutHeal"))&&aa.player.key==ya&&!0===document.getElementById("cooldown_bar_fill_ct").classList.contains("cooldown_bar_fill_ready")){async function b(){var h=
new URL(window.location.href),k=h.origin;h=h.searchParams.get("sh")||"";var q=localStorage.getItem("scoreRangeCircus"),n=[];k=await (await fetch(`${k}/game/index.php?mod=highscore&sh=${h}&a=${q}`)).text();k=(new DOMParser).parseFromString(k,"text/html");k=Array.from(k.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(m=>(m=m.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===m.style.color||"blue"===m.style.color):null===m);n=[...n,...k];
if(0===n.length)return console.log("No players available to attack"),!1;k=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];q=function(m){for(var r=m.length,w,v;0!==r;)v=Math.floor(Math.random()*r),--r,w=m[r],m[r]=m[v],m[v]=w;return m}(n);n=0;for(let m of q)if(q=m.textContent.toLowerCase(),!k.map(r=>r.toLowerCase()).includes(q)){q=await c(m.textContent,h);if(q.includes("index.php?mod=reports")){h=(new URLSearchParams(q)).get("reportId");F(`${d.ta}`+m.textContent);Pf(`mod=reports&submod=showCombatReport&t=3&reportId=${h}`);
await new Promise(r=>setTimeout(r,500));return}n++;if(3<=n)break}return!1}async function c(h,k){try{const q=(new URL(window.location.href)).origin;return await (await fetch(`${q}/game/ajax/doGroupFight.php?dname=${h}&a=${Date.now()}&sh=${k}`,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}})).text()}catch{Of(1E3)}}async function e(h){var k=h.opponentId;const q=h.serverId;h=h.country;var n=(new URL(window.location.href)).origin;n=
new URL(`${n}/game/ajax.php`);k={mod:"arena",submod:"doCombat",aType:3,opponentId:k,serverId:q,country:h.toString(),a:(new Date).getTime(),sh:W("sh")};n.search=(new URLSearchParams(k)).toString();return await (await fetch(n,{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}})).text()}async function g(){function h(y){const D=null!==y.querySelector("span[style*='color:green;']");return Array.from(y.querySelectorAll("a, span")).find(C=>
"green"===C.style.color||"bold"===C.style.fontWeight)||D}var k=new URL(window.location.href);const q=k.origin;var n=await (await fetch(`${q}/game/index.php?mod=arena&submod=grouparena&sh=&sh=${W("sh")}`)).text();n=(new DOMParser).parseFromString(n,"text/html");var m=Array.from(n.querySelectorAll('table[width="80%"] tbody tr')).filter(y=>y.querySelector(".attack"));if(m.length&&1!==m.length){var r=null;n=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];if("true"===localStorage.getItem("leaguecircusrandom")){m=
m.sort(()=>Math.random()-.5);for(var w of m){var v=w.querySelector("a");v=v?v.innerText:null;if(!h(w)&&!n.includes(v)){r=w;break}}}else if("true"===localStorage.getItem("leaguecircuslowtohigh")){m=m.sort((y,D)=>parseInt(y.querySelector("th")?y.querySelector("th").textContent:"0",10)-parseInt(D.querySelector("th")?D.querySelector("th").textContent:"0",10));w=null;r=-1;for(v of m)m=(m=v.querySelector("a"))?m.innerText:null,h(v)||n.includes(m)||(m=parseInt(v?.querySelector("th")?.textContent,10),m>r&&
(r=m,w=v));r=w}if(null===r)localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircusattackenable","false"),Of(500);else if(r)if(n=r.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],v=(new Date).getTime(),k=k.searchParams.get("sh")||"",await new Promise(y=>setTimeout(y,250)),k=await (await fetch(`${q}/game/ajax/doGroupFight.php?did=${n}&a=${v}&sh=${k}`)).text(),(n=k.match(/document\.location\.href\s*=\s*'([^']+)'/))&&
n[1])window.location=`${q}/game/${n[1]}`;else{k.includes("5")&&("true"===localStorage.getItem("leaguecircuslowtohigh")?(localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","true")):"true"===localStorage.getItem("leaguecircusrandom")&&(localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusattackenable","false")),location.reload());if(k.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leaguecircusattackenable",
"false"),location.reload()}async function l(){function h(t){const u=Date.now(),A=y.findIndex(B=>B.playerName===t);-1<A?y[A].timeout=u:y.push({playerName:t,timeout:u});localStorage.setItem("playerTimeouts",JSON.stringify(y))}function k(t,u){const A=Date.now();if(Array.isArray(y)){const B=y.find(H=>H.playerName===t);return!B||A-B.timeout>u}return!y[t]||A-y[t]>u}function q(t){for(var u=t.length-1;0<u;u--){const A=Math.floor(Math.random()*(u+1));[t[u],t[A]]=[t[A],t[u]]}2<t.length&&(u=t.splice(0,2),t.push(...u));
return t}async function n(t,u,A){try{const B=u.match(/\d+/)[0],H=u.match(/\w+/g)[2],G=(new URLSearchParams(u)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:A,aType:t,opponentId:G,serverId:B,country:H}));const K=await (await fetch(T({mod:"arena",submod:"confirmDoCombat",aType:t,opponentId:G,serverId:B,country:H,a:(new Date).getTime(),sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}})).text(),
L=(new URLSearchParams(K)).get("reportId");L||window.location.reload();ma("circusAttacks",0);Pf(`mod=reports&submod=showCombatReport&t=${t}&reportId=${L}`)}catch(B){console.error("Fetch Error:",B),document.getElementById("content").querySelector("form > input").click(),Of(1E3)}}"true"===localStorage.getItem("leaguecircusattackenable")&&await g();"true"===localStorage.getItem("scoreboardcircusenable")&&await b();var m=(new URL(window.location.href)).searchParams.get("sh")||"",r=JSON.parse(localStorage.getItem("autoAttackCircusList"))||
[];let w=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[];const v=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];let y=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const D="true"===localStorage.getItem("onlyCircus");localStorage.getItem("CircusSimulatorAmount");const C="true"===localStorage.getItem("onlyPlayerListCircus");if(vf("circus")&&0<r.length||vf("circus")&&0<w.length||D||C)try{q(r);localStorage.setItem("autoAttackCircusList",JSON.stringify(r));q(w);
localStorage.setItem("autoAttackCircusServerList",JSON.stringify(w));let t=0,u=3,A=0,B=0;D&&(u=15);const H=r.length+w.length;for(C&&(u=H);t<u&&(A<r.length||B<w.length);){let G,K,L;(L=A<r.length&&B<w.length?.5>Math.random():B<w.length)?(K=w[B],G=K.playerName,B++):(G=r[A],A++);if(!v.includes(G)&&(k(G,6E4*(10+Math.floor(36*Math.random())))||D)){let M;M=L?await e(K):await c(G,m);if(M.includes("index.php?mod=reports")&&!M.includes("errorRow")){h(G);F(`${d.ta}`+G);ma("circusAttacks",0);window.location.reload();
break}}t++}if(t===u&&C){F("Tried to attack circus list. Timing out 1min.");Y("circus",1);window.location.reload();return}}catch(t){window.location.reload()}if("mod=arena&submod=serverArena&aType=3"!=tf)Pf("mod=arena&submod=serverArena&aType=3");else try{if(document.querySelector(".messages .message.fail"))localStorage.setItem("doCircus",!1),window.location.reload();else{let t=[...r,...w].map(B=>B.playerName);var E=Array.from(document.querySelectorAll("#own3 tr")).slice(1);const u="true"===localStorage.getItem("circusAttackGM")||
"true"===localStorage.getItem("arenaAttackGM"),A="true"===localStorage.getItem("attackRandomly");m=null;r=Infinity;localStorage.getItem("Username");localStorage.getItem("enableCircusSimulator");for(let B of E){const H=B.querySelector("a");E=2;A&&(E=Math.floor(5*Math.random())+2);const G=B.querySelector(`td:nth-child(${E})`);if(H&&G){const K=H.innerText,L=parseInt(G.textContent.trim(),10),M=v.includes(K),Z=null!==H.querySelector("span[style*='color:green;']"),ba="green"===H.style.color;if(!(M||!u&&
Z&&ba)){if(t.includes(K)){F(`${d.ta}`+K);m=H;break}!m&&L<r&&(r=L,m=H)}}}if(m)await n(3,m.href,m.outerText);else{const B=document.querySelector('form[name="filterForm"] input[type="submit"]');B&&B.click()}}}catch{window.location.reload()}}1==Cb.isUnderworld&&vf("circus")?(await fetch(I({mod:"underworld",submod:"prayEnd",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(h=>h.text()),await l()):Bh&&vf("circus")?await l():
!Bh&&vf("circus")&&("true"===localStorage.getItem("HealEnabled")?da.o>Number(localStorage.getItem("healPercentage")):1)&&await l()}else if(ta&&(da.o<=Number(localStorage.getItem("healPercentage"))&&"true"===localStorage.getItem("HealEnabled")&&!Va.isUnderworld()||3>=Number(Jh().Ha)&&100<=da.level&&!Va.isUnderworld()&&Va.cooldown()&&"true"===localStorage.getItem("autoEnterHell")&&da.o<=Number(localStorage.getItem("hellEnterHP"))||Va.isUnderworld()&&"true"===localStorage.getItem("autoEnterHell")&&"true"===
localStorage.getItem("HealEnabled")&&da.o<=Number(localStorage.getItem("HellHealHP"))))await Jj.start();else if(ta&&Fa&&"true"===localStorage.getItem("autoEnterHell")&&Va.isUnderworld()&&Jh().yo)await Va.start();else if(ta&&"true"==localStorage.getItem("useCostume")&&(!window.location.href.includes("/index.php?mod=hermit")&&vf("CheckDolls")&&Lj.some(b=>Kj.includes(b))||!window.location.href.includes("/index.php?mod=hermit")&&vf("CheckDolls")))await of.start();else if(ta&&5<da.level&&"true"==localStorage.getItem("storeGoldinAuction")&&
Number(Jh().gold)>Math.floor(Number(localStorage.getItem("storeGoldinAuctionmaxGold")))&&vf("enableHideGold"))await nb.A.start();else if(ta&&Pc()&&!0===Fa&&0==fb.isUnderworld&&aa.player.key==ya&&0==Cb.isUnderworld&&aa.player.Ed>=new Date&&("true"===localStorage.getItem("HealEnabled")?da.o>Number(localStorage.getItem("healPercentage")):1)&&!0===document.getElementById("cooldown_bar_fill_expedition").classList.contains("cooldown_bar_fill_ready"))await async function(){function b(){const k=document.getElementById("errorText");
"false"===localStorage.getItem("HealEnabled")?(Ya("Your expedition/dungeon settings are incorrect!"),localStorage.setItem("HealEnabled","true"),Of(5E3)):k&&""!==k.innerText.trim()&&location.reload()}var c=localStorage.getItem("expeditionLocation");if(tf!=`mod=location&loc=${c}`)Pf(`mod=location&loc=${c}`);else{var e="true"===localStorage.getItem("autoCollectBonuses"),g=localStorage.getItem("selectedEnemy")||0;c=document.getElementsByClassName("expedition_button");var l=document.querySelectorAll(".expedition_button.disabled");
try{if(document.querySelector(".expedition_cooldown_reduce"))bb("Your expedition settings are incorrect or there is an unexpected page data!"),window.location.reload();else if(ma("expeditionAttacks",0),e){await new Promise(k=>setTimeout(k,800));for(var h=0;h<c.length;h++){if(4>c[h].closest(".expedition_box").querySelectorAll(".expedition_bonus.active").length||3===h){c[h].click();break}4<=l.length?window.location.reload():setTimeout(b,800)}}else h=c[parseInt(g,10)],h.classList.contains("disabled")?
Ya("Your expedition setting is incorrect! You set it to disabled monster which is wrong."):(h.click(),Array.from(c).every(k=>k.classList.contains("disabled"))?(console.log("All buttons are disabled. Reloading..."),window.location.reload()):setTimeout(b,800))}catch{F("There's a problem with the expedition, refreshing the page."),window.location.reload()}}}();else if(ta&&!0===Ga&&!fb.isUnderworld&&aa.player.key==ya&&9<da.level&&("true"===localStorage.getItem("HealEnabled")?da.o>Number(localStorage.getItem("healPercentage")):
1)&&Jh().wo&&"none"!==document.getElementById("cooldown_bar_dungeon").style.display&&!0===document.getElementById("cooldown_bar_fill_dungeon").classList.contains("cooldown_bar_fill_ready"))await async function(){var b=localStorage.getItem("dungeonLocation")||"1",c="true"===localStorage.getItem("skipBoss"),e="true"===localStorage.getItem("resetIfLose");const g="true"===localStorage.getItem("loose"),l="true"===localStorage.getItem("dungeonFocusQuest"),h="chefe Chefe \u0161\u00e9f chef chef juht boss Boss jefe jefe jefe patron capo vad\u012bt\u0101js vadovas f\u0151n\u00f6k patron Patron \u0428\u0435\u0444 baas sjef szef chefe \u0219ef \u0161\u00e9f \u0161ef pomo chef patron \u0645\u062f\u064a\u0631 \u03b1\u03c6\u03b5\u03bd\u03c4\u03b9\u03ba\u03cc \u0448\u0435\u0444 \u0431\u043e\u0441\u0441 \u8001\u677f".split(" ");
if(tf!=`mod=dungeon&loc=${b}`)Pf(`mod=dungeon&loc=${b}`);else{b=!document.getElementById("content").getElementsByTagName("area")[0];const n=document.getElementById("content").getElementsByClassName("button1");if(2<=n.length){c=n[0].getAttribute("name");e=n[1].getAttribute("name");try{if(b){const m=(new URLSearchParams(window.location.search)).get("loc");if("normal"===Kb&&"dif1"===c){const r=I({mod:"dungeon",loc:m,sh:W("sh")}),w=new URLSearchParams({dif1:Kb});fetch(r,{method:"POST",credentials:"include",
headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:w}).then(v=>v.text());n[0].click();window.location.reload()}else if("dif2"===e){const r=I({mod:"dungeon",loc:m,sh:W("sh")}),w=new URLSearchParams({dif2:Kb});fetch(r,{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()},body:w}).then(v=>v.text());n[1].click();window.location.reload()}else Ya("Incorrect dungeon/expedition settings"),setTimeout(()=>{Of()},
1E4)}}catch(m){location.reload()}}else if(b)window.location.reload();else try{const m=document.querySelector("#content .map_label"),r=m&&m.textContent.toLowerCase(),w=Array.from(document.querySelectorAll("#content .map_label")).find(v=>h.some(y=>y===v.textContent));ma("dungeonAttacks",0);if(e&&g)localStorage.setItem("loose","false"),document.querySelectorAll("#content .button1")[0].click();else if(c&&r&&w)document.querySelectorAll("#content .button1")[0].click();else if(r&&w&&"true"===localStorage.getItem("dungeonAB"))w.click();
else if(l){var k=0,q=null;document.querySelectorAll('[onclick*="startFight"]').forEach(function(v){var y=v.getAttribute("onclick").match(/startFight\('(\d+)',/);y&&y[1]&&(y=parseInt(y[1],10),y>k&&(k=y,q=v))});q?q.click():window.location.reload()}else document.querySelector("#content area").click()}catch{window.location.reload()}}}();else if(ta&&vf("arena")&&(!0===Ha||fb.isUnderworld&&qf)&&(!fb.isUnderworld||fb.isUnderworld&&qf)&&aa.player.key==ya&&ya===Qc&&aa.player.Ed>=new Date&&(fb.isUnderworld||
"true"!==localStorage.getItem("HealEnabled")||da.o>Number(localStorage.getItem("healPercentage"))||fb.isUnderworld&&da.o>Number(localStorage.getItem("HellHealHP")))&&!0===document.getElementById("cooldown_bar_fill_arena").classList.contains("cooldown_bar_fill_ready")){async function b(){var h=new URL(window.location.href),k=h.origin;h=h.searchParams.get("sh")||"";var q=localStorage.getItem("scoreRange"),n=[];k=await (await fetch(`${k}/game/index.php?mod=highscore&sh=${h}&a=${q}`)).text();k=(new DOMParser).parseFromString(k,
"text/html");k=Array.from(k.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(m=>(m=m.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===m.style.color||"blue"===m.style.color):null===m);n=[...n,...k];if(0===n.length)return console.log("No players available to attack"),!1;k=JSON.parse(localStorage.getItem("avoidAttackList"))||[];q=function(m){for(var r=m.length,w,v;0!==r;)v=Math.floor(Math.random()*r),--r,w=m[r],m[r]=m[v],m[v]=w;return m}(n);
n=0;for(let m of q)if(q=m.textContent.toLowerCase(),!k.map(r=>r.toLowerCase()).includes(q)){q=await c(m.textContent,h);if(q.includes("index.php?mod=reports")){h=(new URLSearchParams(q)).get("reportId");F(`${d.sa}`+m.textContent);Pf(`mod=reports&submod=showCombatReport&t=2&reportId=${h}`);await new Promise(r=>setTimeout(r,500));return}n++;if(3<=n)break}return!1}async function c(h,k){try{const q=(new URL(window.location.href)).origin;return await (await fetch(`${q}/game/ajax/doArenaFight.php?dname=${h}&a=${(new Date).getTime()}&sh=${k}`,
{method:"POST",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}})).text()}catch{Of(1E3)}}async function e(h){var k=h.opponentId;const q=h.serverId;h=h.country;var n=(new URL(window.location.href)).origin;n=new URL(`${n}/game/ajax.php`);k={mod:"arena",submod:"doCombat",aType:2,opponentId:k,serverId:q,country:h.toString(),a:(new Date).getTime(),sh:W("sh")};n.search=(new URLSearchParams(k)).toString();return await (await fetch(n,{method:"GET",credentials:"include",
headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}})).text()}async function g(){function h(y){const D=null!==y.querySelector("span[style*='color:green;']");return Array.from(y.querySelectorAll("a, span")).find(C=>"green"===C.style.color||"bold"===C.style.fontWeight)||D}var k=new URL(window.location.href);const q=k.origin;var n=await (await fetch(`${q}/game/index.php?mod=arena&sh=${W("sh")}`)).text();n=(new DOMParser).parseFromString(n,"text/html");var m=Array.from(n.querySelectorAll('table[width="80%"] tbody tr')).filter(y=>
y.querySelector(".attack"));if(m.length&&1!==m.length){var r=null;n=JSON.parse(localStorage.getItem("avoidAttackList"))||[];if("true"===localStorage.getItem("leaguerandom")){m=m.sort(()=>Math.random()-.5);for(var w of m){var v=w.querySelector("a");v=v?v.innerText:null;if(!h(w)&&!n.includes(v)){r=w;break}}}else if("true"===localStorage.getItem("leaguelowtohigh")){m=m.sort((y,D)=>parseInt(y.querySelector("th")?y.querySelector("th").textContent:"0",10)-parseInt(D.querySelector("th")?D.querySelector("th").textContent:
"0",10));w=null;r=-1;for(v of m)m=(m=v.querySelector("a"))?m.innerText:null,h(v)||n.includes(m)||(m=parseInt(v?.querySelector("th")?.textContent,10),m>r&&(r=m,w=v));r=w}if(null===r)localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","false"),localStorage.setItem("leagueattackenable","false"),Of(500);else if(r)if(n=r.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],v=(new Date).getTime(),k=k.searchParams.get("sh")||"",await new Promise(y=>setTimeout(y,
250)),k=await (await fetch(`${q}/game/ajax/doArenaFight.php?did=${n}&a=${v}&sh=${k}`)).text(),(n=k.match(/document\.location\.href\s*=\s*'([^']+)'/))&&n[1])window.location=`${q}/game/${n[1]}`;else{k.includes("5")&&("true"===localStorage.getItem("leaguelowtohigh")?(localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","true")):"true"===localStorage.getItem("leaguerandom")&&(localStorage.setItem("leaguerandom","false"),localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leagueattackenable",
"false")),location.reload());if(k.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leagueattackenable","false"),location.reload()}async function l(){function h(t){const u=Date.now(),A=y.findIndex(B=>B.playerName===t);-1<A?y[A].timeout=u:y.push({playerName:t,timeout:u});localStorage.setItem("playerTimeouts",JSON.stringify(y))}function k(t,u){const A=Date.now();if(Array.isArray(y)){const B=y.find(H=>H.playerName===t);return!B||A-B.timeout>u}return!y[t]||A-y[t]>u}function q(t){for(var u=
t.length-1;0<u;u--){const A=Math.floor(Math.random()*(u+1));[t[u],t[A]]=[t[A],t[u]]}2<t.length&&(u=t.splice(0,2),t.push(...u));return t}async function n(t,u,A){try{const B=u.match(/\d+/)[0],H=u.match(/\w+/g)[2],G=(new URLSearchParams(u)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:A,aType:t,opponentId:G,serverId:B,country:H}));const K=await (await fetch(T({mod:"arena",submod:"confirmDoCombat",aType:t,opponentId:G,serverId:B,country:H,a:(new Date).getTime(),sh:W("sh")}),
{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}})).text(),L=(new URLSearchParams(K)).get("reportId");L||window.location.reload();ma("arenaAttacks",0);Pf(`mod=reports&submod=showCombatReport&t=${t}&reportId=${L}`)}catch(B){console.error("Fetch Error:",B),document.getElementById("content").querySelector("form > input").click(),Of(1E3)}}"true"===localStorage.getItem("leagueattackenable")&&await g();"true"===localStorage.getItem("scoreboardattackenable")&&
await b();var m=(new URL(window.location.href)).searchParams.get("sh")||"",r=JSON.parse(localStorage.getItem("autoAttackList"))||[];let w=JSON.parse(localStorage.getItem("autoAttackServerList"))||[];const v=JSON.parse(localStorage.getItem("avoidAttackList"))||[];let y=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const D="true"===localStorage.getItem("onlyArena"),C="true"===localStorage.getItem("onlyPlayerListArena");if(vf("arena")&&0<r.length||vf("arena")&&0<w.length||D||C)try{q(r);localStorage.setItem("autoAttackList",
JSON.stringify(r));q(w);localStorage.setItem("autoAttackServerList",JSON.stringify(w));let t=0,u=3,A=0,B=0;const H=r.length+w.length;D&&(u=15);for(C&&(u=H);t<u&&(A<r.length||B<w.length);){let G,K,L;(L=A<r.length&&B<w.length?.5>Math.random():B<w.length)?(K=w[B],G=K.playerName,B++):(G=r[A],A++);if(!v.includes(G)&&(k(G,6E4*(10+Math.floor(36*Math.random())))||D)){let M;M=L?await e(K):await c(G,m);M.includes("index.php?mod=reports")&&!M.includes("errorRow")&&(h(G),F(`${d.sa}`+G),ma("arenaAttacks",0),window.location.reload())}t++}if(t===
u&&C){F("Tried to attack arena list. Timing out 1min.");Y("arena",1);window.location.reload();return}}catch(t){window.location.reload()}if("mod=arena&submod=serverArena&aType=2"!=tf)Pf("mod=arena&submod=serverArena&aType=2");else try{let t=[...r,...w].map(B=>B.playerName);var E=Array.from(document.querySelectorAll("#own2 tr")).slice(1);const u="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),A="true"===localStorage.getItem("attackRandomly");m=null;r=
Infinity;localStorage.getItem("Username");localStorage.getItem("enableArenaSimulator");localStorage.getItem("ArenaSimulatorAmount");for(let B of E){const H=B.querySelector("a");E=2;A&&(E=Math.floor(5*Math.random())+2);const G=B.querySelector(`td:nth-child(${E})`);if(H&&G){const K=H.innerText,L=parseInt(G.textContent.trim(),10),M=v.includes(K),Z=null!==H.querySelector("span[style*='color:green;']"),ba="green"===H.style.color;if(!(M||!u&&Z&&ba)){if(t.includes(K)){F(`${d.sa}`+K);m=H;break}!m&&L<r&&(r=
L,m=H)}}}if(m)await n(2,m.href,m.outerText);else{const B=document.querySelector('form[name="filterForm"] input[type="submit"]');B&&B.click()}}catch{window.location.reload()}}fb.isUnderworld&&qf&&vf("arena")?(await fetch(I({mod:"underworld",submod:"prayEnd",sh:W("sh")}),{method:"GET",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded","x-csrf-token":x()}}).then(h=>h.text()),await l()):vf("arena")&&await l()}else if(ta&&!0===Ia&&vf("eventPoints")&&("true"===localStorage.getItem("HealEnabled")?
da.o>Number(localStorage.getItem("healPercentage")):1)&&0<jQuery("#submenu2 a").filter(".glow").length)await async function(){var b=jQuery("#submenu2 a").filter(".glow")?jQuery("#submenu2 a").filter(".glow")[0].href.match(/mod=.*&sh/)[0].slice(0,-3):null;try{if(tf!=b)Pf(b);else{var c=document.querySelector("#content .ticker");let e=parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10);b=mc;localStorage.setItem("eventPoints_",e);if(c){let g=document.querySelector('[data-ticker-type="countdown"]').textContent.trim().split(" ").pop(),
[l,h,k]=g.split(":").map(Number),q=(new Date).getTime()+1E3*(3600*l+60*h+k)+1;q?localStorage.setItem("eventPoints.timeOut",q):Y("eventPoints",5);setTimeout(Pf,1E3,"mod=overview")}else if(!c&&0<e){c=b;if("true"===localStorage.getItem("EventAutoMonsterSwitch")){const l=document.querySelectorAll(".expedition_button");for(let h=l.length-1;0<=h;h--)if(!l[h].classList.contains("disabled")&&!l[h].hasAttribute("disabled")){c=h;break}}3==c&&1==e&&(c=2);const g=document.querySelectorAll(".expedition_button")[c];
if(!g||g.classList.contains("disabled")||g.hasAttribute("disabled")){const l=document.querySelectorAll(".expedition_button");for(let h=l.length-1;0<=h;h--)if(!l[h].classList.contains("disabled")&&!l[h].hasAttribute("disabled")){setTimeout(Ih,1E3,l[h]);break}}else setTimeout(Ih,1E3,g)}else!e&&"true"===localStorage.getItem("renewEvent")&&0<Jh().Mn?((new URL(window.location.href)).searchParams.get("loc"),setTimeout(Ih,1E3,document.querySelectorAll(".expedition_button")[b])):0==e&&"false"===localStorage.getItem("renewEvent")?
(Y("eventPoints",5),location.reload()):0==e&&setTimeout(Pf,5E3,"mod=overview")}}catch{document.querySelector('select[name="highscoreNr"]')&&(localStorage.setItem("doEventExpedition","false"),location.reload())}}();else if((Fc||Gc||Hc)&&!zh&&Fc&&ta&&Ah&&(Ch&&Ic&&Eb&&Fb&&vf("AuctionEmpty")||Gc&&Eb&&Fb&&vf("AuctionEmpty")||Hc&&Eb&&Fb&&vf("AuctionMEmpty")||Dh&&Ic&&Eh&&Fh&&vf("AuctionMEmpty")))await Aa.start();else if(ta&&"true"===localStorage.getItem("resetExpiredItems")&&(0<Hh.length||Mj)&&5E3<=da.gold&&
vf("resetExpired"))await sj(localStorage.getItem("resetDays"),Hh);else if(ta){if("true"==localStorage.getItem("useCostume")&&vf("CheckDolls"))await Fj.start();else if("true"===localStorage.getItem("HealEnabled")&&"true"==localStorage.getItem("BuffsEnable")&&vf("BuffCheck"))await vj();else if(!Gh||Yb-Gh>=6E4*Oj)localStorage.setItem("MarketlastRan",Yb.toString()),"true"==localStorage.getItem("enableMarketSearch")&&aa.player.key==ya&&"true"==sessionStorage.getItem("autoGoActive")&&await pf.mo();11001<
Ec&&(F(`Waiting for ${Zb} seconds...`),await new Promise(b=>setTimeout(b,Ec)));jf()}let z3=localStorage.getItem("we");we=new Date(z3);aa.player.Ed<new Date&&we<new Date&&aa.player.key!=ya&&hb()}}})();const Mh={we:"Auto Switch to next monster when available?",cg:"There is a problem with the market search. Please re-add items to fix.",Lb:"Not enough space in selected inventory to smelt.",ck:"Smelt Higher Colors First?",cc:"Only Attack to player list?",dc:"This option will only attack arena/circus list. If cant, bot will skip for a minute.",Mk:"Your expedition settings are incorrect or there is an unexpected page data!",Nk:"Your expedition setting is incorrect! You set it to disabled monster which is wrong.",
$k:"Reset only all underworld items with selected color?",Ca:"Priority",Vb:"Set Priority",Rg:"Points",Kh:"Stat",Si:"Collect Gold",Oj:"Sell Underworld Items?",uj:"Bot will look for nest in every action, not just expeditions.",sj:"Nest Search Type",qj:"Nothing",rj:"Quick",tj:"Thorough",Ml:"After expedition points are consumed, travel to Germania to consume Dungeon points",zk:"Use this if the bot gets stuck in the repair!",Ok:"When HP is below, use heal",Ng:"Partial Repair",af:"Full Repair",Mg:"Partial or Full Repair",
re:"Enable Limit",kj:"Limit",lj:"If you want to limit the number of times you want to attack to the enemy, enable this option and set the limit. Bot will continue to attack rest of the enemies after it finishes attacking to the selected monster.",me:"Do not enter underworld with underworld costume?",le:"If you dont want to enter underworld while you have underworld costume on, enable this option",yi:"Underworld",pi:"Underworld Buffs",si:"Use god powers after entering the underworld?",ti:"Select gods to use powers from:",
ui:"Use Weapon Buff on the weapon?",vi:"Use Armor Buff on the following equipment:",Jk:"Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.",al:"Select Colors",$a:"Vulcanus Forge",eb:"Feronia`s Earthen Shield",fb:"Neptune`s Fluid Might",gb:"Aelous` Aerial Freedom",hb:"Pluto`s Deadly Mist",ib:"Juno`s Breath of Life",jb:"Wrath Mountain`s Scale Armour",kb:"Eagle Eyes",lb:"Saturn`s Winter Garment",ab:"Bubona` Bull Armour",bb:"Mercerius` Robber`s Garments",cb:"Ra` Light Robe",
lg:"Packages",gg:"Inventory",M:"Min Price",L:"How Many",Fb:"Sell Items",Eb:"Search in",hg:"Material Color",Db:"Item Color",og:"Warehouse",Aa:"Switch to Materials",Hb:"Switch to Items",ng:"Sell Materials",xa:"Please enter a valid item name and price range and how many.",ya:"No suitable items found in the selected search locations.",za:"All items listed successfully!",Uk:"All materials listed successfully!",jg:"If you want to sell items for fixed price, you can enter the same value for both min and max price.",
kg:"This feature is still experimental, use with caution. If you dont put fixed price, it will list items randomly between min and max price you enter.",Kj:"Repair Before Smelt",Vj:"Select the item types you want to smelt.",Wj:"Select the colors you want to smelt.",Xj:"Select the level of the items you want to smelt.",Yj:"Select the hammer you want to use",Zj:"Note that Green and Red circle next to the first box are for enabling/disabling the rule.",$j:"If you want to use smelt randomly any colors or types, you can enable `Smelt randomly if no conditions met? (Last enabled option in the tutorial video)",
Fk:"Sets the max gold that the bot will spend per cycle.",Va:"Bot will start bidding on any food items, if enabled. You do not require to enable gladiator/mercenary toggles",Ld:"Bot will not bid on allies` bids.",Md:"Ignore Prefix/Suffix Combination when looking for an item in the auction.",Oe:"Select Monster",Ce:"Use Hourglass/Ruby?",Lk:"Use Ruby?",Fe:"Use Mobilization?",Ee:"Use Life Potion?",Be:"Heal Percentage (%)",Me:"Number of Attacks",De:"Attack Interval (in seconds)",ze:"Attacks Performed",
Ae:"Hourglass Left",Ke:"Note: It uses lifepotions to heal, not food.",Le:"Note: If attacks stop prematurely, try 'Reset Attacks'.",Pe:"Start",Ne:"Reset",Qe:"Stop",Re:"Expedition Settings (Click to minimize)",Ge:"Monster 1",He:"Monster 2",Ie:"Monster 3",Je:"Monster 4",Xk:"Repair Before Smelt",Qi:"This option will use cervisia when your premium expires.",xj:"This option will enables and picks oils from god rewards. It can use number 1 and number 3 oils on the character but number 2 will only be picked to packages.",
Oi:"This option will use buffs at the time you set. It will find buffs in packages and apply it to the character.",mj:"This option will enter you to the underworld when your expedition points are below 3. Dont forget to enable Auto Login from Extras tab, otherwise you might get logged out upon entering underworld[Game Bug]",ec:"This option will only attack arena/circus list.If cant, bot will skip.",Hj:"This option is only for premium licenses. It simulates the attack before attacking a user for %75 win rate.",
Od:"You do not need to enable main auction toggle to enable this option.",sk:"This option will refresh the page every second when auction is in -Very Short- state to bid constantly to win the auction.",Tj:"If none of the smelt conditions are met, it will smelt randomly. Make sure to select item type and color.",Uj:"This option will only smelt items from inventory. It will ignore items in packages.",Wa:"Auction Items",rg:"Mercenary Items",Xb:"Shop Items",Ai:"Unique Items",Pj:"Set background to black [Increases performance]",
Qj:"Move GLDbot buttons to bottom left?",Ri:"Attack Circus Without Heal",rk:"Pick gold from packages if needed?",bm:"Gold has been picked from packages for training",Fd:"No gold has been found in packages for training",El:'GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.',lk:"Items Repaired",ek:"Arena Attacks",gk:"Circus Attacks",mk:"Items Reset",jk:"Expedition Attacks",ik:"Dungeon Attacks",pk:"Underworld Attacks",
fk:"Money Earned from Arena",hk:"Money Earned from Circus",nk:"Items Smelted",kk:"Gold Cycled",dj:"Guild Battle",fj:"Guild Settings",tl:"Will attack guilds randomly.",cj:"Attack Random Guilds?",ej:"Guild Name",Pi:"Reset Stats",Pc:"Wood",Fc:"Copper",Jc:"Iron",Lc:"Leather",Qc:"Wool",Gc:"Cotton Wool",Ic:"Hemp",Hc:"Gauze Strip",Mc:"Linen Strip",Kc:"Jute Patch",Oc:"Velvet",Nc:"Silk Thread",Yc:"Fur",Sc:"Bone Splinter",ad:"Scale",Vc:"Claw",Xc:"Fang",Wc:"Dragon Scale",Tc:"Bull`s Horn",$c:"Poison Gland",Uc:"Cerberus` Pelt",
Zc:"Hydra Scale",bd:"Sphinx Feather",cd:"Typhon Leather",Cc:"Lapis Lazuli",wc:"Amethyst",vc:"Amber",xc:"Aquamarine",Dc:"Sapphire",Ac:"Garnet",zc:"Emerald",yc:"Diamond",Bc:"Jasper",Ec:"Sugilite",qc:"Scorpion Poison",tc:"Tincture of Stamina",mc:"Antidote",lc:"Adrenaline",sc:"Tincture of Enlightenment",pc:"Potion of Perception",nc:"Essence of Reaction",oc:"Phial of Charisma",uc:"Waters of Oblivion",rc:"Soul Essence",Bd:"Water Seal",vd:"Protection Rune",td:"Earth Mark",Ad:"Totem of Healing",zd:"Talisman of Power",
xd:"Stone of Fortune",ud:"Flintstone",yd:"Storm Rune",wd:"Shadow Rune",gd:"Crystal",fd:"Bronze",ld:"Obsidian",od:"Silver",pd:"Sulphur",jd:"Gold Ore",nd:"Quartz",md:"Platinum",ed:"Almandin",hd:"Cuprit",kd:"Hellstone",Li:"Attack Randomly in Provinciarum?",Mi:'Also disable "Sort players in arena by level" setting in crazy-addon.',$g:"Only accept quests based on god type.",Xa:"Auto Buff",be:"Use it in hell only?",Gg:"New Rule",Eg:"Name Contains",isUnderworldItem:"Is Underworld Item",kf:"Ignore Materials",
yk:"Use Pray?",xi:"When in underworld only accept underworld related quests?",wi:"If enabled, you need to enter underworld item names. If the bot finds these items in the underworld, it will accept the quest.",el:"Underworld Quest Item",ql:"Enter Material Name",Ik:"The bot loves dice! They help find clothes in chests. But if there are no dice, the bot opens chests anyway, hoping for some cool clothes (but it might not find any!).",Sj:"Send smelted materials to package?",qe:"Enable Arena",Sg:"Prioritize arena list?",
Tg:"Prioritize circus list?",ie:"Disable Log Menu",oh:"Reward Min. Gold Value",ah:"Focus Quest, if enabled, will follow the shortest path to finish the dungeon.",Nh:"Throw Dice Automatically?",Oh:"Use throw dice cautiously, it will keep using the first dice until you disable the option.",uh:"Search Progress",ih:"Cooldown for repair by default is 10 minutes.",Bg:"Minimum Condition",ge:"Current item on workbench [Clear if bot pauses unexpectedly]",Gf:"Forge Resources stored to horreum successfully.",
Cf:"Checking marketplace for items...",Ab:"Item moved to workbench.",Tf:"Item successfully repaired and equipped.",Uf:"Item successfully repaired.",Sk:"Repair failed. Page will be refreshed.",Qf:"Picking up materials...",bg:"Waiting for repair...",Sf:"Repair has started for .",wa:"Repair: Moving the item from inventory to bag",Rf:"Repair: Moving the item from workbench to package.",ua:"Could not find enough materials. Disabling the repair slot for 5 minutes ",Nf:"Looking for items to buy to hide gold in Auction...",
zf:"Checking for expired items in packages...",Af:"Item successfully reset.",Bf:"No Empty Space or Gold to Reset.",Hf:"Make sure you have sell rights in guild market!",ub:"Not enough gold/or no item to buy. Waiting for 30sec to refresh.",wb:"Store has been refreshed.",xb:"Error while healing.",Kf:"No Ruby or Cloth, disabling the options.",Rk:"No healing item found in packages.",yb:"No suitable items found",Lf:"Foods have been picked. Ending the process.",Mf:"At least one food has been picked. Ending process.",
zb:"No suitable space found in bag to pick food.",If:"Getting food from packages.",Jf:"No suitable space found in bag to pick food.",vb:"No more heal items. Waiting for 30 seconds.",tb:"HP Recovered.",va:"Nothing to do so I am going to pray!",Yf:"Im going to refresh in 60 seconds to check for my health and villa medici.",Zf:"Waiting for Villa Medici, refreshing in 60 seconds.",$f:"Left underworld.",ag:"Im going to refresh in 60 seconds to check for my health.",Of:"Checking for god oils...",Pf:"God oils have been picked.",
sa:"Successfully attacked player in ARENA: ",ta:"Successfully attacked player in CIRCUS: ",xf:"Checking auction! Please wait...",yf:"Bidding to items. Please wait...",Vf:"Auto Smelted Item: ",Wf:"Smelting Item: ",Bb:"Not enough gold to smelt. Required Gold: ",Xf:"SMELT: Looking for items to smelt...",Tk:"Looking for items to smelt...",Df:"Checking costume availability...",Ff:"Donated : ",Ef:"Throwing dice...",Xe:"Underworld Farm [Manual, Beta]",Ye:"Be aware: Turn on this feature after unlocking the creature you want to attack, it will not automatically attack to unlock the monster.",
We:"Farm Location",Ve:"Farm Enemy",Vd:"Auto Login",Wd:"You need to allow pop-ups from the lobby screen for GameForge. See documentation on how to do it.",Og:"Pause Bot",Pg:"Pause Bot in (Minutes)",Te:"Expiration Date",Jg:"Only buy food?",Kg:"If you enable this, it will ignore your selections and buy food automatically without entering anything.",Jb:"Max total gold to spend",Ib:"Max gold per food to spend",Ig:"Bot will check oils every 60 minutes",fi:"Sets a timer to check smelting times.",ci:"Sets a timer to check smelting after you dont have gold.",
ei:"Sets a timer to check smelting if you dont have available item.",Yh:"Sets a timer for repair to check your items.",Xh:"Sets a timer to check guild market hold gold.",Th:"Sets a timer for auction hold gold option.",Ph:"Sets a timer to check the arena pvp list to attack.",Uh:"Sets a timer to check the circus pvp list to attack.",li:"Sets a timer for training to train your stats.",$h:"Sets a timer to reset expired items.",ji:"Sets a timer to store forge materials to horreum.",Rh:"Sets a timer to check gladiatos & mercenary auction.",
bi:"Sets a timer to search for items in auction&shop.",Vh:"Sets the timer of sending donation to the guild.",bf:"Gold Moved",ne:"Don't sell smelt & auction list items",vh:"Shop Automation",xh:"Item Search Settings",wh:"Use this tool to search for items in shops. Simply add the items to the list, specify the cloth amount, and start the search.",yh:"Cloths to use:",zh:"How many cloths to use?",fa:"Enter Full Item Name",Wb:"Enter Item Level",Bh:"Item Quality",Ah:"Item Name Here",Ch:"Start Searching",
Dh:"Skip and Continue",Eh:"Stop Searching",Ze:"Buy cheapest or expensive?",Dg:"Most Expensive",de:"Cheapest",Da:"Select an option",se:"Highlight Underworld Items",$e:"Focus on the quest?",dm:"Use ruby if there isnt cloth?",Ya:"Add cross-server players: Find profile, use A & C buttons. Play nice: Avoid targeting same players to dodge reports/bans.",Tl:"Smelt Green?",Vg:"Do not accept random quests if entered any filters?",Rc:"Max Material Quality to use",$i:"Enable Mercenary Search",Al:"Click \u2018Sell All Selected\u2019 to sell all items. Make sure to have 2x3 empty space in your first (1) bag and select quality. To mass collect Gold, use `USE GOLD` panel below or filter gold and use the `Pick Selected or Pick All`",
dk:"\ud83d\udd25 : Adds item to smelting list.",Ni:"\ud83d\udd28 : Adds item to auction list.",Jj:"Refresh shop automatically with cloth when its full.",Il:"Page:",Fj:"Stop",Dj:"Sell This Page",Aj:"Pick Selected",zj:"Pick All",Gj:"Auto Package Settings",Ej:"Send Resources",Bj:"Sell All Selected",na:"Item Type",pa:"Weapons",U:"Shields",O:"Armour",S:"Helmets",R:"Gloves",P:"Boots",oa:"Rings",la:"Amulets",Ka:"Usables (Foods)",Pa:"Upgrades",yj:"Boosts",Ma:"Recipes",La:"Mercenary",Oa:"Forging Tools",Na:"Scrolls",
sd:"Reinforcements",qd:"Event Items",rd:"Forging Goods",Hl:"Gold",Ja:"All",Jl:"Quality",qa:"White",C:"Green",B:"Blue",D:"Purple",J:"Orange",T:"Red",Cj:"Sell All Options",Rj:"Ignore Prefix/Suffix Combination?",gj:"How many food to buy/pick?",Vi:"Normal",Ui:"Middle",Ti:"Hard",Ga:"Standard",Nl:"Repair Stuck Fix",Pk:"Underworld mode will automatically disable Dungeon/Arena/Circus, and enable all of them after underworld. Disable Enter Underworld if you want to disable Dungeon/Circus/Arena. If you entered underworld manually, you need to enable underworld Mode.",
oi:"Set how many times you want to train the stats and their priorities. The bot wont train unless you set a priority. If there is no more stat left but priority is set, it will continue with checked stat.",nl:"Quest",Dd:"Smelt",Yl:"Smelt Settings",ak:"Smelted Items",Zl:"Add Prefix or Suffix, once it finds it in the packages it will smelt automatically. If you only want to look for all the items listed without checking their combination, enable Ignore combination option.",Xl:"Smelting Item:",ic:"Click on the item you want to repair and choose the highest quality materials to use. You need to have at least 10,000 gold for the repair to start. Ensure you have a 3x3 space available in your first inventory bag and make sure a food item or any small item is not in the first inventory space otherwise, it might get stuck!. The bot will start the repair once the item has the condition you have chosen. Repair now should be able to continue from where it was left off. Items that have a Hint tooltip might cause a problem.",
gl:"Apply only to Mercenary",jl:"Auction will only bid when market is close to the end.",il:"Smelting will prioritize starting from the first item to search. You can drag and drop to change priority. Smelt will start when you have over 7k gold. ",jj:"Heal & Buffs",Ol:"Not enough gold to smelt. Required Gold:",Rl:"Skipping bid: Guild member has already bid for item ",Ql:"Skipping bid: Already bid for item ",advanced:"Advanced",arena:"Arena",ja:"Auto Attack",fc:"Avoid Attack",ha:"Add Player",ia:"Add Player Name (Same Server)",
vl:"Stop Bot if run out of food?",circusTurma:"Circus Turma",Wi:"Difficulty",dungeon:"Dungeon",Xi:"Dungeon Settings",eventExpedition:"Event Expedition",expedition:"Expedition",aj:"Expedition Settings",Lj:"Select Monster",xl:"Highest",wl:"Put your heal stuff in first page of your inventory",nj:"In",Lh:"Store Gold in Guild Market",Mh:"Store Gold in Auction",rh:"Use Clothes to renew Shop?",Zk:"Select Items to Reset",kh:"Reset Expired Items",Qb:"Note: By enabling this option, the bot will sell upcoming expired items from Packages to Guild Market then cancels to reset expiration time. Guild is required. Make sure you have empty 3x3 space in your bags. It checks last 7 pages per cycle. This might slow down the bot while it is checking for the pages to reset. If it doesnt work, set display expiry date as Date in game settings.",
Qg:"Pause bot randomly to work as [Testing Phase]:",aa:"Hold Gold: Bot will keep this gold in the bag:",pg:"Max Gold: Bot will spend when the gold is greater than",ph:"Bot will bid on random items.",Gd:"Add Random Delay",Hd:"You can add a delay to bot here.",Pb:"Repair",Sl:"Smelt Blue?",Vl:"Smelt Purple?",Ul:"Smelt Orange?",bk:"Smelt Everything Only From Inventory?",Wl:"`Smelt Tab` works only for `Smelt Everything Only From Inventory` option. Rest of the options will use selected smelt tab. This will ignore color and ignore list items. Tab 1 is reserved for repair.",
Gh:"Smelt",Pd:"Auto Search",Fg:"Auto Auction",Qd:"Excess use of Auction might result in ban. If you enabled auction on Crazy-Addon please disable before using this. Note that, if you put only one item to PREFIX section, bot will try to filter by the items name for faster bidding. Although you need to disable bidding food for this.",qh:"Search in Gladiators Auction",th:"Search in Mercenary Auction",Yd:"Bid Food?",qg:"Maximum Bid",Zd:"Bid if the status is less than",$d:"Bidded Items",Dk:"Auction Language",
Ek:"Please set the language according to your ingame language, otherwise auction wont work.",Kd:"You can add items to look for items in market and auction. It will also show purple items in the market once you add an item into the list.",Bk:"Use auction with caution!",Ck:"Auto bid makes too many requests to the server causing white page error and can cause a ban if you use it often!!",hh:"Renew Event Points with Ruby?",ue:"Enable Auto Oil",Gk:"Auto Get Holy Oils",Vk:"Quest Check Speed",Ua:"Attack Guild Members?",
Sa:'Auto add people to the "Attack" list when X GOLD is stolen:',Ta:'Automatically add people to the "Avoid Attack" list when you lose to them:',Tb:"Scoreboard Attacks",ac:"Very Long",Cb:"Long",Kb:"Middle",Yb:"Short",bc:"Very Short",ve:"Enter Underworld if HP >",bh:"Quest Check Speed",Ug:'Default is "3x". If bot causes problems with quests, change quest speed according to your server speed.',cf:"Heal Pick Bag",xe:'If you are renewing points manually, you need to click the button above "Refresh Event Expedition if stuck!',
Kk:"You must enable at least one of the following: expedition, dungeon, arena, or circus to start the Event Expedition.",eh:"Refresh Event Expedition if stuck!",mb:"Dont bid on Allies` Bids?",bl:"Leave all settings disabled if you wish to smelt using packages that contain the items in the list. However, you still need to choose colors.",Hk:"Character(Off) / Mercenary(On)",Yk:"Repair Both?",cl:"Timers",Timers:"Enter the number of minutes for each timer below or leave it default. Be aware! If you enter very low numbers, bot might get stuck in loop!",
Zg:"Quest Filter Ignore",Yg:"Enter keywords to filter out quests you do not want to take",X:"Enter Keyword",K:"Add",gh:"Remove",fe:"Clear",Wg:"Quest Filter Accept",Xg:"Enter keywords to choose which quests to take. You can also use this to accept quests by their reward using keyword. Using this will ignore Quest Types",Ea:"Skip Time Quests?",Wk:"Quests",Sd:"Auto Costume",Di:"Use Costume?",Xd:"Basic Battle",oe:"Dungeon Battle & Event",ee:"Choose underworld costume",Ji:"Wear Underworld costume when available?",
Td:'To ensure the bot doesnt override your Underworld costume, make sure to select "Wear Underworld costume when available?" and "Choose Underworld costume." The bot will only switch to Dis Pater Normal and Medium costumes if your expedition or dungeon points are at 0.',ef:"Underworld Heal Settings",Jd:"Attack Boss When Available?",sb:"League attack will disable itself after 5 unsuccessful attack.",hf:"Holy Oils",Ag:"Item Name",ba:"Min. Item Level",Ba:"Min. Item Quality",Id:"Apply/Reset Timer",lf:"Ignore Prefix/Suffix Combination",
Ki:"Yes",Hg:"No",Qa:"Add Prefix",Ra:"Add Suffix",Za:"Clear History",Hh:"Ignore List",Mb:"Prefix",Zb:"Suffix",mh:"Reset Expiring Items",Ih:"Smelt randomly if no conditions met?",Jh:"Smelt Tab",qb:"Extras",Nd:"Auction",ig:"Market",$b:"Timers",hi:"Smelting",gi:"Smelting if not enough gold",di:"Smelt if no item",Fa:"Repair",Wh:"Guild Market Hold Gold",Sh:"Auction Hold Gold",ki:"Training",Zh:"Reset Expired",ii:"Store Forge",Qh:"Auction Check",ai:"Search",v:"Enable",Cg:"Minimum Gold",Ub:"Select Hour",nb:"Donate Gold to Guild",
je:"Donates every 5 minutes. You can change the interval from timers tab",jf:"How much to donate?",ke:"Donate when you have more than >",wf:"Less than <",jh:"Reset Expired and Other settings",lh:"Reset in:",Qk:"Hold Ctrl (Cmd on Mac) to select multiple items",mf:"Import/Export Settings",Ue:"Export Settings",nf:"Import Settings",tg:"Message All Players",ug:"[Requires Ultra Premium Key, message on Discord to get the key.]",vg:"Enter message to send",he:"For custom scripts contact us on Discord",xg:"Send",
yg:"Show Players",wg:"SelectAll",zg:"UnselectAll",vf:"Make sure your inventory has enough space. Cooldown is 2 minutes.",pb:"Enable Scoreboard Attack:",Rb:"Select Range to Attack",Sb:"Bot will randomly attack from the scoreboard list.",rb:"League Attack",ob:"Enable League Attack:",Nb:"Randomly Attack",Ob:"Attack lowest to highest",Ak:"Bot will avoid attacking guild members by default.",Se:"Expedition Location:",Rd:"Auto Collect Bonuses:",Fh:"Skip Boss",pe:"Dungeon Location:",nh:"Reset if lose?",ff:"Underworld Settings",
gf:"Underworld: Runs from start to finish! Set your heal % in the Heal tab (activate it first). Underworld Mode uses Underworld Heal %, so expect more food consumption. Enable Auto-login in Extras if logout occurs.",df:"Underworld Difficulty:",Ud:"Auto Enter Underworld / Underworld Mode:",Ei:"Use Mobilization if points = 0",Ii:"Use rubies?",Gi:"Use Sacrifice to heal?",uk:"Use Cloth to enter underworld?",ye:"Exit underworld if no points?",ri:"The bot will try to use Villa Medici first and disable itself if there is no available Villa Medici; if thats the case, it will use a healing potion. Dont forget to enable Heal toggle.",
zi:"Auto enter Underworld will disable dungeon/arena/circus upon entering underworld.",dl:"Underworld Heal Settings",Hi:"Use Villa Medici?",Fi:"Use Healing Potion?",dg:"INFO: The bot will search for market items every selected minutes, which may pause attacking during the search.",te:"Enable Market Search:",eg:"Market Search Interval in Minutes:",fg:"Suggested 10 minutes.",rf:"Item Settings:",pf:"Item Name Includes",G:"Max Price",sf:"Item Type",qf:"Item Rarity",ce:"Buy Soulbound?",uf:"Items to Buy",
tf:"Buy packs if any of them match the maximum price entered?",ae:"Bought Items:",hj:"Heal Percentage",wk:"Buy Food from Shop?",xk:"Use Heal from Package?",tk:"Use Cervisia? (packages included)",vk:"Use Eggs? (packages included)",Bl:"Last Used",location:"Location",Strength:"Strength",Dexterity:"Dexterity",Agility:"Agility",Constitution:"Constitution",Charisma:"Charisma",Intelligence:"Intelligence",mi:"Train Settings",ni:"Select the attributes you want to train. It will train once you have enough gold.",
N:"Next action",vj:"No",wj:"Normal",Fl:"Opponent",Gl:"Opponent Level",Ij:"Quests",random:"Random",Pl:"Settings",$l:"Soon...",type:"Click on icons to activate quest types. Select first 3 if you want to focus on Circus & Arena",fm:"Yes",A:"Search",Cd:"Add item",qk:"Store Forge Resources automatically",am:"Submit",zl:"Interval : ",ol:"Enable Auto Bid",pl:"Cover Allies` Bids",cm:"Tutorial",hc:"More users will slow down the bot.",hl:"Begin by adding an items full name to the list. Once added, the tool will display search results on the left. This also aids in auto-auction searches. With auto-bid enabled, the tool will periodically search based on your set interval. If the item is found and you have sufficient funds, it will bid automatically. Note: To search for unique items in shops, you must add at least one item to the search list..",
rl:"The creature number can be selected from the buttons above. Number 1 represents the leftmost creature. Make sure you select the correct location otherwise bot might pause.",Yi:"Choose the difficulty of the dungeon from the options above. Ensure you select the correct location, as otherwise, the bot might pause.",ij:"Heal Settings",Zi:"Store excess gold in Guild by buying guild market items. -> Min. Gold. Leave some empty space in first inventory.",Cl:"Move All",Dl:"Move Selected",kl:"Auto Heal",
ll:"Auto Heal Percentage",em:"Ruby",Lg:"General Settings",Mj:"Sell All",Nj:"Sell Selected",ga:"Weapons",da:"Shields",W:"Chest Armour",Z:"Helmets",Y:"Gloves",ea:"Shoes",ca:"Rings",V:"Amulets",Ci:"Usable",Bi:"Upgrades",dh:"Recipes",sg:"Mercenary Scroll",fh:"Reinforcements",mg:"Sell Food",Gb:"Switch to Food"},Ph={we:"Otomatik Etkinlik Canavar\u0131 De\u011fi\u015ftir?",cg:"Market hatas\u0131! L\u00fctfen itemlari tekrar ekleyip tekrar deneyin.",Lb:"Eritmek icin yeterli alan yok!",ck:"Once daha y\u00fcksek renkleri erit?",
cc:"Sadece oyuncu listesine sald\u0131r?",dc:"Bu se\u00e7enek etkinle\u015ftirildi\u011finde, bot sadece oyuncu listesindeki oyunculara sald\u0131racak. Bu se\u00e7enek etkinle\u015ftirilmezse, bot rastgele oyunculara saldiracak.",Mk:"Sefer ayarlar\u0131n\u0131z yanl\u0131\u015f veya beklenmedik bir sayfa verisi var!",Nk:"Sefer ayar\u0131n\u0131z yanl\u0131\u015f! Devre d\u0131\u015f\u0131 b\u0131rak\u0131lm\u0131\u015f bir canavara ayarlad\u0131n\u0131z, bu yanl\u0131\u015f.",$k:"Sadece se\u00e7ilen renge sahip t\u00fcm yeralt\u0131 \u00f6\u011felerini s\u0131f\u0131rla?",
Ca:"\u00d6ncelik",Vb:"\u00d6ncelik Ayarla",Rg:"Puanlar",Kh:"Stat Ad\u0131",Si:"Alt\u0131n Topla",Oj:"Yeralt\u0131 itemleri satilsin mi?",uj:"Bot her eylemde yuva arayacak, sadece ke\u015fiflerde de\u011fil.",sj:"Yuva arama t\u00fcr\u00fc",qj:"Bir Sey Yapma",rj:"Hizli Ara",tj:"Kapsamli Ara",Ml:"Expedition Sonras\u0131 Eylem",zk:"Tamir takilirsa TIKLA",Ok:"Kaca dustugunde iyilestirsin?",Ng:"K\u0131smi Onar\u0131m",af:"Tam Onar\u0131m",Mg:"K\u0131smi veya Tam Onar\u0131m",re:"Limiti Etkinle\u015ftir",
kj:"Limit",lj:"D\u00fc\u015fmana sald\u0131rmak istedi\u011finiz kez say\u0131s\u0131n\u0131 s\u0131n\u0131rlamak istiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin ve limiti ayarlay\u0131n. Bot, se\u00e7ilen canavara sald\u0131rmay\u0131 bitirdikten sonra di\u011fer d\u00fc\u015fmanlara sald\u0131rmaya devam edecek.",me:"Yeralt\u0131 kost\u00fcm\u00fc ile yeralt\u0131na girmeyin",le:"Yeralt\u0131 kost\u00fcm\u00fc varken yeralt\u0131na girmek istemiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin",
yi:"Yeralt\u0131 D\u00fcnyas\u0131",pi:"Yeralt\u0131 D\u00fcnyas\u0131 G\u00fc\u00e7lendirmeleri",si:"Yeralt\u0131 d\u00fcnyas\u0131na girdikten sonra tanr\u0131 g\u00fc\u00e7lerini kullan?",ti:"G\u00fc\u00e7lerini kullanmak istedi\u011fin tanr\u0131lar\u0131 se\u00e7:",ui:"Silaha Silah G\u00fc\u00e7lendirmesi kullan?",vi:"A\u015fa\u011f\u0131daki ekipmana Z\u0131rh G\u00fc\u00e7lendirmesi kullan:",Jk:"Bekleme s\u00fcresi 30 dakikad\u0131r. \u00dczerinde kost\u00fcm yoksa, bot bekleme s\u00fcresini s\u0131f\u0131rlar.",
al:"Renkleri Se\u00e7",$a:"Vulcano`nun Demirci Atesi",eb:"Feronia`nin Toprak Kalkani",fb:"Neptune`un sivi gucu",gb:"Aelous`un havali ozgurlugu",hb:"Pluto`nun olumcul nefesi",ib:"Juno`nun Hayat Solugu",jb:"Ofkeli Dag Ejderhasi Pul Zirhi",kb:"Kartal Bakisi",lb:"Saturn`un kisi giysisi",ab:"Bubona`nin okuz zirhi",bb:"Mercerius`un Hirsiz Kaftani",cb:"Ra`nin isikli esvabi",lg:"Paketler",gg:"Envanter",M:"Min. Fiyat",L:"Ka\u00e7 Tane",Fb:"E\u015fya Sat",Eb:"\u015eurada Ara",hg:"Malzeme Rengi",Db:"E\u015fya Rengi",
og:"Depo",Aa:"Malzemelere Ge\u00e7",Hb:"E\u015fyalara Ge\u00e7",ng:"Malzeme Sat",xa:"L\u00fctfen ge\u00e7erli bir e\u015fya ad\u0131, fiyat aral\u0131\u011f\u0131 ve miktar girin.",ya:"Se\u00e7ilen arama konumlar\u0131nda uygun e\u015fya bulunamad\u0131.",za:"T\u00fcm e\u015fyalar ba\u015far\u0131yla listelendi!",Uk:"T\u00fcm malzemeler ba\u015far\u0131yla listelendi!",jg:"Sabit fiyata e\u015fya satmak istiyorsan\u0131z, min ve maks fiyat i\u00e7in ayn\u0131 de\u011feri girebilirsiniz.",kg:"Bu \u00f6zellik hala deneyseldir, dikkatli kullan\u0131n. Sabit fiyat koymazsan\u0131z, girdi\u011finiz minimum ve maksimum fiyat aras\u0131nda rastgele \u00f6\u011feler listeleyecektir.",
Vj:"Eritmek istedi\u011finiz e\u015fya t\u00fcrlerini se\u00e7in.",Wj:"Eritmek istedi\u011finiz renkleri se\u00e7in.",Xj:"Eritmek istedi\u011finiz e\u015fyalar\u0131n seviyesini se\u00e7in.",Yj:"Kullanmak istedi\u011finiz \u00e7ekici se\u00e7in.",Zj:"\u0130lk kutunun yan\u0131ndaki Ye\u015fil ve K\u0131rm\u0131z\u0131 \u00e7emberin kural\u0131 etkinle\u015ftirme/devre d\u0131\u015f\u0131 b\u0131rakma i\u00e7in oldu\u011funa dikkat edin.",$j:"E\u011fer rastgele herhangi bir renk veya t\u00fcr\u00fc ergitmek istiyorsan\u0131z, Ko\u015fullar sa\u011flanmazsa rastgele eritilsin mi? (E\u011fitim videosundaki son etkinle\u015ftirilen se\u00e7enek) se\u00e7ene\u011fini etkinle\u015ftirebilirsiniz.",
Fk:"Bot`un her d\u00f6ng\u00fcde harcayaca\u011f\u0131 maksimum alt\u0131n\u0131 belirler.",Va:"Etkinle\u015ftirilirse, bot herhangi bir yiyecek \u00f6\u011fesi i\u00e7in teklif vermeye ba\u015flar. Gladyat\u00f6r/asker ayar\u0131n\u0131 etkinle\u015ftirmeniz gerekmez.",Ld:"Bot, m\u00fcttefiklerin tekliflerine teklif vermez.",Md:"A\u00e7\u0131k art\u0131rmada bir \u00f6\u011fe ararken \u00d6nek/Son ek kombinasyonunu g\u00f6rmezden gelir.",Kj:"Eritmeden \u00f6nce tamir et?",Oe:"Canavar Se\u00e7",Ce:"Kum Saati/Rub kullan?",
Lk:"Rub kullan?",Fe:"Mobilizasyon Kullan?",Ee:"Ya\u015fam \u0130ksiri Kullan?",Be:"\u0130yile\u015ftirme Y\u00fczdesi (%)",Me:"Sald\u0131r\u0131 Say\u0131s\u0131",De:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131 (saniye cinsinden)",ze:"Yap\u0131lan Sald\u0131r\u0131lar",Ae:"Kalan Kum Saati",Ke:"Not: \u0130yile\u015ftirmek i\u00e7in yiyecek de\u011fil, ya\u015fam iksiri kullan\u0131r.",Le:"Not: Sald\u0131r\u0131lar erken durursa, 'Sald\u0131r\u0131lar\u0131 S\u0131f\u0131rla' deneyin.",Pe:"Ba\u015flat",
Ne:"S\u0131f\u0131rla",Qe:"Durdur",Re:"Ke\u015fif Ayarlar\u0131 (K\u00fc\u00e7\u00fcltmek i\u00e7in t\u0131klay\u0131n)",Ge:"Canavar 1",He:"Canavar 2",Ie:"Canavar 3",Je:"Canavar 4",Xk:"Eritmeden \u00f6nce tamir et?",Qi:"Bu se\u00e7enek, premium \u00fcyeli\u011finiz sona erdi\u011finde cervisia kullanacak.",xj:"Bu se\u00e7enek, tanr\u0131 \u00f6d\u00fcllerinden ya\u011flar\u0131 etkinle\u015ftirir ve se\u00e7er. Karakter \u00fczerinde 1 numara ve 3 numara ya\u011flar\u0131 kullanabilir ancak 2 numara sadece paketlere al\u0131n\u0131r.",
Oi:"Bu se\u00e7enek, belirledi\u011finiz zamanda buff kullan\u0131r. Paketlerdeki bufflar\u0131 bulur ve karaktere uygular.",mj:"Bu se\u00e7enek sizi kesif seferleriniz 2 ve altina geldiginde yeralt\u0131 d\u00fcnyas\u0131na sokar. Ekstralar sekmesinden Otomatik Giri\u015fi etkinle\u015ftirmeyi unutmay\u0131n, yoksa yeralt\u0131na girerken \u00e7\u0131k\u0131\u015f yapabilirsiniz [Oyun Hatas\u0131]",ec:"Bot sadece arena veya circus listesindekilere saldirir. Saldiramazsa atlar.",Hj:"Bu se\u00e7enek sadece premium lisanslar i\u00e7indir. Kullan\u0131c\u0131ya sald\u0131rmadan \u00f6nce %75 kazanma oran\u0131 ile sald\u0131r\u0131y\u0131 sim\u00fcle eder.",
Od:"Bu se\u00e7ene\u011fi etkinle\u015ftirmek i\u00e7in ana m\u00fczayede ge\u00e7i\u015fini etkinle\u015ftirmenize gerek yoktur.",sk:"Bu se\u00e7enek, m\u00fczayede -\u00c7ok K\u0131sa- durumundayken sayfay\u0131 her saniye yeniler ve s\u00fcrekli teklif vererek m\u00fczayede kazanmay\u0131 ama\u00e7lar.",Tj:"E\u011fer eritme ko\u015fullar\u0131ndan hi\u00e7biri kar\u015f\u0131lanmazsa rastgele eritir. L\u00fctfen e\u015fya tipini ve rengini se\u00e7in.",Uj:"Bu se\u00e7enek sadece envanterdeki e\u015fyalar\u0131 eritir. Paketlerdeki e\u015fyalar\u0131 g\u00f6rmezden gelecektir.",
Pj:"Arkaplan\u0131 Siyah yap",Qj:"Bot butonlarini sol alta koy?",Ri:"Iyilestirme olmadan Sirke Sald\u0131r?",rk:"Gerekirse paketlerden alt\u0131n al\u0131ns\u0131n?",bm:"E\u011fitim i\u00e7in paketlerden alt\u0131n al\u0131nd\u0131",Fd:"E\u011fitim i\u00e7in paketlerde alt\u0131n bulunamad\u0131",El:'GLDbot: Gizem kutusunu yenilemek ve de\u011ferli e\u015fyalar\u0131 (Vb. Kost\u00fcmler) a\u00e7madan \u00f6nce bulmak i\u00e7in zarlar\u0131 kullan. Sand\u0131klar\u0131 a\u00e7mak i\u00e7in "Ba\u015flat"a t\u0131kla.',
Wa:"Muzayede Esyalari",rg:"Mersaneri Esyalari",Xb:"Dukkan Esyalari",Ai:"Degerli Dukkan Esyalari",lk:"E\u015fyalar Tamir Edildi",ek:"Arena Sald\u0131r\u0131lar\u0131",gk:"Sirk Sald\u0131r\u0131lar\u0131",mk:"E\u015fyalar S\u0131f\u0131rland\u0131",jk:"Sefer Sald\u0131r\u0131lar\u0131",ik:"Zindan Sald\u0131r\u0131lar\u0131",pk:"Yeralt\u0131 Sald\u0131r\u0131lar\u0131",fk:"Arenadan Kazan\u0131lan Para",hk:"Sirkten Kazan\u0131lan Para",nk:"E\u015fyalar Eritildi",kk:"D\u00f6n\u00fc\u015ft\u00fcr\u00fclen Alt\u0131n",
dj:"Lonca Sava\u015f\u0131",fj:"Lonca Ayarlar\u0131",tl:"Loncalara rastgele sald\u0131racak.",ej:"Lonca Ismi",cj:"Rastgele Sald\u0131r",Pi:"\u0130statistikleri S\u0131f\u0131rla",Pc:"Ah\u015fap",Fc:"Bak\u0131r",Jc:"Demir",Lc:"Deri",Qc:"Y\u00fcn \u0130plik",Gc:"Y\u00fcn Yuma\u011f\u0131",Ic:"Kenevir",Hc:"Gaze \u015eeridi",Mc:"Keten Par\u00e7as\u0131",Kc:"J\u00fct Dikimi",Oc:"Kadife \u015eerit",Nc:"\u0130pek \u0130plik",Yc:"Post Par\u00e7as\u0131",Sc:"Kemik Par\u00e7as\u0131",ad:"Kepek",Vc:"Pen\u00e7e",
Xc:"K\u00f6pek Di\u015fi",Wc:"Ejderha Kepe\u011fi",Tc:"Bo\u011fa Boynuzu",$c:"Zehir Bezesi",Uc:"Cerberus`un post par\u00e7as\u0131",Zc:"Hidra pulu",bd:"Sfenks t\u00fcy\u00fc",cd:"Tifon derisi",Cc:"Lacivert Tasi",wc:"Ametist",vc:"Kehribar",xc:"Akuamarin",Dc:"Safir",Ac:"Grena Ta\u015f\u0131",zc:"Z\u00fcmr\u00fct",yc:"Elmas",Bc:"Jaspis",Ec:"Sugilith",qc:"Akrep Zehri",tc:"Dayan\u0131kl\u0131l\u0131k Tent\u00fcr\u00fc",mc:"Antidot",lc:"Adrenalin",sc:"Ayd\u0131nl\u0131k Tent\u00fcr\u00fc",pc:"Alg\u0131 Tent\u00fcr\u00fc",
nc:"Refleks Esans\u0131",oc:"Karizma Flakonu",uc:"Unutman\u0131n Suyu",rc:"Ruh esans\u0131",Bd:"Su M\u00fchr\u00fc",vd:"Koruyucu Runik",td:"D\u00fcnya Grav\u00fcr\u00fc",Ad:"\u015eifa Totemi",zd:"G\u00fc\u00e7 T\u0131ls\u0131m\u0131",xd:"\u015eans Ta\u015f\u0131",ud:"Ate\u015f Ta\u015f\u0131",yd:"F\u0131rt\u0131na Runi\u011fi",wd:"G\u00f6lge runi\u011fi",gd:"Kristal",fd:"Bronz",ld:"Obsidyen",od:"G\u00fcm\u00fc\u015f",pd:"K\u00fck\u00fcrt",jd:"Alt\u0131n Madeni",nd:"Kuvars",md:"Platin",ed:"Almandin",
hd:"Cuprit",kd:"Cehennem ta\u015f\u0131",Li:"Provinciarum'da Rastgele Sald\u0131r?",Mi:'Crazy-addon\'da "Arena oyuncular\u0131n\u0131 seviyeye g\u00f6re s\u0131rala" se\u00e7ene\u011fini de devre d\u0131\u015f\u0131 b\u0131rak\u0131n.',$g:"Sadece tanr\u0131 t\u00fcr\u00fcne g\u00f6re g\u00f6rev kabul et.",Xa:"Oto Buff",be:"Sadece cehennemde kullan?",Gg:"Yeni Kural",Eg:"\u0130sim \u0130\u00e7erir",isUnderworldItem:"Yeralt\u0131 item mi?",kf:"Malzemeleri Yoksay",yk:"Dua Kullan?",Gi:"\u015eifalanmak i\u00e7in Kurban Kullan?",
uk:"Yeralt\u0131na girmek i\u00e7in kuma\u015f kullan?",xi:"Yeralt\u0131nda sadece yeralt\u0131 ile ilgili g\u00f6revleri kabul et?",wi:"Etkinle\u015ftirilirse, yeralt\u0131 item adlar\u0131n\u0131 girmeniz gerekir. Bot, bu itemlari yeralt\u0131nda bulursa g\u00f6revi kabul eder.",el:"Yeralt\u0131 G\u00f6rev Itemi",ql:"Malzeme Ad\u0131n\u0131 Girin",Ik:"Bot zarlar\u0131 sever! Zarlar, sand\u0131klarda k\u0131yafet bulmaya yard\u0131mc\u0131 olur. Ancak zar yoksa, bot yine de sand\u0131klar\u0131 a\u00e7ar ve k\u0131yafetler bulmay\u0131 umar (ama bulamayabilir!).",
Sj:"Ertilen malzemeleri pakete g\u00f6nder?",qe:"Arena'y\u0131 Etkinle\u015ftir",Sg:"Arena listesini \u00f6nceliklendir?",Tg:"Sirk listesini \u00f6nceliklendir?",ie:"Log Men\u00fcs\u00fcn\u00fc Devre D\u0131\u015f\u0131 B\u0131rak",oh:"\u00d6d\u00fcl Min. Alt\u0131n De\u011feri",ah:"Odaklanm\u0131\u015f G\u00f6rev, etkinle\u015ftirilirse, zindan\u0131 bitirmek i\u00e7in en k\u0131sa yolu izler.",Nh:"Zar\u0131 Otomatik At?",Oh:"Zar\u0131 dikkatli kullan\u0131n, ilk zar\u0131 se\u00e7ene\u011fi devre d\u0131\u015f\u0131 b\u0131rakana kadar kullanmaya devam eder.",
uh:"Arama \u0130lerlemesi",ih:"Onar\u0131m\u0131n varsay\u0131lan bekleme s\u00fcresi 10 dakikad\u0131r.",Bg:"Minimum Durum",ge:"\u0130\u015f tezgah\u0131ndaki mevcut \u00f6\u011fe [Bot beklenmedik \u015fekilde durursa Temizle]",Gf:"D\u00f6k\u00fcm Kaynaklar\u0131 ba\u015far\u0131yla horreuma depoland\u0131.",Cf:"Pazar yerindeki \u00f6\u011feleri kontrol ediyor...",Ab:"\u00d6\u011fe i\u015f tezgah\u0131na ta\u015f\u0131nd\u0131.",Tf:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131 ve donat\u0131ld\u0131.",
Uf:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131.",Sk:"Onar\u0131m ba\u015far\u0131s\u0131z oldu. Sayfa yenilenecek.",Qf:"Malzemeler toplan\u0131yor...",bg:"Onar\u0131m bekleniyor...",Sf:"Onar\u0131m ba\u015flad\u0131.",wa:"Onar\u0131m: \u00d6\u011feyi envanterden \u00e7antaya ta\u015f\u0131ma",Rf:"Onar\u0131m: \u00d6\u011feyi i\u015f tezgah\u0131ndan pakete ta\u015f\u0131ma.",ua:"Yeterli malzeme bulunamad\u0131. Onar\u0131m slotunu 5 dakikaligina devre disi birakiyorum. ",Nf:"Alt\u0131n\u0131 saklamak i\u00e7in a\u00e7\u0131k art\u0131rmadan sat\u0131n al\u0131nacak \u00f6\u011feler aran\u0131yor...",
zf:"Paketlerdeki s\u00fcresi dolmu\u015f \u00f6\u011feler kontrol ediliyor...",Af:"\u00d6\u011fe ba\u015far\u0131yla s\u0131f\u0131rland\u0131.",Bf:"Bo\u015f Alan veya S\u0131f\u0131rlanacak Alt\u0131n Yok.",Hf:"Klan pazar\u0131nda sat\u0131\u015f haklar\u0131n\u0131z oldu\u011fundan emin olun!",ub:"Yeterli alt\u0131n ve/veya sat\u0131n al\u0131nacak \u00f6\u011fe yok. Yenilemek i\u00e7in 30sn bekliyor.",wb:"Ma\u011faza yenilendi.",xb:"\u0130yile\u015ftirme s\u0131ras\u0131nda hata.",Kf:"Ruby veya Kuma\u015f yok, se\u00e7enekleri devre d\u0131\u015f\u0131 b\u0131rak.",
Rk:"Paketlerde yiyecek bulunamad\u0131.",yb:"Uygun yiyecek bulunamad\u0131",Lf:"Yiyecekler topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",Mf:"En az bir yiyecek topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",zb:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",If:"Paketlerden yiyecek al\u0131n\u0131yor.",Jf:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",vb:"Daha fazla iyile\u015ftirme \u00f6\u011fesi yok. 30 saniye bekliyor.",tb:"HP Kurtar\u0131ld\u0131.",
va:"Yapacak bir \u015fey yok, bu y\u00fczden dua edece\u011fim!",Yf:"Sa\u011fl\u0131\u011f\u0131m\u0131 ve villa medicimi kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Zf:"Villa Medici bekleniyor, 60 saniye i\u00e7inde yenileniyor.",$f:"Underworld terk edildi.",ag:"Sa\u011fl\u0131\u011f\u0131m\u0131 kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Of:"Tanr\u0131 ya\u011flar\u0131 kontrol ediliyor...",Pf:"Tanr\u0131 ya\u011flar\u0131 topland\u0131.",sa:"ARENADA ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",
ta:"CIRCUS'ta ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",xf:"A\u00e7\u0131k art\u0131rma kontrol ediliyor! L\u00fctfen bekleyin...",yf:"\u00d6\u011felere teklif veriliyor. L\u00fctfen bekleyin...",Vf:"Otomatik Eritilen Item: ",Wf:"Eritme \u00d6\u011fesi: ",Bb:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n: ",Xf:"ER\u0130T: Eritilecek \u00f6\u011feler aran\u0131yor...",Tk:"Eritilecek \u00f6\u011feler aran\u0131yor...",Df:"Kost\u00fcm mevcudiyeti kontrol ediliyor...",Ff:"Ba\u011f\u0131\u015fland\u0131 : ",
Ef:"Zar at\u0131l\u0131yor...",Xe:"Yeralti Farmla [Manuel, BETA]",Ye:"Bu ozelligi saldirmak istediginiz yaratigi actiktan sonra acin, otomatik olarak yaratigi acana kadar saldirmayacaktir. Dikkat edin.",We:"Farm Lokasyonu",Ve:"Farm Dusmani",Vd:"Otomatik Giri\u015f",Wd:"GameForge lobisinden a\u00e7\u0131l\u0131r pencere izinlerini vermeniz gerekmektedir. Nas\u0131l yap\u0131laca\u011f\u0131na dair dok\u00fcmantasyona bak\u0131n.",Og:"Bot'u Durdur",Pg:"Bot'u ka\u00e7 dakika bitince durdurmak istersiniz? (Dakika)",
Te:"Son Kullanma Tarihi",Jg:"Sadece yemek sat\u0131n al?",Kg:"Bunu etkinle\u015ftirirseniz, se\u00e7imlerinizi g\u00f6rmezden gelir ve herhangi bir \u015fey girmeden otomatik olarak yemek sat\u0131n al\u0131r.",Jb:"Harcamak i\u00e7in maksimum toplam alt\u0131n",Ib:"Harcamak i\u00e7in maksimum alt\u0131n miktar\u0131",Ig:"Bot, ya\u011flar\u0131 her 60 dakikada bir kontrol edecek",fi:"Eritme s\u00fcrelerini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",ci:"Alt\u0131n\u0131n\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
ei:"Kullan\u0131labilir e\u015fyan\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Yh:"E\u015fyalar\u0131n\u0131z\u0131 kontrol etmek i\u00e7in bir tamir zamanlay\u0131c\u0131 ayarlar.",Xh:"Ittifak pazar\u0131ndaki alt\u0131n\u0131 kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Th:"M\u00fczayede tutma alt\u0131n\u0131 se\u00e7ene\u011fi i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Ph:"Arenadaki PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Uh:"Sirk PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",li:"\u0130statistiklerinizi e\u011fitmek i\u00e7in bir e\u011fitim zamanlay\u0131c\u0131 ayarlar.",$h:"S\u00fcresi dolmu\u015f e\u015fyalar\u0131 s\u0131f\u0131rlamak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",ji:"D\u00f6vme malzemelerini horreum'a koymak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Rh:"Gladyat\u00f6rler ve paral\u0131 askerler m\u00fczayede kontrol\u00fc i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
bi:"M\u00fczayede ve market i\u00e7in e\u015fya aramak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Vh:"Ittifaga ba\u011f\u0131\u015f g\u00f6nderme zamanlay\u0131c\u0131s\u0131n\u0131 ayarlar.",bf:"Alt\u0131n Ta\u015f\u0131nd\u0131",ne:"Eritme ve Muzayede listesi e\u015fyalar\u0131n\u0131 satma",vh:"Market Otomasyonu",xh:"E\u015fya Arama Ayarlar\u0131",wh:"Bu ozellik, dukkanlarda e\u015fya aramak i\u00e7in kullanilir. Sadece e\u015fyalar\u0131 listeye ekleyin, kuma\u015f miktar\u0131n\u0131 belirtin ve aramay\u0131 ba\u015flat\u0131n. Ornegin mor samnit, mor samnit i bulana kadar arar.",
yh:"Kullan\u0131lacak Kuma\u015flar:",zh:"Ka\u00e7 kuma\u015f kullan\u0131lacak?",fa:"Full E\u015fya Ad\u0131n\u0131 Girin",Wb:"E\u015fya Seviyesini Girin",Bh:"E\u015fya Kalitesi",Ah:"E\u015fya Ad\u0131 Buraya",Ch:"Aramaya Ba\u015fla",Dh:"Atla ve Devam Et",Eh:"Aramay\u0131 Durdur",Ze:"En ucuz mu, en pahal\u0131 m\u0131 alay\u0131m?",Dg:"En Pahal\u0131",de:"En Ucuz",Da:"Bir se\u00e7enek se\u00e7in",se:"Yeralt\u0131 D\u00fcnyas\u0131 Itemlarini Goster",$e:"G\u00f6reve odaklan\u0131ls\u0131n m\u0131?",
dm:"Elbise yoksa yakut kullan?",Ya:"Diger serverlarda sald\u0131rmak icin, oyuncunun sayfasini acin ve A & C butonlariyla ekleyin. Not: Rapor edilmemek i\u00e7in ayn\u0131 ki\u015filere sald\u0131rmaktan ka\u00e7\u0131n\u0131n. Rapor edilmek, banlanma \u015fans\u0131n\u0131z\u0131 art\u0131r\u0131r.",Tl:"Yesil Eritilsin mi?",Vg:"Herhangi bir filtre girildiyse rastgele g\u00f6revleri kabul etme?",Rc:"Maksimum materyal kalitesi?",$i:"Mersaneri Ara?",Al:"T\u00fcm Se\u00e7ilenleri Sat\u2019\u0131 t\u0131klay\u0131n ve t\u00fcm e\u015fyalar\u0131 sat\u0131n. \u0130lk (1) \u00e7antan\u0131zda 2x3 bo\u015f alan oldu\u011fundan emin olun ve kalite secmeyi unutmayin. Alt\u0131n toplamak i\u00e7in, alt\u0131n\u0131 filtreleyin ve `Se\u00e7ilenleri Al veya T\u00fcm\u00fcn\u00fc Al`\u0131 kullan\u0131n",
dk:"\ud83d\udd25 : E\u015fyay\u0131 eritme listesine ekler.",Ni:"\ud83d\udd28 : E\u015fyay\u0131 a\u00e7\u0131k art\u0131rma listesine ekler.",Jj:"D\u00fckkan dolu oldu\u011funda d\u00fckkan\u0131 kuma\u015fla yenileyin",Il:"Sayfa:",Fj:"Durdur",Dj:"Bu Sayfay\u0131 Sat",Aj:"Se\u00e7ilenleri Al",zj:"T\u00fcm\u00fcn\u00fc Al",Gj:"Paket Ayarlar\u0131",Ej:"Kaynaklar\u0131 G\u00f6nder",Bj:"T\u00fcm Se\u00e7ilenleri Sat",na:"E\u015fya T\u00fcr\u00fc",pa:"Silahlar",U:"Kalkanlar",O:"Z\u0131rhlar",S:"Kasklar",
R:"Eldivenler",P:"Ayakkabilar",oa:"Y\u00fcz\u00fckler",la:"Nazarliklar",Ka:"Malzemeler (Yiyecekler)",Pa:"G\u00fc\u00e7lendirmeler",yj:"Yukseltmeler",Ma:"Receteler",La:"Mersaneri Askerler",Oa:"Demirhane Mallari",Na:"Persomenler",sd:"Takviyeler",qd:"Etkinlik E\u015fyalar\u0131",rd:"D\u00f6vme Malzemeleri",Hl:"Alt\u0131n",Ja:"Hepsi",Jl:"Kalite",qa:"Beyaz",C:"Ye\u015fil",B:"Mavi",D:"Mor",J:"Turuncu",T:"K\u0131rm\u0131z\u0131",Cj:"T\u00fcm Sat\u0131\u015f Se\u00e7enekleri",Rj:"\u00d6nek/Sonek Kombinasyonunu Yoksay?",
gj:"Ka\u00e7 yiyecek sat\u0131n almak/al\u0131nmal\u0131?",Vi:"Normal",Ui:"Orta",Ti:"Zor",Ga:"Standart",Nl:"S\u0131k\u0131\u015fma Onar\u0131m\u0131",Pk:"Dungeon/Circus/Arena\u2019y\u0131 devre d\u0131\u015f\u0131 b\u0131rakmak istiyorsan\u0131z Cehenneme Giri\u015fi Devre D\u0131\u015f\u0131 B\u0131rakin. Cehenneme manuel olarak girdiyseniz, Cehennem Modu\u2019nu etkinle\u015ftirmeniz gerekecektir.",oi:"Egitimleri ka\u00e7 kez e\u011fitmek istedi\u011finizi ve onlar\u0131n \u00f6nceliklerini belirleyin. Bot, bir \u00f6ncelik belirlemedik\u00e7e e\u011fitim yapmayacakt\u0131r. E\u011fer \u00f6ncelik belirlenmi\u015fse ancak ba\u015fka bir egitim kalmam\u0131\u015fsa, secilen egitim devam edecektir.",
nl:"Gorev",Dd:"Erit",Yl:"Eritme Ayarlar\u0131",ak:"Eritilen Nesneler",Zl:"\u00d6nek veya Sonek Ekle, paketlerde bulunursa otomatik olarak eritilecektir.:",Xl:"Eritilen Nesne:",ic:"Onarmak istedi\u011finiz nesneyi t\u0131klay\u0131n. Onar\u0131ma ba\u015flamak i\u00e7in en az 10,000 alt\u0131n\u0131z\u0131n olmas\u0131 gerekmektedir. Yeni repair sistemi refresh atilsa bile kaldigi yerden devam edecektir. Sorun cikarsa clear a basip workbench itemini temizleyebilirsiniz. Ayr\u0131ca envanterinizde yer a\u00e7mayi unutmayin. Bot, kondisyon seciminize gore aktif olacaktir.",
gl:"Sadece S\u00f6zle\u015fmeliye Uygula",jl:"M\u00fczayede yaln\u0131zca piyasa sona yakla\u015ft\u0131\u011f\u0131nda teklif verecektir.",il:"Envanterde bos yer acmayi ve en az 7K alt\u0131n\u0131n\u0131z\u0131n oldu\u011fundan emin olun. Bot 1. koydugunuz prefixden baslayip sona dogru bakacaktir, bu siralamayi uzerine gelip tasiyarak degistirebilirsiniz. Bot, sectiginiz sekmeye gore itemlari tasiyacak ve eritecektir. Eritme i\u015flemi her ayarlanan zamana gore kontrol edilir. Bu ayari Zamanlayici sekmesinden degistirebilirsiniz. Eger kombinasyon olarak bakmak istemiyorsaniz, onek sonek kombinasyonunu yoksay`i aktiflestirin.",
jj:"\u0130yile\u015ftirme/Buff",Ol:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n:",Rl:"Teklifi Atla: ittifak \u00fcyesi zaten nesne i\u00e7in teklif verdi ",Ql:"Teklifi Atla: Zaten nesne i\u00e7in teklif verildi ",advanced:"Geli\u015fmi\u015f",arena:"Arena",ja:"Otomatik sald\u0131r\u0131 listesi",fc:"Bu listedekilere sald\u0131rma",ha:"Oyuncu Ekle",ia:"Oyuncu Ad\u0131 Gir (Ayni Server)",vl:"Yiyecek t\u00fckenirse Botu Durdur?",circusTurma:"Sirkin Turma",Wi:"Zorluk",dungeon:"Zindan",
Xi:"Zindan Ayarlar\u0131",eventExpedition:"Etkinlik Seferi",expedition:"Sefer",aj:"Sefer Ayarlar\u0131",Lj:"Yarat\u0131k Se\u00e7",xl:"En Y\u00fcksek",wl:"\u0130yile\u015ftirme e\u015fyalar\u0131n\u0131z\u0131 envanterinizin ilk sayfas\u0131na koyun",nj:"\u0130\u00e7inde",ee:"Yeralti kostumu secin",Ji:"Yeralti kostumu hazir oldugunda giy?",Lh:"Alt\u0131n\u0131 Depola",Mh:"Alt\u0131n\u0131 M\u00fczayedede Depola?",rh:"D\u00fckk\u00e2n\u0131 yenilemek i\u00e7in \u0130\u015f K\u0131yafetleri kullan\u0131ls\u0131n m\u0131?",
Zk:"S\u0131f\u0131rlanacak Nesneleri Se\u00e7in",kh:"S\u00fcresi Dolan Nesneleri S\u0131f\u0131rla",Qb:"Not: Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, bot paketlerden gelecek s\u00fcresi dolan nesneleri ittifak marketine satar ve s\u00fcrelerini s\u0131f\u0131rlar. Ittifak gereklidir. \u00c7antalar\u0131n\u0131zda bo\u015f 3x3 alan\u0131n\u0131z oldu\u011fundan emin olun, ozellikle birinci canta. Her basladiginda son 7 sayfaya bakar. Eger calismazsa oyun ayarlarindan sure bitimini tarih olarak ayarlayin.",
Qg:"Bota Rastgele Ara Vermesini Sa\u011fla [Test A\u015famas\u0131]:",aa:"Alt\u0131n\u0131 Tut: Bot bu alt\u0131n\u0131 \u00e7antada saklayacak:",pg:"Maksimum Alt\u0131n",ph:"Gereksiz itemlar i\u00e7in teklif verilecek",Gd:"Rastgele Gecikme Ekle",Hd:"Bot i\u00e7in rastgele gecikme ekleyebilirsiniz.",Pb:"Onar\u0131m",Sl:"Mavi Eritilsin mi?",Vl:"Mor Eritilsin mi?",Ul:"Turuncu Eritilsin mi?",bk:"Sadece envantere koyulanlari mi eritsin?",Wl:"Bu renk se\u00e7imlerini yok sayacakt\u0131r",Qa:"\u00d6nek Ekle",
Ra:"Sonek Ekle",Gh:"Erit",Pd:"Otomatik Arama",Fg:"Otomatik M\u00fczayede",Qd:"Bu ozelligi fazla kullanmak banlanmaniza sebep olabilir. Eger Crazy Addon`da muzayedeyi zamanlarini gosteren ozelligi aktif ettiyseniz bu ozelligi kullanmadan once onu iptal edin, yoksa yavaslama olacaktir.",qh:"Gladyat\u00f6rler M\u00fczayedesinde Ara",th:"Mersaneriler M\u00fczayedesinde Ara",Yd:"Yiyecek \u0130\u00e7in Teklif Verilsin mi?",qg:"Maksimum Teklif",Zd:"Durum daha azsa teklif ver",$d:"Teklif Edilen Nesneler",
Dk:"M\u00fczayede Dili",Ek:"L\u00fctfen dil ayarlarini oyunun diline gore tekrar ayarlay\u0131n.. Hepsi do\u011fru oldu\u011fundan emin olun, aksi takdirde teklif vermeyebilir.",Kd:"Piyasada aranacak nesneleri ekleyebilirsiniz. Bir nesneyi listede ekledi\u011finizde, nesneyi arayacak ve sonu\u00e7lar\u0131 sol tarafta g\u00f6sterecektir. Otomatik m\u00fczayedeyi aramak i\u00e7in de arayacakt\u0131r. Otomatik teklifi etkinle\u015ftirirseniz, belirledi\u011finiz aral\u0131klarla nesneyi arayacak ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: Tekil nesneleri d\u00fckkanlarda aramak i\u00e7in, en az\u0131ndan bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
Bk:"M\u00fczayedeyi dikkatli kullan\u0131n!",Ck:"Otomatik teklif, sunucuya \u00e7ok fazla istek g\u00f6nderir ve s\u00fcrekli kullan\u0131rsan\u0131z yasa\u011fa neden olabilir!",hh:"Etkinlik Puanlar\u0131n\u0131 Yakut ile Yenile?",ue:"Otomatik Ya\u011f Topla",Gk:"Kutsal Ya\u011flar\u0131 Otomatik Al",Vk:"G\u00f6rev Kontrol H\u0131z\u0131",Ua:"Ittifak \u00dcyelerine Sald\u0131r\u0131ls\u0131n m\u0131?",Sa:"Oto Sald\u0131r\u0131 listesine cal\u0131nan Alt\u0131n X ALTINI a\u015ft\u0131\u011f\u0131nda > eklensin mi? ",
Ta:"Yenildi\u011finizde otomatik olarak eklensin mi?:",Tb:"Skor Tablosu Sald\u0131r\u0131lar\u0131",ac:"\u00c7ok Uzun",Cb:"Uzun",Kb:"Orta",Yb:"K\u0131sa",bc:"\u00c7ok K\u0131sa",ve:"HP > ise Yeralt\u0131 D\u00fcnyas\u0131'na Gir",bh:"G\u00f6rev Kontrol H\u0131z\u0131",Ug:'Varsay\u0131lan olarak "3x" ayarl\u0131d\u0131r. Bot g\u00f6revlerle sorun \u00e7\u0131kar\u0131yorsa, g\u00f6rev h\u0131z\u0131n\u0131 sunucu h\u0131z\u0131n\u0131za g\u00f6re ayarlay\u0131n.',cf:"\u0130yile\u015ftirme \u00c7anta Se\u00e7imi",
xe:'Puanlar\u0131 manuel olarak yeniliyorsan\u0131z, s\u0131k\u0131\u015f\u0131rsa "Yeniden Etkinlik Seferi Yenile" d\u00fc\u011fmesine t\u0131klaman\u0131z gerekmektedir!',Kk:"Etkinlik Seferi'ni ba\u015flatmak i\u00e7in en az birini etkinle\u015ftirmeniz gerekmektedir: sefer, zindan, arena veya sirk.",eh:"E\u011fer s\u0131k\u0131\u015f\u0131rsa Etkinlik Seferi'ni Yenile!",mb:"\u0130ttifak \u00fcyesi teklif verdiyse atlas\u0131n m\u0131?",bl:"E\u011fer paketlerde bulunan \u00f6\u011feleri kullanarak eritmek istiyorsan\u0131z, t\u00fcm ayarlar\u0131 devre d\u0131\u015f\u0131 b\u0131rak\u0131n. Ancak hala renkleri se\u00e7ebilirsiniz.",
Hk:"Karakter(Kapal\u0131) / S\u00f6zle\u015fmeli(A\u00e7\u0131k)",Yk:"Ana/Sirk her iki karakteri de tamir etsin mi?",cl:"Zamanlar",Timers:"Her zamanlay\u0131c\u0131 i\u00e7in a\u015fa\u011f\u0131daki dakika cinsinden say\u0131lar\u0131 girin veya varsay\u0131lan b\u0131rak\u0131n. Dikkat edin! eger cok kisa sureler girerseniz baz\u0131 ozellikler botu donguye sokayabilir.",pb:"Skor Tablosu Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Rb:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131n\u0131 Se\u00e7",
Sb:"Bot, skor tablosu listesinden rastgele sald\u0131r\u0131 yapacakt\u0131r.",rb:"Lig Sald\u0131r\u0131s\u0131",ob:"Lig Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Nb:"Rastgele Sald\u0131r",Ob:"En d\u00fc\u015f\u00fckten en y\u00fckse\u011fe sald\u0131r",Ak:"Bot, varsay\u0131lan olarak ittifak \u00fcyelerine sald\u0131rmaktan ka\u00e7\u0131nacakt\u0131r.",Se:"Sefer Yeri:",Rd:"Bonuslar\u0131 Otomatik Al:",Fh:"Boss`a sald\u0131rma",pe:"Zindan Yeri:",nh:"Kaybederseniz S\u0131f\u0131rlans\u0131n m\u0131?",
ff:"Cehennem Ayarlar\u0131",gf:"Bu mod birden sona kadar saldirarak cehennemi bitirir. \u0130yile\u015ftirme y\u00fczde ayarlar\u0131n\u0131z\u0131 iyile\u015ftirme sekmesinden yap\u0131land\u0131r\u0131n ve iyile\u015ftirme sekmesini etkinle\u015ftirdi\u011finizden emin olun. Cehennem modu aktif oldugunda bot cehennem iyilestirme oranina gore karakterinize yemek yedirecektir. Cehenneme giri\u015f sizi oturumdan \u00e7\u0131kar\u0131yorsa, extralar tabini ziyaret edin ve otomatik giri\u015f kutusunu i\u015faretleyin.",
df:"Cehennem Zorlu\u011fu",Ud:"Otomatik Cehennem Giri\u015fi / Cehennem Modu:",Ei:"Puan = 0 ise Mobilizasyon Kullan?",Ii:"Yakut Kullan?",ye:"Puan Yoksa Cehennemden \u00c7\u0131k\u0131ls\u0131n m\u0131?",ri:"Bot, \u00f6nce villa mediciyi kullanmaya \u00e7al\u0131\u015facakt\u0131r, e\u011fer yoksa iyile\u015ftirme iksiri kullanacakt\u0131r. \u0130yile\u015ftirme anahtar\u0131n\u0131 etkinle\u015ftirdi\u011finizden emin olmay\u0131 unutmay\u0131n.",zi:"Otomatik cehennem giri\u015fi, cehenneme girdi\u011finizde zindan/arena/sirk otomatik olarak devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",
dl:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",Hi:"Villa Medici Kullan?",Fi:"\u0130yile\u015ftirme \u0130ksiri Kullan?",dg:"Bu ozellik genel marketten esya almaya yarar. Satin alma suresi biraz surebilir.",te:"Pazar Aramas\u0131n\u0131 Etkinle\u015ftir:",eg:"Dakika cinsinden Pazar Arama Aral\u0131\u011f\u0131:",fg:"\u00d6nerilen 10 dakika.",rf:"Nesne Ayarlar\u0131:",pf:"Nesne Ad\u0131 \u0130\u00e7erir",G:"Maksimum Fiyat",sf:"Nesne T\u00fcr\u00fc",qf:"Nesne Nadirli\u011fi",ce:"Ruh Ba\u011fl\u0131 Al\u0131ns\u0131n m\u0131?",
uf:"Al\u0131nacak Nesneler",tf:"Herhangi biri maksimum fiyat\u0131 a\u015f\u0131yorsa \u00f6\u011feleri almay\u0131 deneyin.:",ae:"Sat\u0131n Al\u0131nan Nesneler:",hj:"\u0130yile\u015ftirme Y\u00fczdesi",wk:"D\u00fckkandan Yiyecek Sat\u0131n Al\u0131ns\u0131n m\u0131?",xk:"Paketten \u0130yile\u015ftirme Kullan\u0131ls\u0131n m\u0131?",tk:"Cervisia Kullan\u0131ls\u0131n m\u0131?",vk:"Yumurta Kullan\u0131ls\u0131n m\u0131?",Bl:"Son Kullan\u0131ld\u0131",location:"Konum",Strength:"G\u00fc\u00e7",Dexterity:"Beceri",
Agility:"\u00c7eviklik",Constitution:"Dayaniklilik",Charisma:"Karizma",Intelligence:"Zeka",mi:"E\u011fitim Ayarlar\u0131",ni:"E\u011fitim yapmak istedi\u011finiz nitelikleri se\u00e7in. Yeterli alt\u0131n\u0131z oldu\u011funda e\u011fitim yapacakt\u0131r.",N:"Sonraki ad\u0131m",vj:"Hay\u0131r",wj:"Normal",Fl:"Rakip",Gl:"Rakip Seviyesi",Ij:"G\u00f6revler",random:"Rastgele",Pl:"Ayarlar",$l:"Yak\u0131nda...",type:"G\u00f6rev t\u00fcrlerini etkinle\u015ftirmek i\u00e7in simgeleri t\u0131klay\u0131n.",
fm:"Evet",A:"Arama",Cd:"\u00d6\u011feleri ekle",qk:"Demircilik Kaynaklar\u0131n\u0131 Otomatik Olarak Sakla",am:"G\u00f6nder",zl:"Aral\u0131k : ",ol:"Otomatik Teklif Etkinle\u015ftir",pl:"Bir ittifak \u00fcyesi zaten teklif verdiyse teklif vermeyin",cm:"\u00d6\u011fretici",hc:"Arena'da en d\u00fc\u015f\u00fck veya en y\u00fcksek seviyeli rakiple y\u00fczle\u015fmek isteyip istemedi\u011finizi yukar\u0131daki d\u00fc\u011fmelerden se\u00e7in. Daha fazla kullan\u0131c\u0131, botun h\u0131z\u0131n\u0131 yava\u015flatabilir.",
hl:"Ba\u015flamak i\u00e7in bir \u00f6\u011feyi listeyle ekleyin (\u00f6r. `Lucius`). Ekledikten sonra, arama sonu\u00e7lar\u0131n\u0131 sol tarafta g\u00f6r\u00fcnt\u00fclemek i\u00e7in arama sonu\u00e7lar\u0131n\u0131 g\u00f6sterir. Ayn\u0131 zamanda otomatik m\u00fczayede ama\u00e7lar\u0131 i\u00e7in de arar. Otomatik teklifi etkinle\u015ftirirseniz, belirli aral\u0131klarla \u00f6\u011feyi arar ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: D\u00fckkanlarda benzersiz \u00f6\u011feleri aramak i\u00e7in, en az bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
rl:"Yarat\u0131k numaras\u0131n\u0131 yukar\u0131daki d\u00fc\u011fmelerden se\u00e7ebilirsiniz. Numara 1, en soldaki yarat\u0131\u011f\u0131 temsil eder. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",Yi:"Zindan\u0131n zorlu\u011funu yukar\u0131dakilerden se\u00e7in. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",ij:"\u0130yile\u015ftirme Ayarlar\u0131",Zi:"Ittifak Piyasas\u0131ndan al\u0131\u015fveri\u015f yaparak fazla alt\u0131n\u0131 depola -> Min. Alt\u0131n. 1. Envanterde bos yer birakmaya calisin.",
Cl:"T\u00fcm\u00fcn\u00fc Ta\u015f\u0131",Dl:"Se\u00e7ilenleri Ta\u015f\u0131",kl:"Otomatik \u0130yile\u015ftirme",ll:"Otomatik \u0130yile\u015ftirme Y\u00fczdesi",em:"Yakut",Lg:"Genel Ayarlar",Mj:"Hepsini Sat",Nj:"Se\u00e7ilenleri Sat",ga:"Silahlar",da:"Kalkanlar",W:"G\u00f6\u011f\u00fcs Z\u0131rhlar\u0131",Z:"Kasklar",Y:"Eldivenler",ea:"Ayakkab\u0131lar",ca:"Y\u00fcz\u00fckler",V:"Kolyeler",Ci:"Kullan\u0131labilir",Bi:"G\u00fc\u00e7lendirmeler",dh:"Re\u00e7eteler",sg:"S\u00f6zle\u015fmeli Scrollar",
fh:"Takviyeler",Zg:"G\u00f6rev Filtre \u0130gnore",Yg:"Almak istemedi\u011finiz g\u00f6revleri filtrelemek i\u00e7in anahtar kelimeleri girin",X:"Anahtar Kelime Girin",K:"Ekle",gh:"Kald\u0131r",fe:"Temizle",Wg:"G\u00f6rev Filtre Kabul",Xg:"Almak istedi\u011finiz g\u00f6revleri se\u00e7mek i\u00e7in anahtar kelimeleri girin. Odule gore secmek isterseniz odulun icinde gecen bir kelimeyi girin.",Ea:"Zamanl\u0131 G\u00f6revleri Atla?",Wk:"G\u00f6revler",Sd:"Oto Kost\u00fcm",Di:"Kost\u00fcm Kullan?",Xd:"Ana Sava\u015f",
oe:"Dungeon Sava\u015f ve Etkinlik",Td:"Bot yaln\u0131zca ke\u015fif/zindan puanlar\u0131n\u0131z 0 ise Dis Pater Normal ve Medium giyecektir.",ef:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",Jd:"Boss Mevcut Oldu\u011funda Sald\u0131r?",sb:"5 ba\u015far\u0131s\u0131z sald\u0131r\u0131dan sonra Lig sald\u0131r\u0131s\u0131n\u0131 devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",hf:"Kutsal Ya\u011flar",Ag:"\u00dcr\u00fcn Ad\u0131",ba:"Min. Item Seviyesi",Ba:"Min. \u00dcr\u00fcn Kalitesi",Id:"Zamanlay\u0131c\u0131y\u0131 Uygula/S\u0131f\u0131rla",
lf:"\u00d6nek/Soneki Yok Say",Ki:"Evet",Hg:"Hay\u0131r",Za:"Ge\u00e7mi\u015fi Temizle",Hh:"Yok Sayma Listesi",Mb:"\u00d6nek",Zb:"Sonek",mh:"S\u00fcresi Dolan \u00dcr\u00fcnleri S\u0131f\u0131rla",Ih:"Kondisyonlar disinda rastgele erit",Jh:"Eritme Sekmesi",qb:"Ekstralar",Nd:"M\u00fczayede",ig:"Pazar",$b:"Zamanlar",hi:"Eritme",gi:"Alt\u0131n Yoksa Eritme",di:"\u00dcr\u00fcn Yoksa Eritme",Fa:"Tamir",Wh:"Ittifak Pazar\u0131 Alt\u0131n Tutma",Sh:"M\u00fczayede Alt\u0131n Tutma",ki:"E\u011fitim",Zh:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla",
ii:"Hammadde Depola",Qh:"M\u00fczayede Kontrol",ai:"Arama",v:"Etkinle\u015ftir",Cg:"Min. Alt\u0131n",Ub:"Saat Se\u00e7in",nb:"Ittifaga Alt\u0131n Ba\u011f\u0131\u015fla",je:"Her 5 dakikada bir ba\u011f\u0131\u015f yapacakt\u0131r. Zamanlay\u0131c\u0131lar sekmesinden aral\u0131\u011f\u0131 de\u011fi\u015ftirebilirsiniz",jf:"Ne kadar ba\u011f\u0131\u015f yap\u0131lmal\u0131?",ke:"Ne zaman ba\u011f\u0131\u015f yap\u0131lmal\u0131 >",wf:"Daha az <",jh:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla ve Di\u011fer Ayarlar\u0131",
lh:"S\u0131f\u0131rla in:",Qk:"Birden fazla \u00f6\u011feyi se\u00e7mek i\u00e7in Ctrl (Mac'de Cmd) tu\u015funu bas\u0131l\u0131 tutun",mf:"Ayarlar\u0131 Kaydet / Yukle",Ue:"Ayarlar\u0131 Indir",nf:"Ayarlar\u0131 Yukle",tg:"T\u00fcm Oyunculara Mesaj G\u00f6nder",ug:"[Ultra Premium Anahtar\u0131 gerektirir, anahtar i\u00e7in Discord \u00fczerinden ileti\u015fime ge\u00e7in.]",vg:"G\u00f6nderilecek mesaj\u0131 girin",he:"\u00d6zel scriptler i\u00e7in Discord \u00fczerinden bize ula\u015f\u0131n",xg:"G\u00f6nder",
yg:"Oyuncular\u0131 G\u00f6ster",wg:"T\u00fcm\u00fcn\u00fc Se\u00e7",zg:"T\u00fcm Se\u00e7imleri Kald\u0131r",vf:"Envanterinizin yeterli alan\u0131 oldu\u011fundan emin olun. Geri say\u0131m 2 dakikad\u0131r.",mg:"Yiyecek Sat",Gb:"Yiyeceklere Ge\u00e7"},Sh={we:"Trocar automaticamente para o monstro do evento?",cg:"Erro de mercado! Por favor, adicione os itens novamente e tente novamente.",Lb:"N\u00e3o h\u00e1 espa\u00e7o suficiente no invent\u00e1rio!",ck:"Derreter cores mais altas primeiro?",cc:"Atacar apenas a lista de jogadores?",
dc:"Quando esta op\u00e7\u00e3o \u00e9 ativada, o bot s\u00f3 atacar\u00e1 jogadores na lista de jogadores. Se esta op\u00e7\u00e3o n\u00e3o estiver ativada, o bot atacar\u00e1 jogadores aleat\u00f3rios.",Mk:"Suas configura\u00e7\u00f5es de expedi\u00e7\u00e3o est\u00e3o incorretas ou h\u00e1 dados de p\u00e1gina inesperados!",Nk:"Sua configura\u00e7\u00e3o de expedi\u00e7\u00e3o est\u00e1 incorreta! Voc\u00ea definiu um monstro desabilitado, o que est\u00e1 errado.",$k:"Redefinir apenas todos os itens do submundo com a cor selecionada?",
Ca:"Prioridade",Vb:"Definir Prioridade",Rg:"Pontos",Kh:"Stat",Si:"Coletar Ouro",Oj:"Vender itens do Submundo?",uj:"O bot procurar\u00e1 pelo ninho em cada a\u00e7\u00e3o, n\u00e3o apenas em expedi\u00e7\u00f5es.",sj:"Tipo de busca de ninho",qj:"N\u00e3o fazer nada",rj:"Busca r\u00e1pida",tj:"Busca detalhada",Ml:"A\u00e7\u00e3o p\u00f3s expedi\u00e7\u00e3o",zk:"Clique aqui se o reparo ficar travado",Ok:"Quando HP estiver baixo, use cura",Ng:"Reparo Parcial",af:"Reparo Completo",Mg:"Reparo Parcial ou Completo",
re:"Habilitar Limite",kj:"Limite",lj:"Se voc\u00ea deseja limitar o n\u00famero de vezes que quer atacar o inimigo, habilite esta op\u00e7\u00e3o e defina o limite. O bot continuar\u00e1 atacando o resto dos inimigos ap\u00f3s terminar de atacar o monstro selecionado.",me:"N\u00e3o entre no submundo com a fantasia do submundo",le:"Se voc\u00ea n\u00e3o quiser entrar no submundo enquanto estiver usando a fantasia do submundo, ative esta op\u00e7\u00e3o",yi:"Submundo",pi:"Melhorias do Submundo",si:"Usar os poderes dos deuses ap\u00f3s entrar no submundo?",
ti:"Selecione os deuses para usar seus poderes:",ui:"Usar Buff de Arma na arma?",vi:"Usar Buff de Armadura no seguinte equipamento:",Jk:"O tempo de espera \u00e9 de 30 minutos. Se voc\u00ea n\u00e3o estiver com um traje, o bot redefinir\u00e1 o tempo de espera para 0.",al:"Selecionar Cores",$a:"Forja de Vulcano",eb:"Escudo Terrestre de Feronia",fb:"Poder Fluido de Netuno",gb:"Liberdade A\u00e9rea de Aelous",hb:"N\u00e9voa Mortal de Plut\u00e3o",ib:"Sopro de Vida de Juno",jb:"Armadura de Escamas das Montanhas da Ira",
kb:"Olhos de \u00c1guia",lb:"Vestimenta de Inverno de Saturno",ab:"Armadura de Touro de Bubona",bb:"Trajes de Ladr\u00e3o de Merc\u00fario",cb:"T\u00fanica de Luz de R\u00e1",lg:"Pacotes",gg:"Invent\u00e1rio",M:"Pre\u00e7o M\u00edn.",L:"Quantos",Fb:"Vender Itens",Eb:"Procurar em",hg:"Cor do Material",Db:"Cor do Item",og:"Armaz\u00e9m",Aa:"Mudar para Materiais",Hb:"Mudar para Itens",ng:"Vender Materiais",xa:"Por favor, insira um nome de item v\u00e1lido, faixa de pre\u00e7o e quantidade.",ya:"Nenhum item adequado encontrado nos locais de busca selecionados.",
za:"Todos os itens foram listados com sucesso!",Uk:"Todos os materiais foram listados com sucesso!",jg:"Se voc\u00ea quiser vender itens por um pre\u00e7o fixo, voc\u00ea pode inserir o mesmo valor para o pre\u00e7o m\u00ednimo e m\u00e1ximo.",kg:"Este recurso ainda \u00e9 experimental, use com cautela. Se voc\u00ea n\u00e3o colocar um pre\u00e7o fixo, os itens ser\u00e3o listados aleatoriamente entre o pre\u00e7o m\u00ednimo e m\u00e1ximo que voc\u00ea inserir.",Fk:"Define o m\u00e1ximo de ouro que o bot gastar\u00e1 por ciclo.",
Va:"O bot come\u00e7ar\u00e1 a fazer lances em itens de comida, se habilitado. Voc\u00ea n\u00e3o precisa habilitar os interruptores de gladiador/mercen\u00e1rio.",Ld:"O bot n\u00e3o far\u00e1 lances sobre os lances dos aliados.",Md:"Ignorar combina\u00e7\u00e3o de Prefixo/Sufixo ao procurar por um item no leil\u00e3o.",Vj:"Selecione os tipos de item que voc\u00ea deseja fundir.",Wj:"Selecione as cores que voc\u00ea deseja fundir.",Xj:"Selecione o n\u00edvel dos itens que voc\u00ea deseja fundir.",
Yj:"Selecione o martelo que voc\u00ea deseja usar.",Zj:"Note que o c\u00edrculo Verde e Vermelho ao lado da primeira caixa s\u00e3o para ativar/desativar a regra.",$j:"Se voc\u00ea quiser fundir aleatoriamente quaisquer cores ou tipos, voc\u00ea pode ativar `Fundir aleatoriamente se nenhuma condi\u00e7\u00e3o for atendida? (\u00daltima op\u00e7\u00e3o habilitada no v\u00eddeo tutorial)",Kj:"Reparar antes de fundir?",Oe:"Selecionar Monstro",Ce:"Usar Ampulheta/Rubi?",Lk:"Usar Rubi?",Fe:"Usar Mobiliza\u00e7\u00e3o?",
Ee:"Usar Po\u00e7\u00e3o de Vida?",Be:"Percentual de Cura (%)",Me:"N\u00famero de Ataques",De:"Intervalo de Ataque (em segundos)",ze:"Ataques Realizados",Ae:"Ampulhetas Restantes",Ke:"Nota: Usa po\u00e7\u00f5es de vida para curar, n\u00e3o comida.",Le:"Nota: Se os ataques pararem prematuramente, tente 'Resetar Ataques'.",Pe:"Iniciar",Ne:"Resetar",Qe:"Parar",Re:"Configura\u00e7\u00f5es de Expedi\u00e7\u00e3o (Clique para minimizar)",Ge:"Monstro 1",He:"Monstro 2",Ie:"Monstro 3",Je:"Monstro 4",Xk:"Reparar antes de fundir?",
Qi:"Esta op\u00e7\u00e3o usar\u00e1 cervisia quando seu premium expirar.",xj:"Esta op\u00e7\u00e3o ativa e seleciona \u00f3leos das recompensas divinas. Pode usar \u00f3leos n\u00famero 1 e 3 no personagem, mas o n\u00famero 2 s\u00f3 ser\u00e1 pego para pacotes.",Oi:"Esta op\u00e7\u00e3o usar\u00e1 buffs no hor\u00e1rio que voc\u00ea definir. Encontrar\u00e1 buffs nos pacotes e os aplicar\u00e1 ao personagem.",mj:"Esta op\u00e7\u00e3o te levar\u00e1 ao submundo. N\u00e3o esque\u00e7a de habilitar o Login Autom\u00e1tico na aba Extras, caso contr\u00e1rio, voc\u00ea pode ser desconectado ao entrar no submundo [Bug do Jogo]",
ec:"Esta opci\u00f3n solo atacar\u00e1 la lista de arena/circo. Si no puede, el bot la omitir\u00e1.",Hj:"Esta op\u00e7\u00e3o \u00e9 apenas para licen\u00e7as premium. Simula o ataque antes de atacar um usu\u00e1rio para uma taxa de vit\u00f3ria de 75%.",Od:"Voc\u00ea n\u00e3o precisa habilitar a togglede leil\u00e3o principal para habilitar esta op\u00e7\u00e3o.",sk:"Esta op\u00e7\u00e3o atualizar\u00e1 a p\u00e1gina a cada segundo quando o leil\u00e3o estiver no estado -Muito Curto- para dar lances constantemente e vencer o leil\u00e3o.",
Tj:"Se nenhuma das condi\u00e7\u00f5es de fus\u00e3o for atendida, ele fundir\u00e1 aleatoriamente. Certifique-se de selecionar o tipo e a cor do item.",Uj:"Esta op\u00e7\u00e3o fundir\u00e1 apenas itens do invent\u00e1rio. Ignorar\u00e1 itens nos pacotes.",Wa:"Itens de Leil\u00e3o",rg:"Itens de Mercen\u00e1rio",Xb:"Itens da Loja",Ai:"Itens \u00danicos",Pj:"Definir fundo para preto [Aumenta o desempenho]",Qj:"Mover bot\u00f5es do GLDbot para o canto inferior esquerdo?",Ri:"Atacar o Circo Sem Curar",
rk:"Pegar ouro dos pacotes se necess\u00e1rio?",bm:"Ouro foi pego dos pacotes para treinamento",Fd:"Nenhum ouro foi encontrado nos pacotes para treinamento",lk:"Itens Reparados",ek:"Ataques na Arena",gk:"Ataques no Circo",mk:"Itens Reiniciados",jk:"Ataques em Expedi\u00e7\u00f5es",ik:"Ataques em Masmorras",pk:"Ataques no Submundo",fk:"Dinheiro Ganhado na Arena",hk:"Dinheiro Ganhado no Circo",nk:"Itens Fundidos",kk:"Ouro Reciclado",dj:"Batalha de Guilda",fj:"Configura\u00e7\u00f5es da Guilda",tl:"Atacar\u00e1 guildas aleatoriamente.",
ej:"Nome da Guilda",Pi:"Redefinir Estat\u00edsticas",cj:"Atacar Guildas Aleatoriamente",El:'GLDbot: Use os dados para atualizar a caixa misteriosa e encontrar itens valiosos antes de abri-los (Etc. Trajes). Clique em "Iniciar" para abrir ba\u00fas.',Pc:"Madeira",Fc:"Cobre",Jc:"Ferro",Lc:"Couro",Qc:"Fio de L\u00e3",Gc:"Bolas de Algod\u00e3o",Ic:"Hemp",Hc:"Tiras de Gaze",Mc:"Fios de Linho",Kc:"Remendo",Oc:"Veludo",Nc:"Fio de Seda",Yc:"Pelo",Sc:"Lasca de Osso",ad:"Escama",Vc:"Garra",Xc:"Presas",Wc:"Escama de Drag\u00e3o",
Tc:"Corno de Touro",$c:"Gl\u00e2ndula Venenosa",Uc:"Casaco de Pele de Cerberus",Zc:"Escama de Hydra",bd:"Pena de Esfinge",cd:"Pele de Typhon",Cc:"Lapis Lazuli",wc:"Ametista",vc:"Ambar",xc:"Agua-Marinha",Dc:"Safira",Ac:"Granada",zc:"Esmeralda",yc:"Diamante",Bc:"Jasper",Ec:"Sugilite",qc:"Veneno de Escorpi\u00e3o",tc:"Tintura de Resist\u00eancia",mc:"Antidoto",lc:"Adrenalina",sc:"Tintura Esclarecedora",pc:"Po\u00e7\u00e3o de Perce\u00e7\u00e3o",nc:"Ess\u00eancia de Rea\u00e7\u00e3o",oc:"Frasco de Carisma",
uc:"\u00c0guas de Oblivion",rc:"Ess\u00eancia de Alma",Bd:"Selo Aqu\u00e1tico",vd:"Runa Protetora",td:"Marca da Terra",Ad:"Totem de Cura",zd:"Talism\u00e3 do Poder",xd:"Pedra da Fortuna",ud:"Pedernal",yd:"Runa da Tempestade",wd:"Runa das Sombras",gd:"Cristal",fd:"Bronze",ld:"Obsidiana",od:"Prata",pd:"Enxofre",jd:"Mina de Ouro",nd:"Quartzo",md:"Platina",ed:"Almandin",hd:"Cuprit",kd:"Pedra do Inferno",Li:"Atacar Aleatoriamente em Provinciarum?",Mi:'Tamb\u00e9m desative a configura\u00e7\u00e3o "Classificar jogadores na arena por n\u00edvel" no crazy-addon.',
$g:"Aceitar apenas miss\u00f5es com base no tipo de deus.",Xa:"Auto Buff",be:"Usar apenas no inferno?",Gg:"Nova Regra",Eg:"Nome Cont\u00e9m",isUnderworldItem:"\u00c9 Item do Submundo",kf:"Ignorar Materiais",yk:"Usar Ora\u00e7\u00e3o?",Gi:"Usar Sacrif\u00edcio?",uk:"Usar Roupas para Entrar no Submundo?",xi:"Miss\u00f5es do Submundo",wi:"Se habilitado, voc\u00ea precisa digitar nomes de itens do submundo. Se o bot encontrar esses itens no submundo, ele aceitar\u00e1 a miss\u00e3o.",el:"Item da Miss\u00e3o do Submundo",
ql:"Digite o nome do material",Ik:"O bot adora dados! Eles ajudam a encontrar roupas nos ba\u00fas. Mas se n\u00e3o houver dados, o bot abre os ba\u00fas mesmo assim, na esperan\u00e7a de encontrar roupas legais (mas pode n\u00e3o encontrar nenhuma!)",Sj:"Enviar para os pacotes",qe:"Ativar Arena?",Sg:"Priorizar lista de arena?",Tg:"Priorizar lista de circo?",ie:"Desativar Menu de Log",oh:"Recompensa Min. Valor em Ouro",ah:"Miss\u00e3o Focada, se ativada, seguir\u00e1 o caminho mais curto para terminar a masmorra.",
Nh:"Jogar Dados Automaticamente?",Oh:"Use jogar dados com cautela, ele continuar\u00e1 usando o primeiro dado at\u00e9 voc\u00ea desativar a op\u00e7\u00e3o.",uh:"Progresso da Pesquisa",ih:"O tempo de espera para reparo por padr\u00e3o \u00e9 de 10 minutos.",Bg:"Condi\u00e7\u00e3o M\u00ednima",ge:"Item atual na bancada [Limpar se o bot pausar inesperadamente]",Gf:"Recursos da Forja armazenados com sucesso no horreum.",Cf:"Verificando itens no mercado...",Ab:"Item movido para a bancada.",Tf:"Item reparado e equipado com sucesso.",
Uf:"Item reparado com sucesso.",Sk:"Reparo falhou. A p\u00e1gina ser\u00e1 atualizada.",Qf:"Pegando materiais...",bg:"Aguardando reparo...",Sf:"Reparo iniciado para .",wa:"Reparo: Movendo o item do invent\u00e1rio para a bolsa",Rf:"Reparo: Movendo o item da bancada para o pacote.",ua:"N\u00e3o foi poss\u00edvel encontrar materiais suficientes. Desativando o slot de reparo ",Nf:"Procurando itens para comprar para esconder ouro no Leil\u00e3o...",zf:"Verificando itens expirados nos pacotes...",Af:"Item redefinido com sucesso.",
Bf:"Sem Espa\u00e7o Vazio ou Ouro para Redefinir.",Hf:"Certifique-se de que voc\u00ea tem direitos de venda no mercado da guilda!",ub:"Ouro insuficiente e/ou nenhum item para comprar. Aguardando 30s para atualizar.",wb:"Loja foi atualizada.",xb:"Erro durante a cura.",Kf:"Sem Rubi ou Pano, desativando as op\u00e7\u00f5es.",Rk:"Nenhum item de cura encontrado nos pacotes.",yb:"Nenhum item adequado encontrado",Lf:"Alimentos foram pegos. Finalizando o processo.",Mf:"Pelo menos um alimento foi pego. Finalizando processo.",
zb:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",If:"Pegando comida dos pacotes.",Jf:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",vb:"Sem mais itens de cura. Aguardando 30 segundos.",tb:"HP Recuperado.",va:"Nada para fazer ent\u00e3o vou rezar!",Yf:"Vou atualizar em 60 segundos para verificar minha sa\u00fade e villa medici.",Zf:"Aguardando Villa Medici, atualizando em 60 segundos.",$f:"Saiu do submundo.",ag:"Vou atualizar em 60 segundos para verificar minha sa\u00fade.",
Of:"Verificando \u00f3leos de deus...",Pf:"\u00d3leos de deus foram pegos.",sa:"Atacou com sucesso o jogador na ARENA: ",ta:"Atacou com sucesso o jogador no CIRCO: ",xf:"Verificando leil\u00e3o! Por favor, aguarde...",yf:"Dando lances em itens. Por favor, aguarde...",Vf:"Item Derretido Automaticamente: ",Wf:"Derretendo Item: ",Bb:"Ouro insuficiente para derreter. Ouro Necess\u00e1rio: ",Xf:"DERRETER: Procurando itens para derreter...",Tk:"Procurando itens para derreter...",Df:"Verificando disponibilidade de traje...",
Ff:"Doado : ",Ef:"Jogando dados...",Xe:"Underworld Farm [Manual, Beta]",Ye:"Esteja ciente: ative este recurso ap\u00f3s desbloquear a criatura que deseja atacar, ela n\u00e3o atacar\u00e1 automaticamente para desbloquear o monstro.",We:"Farm Location",Ve:"Farm Enemy",Vd:"Login Autom\u00e1tico",Wd:"Voc\u00ea precisa permitir pop-ups da tela do lobby do GameForge. Veja a documenta\u00e7\u00e3o sobre como fazer isso.",Og:"Pausar Bot",Pg:"Pausar Bot em (Minutos)",Te:"Data de Expira\u00e7\u00e3o",Jg:"Comprar apenas comida?",
Kg:"Se voc\u00ea habilitar isso, o bot ignorar\u00e1 suas sele\u00e7\u00f5es e comprar\u00e1 comida automaticamente sem inserir nada.",Jb:"M\u00e1ximo de ouro total para gastar",Ib:"M\u00e1ximo de ouro por comida para gastar",Ig:"O bot verificar\u00e1 \u00f3leos a cada 60 minutos",fi:"Define um temporizador para verificar os tempos de fus\u00e3o.",ci:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver ouro.",ei:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver o item dispon\u00edvel.",
Yh:"Define um temporizador para reparar e verificar seus itens.",Xh:"Define um temporizador para verificar o ouro mantido no mercado da guilda.",Th:"Define um temporizador para a op\u00e7\u00e3o de reten\u00e7\u00e3o de ouro em leil\u00e3o.",Ph:"Define um temporizador para verificar a lista de PvP na arena para atacar.",Uh:"Define um temporizador para verificar a lista de PvP no circo para atacar.",li:"Define um temporizador para treinar suas estat\u00edsticas.",$h:"Define um temporizador para redefinir itens expirados.",
ji:"Define um temporizador para armazenar materiais de forja no horreum.",Rh:"Define um temporizador para verificar o leil\u00e3o de gladiadores e mercen\u00e1rios.",bi:"Define um temporizador para buscar itens em leil\u00e3o e loja.",Vh:"Define o temporizador para enviar doa\u00e7\u00f5es \u00e0 guilda.",bf:"Ouro Movido",ne:"N\u00e3o venda itens da lista de fundi\u00e7\u00e3o e leil\u00e3oo",vh:"Automa\u00e7\u00e3o da Loja",xh:"Configura\u00e7\u00f5es de Busca de Item",wh:"Use esta ferramenta para buscar itens. Basta adicionar os itens \u00e0 lista, especificar a quantidade de pano e iniciar a busca.",
yh:"Panos a Usar:",zh:"Quantos panos usar?",fa:"Full Digite o Nome do Item",Wb:"Digite o N\u00edvel do Item",Bh:"Qualidade do Item",Ah:"Nome do Item Aqui",Ch:"Iniciar Busca",Dh:"Pular e Continuar",Eh:"Parar Busca",Ze:"Comprar o mais barato ou o mais caro?",Dg:"Mais Caro",de:"Mais Barato",Da:"Selecionar uma op\u00e7\u00e3o",se:"Destacar itens do submundo",$e:"Foco na miss\u00e3o?",dm:"Usar Ruby se n\u00e3o houver pano?",Ya:"Evite atacar as mesmas pessoas para n\u00e3o ser reportado. Ser reportado aumenta as chances de ser banido.",
Tl:"Queimar verde?",Vg:"N\u00e3o aceitar miss\u00f5es aleat\u00f3rias se algum filtro for inserido?",Rc:"Qualidade m\u00e1xima do material a ser usado",$i:"Ativar a busca mercen\u00e1ria",Al:"Clique em `Vender Todos Selecionados` para vender todos os itens. Certifique-se de ter um espa\u00e7o vazio de 2x3 em sua primeira (1) bolsa. Para coletar ouro em massa, filtre ouro e use `Selecionar Todos ou Selecionar`",dk:"\ud83d\udd25 : Adiciona item \u00e0 lista de fundi\u00e7\u00e3o.",Ni:"\ud83d\udd28 : Adiciona item \u00e0 lista de leil\u00e3o.",
Jj:"Atualize a loja com pano quando estiver cheia",Il:"P\u00e1gina:",Fj:"Parar",Dj:"Vender Esta P\u00e1gina",Aj:"Pegar Selecionados",zj:"Pegar Tudo",Gj:"Configura\u00e7\u00f5es de Empacotamento Autom\u00e1tico",Ej:"Enviar Recursos",Bj:"Vender Todos Selecionados",na:"Tipo de Item",pa:"Armas",U:"Escudos",O:"Armaduras",S:"Capacetes",R:"Luvas",P:"Botas",oa:"An\u00e9is",la:"Amuletos",Ka:"Utiliz\u00e1veis (Alimentos)",Pa:"Melhorias",yj:"Potencializadores",Ma:"Receitas",La:"Mercen\u00e1rios",Oa:"Ferramentas de Forja",
Na:"Pergaminhos",sd:"Refor\u00e7os",qd:"Itens de Evento",rd:"Materiais de Forja",Hl:"Ouro",Ja:"Todos",Jl:"Qualidade",qa:"Branco",C:"Verde",B:"Azul",D:"Roxo",J:"Laranja",T:"Vermelho",Cj:"Op\u00e7\u00f5es de Venda",Rj:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo?",gj:"Quantos alimentos comprar/pegar?",Vi:"Normal",Ui:"Intermedi\u00e1rio",Ti:"Dif\u00edcil",Ga:"Padr\u00e3o",Nl:"Reparar Corre\u00e7\u00e3o de Travamento",Pk:"Desative a entrada no Inferno se voc\u00ea quiser desabilitar a Dungeon/Circo/Arena. Se voc\u00ea entrar no Inferno manualmente, ser\u00e1 necess\u00e1rio ativar o Modo Inferno.",
ee:"Escolher traje do submundo",Ji:"Vestir traje do submundo quando dispon\u00edvel?",oi:"Define quantas vezes quer treinar as estat\u00edsticas e suas prioridades. O bot n\u00e3o treinar\u00e1 a menos que defina uma prioridade. Se n\u00e3o houver mais estat\u00edsticas ele continuar\u00e1 com as estat\u00edsticas Defenidas.",nl:"Aventura",Dd:"Derreter",Yl:"Defini\u00e7\u00f5es de Derreter",ak:"Itens Derretidos",Zl:"Adicione um Prefixo ou Sufixo, uma vez encontrado nos pacotes Ser\u00e1 Derretido automaticamente.:",
Xl:"Derreter Item:",ic:"Clique no item que voc\u00ea deseja consertar. Isto utilizar\u00e1 apenas materiais Padr\u00e3o, Verde e Azul. Voc\u00ea precisa ter pelo menos 10.000 ouro para iniciar o reparo. Abra espa\u00e7o 3x3 em sua PRIMEIRA Bolsa do invent\u00e1rio. Caso contr\u00e1rio, ele poder\u00e1 ficar preso! O bot iniciar\u00e1 o reparo assim que o item tiver durabilidade de %0.",gl:"Aplicar apenas no Mercenario.",jl:"O leil\u00e3o s\u00f3 dar\u00e1  o lance quando o mercado estiver no Fim..",
il:"Certifique-se de que a SEGUNDA PAGINA DO INVENT\u00c1RIO est\u00e1 vazia e tem 10K de ouro. O bot encontrar\u00e1 e colocar\u00e1 o item na segunda pagina e na pr\u00f3xima vez, a p\u00e1gina, atualiza-se Derrentendo o item. A fundi\u00e7\u00e3o acontecer\u00e1 novamente a cada 5-10 minutos. ",jj:"Cura & Buffs",Ol:"Sem ouro suficiente para fundir. Ouro necess\u00e1rio!:",Rl:"Skipping bid: Membro da galian\u00e7a j\u00e1 deu lance no item ",Ql:"Skipping bid: J\u00e1 licitei o item ",advanced:"Avan\u00e7ado",
arena:"Arena",ja:"Ataque autom\u00e1tico",fc:"Evitar Atacar",ha:"Adicionar Jogador",ia:"Adicionar Nome do Jogador (Same Server)",vl:"Parar o Bot se ficar sem comida?",circusTurma:"Circus Turma",Wi:"Dificuldade",dungeon:"Masmorra",Xi:"Configura\u00e7\u00e1o da Masmorra",eventExpedition:"Expedi\u00e7\u00e3o de evento",expedition:"Expedi\u00e7\u00f5es",aj:"Configura\u00e7\u00e1o de Expedi\u00e7\u00f5es",Lj:"Selecionar Monstro",xl:"Maior",wl:"Coloque as curas na primeira p\u00e1gina do invent\u00e1rio",
nj:"No",Lh:"Guardar Ouro",Mh:"Guardar ouro no Leil\u00e3o?",Ub:"Selecionar Horas",rh:"Utilizar Roupas para Renovar Iventario?",Zk:"Selecione itens para serem redefinidos",kh:"Redefinir itens expirados\t",Qb:"Nota: Ao ativar esta op\u00e7\u00e3o, o bot vender\u00e1 os  itens expirados nos Pacotes para o Mercado da Guilda e cancelar\u00e1 para redefinir o tempo de expira\u00e7\u00e3o. Guilda \u00e9 necess\u00e1ria. Certifique-se que tem espa\u00e7o 3x3 vazio no iventario. Nota: Tamb\u00e9m ir\u00e1 coletar as Moedas de Ouro se elas estiverem prestes a expirar!!!",
Qg:"Parar o Bot Aleatoriamente para trabalhar como [Fase de Teste]:",aa:"Ficar com o Ouro: Bot vai segurar esse ouro na bolsa:",pg:"maximo de Ouro: O bot gastar\u00e1 o ouro quando for Superior a",ph:"Ofertas ser\u00e3o aceitas por itens desnecess\u00e1rios",Gd:"Adicionar atraso aleat\u00f3rio",Hd:"Podes adicionar um atraso para o bot aqui.",Pb:"Reparar",Sl:"Derreter apenas Azul?",Vl:"Derreter apenas Roxo?",Ul:"Derreter apenas Laranja?",bk:"Derreter apenas do ivent\u00e1rio?",Wl:"Isto ir\u00e1 ignorar a cor e os itens da lista. A pagina 1 est\u00e1 reservada a repara\u00e7\u00e3o..",
Gh:"Derreter",Pd:"Pesquisa autom\u00e1tica",Fg:"Leil\u00e3o Autom\u00e1tico",Qd:"O uso excessivo do Leil\u00e3o pode resultar em banimento. Esse recurso tamb\u00e9m pode desacelerar o bot, pois ele verifica os leil\u00f5es a cada atualiza\u00e7\u00e3o. As licita\u00e7\u00f5es s\u00e3o feitas a cada 5 minutos, a menos que o leil\u00e3o esteja no estado \u201cmuito curto\u201d. Observe que, se voc\u00ea colocar apenas um item na se\u00e7\u00e3o PREFIX, o bot tentar\u00e1 filtrar pelo nome dos itens para licitar mais rapidamente. Embora voc\u00ea precise desativar a licita\u00e7\u00e3o de alimentos para isso.",
qh:"Pesquisar no leil\u00e3o dos gladiadores",th:"Pesquisar no leil\u00e3o dos mercen\u00e1rios",Yd:"Licitar Comida?",qg:"Lance m\u00e1ximo",Zd:"Licitar se o Tempo for inferior a",$d:"Itens licitados",Dk:"Linguagem do Leil\u00e3o",Ek:"De acordo com a atualiza\u00e7\u00e3o 2.5.6, defina o idioma novamente.",Kd:"Poder\u00e1 adicionar itens para procurar no mercado e no leil\u00e3o. Tamb\u00e9m mostrar\u00e1 itens roxos no mercado assim que voc\u00ea adicionar um item \u00e0 lista.",Bk:"Utilize o leil\u00e3o com cuidado!",
Ck:"O lance autom\u00e1tico faz muitas solicita\u00e7\u00f5es ao servidor, causando erro de p\u00e1gina em branco e pode causar banimento se for utilizado com frequ\u00eancia!!",hh:"Renovar pontos de evento com Rubis?",ue:"Ativar \u00f3leo autom\u00e1tico",Gk:"Obter os \u00f3leos sagrados automaticamente",Vk:"Velocidade de verifica\u00e7\u00e3o das miss\u00f5es",Ua:"Atacar membros da alian\u00e7a?",Sa:'Adicionar Jogador automaticamente \u00e0 lista de "Ataque" quando X OURO for roubado:',Ta:'Adicione Jogadores automaticamente \u00e0 lista "Evitar Ataque" quando perder:',
Tb:"Placar De Ataques",ac:"Muito Longo",Cb:"Longo",Kb:"M\u00e9dio",Yb:"Curto",bc:"Bastante Curto",pb:"Aceitar Ataques ao Placar:",Rb:"Selecionar Posi\u00e7\u00e3o do ataque",Sb:"O bot ira atacar aleatoriamente jogadores no placar.",rb:"Ataque da Liga",ob:"Ativar ataque da liga:",Nb:"Ataque aleat\u00f3rio",Ob:"Atacar do Menor para o maior",Ak:"Bot N\u00e3o atacara menbros da alian\u00e7a.",Se:"Local da Expedi\u00e7\u00e3o:",Rd:"Coletar Bonus automaticamente:",Fh:"Ignorar Chefe",pe:"Local da Masmorra:",
nh:"Recome\u00e7ar se perder?",ff:"Defeni\u00e7\u00f5es do Inferno",gf:" A Personagem entrar\u00e1 no submundo apenas quando o HP for> 90%. Por favor, defina as configura\u00e7\u00f5es de porcentagem de cura na Aba de cura e certifique-se de que a Aba de cura est\u00e1 ativada. Se ao entrar no submundo fizer logout, v\u00e1 para o lobby e ative a caixa de sele\u00e7\u00e3o de login autom\u00e1tico.",df:"Dificuldade Do inferno:",Ud:"Entrar automaticamente no inferno / Inferno Mode",Ei:"Utilizar Mobiliza\u00e7\u00e3o se pontos = 0",
Ii:"Usar Rubies?",ye:"Deixar Inferno se nao tiver pontos?",ri:"O bot tentar\u00e1 usar a Villa Medici primeiro, se voc\u00ea n\u00e3o tiver, ele usar\u00e1 a po\u00e7\u00e3o de cura. N\u00e3o se esque\u00e7a de ativar o bot\u00e3o de Cura!.",zi:"Entrar automaticamente no Inferno ira desabilitar masmorras/arena/Circus.",dl:"Defeni\u00e7oes de cura no Inferno",Hi:"Usar Villa Medici?",Fi:"Usar Po\u00e7\u00e3o de Vida?",dg:"INFO: O bot ir\u00e1 procurar itens no mercado a cada minuto selecionado, o que pode parar o ataque durante a busca.",
te:"Ativar pesquisa de mercado:",eg:"Intervalo de pesquisa no mercado:",fg:"Sugest\u00e3o 10 minutos.",rf:"Defini\u00e7\u00f5es de itens:",pf:"Nome do item inclui",G:"Pre\u00e7o Maximo",sf:"Estilo do Item",qf:"Raridade do Item",ce:"Comprar Soulbound?",uf:"Itens para comprar",tf:"Tentar comprar itens com pacotes se algum deles corresponde ao pre\u00e7o m\u00e1ximo Defenido.:",ae:"Itens Comprados:",hj:"Percentagem de Cura",wk:"Comprar comida da Loja?",xk:"Usar cura dos pacotes?",tk:"Usar Cervisia?",
vk:"Usar Ovos?",Bl:"Usado por \u00faltimo",location:"Localiza\u00e7\u00e3o",Strength:"For\u00e7a",Dexterity:"Destreza",Agility:"Agilidade",Constitution:"Constitui\u00e7\u00e3o",Charisma:"Carisma",Intelligence:"Inteligencia",mi:"Defini\u00e7\u00f5es de Treino",ni:"Selecione os atributos que deseja treinar. ir\u00e1 treinar assim que houver ouro suficiente.",N:"Proxima A\u00e7\u00e3o",vj:"N\u00e3o",wj:"Normal",Fl:"Oponente",Gl:"Nivel do Oponente",Ij:"Miss\u00f5es",random:"aleat\u00f3rio",Pl:"Defini\u00e7\u00f5es",
$l:"Brevemente...",type:"Clique nos \u00edcones para ativar os tipos de miss\u00f5es. Selecione os 3 primeiros se quiser se concentrar em Circus & Arena",fm:"Sim",A:"Procura",Cd:"Adicionar item [NOME COMPLETO]",qk:"Guardar recursos da Forja automaticamente",am:"Enviar",zl:"Intervalo : ",ol:"Ativar lance autom\u00e1tico",pl:"Cobrir aliados",cm:"Tutorial",hc:"MMais jogadores ir\u00e3o por o bot mais lento.",hl:"Comece adicionando o nome completo dos itens \u00e0 lista. Uma vez adicionado, a ferramenta exibir\u00e1 os resultados da pesquisa \u00e0 esquerda. Isso tamb\u00e9m auxilia nas pesquisas de leil\u00e3o autom\u00e1tico. Com o lance autom\u00e1tico ativado, a ferramenta far\u00e1 pesquisas peri\u00f3dicas com base no intervalo definido. Se o item for encontrado e voc\u00ea tiver fundos suficientes, ele far\u00e1 um lance automaticamente. Nota: Para pesquisar itens exclusivos em lojas, voc\u00ea deve adicionar pelo menos um item \u00e0 lista de pesquisa...",
rl:"O n\u00famero da criatura pode ser escolhido nos bot\u00f5es acima. O n\u00famero 1 representa a criatura \u00e0 esquerda. Certifique-se de selecionar o local correto, caso contr\u00e1rio o bot poder\u00e1 fazer uma pausa.",Yi:"Escolha a dificuldade da masmorra nas op\u00e7\u00f5es acima. Certifique-se de selecionar o local correto, caso contr\u00e1rio, o bot poder\u00e1 fazer uma pausa.",ij:"Defini\u00e7\u00f5es de cura",Zi:"Armazene o excesso de ouro na Guilda comprando itens do mercado da Guilda. -> Min. Gold",
Cl:"Mover tudo",Dl:"Mover o Selecionado",kl:"Curar autom\u00e1ticamente",ll:"Percentagem da cura",em:"Rubi",Lg:"Defini\u00e7\u00f5es Gerais",Mj:"Vender tudo",Nj:"Vender Selecionados",ga:"Armas",da:"Escudos",W:"Armaduras",Z:"Capacetes",Y:"Luvas",ea:"Sapatos",ca:"Aneis",V:"Amuletos",Ci:"Usaveis",Bi:"Atualiza\u00e7\u00f5es",dh:"Receitas",sg:"Mercen\u00e1rios",fh:"Refor\u00e7os",ve:"Entrar no Submundo se HP >",bh:"Velocidade de Verifica\u00e7\u00e3o de Miss\u00e3o",Ug:'O padr\u00e3o \u00e9 "3x". Se o bot causar problemas com miss\u00f5es, altere a velocidade da miss\u00e3o de acordo com a velocidade do seu servidor.',
cf:"Aba de Cura",xe:'Se voc\u00ea est\u00e1 renovando pontos manualmente, voc\u00ea precisa clicar no bot\u00e3o acima "Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!',Kk:"Voc\u00ea deve ativar pelo menos uma das seguintes op\u00e7\u00f5es: expedi\u00e7\u00e3o, masmorra, arena ou circo para iniciar a Expedi\u00e7\u00e3o de Evento.",eh:"Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!",mb:"Não Cobrir Aliados?",bl:"Deixe todas as configura\u00e7\u00f5es desativadas se desejar fundir usando pacotes que cont\u00eam os itens da lista. No entanto, voc\u00ea ainda pode escolher cores.",
Hk:"Personagem(Desligado) / Mercen\u00e1rio(Ligado)",Yk:"Reparar Ambos?",cl:"Cron\u00f4metros",Timers:"Insira o n\u00famero de minutos para cada cron\u00f4metro abaixo ou deixe-o padr\u00e3o.",Zg:"Ignorar Filtro de Miss\u00e3o",Yg:"Digite palavras-chave para filtrar miss\u00f5es que voc\u00ea n\u00e3o deseja aceitar",X:"Inserir Palavra-chave",K:"Adicionar",gh:"Remover",fe:"Limpar",Wg:"Aceitar Filtro de Miss\u00e3o",Xg:"Digite palavras-chave para escolher quais miss\u00f5es aceitar. Usar isso ignorar\u00e1 os tipos de miss\u00e3o",
Ea:"Pular Miss\u00f5es de Tempo?",Wk:"Miss\u00f5es",Sd:"Auto Traje",Di:"Usar Traje?",Xd:"Batalha B\u00e1sica",oe:"Batalha em Masmorra",Td:"O bot s\u00f3 usar\u00e1 Dis Pater Normal e M\u00e9dio se seus pontos de expedi\u00e7\u00e3o/masmorra forem 0.",ef:"Configura\u00e7\u00f5es de Cura no Inferno",Jd:"Atacar Chefe Quando Dispon\u00edvel?",sb:"O ataque \u00e0 Liga ser\u00e1 desativado ap\u00f3s 5 ataques malsucedidos.",hf:"\u00d3leos Sagrados",Ag:"Nome do Item",ba:"N\u00edvel M\u00edn. do Item",Ba:"Qualidade M\u00edn. do Item",
Id:"Aplicar/Reiniciar Temporizador",lf:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo",Ki:"Sim",Hg:"N\u00e3o",Qa:"Adicionar Prefixo",Ra:"Adicionar Sufixo",Za:"Limpar Hist\u00f3rico",Hh:"Lista de Ignora\u00e7\u00e3o de Fundi\u00e7\u00e3o",Mb:"Prefixo",Zb:"Sufixo",mh:"Redefinir Itens Expirados",Ih:"Fundir Aleatoriamente de Pacotes?",Jh:"Aba de Fundi\u00e7\u00e3o",qb:"Extras",Nd:"Leil\u00e3o",ig:"Mercado",$b:"Temporizadores",hi:"Fundi\u00e7\u00e3o",gi:"Fundi\u00e7\u00e3o se n\u00e3o houver ouro suficiente",
di:"Fundir se n\u00e3o houver item",Fa:"Reparo",Wh:"Manter Ouro no Mercado da Guilda",Sh:"Manter Ouro no Leil\u00e3o",ki:"Treinamento",Zh:"Redefinir Expirados",ii:"Loja de Forja",Qh:"Verifica\u00e7\u00e3o de Leil\u00e3o",ai:"Pesquisa",v:"Habilitar",Cg:"Ouro M\u00ednimo (pacote guilda)",nb:"Doar Ouro para a Guilda",je:"Isso doar\u00e1 a cada 5 minutos. Voc\u00ea pode alterar o intervalo na guia de temporizadores",jf:"Quanto deseja doar?",ke:"Doar quando tiver mais que >",wf:"Menos que <",jh:"Redefinir Expirados e Outras Configura\u00e7\u00f5es",
lh:"Redefinir em:",Qk:"Mantenha Ctrl (Cmd no Mac) pressionado para selecionar v\u00e1rios itens",mf:"Importar/Exportar Configura\u00e7\u00f5es",Ue:"Exportar Configura\u00e7\u00f5es",nf:"Importar Configura\u00e7\u00f5es",tg:"Mensagem para Todos os Jogadores",ug:"[Requer Chave Ultra Premium, mensagem no Discord para obter a chave.]",vg:"Digite a mensagem a ser enviada",he:"Para scripts personalizados, entre em contato conosco no Discord",xg:"Enviar",yg:"Mostrar Jogadores",wg:"Selecionar Todos",zg:"Desmarcar Todos",
vf:"Certifique-se de que seu invent\u00e1rio tenha espa\u00e7o suficiente. O tempo de recarga \u00e9 de 2 minutos.",mg:"Vender Comida",Gb:"Mudar para Comida"},Nh={we:"Automatycznie prze\u0142\u0105czaj potwory na wyprawie eventowej",cg:"B\u0142\u0105d rynkowy! Prosz\u0119 ponownie doda\u0107 elementy i spr\u00f3bowa\u0107.",Lb:"Brak wystarczaj\u0105cej ilo\u015bci miejsca w torbie na jedzenie.",ck:"Roztopi\u0107 najpierw wy\u017csze kolory?",cc:"Atakowa\u0107 tylko list\u0119 graczy?",dc:"Kiedy ta opcja jest w\u0142\u0105czona, bot b\u0119dzie atakowa\u0142 tylko graczy z listy graczy. Je\u015bli ta opcja nie jest w\u0142\u0105czona, bot b\u0119dzie atakowa\u0142 losowych graczy.",
Mk:"Twoje ustawienia ekspedycji s\u0105 nieprawid\u0142owe lub wyst\u0105pi\u0142y nieoczekiwane dane strony!",Nk:"Twoje ustawienie ekspedycji jest nieprawid\u0142owe! Ustawi\u0142e\u015b wy\u0142\u0105czonego potwora, co jest b\u0142\u0119dne.",$k:"Zresetowa\u0107 tylko wszystkie przedmioty z podziemi o wybranym kolorze?",Ca:"Priorytet",Vb:"Ustaw Priorytet",Rg:"Punkty",Kh:"Stat",Si:"Zbieranie Z\u0142ota",Oj:"Sprzedaj przedmioty z podziemia?",uj:"Bot b\u0119dzie szuka\u0142 gniazda w ka\u017cdej akcji, nie tylko na wyprawach.",
sj:"Typ wyszukiwania gniazda",qj:"Nic nie r\u00f3b",rj:"Szybkie wyszukiwanie",tj:"Dok\u0142adne wyszukiwanie",Ml:"After expedition points are consumed, travel to Germania to consume Dungeon points",zk:"Kliknij tutaj, je\u015bli naprawa si\u0119 zacina",Ok:"Gdy HP spadnie poni\u017cej, u\u017cyj leczenia",Ng:"Cz\u0119\u015bciowa Naprawa",af:"Pe\u0142na Naprawa",Mg:"Cz\u0119\u015bciowa lub Pe\u0142na Naprawa",re:"W\u0142\u0105cz Limit",kj:"Limit",lj:"Je\u015bli chcesz ograniczy\u0107 liczb\u0119 atak\u00f3w na przeciwnika, w\u0142\u0105cz t\u0119 opcj\u0119 i ustaw limit. Bot b\u0119dzie kontynuowa\u0142 atakowanie reszty przeciwnik\u00f3w po zako\u0144czeniu atak\u00f3w na wybranego potwora.",
me:"Nie wchod\u017a do podziemia w kostiumie podziemia",le:"Je\u015bli nie chcesz wchodzi\u0107 do podziemia, maj\u0105c na sobie kostium podziemia, w\u0142\u0105cz t\u0119 opcj\u0119",yi:"Podziemia",pi:"Wzmocnienia Podziemi",si:"U\u017cy\u0107 mocy bog\u00f3w po wej\u015bciu do podziemi?",ti:"Wybierz bog\u00f3w, kt\u00f3rych moce chcesz wykorzysta\u0107:",ui:"U\u017cy\u0107 Wzmocnienia Broni na broni?",vi:"U\u017cy\u0107 Wzmocnienia Zbroi na nast\u0119puj\u0105cym ekwipunku?",Jk:"Czas odnowienia wynosi 30 minut. Je\u015bli nie masz kostiumu, bot zresetuje czas odnowienia do 0.",
al:"Wybierz Kolory",$a:"Kowad\u0142o Wulkana",eb:"Ziemna Tarcza Feronii",fb:"P\u0142ynna Moc Neptuna",gb:"Powietrzna Wolno\u015b\u0107 Aelousa",hb:"Zab\u00f3jcza Mg\u0142a Plutona",ib:"Oddech \u017bycia Junony",jb:"Pancerz \u0141usek G\u00f3r Gniewu",kb:"Orle Oczy",lb:"Zimowy Str\u00f3j Saturna",ab:"Bycza Zbroja Bubony",bb:"Szaty Z\u0142odzieja Merceriusa",cb:"Szata \u015awiat\u0142a Ra",lg:"Paczki",gg:"Inwentarz",M:"Min. Cena",L:"Ile",Fb:"Sprzedaj Przedmioty",Eb:"Szukaj w",hg:"Kolor Materia\u0142u",
Db:"Kolor Przedmiotu",og:"Magazyn",Aa:"Prze\u0142\u0105cz na Materia\u0142y",Hb:"Prze\u0142\u0105cz na Przedmioty",ng:"Sprzedaj Materia\u0142y",xa:"Prosz\u0119 wprowadzi\u0107 poprawn\u0105 nazw\u0119 przedmiotu, zakres cen oraz ilo\u015b\u0107.",ya:"Nie znaleziono odpowiednich przedmiot\u00f3w w wybranych miejscach wyszukiwania.",za:"Wszystkie przedmioty zosta\u0142y pomy\u015blnie wystawione!",Uk:"Wszystkie materia\u0142y zosta\u0142y pomy\u015blnie wystawione!",jg:"Je\u015bli chcesz sprzeda\u0107 przedmioty za sta\u0142\u0105 cen\u0119, mo\u017cesz wpisa\u0107 t\u0119 sam\u0105 warto\u015b\u0107 dla minimalnej i maksymalnej ceny.",
kg:"Ta funkcja jest nadal eksperymentalna, u\u017cywaj ostro\u017cnie. Je\u015bli nie ustawisz sta\u0142ej ceny, przedmioty b\u0119d\u0105 wy\u015bwietlane losowo mi\u0119dzy minimaln\u0105 a maksymaln\u0105 cen\u0105, kt\u00f3r\u0105 wpiszesz.",Fk:"Ustawia maksymaln\u0105 ilo\u015b\u0107 z\u0142ota, kt\u00f3r\u0105 bot wyda w jednym cyklu.",Va:"Bot zacznie licytowa\u0107 wszelkie przedmioty \u017cywno\u015bciowe, je\u015bli opcja jest w\u0142\u0105czona. Nie musisz w\u0142\u0105cza\u0107 prze\u0142\u0105cznik\u00f3w gladiatora/najemnika.",
Ld:"Bot nie b\u0119dzie licytowa\u0142 ofert sojusznik\u00f3w.",Md:"Ignoruj kombinacj\u0119 Prefixu/Sufiksu podczas szukania przedmiotu na aukcji.",Vj:"Wybierz typy przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Wj:"Wybierz kolory, kt\u00f3re chcesz przetopi\u0107.",Xj:"Wybierz poziom przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Yj:"Wybierz m\u0142ot, kt\u00f3rego chcesz u\u017cy\u0107.",Zj:"Zwr\u00f3\u0107 uwag\u0119, \u017ce zielone i czerwone k\u00f3\u0142ko obok pierwszego pola s\u0142u\u017cy do w\u0142\u0105czania/wy\u0142\u0105czania regu\u0142y.",
$j:"Je\u015bli chcesz przetapia\u0107 losowo jakiekolwiek kolory lub typy, mo\u017cesz w\u0142\u0105czy\u0107 `Czy przetapia\u0107 losowo, je\u015bli \u017cadne warunki nie s\u0105 spe\u0142nione? (Ostatnia w\u0142\u0105czona opcja w filmie instrukta\u017cowym)",Kj:"Napraw przed przetopieniem",Oe:"Wybierz Potwora",Ce:"U\u017cy\u0107 Klepsydry/Rubinu?",Lk:"U\u017cy\u0107 Rubinu?",Fe:"U\u017cy\u0107 Mobilizacji?",Ee:"U\u017cy\u0107 Mikstury \u017bycia?",Be:"Procent Leczenia (%)",Me:"Liczba Atak\u00f3w",
De:"Interwa\u0142 Ataku (w sekundach)",ze:"Wykonane Ataki",Ae:"Pozosta\u0142e Klepsydry",Ke:"Uwaga: U\u017cywa mikstur \u017cycia do leczenia, nie jedzenia.",Le:"Uwaga: Je\u015bli ataki zatrzymaj\u0105 si\u0119 przedwcze\u015bnie, spr\u00f3buj 'Zresetuj Ataki'.",Pe:"Rozpocznij",Ne:"Resetuj",Qe:"Zatrzymaj",Re:"Ustawienia Ekspedycji (Kliknij, aby zminimalizowa\u0107)",Ge:"Potw\u00f3r 1",He:"Potw\u00f3r 2",Ie:"Potw\u00f3r 3",Je:"Potw\u00f3r 4",Xk:"Napraw przed przetopieniem",Qi:"Ta opcja u\u017cyje cervisia, gdy twoja subskrypcja premium wyga\u015bnie.",
xj:"Ta opcja w\u0142\u0105cza i wybiera oleje z nagr\u00f3d boskich. Mo\u017ce u\u017cywa\u0107 olej\u00f3w numer 1 i 3 na postaci, ale numer 2 b\u0119dzie tylko zbierany do paczek.",Oi:"Ta opcja u\u017cyje buff\u00f3w o ustawionym przez ciebie czasie. Znajdzie buffy w paczkach i zastosuje je na postaci.",mj:"Ta opcja wprowadzi ci\u0119 do podziemia. Nie zapomnij w\u0142\u0105czy\u0107 Automatycznego Logowania z zak\u0142adki Dodatki, inaczej mo\u017cesz zosta\u0107 wylogowany przy wej\u015bciu do podziemia [B\u0142\u0105d Gry]",
ec:"Ta opcja b\u0119dzie atakowa\u0107 tylko list\u0119 aren/cyrk\u00f3w. Je\u017celi nie uda si\u0119 jej wykona\u0107, bot pominie dan\u0105 aren\u0119.",Hj:"Ta opcja jest tylko dla licencji premium. Symuluje atak przed zaatakowaniem u\u017cytkownika dla 75% szansy na wygran\u0105.",Od:"Nie musisz w\u0142\u0105cza\u0107 g\u0142\u00f3wnego prze\u0142\u0105cznika aukcji, aby w\u0142\u0105czy\u0107 t\u0119 opcj\u0119.",sk:"Ta opcja od\u015bwie\u017cy stron\u0119 co sekund\u0119, gdy aukcja jest w stanie -Bardzo Kr\u00f3tki-, aby nieustannie licytowa\u0107 i wygra\u0107 aukcj\u0119.",
Tj:"Je\u015bli \u017caden z warunk\u00f3w wytopu nie zostanie spe\u0142niony, b\u0119dzie wybiera\u0107 losowo. Upewnij si\u0119, \u017ce wybra\u0142e\u015b typ i kolor przedmiotu.",Uj:"Ta opcja b\u0119dzie tylko wytopi\u0107 przedmioty z inwentarza. Zignoruje przedmioty w paczkach.",Wa:"Przedmioty na Aukcji",rg:"Przedmioty Najemnika",Xb:"Przedmioty w Sklepie",Ai:"Unikalne Przedmioty",Pj:"Ustaw t\u0142o na czarne [Zwi\u0119ksza wydajno\u015b\u0107]",Qj:"Przenie\u015b przyciski GLDbot do lewego dolnego rogu?",
Ri:"Atakuj Cyrk Bez Leczenia",rk:"Czy pobra\u0107 z\u0142oto z paczek, je\u015bli to konieczne?",bm:"Z\u0142oto zosta\u0142o pobrane z paczek do treningu",Fd:"Nie znaleziono z\u0142ota w paczkach do treningu",lk:"Naprawione Przedmioty",ek:"Ataki na Arenie",gk:"Ataki w Cyrku",mk:"Zresetowane Przedmioty",jk:"Ataki na Wyprawach",ik:"Ataki w Lochach",pk:"Ataki w Podziemiach",fk:"Pieni\u0105dze Zarobione na Arenie",hk:"Pieni\u0105dze Zarobione w Cyrku",nk:"Przedmioty Przetopione",kk:"Przetopione Z\u0142oto",
dj:"Bitwa Gildii",fj:"Ustawienia Gildii",tl:"B\u0119dzie atakowa\u0107 gildie losowo.",ej:"Nazwa Gildii",Pi:"Zresetuj Statystyki",cj:"Atakuj losowo?",El:"GLDbot: U\u017cyj kostek, aby od\u015bwie\u017cy\u0107 tajemnicze pude\u0142ko i znale\u017a\u0107 cenne przedmioty przed ich otwarciem (itp. Kostiumy). Kliknij \u201eStart\u201d otw\u00f3rz skrzynie.",Pc:"Drewno",Fc:"Mied\u017a",Jc:"\u017belazo",Lc:"Sk\u00f3ra",Qc:"We\u0142niana nitka",Gc:"Bawe\u0142na",Ic:"Konopie",Hc:"Kawa\u0142ek tkaniny",Mc:"Kawa\u0142ek w\u0142\u00f3kna lnianego",
Kc:"\u0141ata z juty",Oc:"Pasek aksamitu",Nc:"Jedwabna nitka",Yc:"Futro",Sc:"Od\u0142amek ko\u015bci",ad:"\u0141uska",Vc:"Pazur",Xc:"Kie\u0142",Wc:"Smocza \u0142uska",Tc:"R\u00f3g byka",$c:"Gruczo\u0142 jadowy",Uc:"Kawa\u0142ek futra Cerbera",Zc:"\u0141uska Hydry",bd:"Pi\u00f3ro Sfinksa",cd:"Sk\u00f3ra Tyfona",Cc:"Lazuryt",wc:"Ametyst",vc:"Bursztyn",xc:"Akwamaryn",Dc:"Szafir",Ac:"Granat",zc:"Szmaragd",yc:"Diament",Bc:"Jaspis",Ec:"Sugilit",qc:"Jad skorpiona",tc:"Eliksir wytrwa\u0142o\u015bci",mc:"Antidotum",
lc:"Adrenalina",sc:"Eliksir o\u015bwiecenia",pc:"Nap\u00f3j postrzegania",nc:"Esencja refleksu",oc:"Fiolka Charyzmy",uc:"Woda zapomnienia",rc:"Esencja duszy",Bd:"Wodna piecz\u0119\u0107",vd:"Runa ochrony",td:"Ziemny grawerunek",Ad:"\u015awi\u0119ty totem",zd:"Talizman mocy",xd:"Kamie\u0144 szcz\u0119\u015bcia",ud:"Krzemie\u0144",yd:"Runa wichury",wd:"Runa cienia",gd:"Kryszta\u0142",fd:"Br\u0105z",ld:"Obsydian",od:"Srebro",pd:"Siarka",jd:"Ruda z\u0142ota",nd:"Kwarc",md:"Platina",ed:"Almandyn",hd:"Kupryt",
kd:"Piekielny kamie\u0144",Li:"Atakuj losowo?",Mi:'Wy\u0142\u0105cz r\u00f3wnie\u017c ustawienie "Sortuj graczy na arenie wed\u0142ug poziomu" w crazy-addon.',$g:"Akceptuj tylko misje na podstawie typu boga.",Xa:"Automatyczny Buff",be:"U\u017cywaj tylko w piekle?",Gg:"Nowa Zasada",Eg:"Nazwa Zawiera",isUnderworldItem:"Czy to przedmiot z Podziemi",kf:"Ignoruj Materia\u0142y",yk:"U\u017cyj modlitwy",Gi:"U\u017cyj ofiary",uk:"U\u017cyj tkaniny, aby wej\u015b\u0107 do podziemia",xi:"Czy w podziemiach akceptowa\u0107 tylko zadania zwi\u0105zane z podziemiami?",
wi:"Je\u015bli w\u0142\u0105czone, musisz wprowadzi\u0107 nazwy przedmiot\u00f3w z podziemi. Je\u015bli bot znajdzie te przedmioty w podziemiach, zaakceptuje zadanie.",el:"Przedmiot zadania z podziemi",ql:"Wprowad\u017a nazw\u0119 materia\u0142u",Ik:"Bot uwielbia ko\u015bci! Pomagaj\u0105 znale\u017a\u0107 ubrania w skrzyniach. Ale je\u015bli nie ma ko\u015bci, bot i tak otwiera skrzynie, licz\u0105c na fajne ciuchy (ale mo\u017ce ich nie znale\u017a\u0107!)",Sj:"Czy chcesz przetopi\u0107 skrzynki?",
qe:"W\u0142\u0105cz automatyczne ataki na arenie?",Sg:"Priorytetowa lista aren?",Tg:"Priorytetowa lista cyrk\u00f3w?",ie:"Wy\u0142\u0105cz menu dziennika",oh:"Minimalna warto\u015b\u0107 nagrody z\u0142ota",ah:"Je\u015bli w\u0142\u0105czone, Fokus na zadaniach b\u0119dzie pod\u0105\u017ca\u0142 najkr\u00f3tsz\u0105 drog\u0105 do uko\u0144czenia lochu.",Nh:"Automatyczne rzucanie kostk\u0105?",Oh:"U\u017cywaj rzucania kostk\u0105 ostro\u017cnie, b\u0119dzie ono nadal u\u017cywa\u0107 pierwszej kostki, dop\u00f3ki nie wy\u0142\u0105czysz opcji.",
uh:"Post\u0119p w wyszukiwaniu",ih:"Czas odnowienia naprawy domy\u015blnie wynosi 10 minut.",Bg:"Minimalny stan",ge:"Obecny przedmiot na warsztacie [Wyczy\u015b\u0107, je\u015bli bot nagle zostanie zatrzymany]",Gf:"Pomy\u015blnie przechowywano zasoby do horreum.",Cf:"Sprawdzanie rynku na przedmioty...",Ab:"Przedmiot przeniesiony na warsztat.",Tf:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony i za\u0142o\u017cony.",Uf:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony.",Sk:"Naprawa nie powiod\u0142a si\u0119. Strona zostanie od\u015bwie\u017cona.",
Qf:"Podnoszenie materia\u0142\u00f3w...",bg:"Oczekiwanie na napraw\u0119...",Sf:"Naprawa rozpocz\u0119\u0142a si\u0119 dla .",wa:"Naprawa: Przenoszenie przedmiotu z inwentarza do torby",Rf:"Naprawa: Przenoszenie przedmiotu z warsztatu do paczki.",ua:"Nie uda\u0142o si\u0119 znale\u017a\u0107 wystarczaj\u0105cej ilo\u015bci materia\u0142\u00f3w. Wy\u0142\u0105czanie slotu naprawy ",Nf:"Szukanie przedmiot\u00f3w do kupienia w celu ukrycia z\u0142ota na Aukcji...",zf:"Sprawdzanie wygas\u0142ych przedmiot\u00f3w w paczkach...",
Af:"Przedmiot zosta\u0142 pomy\u015blnie zresetowany.",Bf:"Brak pustej przestrzeni lub z\u0142ota do zresetowania.",Hf:"Upewnij si\u0119, \u017ce masz prawa do sprzeda\u017cy na rynku gildii!",ub:"Brak wystarczaj\u0105cej ilo\u015bci z\u0142ota/lub brak przedmiotu do kupienia. Oczekiwanie 30 sekund na od\u015bwie\u017cenie.",wb:"Sklep zosta\u0142 od\u015bwie\u017cony.",xb:"B\u0142\u0105d podczas leczenia.",Kf:"Brak Rubina lub Materia\u0142u, wy\u0142\u0105czanie opcji.",Rk:"Brak przedmiotu do leczenia w paczkach.",
yb:"Nie znaleziono odpowiednich przedmiot\u00f3w",Lf:"\u017bywno\u015b\u0107 zosta\u0142a wybrana. Zako\u0144czenie procesu.",Mf:"Wybrano przynajmniej jedzenie. Proces zako\u0144czony.",zb:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",If:"Pobieranie jedzenia z paczek.",Jf:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",vb:"Brak wi\u0119cej przedmiot\u00f3w do leczenia. Oczekiwanie 30 sekund.",tb:"Odzyskano punkty \u017cycia.",va:"Nie ma nic do roboty, wi\u0119c id\u0119 si\u0119 pomodli\u0107!",
Yf:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie i Vill\u0119 Medici.",Zf:"Oczekiwanie na Vill\u0119 Medici, od\u015bwie\u017canie za 60 sekund.",$f:"Opuszczono za\u015bwiaty.",ag:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie.",Of:"Sprawdzanie olejk\u00f3w bo\u017cych...",Pf:"Olejki bo\u017ce zosta\u0142y podniesione.",sa:"Pomy\u015blnie zaatakowano gracza na ARENIE: ",ta:"Pomy\u015blnie zaatakowano gracza w CIRKUSIE: ",xf:"Sprawdzanie aukcji! Prosz\u0119 czeka\u0107...",
yf:"Licytacja przedmiot\u00f3w. Prosz\u0119 czeka\u0107...",Vf:"Automatycznie przetopiony przedmiot: ",Wf:"Przetapiany przedmiot: ",Bb:"Nie ma wystarczaj\u0105cej ilo\u015bci z\u0142ota do przetopienia. Wymagane z\u0142oto: ",Xf:"PRZETAP: Szukanie przedmiot\u00f3w do przetopienia...",Tk:"Szukanie przedmiot\u00f3w do przetopienia...",Df:"Sprawdzanie dost\u0119pno\u015bci kostium\u00f3w...",Ff:"Wys\u0142ano datek: ",Ef:"Rzucanie kostk\u0105...",Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",
Ye:"Uwaga: w\u0142\u0105cz t\u0119 funkcj\u0119 po odblokowaniu stworzenia, kt\u00f3re chcesz zaatakowa\u0107, nie b\u0119dzie ono automatycznie atakowa\u0107, aby odblokowa\u0107 potwora.",Ve:"Farm Enemy",Vd:"Automatyczne Logowanie",Wd:"Musisz zezwoli\u0107 na wyskakuj\u0105ce okienka z ekranu lobby GameForge. Zobacz dokumentacj\u0119, jak to zrobi\u0107.",Og:"Wstrzymaj Bota",Pg:"Wstrzymaj Bota na (Minuty)",Te:"Data Wyga\u015bni\u0119cia",Jg:"Tylko kupowa\u0107 jedzenie?",Kg:"Je\u015bli to w\u0142\u0105czysz, zignoruje twoje wybory i b\u0119dzie automatycznie kupowa\u0107 jedzenie, nie wprowadzaj\u0105c niczego.",
Jb:"Maksymalna \u0142\u0105czna ilo\u015b\u0107 z\u0142ota do wydania",Ib:"Maksymalna ilo\u015b\u0107 z\u0142ota na jedzenie do wydania",Ig:"Bot b\u0119dzie sprawdza\u0107 oleje co 60 minut",fi:"Ustawia timer do sprawdzania czas\u00f3w topienia.",ci:"Ustawia timer do sprawdzania topienia, gdy nie masz z\u0142ota.",ei:"Ustawia timer do sprawdzania topienia, gdy nie masz dost\u0119pnego przedmiotu.",Yh:"Ustawia timer do naprawy i sprawdzania twoich przedmiot\u00f3w.",Xh:"Ustawia timer do sprawdzania ilo\u015bci z\u0142ota w gildijnym rynku.",
Th:"Ustawia timer dla opcji zatrzymania z\u0142ota na aukcji.",Ph:"Ustawia timer do sprawdzania listy PvP na arenie do ataku.",Uh:"Ustawia timer do sprawdzania listy PvP w cyrku do ataku.",li:"Ustawia timer treningowy do trenowania statystyk.",$h:"Ustawia timer do resetowania wygas\u0142ych przedmiot\u00f3w.",ji:"Ustawia timer do przechowywania materia\u0142\u00f3w do kucia w horreum.",Rh:"Ustawia timer do sprawdzania aukcji gladiator\u00f3w i najemnik\u00f3w.",bi:"Ustawia timer do wyszukiwania przedmiot\u00f3w na aukcji i w sklepie.",
Vh:"Ustawia timer do wysy\u0142ania darowizn do gildii.",bf:"Z\u0142oto Przeniesione",ne:"Nie sprzedawaj przedmiot\u00f3w z listy hutniczej i aukcyjnej",vh:"Automatyzacja Sklepu",xh:"Ustawienia Wyszukiwania Przedmiotu",wh:"U\u017cyj tego narz\u0119dzia do wyszukiwania przedmiot\u00f3w. Po prostu dodaj przedmioty do listy, okre\u015bl ilo\u015b\u0107 tkaniny i rozpocznij wyszukiwanie.",yh:"Ilo\u015b\u0107 Tkaniny do U\u017cycia:",zh:"Ile tkaniny u\u017cy\u0107?",fa:"Full Wprowad\u017a Nazw\u0119 Przedmiotu",
Wb:"Wprowad\u017a Poziom Przedmiotu",Bh:"Jako\u015b\u0107 Przedmiotu",Ah:"Wprowad\u017a Nazw\u0119 Przedmiotu Tutaj",Ch:"Rozpocznij Wyszukiwanie",Dh:"Pomi\u0144 i Kontynuuj",Eh:"Zatrzymaj Wyszukiwanie",Ze:"Kupi\u0107 najta\u0144sze czy najdro\u017csze?",Dg:"Najdro\u017csze",de:"Najta\u0144sze",Da:"Wybierz Opcj\u0119",se:"Pod\u015bwietl przedmioty z Podziemia",$e:"Skoncentruj si\u0119 na zadaniu?",dm:"U\u017cyj rubinu, je\u015bli nie ma tkaniny?",Ya:"Unikaj atakowania tych samych os\u00f3b, aby unikn\u0105\u0107 zg\u0142osze\u0144. Zg\u0142oszenia zwi\u0119kszaj\u0105 szans\u0119 na zablokowanie konta.",
Tl:"Roztopi\u0107 zielone?",Vg:"Nie akceptuj losowych zada\u0144, je\u015bli wprowadzono jakiekolwiek filtry?",Rc:"Maksymalna jako\u015b\u0107 materia\u0142u do u\u017cycia",$i:"W\u0142\u0105czy\u0107 wyszukiwanie najemnik\u00f3w",Al:"Kliknij \u201eSprzedaj Wszystkie Wybrane\u201d, aby sprzeda\u0107 wszystkie przedmioty. Upewnij si\u0119, \u017ce masz 2x3 puste miejsce w swojej pierwszej (1) torbie. Aby zbiera\u0107 z\u0142oto masowo, u\u017cyj filtra na z\u0142oto i opcji \u201eWybierz Wybrane lub Wybierz Wszystkie\u201d.",
dk:"\ud83d\udd25 : Dodaje przedmiot do listy przetapiania.",Ni:"\ud83d\udd28 : Dodaje przedmiot do listy aukcyjnej.",Jj:"Od\u015bwie\u017c sklep tkanin\u0105, gdy jest pe\u0142ny",Il:"Strona:",Fj:"Zatrzymaj",Dj:"Sprzedaj T\u0119 Stron\u0119",Aj:"Wybierz Wybrane",zj:"Wybierz Wszystko",Gj:"Ustawienia Automatycznego Pakowania",Ej:"Wy\u015blij Zasoby",Bj:"Sprzedaj Wszystkie Wybrane",na:"Rodzaj Przedmiotu",pa:"Bronie",U:"Tarcze",O:"Zbroje",S:"He\u0142my",R:"R\u0119kawice",P:"Buty",oa:"Pier\u015bcienie",
la:"Amulety",Ka:"U\u017cytkowe (\u017bywno\u015b\u0107)",Pa:"Ulepszenia",yj:"Wzmacniacze",Ma:"Receptury",La:"Najemnicy",Oa:"Narz\u0119dzia Kowalskie",Na:"Zwoje",sd:"Wzmocnienia",qd:"Przedmioty Eventowe",rd:"Materia\u0142y Kowalskie",Hl:"Z\u0142oto",Ja:"Wszystko",Jl:"Jako\u015b\u0107",qa:"Bia\u0142y",C:"Zielony",B:"Niebieski",D:"Fioletowy",J:"Pomara\u0144czowy",T:"Czerwony",Cj:"Opcje Sprzeda\u017cy",Rj:"Ignorowa\u0107 Kombinacje Przedrostk\u00f3w/Sufiks\u00f3w?",gj:"Ile jedzenia kupi\u0107/wybiera\u0107?",
Vi:"Normalny",Ui:"\u015aredni",Ti:"Trudny",Ga:"Standardowy",Nl:"Naprawa Utkni\u0119\u0107",Pk:"Wy\u0142\u0105cz Wej\u015bcie do Piek\u0142a, je\u015bli chcesz wy\u0142\u0105czy\u0107 Lochy/Cyrk/Aren\u0119. Je\u015bli wszed\u0142e\u015b do Piek\u0142a r\u0119cznie, musisz w\u0142\u0105czy\u0107 Tryb Piek\u0142a.",oi:"Okre\u015bl, ile razy chcesz przeprowadzi\u0107 szkolenia dla statystyk oraz ich priorytety. Bot nie b\u0119dzie przeprowadza\u0142 szkole\u0144, dop\u00f3ki nie zostanie ustalony priorytet. Je\u015bli priorytet zosta\u0142 ustawiony, ale nie ma ju\u017c wi\u0119cej statystyk do szkolenia, bot kontynuowa\u0107 b\u0119dzie z priorytetowym szkoleniem.",
nl:"Quest",ee:"Wybierz kostium z Za\u015bwiat\u00f3w",Ji:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",Dd:"Przetapianie",Yl:"Ustawienia Topienia",ak:"Topione Przedmioty",Zl:"Dodaj Prefiks lub Sufiks, gdy bot znajdzie go w paczkach, automatycznie przeprowadzi przetapianie.:",Xl:"Topiony Przedmiot:",ic:"Kliknij na przedmiot, kt\u00f3ry chcesz naprawi\u0107. Ten system naprawi twoje dwie postacie, g\u0142\u00f3wn\u0105 oraz pierwsz\u0105 posta\u0107 cyrku. Musisz mie\u0107 co najmniej 10000 z\u0142ota, aby naprawa mog\u0142a si\u0119 rozpocz\u0105\u0107. Je\u015bli utkn\u0105\u0142 na jednym przedmiocie, oznacza to, \u017ce nie masz materia\u0142u do naprawy. Spr\u00f3buj r\u00f3wnie\u017c zrobi\u0107 troch\u0119 miejsca w swoim inwentarzu. Bot rozpocznie napraw\u0119, gdy trwa\u0142o\u015b\u0107 przedmiotu wynosi 0%.",
gl:"Zastosuj tylko do Najemnik\u00f3w",jl:"Licytacja b\u0119dzie licytowa\u0107 tylko wtedy, gdy rynek zbli\u017cy si\u0119 do ko\u0144ca.",il:"Upewnij si\u0119, \u017ce DRUGA KARTA INWENTARZA jest pusta i masz 10 000 z\u0142ota. Bot znajdzie i umie\u015bci przedmiot na drugiej karcie, a nast\u0119pnie, gdy strona zostanie od\u015bwie\u017cona, przeprowadzi przetapianie przedmiotu. przetapianie b\u0119dzie ponownie sprawdzane co 5-10 minut.",jj:"Leczenie & Buffs",Ol:"Za ma\u0142o z\u0142ota na przetapianie. Wymagane Z\u0142oto:",
Rl:"Pomijanie licytacji: Cz\u0142onek gildii ju\u017c licytowa\u0142 przedmiot ",Ql:"Pomijanie licytacji: Ju\u017c licytowa\u0142e\u015b przedmiot ",advanced:"Zaawansowane",arena:"Arena",ja:"Auto Atak",fc:"Unikaj Ataku",ha:"Dodaj Gracza",ia:"Wpisz Nazw\u0119 Gracza (Same Server)",vl:"Zatrzymaj Bota, je\u015bli brakuje jedzenia?",circusTurma:"Cyrk Turma",Wi:"Trudno\u015b\u0107",dungeon:"Loch",Xi:"Ustawienia Lochu",eventExpedition:"Ekspedycja Wydarzenia",expedition:"Wyprawa",aj:"Ustawienia Wyprawy",
Lj:"Wybierz Potwora",xl:"Najwy\u017cszy",wl:"Umie\u015b\u0107 swoje przedmioty uzdrawiaj\u0105ce na pierwszej stronie swojego inwentarza",nj:"W",Lh:"Przechowuj Z\u0142oto",Mh:"Przechowuj Z\u0142oto w Licytacji?",Ub:"Wybierz Godzin\u0119",rh:"U\u017cyj Roboczych Ubran, aby odnowi\u0107 Sklep?",Zk:"Wybierz Przedmioty do Zresetowania",kh:"Zresetuj Wygas\u0142e Przedmioty",Qb:"Uwaga: W\u0142\u0105czaj\u0105c t\u0119 opcj\u0119, bot b\u0119dzie sprzedawa\u0142 nadchodz\u0105ce wygas\u0142e przedmioty z Paczek na Rynek Gildii, a nast\u0119pnie anuluje, aby zresetowa\u0107 czas wyga\u015bni\u0119cia. Wymagana jest gildia. Upewnij si\u0119, \u017ce masz puste miejsce 3x3 w swoich torbach.",
Qg:"Losowe Zatrzymywanie Bota [Faza Testowa]:",aa:"Zachowaj Z\u0142oto: Bot b\u0119dzie trzyma\u0142 to z\u0142oto w torbie:",pg:"Max Gold: Bot b\u0119dzie wydawa\u0142, gdy z\u0142oto b\u0119dzie wi\u0119ksze ni\u017c",ph:"Bot b\u0119dzie sk\u0142ada\u0142 oferty na losowe przedmioty.",Gd:"Dodaj Losowe Op\u00f3\u017anienie",Hd:"Mo\u017cesz tutaj doda\u0107 op\u00f3\u017anienie do bota.",Pb:"Naprawa",Sl:"Top Tylko Niebieskie?",Vl:"Top Tylko Fioletowe?",Ul:"Top Tylko Pomara\u0144czowe?",bk:"Top Wszystko na 2. karcie?",
Wl:"To zignoruje wyb\u00f3r kolor\u00f3w",Za:"Wyczy\u015b\u0107 Histori\u0119",Gh:"Przetapianie",Pd:"Search",Fg:"Auto Licytacja",Qd:"Nadmierne korzystanie z aukcji mo\u017ce skutkowa\u0107 banem. Zaleca si\u0119 wy\u0142\u0105czenie innych funkcji okre\u015blania stawek, aby unikn\u0105\u0107 potencjalnych konflikt\u00f3w. Ta funkcja spowolni bota.",qh:"Szukaj w Licytacji Gladiator\u00f3w",th:"Szukaj w Licytacji Najemnik\u00f3w",Yd:"Licytuj Po\u017cywienie?",qg:"Maksymalna Licytacja",Zd:"Licytuj, je\u015bli status jest mniejszy ni\u017c",
$d:"Wystawione Przedmioty",Dk:"J\u0119zyk Licytacji",Ek:"Zgodnie z aktualizacj\u0105 2.9.4, prosz\u0119 ponownie ustawi\u0107 j\u0119zyk lub ZRESETOWA\u0106 BOTA. Upewnij si\u0119, \u017ce wszystko jest poprawne, w przeciwnym razie bot nie b\u0119dzie licytowa\u0107.",Kd:"Mo\u017cesz doda\u0107 przedmioty do wyszukiwania na rynku i w licytacji. Poka\u017ce tak\u017ce fioletowe przedmioty na rynku, gdy dodasz przedmiot do listy. Je\u015bli chcesz w\u0142\u0105czy\u0107 auto licytacj\u0119, u\u017cyj opcji poni\u017cej",
Bk:"U\u017cywaj licytacji z rozwag\u0105!",Ck:"Automatyczna licytacja generuje zbyt wiele \u017c\u0105da\u0144 do serwera i mo\u017ce spowodowa\u0107 ban, je\u015bli u\u017cywasz jej ca\u0142y czas!",hh:"Odnowi\u0107 Punkty Wydarzenia Rubinem?",ue:"W\u0142\u0105cz Auto Olej",Gk:"Auto Pobieraj \u015awi\u0119te Oleje",Vk:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Ua:"Atakowa\u0107 Cz\u0142onk\u00f3w Gildii?",Sa:'Automatycznie dodawaj osoby do listy "Atak", gdy wi\u0119cej ni\u017c X z\u0142ota zostanie skradzione.:',
Ta:'Automatycznie dodawaj osoby do listy "Unikaj Atak", gdy przegrasz z nimi.:',Tb:"Ataki na Tablicy Wynik\u00f3w",ac:"Bardzo D\u0142ugo",Cb:"D\u0142ugo",Kb:"\u015arednio",Yb:"Kr\u00f3tko",bc:"Bardzo Kr\u00f3tko",ve:"Wejd\u017a do Podziemia je\u015bli HP >",bh:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Ug:'Domy\u015blnie to "3x". Je\u015bli bot sprawia problemy z zadaniami, zmie\u0144 szybko\u015b\u0107 zada\u0144 zgodnie ze szybko\u015bci\u0105 serwera.',cf:"Wyb\u00f3r Worka z Lecznicami",xe:'Je\u015bli r\u0119cznie odnawiasz punkty, musisz klikn\u0105\u0107 przycisk powy\u017cej: "Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!"',
Kk:"Musisz w\u0142\u0105czy\u0107 co najmniej jedn\u0105 z opcji: ekspedycja, loch, arena lub cyrk, aby rozpocz\u0105\u0107 Ekspedycj\u0119 Eventow\u0105.",eh:"Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!",mb:"Nie przebijaj gildii?",bl:"Pozostaw wszystkie ustawienia wy\u0142\u0105czone, je\u015bli chcesz przetapia\u0107 za pomoc\u0105 paczek zawieraj\u0105cych przedmioty z listy. Jednak nadal mo\u017cesz wybiera\u0107 kolory.",Hk:"Posta\u0107(Wy\u0142\u0105czona) / Najemnik(W\u0142\u0105czony)",
Yk:"Naprawi\u0107 Obie?",cl:"Timery",Timers:"Wprowad\u017a liczb\u0119 minut dla ka\u017cdego timera poni\u017cej lub pozostaw domy\u015blnie.",Zg:"Ignoruj Filtr Zada\u0144",Yg:"Wprowad\u017a s\u0142owa kluczowe, aby odfiltrowa\u0107 zadania, kt\u00f3rych nie chcesz przyj\u0105\u0107. You can also use this to accept quests by their reward using keywords.",X:"Wprowad\u017a S\u0142owo Kluczowe",K:"Dodaj",gh:"Usu\u0144",fe:"Wyczy\u015b\u0107",Wg:"Akceptuj Filtr Zada\u0144",Xg:"Wprowad\u017a s\u0142owa kluczowe, aby wybra\u0107 zadania do przyj\u0119cia. U\u017cycie tego spowoduje ignorowanie rodzaj\u00f3w zada\u0144",
Ea:"Pomi\u0144 Zadania Czasowe?",Wk:"Zadania",Sd:"Automatyczny Kostium",Di:"U\u017cywa\u0107 Kostiumu?",Xd:"Podstawowa Bitwa",oe:"Bitwa w Lochach",Td:"Bot b\u0119dzie nosi\u0142 Dis Pater Normal i Medium tylko wtedy, gdy Twoje punkty ekspedycji/podziemi wynosz\u0105 0.",ef:"Ustawienia Piekielnego Leczenia",Jd:"Atakuj Bossa, Gdy Dost\u0119pny?",sb:"Atak na Lig\u0119 zostanie wy\u0142\u0105czony po 5 nieudanych atakach.",hf:"\u015awi\u0119te Oleje",Ag:"Nazwa Przedmiotu",ba:"Minimalny Poziom Przedmiotu",
Ba:"Minimalna Jako\u015b\u0107 Przedmiotu",Id:"Zastosuj/Resetuj Licznik",lf:"Ignoruj Prefiks/Sufiks",Ki:"Tak",Hg:"Nie",Qa:"Dodaj Prefiks",Ra:"Dodaj Sufiks",Hh:"Lista Ignorowanych Przedmiot\u00f3w do Topienia",Mb:"Prefiks",Zb:"Sufiks",mh:"Resetuj Wygas\u0142e Przedmioty",Ih:"Losowe Topienie z Paczek?",Jh:"Karta Topienia",qb:"Dodatki",Nd:"Aukcja",ig:"Rynek",$b:"Zegary",hi:"Topienie",gi:"Topienie, je\u015bli brakuje z\u0142ota",di:"Topienie, je\u015bli brakuje przedmiotu",Fa:"Naprawa",Wh:"Przechowuj Z\u0142oto na Rynku Gildii",
Sh:"Przechowuj Z\u0142oto na Aukcji",ki:"Trening",Zh:"Resetuj Wygas\u0142e",ii:"Przechowuj W Ku\u017ani",Qh:"Sprawd\u017a Aukcj\u0119",ai:"Szukaj",v:"W\u0142\u0105cz",Cg:"Minimalne Z\u0142oto",nb:"Wp\u0142acaj Z\u0142oto do Gildii",je:"B\u0119dzie wp\u0142aca\u0107 co 5 minut. Mo\u017cesz zmieni\u0107 interwa\u0142 w zak\u0142adce zegar\u00f3w",jf:"Ile chcesz wp\u0142aci\u0107?",ke:"Wp\u0142aca\u0107, gdy masz wi\u0119cej ni\u017c >",wf:"Mniej ni\u017c <",jh:"Resetuj Wygas\u0142e i Inne Ustawienia",
lh:"Reset za:",Qk:"Naci\u015bnij Ctrl (Cmd na Macu), aby zaznaczy\u0107 wiele przedmiot\u00f3w",mf:"Importuj/Eksportuj Ustawienia",Ue:"Eksportuj Ustawienia",nf:"Importuj Ustawienia",tg:"Wiadomo\u015b\u0107 do Wszystkich Graczy",ug:"[Wymaga Klucza Ultra Premium, wiadomo\u015b\u0107 na Discordzie, aby go otrzyma\u0107.]",vg:"Wprowad\u017a wiadomo\u015b\u0107 do wys\u0142ania",he:"Aby uzyska\u0107 niestandardowe skrypty, skontaktuj si\u0119 z nami na Discordzie",xg:"Wy\u015blij",yg:"Poka\u017c Graczy",
wg:"Zaznacz Wszystkie",zg:"Odznacz Wszystkie",vf:"Upewnij si\u0119, \u017ce tw\u00f3j inwentarz ma wystarczaj\u0105co du\u017co miejsca. Czas odnowienia wynosi 2 minuty.",pb:"W\u0142\u0105cz Atak na Tablicy Wynik\u00f3w:",Rb:"Wybierz Zakres Ataku",Sb:"Bot losowo atakuje z listy tablicy wynik\u00f3w.",rb:"Atak Ligi",ob:"W\u0142\u0105cz Atak Ligi:",Nb:"Losowo Atakuj",Ob:"Atakuj od najs\u0142abszego do najsilniejszego",Ak:"Domy\u015blnie bot unika atakowania cz\u0142onk\u00f3w gildii.",Se:"Lokalizacja Wyprawy:",
Rd:"Auto Zbieraj Bonusy:",Fh:"Pomi\u0144 Bossa",pe:"Lokalizacja Lochu:",nh:"Zresetowa\u0107, je\u015bli przegrasz?",ff:"Ustawienia Piek\u0142a",gf:"Skonfiguruj ustawienia procentu leczenia w zak\u0142adce leczenia i upewnij si\u0119, \u017ce zak\u0142adka leczenia jest aktywowana. Je\u015bli wej\u015bcie do podziemi wyrzuca ci\u0119 z gry, przejd\u017a do lobby i zaznacz pole wyboru automatycznego logowania.",df:"Trudno\u015b\u0107 Piek\u0142a",Ud:"Auto Wej\u015bcie do Piek\u0142a: / Piek\u0142a Mode",
Ei:"U\u017cyj Mobilizacji, je\u015bli punkty = 0",Ii:"U\u017cyj rubin\u00f3w?",ye:"Wyj\u015b\u0107 z podziemi, je\u015bli nie ma punkt\u00f3w?",ri:"Bot b\u0119dzie pr\u00f3bowa\u0142 u\u017cy\u0107 willi medici najpierw, je\u015bli jej nie masz, u\u017cyje mikstury uzdrawiania. Nie zapomnij w\u0142\u0105czy\u0107 prze\u0142\u0105cznika uzdrawiania.",zi:"Automatyczne wej\u015bcie do piek\u0142a wy\u0142\u0105czy loch/aren\u0119/cyrk po wej\u015bciu do piek\u0142a.",dl:"Ustawienia Leczenia Piek\u0142a",
Hi:"U\u017cyj Willi Medici?",Fi:"U\u017cyj Mikstury Uzdrawiania?",dg:"INFORMACJA: Bot b\u0119dzie wyszukiwa\u0142 przedmioty na rynku co wybran\u0105 liczb\u0119 minut, co mo\u017ce spowodowa\u0107 zatrzymanie atakowania podczas wyszukiwania.",te:"W\u0142\u0105cz Wyszukiwanie na Rynku:",eg:"Interwa\u0142 Wyszukiwania na Rynku w Minutach:",fg:"Sugerowane 10 minut.",rf:"Ustawienia Przedmiotu:",pf:"Nazwa Przedmiotu Zawiera",G:"Maksymalna Cena",sf:"Rodzaj Przedmiotu",qf:"Rzadko\u015b\u0107 Przedmiotu",
ce:"Kup Przedmiot Uwi\u0105zany?",uf:"Przedmioty do Kupienia",tf:"Pr\u00f3buj kupowa\u0107 przedmioty z paczek, je\u015bli kt\u00f3rykolwiek z nich pasuje do maksymalnej ceny wprowadzonej.:",ae:"Zakupione Przedmioty:",hj:"Procent Leczenia",wk:"Kupuj Jedzenie ze Sklepu?",xk:"U\u017cyj Leczenia z Paczki?",tk:"U\u017cyj Cervisia?",vk:"U\u017cyj Jajka?",Bl:"Ostatnio U\u017cyty",location:"Lokalizacja",Strength:"Si\u0142a",Dexterity:"W\u0142adanie broni\u0105",Agility:"Zr\u0119czno\u015b\u0107",Constitution:"Budowa fizyczna",
Charisma:"Charyzma",Intelligence:"Inteligencja",mi:"Ustawienia Treningu",ni:"Wybierz atrybuty, kt\u00f3re chcesz trenowa\u0107. Bot przeprowadzi trening, gdy b\u0119dziesz mia\u0142 wystarczaj\u0105co du\u017co z\u0142ota.",N:"Nast\u0119pna akcja",vj:"Nie",wj:"Normalnie",Fl:"Przeciwnik",Gl:"Poziom Przeciwnika",Ij:"Zadania",random:"Losowo",Pl:"Ustawienia",$l:"Wkr\u00f3tce...",type:"Kliknij na ikony, aby aktywowa\u0107 rodzaje zada\u0144.",fm:"Tak",A:"Licytacja/Szukaj",Cd:"Dodaj przedmioty",qk:"Automatycznie Przechowuj Zasoby W\u0142asne",
am:"Zatwierd\u017a",zl:"Interwa\u0142 : ",ol:"W\u0142\u0105cz Automatyczn\u0105 Licytacj\u0119",pl:"Nie licytuj, je\u015bli cz\u0142onek gildii ju\u017c licytowa\u0142",cm:"Samouczek",hc:"Wybierz przyciski powy\u017cej, aby wybra\u0107, czy chcesz stawi\u0107 czo\u0142a najni\u017cszemu przeciwnikowi na arenie, czy przeciwnikowi najwy\u017cszego poziomu. Wi\u0119cej u\u017cytkownik\u00f3w spowolni dzia\u0142anie bota.",hl:'Aby rozpocz\u0105\u0107, dodaj przedmiot do listy (np. "Lucius"). Po dodaniu narz\u0119dzie b\u0119dzie szuka\u0107 przedmiotu i wy\u015bwietla\u0107 wyniki wyszukiwania po lewej stronie ekranu. B\u0119dzie r\u00f3wnie\u017c szuka\u0107 przedmiotu w celu automatycznej licytacji. Je\u015bli w\u0142\u0105czysz automatyczn\u0105 licytacj\u0119, narz\u0119dzie b\u0119dzie regularnie szuka\u0107 przedmiotu w okre\u015blonych odst\u0119pach czasu, zgodnie z liczb\u0105 wpisan\u0105 w polu interwa\u0142u. Je\u015bli narz\u0119dzie znajdzie przedmiot i b\u0119dziesz mie\u0107 wystarczaj\u0105co du\u017co pieni\u0119dzy, automatycznie z\u0142o\u017cy za ciebie licytacj\u0119. *Uwaga* aby szuka\u0107 unikalnych przedmiot\u00f3w w sklepach, musisz doda\u0107 przynajmniej 1 losowy przedmiot do listy wyszukiwania.',
rl:"Numer potwora mo\u017cna wybra\u0107 z przycisk\u00f3w powy\u017cej. Numer 1 reprezentuje potwora najbardziej na lewo. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",Yi:"Wybierz trudno\u015b\u0107 lochu z powy\u017cszych opcji. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",ij:"Ustawienia Leczenia",Zi:"Przechowuj nadmiar z\u0142ota w Gildii, kupuj\u0105c przedmioty z rynku gildii. -> Min. Z\u0142oto",
Cl:"Przenie\u015b Wszystko",Dl:"Przenie\u015b Wybrane",kl:"Auto Uzdrawianie",ll:"Procent Auto Uzdrawiania",em:"Ruby",Lg:"Og\u00f3lne Ustawienia",Mj:"Sprzedaj Wszystko",Nj:"Sprzedaj Wybrane",ga:"Bronie",da:"Tarcze",W:"Zbroje Piersiowe",Z:"He\u0142my",Y:"R\u0119kawice",ea:"Buty",ca:"Pier\u015bcienie",V:"Amulety",Ci:"U\u017cywalne",Bi:"Ulepszenia",dh:"Receptury",sg:"Zwoje Najemnik\u00f3w",fh:"Wzmocnienia",mg:"Sprzedaj \u017bywno\u015b\u0107",Gb:"Prze\u0142\u0105cz na \u017bywno\u015b\u0107"},Oh={we:"Cambiar autom\u00e1ticamente a los monstruos de eventos",
cg:"\u00a1Error de mercado! Por favor, a\u00f1ade los elementos nuevamente e int\u00e9ntalo.",Lb:"No hay suficiente espacio en tu inventario. Por favor, limpia tu inventario.",ck:"\u00bfDerretir los colores m\u00e1s altos primero?",cc:"\u00bfAtacar solo a la lista de jugadores?",dc:"Cuando esta opci\u00f3n est\u00e9 habilitada, el bot solo atacar\u00e1 a los jugadores en la lista de jugadores. Si esta opci\u00f3n no est\u00e1 habilitada, el bot atacar\u00e1 a jugadores aleatorios.",Mk:"\u00a1Tus configuraciones de expedici\u00f3n son incorrectas o hay datos de p\u00e1gina inesperados!",
Nk:"\u00a1Tu configuraci\u00f3n de expedici\u00f3n es incorrecta! Has establecido un monstruo deshabilitado, lo cual est\u00e1 mal.",Ca:"Prioridad",Vb:"Establecer Prioridad",Rg:"Puntos",Kh:"Stat",Si:"Recolectar Oro",Oj:"Vender en el Inframundo?",uj:"El bot buscar\u00e1 el nido en cada acci\u00f3n, no solo en expediciones.",sj:"Tipo de b\u00fasqueda de nido",qj:"No hacer nada",rj:"B\u00fasqueda r\u00e1pida",tj:"B\u00fasqueda exhaustiva",Ml:"After expedition points are consumed, travel to Germania to consume Dungeon points",
zk:"Haz clic aqu\u00ed si la reparaci\u00f3n se atasca",Ok:"Cuando los HP est\u00e9n bajos, usa curar",Ng:"Reparaci\u00f3n Parcial",af:"Reparaci\u00f3n Completa",Mg:"Reparaci\u00f3n Parcial o Completa",re:"Habilitar L\u00edmite",kj:"L\u00edmite",lj:"Si deseas limitar el n\u00famero de veces que quieres atacar al enemigo, habilita esta opci\u00f3n y establece el l\u00edmite. El bot continuar\u00e1 atacando al resto de los enemigos despu\u00e9s de terminar de atacar al monstruo seleccionado.",me:"No entres al inframundo con el traje del inframundo",
le:"Si no quieres entrar al inframundo mientras llevas el traje del inframundo puesto, activa esta opci\u00f3n",yi:"Inframundo",pi:"Mejoras del Inframundo",si:"\u00bfUsar los poderes de los dioses despu\u00e9s de entrar al inframundo?",ti:"Selecciona a los dioses para usar sus poderes:",ui:"\u00bfUsar Buff de Arma en el arma?",vi:"\u00bfUsar Buff de Armadura en el siguiente equipo?",Jk:"El tiempo de enfriamiento es de 30 minutos. Si no llevas un disfraz, el bot restablecer\u00e1 el tiempo de enfriamiento a 0.",
al:"Seleccionar Colores",$a:"Forja de Vulcano",eb:"Escudo Terrestre de Feronia",fb:"Poder Fluido de Neptuno",gb:"Libertad A\u00e9rea de Aelous",hb:"Niebla Mortal de Plut\u00f3n",ib:"Aliento de Vida de Juno",jb:"Armadura de Escamas de las Monta\u00f1as de la Ira",kb:"Ojos de \u00c1guila",lb:"Vestidura Invernal de Saturno",ab:"Armadura de Toro de Bubona",bb:"Vestiduras de Ladr\u00f3n de Mercurio",cb:"T\u00fanica de Luz de Ra",lg:"Paquetes",gg:"Inventario",M:"Precio M\u00edn.",L:"Cantidad",Fb:"Vender Art\u00edculos",
Eb:"Buscar en",hg:"Color del Material",Db:"Color del Art\u00edculo",og:"Almac\u00e9n",Aa:"Cambiar a Materiales",Hb:"Cambiar a Art\u00edculos",ng:"Vender Materiales",xa:"Por favor, introduce un nombre de art\u00edculo v\u00e1lido, rango de precio y cantidad.",ya:"No se han encontrado art\u00edculos adecuados en las ubicaciones de b\u00fasqueda seleccionadas.",za:"\u00a1Todos los art\u00edculos fueron listados con \u00e9xito!",Uk:"\u00a1Todos los materiales fueron listados con \u00e9xito!",jg:"Si quieres vender art\u00edculos a un precio fijo, puedes ingresar el mismo valor para el precio m\u00ednimo y m\u00e1ximo.",
kg:"Esta caracter\u00edstica todav\u00eda es experimental, \u00fasala con precauci\u00f3n. Si no pones un precio fijo, los art\u00edculos se listar\u00e1n aleatoriamente entre el precio m\u00ednimo y m\u00e1ximo que ingreses.",Fk:"Establece el m\u00e1ximo de oro que el bot gastar\u00e1 por ciclo.",Va:"El bot comenzar\u00e1 a pujar por cualquier art\u00edculo de comida, si est\u00e1 habilitado. No necesitas habilitar los interruptores de gladiador/mercenario.",Ld:"El bot no pujar\u00e1 sobre las ofertas de los aliados.",
Md:"Ignorar la combinaci\u00f3n de Prefijo/Sufijo al buscar un art\u00edculo en la subasta.",Vj:"Selecciona los tipos de art\u00edculos que quieres fundir.",Wj:"Selecciona los colores que quieres fundir.",Xj:"Selecciona el nivel de los art\u00edculos que quieres fundir.",Yj:"Selecciona el martillo que quieres usar.",Zj:"Nota que el c\u00edrculo verde y rojo junto a la primera caja son para habilitar/deshabilitar la regla.",$j:"Si quieres fundir aleatoriamente cualquier color o tipo, puedes habilitar `\u00bfFundir aleatoriamente si no se cumplen condiciones? (\u00daltima opci\u00f3n habilitada en el video tutorial)",
Kj:"Reparar antes de fundir?",Oe:"Seleccionar Monstruo",Ce:"\u00bfUsar Reloj de Arena/Rub\u00ed?",Lk:"\u00bfUsar Rub\u00ed?",Fe:"\u00bfUsar Movilizaci\u00f3n?",Ee:"\u00bfUsar Poci\u00f3n de Vida?",Be:"Porcentaje de Curaci\u00f3n (%)",Me:"N\u00famero de Ataques",De:"Intervalo de Ataque (en segundos)",ze:"Ataques Realizados",Ae:"Reloj de Arena Restante",Ke:"Nota: Usa pociones de vida para curar, no comida.",Le:"Nota: Si los ataques se detienen prematuramente, intenta 'Reiniciar Ataques'.",Pe:"Comenzar",
Ne:"Reiniciar",Qe:"Detener",Re:"Configuraci\u00f3n de Expedici\u00f3n (Clic para minimizar)",Ge:"Monstruo 1",He:"Monstruo 2",Ie:"Monstruo 3",Je:"Monstruo 4",Xk:"Reparar antes de fundir?",Qi:"Esta opci\u00f3n usar\u00e1 cervisia cuando tu premium expire.",xj:"Esta opci\u00f3n activa y selecciona aceites de las recompensas de los dioses. Puede usar los aceites n\u00famero 1 y n\u00famero 3 en el personaje, pero el n\u00famero 2 solo ser\u00e1 recogido para los paquetes.",Oi:"Esta opci\u00f3n usar\u00e1 buffs en el momento que establezcas. Encontrar\u00e1 buffs en los paquetes y los aplicar\u00e1 al personaje.",
mj:"Esta opci\u00f3n te llevar\u00e1 al inframundo. No olvides activar el Inicio de Sesi\u00f3n Autom\u00e1tico desde la pesta\u00f1a de Extras, de lo contrario podr\u00edas desconectarte al entrar al inframundo [Error del Juego]",ec:"Esta op\u00e7\u00e3o atacar\u00e1 apenas a lista de arena/circo. Se n\u00e3o puder, o bot pular\u00e1.",Hj:"Esta opci\u00f3n es solo para licencias premium. Simula el ataque antes de atacar a un usuario para un ratio de victoria del 75%.",Od:"No necesitas activar el interruptor principal de subastas para habilitar esta opci\u00f3n.",
sk:"Esta opci\u00f3n refrescar\u00e1 la p\u00e1gina cada segundo cuando la subasta est\u00e9 en estado -Muy Corto- para ofertar constantemente y ganar la subasta.",Tj:"Si ninguna de las condiciones de fundici\u00f3n se cumple, fundir\u00e1 aleatoriamente. Aseg\u00farate de seleccionar tipo de objeto y color.",Uj:"Esta opci\u00f3n solo fundir\u00e1 art\u00edculos del inventario. Ignorar\u00e1 los art\u00edculos en los paquetes.",Wa:"Art\u00edculos de Subasta",rg:"Art\u00edculos de Mercenario",Xb:"Art\u00edculos de la Tienda",
Ai:"Art\u00edculos \u00danicos",Pj:"Establecer fondo en negro [Aumenta el rendimiento]",Qj:"Mover los botones de GLDbot a la parte inferior izquierda?",Ri:"Atacar al circo sin sanar",rk:"\u00bfRecoger oro de los paquetes si es necesario?",bm:"Se ha recogido oro de los paquetes para entrenamiento",Fd:"No se ha encontrado oro en los paquetes para entrenamiento",lk:"Objetos Reparados",ek:"Ataques en la Arena",gk:"Ataques en el Circo",mk:"Objetos Reiniciados",jk:"Ataques en Expediciones",ik:"Ataques en Mazmorras",
pk:"Ataques en el Inframundo",fk:"Dinero Ganado en la Arena",hk:"Dinero Ganado en el Circo",nk:"Objetos Fundidos",kk:"Oro Reciclado",dj:"Batalla de Gremio",fj:"Configuraci\u00f3n del Gremio",tl:"Atacar\u00e1 gremios al azar.",ej:"Nombre del Gremio",cj:"Atacar Guilds Aleatoriamente",Pi:"Restablecer Estad\u00edsticas",El:'GLDbot: usa los dados para actualizar la caja misteriosa y encontrar objetos valiosos antes de abrirla (por ejemplo, disfraces). Haz clic en "Iniciar" para abrir los cofres.',Pc:"Madera",
Fc:"Cobre",Jc:"Hierro",Lc:"Cuero",Qc:"Hilo de lana",Gc:"Bolas de algod\u00f3n",Ic:"C\u00e1\u00f1amo",Hc:"Tiras de gasa",Mc:"Lino",Kc:"Yute",Oc:"Tiras de terciopelo",Nc:"Hilo de seda",Yc:"Pelaje",Sc:"Astilla \u00f3sea",ad:"Escama",Vc:"Garra",Xc:"Colmillo",Wc:"Escama de drag\u00f3n",Tc:"Cuerno de toro",$c:"Gl\u00e1ndula venenosa",Uc:"Pelaje de Cerbero",Zc:"Escama de Hidra",bd:"Pluma de Esfinge",cd:"Piel de Tif\u00f3n",Cc:"Lapisl\u00e1zuli",wc:"Amatista",vc:"\u00c1mbar",xc:"Aguamarina",Dc:"Safiro",Ac:"Granate",
zc:"Esmeralda",yc:"Diamante",Bc:"Jaspe",Ec:"Sugilita",qc:"Veneno de escorpi\u00f3n",tc:"Tintura de la resistencia",mc:"Ant\u00eddoto",lc:"Adrenalina",sc:"Tintura de la inspiraci\u00f3n",pc:"Poci\u00f3n de percepci\u00f3n",nc:"Esencia de reflejos",oc:"Frasco de carisma",uc:"Agua del olvido",rc:"Esencia de alma",Bd:"Sello acu\u00e1tico",vd:"Runa protectora",td:"Grabado terrestre",Ad:"T\u00f3tem curativo",zd:"Talism\u00e1n de poder",xd:"Piedra de la fortuna",ud:"Pedernal",yd:"Runa de la tormenta",wd:"Runa de las sombras",
gd:"Cristal",fd:"Bronce",ld:"Obsidiana",od:"Plata",pd:"Azufre",jd:"Mena de oro",nd:"Cuarzo",md:"Platino",ed:"Almandino",hd:"Cuprita",kd:"Piedra infernal",Li:"\u00bfAtacar aleatoriamente?",Mi:'Tambi\u00e9n desactiva la configuraci\u00f3n "Ordenar jugadores en la arena por nivel" en crazy-addon.',$g:"Aceptar solo misiones basadas en el tipo de dios.",Xa:"Auto Buff",be:"\u00bfUsar solo en el infierno?",Gg:"Nueva Regla",Eg:"Nombre Contiene",isUnderworldItem:"\u00bfEs un objeto del inframundo?",kf:"Ignorar Materiales",
yk:"\u00bfUsar Oraci\u00f3n?",Gi:"Usar Sacrificio",uk:"Usar Tela para entrar en el Inframundo",xi:"\u00bfCuando est\u00e9s en el inframundo, solo aceptar misiones relacionadas con el inframundo?",wi:"Si est\u00e1 habilitado, necesitas ingresar los nombres de los objetos del inframundo. Si el bot encuentra estos objetos en el inframundo, aceptar\u00e1 la misi\u00f3n.",el:"Objeto de Misi\u00f3n del Inframundo",ql:"Introduzca el nombre del material",Ik:"\u00a1El robot adora los dados! Le ayudan a encontrar ropa en los cofres. Pero si no hay dados, el robot abre los cofres de todos modos, con la esperanza de encontrar ropa genial (\u00a1pero puede que no encuentre nada!)",
Sj:"\u00bfFusionar Cajas de Bot\u00edn?",qe:"Habilitar Arena",Sg:"\u00bfPriorizar lista de arenas?",Tg:"\u00bfPriorizar lista de circos?",ie:"Desactivar men\u00fa de registro",oh:"Valor m\u00ednimo de recompensa en oro",ah:"Si est\u00e1 habilitado, el Enfoque en misiones seguir\u00e1 el camino m\u00e1s corto para terminar el calabozo.",Nh:"\u00bfLanzar dados autom\u00e1ticamente?",Oh:"Usa el lanzamiento de dados con cautela, seguir\u00e1 usando el primer dado hasta que desactives la opci\u00f3n.",
uh:"Progreso de b\u00fasqueda",ih:"El tiempo de enfriamiento para la reparaci\u00f3n por defecto es de 10 minutos.",Bg:"Condici\u00f3n m\u00ednima",ge:"Art\u00edculo actual en el banco de trabajo [Borrar si el bot se detiene inesperadamente]",Gf:"Recursos de forja almacenados en el horreum con \u00e9xito.",Cf:"Comprobando el mercado para art\u00edculos...",Ab:"Art\u00edculo movido al banco de trabajo.",Tf:"Art\u00edculo reparado y equipado con \u00e9xito.",Uf:"Art\u00edculo reparado con \u00e9xito.",
Sk:"La reparaci\u00f3n fall\u00f3. La p\u00e1gina se actualizar\u00e1.",Qf:"Recogiendo materiales...",bg:"Esperando reparaci\u00f3n...",Sf:"La reparaci\u00f3n ha comenzado para .",wa:"Reparaci\u00f3n: Moviendo el art\u00edculo del inventario a la bolsa",Rf:"Reparaci\u00f3n: Moviendo el art\u00edculo del banco de trabajo al paquete.",ua:"No se pudieron encontrar suficientes materiales. Desactivando la ranura de reparaci\u00f3n ",Nf:"Buscando art\u00edculos para comprar y ocultar oro en la subasta...",
zf:"Comprobando los art\u00edculos caducados en los paquetes...",Af:"Art\u00edculo reseteado con \u00e9xito.",Bf:"Sin espacio vac\u00edo o oro para resetear.",Hf:"\u00a1Aseg\u00farate de tener derechos de venta en el mercado de la guild!",ub:"No hay suficiente oro o ning\u00fan art\u00edculo para comprar. Esperando 30 segundos para actualizar.",wb:"La tienda ha sido actualizada.",xb:"Error durante la curaci\u00f3n.",Kf:"Sin Rub\u00ed o Tela, desactivando las opciones.",Rk:"No se encontr\u00f3 ning\u00fan art\u00edculo de curaci\u00f3n en los paquetes.",
yb:"No se encontraron art\u00edculos adecuados",Lf:"Se han recogido alimentos. Finalizando el proceso.",Mf:"Se ha recogido al menos un alimento. Finalizando el proceso.",zb:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",If:"Obteniendo alimentos de los paquetes.",Jf:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",vb:"No hay m\u00e1s art\u00edculos de curaci\u00f3n. Esperando 30 segundos.",tb:"Puntos de vida recuperados.",va:"\u00a1No hay nada que hacer, as\u00ed que voy a rezar!",
Yf:"Voy a actualizar en 60 segundos para revisar mi salud y Villa Medici.",Zf:"Esperando Villa Medici, actualizando en 60 segundos.",$f:"Sal\u00ed del inframundo.",ag:"Voy a actualizar en 60 segundos para revisar mi salud.",Of:"Comprobando aceites divinos...",Pf:"Los aceites divinos han sido recogidos.",sa:"Atacado con \u00e9xito al jugador en la ARENA: ",ta:"Atacado con \u00e9xito al jugador en el CIRCO: ",xf:"\u00a1Comprobando subasta! Por favor, espere...",yf:"Pujando por art\u00edculos. Por favor, espere...",
Vf:"Art\u00edculo fundido autom\u00e1ticamente: ",Wf:"Fundiendo art\u00edculo: ",Bb:"No hay suficiente oro para fundir. Oro requerido: ",Xf:"FUNDIR: Buscando art\u00edculos para fundir...",Tk:"Buscando art\u00edculos para fundir...",Df:"Comprobando disponibilidad de disfraces...",Ff:"Donado : ",Ef:"Lanzando dados...",Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",Ye:"Tenga en cuenta: active esta funci\u00f3n despu\u00e9s de desbloquear la criatura que desea atacar, no atacar\u00e1 autom\u00e1ticamente para desbloquear el monstruo.",
Ve:"Farm Enemy",Vd:"Inicio Autom\u00e1tico",Wd:"Necesitas permitir las ventanas emergentes desde la pantalla del lobby de GameForge. Consulta la documentaci\u00f3n sobre c\u00f3mo hacerlo.",Og:"Pausar Bot",Pg:"Pausar Bot en (Minutos)",Te:"Fecha de Expiraci\u00f3n",Jg:"\u00bfComprar solo comida?",Kg:"Si activas esto, el bot ignorar\u00e1 tus selecciones y comprar\u00e1 comida autom\u00e1ticamente sin ingresar nada.",Jb:"M\u00e1ximo de oro total para gastar",Ib:"M\u00e1ximo de oro por comida para gastar",
Ig:"El bot verificar\u00e1 los aceites cada 60 minutos",fi:"Establece un temporizador para verificar los tiempos de fundici\u00f3n.",ci:"Establece un temporizador para verificar la fundici\u00f3n cuando no tengas oro.",ei:"Establece un temporizador para verificar la fundici\u00f3n si no tienes el art\u00edculo disponible.",Yh:"Establece un temporizador para reparar y verificar tus objetos.",Xh:"Establece un temporizador para verificar el oro en el mercado de la hermandad.",Th:"Establece un temporizador para la opci\u00f3n de retenci\u00f3n de oro en la subasta.",
Ph:"Establece un temporizador para verificar la lista de PVP en la arena para atacar.",Uh:"Establece un temporizador para verificar la lista de PVP en el circo para atacar.",li:"Establece un temporizador para entrenar tus estad\u00edsticas.",$h:"Establece un temporizador para reiniciar los objetos caducados.",ji:"Establece un temporizador para almacenar los materiales de forja en el horreo.",Rh:"Establece un temporizador para verificar la subasta de gladiadores y mercenarios.",bi:"Establece un temporizador para buscar objetos en la subasta y la tienda.",
Vh:"Establece el temporizador para enviar donaciones a la hermandad.",bf:"Oro Movido",ne:"No vender art\u00edculos de la lista de fundici\u00f3n y subasta.",vh:"Automatizaci\u00f3n de la Tienda",xh:"Configuraci\u00f3n de B\u00fasqueda de Objetos",wh:"Utiliza esta herramienta para buscar objetos. Simplemente agrega los objetos a la lista, especifica la cantidad de tela y comienza la b\u00fasqueda.",yh:"Telas a Usar:",zh:"\u00bfCu\u00e1ntas telas usar?",fa:"Full Ingresa el Nombre del Objeto",Wb:"Ingresa el Nivel del Objeto",
Bh:"Calidad del Objeto",Ah:"Nombre del Objeto Aqu\u00ed",Ch:"Comenzar B\u00fasqueda",Dh:"Saltar y Continuar",Eh:"Detener B\u00fasqueda",Ze:"\u00bfComprar lo m\u00e1s barato o lo m\u00e1s caro?",Dg:"M\u00e1s Caros",de:"M\u00e1s Baratos",Da:"Selecciona una Opci\u00f3n",se:"Pod\u015bwietl przedmioty z Podziemia",$e:"\u00bfCentrarse en la b\u00fasqueda",dm:"\u00bfUsar Ruby si no hay tela",Ya:"Evita atacar a las mismas personas para no ser reportado. Ser reportado aumenta las posibilidades de ser baneado.",
Tl:"\u00bfDerretir verde?",Vg:"\u00bfNo aceptar misiones aleatorias si se han introducido filtros?",Rc:"Calidad m\u00e1xima del material a utilizar",$i:"Habilitar la b\u00fasqueda de mercenarios",Al:"Haz clic en `Vender Todo Seleccionado` para vender todos los elementos. Aseg\u00farate de tener espacio vac\u00edo de 2x3 en tu primera (1) bolsa. Para recoger oro en masa, filtra el oro y usa `Seleccionar Seleccionados o Seleccionar Todo`.",dk:"\ud83d\udd25 : A\u00f1ade elemento a la lista de fundici\u00f3n.",
Ni:"\ud83d\udd28 : A\u00f1ade elemento a la lista de subastas.",Jj:"Actualiza la tienda con tela cuando est\u00e9 llena",Il:"P\u00e1gina:",Fj:"Detener",Dj:"Vender Esta P\u00e1gina",Aj:"Seleccionar Seleccionados",zj:"Seleccionar Todo",Gj:"Configuraci\u00f3n de Empaquetado Autom\u00e1tico",Ej:"Enviar Recursos",Bj:"Vender Todo Seleccionado",na:"Tipo de Objeto",pa:"Armas",U:"Escudos",O:"Armaduras",S:"Cascos",R:"Guantes",P:"Botas",oa:"Anillos",la:"Amuletos",Ka:"Utilizables (Comida)",Pa:"Mejoras",yj:"Potenciadores",
Ma:"Recetas",La:"Mercenarios",Oa:"Herramientas de Forja",Na:"Pergaminos",sd:"Refuerzos",qd:"Objetos de Evento",rd:"Materiales de Forja",Hl:"Oro",Ja:"Todo",Jl:"Calidad",qa:"Blanco",C:"Verde",B:"Azul",D:"Morado",J:"Naranja",T:"Rojo",Cj:"Opciones de Venta",Rj:"\u00bfIgnorar Combinaci\u00f3n de Prefijo/Sufijo?",gj:"\u00bfCu\u00e1nta comida comprar/recoger?",Vi:"Normal",Ui:"Intermedio",Ti:"Dif\u00edcil",Ga:"Est\u00e1ndar",Nl:"Reparar Correcci\u00f3n de Atascos",Pk:"Desactiva la entrada al Infierno si deseas desactivar la Mazmorra/Circo/Arena. Si entraste al Infierno manualmente, deber\u00e1s activar el Modo Infierno.",
ee:"Wybierz kostium z Za\u015bwiat\u00f3w",Ji:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",oi:"Indica cu\u00e1ntas veces deseas entrenar las estad\u00edsticas y establece sus prioridades. El bot no entrenar\u00e1 a menos que se establezca una prioridad. Si hay una prioridad configurada pero no quedan m\u00e1s estad\u00edsticas por entrenar, el bot continuar\u00e1 con la estad\u00edstica seleccionada.",nl:"Quest",Dd:"Fundir",Yl:"Configuraci\u00f3n de Fundici\u00f3n",ak:"Objetos Fundidos",
Zl:"Agrega Prefijos o Sufijos, una vez que los encuentre en los paquetes, se fundir\u00e1n autom\u00e1ticamente:",Xl:"Objeto en Fundici\u00f3n:",ic:"Haz clic en el objeto que deseas reparar. Este sistema reparar\u00e1 a tus dos personajes, el principal y el primer personaje de circo. Debes tener al menos 10000 de oro para que comience la reparaci\u00f3n. Si se queda atascado en un objeto, significa que no tienes material para arreglarlo. Tambi\u00e9n trata de hacer espacio en tu inventario. El bot iniciar\u00e1 la reparaci\u00f3n una vez que el objeto tenga un %0 de durabilidad.",
gl:"Aplicar solo a Mercenarios",jl:"La subasta solo pujar\u00e1 cuando el mercado est\u00e9 cerca del final.",il:"Aseg\u00farate de que la SEGUNDA PESTA\u00d1A DEL INVENTARIO est\u00e9 vac\u00eda y tenga 10K de oro. El bot encontrar\u00e1 y colocar\u00e1 el objeto en la segunda pesta\u00f1a y luego, la pr\u00f3xima vez que se actualice la p\u00e1gina, fundir\u00e1 el objeto. La fundici\u00f3n se revisar\u00e1 cada 5-10 minutos.",jj:"Curar & Buffs",Ol:"No hay suficiente oro para fundir. Oro requerido:",
Rl:"Saltando puja: El miembro del gremio ya ha pujado por el objeto ",Ql:"Saltando puja: Ya has pujado por el objeto ",advanced:"Avanzado",arena:"Arena",ja:"Auto Ataque",fc:"Evitar Ataque",ha:"Agregar Jugador",ia:"Agregar Nombre de Jugador (Same Server)",vl:"\u00bfDetener el bot si se queda sin comida?",circusTurma:"Circo Turma",Wi:"Dificultad",dungeon:"Mazmorra",Xi:"Configuraci\u00f3n de Mazmorra",eventExpedition:"Expedici\u00f3n de Evento",expedition:"Expedici\u00f3n",aj:"Configuraci\u00f3n de Expedici\u00f3n",
Lj:"Seleccionar Monstruo",xl:"M\u00e1s Alto",wl:"Coloca tus objetos de curaci\u00f3n en la primera p\u00e1gina de tu inventario",nj:"En",Lh:"Almacenar Oro",Mh:"\u00bfAlmacenar Oro en Subasta?",rh:"\u00bfUsar Ropa de Trabajo para renovar la Tienda?",Zk:"Seleccionar Objetos para Reiniciar",kh:"Reiniciar Objetos Expirados",Qb:"Nota: Al habilitar esta opci\u00f3n, el bot vender\u00e1 los objetos pr\u00f3ximos a expirar de los Paquetes al Mercado del Gremio y luego los cancelar\u00e1 para reiniciar el tiempo de vencimiento. Se requiere el Gremio. Aseg\u00farate de tener un espacio vac\u00edo de 3x3 en tus bolsas.",
Qg:"Pausar el bot aleatoriamente para funcionar como [Fase de Pruebas]:",aa:"Mantener Oro: El bot mantendr\u00e1 este oro en la bolsa:",pg:"Oro M\u00e1ximo: El bot gastar\u00e1 cuando el oro sea mayor que",ph:"El bot pujar\u00e1 por art\u00edculos aleatorios",Gd:"Agregar Retraso Aleatorio",Hd:"Puedes agregar un retraso al bot aqu\u00ed.",Pb:"Reparar",Sl:"\u00bfFundir solo Azules?",Vl:"\u00bfFundir solo P\u00farpuras?",Ul:"\u00bfFundir solo Naranjas?",bk:"\u00bfFundir Todo en la 2da pesta\u00f1a?",
Wl:"Esto ignorar\u00e1 las selecciones de colores",Za:"Limpiar Historial",Gh:"Fundir",Pd:"Search",Fg:"Subasta Autom\u00e1tica",Qd:"El uso excesivo de la Subasta podr\u00eda resultar en una prohibici\u00f3n. Se recomienda desactivar otras funciones de oferta para evitar posibles conflictos. Esta caracter\u00edstica ralentizar\u00e1 el bot.",qh:"Buscar en la Subasta de Gladiadores",th:"Buscar en la Subasta de Mercenarios",Yd:"\u00bfPujar por Comida?",qg:"Puja M\u00e1xima",Zd:"Pujar si el estado es menor que",
$d:"Objetos Pujados",Dk:"Idioma de Subasta",Ek:"Seg\u00fan la actualizaci\u00f3n 2.9.4, establece el idioma nuevamente o REINICIA EL BOT. Aseg\u00farate de que todos sean correctos, de lo contrario, no pujar\u00e1.",Kd:"Puedes agregar objetos para buscar en el mercado y en la subasta. Tambi\u00e9n mostrar\u00e1 objetos p\u00farpuras en el mercado una vez que agregues un objeto a la lista. Si deseas habilitar la puja autom\u00e1tica, usa las opciones a continuaci\u00f3n",Bk:"\u00a1Usa la subasta con precauci\u00f3n!",
Ck:"La puja autom\u00e1tica realiza demasiadas solicitudes al servidor y puede causar una prohibici\u00f3n si se usa todo el tiempo.",hh:"\u00bfRenovar Puntos de Evento con Rub\u00edes?",ue:"\u00bfHabilitar Aceite Autom\u00e1tico?",Gk:"\u00bfObtener Aceites Sagrados Autom\u00e1ticamente?",Vk:"Velocidad de Verificaci\u00f3n de Misiones",Ua:"\u00bfAtacar a Miembros del Gremio?",Sa:'Agregar autom\u00e1ticamente a las personas a la lista de "Ataque" cuando se roban m\u00e1s de X ORO.:',Ta:'Agregar autom\u00e1ticamente a las personas a la lista de "Evitar Ataque" cuando pierdas contra ellas.:',
Tb:"Ataques en el Marcador",ac:"Muy Largo",Cb:"Largo",Kb:"Medio",Yb:"Corto",bc:"Muy Corto",ve:"Entrar al Inframundo si HP >",bh:"Velocidad de Verificaci\u00f3n de Misiones",Ug:'El valor predeterminado es "3x". Si el bot causa problemas con las misiones, cambia la velocidad de las misiones seg\u00fan la velocidad de tu servidor.',cf:"Selecci\u00f3n de Bolsa de Curaci\u00f3n",xe:'Si est\u00e1s renovando puntos manualmente, debes hacer clic en el bot\u00f3n de arriba "Actualizar expedici\u00f3n de evento si est\u00e1 atascada".',
Kk:"Debes habilitar al menos una de las siguientes opciones: expedici\u00f3n, mazmorra, arena o circo para comenzar la Expedici\u00f3n de Evento.",eh:"\u00a1Actualiza la Expedici\u00f3n de Evento si est\u00e1 atascada!",mb:"\u00bfCubrir a los Aliados?",bl:"Deja todas las configuraciones desactivadas si deseas fundir usando paquetes que contienen los elementos de la lista. Sin embargo, a\u00fan puedes elegir colores.",Hk:"Personaje(Desactivado) / Mercenario(Activado)",Yk:"\u00bfReparar Ambos?",cl:"Temporizadores",
Timers:"Ingresa el n\u00famero de minutos para cada temporizador a continuaci\u00f3n o d\u00e9jalo en su valor predeterminado.",Zg:"Ignorar Filtro de Misiones",Yg:"Ingresa palabras clave para filtrar las misiones que no deseas tomar. You can also use this to accept quests by their reward using keywords.",X:"Ingresar Palabra Clave",K:"Agregar",gh:"Eliminar",fe:"Limpiar",Wg:"Aceptar Filtro de Misiones",Xg:"Ingresa palabras clave para seleccionar qu\u00e9 misiones tomar. Usar esto ignorar\u00e1 los tipos de misiones",
Ea:"\u00bfSaltar Misiones Temporales?",Wk:"Misiones",Sd:"Auto Traje",Di:"\u00bfUsar Traje?",Xd:"Batalla B\u00e1sica",oe:"Batalla en Mazmorra",Td:"Bot solo usar\u00e1 Dis Pater Normal y Medium si tus puntos de expedici\u00f3n/mazmorra son 0.",ef:"Configuraci\u00f3n de Sanaci\u00f3n Infernal",Jd:"\u00bfAtacar al Jefe cuando est\u00e9 disponible?",sb:"La opci\u00f3n de ataque a la Liga se desactivar\u00e1 despu\u00e9s de 5 intentos fallidos.",hf:"Aceites Sagrados",Ag:"Nombre del Objeto",ba:"Nivel M\u00ednimo del Objeto",
Ba:"Calidad M\u00ednima del Objeto",Id:"Aplicar/Restablecer Temporizador",lf:"Ignorar Combinaci\u00f3n de Prefijo/Sufijo",Ki:"S\u00ed",Hg:"No",Qa:"Agregar Prefijo",Ra:"Agregar Sufijo",Hh:"Lista de Objetos a Ignorar al Fundir",Mb:"Prefijo",Zb:"Sufijo",mh:"Restablecer Objetos Expirados",Ih:"\u00bfFundir al Azar desde los Paquetes?",Jh:"Pesta\u00f1a de Fundici\u00f3n",qb:"Extras",Nd:"Subasta",ig:"Mercado",$b:"Temporizadores",hi:"Fundici\u00f3n",gi:"Fundici\u00f3n si no hay suficiente oro",di:"Fundir si no hay objeto",
Fa:"Reparaci\u00f3n",Wh:"Mantener Oro en el Mercado de Gremio",Sh:"Mantener Oro en la Subasta",ki:"Entrenamiento",Zh:"Restablecer Expirados",ii:"Almacenar en la Forja",Qh:"Comprobar Subasta",ai:"Buscar",v:"Habilitar",Cg:"Oro M\u00ednimo",Ub:"Seleccionar Hora",nb:"Donar Oro al Gremio",je:"Donar\u00e1 cada 5 minutos. Puedes cambiar el intervalo desde la pesta\u00f1a de temporizadores",jf:"\u00bfCu\u00e1nto deseas donar?",ke:"Donar cuando tengas m\u00e1s de >",wf:"Menos de <",jh:"Restablecer Objetos Expirados y Otras Configuraciones",
lh:"Restablecer en:",Qk:"Mant\u00e9n presionada la tecla Ctrl (Cmd en Mac) para seleccionar varios objetos",mf:"Importar/Exportar Configuraciones",Ue:"Exportar Configuraciones",nf:"Importar Configuraciones",tg:"Mensaje a Todos los Jugadores",ug:"[Requiere Clave Ultra Premium, mensaje en Discord para obtenerla.]",vg:"Ingresar mensaje para enviar",he:"Para scripts personalizados, cont\u00e1ctanos en Discord",xg:"Enviar",yg:"Mostrar Jugadores",wg:"Seleccionar Todos",zg:"Deseleccionar Todos",vf:"Aseg\u00farate de que tu inventario tenga suficiente espacio. El tiempo de reutilizaci\u00f3n es de 2 minutos.",
pb:"Habilitar Ataque en el Marcador:",Rb:"Seleccionar Rango para Atacar",Sb:"El bot atacar\u00e1 aleatoriamente desde la lista del marcador.",rb:"Ataque de Liga",ob:"Habilitar Ataque de Liga:",Nb:"Ataque Aleatorio",Ob:"Atacar desde el m\u00e1s bajo al m\u00e1s alto",Ak:"El bot evitar\u00e1 atacar a los miembros del gremio por defecto.",Se:"Ubicaci\u00f3n de Expedici\u00f3n:",Rd:"\u00bfRecoger Bonos Autom\u00e1ticamente?",Fh:"\u00bfSaltar al Jefe?",pe:"Ubicaci\u00f3n de Mazmorra:",nh:"\u00bfReiniciar si pierdes?",
ff:"Configuraci\u00f3n de Inframundo",gf:"Configura tus ajustes de porcentaje de curaci\u00f3n desde la pesta\u00f1a de curaci\u00f3n y aseg\u00farate de que est\u00e9 activada. Si ingresar al inframundo te desconecta, ve al lobby y activa la casilla de inicio de sesi\u00f3n autom\u00e1tico.",df:"Dificultad del Inframundo",Ud:"Entrar Autom\u00e1ticamente al Inframundo: / Inframundo Mode",Ei:"\u00bfUsar Movilizaci\u00f3n si los puntos = 0",Ii:"\u00bfUsar Rub\u00edes?",ye:"\u00bfSalir del inframundo si no hay puntos?",
ri:"El bot intentar\u00e1 usar villa medici primero, si no la tienes, usar\u00e1 poci\u00f3n de curaci\u00f3n. No olvides activar el interruptor de Curar.",zi:"El ingreso autom\u00e1tico al inframundo deshabilitar\u00e1 la mazmorra/arena/circo al ingresar al inframundo.",dl:"Ajustes de Curaci\u00f3n del Inframundo",Hi:"\u00bfUsar Villa Medici?",Fi:"\u00bfUsar Poci\u00f3n de Curaci\u00f3n?",dg:"INFO: El bot buscar\u00e1 objetos en el mercado cada ciertos minutos, lo que puede detener los ataques durante la b\u00fasqueda.",
te:"Habilitar B\u00fasqueda en el Mercado:",eg:"Intervalo de B\u00fasqueda en el Mercado en Minutos:",fg:"Se sugieren 10 minutos.",rf:"Ajustes de Objetos:",pf:"Nombre del Objeto Incluye",G:"Precio M\u00e1ximo",sf:"Tipo de Objeto",qf:"Rareza del Objeto",ce:"\u00bfComprar con V\u00ednculo Espiritual?",uf:"Objetos para Comprar",tf:"Intentar comprar objetos con paquetes si alguno coincide con el precio m\u00e1ximo ingresado:",ae:"Objetos Comprados:",hj:"Porcentaje de Curaci\u00f3n",wk:"\u00bfComprar Comida en la Tienda?",
xk:"\u00bfUsar Curaci\u00f3n de Paquete?",tk:"\u00bfUsar Cervisia?",vk:"\u00bfUsar Huevos?",Bl:"\u00daltima Vez Usado",location:"Ubicaci\u00f3n",Strength:"Fuerza",Dexterity:"Destreza",Agility:"Agilidad",Constitution:"Constituci\u00f3n",Charisma:"Carisma",Intelligence:"Inteligencia",mi:"Ajustes de Entrenamiento",ni:"Selecciona los atributos que deseas entrenar. Se entrenar\u00e1 una vez que tengas suficiente oro.",N:"Siguiente acci\u00f3n",vj:"No",wj:"Normal",Fl:"Oponente",Gl:"Nivel del Oponente",
Ij:"Misiones",random:"Aleatorio",Pl:"Ajustes",$l:"Pronto...",type:"Haz clic en los \u00edconos para activar los tipos de misiones.",fm:"S\u00ed",A:"Subasta/B\u00fasqueda",Cd:"Agregar objetos",qk:"Almacenar Recursos Forjados autom\u00e1ticamente",am:"Enviar",zl:"Intervalo : ",ol:"Habilitar Puja Autom\u00e1tica",pl:"No pujar si el miembro del gremio ya ha pujado",cm:"Tutorial",hc:"Selecciona entre los botones de arriba si deseas enfrentar al oponente de nivel m\u00e1s bajo en la arena o al oponente de nivel m\u00e1s alto. M\u00e1s usuarios ralentizar\u00e1n el bot.",
hl:"Para empezar, agrega un objeto a la lista (p. ej., `Lucius`). Una vez agregado, la herramienta buscar\u00e1 el objeto y mostrar\u00e1 los resultados de la b\u00fasqueda en el lado izquierdo de la pantalla. Tambi\u00e9n se buscar\u00e1 para fines de subasta autom\u00e1tica. Si habilitas la puja autom\u00e1tica, la herramienta buscar\u00e1 el objeto a intervalos regulares seg\u00fan el n\u00famero que ingreses en el cuadro de intervalo. Si la herramienta encuentra el objeto y tienes suficiente dinero, pujar\u00e1 autom\u00e1ticamente por ti. *Nota* para buscar objetos \u00fanicos en las tiendas, debes agregar al menos 1 objeto aleatorio en la lista de b\u00fasqueda.",
rl:"El n\u00famero de criatura se puede seleccionar desde los botones de arriba. El n\u00famero 1 representa la criatura m\u00e1s a la izquierda. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",Yi:"Selecciona la dificultad de la mazmorra de arriba. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",ij:"Ajustes de Curaci\u00f3n",Zi:"Almacena el oro excedente en el Gremio comprando objetos del mercado del gremio. -> M\u00edn. Oro",
Cl:"Mover Todo",Dl:"Mover Seleccionados",kl:"Curaci\u00f3n Autom\u00e1tica",ll:"Porcentaje de Curaci\u00f3n Autom\u00e1tica",em:"Ruby",Lg:"Ajustes Generales",Mj:"Vender Todo",Nj:"Vender Seleccionados",ga:"Armas",da:"Escudos",W:"Armadura de Pecho",Z:"Cascos",Y:"Guantes",ea:"Zapatos",ca:"Anillos",V:"Amuletos",Ci:"Usables",Bi:"Mejoras",dh:"Recetas",sg:"Pergamino de Mercenario",fh:"Refuerzos",mg:"Vender Comida",Gb:"Cambiar a Comida"},Qh={we:"Changer automatiquement de monstre",cg:"Erreur de march\u00e9, Veuillez ajouter \u00e0 nouveau les \u00e9l\u00e9ments et r\u00e9essayer.",
Lb:"Pas assez d`espace dans l`inventaire pour les objets \u00e0 vendre.",ck:"Faire fondre d\u2019abord les couleurs plus \u00e9lev\u00e9es ?",cc:"Attaquer uniquement la liste de joueurs ?",dc:"Lorsque cette option est activ\u00e9e, le bot n\u2019attaquera que les joueurs figurant sur la liste des joueurs. Si cette option n\u2019est pas activ\u00e9e, le bot attaquera des joueurs al\u00e9atoires.",Mk:"Vos param\u00e8tres d'exp\u00e9dition sont incorrects ou il y a des donn\u00e9es de page inattendues !",
Nk:"Votre param\u00e8tre d'exp\u00e9dition est incorrect ! Vous avez s\u00e9lectionn\u00e9 un monstre d\u00e9sactiv\u00e9, ce qui est incorrect.",$k:"R\u00e9initialiser uniquement tous les \u00e9l\u00e9ments du monde souterrain avec la couleur s\u00e9lectionn\u00e9e?",Ca:"Priorit\u00e9",Vb:"D\u00e9finir la priorit\u00e9",Rg:"Points",Kh:"Stat",Si:"Collecter de l`or",Oj:"Vendre des objets des Enfers?",uj:"Le bot cherchera le nid dans chaque action, pas seulement lors des exp\u00e9ditions.",sj:"Type de recherche de nid",
qj:"Ne rien faire",rj:"Recherche rapide",tj:"Recherche approfondie",Ml:"After expedition points are consumed, travel to Germania to consume Dungeon points",zk:"Cliquez ici si la r\u00e9paration se bloque",Ok:"Quand les PV sont en dessous, utilisez soin",Ng:"R\u00e9paration Partielle",af:"R\u00e9paration Compl\u00e8te",Mg:"R\u00e9paration Partielle ou Compl\u00e8te",re:"Activer la Limite",kj:"Limite",lj:"Si vous voulez limiter le nombre de fois que vous souhaitez attaquer l'ennemi, activez cette option et d\u00e9finissez la limite. Le bot continuera \u00e0 attaquer le reste des ennemis apr\u00e8s avoir fini d'attaquer le monstre s\u00e9lectionn\u00e9.",
yi:"Monde Souterrain",pi:"Am\u00e9liorations du Monde Souterrain",si:"Utiliser les pouvoirs des dieux apr\u00e8s \u00eatre entr\u00e9 dans le monde souterrain?",ti:"S\u00e9lectionnez les dieux pour utiliser leurs pouvoirs:",ui:"Utiliser un Buff d'Arme sur l'arme?",vi:"Utiliser un Buff d'Armure sur l'\u00e9quipement suivant:",Jk:"Le temps de recharge est de 30 minutes. Si vous n'avez pas de costume, le bot r\u00e9initialisera le temps de recharge \u00e0 0.",al:"S\u00e9lectionner les Couleurs",$a:"Forge de Vulcain",
eb:"Bouclier de Terre de Feronia",fb:"Puissance Fluide de Neptune",gb:"Libert\u00e9 A\u00e9rienne d'Aelous",hb:"Brouillard Mortel de Pluton",ib:"Souffle de Vie de Junon",jb:"Armure d'\u00c9cailles des Montagnes de Col\u00e8re",kb:"Yeux d'Aigle",lb:"V\u00eatement d'Hiver de Saturne",ab:"Armure de Taureau de Bubona",bb:"V\u00eatements de Voleur de Mercure",cb:"Robe de Lumi\u00e8re de R\u00e2",me:"N`entrez pas dans le monde souterrain avec le costume des enfers",le:"Si vous ne voulez pas entrer dans le monde souterrain en portant le costume des enfers, activez cette option",
lg:"Paquets",gg:"Inventaire",M:"Prix Min.",L:"Combien",Fb:"Vendre des Articles",Eb:"Rechercher dans",hg:"Couleur du Mat\u00e9riau",Db:"Couleur de l`Article",og:"Entrep\u00f4t",Aa:"Basculer vers Mat\u00e9riaux",Hb:"Basculer vers Articles",ng:"Vendre des Mat\u00e9riaux",xa:"Veuillez entrer un nom d`article valide, une fourchette de prix et une quantit\u00e9.",ya:"Aucun article correspondant trouv\u00e9 dans les emplacements de recherche s\u00e9lectionn\u00e9s.",za:"Tous les articles ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",
Uk:"Tous les mat\u00e9riaux ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",jg:"Si vous souhaitez vendre des articles \u00e0 un prix fixe, vous pouvez entrer la m\u00eame valeur pour le prix minimum et maximum.",kg:"Cette fonctionnalit\u00e9 est encore exp\u00e9rimentale, utilisez-la avec prudence. Si vous ne fixez pas un prix, les articles seront list\u00e9s al\u00e9atoirement entre le prix minimum et maximum que vous entrez.",Fk:"D\u00e9finit le maximum d`or que le bot d\u00e9pensera par cycle.",
Va:"Le bot commencera \u00e0 faire des offres sur tout article de nourriture, si activ\u00e9. Vous n`avez pas besoin d`activer les bascules gladiateur/mercenaire.",Ld:"Le bot ne fera pas d`offres sur les ench\u00e8res des alli\u00e9s.",Md:"Ignorer la combinaison Pr\u00e9fixe/Suffixe lors de la recherche d`un objet \u00e0 la vente aux ench\u00e8res.",Vj:"S\u00e9lectionnez les types d\u2019objets que vous souhaitez fondre.",Wj:"S\u00e9lectionnez les couleurs que vous souhaitez fondre.",Xj:"S\u00e9lectionnez le niveau des objets que vous souhaitez fondre.",
Yj:"S\u00e9lectionnez le marteau que vous voulez utiliser.",Zj:"Notez que le cercle vert et rouge \u00e0 c\u00f4t\u00e9 de la premi\u00e8re case sert \u00e0 activer/d\u00e9sactiver la r\u00e8gle.",$j:"Si vous voulez fondre al\u00e9atoirement n\u2019importe quelle couleur ou type, vous pouvez activer `Fondre al\u00e9atoirement si aucune condition n\u2019est remplie? (Derni\u00e8re option activ\u00e9e dans la vid\u00e9o du tutoriel)",Kj:"R\u00e9parer avant de fondre",Oe:"S\u00e9lectionner Monstre",
Ce:"Utiliser Sablier/Rubis?",Lk:"Utiliser Rubis?",Fe:"Utiliser Mobilisation?",Ee:"Utiliser Potion de Vie?",Be:"Pourcentage de Soin (%)",Me:"Nombre d'Attaques",De:"Intervalle d'Attaque (en secondes)",ze:"Attaques Effectu\u00e9es",Ae:"Sabliers Restants",Ke:"Note : Utilise des potions de vie pour gu\u00e9rir, pas de nourriture.",Le:"Note : Si les attaques s'arr\u00eatent pr\u00e9matur\u00e9ment, essayez 'R\u00e9initialiser les Attaques'.",Pe:"D\u00e9marrer",Ne:"R\u00e9initialiser",Qe:"Arr\u00eater",
Re:"Param\u00e8tres d'Exp\u00e9dition (Cliquez pour minimiser)",Ge:"Monstre 1",He:"Monstre 2",Ie:"Monstre 3",Je:"Monstre 4",Xk:"R\u00e9parer avant de fondre",Qi:"Cette option utilisera cervisia lorsque votre premium expirera.",xj:"Cette option permet d'activer et de choisir les huiles parmi les r\u00e9compenses des dieux. Elle peut utiliser les huiles num\u00e9ro 1 et 3 sur le personnage, mais la num\u00e9ro 2 ne sera prise que pour les paquets.",Oi:"Cette option utilisera des buffs au moment que vous avez fix\u00e9. Elle trouvera les buffs dans les paquets et les appliquera au personnage.",
mj:"Cette option vous m\u00e8nera aux enfers. N'oubliez pas d'activer la Connexion Automatique depuis l'onglet Extras, sinon vous pourriez \u00eatre d\u00e9connect\u00e9 en entrant aux enfers [Bug du Jeu]",ec:"Cette option n'attaquera que la liste ar\u00e8ne/cirque. Si ce n'est pas possible, le bot sautera.",Hj:"Cette option est uniquement pour les licences premium. Elle simule l'attaque avant d'attaquer un utilisateur pour un taux de victoire de 75%.",Od:"Vous n'avez pas besoin d'activer l'interrupteur principal de l'ench\u00e8re pour activer cette option.",
sk:"Cette option rafra\u00eechira la page chaque seconde quand l'ench\u00e8re est en \u00e9tat -Tr\u00e8s Court- pour ench\u00e9rir constamment et gagner l'ench\u00e8re.",Tj:"Si aucune des conditions de fusion n'est remplie, il fusionnera al\u00e9atoirement. Assurez-vous de s\u00e9lectionner le type et la couleur de l'objet.",Uj:"Cette option ne fusionnera que les objets de l'inventaire. Elle ignorera les objets dans les paquets.",Wa:"Articles aux Ench\u00e8res",rg:"Articles de Mercenaire",Xb:"Articles de Boutique",
Ai:"Articles Uniques",Pj:"D\u00e9finir le fond en noir [Augmente les performances]",Qj:"D\u00e9placer les boutons GLDbot en bas \u00e0 gauche?",Ri:"Attaquer le cirque sans soigner",rk:"Prendre l'or des paquets si n\u00e9cessaire?",bm:"L'or a \u00e9t\u00e9 pris des paquets pour l'entra\u00eenement",Fd:"Aucun or n'a \u00e9t\u00e9 trouv\u00e9 dans les paquets pour l'entra\u00eenement",lk:"Objets R\u00e9par\u00e9s",ek:"Attaques en Ar\u00e8ne",gk:"Attaques au Cirque",mk:"Objets R\u00e9initialis\u00e9s",
jk:"Attaques en Exp\u00e9dition",ik:"Attaques en Donjon",pk:"Attaques dans l'Underworld",fk:"Argent Gagn\u00e9 en Ar\u00e8ne",hk:"Argent Gagn\u00e9 au Cirque",nk:"Objets Fondus",kk:"Or Recycl\u00e9",dj:"Bataille de Guilde",fj:"Param\u00e8tres de Guilde",ej:"Guild Name",tl:"Attaquera les guildes au hasard.",Pi:"R\u00e9initialiser les Statistiques",Lh:"Stockage de l'Or",cj:"Attaquer une Guilde Al\u00e9atoire",El:"GLDbot\u00a0: utilisez les d\u00e9s pour rafra\u00eechir la bo\u00eete myst\u00e8re et trouver des objets de valeur avant de les ouvrir (etc. Costumes). Cliquez sur \u00ab\u00a0D\u00e9marrer\u00a0\u00bb pour ouvrir les coffres.\u00a0",
Pc:"Bois",Fc:"Cuivre",Jc:"Fer",Lc:"Cuir",Qc:"Fil de laine",Gc:"Boule de coton",Ic:"Chanvre",Hc:"Bande de gaze",Mc:"Toile de lin",Kc:"Jute",Oc:"Bande de velours",Nc:"Fil de soie",Yc:"Fourrure",Sc:"\u00c9clat osseux",ad:"\u00c9caille",Vc:"Griffe",Xc:"Canine",Wc:"\u00c9caille de dragon",Tc:"Corne de taureau",$c:"Glande \u00e0 venin",Uc:"Touffe de poils de Cerb\u00e8re",Zc:"\u00c9caille d`Hydre",bd:"Plume du Sphinx",cd:"Cuir de Typhon",Cc:"Lapis-lazuli",wc:"Am\u00e9thyste",vc:"Ambre jaune",xc:"Aigue-marine",
Dc:"Safir",Ac:"Grenat",zc:"\u00c9meraude",yc:"Diamant",Bc:"Jaspe",Ec:"Sugilith",qc:"Venin de scorpion",tc:"Teinture d`endurance",mc:"Antidote",lc:"Adr\u00e9naline",sc:"Teinture de r\u00e9v\u00e9lation",pc:"Potion de perception",nc:"Essence de reflet",oc:"Flacon du rayonnement",uc:"Eau de l`oubli",rc:"Essence d`\u00e2me",Bd:"Sceau aquatique",vd:"Rune protectrice",td:"Gravure terrestre",Ad:"Totem gu\u00e9risseur",zd:"Talism\u00e1n de puissance",xd:"Pierre de fortune",ud:"Pierre du feu",yd:"Rune temp\u00e9tueuse",
wd:"Rune t\u00e9n\u00e9breuse",gd:"Cristal",fd:"Bronze",ld:"Obsidienne",od:"Argent",pd:"Soufre",jd:"Minerai d`or",nd:"Quartz",md:"Platine",ed:"Almandin",hd:"Cuprit",kd:"Pierre infernale",Li:"Attaquer al\u00e9atoirement?",Mi:'D\u00e9sactivez \u00e9galement le param\u00e8tre "Trier les joueurs dans l\'ar\u00e8ne par niveau" dans crazy-addon.',$g:"Accepter uniquement les qu\u00eates bas\u00e9es sur le type de dieu.",Xa:"Buff Automatique",be:"Utiliser uniquement en enfer?",Gg:"Nouvelle R\u00e8gle",Eg:"Le Nom Contient",
isUnderworldItem:"Est-ce un objet du monde souterrain?",kf:"Ignorer les Mat\u00e9riaux",yk:"Utiliser la pri\u00e8re",Gi:"Utiliser le sacrifice",uk:"Utiliser des v\u00eatements pour entrer dans le monde souterrain",xi:"Lorsque vous \u00eates dans le monde souterrain, n`acceptez que les qu\u00eates li\u00e9es au monde souterrain ?",wi:"Si activ\u00e9, vous devez entrer les noms des objets du monde souterrain. Si le bot trouve ces objets dans le monde souterrain, il acceptera la qu\u00eate.",el:"Objet de Qu\u00eate du Monde Souterrain",
ql:"Entrez le nom du mat\u00e9riau",Ik:"Le robot adore les d\u00e9s ! Ils l'aident \u00e0 trouver des v\u00eatements dans les coffres. Mais s'il n'y a pas de d\u00e9s, le robot ouvre quand m\u00eame les coffres, en esp\u00e9rant trouver des v\u00eatements cool (mais il pourrait ne rien trouver !)",Sj:"Fondre les coffres",qe:"Activer l'ar\u00e8ne",Sg:"Prioriser la liste des ar\u00e8nes ?",Tg:"Prioriser la liste des cirques ?",ie:"D\u00e9sactiver le menu de journalisation",oh:"Valeur minimale de r\u00e9compense en or",
ph:"Le robot ench\u00e9rira sur des articles al\u00e9atoires.",ah:"Si activ\u00e9, le Focus sur les qu\u00eates suivra le chemin le plus court pour terminer le donjon.",Nh:"Lancer les d\u00e9s automatiquement ?",Oh:"Utilisez le lancer de d\u00e9s avec prudence, il continuera \u00e0 utiliser le premier d\u00e9 jusqu'\u00e0 ce que vous d\u00e9sactiviez l'option.",uh:"Progression de la recherche",ih:"Le temps de recharge pour la r\u00e9paration par d\u00e9faut est de 10 minutes.",Bg:"Condition minimale",
ge:"Article actuel sur l'\u00e9tabli [Effacer si le bot se met en pause de mani\u00e8re inattendue]",Gf:"Ressources de forge stock\u00e9es avec succ\u00e8s dans l'horreum.",Cf:"V\u00e9rification du march\u00e9 pour les articles...",Ab:"Article d\u00e9plac\u00e9 sur l'\u00e9tabli.",Tf:"Article r\u00e9par\u00e9 et \u00e9quip\u00e9 avec succ\u00e8s.",Uf:"Article r\u00e9par\u00e9 avec succ\u00e8s.",Sk:"La r\u00e9paration a \u00e9chou\u00e9. La page sera rafra\u00eechie.",Qf:"Ramassage des mat\u00e9riaux...",
bg:"En attente de r\u00e9paration...",Sf:"La r\u00e9paration a commenc\u00e9 pour .",wa:"R\u00e9paration : D\u00e9placement de l'article de l'inventaire vers le sac",Rf:"R\u00e9paration : D\u00e9placement de l'article de l'\u00e9tabli vers le paquet.",ua:"Impossible de trouver suffisamment de mat\u00e9riaux. D\u00e9sactivation de l'emplacement de r\u00e9paration ",Nf:"Recherche d'articles \u00e0 acheter pour cacher de l'or aux ench\u00e8res...",zf:"V\u00e9rification des articles expir\u00e9s dans les paquets...",
Af:"R\u00e9initialisation de l'article r\u00e9ussie.",Bf:"Aucun espace vide ou or pour r\u00e9initialiser.",Hf:"Assurez-vous d'avoir les droits de vente sur le march\u00e9 de guilde !",ub:"Pas assez d'or ou aucun article \u00e0 acheter. Attente de 30 secondes pour rafra\u00eechir.",wb:"Le magasin a \u00e9t\u00e9 rafra\u00eechi.",xb:"Erreur lors de la gu\u00e9rison.",Kf:"Pas de Rubis ou de Tissu, d\u00e9sactivation des options.",Rk:"Aucun article de gu\u00e9rison trouv\u00e9 dans les paquets.",yb:"Aucun article appropri\u00e9 trouv\u00e9",
Lf:"Les aliments ont \u00e9t\u00e9 ramass\u00e9s. Fin du processus.",Mf:"Au moins un aliment a \u00e9t\u00e9 ramass\u00e9. Fin du processus.",zb:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",If:"Obtention de la nourriture des paquets.",Jf:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",vb:"Plus d'articles de gu\u00e9rison. Attente de 30 secondes.",tb:"Points de vie r\u00e9cup\u00e9r\u00e9s.",va:"Rien \u00e0 faire alors je vais prier !",
Yf:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9 et Villa Medici.",Zf:"En attente de Villa Medici, actualisation dans 60 secondes.",$f:"Quitt\u00e9 les Enfers.",ag:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9.",Of:"V\u00e9rification des huiles divines...",Pf:"Les huiles divines ont \u00e9t\u00e9 ramass\u00e9es.",sa:"Attaque r\u00e9ussie du joueur dans l'AR\u00c8NE : ",ta:"Attaque r\u00e9ussie du joueur dans le CIRQUE : ",xf:"V\u00e9rification des ench\u00e8res ! Veuillez patienter...",
yf:"Mise aux ench\u00e8res d'articles. Veuillez patienter...",Vf:"Article fondu automatiquement : ",Wf:"Fusion de l'article : ",Bb:"Pas assez d'or pour fondre. Or requis : ",Xf:"FONDRE : Recherche d'articles \u00e0 fondre...",Tk:"Recherche d'articles \u00e0 fondre...",Df:"V\u00e9rification de la disponibilit\u00e9 des costumes...",Ff:"Donn\u00e9 : ",Ef:"Lancer des d\u00e9s...",Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",Ye:"Attention\u00a0: activez cette fonctionnalit\u00e9 apr\u00e8s avoir d\u00e9verrouill\u00e9 la cr\u00e9ature que vous souhaitez attaquer, elle n'attaquera pas automatiquement pour d\u00e9bloquer le monstre.",
Ve:"Farm Enemy",Vd:"Connexion Automatique",Wd:"Vous devez autoriser les pop-ups depuis l'\u00e9cran du lobby de GameForge. Consultez la documentation pour savoir comment faire.",Og:"Mettre le Bot en Pause",Pg:"Mettre le Bot en pause (Minutes)",Te:"Date d'Expiration",Jg:"Acheter uniquement de la nourriture ?",Kg:"Si vous activez cette option, le bot ignorera vos s\u00e9lections et ach\u00e8tera automatiquement de la nourriture sans rien saisir.",Jb:"Montant total maximal d'or \u00e0 d\u00e9penser",
Ib:"Montant maximal d'or par aliment \u00e0 d\u00e9penser",Ig:"Le bot v\u00e9rifiera les huiles toutes les 60 minutes",fi:"D\u00e9finit une minuterie pour v\u00e9rifier les temps de fusion.",ci:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion lorsque vous n'avez pas d'or.",ei:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion si vous n'avez pas l'objet disponible.",Yh:"D\u00e9finit une minuterie pour r\u00e9parer et v\u00e9rifier vos objets.",Xh:"D\u00e9finit une minuterie pour v\u00e9rifier l'or retenu sur le march\u00e9 de la guilde.",
Th:"D\u00e9finit une minuterie pour l'option de retenue d'or aux ench\u00e8res.",Ph:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans l'ar\u00e8ne pour attaquer.",Uh:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans le cirque pour attaquer.",li:"D\u00e9finit une minuterie pour entra\u00eener vos statistiques.",$h:"D\u00e9finit une minuterie pour r\u00e9initialiser les objets expir\u00e9s.",ji:"D\u00e9finit une minuterie pour stocker les mat\u00e9riaux de forge dans l'horreum.",
Rh:"D\u00e9finit une minuterie pour v\u00e9rifier les ench\u00e8res des gladiateurs et des mercenaires.",bi:"D\u00e9finit une minuterie pour rechercher des objets aux ench\u00e8res et en boutique.",Vh:"D\u00e9finit la minuterie d'envoi de dons \u00e0 la guilde.",bf:"Or D\u00e9plac\u00e9",ne:"Ne vendez pas d'articles de la fonderie et de la liste des ench\u00e8res",vh:"Automatisation de la Boutique",xh:"Param\u00e8tres de Recherche d'Objets",wh:"Utilisez cet outil pour rechercher des objets. Ajoutez simplement les objets \u00e0 la liste, sp\u00e9cifiez la quantit\u00e9 de tissu et lancez la recherche.",
yh:"Tissus \u00e0 Utiliser :",zh:"Combien de tissus utiliser ?",fa:"Full Entrez le Nom de l'Objet",Wb:"Entrez le Niveau de l'Objet",Bh:"Qualit\u00e9 de l'Objet",Ah:"Nom de l'Objet Ici",Ch:"Commencer la Recherche",Dh:"Sauter et Continuer",Eh:"Arr\u00eater la Recherche",Ze:"Acheter le moins cher ou le plus cher?",Dg:"Le Plus Cher",de:"Le Moins Cher",Da:"S\u00e9lectionnez une Option",se:"Mettre en surbrillance les objets du monde souterrain",$e:"Concentrez-vous sur la qu\u00eate\u00a0?",dm:"Utiliser Ruby s'il n'y a pas de tissu ?",
Ya:"\u00c9vitez d'attaquer les m\u00eames personnes pour ne pas \u00eatre signal\u00e9. \u00catre signal\u00e9 augmente les chances d'\u00eatre banni.",Tl:"Fondre Green ?",Vg:"Ne pas accepter les qu\u00eates al\u00e9atoires si des filtres sont entr\u00e9s ?",Rc:"Qualit\u00e9 maximale des mat\u00e9riaux \u00e0 utiliser",$i:"Activer la recherche de mercenaires",Al:"Cliquez sur `Vendre Tout S\u00e9lectionn\u00e9` pour vendre tous les objets. Assurez-vous d`avoir de l`espace vide de 2x3 dans votre premi\u00e8re (1) sac. Pour collecter de l`or en masse, filtrez l`or et utilisez `S\u00e9lectionner S\u00e9lectionn\u00e9s ou Tout S\u00e9lectionner`.",
dk:"\ud83d\udd25 : Ajoute l`objet \u00e0 la liste de fusion.",Ni:"\ud83d\udd28 : Ajoute l`objet \u00e0 la liste des ench\u00e8res.",Jj:"Actualisez la boutique avec du tissu lorsqu`elle est pleine",Il:"Page:",Fj:"Arr\u00eater",Dj:"Vendre Cette Page",Aj:"S\u00e9lectionner S\u00e9lectionn\u00e9s",zj:"Tout S\u00e9lectionner",Gj:"Param\u00e8tres d`Emballage Automatique",Ej:"Envoyer les Ressources",Bj:"Vendre Tout S\u00e9lectionn\u00e9",na:"Type d`Objet",pa:"Armes",U:"Boucliers",O:"Armures",S:"Casques",
R:"Gants",P:"Bottes",oa:"Anneaux",la:"Amulettes",Ka:"Utilisables (Nourriture)",Pa:"Am\u00e9liorations",yj:"Boosts",Ma:"Recettes",La:"Mercenaires",Oa:"Outils de Forge",Na:"Parchemins",sd:"Renforcements",qd:"Objets d`\u00c9v\u00e9nement",rd:"Mat\u00e9riaux de Forge",Hl:"Or",Ja:"Tout",Jl:"Qualit\u00e9",qa:"Blanc",C:"Vert",B:"Bleu",D:"Violet",J:"Orange",T:"Rouge",Cj:"Options de Vente",Rj:"Ignorer la Combinaison Pr\u00e9fixe/Suffixe ?",gj:"Combien de nourriture acheter/cueillir ?",Vi:"Normal",Ui:"Interm\u00e9diaire",
Ti:"Difficile",Ga:"Standard",Nl:"R\u00e9paration Correction d`Enlisement",Pk:"D\u00e9sactivez l`Entr\u00e9e en Enfer si vous souhaitez d\u00e9sactiver le Donjon/Cirque/Arenas. Si vous \u00eates entr\u00e9 en Enfer manuellement, vous devrez activer le Mode Enfer.",ee:"Choisir le costume des Enfers",Ji:"Porter le costume des Enfers quand il est disponible ?",oi:"Tutoriel dentra\u00eenement : Indiquez combien de fois vous souhaitez entra\u00eener les statistiques et d\u00e9finissez leurs priorit\u00e9s. Le bot nentra\u00eenera pas sans quune priorit\u00e9 soit d\u00e9finie. Si une priorit\u00e9 est configur\u00e9e mais quil ne reste plus de statistiques \u00e0 entra\u00eener, le bot continuera avec la statistique s\u00e9lectionn\u00e9e.",
nl:"Quest",Mh:"Conserver l'Or aux Ench\u00e8res ?",Qg:"Mettre en Pause le Bot Al\u00e9atoirement pour travailler comme [Phase de Test] :",kh:"R\u00e9initialiser les Objets Expir\u00e9s",Qb:"Remarque : En activant cette option, le bot vendra les objets expir\u00e9s \u00e0 venir des paquets sur le march\u00e9 de la guilde, puis annulera pour r\u00e9initialiser le temps d'expiration. La guilde est requise. Assurez-vous d'avoir un espace vide de 3x3 dans vos sacs.",aa:"Conserver l'Or : Le bot conservera cet or dans le sac :",
pg:"Or Maximum : Le bot d\u00e9pensera lorsque l'or sera sup\u00e9rieur \u00e0",Dd:"Fonderie",Yl:"Fonderie Param\u00e8tres",ak:"Fonderie Liste",Zl:"Ajouter un pr\u00e9fixe ou un suffixe, une fois qu`il l`aura trouv\u00e9 dans les paquets, il le fondera automatiquement:",Xl:"Fusion d'item:",ic:"Cliquez sur l`\u00e9l\u00e9ment que vous souhaitez r\u00e9parer. Essayez de faire de la place dans votre inventaire",gl:"S`applique-t-il uniquement aux mercenaires ?",jl:"L'ench\u00e8re ach\u00e8te que lorsque le march\u00e9 est proche de la fin.",
il:"Assurez-vous que le SECOND ONGLET D'INVENTAIRE est vide. Le bot trouvera et mettra l'objet dans le deuxi\u00e8me onglet puis la prochaine fois que la page est actualis\u00e9e, il fondra l'objet.",jj:"Gu\u00e9risseur & Buffs",Ol:"Pas assez d'or pour fondre. Or requis:",Rl:"Ench\u00e8re ignor\u00e9e: un membre de la guilde a d\u00e9j\u00e0 mis\u00e9 pour l'objet ",Ql:"Ench\u00e8re ignor\u00e9e: Vous avez d\u00e9j\u00e0 mis\u00e9 pour cet objet ",advanced:"Avanc\u00e9e",arena:"Ar\u00e8ne",ja:"Attaque automatique",
fc:"Eviter l'attaque",ha:"Ajouter un joueur",ia:"Entrez le nom du joueur (Same Server)",vl:"Arr\u00eater le bot en cas de manque de nourriture?",circusTurma:"Circus Turma",Wi:"Difficult\u00e9",dungeon:"Donjon",Xi:"Param\u00e8tres du donjon",eventExpedition:"Event Exp\u00e9dition",expedition:"Expedition",aj:"Param\u00e8tres d'expedition",Lj:"S\u00e9lectionner un monstre",xl:"Plus haut",wl:"Mettez vos objets de soin dans la premi\u00e8re page de votre inventaire",nj:"Dans",rh:"Utiliser les v\u00eatements de travail pour renouveler la boutique?",
hj:"Pourcentage de gu\u00e9rison",wk:"Acheter de la nourriture dans la boutique?",xk:"Utiliser la gu\u00e9rison \u00e0 partir du paquet?",tk:"Utiliser Cervisia?",vk:"Utiliser des oeufs?",Bl:"Dernier utilis\u00e9",location:"Emplacement",Strength:"Force",Dexterity:"Adresse",Agility:"Agilit\u00e9",Constitution:"Constitution",Charisma:"Charisme",Intelligence:"Intelligence",mi:"Param\u00e8tres d'entrainement",ni:"S\u00e9lectionnez les states que vous souhaitez entra\u00eener. L'entra\u00eenement commencera une fois que vous aurez assez d'or.",
N:"Action suivante",vj:"Non",wj:"Normal",Fl:"Adversaire",Gl:"Niveau de l'adversaire",Ij:"Qu\u00eates",random:"Al\u00e9atoire",Pl:"Param\u00e8tres",$l:"Bient\u00f4t...",type:"Cliquez sur les ic\u00f4nes pour activer les types de qu\u00eate.",fm:"Oui",A:"Ench\u00e8re",Cd:"Ajouter des objets",qk:"Stocker automatiquement les ressources de la forge",am:"Soumettre",zl:"Intervalle : ",ol:"Activer l'ench\u00e8re automatique",pl:"Ne pas ench\u00e9rir si un membre de la guilde a d\u00e9j\u00e0 ench\u00e9ri",
cm:"Tutoriel",hc:"S\u00e9lectionnez \u00e0 partir des boutons ci-dessus pour choisir si vous souhaitez affronter l'adversaire le plus faible de l'ar\u00e8ne ou l'adversaire de niveau le plus \u00e9lev\u00e9.",hl:"Pour commencer, ajoutez un article \u00e0 la liste (par exemple, `Lucius`). Une fois ajout\u00e9, l'outil recherchera l'article et affichera les r\u00e9sultats de la recherche sur le c\u00f4t\u00e9 gauche de l'\u00e9cran. Il sera \u00e9galement recherch\u00e9 \u00e0 des fins d'ench\u00e8re automatique. Si vous activez l'ench\u00e8re automatique, l'outil recherchera l'article \u00e0 des intervalles r\u00e9guliers en fonction du nombre que vous mettez dans la case d'intervalle. Si l'outil trouve l'article et que vous avez assez d'argent, il ench\u00e9rira automatiquement pour vous. *Note* pour rechercher des articles uniques dans les boutiques, vous devez ajouter au moins 1 article al\u00e9atoire \u00e0 la liste de recherche.",
rl:"Le num\u00e9ro de la cr\u00e9ature peut \u00eatre s\u00e9lectionn\u00e9 \u00e0 partir des boutons ci-dessus. Le num\u00e9ro 1 repr\u00e9sente la cr\u00e9ature la plus \u00e0 gauche. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",Yi:"S\u00e9lectionnez la difficult\u00e9 du donjon depuis le dessus. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",ij:"Param\u00e8tres de gu\u00e9rison",Zi:"Stocker l'or exc\u00e9dentaire dans la guilde en achetant des objets du march\u00e9 de la guilde. -> Or Min.",
Cl:"D\u00e9placer tout",Dl:"D\u00e9placer les s\u00e9lectionn\u00e9s",kl:"Auto gu\u00e9rison",ll:"Pourcentage de gu\u00e9rison automatique",em:"Ruby",Lg:"Param\u00e8tres g\u00e9n\u00e9raux",Mj:"Tout vendre",Nj:"Vendre s\u00e9lectionn\u00e9s",ga:"Armes",da:"Boucliers",W:"Armure de poitrine",Z:"Casques",Y:"Gants",ea:"Chaussures",ca:"Anneaux",V:"Amulettes",Ci:"Utilisable",Bi:"Am\u00e9liorations",dh:"Nourriture",sg:"Parchemin de mercenaire",fh:"Renforts",Gd:"Ajouter un D\u00e9lai Al\u00e9atoire",Hd:"Vous pouvez ajouter un d\u00e9lai al\u00e9atoire au bot ici.",
Pb:"R\u00e9parer",Sl:"Fonder uniquement les Bleus?",Vl:"Fonder uniquement les Violets?",Ul:"Fonder uniquement les Oranges?",bk:"Tout Fondre dans le 2e Onglet?",Wl:"Cela ignorera les s\u00e9lections de couleur",Za:"Effacer l'Historique",Gh:"Fondre",Pd:"Search",Fg:"Ench\u00e8re Automatique",Qd:"Une utilisation excessive des ench\u00e8res peut entra\u00eener un bannissement. Il est recommand\u00e9 de d\u00e9sactiver les autres fonctionnalit\u00e9s d ench\u00e8res pour \u00e9viter les conflits potentiels. Cette fonctionnalit\u00e9 ralentira le bot..",
qh:"Rechercher dans l'Ench\u00e8re des Gladiateurs",th:"Rechercher dans l'Ench\u00e8re des Mercenaires",Yd:"Miser de la Nourriture?",qg:"Mise Maximale",Zd:"Miser si le statut est inf\u00e9rieur \u00e0",$d:"Objets Mis\u00e9s",Dk:"Langue de l'Ench\u00e8re",Ek:"\u00c0 partir de la mise \u00e0 jour 2.9.4, veuillez r\u00e9initialiser la langue ou R\u00c9INITIALISER LE BOT. Assurez-vous que toutes les informations sont correctes, sinon les ench\u00e8res ne fonctionneront pas.",Kd:"Vous pouvez ajouter des objets pour les rechercher dans le march\u00e9 et les ench\u00e8res. Il montrera \u00e9galement les objets violets dans le march\u00e9 une fois que vous aurez ajout\u00e9 un objet \u00e0 la liste. Si vous souhaitez activer les ench\u00e8res automatiques, utilisez les options ci-dessous.",
Bk:"Utilisez les ench\u00e8res avec prudence!",Ck:"Les ench\u00e8res automatiques font trop de requ\u00eates au serveur et peuvent entra\u00eener un bannissement si elles sont utilis\u00e9es en permanence!",hh:"Renouveler les Points d'\u00c9v\u00e9nement avec des Rubis?",ue:"Activer l'Huile Automatique",Gk:"R\u00e9cup\u00e9rer Automatiquement les Huiles Sacr\u00e9es",Vk:"Vitesse de V\u00e9rification des Qu\u00eates",Ua:"Attaquer les Membres du Gremio ?",Sa:'Ajouter automatiquement les personnes \u00e0 la liste "Attaque" lorsque plus de X OR est vol\u00e9.:',
Ta:'Ajouter automatiquement les personnes \u00e0 la liste "\u00c9viter l\'Attaque" lorsque vous perdez contre elles.:',Tb:"Attaques au Tableau des Scores",ac:"Tr\u00e8s Long",Cb:"Long",Kb:"Moyen",Yb:"Court",bc:"Tr\u00e8s Court",ve:"Entrer dans le Monde Souterrain si HP >",bh:"Vitesse de V\u00e9rification des Qu\u00eates",Ug:'Par d\u00e9faut, c\'est "3x". Si le bot pose des probl\u00e8mes avec les qu\u00eates, changez la vitesse des qu\u00eates en fonction de la vitesse de votre serveur.',cf:"S\u00e9lection du Sac de Soins",
xe:"Si vous renouvelez manuellement les points, vous devez cliquer sur le bouton ci-dessus \"Actualiser l'exp\u00e9dition d'\u00e9v\u00e9nement si bloqu\u00e9e !",Kk:"Vous devez activer au moins l'une des options suivantes : exp\u00e9dition, donjon, ar\u00e8ne ou cirque pour commencer l'exp\u00e9dition d'\u00e9v\u00e9nement.",eh:"Actualisez l'exp\u00e9dition d'\u00e9v\u00e9nement en cas de blocage !",mb:"Prot\u00e9ger les Alli\u00e9s ?",bl:"Laissez tous les param\u00e8tres d\u00e9sactiv\u00e9s si vous souhaitez fondre en utilisant les paquets contenant les objets de la liste. Cependant, vous pouvez toujours choisir les couleurs.",
Hk:"Personnage(D\u00e9sactiv\u00e9) / Mercenaire(Activ\u00e9)",Yk:"R\u00e9parer les Deux ?",cl:"Minuteries",Timers:"Entrez le nombre de minutes pour chaque minuteur ci-dessous ou laissez-le par d\u00e9faut.",pb:"Activer l'Attaque au Tableau des Scores:",Rb:"S\u00e9lectionner la Fourchette pour Attaquer",Sb:"Le bot attaquera al\u00e9atoirement depuis la liste du tableau des scores.",rb:"Attaque de Ligue",ob:"Activer l'Attaque de Ligue:",Nb:"Attaquer Al\u00e9atoirement",Ob:"Attaquer du plus bas au plus haut",
Ak:"Le bot \u00e9vitera par d\u00e9faut d'attaquer les membres du gremio.",Se:"Lieu d'Exp\u00e9dition:",Rd:"Collecter Automatiquement les Bonus:",Fh:"Passer le Boss",pe:"Lieu de Donjon:",nh:"R\u00e9initialiser en cas de perte?",ff:"Param\u00e8tres de l'Enfer",gf:"Configurez vos param\u00e8tres de pourcentage de gu\u00e9rison depuis l'onglet Gu\u00e9rison, et assurez-vous que l'interrupteur Gu\u00e9rison est activ\u00e9. Si l'entr\u00e9e dans le monde souterrain vous d\u00e9connecte, allez au lobby et activez la case \u00e0 cocher Connexion Automatique.",
df:"Difficult\u00e9 de l'Enfer",Ud:"Entrer Automatiquement dans l'Enfer: / Enfer Mode",Ei:"Utiliser Mobilisation si les points = 0",Ii:"Utiliser les Rubis?",ye:"Sortir du monde souterrain s'il n'y a plus de points?",ri:"Le bot essaiera d'abord d'utiliser Villa Medici, si vous ne l'avez pas, il utilisera la potion de gu\u00e9rison. N'oubliez pas d'activer l'interrupteur de Gu\u00e9rison.",zi:"L'entr\u00e9e automatique dans le monde souterrain d\u00e9sactivera le donjon/l'ar\u00e8ne/le cirque lors de l'entr\u00e9e dans le monde souterrain.",
dl:"Param\u00e8tres de Gu\u00e9rison du Monde Souterrain",Hi:"Utiliser Villa Medici?",Fi:"Utiliser la Potion de Gu\u00e9rison?",dg:"INFO: Le bot recherchera les objets sur le march\u00e9 toutes les minutes s\u00e9lectionn\u00e9es, ce qui peut interrompre les attaques pendant la recherche.",te:"Activer la Recherche sur le March\u00e9:",eg:"Intervalle de Recherche sur le March\u00e9 en Minutes:",fg:"Sugg\u00e9r\u00e9: 10 minutes.",rf:"Param\u00e8tres de l'Objet:",pf:"Le Nom de l'Objet Inclut",G:"Prix Max",
sf:"Type d'Objet",qf:"Raret\u00e9 de l'Objet",ce:"Acheter avec Lien d'\u00c2me?",uf:"Objets \u00e0 Acheter",tf:"Tentative d'achat d'objets avec des packs si l'un d'eux correspond au prix maximum indiqu\u00e9.:",ae:"Objets Achet\u00e9s:",Zg:"Ignorer le Filtre de Qu\u00eates",Yg:"Saisissez des mots-cl\u00e9s pour filtrer les qu\u00eates que vous ne souhaitez pas accepter. You can also use this to accept quests by their reward using keywords.",X:"Saisir un Mot-cl\u00e9",K:"Ajouter",gh:"Supprimer",fe:"Effacer",
Wg:"Accepter le Filtre de Qu\u00eates",Xg:"Saisissez des mots-cl\u00e9s pour choisir les qu\u00eates \u00e0 accepter. Cela ignorera les types de qu\u00eates",Ea:"Ignorer les Qu\u00eates Temporelles ?",Wk:"Qu\u00eates",Sd:"Costume Automatique",Di:"Utiliser le Costume ?",Xd:"Combat de Base",oe:"Combat en Donjon",Td:"Le bot ne portera Dis Pater Normal et Medium que si vos points d'exp\u00e9dition/donjon sont de 0.",ef:"Param\u00e8tres de Gu\u00e9rison en Enfer",Jd:"Attaquer le Boss quand disponible ?",
sb:"L'attaque en Ligue se d\u00e9sactivera apr\u00e8s 5 attaques infructueuses.",hf:"Huiles Sacr\u00e9es",Ag:"Nom de l'Objet",ba:"Niveau Minimum de l'Objet",Ba:"Qualit\u00e9 Minimum de l'Objet",Id:"Appliquer/R\u00e9initialiser la Minuterie",lf:"Ignorer la Combinaison de Pr\u00e9fixe/Suffixe",Ki:"Oui",Hg:"Non",Qa:"Ajouter un Pr\u00e9fixe",Ra:"Ajouter un Suffixe",Hh:"Liste des Objets \u00e0 Ignorer pour la Fusion",Mb:"Pr\u00e9fixe",Zb:"Suffixe",mh:"R\u00e9initialiser les Objets Expir\u00e9s",Ih:"Fusionner au Hasard depuis les Paquets ?",
Jh:"Onglet Fusion",qb:"Extras",Nd:"Ench\u00e8res",ig:"March\u00e9",$b:"Minuteries",hi:"Fusion",gi:"Fusionner s'il n'y a pas assez d'or",di:"Fusionner s'il n'y a pas d'objet",Fa:"R\u00e9paration",Wh:"Garder de l'Or sur le March\u00e9 de Guilde",Sh:"Garder de l'Or aux Ench\u00e8res",ki:"Entra\u00eenement",Zh:"R\u00e9initialiser les Expir\u00e9s",ii:"Stockage \u00e0 la Forge",Qh:"V\u00e9rification des Ench\u00e8res",ai:"Recherche",v:"Activer",Cg:"Or Minimum",Ub:"S\u00e9lectionner une Heure",nb:"Donner de l'Or \u00e0 la Guilde",
je:"Il donnera toutes les 5 minutes. Vous pouvez changer l'intervalle depuis l'onglet des minuteries",jf:"Combien souhaitez-vous donner ?",ke:"Donner lorsque vous avez plus de >",wf:"Moins de <",jh:"R\u00e9initialiser les Objets Expir\u00e9s et les Autres Param\u00e8tres",lh:"R\u00e9initialiser dans :",Qk:"Maintenez Ctrl (Cmd sur Mac) enfonc\u00e9 pour s\u00e9lectionner plusieurs objets",mf:"Import/Export des Param\u00e8tres",Ue:"Exporter les Param\u00e8tres",nf:"Importer les Param\u00e8tres",tg:"Message \u00e0 Tous les Joueurs",
ug:"[N\u00e9cessite une Cl\u00e9 Ultra Premium, message sur Discord pour l'obtenir.]",vg:"Saisir le message \u00e0 envoyer",he:"Pour des scripts personnalis\u00e9s, contactez-nous sur Discord",xg:"Envoyer",yg:"Afficher les Joueurs",wg:"Tout S\u00e9lectionner",zg:"Tout D\u00e9s\u00e9lectionner",vf:"Assurez-vous que votre inventaire ait suffisamment d'espace. Le temps de recharge est de 2 minutes.",mg:"Vendre de la Nourriture",Gb:"Vendre de la Nourriture"},Rh={we:"Auto Monster Switch",cg:"Piaci hiba! K\u00e9rj\u00fck, adja hozz\u00e1 \u00fajra az elemeket, \u00e9s pr\u00f3b\u00e1lja meg.",
Lb:"Pas assez d'espace dans l'inventaire pour fondre. Espace requis:",ck:"El\u0151sz\u00f6r olvassza fel a magasabb sz\u00edneket?",cc:"Csak a j\u00e1t\u00e9koslist\u00e1ra t\u00e1madjunk?",dc:"Ha ez az opci\u00f3 be van kapcsolva, a bot csak a j\u00e1t\u00e9koslist\u00e1n szerepl\u0151 j\u00e1t\u00e9kosokat t\u00e1madja meg. Ha ez az opci\u00f3 nincs bekapcsolva, a bot v\u00e9letlenszer\u0171 j\u00e1t\u00e9kosokat t\u00e1mad meg.",Mk:"Az exped\u00edci\u00f3s be\u00e1ll\u00edt\u00e1said helytelenek vagy v\u00e1ratlan oldaladatok vannak!",
Nk:"Az exped\u00edci\u00f3s be\u00e1ll\u00edt\u00e1sod helytelen! Letiltott sz\u00f6rnyet \u00e1ll\u00edtott\u00e1l be, ami helytelen.",$k:"Csak az \u00f6sszes kiv\u00e1lasztott sz\u00edn\u0171 alvil\u00e1gi elemet \u00e1ll\u00edtsa vissza?",Ca:"Priorit\u00e9",Vb:"D\u00e9finir la Priorit\u00e9",Rg:"Points",Kh:"Stat",Si:"Collect Gold",Oj:"Alvil\u00e1gi t\u00e1rgyakat eladni?",uj:"A bot minden m\u0171veletben f\u00e9szket keres, nem csak exped\u00edci\u00f3k sor\u00e1n.",sj:"F\u00e9szek keres\u00e9si t\u00edpus",
qj:"Ne csin\u00e1lj semmit",rj:"Gyors keres\u00e9s",tj:"Alapos keres\u00e9s",Ml:"After expedition points are consumed, travel to Germania to consume Dungeon points",zk:"Kattintson ide, ha a jav\u00edt\u00e1s beragad",Ng:"R\u00e9szleges Jav\u00edt\u00e1s",af:"Teljes Jav\u00edt\u00e1s",Mg:"R\u00e9szleges vagy Teljes Jav\u00edt\u00e1s",re:"Korl\u00e1t Enged\u00e9lyez\u00e9se",kj:"Korl\u00e1toz\u00e1s",lj:"Ha korl\u00e1tozni szeretn\u00e9d a t\u00e1mad\u00e1sok sz\u00e1m\u00e1t az ellens\u00e9gre, enged\u00e9lyezd ezt az opci\u00f3t \u00e9s \u00e1ll\u00edtsd be a korl\u00e1tot. A bot folytatja a t\u00e1mad\u00e1st a t\u00f6bbi ellens\u00e9ggel, miut\u00e1n befejezte a kiv\u00e1lasztott sz\u00f6rny elleni t\u00e1mad\u00e1sokat.",
me:"Ne l\u00e9pj be az alvil\u00e1gba alvil\u00e1gi jelmezben",le:"Ha nem akarsz alvil\u00e1gi jelmezben az alvil\u00e1gba l\u00e9pni, enged\u00e9lyezd ezt az opci\u00f3t",yi:"Alvil\u00e1g",pi:"Alvil\u00e1gi Buffok",si:"Haszn\u00e1ld az istenek erej\u00e9t az alvil\u00e1gba l\u00e9p\u00e9s ut\u00e1n?",ti:"V\u00e1laszd ki az isteneket, akikt\u0151l er\u0151t szeretn\u00e9l nyerni:",ui:"Haszn\u00e1lj fegyver er\u0151s\u00edt\u00e9st a fegyveren?",vi:"Haszn\u00e1lj p\u00e1nc\u00e9l er\u0151s\u00edt\u00e9st a k\u00f6vetkez\u0151 felszerel\u00e9sen:",
Jk:"A leh\u0171l\u00e9si id\u0151 30 perc. Ha nincs rajtad jelmez, a bot null\u00e1zza a leh\u0171l\u00e9si id\u0151t.",al:"Sz\u00ednek kiv\u00e1laszt\u00e1sa",$a:"Vulcanus Kov\u00e1csm\u0171helye",eb:"Feronia F\u00f6ldi Pajzsa",fb:"Neptunusz Foly\u00e9kony Ereje",gb:"Aelous L\u00e9gies Szabads\u00e1ga",hb:"Pl\u00fat\u00f3 Hal\u00e1los K\u00f6de",ib:"Juno \u00c9let Lehelete",jb:"Harag Hegyeinek Pikkelyes P\u00e1nc\u00e9lja",kb:"Sas Szemei",lb:"Saturnusz T\u00e9li \u00d6lt\u00f6z\u00e9ke",ab:"Bubona Bikap\u00e1nc\u00e9lja",
bb:"Mercerius Rabl\u00f3ruh\u00e1i",cb:"Ra F\u00e9nyk\u00f6nt\u00f6se",lg:"Csomagok",gg:"K\u00e9szlet",M:"Min. \u00c1r",L:"H\u00e1ny darab",Fb:"T\u00e1rgyak Elad\u00e1sa",Eb:"Keres\u00e9s ebben",hg:"Anyag Sz\u00edne",Db:"T\u00e1rgy Sz\u00edne",og:"Rakt\u00e1r",Aa:"V\u00e1lt\u00e1s Anyagokra",Hb:"V\u00e1lt\u00e1s T\u00e1rgyakra",ng:"Anyagok Elad\u00e1sa",xa:"K\u00e9rj\u00fck, adjon meg \u00e9rv\u00e9nyes t\u00e1rgyn\u00e9v, \u00e1rfekv\u00e9s \u00e9s mennyis\u00e9get.",ya:"Nincsenek megfelel\u0151 t\u00e1rgyak a kiv\u00e1lasztott keres\u00e9si helyeken.",
za:"Minden t\u00e1rgy sikeresen list\u00e1zva!",Uk:"Minden anyag sikeresen list\u00e1zva!",jg:"Ha fix \u00e1ron szeretne t\u00e1rgyakat eladni, ugyanazt az \u00e9rt\u00e9ket adja meg a min \u00e9s max \u00e1rra.",kg:"Ez a funkci\u00f3 m\u00e9g k\u00eds\u00e9rleti, \u00f3vatosan haszn\u00e1lja. Ha nem ad meg fix \u00e1rat, az elemek v\u00e9letlenszer\u0171en ker\u00fclnek list\u00e1z\u00e1sra a megadott minimum \u00e9s maximum \u00e1r k\u00f6z\u00f6tt.",Fk:"Be\u00e1ll\u00edtja a maxim\u00e1lis aranyat, amit a bot egy ciklusban elk\u00f6lt.",
Va:"A bot licit\u00e1lni kezd minden \u00e9tel t\u00e1rgyra, ha enged\u00e9lyezve van. Nem kell enged\u00e9lyezned a gladi\u00e1tor/zsoldos kapcsol\u00f3kat.",Ld:"A bot nem licit\u00e1l az sz\u00f6vets\u00e9gesei licitjeire.",Md:"Figyelmen k\u00edv\u00fcl hagyja az El\u0151tag/Ut\u00f3tag kombin\u00e1ci\u00f3t t\u00e1rgy keres\u00e9sekor az aukci\u00f3n.",Vj:"V\u00e1laszd ki azokat a t\u00e1rgyt\u00edpusokat, amelyeket be akarsz olvasztani.",Wj:"V\u00e1laszd ki azokat a sz\u00edneket, amelyeket be akarsz olvasztani.",
Xj:"V\u00e1laszd ki az t\u00e1rgyak szintj\u00e9t, amelyeket be akarsz olvasztani.",Yj:"V\u00e1laszd ki a kalap\u00e1csot, amit haszn\u00e1lni szeretn\u00e9l.",Zj:"Figyelj arra, hogy az els\u0151 mez\u0151 melletti z\u00f6ld \u00e9s piros k\u00f6r a szab\u00e1ly enged\u00e9lyez\u00e9s\u00e9hez/letilt\u00e1s\u00e1hoz van.",$j:"Ha v\u00e9letlenszer\u0171en szeretn\u00e9l beolvasztani b\u00e1rmilyen sz\u00ednt vagy t\u00edpust, enged\u00e9lyezheted a `V\u00e9letlenszer\u0171en beolvasztani, ha nincsenek felt\u00e9telek teljes\u00edtve? (A tutorial vide\u00f3ban utolj\u00e1ra enged\u00e9lyezett opci\u00f3)",
Kj:"R\u00e9parer avant la Fusion",Oe:"Sz\u00f6rny Kiv\u00e1laszt\u00e1sa",Ce:"Homok\u00f3ra/Rubin Haszn\u00e1lata?",Lk:"Rubin Haszn\u00e1lata?",Fe:"Mozg\u00f3s\u00edt\u00e1s Haszn\u00e1lata?",Ee:"\u00c9letital Haszn\u00e1lata?",Be:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9ka (%)",Me:"T\u00e1mad\u00e1sok Sz\u00e1ma",De:"T\u00e1mad\u00e1si Id\u0151k\u00f6z (m\u00e1sodpercben)",ze:"V\u00e9grehajtott T\u00e1mad\u00e1sok",Ae:"H\u00e1tral\u00e9v\u0151 Homok\u00f3ra",Ke:"Megjegyz\u00e9s: \u00c9leter\u0151-p\u00f3ci\u00f3kat haszn\u00e1l gy\u00f3gy\u00edt\u00e1sra, nem \u00e9telt.",
Le:"Megjegyz\u00e9s: Ha a t\u00e1mad\u00e1sok id\u0151 el\u0151tt meg\u00e1llnak, pr\u00f3b\u00e1lja meg az 'T\u00e1mad\u00e1sok Vissza\u00e1ll\u00edt\u00e1sa' opci\u00f3t.",Pe:"Ind\u00edt\u00e1s",Ne:"Vissza\u00e1ll\u00edt\u00e1s",Qe:"Le\u00e1ll\u00edt\u00e1s",Re:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sai (Kattintson minimaliz\u00e1l\u00e1shoz)",Ge:"Sz\u00f6rny 1",He:"Sz\u00f6rny 2",Ie:"Sz\u00f6rny 3",Je:"Sz\u00f6rny 4",Xk:"R\u00e9parer avant la Fusion",Qi:"Ez az opci\u00f3 haszn\u00e1lja a cervisia-t, amikor lej\u00e1r a pr\u00e9mium tags\u00e1god.",
xj:"Ez az opci\u00f3 aktiv\u00e1lja \u00e9s v\u00e1laszt olajokat az istenek jutalmai k\u00f6z\u00fcl. Haszn\u00e1lhatja az 1. \u00e9s 3. sz\u00e1m\u00fa olajokat a karakteren, de a 2. sz\u00e1m\u00fa csak csomagokba ker\u00fcl.",Oi:"Ez az opci\u00f3 a be\u00e1ll\u00edtott id\u0151ben haszn\u00e1lja a buffokat. Megkeresi a csomagokban l\u00e9v\u0151 buffokat \u00e9s alkalmazza \u0151ket a karakteren.",mj:"Ez az opci\u00f3 bevisz az alvil\u00e1gba. Ne felejtsd el enged\u00e9lyezni az Auto Bejelentkez\u00e9st az Extra f\u00fcl\u00f6n, k\u00fcl\u00f6nben kijelentkezhetsz az alvil\u00e1gba l\u00e9p\u00e9skor [J\u00e1t\u00e9k Hiba]",
ec:"Ez az opci\u00f3 csak az ar\u00e9na/cirkusz list\u00e1t t\u00e1madja meg. Ha nem, a bot kihagyja.",Hj:"Ez az opci\u00f3 csak pr\u00e9mium licencek sz\u00e1m\u00e1ra van. Szimul\u00e1l egy t\u00e1mad\u00e1st egy felhaszn\u00e1l\u00f3 ellen 75%-os gy\u0151zelmi r\u00e1t\u00e1val, miel\u0151tt megt\u00e1madn\u00e1.",Od:"Nem kell enged\u00e9lyezned a f\u0151 aukci\u00f3 kapcsol\u00f3t, hogy ezt az opci\u00f3t haszn\u00e1lhasd.",sk:"Ez az opci\u00f3 m\u00e1sodpercenk\u00e9nt friss\u00edti az oldalt, amikor az aukci\u00f3 -Nagyon R\u00f6vid- \u00e1llapotban van, hogy folyamatosan licit\u00e1ljon \u00e9s megnyerje az aukci\u00f3t.",
Tj:"Ha egyik olvaszt\u00e1si felt\u00e9tel sem teljes\u00fcl, akkor v\u00e9letlenszer\u0171en olvaszt. Gy\u0151z\u0151dj meg r\u00f3la, hogy v\u00e1lasztott\u00e1l t\u00e1rgyt\u00edpust \u00e9s sz\u00ednt.",Uj:"Ez az opci\u00f3 csak a lelt\u00e1rban l\u00e9v\u0151 t\u00e1rgyakat olvasztja. A csomagokban l\u00e9v\u0151 t\u00e1rgyakat figyelmen k\u00edv\u00fcl hagyja.",Wa:"Aukci\u00f3s T\u00e1rgyak",rg:"Zsoldos T\u00e1rgyak",Xb:"Bolt T\u00e1rgyak",Ai:"Egyedi T\u00e1rgyak",Pj:"H\u00e1tt\u00e9r be\u00e1ll\u00edt\u00e1sa feket\u00e9re [N\u00f6veli a teljes\u00edtm\u00e9nyt]",
Qj:"GLDbot gombok \u00e1thelyez\u00e9se a bal als\u00f3 sarokba?",Ri:"Cirkusz T\u00e1mad\u00e1s Gy\u00f3gy\u00edt\u00e1s N\u00e9lk\u00fcl",rk:"Sz\u00fcks\u00e9g eset\u00e9n vegy\u00fcnk ki aranyat a csomagokb\u00f3l?",bm:"Az edz\u00e9shez aranyat vettek a csomagokb\u00f3l",Fd:"Nem tal\u00e1ltak aranyat a csomagokban az edz\u00e9shez",lk:"Jav\u00edtott T\u00e1rgyak",ek:"Ar\u00e9na T\u00e1mad\u00e1sok",gk:"Cirkusz T\u00e1mad\u00e1sok",mk:"T\u00e1rgyak Vissza\u00e1ll\u00edtva",jk:"Exped\u00edci\u00f3s T\u00e1mad\u00e1sok",
ik:"Kazamata T\u00e1mad\u00e1sok",pk:"Alvil\u00e1gi T\u00e1mad\u00e1sok",fk:"Ar\u00e9n\u00e1ban Szerzett P\u00e9nz",hk:"Cirkuszban Szerzett P\u00e9nz",nk:"Olvasztott T\u00e1rgyak",kk:"\u00dajrahasznos\u00edtott Arany",dj:"C\u00e9h Csata",fj:"C\u00e9h Be\u00e1ll\u00edt\u00e1sok",ej:"C\u00e9h N\u00e9v",cj:"V\u00e9letlenszer\u0171 C\u00e9h T\u00e1mad\u00e1s",tl:"V\u00e9letlenszer\u0171en t\u00e1madja a c\u00e9heket.",Pi:"Statisztik\u00e1k Vissza\u00e1ll\u00edt\u00e1sa",El:'GLDbot: A kock\u00e1k seg\u00edts\u00e9g\u00e9vel friss\u00edtse a rejt\u00e9lydobozt, \u00e9s tal\u00e1ljon \u00e9rt\u00e9kes t\u00e1rgyakat, miel\u0151tt kinyitn\u00e1 azokat (stb. jelmezek). Kattintson a "Start" gombra, nyissa meg a l\u00e1d\u00e1kat.',
Pc:"Wood",Fc:"Copper",Jc:"Iron",Lc:"Leather",Qc:"Wool",Gc:"Cotton Wool",Ic:"Hemp",Hc:"Gauze Strip",Mc:"Linen Strip",Kc:"Jute Patch",Oc:"Velvet",Nc:"Silk Thread",Yc:"Fur",Sc:"Bone Splinter",ad:"Scale",Vc:"Claw",Xc:"Fang",Wc:"Dragon Scale",Tc:"Bull`s Horn",$c:"Poison Gland",Uc:"Cerberus` Pelt",Zc:"Hydra Scale",bd:"Sphinx Feather",cd:"Typhon Leather",Cc:"Lapis Lazuli",wc:"Amethyst",vc:"Amber",xc:"Aquamarine",Dc:"Sapphire",Ac:"Garnet",zc:"Emerald",yc:"Diamond",Bc:"Jasper",Ec:"Sugilite",qc:"Scorpion Poison",
tc:"Tincture of Stamina",mc:"Antidote",lc:"Adrenaline",sc:"Tincture of Enlightenment",pc:"Potion of Perception",nc:"Essence of Reaction",oc:"Phial of Charisma",uc:"Waters of Oblivion",rc:"Soul Essence",Bd:"Water Seal",vd:"Protection Rune",td:"Earth Mark",Ad:"Totem of Healing",zd:"Talisman of Power",xd:"Stone of Fortune",ud:"Flintstone",yd:"Storm Rune",wd:"Shadow Rune",gd:"Crystal",fd:"Bronze",ld:"Obsidian",od:"Silver",pd:"Sulphur",jd:"Gold Ore",nd:"Quartz",md:"Platinum",ed:"Almandin",hd:"Cuprit",
kd:"Hellstone",Li:"T\u00e1mad\u00e1s v\u00e9letlenszer\u0171en?",Mi:'Kapcsold ki a "J\u00e1t\u00e9kosok rendez\u00e9se az ar\u00e9n\u00e1ban szint szerint" be\u00e1ll\u00edt\u00e1st a crazy-addonban is.',$g:"Csak az isten t\u00edpus\u00e1n alapul\u00f3 k\u00fcldet\u00e9seket fogadja el.",Xa:"Automatikus Buff",be:"Csak a pokolban haszn\u00e1lja?",Gg:"\u00daj Szab\u00e1ly",Eg:"N\u00e9v Tartalmazza",isUnderworldItem:"Ez egy alvil\u00e1gi t\u00e1rgy?",kf:"Anyagok Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
yk:"Utiliser la Pri\u00e8re ?",Gi:"Utiliser le Sacrifice ?",uk:"Utiliser le tissu pour entrer dans le monde souterrain ?",xi:"A m\u00e9lyvil\u00e1gban csak a m\u00e9lyvil\u00e1ggal kapcsolatos k\u00fcldet\u00e9seket fogadja el?",wi:"Ha enged\u00e9lyezve van, meg kell adnia a m\u00e9lyvil\u00e1gi t\u00e1rgyak nev\u00e9t. Ha a bot megtal\u00e1lja ezeket a t\u00e1rgyakat a m\u00e9lyvil\u00e1gban, elfogadja a k\u00fcldet\u00e9st.",el:"M\u00e9lyvil\u00e1gi K\u00fcldet\u00e9s T\u00e1rgy",ql:"Entrez le Nom du Mat\u00e9riel",
Ik:"A robot im\u00e1dja a kock\u00e1kat! Seg\u00edtenek ruh\u00e1t tal\u00e1lni a l\u00e1d\u00e1kban. De ha nincs kocka, a robot akkor is kinyitja a l\u00e1d\u00e1kat, rem\u00e9lve, hogy tal\u00e1l valami men\u0151 ruh\u00e1t (de lehet, hogy semmit sem tal\u00e1l!)",Sj:"Fusionner les Bo\u00eetes de Butin ?",qe:"Enable Arena",Sg:"Prioriz\u00e1lja az ar\u00e9na list\u00e1t?",Tg:"Prioriz\u00e1lja a cirkusz list\u00e1t?",ie:"Napl\u00f3 men\u00fc letilt\u00e1sa",oh:"Jutalom Min. Arany \u00c9rt\u00e9k",
ah:"Ha enged\u00e9lyezve van, a K\u00fcldet\u00e9s F\u00f3kusz a legr\u00f6videbb utat k\u00f6veti a dungeon befejez\u00e9s\u00e9hez.",Nh:"Dobja a kock\u00e1t automatikusan?",Oh:"Vigy\u00e1zva haszn\u00e1lja a dob\u00f3 kock\u00e1t, folyamatosan az els\u0151 kock\u00e1t fogja haszn\u00e1lni, am\u00edg ki nem kapcsolja az opci\u00f3t.",uh:"Keres\u00e9s folyamatban",ih:"A jav\u00edt\u00e1s alap\u00e9rtelmezett leh\u0171l\u00e9se 10 perc.",Bg:"Minim\u00e1lis \u00c1llapot",ge:"Aktu\u00e1lis t\u00e9tel a munkapadon [T\u00f6r\u00f6lje, ha a bot v\u00e1ratlanul sz\u00fcnetelt]",
Gf:"Kov\u00e1csolt er\u0151forr\u00e1sok sikeresen elmentve a horreumhoz.",Cf:"Piac ellen\u0151rz\u00e9se t\u00e1rgyak sz\u00e1m\u00e1ra...",Ab:"T\u00e9tel \u00e1thelyezve a munkapadra.",Tf:"T\u00e9tel sikeresen jav\u00edtva \u00e9s felszerelve.",Uf:"T\u00e9tel sikeresen jav\u00edtva.",Sk:"A jav\u00edt\u00e1s sikertelen. Az oldal friss\u00edt\u00e9sre ker\u00fcl.",Qf:"Anyagok felv\u00e9tele...",bg:"V\u00e1rakoz\u00e1s a jav\u00edt\u00e1sra...",Sf:"Jav\u00edt\u00e1s elindult: .",wa:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa az invent\u00e1riumb\u00f3l a t\u00e1sk\u00e1ba",
Rf:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa a munkapadra a csomagol\u00f3ba.",ua:"Nem tal\u00e1lhat\u00f3 elegend\u0151 anyag. A jav\u00edt\u00e1si hely le lesz tiltva ",Nf:"T\u00e1rgyak keres\u00e9se arany elrejt\u00e9s\u00e9re az aukci\u00f3ban...",zf:"Lej\u00e1rt t\u00e1rgyak ellen\u0151rz\u00e9se a csomagokban...",Af:"T\u00e9tel sikeresen vissza\u00e1ll\u00edtva.",Bf:"Nincs \u00fcres hely vagy arany a vissza\u00e1ll\u00edt\u00e1shoz.",Hf:"Gy\u0151z\u0151dj\u00f6n meg arr\u00f3l, hogy van elad\u00e1si joga a c\u00e9hes piacon!",
ub:"Nincs el\u00e9g arany/vagy nincs meg a v\u00e1s\u00e1rl\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s a friss\u00edt\u00e9shez.",wb:"A bolt friss\u00edtve lett.",xb:"Hiba t\u00f6rt\u00e9nt a gy\u00f3gyul\u00e1s k\u00f6zben.",Kf:"Nincs Ruby vagy Cloth, letilt\u00e1sa az opci\u00f3knak.",Rk:"Nincs gy\u00f3gy\u00edt\u00f3 t\u00e1rgy a csomagokban.",yb:"Nem tal\u00e1lhat\u00f3 megfelel\u0151 t\u00e1rgy",Lf:"Az \u00e9lelmiszereket felvett\u00e9k. A folyamat v\u00e9get \u00e9rt.",Mf:"Legal\u00e1bb egy \u00e9tel felv\u00e9telre ker\u00fclt. A folyamat v\u00e9get \u00e9rt.",
zb:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",If:"\u00c9telek felv\u00e9tele a csomagokb\u00f3l.",Jf:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",vb:"Nincs t\u00f6bb gy\u00f3gy\u00edt\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s.",tb:"\u00c9P helyre\u00e1ll\u00edtva.",va:"Nincs teend\u0151, ez\u00e9rt im\u00e1dkozom!",Yf:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem \u00e9s a Villa Medici ellen\u0151rz\u00e9s\u00e9re.",
Zf:"V\u00e1rakoz\u00e1s a Villa Medici-re, friss\u00edt\u00e9s 60 m\u00e1sodperc m\u00falva.",$f:"Elhagytam az alvil\u00e1got.",ag:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem ellen\u0151rz\u00e9s\u00e9re.",Of:"Isteni olajok ellen\u0151rz\u00e9se...",Pf:"Isteni olajok felv\u00e9ve.",sa:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen AZ AR\u00c9N\u00c1BAN: ",ta:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen A CIRKUSZBAN: ",xf:"Aukci\u00f3 ellen\u0151rz\u00e9se! K\u00e9rem v\u00e1rjon...",
yf:"T\u00e1rgyak licit\u00e1l\u00e1sa. K\u00e9rem v\u00e1rjon...",Vf:"Automatikus olvasztott t\u00e9tel: ",Wf:"Olvaszt\u00e1s alatt \u00e1ll\u00f3 t\u00e9tel: ",Bb:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges arany: ",Xf:"OLVASZT\u00c1S: T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",Tk:"T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",Df:"Koszt\u00fcm\u00f6k el\u00e9rhet\u0151s\u00e9g\u00e9nek ellen\u0151rz\u00e9se...",Ff:"Adom\u00e1nyozva: ",Ef:"Kocka dob\u00e1sa...",
Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",Ye:"Figyelem: Kapcsolja be ezt a funkci\u00f3t a t\u00e1madni k\u00edv\u00e1nt l\u00e9ny felold\u00e1sa ut\u00e1n, nem fog automatikusan t\u00e1madni, hogy feloldja a sz\u00f6rnyet.",Ve:"Farm Enemy",Vd:"Automatikus Bejelentkez\u00e9s",Wd:"Enged\u00e9lyezned kell a felugr\u00f3 ablakokat a GameForge el\u0151csarnok k\u00e9perny\u0151j\u00e9r\u0151l. N\u00e9zd meg a dokument\u00e1ci\u00f3t, hogy hogyan tedd meg.",Og:"Bot Sz\u00fcneteltet\u00e9se",
Pg:"Bot sz\u00fcneteltet\u00e9se ennyi id\u0151re: (Perc)",Te:"Lej\u00e1rati D\u00e1tum",Jg:"Csak \u00e9telt v\u00e1s\u00e1rolj?",Kg:"Ha ezt enged\u00e9lyezed, a bot figyelmen k\u00edv\u00fcl hagyja a kiv\u00e1laszt\u00e1saidat, \u00e9s automatikusan v\u00e1s\u00e1rol \u00e9telt an\u00e9lk\u00fcl, hogy b\u00e1rmit be\u00edrn\u00e1l.",Jb:"Maxim\u00e1lis \u00f6sszes arany kiad\u00e1s",Ib:"Maxim\u00e1lis arany \u00e9telenk\u00e9nti kiad\u00e1s",Ig:"A bot 60 percenk\u00e9nt ellen\u0151rzi az olajokat",
fi:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a olvaszt\u00e1si id\u0151k ellen\u0151rz\u00e9s\u00e9hez.",ci:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs aranyad.",ei:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs el\u00e9rhet\u0151 t\u00e1rgyad.",Yh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a t\u00e1rgyak jav\u00edt\u00e1s\u00e1hoz \u00e9s ellen\u0151rz\u00e9s\u00e9hez.",
Xh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a guild piac\u00e1nak arany\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Th:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az aukci\u00f3 arany tart\u00e1si lehet\u0151s\u00e9g\u00e9hez.",Ph:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az ar\u00e9na PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",Uh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a cirkusz PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",
li:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a statisztik\u00e1k tr\u00e9ningez\u00e9s\u00e9hez.",$h:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a lej\u00e1rt t\u00e1rgyak vissza\u00e1ll\u00edt\u00e1s\u00e1hoz.",ji:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a kov\u00e1csol\u00f3 anyagok t\u00e1rol\u00e1s\u00e1hoz a horreum-ban.",Rh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a gladi\u00e1torok \u00e9s zsoldosok aukci\u00f3j\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",bi:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t t\u00e1rgyak keres\u00e9s\u00e9hez az aukci\u00f3ban \u00e9s a boltban.",
Vh:"Be\u00e1ll\u00edtja a guild adom\u00e1ny k\u00fcld\u00e9s\u00e9nek id\u0151z\u00edt\u0151j\u00e9t.",bf:"Arany Mozgatva",ne:"Ne adjon el az \u00f6sszeoml\u00e1si \u00e9s aukci\u00f3s list\u00e1n szerepl\u0151 t\u00e9teleket",vh:"Bolt Automatiz\u00e1l\u00e1s",xh:"T\u00e1rgy Keres\u00e9s Be\u00e1ll\u00edt\u00e1sok",wh:"Haszn\u00e1lja ezt az eszk\u00f6zt t\u00e1rgyak keres\u00e9s\u00e9hez. Egyszer\u0171en adjon hozz\u00e1 t\u00e1rgyakat a list\u00e1hoz, hat\u00e1rozza meg a ruha mennyis\u00e9g\u00e9t, majd ind\u00edtsa el a keres\u00e9st.",
yh:"Haszn\u00e1lni k\u00edv\u00e1nt Ruha:",zh:"H\u00e1ny ruh\u00e1t haszn\u00e1ljon?",fa:"Full Adja meg a T\u00e1rgy Nev\u00e9t",Wb:"Adja meg a T\u00e1rgy Szintj\u00e9t",Bh:"T\u00e1rgy Min\u0151s\u00e9ge",Ah:"T\u00e1rgy Neve Itt",Ch:"Keres\u00e9s Ind\u00edt\u00e1sa",Dh:"\u00c1tugr\u00e1s \u00e9s Folytat\u00e1s",Eh:"Keres\u00e9s Le\u00e1ll\u00edt\u00e1sa",Ze:"Guild Piac Rendez\u00e9se",Dg:"Legdr\u00e1g\u00e1bb",de:"Legolcs\u00f3bb",Da:"V\u00e1lasszon egy lehet\u0151s\u00e9get",se:"Mettre en surbrillance les objets du monde souterrain",
$e:"F\u00f3kuszban a k\u00fcldet\u00e9sre?",Rq:"Haszn\u00e1ljon rubint, ha nincs ruha?",Ya:"Ker\u00fclje azonos szem\u00e9lyek megt\u00e1mad\u00e1s\u00e1t, hogy elker\u00fclje a jelent\u00e9st\u00e9tel\u00e9t. A jelent\u00e9s megn\u00f6veli a kitilt\u00e1s es\u00e9ly\u00e9t.",Tl:"Olvad a z\u00f6ld?",Vg:"Ne fogadja el a v\u00e9letlenszer\u0171 k\u00fcldet\u00e9seket, ha b\u00e1rmilyen sz\u0171r\u0151t megadott?",Rc:"Maxim\u00e1lis haszn\u00e1lhat\u00f3 anyagmin\u0151s\u00e9g",$i:"Enged\u00e9lyezze a zsoldos keres\u00e9st",
Al:'Kattints a "Minden Kiv\u00e1lasztott Elad\u00e1sa" gombra az \u00f6sszes t\u00e9tel elad\u00e1s\u00e1hoz. Gy\u0151z\u0151dj meg r\u00f3la, hogy az els\u0151 (1) t\u00e1sk\u00e1dban van el\u00e9g 2x3 \u00fcres hely. Az arany t\u00f6meges gy\u0171jt\u00e9s\u00e9hez sz\u0171rd ki az aranyat, \u00e9s haszn\u00e1ld a "Kiv\u00e1lasztott vagy Mindet Kiv\u00e1laszt" lehet\u0151s\u00e9get.',dk:"\ud83d\udd25 : Hozz\u00e1adja az elemet a koh\u00e1szati list\u00e1hoz.",Ni:"\ud83d\udd28 : Hozz\u00e1adja az elemet az \u00e1rver\u00e9si list\u00e1hoz.",
Jj:"Friss\u00edtsd a boltot anyaggal, amikor tele van",Il:"Oldal:",Fj:"Meg\u00e1ll\u00edt",Dj:"Elad\u00e1s Ezen az Oldalon",Aj:"Kiv\u00e1lasztott Kiv\u00e1laszt\u00e1sa",zj:"Mindent Kiv\u00e1laszt",Gj:"Automatikus Csomagol\u00e1si Be\u00e1ll\u00edt\u00e1sok",Ej:"Er\u0151forr\u00e1sok K\u00fcld\u00e9se",Bj:"Minden Kiv\u00e1lasztott Elad\u00e1sa",na:"T\u00e9tel T\u00edpusa",pa:"Fegyverek",U:"Pajzsok",O:"P\u00e1nc\u00e9lok",S:"Sisakok",R:"Keszty\u0171k",P:"Csizm\u00e1k",oa:"Gy\u0171r\u0171k",la:"Amulettek",
Ka:"Haszn\u00e1lati T\u00e1rgyak (\u00c9telek)",Pa:"Fejleszt\u00e9sek",yj:"Er\u0151s\u00edt\u00e9sek",Ma:"Receptek",La:"Zsoldosok",Oa:"Kov\u00e1csol\u00f3 Eszk\u00f6z\u00f6k",Na:"Pergamenek",sd:"Er\u0151s\u00edt\u00e9sek",qd:"Esem\u00e9ny T\u00e1rgyak",rd:"Kov\u00e1csol\u00e1shoz Val\u00f3 T\u00e1rgyak",Hl:"Arany",Ja:"Minden",Jl:"Min\u0151s\u00e9g",qa:"Feh\u00e9r",C:"Z\u00f6ld",B:"K\u00e9k",D:"Lila",J:"Narancss\u00e1rga",T:"Piros",Cj:"Az \u00d6sszes Elad\u00e1si Be\u00e1ll\u00edt\u00e1s",Rj:"Elhanyagolja a El\u0151tag / Ut\u00f3tag Kombin\u00e1ci\u00f3t?",
gj:"H\u00e1ny \u00e9telt vegy\u00e9l/fogj fel?",Vi:"Norm\u00e1l",Ui:"K\u00f6zepes",Ti:"Neh\u00e9z",Ga:"Alap",Nl:"Ragadt Megjav\u00edt\u00e1s",Pk:"Kapcsold ki a Pokol Bel\u00e9p\u00e9s\u00e9t, ha letiltan\u00e1d a Dungeon/Circus/Arena-t. Ha k\u00e9zzel l\u00e9pt\u00e9l be a Pokolba, akkor enged\u00e9lyezned kell a Pokol M\u00f3dot.",ee:"V\u00e1lassz alvil\u00e1gi jelmezt",Ji:"Viselj alvil\u00e1gi jelmezt, ha el\u00e9rhet\u0151?",oi:"K\u00e9pz\u00e9si \u00fatmutat\u00f3: Hat\u00e1rozza meg, h\u00e1nyszor szeretn\u00e9 edzeni a statisztik\u00e1kat, \u00e9s \u00e1ll\u00edtsa be priorit\u00e1saikat. A bot nem fog edzeni, hacsak nincs be\u00e1ll\u00edtva egy priorit\u00e1s. Ha van be\u00e1ll\u00edtott priorit\u00e1s, de nincs t\u00f6bb k\u00e9pzend\u0151 statisztika, a bot a kiv\u00e1lasztott statisztik\u00e1val folytatja.",
nl:"Quest",Dd:"Olvaszt\u00e1s",Yl:"Olvaszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",ak:"Olvasztott T\u00e1rgyak",Zl:"Adj hozz\u00e1 el\u0151tagot vagy ut\u00f3tagot, amint megtal\u00e1lja a csomagokban, aut\u00f3matikusan olvasztani fogja.:",Xl:"Olvasztand\u00f3 T\u00e1rgy:",ic:"Kattints a t\u00e1rgyra, amelyet meg akarsz jav\u00edtani. Ez a rendszer megjav\u00edtja a k\u00e9t f\u0151 karaktered t\u00e1rgyait ( AR\u00c9NA/CT). Legal\u00e1bb 10000 aranyra van sz\u00fcks\u00e9g a jav\u00edt\u00e1s elind\u00edt\u00e1s\u00e1hoz. Ha egy t\u00e1rgy beragad, az azt jelenti, hogy nincs anyagod a jav\u00edt\u00e1shoz. Pr\u00f3b\u00e1lj szabad helyet k\u00e9sz\u00edteni a t\u00e1sk\u00e1dban. A bot akkor kezdi meg a jav\u00edt\u00e1st, amikor a t\u00e9tel tart\u00f3ss\u00e1ga %0.",
gl:"Csak Zsoldosra alkalmaz",jl:"Aukci\u00f3 csak akkor licit\u00e1l, ha a lej\u00e1rati id\u0151 k\u00f6zel van a v\u00e9g\u00e9hez.",il:"Gy\u0151z\u0151dj meg arr\u00f3l, hogy a 2. lelt\u00e1r f\u00fcl \u00fcres \u00e9s rendelkezik 10K arannyal. A bot megtal\u00e1lja \u00e9s a m\u00e1sodik f\u00fclre helyezi a t\u00e1rgyat, majd legk\u00f6zelebb az oldal friss\u00edt\u00e9se ut\u00e1n olvasztja a t\u00e1rgyat. Az olvaszt\u00e1st minden 5-10 percen bel\u00fcl \u00fajraellen\u0151rzi.",jj:"Gy\u00f3gy\u00edt\u00e1s & Buffs",
Ol:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges Arany:",Rl:"Licit kihagy\u00e1sa: Egyes\u00fclet tag m\u00e1r licit\u00e1lt a t\u00e1rgyra ",Ql:"Licit kihagy\u00e1sa: M\u00e1r licit\u00e1lt a t\u00e1rgyra ",advanced:"Halad\u00f3",arena:"Ar\u00e9na",ja:"Aut\u00f3matikus T\u00e1mad\u00e1s",fc:"T\u00e1mad\u00e1s Elker\u00fcl\u00e9se",ha:"J\u00e1t\u00e9kos Hozz\u00e1ad\u00e1sa",ia:"Add hozz\u00e1 a j\u00e1t\u00e9kos nev\u00e9t (Same Server)",vl:"Meg\u00e1ll\u00edtja a bot, ha elfogyott az \u00e9tel?",
circusTurma:"Circus Turma",Wi:"Neh\u00e9zs\u00e9g",dungeon:"Kazamata",Xi:"Kazamata Be\u00e1ll\u00edt\u00e1sok",eventExpedition:"Esem\u00e9ny Exped\u00edci\u00f3",expedition:"Exped\u00edci\u00f3",aj:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sok",Lj:"V\u00e1lassz Sz\u00f6rnyet",xl:"Legmagasabb",wl:"Tedd be a gy\u00f3gy\u00edt\u00f3 t\u00e1rgyaid az els\u0151 oldalra a lelt\u00e1rodon bel\u00fcl",nj:"Bent",Lh:"Arany T\u00e1rol\u00e1sa",Mh:"Arany T\u00e1rol\u00e1sa az Aukci\u00f3ban?",rh:"Haszn\u00e1ld a Munk\u00e1sruh\u00e1t a Bolt Felt\u00f6lt\u00e9s\u00e9hez?",
Zk:"V\u00e1lassz T\u00e9teleket a Vissza\u00e1ll\u00edt\u00e1shoz",kh:"Lej\u00e1rt T\u00e9telek Vissza\u00e1ll\u00edt\u00e1sa",Qb:"Megjegyz\u00e9s: Az opci\u00f3 enged\u00e9lyez\u00e9s\u00e9vel a bot eladja a k\u00f6zelg\u0151 lej\u00e1rat\u00fa t\u00e1rgyakat a Csomagokb\u00f3l az Egyes\u00fcleti Piacon majd megszak\u00edtja a lej\u00e1rati id\u0151 vissza\u00e1ll\u00edt\u00e1s\u00e1t. Egyes\u00fclet sz\u00fcks\u00e9ges. Gy\u0151z\u0151dj meg r\u00f3la, hogy a t\u00e1sk\u00e1dban van \u00fcres 3x3-as hely.",
Qg:"Bot v\u00e9letlenszer\u0171 sz\u00fcneteltet\u00e9se m\u0171k\u00f6d\u00e9si [Teszt F\u00e1zis]:",aa:"Arany T\u00e1rol\u00e1sa: A bot megtartja ezt az aranyat a karakteren:",pg:"Max Arany: A bot elk\u00f6lti, ha az arany nagyobb, mint",ph:"A bot v\u00e9letlenszer\u0171 t\u00e1rgyakra fog licit\u00e1lni.",Gd:"V\u00e9letlenszer\u0171 k\u00e9sleltet\u00e9s hozz\u00e1ad\u00e1sa",Hd:"Itt adhatsz hozz\u00e1 k\u00e9sleltet\u00e9st a bothoz.",Pb:"Jav\u00edt\u00e1s",Sl:"Csak K\u00e9k t\u00e1rgy Olvaszt\u00e1s?",
Vl:"Csak Lila t\u00e1rgy Olvaszt\u00e1s?",Ul:"Csak Narancss\u00e1rga t\u00e1rgy Olvaszt\u00e1s?",bk:"Mindent Olvassz be a 2. f\u00fclben?",Wl:"Ez figyelmen k\u00edv\u00fcl hagyja a sz\u00ednv\u00e1laszt\u00e1sokat",Za:"El\u0151zm\u00e9nyek T\u00f6rl\u00e9se",Gh:"Olvaszt\u00e1s",Pd:"Search",Fg:"Aut\u00f3matikus Aukci\u00f3",Qd:"Az aukci\u00f3 t\u00falzott haszn\u00e1lata kitilt\u00e1st vonhat maga ut\u00e1n. Az esetleges \u00fctk\u00f6z\u00e9sek elker\u00fcl\u00e9se \u00e9rdek\u00e9ben aj\u00e1nlatos letiltani az egy\u00e9b aj\u00e1nlatt\u00e9teli funkci\u00f3kat. Ez a funkci\u00f3 lelass\u00edtja a botot.",
qh:"Keres\u00e9s a Gladi\u00e1torok Aukci\u00f3j\u00e1ban",th:"Keres\u00e9s a Zsoldosok Aukci\u00f3j\u00e1ban",Yd:"Licit\u00e1l\u00e1s \u00c9telekre?",qg:"Maxim\u00e1lis Licit",Zd:"Licit\u00e1l\u00e1s, ha az \u00e1llapot kevesebb, mint",$d:"Licit\u00e1lt T\u00e1rgyak",Dk:"Aukci\u00f3 Nyelve",Ek:"2.9.4-es friss\u00edt\u00e9ssel kapcsolatban k\u00e9rlek \u00e1ll\u00edtsd be \u00fajra a nyelvet, vagy ALAP\u00c9RTELMEZET BE\u00c1LL\u00cdT\u00c1SOK. Gy\u0151z\u0151dj meg r\u00f3la, hogy minden helyesen van be\u00e1ll\u00edtva, k\u00fcl\u00f6nben a licit\u00e1l\u00e1s nem m\u0171k\u00f6dik.",
Kd:"Hozz\u00e1adhatsz t\u00e9teleket a piac keres\u00e9s\u00e9hez \u00e9s az aukci\u00f3hoz. Amikor egy t\u00e9telt hozz\u00e1ad a list\u00e1hoz, a piac lila t\u00e9teleket is megjelen\u00edti. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, az al\u00e1bbi opci\u00f3kat haszn\u00e1lhatod",Bk:"\u00d3vatosan haszn\u00e1ld az aukci\u00f3t!",Ck:"Az aut\u00f3matikus licit\u00e1l\u00e1s t\u00fal sok k\u00e9r\u00e9st k\u00fcldhet a szerverre, \u00e9s kitilthatj\u00e1k, ha folyamatosan haszn\u00e1lod!",
hh:"\u00dajra Aktiv\u00e1lja az Esem\u00e9nypontokat Rubinokkal?",ue:"Aut\u00f3matikus Olaj Enged\u00e9lyez\u00e9se",Gk:"Aut\u00f3matikus Szent Olajok Beszerz\u00e9se",Vk:"K\u00fcldet\u00e9s ellen\u0151rz\u00e9si Sebess\u00e9g",Ua:"T\u00e1madj Egyes\u00fcleti Tagokat?",Sa:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "T\u00e1mad\u00e1s" list\u00e1hoz, amikor t\u00f6bb, mint X ARANYAT rabolsz.:',Ta:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "Elker\u00fclend\u0151 T\u00e1mad\u00e1s" list\u00e1hoz, ha vesz\u00edtesz ellen\u00fck.:',
Tb:"T\u00e1mad\u00e1sok Statisztik\u00e1i",ac:"Nagyon Hossz\u00fa",Cb:"Hossz\u00fa",Kb:"K\u00f6zepes",Yb:"R\u00f6vid",bc:"Nagyon R\u00f6vid",ve:"Bel\u00e9p\u00e9s az Alvil\u00e1gba, ha az \u00c9P >",bh:"K\u00fcldet\u00e9s Ellen\u0151rz\u00e9si Sebess\u00e9g",Ug:'Az alap\u00e9rtelmezett "3x". Ha a bot probl\u00e9m\u00e1kat okoz a k\u00fcldet\u00e9sekkel, \u00e1ll\u00edtsd \u00e1t a k\u00fcldet\u00e9s sebess\u00e9g\u00e9t a szerver sebess\u00e9g\u00e9nek megfelel\u0151en.',cf:"Gy\u00f3gy\u00edt\u00f3 Kiv\u00e1laszt\u00f3 T\u00e1ska",
xe:'Ha manu\u00e1lisan friss\u00edted a pontokat, akkor kattints a fent l\u00e9v\u0151 gombra: "Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!"',Kk:"Legal\u00e1bb az egyiket enged\u00e9lyezned kell a k\u00f6vetkez\u0151k k\u00f6z\u00fcl: exped\u00edci\u00f3, dungeont, ar\u00e9n\u00e1t vagy cirkuszt, hogy elind\u00edtsd az Esem\u00e9ny Exped\u00edci\u00f3t.",eh:"Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!",mb:"Fedezze a T\u00e1rsakat?",bl:"Hagyd minden be\u00e1ll\u00edt\u00e1st letiltva, ha a csomagokban szerepl\u0151 elemekkel szeretn\u00e9l olvasztani. Azonban m\u00e9g mindig v\u00e1laszthatsz sz\u00edneket.",
Hk:"Karakter(Ki) / Zsoldos(Be)",Yk:"Mindkett\u0151t Jav\u00edtani?",cl:"Id\u0151z\u00edt\u0151k",Timers:"\u00cdrd be az egyes id\u0151z\u00edt\u0151kh\u00f6z a percek sz\u00e1m\u00e1t lent vagy hagyd az alap\u00e9rtelmezetten.",pb:"T\u00e1mad\u00e1s Statisztik\u00e1i Enged\u00e9lyez\u00e9se:",Rb:"V\u00e1lassz tartom\u00e1nyt a t\u00e1mad\u00e1shoz",Sb:"A bot v\u00e9letlenszer\u0171en t\u00e1mad a t\u00e1bl\u00e1zatban szerepl\u0151 j\u00e1t\u00e9kosok k\u00f6z\u00fcl.",rb:"Ligat\u00e1mad\u00e1sok",
ob:"Ligat\u00e1mad\u00e1s Enged\u00e9lyez\u00e9se:",Nb:"V\u00e9letlenszer\u0171 T\u00e1mad\u00e1s",Ob:"T\u00e1mad\u00e1s alacsonyt\u00f3l a magas szint\u0171 j\u00e1t\u00e9kosokig",Ak:"A bot alap\u00e9rtelmezetten elker\u00fcli az Egyes\u00fcleti tagok t\u00e1mad\u00e1s\u00e1t.",Se:"Exped\u00edci\u00f3 Helysz\u00edne:",Rd:"Aut\u00f3matikus B\u00f3nuszok Begy\u0171jt\u00e9se:",Fh:"Boss Kihagy\u00e1sa",pe:"Kazamata Helysz\u00edne:",nh:"Kazamata \u00fajrakezd\u00e9se veres\u00e9g eset\u00e9n?",ff:"Alvil\u00e1g Be\u00e1ll\u00edt\u00e1sok",
gf:"K\u00e9rlek konfigur\u00e1ld a gy\u00f3gy\u00edt\u00e1s sz\u00e1zal\u00e9kos be\u00e1ll\u00edt\u00e1sait a gy\u00f3gy\u00edt\u00e1s f\u00fcl\u00f6n, \u00e9s gy\u0151z\u0151dj meg r\u00f3la, hogy a gy\u00f3gy\u00edt\u00e1s f\u00fcl be van kapcsolva. Ha az alvil\u00e1g bel\u00e9p\u00e9se kijelentkeztet, l\u00e9pj a lobbyba, \u00e9s kapcsold be az aut\u00f3mata bejelentkez\u00e9s jel\u00f6l\u0151n\u00e9gyzetet.",df:"Alvil\u00e1g Neh\u00e9zs\u00e9g",Ud:"Aut\u00f3matikus Alvil\u00e1g Bel\u00e9p\u00e9s: / Alvil\u00e1g Mode",
Ei:"Mobiliz\u00e1ci\u00f3 haszn\u00e1lata, ha pontok = 0",Ii:"Rubinok haszn\u00e1lata?",ye:"Kil\u00e9p\u00e9s az alvil\u00e1gb\u00f3l, ha nincsenek pontok?",ri:"A bot megpr\u00f3b\u00e1lja el\u0151sz\u00f6r a Villa Medici-t haszn\u00e1lni, ha nincs, akkor gy\u00f3gy\u00edt\u00f3 italt haszn\u00e1l. Ne felejtsd el bekapcsolni a Gy\u00f3gy\u00edt\u00e1s kapcsol\u00f3t.",zi:"Az aut\u00f3matikus alvil\u00e1g bel\u00e9p\u00e9s letiltja a kazamata/ar\u00e9na/circus be\u00e1ll\u00edt\u00e1sokat az alvil\u00e1g bel\u00e9p\u00e9sekor.",
dl:"Alvil\u00e1g Gy\u00f3gy\u00edt\u00e1si Be\u00e1ll\u00edt\u00e1sok",Hi:"Villa Medici Haszn\u00e1lata?",Fi:"Gy\u00f3gy\u00edt\u00f3 Ital Haszn\u00e1lata?",dg:"INF\u00d3: A bot minden kiv\u00e1lasztott percben keresni fog piaci t\u00e9teleket, ami meg\u00e1ll\u00edthatja a t\u00e1mad\u00e1st a keres\u00e9s alatt.",te:"Piaci Keres\u00e9s Enged\u00e9lyez\u00e9se:",eg:"Piaci Keres\u00e9s Id\u0151k\u00f6z Percekben:",fg:"Javasolt 10 perc.",rf:"T\u00e9tel Be\u00e1ll\u00edt\u00e1sok:",pf:"T\u00e9tel N\u00e9v Tartalmazza",
G:"Max \u00c1r",sf:"T\u00e9tel T\u00edpus",qf:"T\u00e9tel Ritkas\u00e1g",ce:"L\u00e9lekhez k\u00f6t\u00f6ttet v\u00e1s\u00e1roljon?",uf:"V\u00e1s\u00e1roland\u00f3 T\u00e9telek",tf:"Megpr\u00f3b\u00e1lja megvenni a t\u00e1sk\u00e1ban l\u00e9v\u0151 legnagyobb \u00e1ron tal\u00e1lhat\u00f3 t\u00e9telt, ha b\u00e1rmelyik megegyezik a maxim\u00e1lis \u00e1r be\u00e1ll\u00edt\u00e1ssal.:",ae:"Megv\u00e1s\u00e1rolt T\u00e9telek:",hj:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",wk:"\u00c9tel V\u00e1s\u00e1rl\u00e1sa a Boltb\u00f3l?",
xk:"Gy\u00f3gy\u00edt\u00f3 eszk\u00f6z haszn\u00e1lata a Csomagb\u00f3l?",tk:"Cervisia haszn\u00e1lata?",vk:"Toj\u00e1sok haszn\u00e1lata?",Bl:"Utols\u00f3 Haszn\u00e1lat",location:"Helysz\u00edn",Strength:"Er\u0151",Dexterity:"\u00dcgyess\u00e9g",Agility:"F\u00fcrges\u00e9g",Constitution:"Alkat",Charisma:"Karizma",Intelligence:"Intelligencia",mi:"Gyakorl\u00e1s Be\u00e1ll\u00edt\u00e1sok",ni:"V\u00e1laszd ki az attrib\u00fatumokat, amiket szeretn\u00e9l edzeni. Akkor fogja elkezdeni az edz\u00e9st, ha van el\u00e9g aranyad.",
N:"K\u00f6vetkez\u0151 l\u00e9p\u00e9s",vj:"Nem",wj:"Norm\u00e1l",Fl:"Ellens\u00e9g",Gl:"Ellens\u00e9g Szintje",Ij:"K\u00e9rd\u00e9sek",random:"V\u00e9letlenszer\u0171",Pl:"Be\u00e1ll\u00edt\u00e1sok",$l:"Hamarosan...",type:"Kattints az ikonokra a k\u00e9rd\u00e9s t\u00edpus\u00e1nak kiv\u00e1laszt\u00e1s\u00e1hoz.",fm:"Igen",A:"Aukci\u00f3/Keres\u00e9s",Cd:"T\u00e9telek Hozz\u00e1ad\u00e1sa",qk:"Fejleszt\u0151t\u00e1rgyak Aut\u00f3matikus T\u00e1rol\u00e1sa",am:"Elk\u00fcld\u00e9s",zl:"Id\u0151k\u00f6z : ",
ol:"Aut\u00f3matikus Licit Enged\u00e9lyez\u00e9se",pl:"Ne licit\u00e1ljon, ha az Egyes\u00fcleti tag m\u00e1r licit\u00e1lt",cm:"\u00datmutat\u00f3",hc:"V\u00e1lassz a fenti gombok k\u00f6z\u00fcl, hogy akarod-e az ar\u00e9n\u00e1ban a legkisebb vagy a legmagasabb szint\u0171 ellenfelet. T\u00f6bb felhaszn\u00e1l\u00f3 lass\u00edthatja a bot m\u0171k\u00f6d\u00e9s\u00e9t.",hl:"Kezdetnek adj hozz\u00e1 egy t\u00e9telt a list\u00e1hoz (pl. `Lucius`). Miut\u00e1n hozz\u00e1adtad, a bot keresni fogja a t\u00e1rgyakat \u00e9s megjelen\u00edti a keres\u00e9si eredm\u00e9nyeket a k\u00e9perny\u0151 bal oldal\u00e1n. Az aut\u00f3matikus aukci\u00f3 c\u00e9lj\u00e1b\u00f3l is keressen r\u00e1 a t\u00e1rgyra. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, a bot rendszeres id\u0151k\u00f6z\u00f6nk\u00e9nt keresni fogja a t\u00e9teleket a megadott id\u0151szak alapj\u00e1n. Ha a bot megtal\u00e1lja a t\u00e1rgyat \u00e9s van el\u00e9g p\u00e9nzed, aut\u00f3matikusan licit\u00e1l majd helyetted. *Megjegyz\u00e9s*: egyedi t\u00e1rgyak keres\u00e9s\u00e9hez a boltban legal\u00e1bb 1 v\u00e9letlenszer\u0171 t\u00e1rgyat hozz\u00e1 kell adnod a keres\u00e9si list\u00e1hoz.",
rl:"A sz\u00f6rny sz\u00e1m\u00e1t a fenti gombok k\u00f6z\u00fcl v\u00e1laszthatod ki. A 1 a legbaloldali sz\u00f6rnyet k\u00e9pviseli. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",Yi:"V\u00e1lassz nehezs\u00e9get a kazamat\u00e1hoz a fentiek k\u00f6z\u00fcl. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",ij:"Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sok",
Zi:"Felesleges arany t\u00e1rol\u00e1sa az egyes\u00fcletben az egyes\u00fcleti piacon t\u00e1rgyak v\u00e1s\u00e1rl\u00e1s\u00e1val. -> Min. Arany",Cl:"Mindent Mozgat",Dl:"Kijel\u00f6ltek Mozgat\u00e1sa",kl:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s",ll:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",em:"Rubin",Lg:"\u00c1ltal\u00e1nos Be\u00e1ll\u00edt\u00e1sok",Mj:"Mindent Elad",Nj:"Kijel\u00f6ltek Elad\u00e1sa",ga:"Fegyverek",da:"Pajzsok",W:"Mellv\u00e9rtek",Z:"Sisakok",Y:"Keszty\u0171k",
ea:"Cip\u0151k",ca:"Gy\u0171r\u0171k",V:"Amulettek",Ci:"\u00c9telek",Bi:"Fejleszt\u00e9sek",dh:"Receptek",sg:"Tekercsek",fh:"Er\u0151s\u00edt\u00e9sek",Zg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",Yg:"\u00cdrja be a sz\u0171rend\u0151 kulcsszavakat, hogy kisz\u0171rje azokat a k\u00fcldet\u00e9seket, amelyeket nem szeretne v\u00e1llalni. You can also use this to accept quests by their reward using keywords.",X:"Adjon meg kulcssz\u00f3t",K:"Hozz\u00e1ad\u00e1s",gh:"Elt\u00e1vol\u00edt\u00e1s",
fe:"T\u00f6rl\u00e9s",Wg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Elfogad\u00e1sa",Xg:"\u00cdrja be a kulcsszavakat, hogy kiv\u00e1lassza, melyik k\u00fcldet\u00e9seket szeretn\u00e9 v\u00e1llalni. Ez figyelmen k\u00edv\u00fcl hagyja a k\u00fcldet\u00e9st\u00edpusokat",Ea:"Id\u0151 Sz\u0171r\u00e9s\u0171 K\u00fcldet\u00e9sek Kihagy\u00e1sa?",Wk:"K\u00fcldet\u00e9sek",Sd:"Automatikus Kost\u00fcm",Di:"Kost\u00fcm Haszn\u00e1lata?",Xd:"Alap Harc",oe:"Dungeoni Harc",Td:"A Bot csak akkor viseli a Dis Pater Normal \u00e9s Medium form\u00e1tumot, ha az exped\u00edci\u00f3/kazamata pontja 0.",
ef:"Pokoli Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sai",Jd:"T\u00e1mad\u00e1s a F\u0151ellens\u00e9g el\u00e9rhet\u0151v\u00e9 v\u00e1l\u00e1sakor?",sb:"Az Ligat\u00e1mad\u00e1s \u00f6nmag\u00e1t letiltja 5 sikertelen t\u00e1mad\u00e1s ut\u00e1n.",hf:"Szent Olajok",Ag:"T\u00e1rgy Neve",ba:"Minim\u00e1lis T\u00e1rgyszint",Ba:"Minim\u00e1lis T\u00e1rgymin\u0151s\u00e9g",Id:"Alkalmaz/T\u00f6r\u00f6l Minut\u00e9ri\u00e1t",lf:"El\u0151tag/Ut\u00f3tag Kombin\u00e1ci\u00f3 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
Ki:"Igen",Hg:"Nem",Qa:"El\u0151tag Hozz\u00e1ad\u00e1sa",Ra:"Ut\u00f3tag Hozz\u00e1ad\u00e1sa",Hh:"Olvasd el a List\u00e1t",Mb:"El\u0151tag",Zb:"Ut\u00f3tag",mh:"Lej\u00e1r\u00f3 T\u00e1rgyak Vissza\u00e1ll\u00edt\u00e1sa",Ih:"V\u00e9letlenszer\u0171 Olvasd el a Csomagokat?",Jh:"Olvasd el a Lapon",qb:"Extr\u00e1k",Nd:"\u00c1rver\u00e9s",ig:"Piac",$b:"Id\u0151z\u00edt\u0151k",hi:"Olvasd el a Minut\u00e9ri\u00e1t",gi:"Olvasd el, ha nincs el\u00e9g arany",di:"Olvasd el, ha nincs t\u00e1rgy",Fa:"Jav\u00edt\u00e1s",
Wh:"Gilda Piac Aranytartalma",Sh:"\u00c1rver\u00e9s Aranytartalma",ki:"Edz\u00e9s",Zh:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa",ii:"\u00dczletek a Kov\u00e1cshoz",Qh:"\u00c1rver\u00e9s Ellen\u0151rz\u00e9se",ai:"Keres\u00e9s",v:"Enged\u00e9lyez\u00e9s",Cg:"Minim\u00e1lis Arany",Ub:"\u00d3ra Kiv\u00e1laszt\u00e1sa",nb:"Arany Adom\u00e1nyoz\u00e1sa a Gildinek",je:"Minden 5 percenk\u00e9nt adom\u00e1nyoz. Az id\u0151z\u00edt\u0151k lapr\u00f3l m\u00f3dos\u00edthatja az id\u0151k\u00f6zt",jf:"Mennyit szeretne adom\u00e1nyozni?",
ke:"Adom\u00e1nyozni, amikor t\u00f6bb van, mint >",wf:"Kevesebb, mint <",jh:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa \u00e9s Egy\u00e9b Be\u00e1ll\u00edt\u00e1sok",lh:"Vissza\u00e1ll\u00edt\u00e1s ideje:",Qk:"Tartsa lenyomva a Ctrl (Cmd a Mac-en) billenty\u0171t a t\u00f6bb t\u00e1rgy kiv\u00e1laszt\u00e1s\u00e1hoz",mf:"Be-/Kiv\u00e1laszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Ue:"Be\u00e1ll\u00edt\u00e1sok Export\u00e1l\u00e1sa",nf:"Be\u00e1ll\u00edt\u00e1sok Import\u00e1l\u00e1sa",tg:"\u00dczenet Minden J\u00e1t\u00e9kosnak",
ug:"[Ultra Pr\u00e9mium Kulcs sz\u00fcks\u00e9ges, \u00fczenet a Discordon az kulcs megszerz\u00e9s\u00e9hez.]",vg:"Adja meg az elk\u00fcldend\u0151 \u00fczenetet",he:"Egyedi szkriptek\u00e9rt vegye fel a kapcsolatot vel\u00fcnk a Discordon",xg:"K\u00fcld\u00e9s",yg:"J\u00e1t\u00e9kosok Megjelen\u00edt\u00e9se",wg:"Mindet Kiv\u00e1laszt",zg:"\u00d6sszes Kiv\u00e1laszt\u00e1s Visszavon\u00e1sa",vf:"Gy\u0151z\u0151dj\u00f6n meg r\u00f3la, hogy van el\u00e9g hely a t\u00e1sk\u00e1j\u00e1ban. A leh\u0171l\u00e9si id\u0151 2 perc.",
mg:"\u00c9tel Elad\u00e1sa a Piacon?",Gb:"\u00c9telre V\u00e1lt\u00e1s a Piacon?"};if("true"!==localStorage.getItem("isInitialized")){const x={Timers:JSON.stringify({Smelting:10,SmeltingNoGold:5,SmeltingNoItem:15,Repair:10,GuildMarket:2,AuctionHoldGold:15,Arena:10,CircusTurma:10,Training:2,ResetExpired:30,SearchTimer:5,StoreForge:30,AuctionCheck:10,GuildDonate:15,guildBattleEnable:120,BuffTimer:5}),packagesPurchased:"[]",questKeywords:"[]",activeItems:'{"gloves":false,"shoes":false,"rings1":false,"rings2":false,"shield":false,"armor":false,"weapon":false,"helmet":false,"necklace":false}',
auctionPrefixes:"[]",auctionSuffixes:"[]",prefixes:"[]",suffixes:"[]",underworldQuestKeywords:"[]",UnderworldQuests:"false",statSettings:JSON.stringify([{stat:"Strength",count:"0",priority:null,continueTraining:!1},{stat:"Dexterity",count:"0",priority:null,continueTraining:!1},{stat:"Agility",count:"0",priority:null,continueTraining:!1},{stat:"Constitution",count:"0",priority:null,continueTraining:!1},{stat:"Charisma",count:"0",priority:null,continueTraining:!1},{stat:"Intelligence",count:"0",priority:null,
continueTraining:!1}]),farmEnable:"false",farmEnemy:"1",farmLocation:"0",HealPickBag:"1",AutoBidInterval:"5",AuctionItemLevel2:"0",HealShop:"false",noItemsLastCheck:"false",dungeonFocusQuest:"false",smeltBlue:"false",smeltGreen:"false",HealClothToggle:"false",questrewardvalue:"2000",smeltOrange:"false",smeltRed:"false",auctionTURBO:"false",smeltusehammers:"false",BuffsEnable:"false",repairPercentage:"10",HealRubyToggle:"false",dungeonLocation:"0",costumeBasic:"1",costumeDungeon:"2",smeltAnything:"false",
skipTimeQuests:"false",skipTimeCircusQuests:"false",costumeUnderworld:"9",wearUnderworld:"false",hellDifficulty:"1",repairMaxQuality:"1",FoodAmount:"3",smeltIgnorePS:"false",EnableSmelt:"false",filterGM:"p","AuctionEmpty.timeOut":"0","BuffCheck.timeOut":"0","CheckDolls.timeOut":"0","AuctionMEmpty.timeOut":"0",expeditionLocation:"0",auctionMinQuality:"0",doQuests:"false",unique_shop_results_height:"124",unique_shop_results_width:"184",unique_shop_results_top:"452",unique_shop_results_left:"368",search_results_top:"112",
search_results_width:"179",search_results_height:"284",search_results_left:"410",itemBought:"false",itemMovedToInventory:"false",AucTab:"true",patmp:"false",arenaPlayer:"true",repairInitiated:"true",doKasa:"false",packages:JSON.stringify({quality:[],type:[1,2,3,4,5,8,6,9,7,12,13,15,19,20,11,21,18,14,99]}),delaySelect:"0",autoAttackList:"[]",avoidAttackList:"[]",autoAttackCircusList:"[]",avoidAttackCircusList:"[]",autoAttackServerList:"[]",removeCircusList:"[]",removeArenaList:"[]",arenacrosslist:"[]",
circuscrosslist:"[]",autoAttackCircusServerList:"[]",doArena:"false",doCircus:"false","gladBotChecks.timeOut":"0","repair.timeOut":"0","storeForgeResources.timeOut":"0",HealCervisia:"false",dungeonAB:"false",bidStatus:"4",doDungeon:"false",doExpedition:"false",arenaAttackGM:"false",circusAttackGM:"false",AutoAuction:"false",auctionminlevel:"0",storeGoldinAuctionmaxGold:"0",storeGoldinAuction:"false",autoAddArenaAmount:"0",autoAddCircusAmount:"0",eventPoints_:"16",storeGoldinAuctionholdGold:"0",TrainingHoldGold:"0",
smeltLevel:"1",MarketHoldGold:"0",KasaHoldGold:"0",HealPackage:"false",smeltPurple:"false",guildPackHour:"3",smeltEverything3:"false",questSpeed:"2","enableHideGold.timeOut":"0",bidFood:"false",auctionmercenaryenable:"false",auctiongladiatorenable:"false",maximumBid:"100000",activateAuction2:"false",scoreboardattackenable:"false",scoreRange:"5",auctionlanguagesettings:JSON.stringify(["Very long","Long","Middle","Short","Very short"]),scoreboardcircusenable:"false",healPercentage:"25",hellEnterHP:"75",
questTypes:JSON.stringify({combat:!0,arena:!0,circus:!0,expedition:!1,dungeon:!1,items:!1}),scoreRangeCircus:"5",underworld:JSON.stringify({cooldown:"",wins:0,isUnderworld:!1,oj:!1}),enableMarketSearch:"false",smeltTab:"1",UnderWorldUseRuby:"false",renewEvent:"false","arena.timeOut":"0","circus.timeOut":"0",AuctionCover:"false",AuctionGoldCover:"false",UnderworldUseMobi:"false",MarketSearchInterval:"5",useVillaMedici:"false",autoEnterHell:"false",useHealingPotion:"false",repairMercenary:"false",repairALL:"false",
AutoBidButton:"false",healstopbot:"false",HealEnabled:"false",minimumGoldAmount:"100000",doEventExpedition:"false",GuildMemberBid:"false",autoCollectBonuses:"false",exitUnderworld:"false",workbench_selectedItem:JSON.stringify({})};Object.keys(x).forEach(N=>{null===localStorage.getItem(N)&&localStorage.setItem(N,x[N])});["license_playerId","eventPoints","playerTimeouts"].forEach(N=>{null!==localStorage.getItem(N)&&localStorage.removeItem(N)});localStorage.setItem("isInitialized","true")};
