var we="",showTrial="";const aa={player:{key:"",mq:0,Fd:"",supportDevelopersPlease:"",language:"en"},$m:{iq:!1,Tp:!1,wins:0},Dd:{Fn:!1},workbench:{enable:!1,Vp:10,pq:1,repairArena:!0,repairTurma:!0,itemList1:[],itemList2:[]},packages:{type:[],quality:[],Oq:!1,useCloths:!1},H:{enable:!1,un:!1,Qn:[1],Uo:3,ro:3,Ro:3,To:3,bo:3,kp:3},Kp:{}};function F(G){let M=`${window.location.origin}/game/index.php?`;Object.entries(G).forEach((N,U)=>{M+=(0==U?"":"&")+N[0]+"="+N[1]});return M}
function T(G){let M=`${window.location.origin}/game/ajax.php?`;Object.entries(G).forEach((N,U)=>{M+=(0==U?"":"&")+N[0]+"="+N[1]});return M}async function ea(G,M){M=await ha(G,M);if(!M)return!1;M.slot&&ia(M.slot,G.dataset.itemId||G.parentNode.dataset.containerNumber);sa(G,M.x,M.y);return!0}
async function ua(G,M){var N=document.getElementById("inv");if(N&&M){var U=M.x;M=M.y;(N=jQuery(N).offset())?(U=Math.ceil(N.left+32*U+16),M=Math.ceil(N.top+32*M+16),console.log(`Dragging item to: x=${U}, y=${M}`),sa(G,U,M)):console.error("Grid offset could not be determined.")}else console.error("Invalid target grid or slot coordinates.")}
async function sa(G,M,N){var U=jQuery(G).offset();U={x:U.left,y:U.top};wa(G,"mousedown",{clientX:U.x-window.scrollX,clientY:U.y-window.scrollY});wa(document,"mousemove",{clientX:M-window.scrollX,clientY:N-window.scrollY});wa(document,"mouseup",{clientX:M-window.scrollX,clientY:N-window.scrollY});setTimeout(()=>{window.scroll(scroll.x,scroll.y)},0)}function Ba(G){G=G.getAttribute("data-quality");return null!=G?G:"0"}function Ca(G){return Ea(G).split("-")[0]}
function Sa(G){return parseInt(G.getAttribute("data-amount"),10)}function ub(G){return G.getAttribute("data-content-type")}function vb(G){return G.getAttribute("data-level")}function Ea(G){return G.getAttribute("data-basis")}
function wb(G,M){var N=[248,284,275,269,283,282,272,194,259,261,241,166,266,246,258,277,247,270,202,243,242,279,254,274,256,245,250,268,244,281,257,263,278,276,289,262,280,286,267,271,252,255,288,260,264,265];G=parseInt(G.split("-")[0],10);if(![1,2,3,4,5,6,8,9,20].includes(G))return!1;M=M.split("-");G=parseInt(M[6],36);return-1<[173,156,158,182,175,168,180,178,177,162,179,174,172,155,171,183,167,159,166,176,164,157,181,169,161,163,165].indexOf(parseInt(M[5],36))||-1<N.indexOf(G)}
function Fb(G){return parseInt(G.getAttribute("data-measurement-x"),10)*parseInt(G.getAttribute("data-measurement-y"),10)}function Gb(G){G=G.getAttribute("data-tooltip");G=G.substring(4,G.indexOf(",")).replace('"',"");return unescape(JSON.parse('"'+G+'"'))}function Hb(G){G=G.getAttribute("data-tooltip");return parseInt(G.replace(/\./g,"").match(/(\d+) (<img|<div class=\\"icon_gold\\")/i)[1],10)}
function Yb(G){G=parseInt(G.getAttribute("data-basis").split("-")[0],10);return-1<[1,2,3,4,5,6,8,9].indexOf(G)}function Zb(G){for(var M=0,N=0;N<G.length;N++){var U=G[N];M+=U.sl*U.w}return M}function $b(G){if("string"!==typeof G)return"";G=G.split(" ");return G[G.length-1]}
async function ac(G,M,N){return new Promise(U=>{async function V(Aa){Aa===D.length&&V(Aa+1);await jQuery.post(D[Aa],ta=>{ta=jQuery("<div>").append(ta)[0];ta=bc(ta);ta=cc(oa[0],oa[1],ta);(ta=lc(M,G,ta))?(U({spot:ta,bag:Aa+512}),N&&"function"===typeof N&&N(ta,Aa+512)):V(Aa+1)})}let D=[];for(var ka of[512,513,514,515])D.push(T({mod:"inventory",submod:"loadBag",shopType:0,bag:ka,sh:W("sh")}));let oa=[5,8];V(0)})}var Fc=[],Gc={};
function ia(G,M){if("inv"==G.target||"shop"==G.target){var N=Hc(G.target),U=[];for(let V=0;V<G.w;V++)for(let D=0;D<G.sl;D++)U.push(N+"<"+(G.x+V)+","+(G.y+D)+">");U.forEach(V=>{Fc.includes(V)||Fc.push(V)});M&&(Ic(M),Gc[M]=U)}}function Ic(G){G&&Gc.hasOwnProperty(G)&&(Gc[G].forEach(M=>{M=Fc.indexOf(M);-1<M&&Fc.splice(M,1)}),delete Gc[G])}
function Hc(G){let M=document.getElementById(G);return M?"inv"==G?M.parentNode.getElementsByClassName("awesome-tabs current")[0].dataset.Gp:"inv"==G?M.dataset.containerNumber:G:G}
function Jc(G,M){var N=G.querySelectorAll('.ui-draggable:not([style*="display: none"])');G=Array(5).fill(null).map(()=>Array(8).fill(!1));const U=parseInt(M.getAttribute("data-measurement-x"),10);M=parseInt(M.getAttribute("data-measurement-y"),10);for(var V of N){N=parseInt(V.getAttribute("data-position-x"),10)-1;var D=parseInt(V.getAttribute("data-position-y"),10)-1,ka=parseInt(V.getAttribute("data-measurement-x"),10),oa=parseInt(V.getAttribute("data-measurement-y"),10);for(let Aa=0;Aa<ka;Aa++)for(let ta=
0;ta<oa;ta++)0<=N+Aa&&8>N+Aa&&0<=D+ta&&5>D+ta&&(G[D+ta][N+Aa]=!0)}for(V=0;5>V;V++)for(N=0;8>N;N++){D=!0;for(ka=0;ka<U;ka++){for(oa=0;oa<M;oa++)if(8<=N+ka||5<=V+oa||G[V+oa][N+ka]){D=!1;break}if(!D)break}if(D)return{x:N,y:V}}return null}
async function ha(G,M){if("shop"==M){var N=document.getElementById("shop");var U=[Math.round(N.clientHeight/32),6]}else if("inv-guild"==M)Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));else if("inv"==M)N=document.getElementById("inv"),U=[5,8];else{if("market"==M){N=document.getElementById("market_sell");var V=jQuery(N).offset();return{x:Math.ceil(V.left+32+8),y:Math.ceil(V.top+32+8),parent:N}}if("avatar"==M)return N=document.getElementById("avatar"),
V=jQuery(N).offset(),{x:Math.ceil(V.left+84),y:Math.ceil(V.top+97),parent:N};if("char"==M)for(var D=document.getElementById("char").children,ka=Number(G.dataset.contentType||"0"),oa=0;oa<D.length;oa++){var Aa=D[oa];if(Number(Aa.getAttribute("data-content-type-accept")||"0")==ka&&0==D[oa].children.length)return V=jQuery(Aa).offset(),{x:V.left+5,y:V.top+5}}else return!1}D=bc(N);ka=parseInt(G.dataset.measurementX,10);oa=parseInt(G.dataset.measurementY,10);try{var ta="shop"!=M&&kf(G,D)||lc(oa,ka,cc(U[0],
U[1],D));if(!ta)return!1;V=jQuery(N).offset();V={x:V.left,y:V.top};return ta={x:Math.ceil(V.x+32*ta.x+8),y:Math.ceil(V.y+32*ta.y+8),parent:N,slot:{target:M,x:ta.x,y:ta.y,sl:oa,w:ka}}}catch{return!1}}
function bc(G){if(!G)return[];var M=[];G=G.getElementsByClassName("ui-draggable");for(var N=0;N<G.length;N++)M.push({y:parseInt(G[N].style.top,10)/32,x:parseInt(G[N].style.left,10)/32,sl:parseInt(G[N].dataset.measurementY,10),w:parseInt(G[N].dataset.measurementX,10),basis:G[N].dataset.basis,hash:G[N].dataset.hash,amount:parseInt(G[N].dataset.amount,10)});return M}
function cc(G,M,N){var U,V,D=[];for(U=0;U<G;U++)for(D.push([]),V=0;V<M;V++)D[U].push(!1);for(G=N.length-1;0<=G;G--)for(U=0;U<N[G].sl;U++)for(V=0;V<N[G].w;V++)D[N[G].y+U][N[G].x+V]=!0;return D}function kf(G,M){let N=G.dataset.amount?parseInt(G.dataset.amount,10):1;for(var U=0;U<M.length;U++)if(M[U].hash==G.dataset.hash&&100>=M[U].amount+N)return{y:M[U].y,x:M[U].x};return!1}
function lc(G,M,N){var U,V,D,ka,oa=!1;for(U=0;U<=N[0].length-M;U++){for(V=0;V<=N.length-G;V++){if(oa=!0,1==G)0==N[V][U]?oa=!0:0==N[V][U+1]?U++:oa=!1;else for(D=0;D<M;D++){for(ka=0;ka<G;ka++)if(1==N[V+ka][U+D]){oa=!1;break}if(!oa)break}if(oa){for(D=0;D<M;D++)for(ka=0;ka<G;ka++)N[V+ka][U+D]=!0;oa={y:V,x:U};break}}if(oa)break;1==G&&U++}return oa}
function wa(G,M,N){var U="mousemove"!==M,V=window;var D=N.clientX;N=N.clientY;var ka=document.createEvent("MouseEvents");ka.initMouseEvent(M,!0,U,V,0,0,0,D,N,!1,!1,!1,!1,0,document.body.parentNode);G.dispatchEvent(ka)}
function lf(){new Promise(G=>{let M=2,N=()=>{--M;0===M&&G()};if(mf.includes("mod=auction")&&mf.includes("ttype=3")){var U=nf();(U<localStorage.getItem("auctionMStatus")&&of("AuctionMEmpty")||4===U&&of("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",U);N()}else mf.includes("mod=auction")?(U=nf(),(U<localStorage.getItem("auctionStatus")&&of("AuctionEmpty")||4===U&&of("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",0),localStorage.setItem("auctionStatus",
U),N()):(jQuery.get(F({mod:"auction",ttype:3,itemLevel:999,itemQuality:2,sh:W("sh")}),V=>{V=nf(jQuery(V));(V<localStorage.getItem("auctionMStatus")&&of("AuctionMEmpty")||4===V&&of("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",V);N()}),jQuery.get(F({mod:"auction",itemLevel:999,itemQuality:2,sh:W("sh")}),V=>{V=nf(jQuery(V));(V<localStorage.getItem("auctionStatus")&&of("AuctionEmpty")||4===V&&of("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",
0);localStorage.setItem("auctionStatus",V);N()}))})}function pf(G){if(document.querySelector("#inv div.spinner-img"))return setTimeout(()=>{pf(G)},500),!1;G&&G();return!0}var qf=new URLSearchParams(window.location.search);function W(G){return qf.get(G)}
var mf=window.location.search.match(/mod=.*&sh/)?window.location.search.match(/mod=.*&sh/)[0].slice(0,-3):null,Cf=window.location.hostname.split(/\./)?window.location.hostname.split(/\./)[0]:null,Df={Aq:{l:"muito longo",h:"longo",i:"m\u00e9dio",j:"curto",m:"muito curto"},Bq:{l:"foarte lung",h:"lung",i:"mijlociu",j:"scurt",m:"foarte scurt"},Gq:{l:"ve\u013emi dlho",h:"dlho",i:"stredne",j:"kr\u00e1tko",m:"ve\u013emi kr\u00e1tko"},Rq:{l:"jako dugo",h:"dugo",i:"srednje",j:"kratko",m:"jako kratko"},Wp:{l:"hyvin pitk\u00e4",
h:"pitk\u00e4",i:"keskim\u00e4\u00e4r\u00e4inen",j:"lyhyt",m:"hyvin lyhyt"},Dq:{l:"mycket l\u00e5ng",h:"l\u00e5ng",i:"medel",j:"kort",m:"mycket kort"},Jq:{l:"\u00e7ok uzun",h:"uzun",i:"orta",j:"k\u0131sa",m:"\u00e7ok k\u0131sa"},Bp:{l:"\u0637\u0648\u064a\u0644 \u062c\u062f\u0627\u064b",h:"\u0637\u0648\u064a\u0644",i:"\u0645\u0646\u062a\u0635\u0641",j:"\u0642\u0635\u064a\u0631",m:"\u0642\u0635\u064a\u0631\u0629 \u062c\u062f\u0627\u064b"},hq:{l:"\u05d0\u05e8\u05d5\u05da \u05de\u05d0\u05d5\u05d3",h:"\u05d0\u05e8\u05d5\u05da",
i:"\u05d1\u05d9\u05e0\u05d5\u05e0\u05d9",j:"\u05e7\u05e6\u05e8",m:"\u05e7\u05e6\u05e8 \u05de\u05d0\u05d5\u05d3"},gr:{l:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",h:"\u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",i:"m\u03ad\u03c3\u03b7",j:"\u03bc\u03b9\u03ba\u03c1\u03ae",m:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b9\u03ba\u03c1\u03ae"},Hp:{l:"\u043c\u043d\u043e\u0433\u043e \u0434\u044a\u043b\u044a\u0433",h:"\u0434\u044a\u043b\u044a\u0433",i:"\u0441\u0440\u0435\u0434\u0435\u043d",j:"\u043a\u044a\u0441",
m:"\u043c\u043d\u043e\u0433\u043e \u043a\u044a\u0441"},Cq:{l:"\u043e\u0447\u0435\u043d\u044c \u043c\u043d\u043e\u0433\u043e",h:"\u043c\u043d\u043e\u0433\u043e",i:"\u0441\u0440\u0435\u0434\u043d\u0435",j:"\u043c\u0430\u043b\u043e",m:"\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e"},Ip:{l:"muito tempo",h:"longo",i:"m\u00e9dio",j:"curto",m:"bastante curto"},Np:{l:"velmi dlouh\u00e1",h:"dlouh\u00e1",i:"st\u0159edn\u00ed",j:"kr\u00e1tk\u00e1",m:"velmi kr\u00e1tk\u00e1"},Pp:{l:"meget lang tid",
h:"lang tid",i:"halv tid",j:"kort tid",m:"meget kort tid"},Op:{l:"sehr lange",h:"lange",i:"mittel",j:"kurz",m:"sehr kurz"},Qp:{l:"v\u00e4ga pikk",h:"pikk",i:"keskmine",j:"l\u00fchike",m:"v\u00e4ga l\u00fchike"},Rp:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},Nq:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},Dp:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},Up:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},sq:{l:"muy largo",h:"largo",i:"medio",
j:"corto",m:"muy corto"},Xp:{l:"tr\u00e8s longtemps",h:"longtemps",i:"moyen",j:"court",m:"tr\u00e8s court"},lq:{l:"lunghissima",h:"lunga",i:"media",j:"breve",m:"brevissima"},oq:{l:"\u013coti gar\u0161",h:"gar\u0161",i:"vid\u0113js",j:"\u012bss",m:"\u013coti \u012bss"},nq:{l:"labai ilgai",h:"ilgai",i:"vidutini\u0161kai",j:"trumpai",m:"labai trumpai"},gq:{l:"nagyon hossz\u00fa",h:"hossz\u00fa",i:"k\u00f6zepes",j:"r\u00f6vid",m:"nagyon r\u00f6vid"},tq:{l:"heel lang",h:"lang",i:"gemiddeld",j:"kort",m:"zeer kort"},
vj:{l:"veldig lenge",h:"lenge",i:"medium",j:"kortvarig",m:"veldig kort"},zq:{l:"bardzo d\u0142ugi",h:"d\u0142ugi",i:"\u015bredni",j:"kr\u00f3tki",m:"bardzo kr\u00f3tki"},Lq:{l:"\u8d85\u9577",h:"\u8f03\u9577",i:"\u5e38\u898f\u6642\u9593",j:"\u8f03\u77ed",m:"\u8d85\u77ed"}},nf=(G=document)=>{G=jQuery(".description_span_right",G).text().trim().toLowerCase();for(const M in Df){const N=Df[M],U=Object.values(N);for(const V in N)if(N[V].toLowerCase()===G)return U.indexOf(N[V])}return-1};
async function Ef(G="-1",M=""){const N=F({mod:"packages",submod:"sort",page:"1",sh:W("sh")});jQuery.post(N,{packageSorting:"in_desc"});return Promise.all(Array.from({length:2},(U,V)=>V+1).map(async U=>await Ff(G,M,U))).then(U=>U.reduce((V,D)=>V.concat(D),[]))}async function Ff(G="-1",M="",N){G=await jQuery.get(F({mod:"packages",f:"0",fq:G||-1,qry:M||"",page:N,sh:W("sh")}),()=>{});return Array.from(jQuery(G).find(".packageItem"))}function Gf(G){setTimeout(()=>{window.location.reload(!1)},G)}
function Hf(G){window.location.href=`${window.location.origin}/game/index.php?${G}&sh=${W("sh")}`}function Eh(G){G&&(G.classList.contains("disabled")?window.location.reload():G.click())}
function Fh(){return{o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,"")),xo:document.querySelectorAll("#cooldown_bar_expedition .cooldown_bar_fill_ready")[0],vo:document.querySelectorAll("#cooldown_bar_dungeon .cooldown_bar_fill_ready")[0],Kq:document.querySelectorAll("#cooldown_bar_ct .cooldown_bar_fill_ready")[0],Ha:document.getElementById("expeditionpoints_value_point").innerText,uo:document.getElementById("dungeonpoints_value_point").innerText,
Ep:document.querySelectorAll("#cooldown_bar_arena .cooldown_bar_fill_ready")[0],Ln:parseInt(document.getElementById("sstat_ruby_val").innerText,10),level:parseInt(document.getElementById("header_values_level").innerText,10)}}function of(G){let M=(new Date).getTime(),N=localStorage.getItem(G+".timeOut");null===N?(localStorage.setItem(G+".timeOut",0),N=0):N=parseInt(N,10);return N<=M?!0:!1}
function Gh(){let G=0;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(M=>{G+=Math.round(.04*M.price)});return Fh().gold>=G?!0:!1}function Hh(G,M){M-=G;let N=.04*G;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(U=>{N+=Math.round(.04*U.price)});return M>=N}function Y(G,M){localStorage.setItem(G+".timeOut",(new Date).getTime()+Math.floor(6E4*(M?M:5)))};(async function(){function G(){const b=document.getElementById("mainnav");return b?!!b.querySelector('a[href*="mod=dungeon"], a[href*="submod=showDungeons"]'):!1}function M(){var b=document.getElementById("mainnav");return b?b.querySelector('a[href*="submod=showExpeditions"]')||(b=b.querySelector('a[href*="mod=location&loc="]'))&&(b=b.getAttribute("href").match(/loc=([^&]+)/))&&!isNaN(parseInt(b[1],10))?!0:!1:!1}function N(){var b=document.getElementById("mainnav");if(!b)return!1;b=b.querySelector('a[href*="mod=location&loc="]');
return b?(b=b.getAttribute("href").match(/loc=([^&]+)/))?isNaN(parseInt(b[1],10)):!1:!1}function U(){rf=setInterval(function(){sf++;5>=sf?location.reload():clearInterval(rf)},12E4)}function V(){var b="Pantheon;Panteon;Gudarnas tempel;\u0628\u0627\u0646\u062a\u064a\u0648\u0646;\u041f\u0430\u043d\u0442\u0435\u043e\u043d;Panth\u00e9on;\u795e\u8aed;\u05e4\u05e0\u05ea\u05d9\u05d0\u05d5\u05df".split(";"),c=null;for(var e of b)if(c=document.querySelector(`a[title="${e}"]`))break;return c&&(b=c.innerHTML,
(e=b.match(/<font color="green">(\d+)<\/font>/))&&0<e[1]||b.includes('color="green"')||b.includes("Nowe")||b.includes("Yeni")||b.includes("New")||b.includes('color="yellow"')||b.includes("Yeni")||b.includes("Nowe")||b.includes("New")||(c=c.innerText.match(/Pantheon \((\d+)\)/))&&0<c[1])?(localStorage.setItem("nextQuestTime",0),localStorage.setItem("nextQuestTime.timeOut",0),!0):!1}function D(b){function c(h){let l=localStorage.getItem(h);l&&(l=JSON.parse(l),localStorage.setItem(h,JSON.stringify(l.slice(-20))))}
var e=document.querySelector("#logEntriesContainer");if(e){var g=new Date,k=`${g.getHours().toString().padStart(2,"0")}:${g.getMinutes().toString().padStart(2,"0")}`;g=document.createElement("p");g.style.margin="0";g.style.padding="0";g.style.fontSize="12px";b=`[${k}] ${b}`;g.textContent=b;e.prepend(g);(e=localStorage.getItem("savedLogs"))?e=JSON.parse(e):e=[];e.unshift(b);30<e.length&&e.pop();localStorage.setItem("savedLogs",JSON.stringify(e));c("bidList");c("smeltedItems");c("MarketboughtItems")}}
function ka(b,c){switch(b){case "itemRepaired":na.Rm++;break;case "itemReset":na.Sm++;break;case "goldCycled":na.Pm++;break;case "arenaAttacks":na.Dm++;break;case "circusAttacks":na.Gm++;break;case "dungeonAttacks":na.Jm++;break;case "expeditionAttacks":na.Lm++;break;case "itemSmelted":na.Tm++;break;case "underworldAttacks":na.an++;break;case "arenaMoney":na.nm+=c;break;case "circusMoney":na.om+=c}localStorage.setItem("userStats",JSON.stringify(na))}function oa(){fb||(fb=document.createElement("div"),
fb.className="confirmation-popup",fb.innerHTML='\n                <p>Are you sure you want to reset the bot?</p>\n                <button id="confirmReset">Yes</button>\n                <button id="cancelReset">No</button>\n            ',document.body.appendChild(fb),document.getElementById("confirmReset").addEventListener("click",function(){const b=["tkz_lcr","Username","tkn","nana_lcn"];let c=[];for(let e=0;e<localStorage.length;e++){const g=localStorage.key(e);!g||b.includes(g)||g.startsWith("gladiatusCrazyAddonData_")||
c.push(g)}for(const e of c)localStorage.removeItem(e);window.location.reload();fb.style.display="none"}),document.getElementById("cancelReset").addEventListener("click",function(){fb.style.display="none"}));fb.style.display="block"}function Aa(b,c){return null==b?"":b.split("").map(e=>String.fromCharCode(e.charCodeAt(0)+c)).join("")}async function ta(b,c,e,g){g=Aa(g,3);const k={action:"vx",data:{token:b,refreshToken:c,playerId:e,Sp:g}};try{const h=await Promise.race([new Promise((l,q)=>{chrome.runtime.sendMessage(k,
n=>{chrome.runtime.Po||!n?q(chrome.runtime.Po||"No response"):l(n)})}),new Promise(l=>setTimeout(()=>l("timeout"),6E4))]);if("timeout"===h)await new Promise(l=>setTimeout(l,1E3)),window.location.reload();else if(h.success||h.s){const l=h.data||h.d;if(l.valid&&!l.expired)return aa.player.key=l.playerId,aa.player.supportDevelopersPlease=l.supportDevs,"true"!==localStorage.getItem("nana_lcn")&&localStorage.setItem("nana_lcn","true"),l.announcement&&0<=l.announcement.length&&localStorage.getItem("latestAnnouncement")!==
l.announcement&&localStorage.setItem("latestAnnouncement",l.announcement),await Ph(l.supportDevs).then(q=>{aa.player.Fd=q}),!0;if(l.expired&&(sessionStorage.setItem("autoGoActive","false"),l.newToken))return l.newToken&&(localStorage.setItem("token",l.newToken+1),localStorage.setItem("nana_lcn","false"),aa.player.key=dc()+"l",gb()),!1}else new Promise(l=>setTimeout(()=>l("timeout"),3E4))}catch(h){return window.location.reload(),!1}}function Qh(b){return((localStorage.getItem("playerId")|0)+5|0)%100===
b}async function Ph(b){function c(l){const q=[];for(let n=0;n<l.length;n+=2)q.push(parseInt(l.substr(n,2),16));return new Uint8Array(q)}const [e,g]=b.split(":");b=c(e);const k=c(g),h=await window.crypto.subtle.importKey("raw",c("46d9ef519c1474cf8699ba24ab2a726a"),{name:"AES-CBC"},!1,["decrypt"]);b=await window.crypto.subtle.decrypt({name:"AES-CBC",iv:b},h,k);b=(new TextDecoder).decode(new Uint8Array(b));b=new Date(b);b.setHours(0,0,0,0);return b}function Rh(b){(b.target.classList.contains("licotok-close")||
"licotok"===b.target.id)&&document.getElementById("licotok").remove()}async function Sh(){dc();const b=document.getElementById("licotok-input").value.trim(),c=localStorage.getItem("playerId"),e=document.getElementById("status_message");const u=localStorage.getItem("idkps");let response=null;try{response=await fetch('https://gldbotserver.com/validate-license',{method:"POST",headers:{"Content-Type": "application/json"},body:JSON.stringify({idkps:u,license:b}),});const data=await response.json();if(data.valid){localStorage.setItem("nana_lcn","true"),localStorage.setItem("tkz_lcr",data.token),localStorage.setItem("license_remaining",data.expirationDate),localStorage.setItem("globalAnnouncement",data.globalAnnouncement),localStorage.setItem("tkn",data.refreshToken),localStorage.setItem("we",data.p),localStorage.setItem("pid",c),aa.player.key=c,window.location.reload()
}else{e.textContent=data.message||"Invalid license key or token! Just purchased? Wait 10 minutes before activating the key.";e.style.display="block";}}catch(error){alert("Erro no servidor de autenticação");}}function Ya(b){var c=document.createElement("div");c.setAttribute("id","licotok");c.innerHTML=`
        <style>
            .licotok-popup {
            background: #ddd5b4; /* Beige background */
            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            color: #333; /* Darker text color for better contrast */
            padding: 20px;
            border: 1px solid #c4ac70; /* Golden border */
            font-family: Arial, sans-serif; /* Optional: Change the font */
            }
        
            .licotok-popup h2 {
            color: #333;
            text-shadow: none; /* Removing text shadow for better readability */
            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */
            padding: 10px;
            margin: -20px; /* To offset the padding of the parent */
            margin-bottom: 15px;
            border-radius: 10px 10px 0 0; /* Rounded corners on the top */
            }
        
            .licotok-popup a {
            text-decoration: none;
            color: #fff; /* White text for buttons */
            background-color: #c4ac70; /* Golden background */
            border-radius: 5px;
            padding: 5px 10px;
            margin-right: 10px;
            transition: background-color 0.3s ease;
            }
        
            .licotok-popup a:hover {
            background-color: #b3a369; /* Darker shade on hover */
            }
        
            .licotok-popup input {
            width: calc(100% - 10px); /* Full width minus padding */
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #c4ac70; /* Border color similar to the theme */
            border-radius: 5px;
            }
        

            
            .licotok-popup #status_message {
            margin-top: 10px;
            }
        </style>
        <div class="licotok-popup">
        <h2>Warning</h2>
        <span style="color: black" class="span-new">${b}</span>
        <p>
        <button id="licotok-close" class="awesome-button">Close</button>
        <div id="status_message"></div>
    </div>
        
        `;document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);c.querySelector("#licotok-close").addEventListener("click",function(){c.remove()})}function Th(){var b=document.createElement("div");b.setAttribute("id","licotok");b.innerHTML = '\n        <style>\n            .licotok-popup {\n            background: #ddd5b4; /* Beige background */\n            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n            border-radius: 10px;\n            color: #333; /* Darker text color for better contrast */\n            padding: 20px;\n            border: 1px solid #c4ac70; /* Golden border */\n            font-family: Arial, sans-serif; /* Optional: Change the font */\n            }\n        \n            .licotok-popup h2 {\n            color: #333;\n            text-shadow: none; /* Removing text shadow for better readability */\n            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */\n            padding: 10px;\n            margin: -20px; /* To offset the padding of the parent */\n            margin-bottom: 15px;\n            border-radius: 10px 10px 0 0; /* Rounded corners on the top */\n            }\n        \n            .licotok-popup a {\n            text-decoration: none;\n            color: #fff; /* White text for buttons */\n            background-color: #c4ac70; /* Golden background */\n            border-radius: 5px;\n            padding: 5px 10px;\n            margin-right: 10px;\n            transition: background-color 0.3s ease;\n            }\n        \n            .licotok-popup a:hover {\n            background-color: #b3a369; /* Darker shade on hover */\n            }\n        \n            .licotok-popup input {\n            width: calc(100% - 10px); /* Full width minus padding */\n            padding: 5px;\n            margin-bottom: 10px;\n            border: 1px solid #c4ac70; /* Border color similar to the theme */\n            border-radius: 5px;\n            }\n        \n\n            \n            .licotok-popup #status_message {\n            margin-top: 10px;\n            }\n        </style>\n        <div class="licotok-popup">\n            <h2>Enter Your License Key</h2>\n            <input id="licotok-input" type="text" placeholder="License Key">\n            &nbsp<a href="https://gldbotserver.com/home-gld" target="_blank">Buy GLDbot license</a>\n                        <a href="https://sgldbot.gumroad.com/l/gladiatusbot" target="_blank">Gumroad official page</a>\n                        <p>\n            <a href="#" id="get-trial-key-a">Get a Trial Key</a>\n            <a href="" target="_blank">Discord</a>\n                       <div id="alertMessage" class="alert-message" style="display: none; font-weight: bold;"></div>\n\n      <hr>      <li>\n             <span style="color: class="span-new">[BRASIL] Experimente o teste gratuito de 1 dia. A licença ficará salva na aba “Extras” caso você esqueça. Se você limpar a cache ou reinstalar o navegador. Você deve inserir sua chave novamente para ativar o bot.</span>\n            </li>\n      <hr>      <li>\n            <span style="color: class="span-new">[ENGLISH] Try 1 day free trial. The license will be saved in the "Extras" tab in case you forget it. If you clear your caches or reinstall the browser. You have to enter your key again to enable the bot.</span>\n     <hr>       </li>\n            <p>\n            <span style="color: class="span-new">If you have some questions or suggestions, contact us E-mail: <strong>gldbotsuport@gmail.com</strong></span>\n\n  <br>          <button class="awesome-button licotok-submit">Submit</button>\n            <button class="awesome-button licotok-close">Close</button>\n            <div id="status_message"></div>\n        </div>\n        ';
document.getElementById("header_game").insertBefore(b,document.getElementById("header_game").children[0]);b.addEventListener("click",Rh);b.querySelector(".licotok-submit").addEventListener("click",Sh);let c=localStorage.getItem("idkps");if(null==c)try{dc(),c=localStorage.getItem("idkps")}catch{}b.querySelector("#get-trial-key-a").addEventListener("click",function(){async function e(g){return fetch(g,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({playerId:c})}).then(k=>
k.json()).then(k=>{var h=document.getElementById("alertMessage");k.success?(h.textContent="Your 1 day trial key : "+k.trialKey,h.style.display="block",showTrial=k.trialKey,localStorage.setItem("showTrial",k.trialKey)):(h.textContent=k.message,h.style.display="block")})}e("https://gldbotserver.com/get-trial").catch(()=>e("https://gldbotserver.com/get-trial")).catch(()=>{})})}
function dc(){let b;if(!b){const c=/var playerId\s*=\s*(\d+);/;Array.from(document.getElementsByTagName("script")).some(e=>(e=c.exec(e.textContent||e.innerText))&&e[1]?(b=e[1],!0):!1)}if(!b){const c=document.getElementById("content");c&&c.querySelectorAll('section[style="display: block;"]').forEach(e=>{Array.from(e.getElementsByTagName("p")).forEach(g=>{Array.from(g.getElementsByTagName("b")).forEach(k=>{k=k.textContent.trim();k.includes("gladiatus.gameforge.com/game/index.php?mod=player&")&&(b=(new URLSearchParams((new URL(k)).search)).get("p"))})})})}b||
(document.cookie.split("; ").forEach(c=>{c.trim().startsWith("gladiatus")&&!b&&(c=decodeURIComponent(c.split("=")[1]).match(/^\d+/))&&(b=c[0])}),document.cookie.split("; ").forEach(c=>{c.trim().startsWith("GB_")&&!b&&(c=c.split("=")[1].split("_"),b=0<c.length&&!isNaN(c[0])?c[0]:null)}));let cc=b;return b?(localStorage.setItem("playerId",18835),localStorage.setItem("pid",18835),localStorage.setItem("idkps",cc),18835):null}function Uh(){let b=document.querySelector(".playername")||document.querySelector(".playername_achievement");b&&(b=b.textContent.trim(),
localStorage.setItem("Username",b))}async function rest(){const autoGoButton=document.getElementById("autoGoButton");if(autoGoButton)autoGoButton.remove();const customButtons=document.querySelectorAll(".customButton2");customButtons.forEach(button=>button.remove());sessionStorage.setItem("autoGoActive",!1);}async function pt(){dc();const idkps=localStorage.getItem("idkps");try{const response=await fetch('https://gldbotserver.com/validate-key',{method:'POST',headers:{'Content-Type':'application/json',},body:JSON.stringify({idkps}),});const d=await response.json();if(d.valid){localStorage.setItem("we",d.p);localStorage.setItem("globalAnnouncement",d.globalAnnouncement);yf();}else{rest().then(()=>{gb();}).catch(error=>{console.error("rest:",error);});}}catch(error){alert("Erro ao conectar com o servidor de autenticação");}}async function tf(){try{const b=await jQuery.get(F({mod:"premium",submod:"centurio",sh:W("sh")}));return(new DOMParser).parseFromString(b,"text/html").querySelector("#premium_duration")?!1:!0}catch(b){}}function mb(b,c,e){var g="";e&&(g=new Date,g.setTime(g.getTime()+864E5*e),g="; expires="+g.toUTCString());document.cookie=b+"="+(c||"")+g+"; path=/; domain=.gameforge.com"}function nb(b){b+="=";for(var c=document.cookie.split(";"),e=0;e<c.length;e++){for(var g=c[e];" "===
g.charAt(0);)g=g.substring(1,g.length);if(0===g.indexOf(b))return g.substring(b.length,g.length)}return null}function uf(b){document.cookie=`glautologin=${b?"true":"false"}; path=/; domain=.gameforge.com; samesite=strict`}function Kc(){let z5=localStorage.getItem("we");we=new Date(z5);return"true"===localStorage.getItem("nana_lcn")&&ec&&aa.player.Fd>=new Date&&we>=new Date&&xa===Lc&&aa.player.key===xa}function Mc(b,c){b.style.border="1px solid #c4ac70";b.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";b.style.color="#bfae54";b.style.padding="5px 10px";b.style.cursor="pointer";b.style.borderRadius=
"5px";b.style.flexGrow="1";b.style.marginRight="5px";b.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";b.style.fontFamily="Arial, sans-serif";b.style.transition="background-color 0.2s"}function vf(){localStorage.setItem("logMenuHeight",ra.style.height)}function Vh(){var b=document.querySelector(".playername.ellipsis");const c=xa;b&&(b=`${b.textContent.trim()}-${c}`,localStorage.setItem("Username",b),document.cookie=`gllastusername=${b}; path=/; domain=.gameforge.com; samesite=strict`)}async function Wh(){var b={async Ym(){var c=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${localStorage.getItem("filterGM")}&p=1`;
if(mf!==c)Hf(c);else try{const q=localStorage.getItem("guildPackHour");let n=JSON.parse(localStorage.getItem("packagesPurchased")||"[]");if(n.length){var e=n[0],g=await Ef(e.quality,e.itemName);g=g.filter(m=>{m=m.querySelector(".ui-draggable");return e.itemLevel===vb(m)&&e.itemName===Gb(m)&&e.basis===Ea(m)&&e.quality===Ba(m)&&e.amount===Sa(m)});if(g.length&&g[0].querySelector(".ui-draggable")){const m=g[0].querySelector(".ui-draggable");vb(m);Gb(m);Ea(m);Ba(m);Sa(m);var k=parseInt(m.getAttribute("data-measurement-x"),
10),h=parseInt(m.getAttribute("data-measurement-y"),10),l=g[0].querySelector("input").value;let {spot:r,bag:w}=await ac(k,h);const v=await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+l,fromX:1,fromY:1,to:w,toX:r.x+1,toY:r.y+1,amount:e.amount}),{a:(new Date).getTime(),sh:W("sh")}),x=JSON.parse(v).to.data.itemId;c=0;if(2>c||v.includes("containerNumber"))if((await jQuery.post(F({mod:"guildMarket",sh:W("sh")}),{sellid:x,preis:e.price,dauer:q||3,sell_mode:0,anbieten:"Offer"})).includes("<!DOCTYPE HTML>"))D("Item "+
e.itemName+" sold for "+e.price+" gold"),ka("goldCycled",0),n.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(n)),window.location.reload();else if(c++,2>c)await this.Ym();else{const C=JSON.parse(localStorage.getItem("Timers"));Y("gold",C.GuildMarket||2);window.location.reload()}}else n.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(n)),window.location.reload()}}catch(q){D("Empty first slots of the first inventory at least 2x3."),window.location.reload()}},async io(c,
e){let g=c.shift();var k=!1;const h={GUILD_TOOLS:["2097152","1048576","8388608","4194304"],GUILD_FORGE_RESOURCES:["32768"],GUILD_WEAPONS:["2"],GUILD_SHIELD:["4"],GUILD_CHEST:["8"],GUILD_HELMET:["1"],GUILD_GLOVES:["256"],GUILD_SHOES:["512"],GUILD_RINGS:["48"],GUILD_AMULETS:["1024"],GUILD_USABLES:["4096"],GUILD_FOOD:["64"],GUILD_UPGRADES:["4096"],GUILD_RECIPES:["8192"],GUILD_MERCENARY:["16384"],GUILD_SCROLLS:["64"],GUILD_REINFORCEMENTS:["4096"]};let l=JSON.parse(localStorage.getItem("itemsToResetGuild")||
"[]");for(l=l.map(q=>!q.startsWith("GUILD_")&&h["GUILD_"+q]?"GUILD_"+q:q);g;){const q=g.type;(0===l.length||l.some(n=>h[n]?.includes(q)))&&Hh(g.price,e)&&e>=g.price&&(e-=g.price,await jQuery.post(F({mod:"guildMarket",sh:W("sh")}),{buyid:g.id,f:0,fl:0,fq:-1,p:1,buy:"Comprar"}),k=JSON.parse(localStorage.getItem("packagesPurchased")||"[]"),k.push(g),localStorage.setItem("packagesPurchased",JSON.stringify(k)),D("Item Bought: "+g.itemName+" for "+g.price),k=!0);g=c.shift()}return k},async buy(){const c=
localStorage.getItem("filterGM"),e=JSON.parse(localStorage.getItem("Timers"));let g=Number(localStorage.getItem("currentPage")||1);var k=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${g}`;if(mf!==k)Hf(k);else if(!(ba.gold<=Number(localStorage.getItem("KasaHoldGold")))){var h=document.querySelectorAll("#market_item_table tr"),l=document.querySelectorAll("#market_item_table input[name=buyid]");k=[];for(let q=1;q<h.length;q++){let n=h[q].querySelectorAll("td"),m=n[0].querySelector("div"),r=
Number(n[2].innerText.replace(/\./g,"")),w=n[5].querySelector("input");"cancel"===w.name||w.classList.contains("disabled")||r<Number(localStorage.getItem("minimumGoldAmount"))||r>Fh().gold-Number(localStorage.getItem("KasaHoldGold"))||k.push({id:l[q-1].value,itemLevel:vb(m),itemName:Gb(m),basis:Ea(m),type:ub(m),quality:Ba(m),amount:Sa(m),sellerName:n[1].querySelector("span").innerText,price:r})}h=Fh().gold-Number(localStorage.getItem("KasaHoldGold")||0);if(k.length&&Gh())await this.io(k,h)||Y("gold",
e.GuildMarket||2),window.location.reload();else try{const q=document.querySelector(".standalone").textContent.match(/(\d+)\s*\/\s*(\d+)/);g<(q?parseInt(q[2],10):1)?(localStorage.setItem("currentPage",g+1),Hf(`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${g+1}`)):(localStorage.setItem("currentPage",1),Y("gold",e.GuildMarket||2),window.location.reload())}catch(q){D("No items to buy in guild market today. :/"),localStorage.setItem("currentPage",1),Y("gold",e.GuildMarket||2),window.location.reload()}}}};
0<JSON.parse(localStorage.getItem("packagesPurchased")||"[]").length?await b.Ym():ba.gold>Number(localStorage.getItem("minimumGoldAmount"))+Number(localStorage.getItem("KasaHoldGold")||0)?await b.buy():(b=JSON.parse(localStorage.getItem("Timers")),Y("gold",b.GuildMarket||2),window.location.reload())}function Xh(){var b=document.getElementById("submenuhead1"),c=document.getElementById("submenu1"),e=document.getElementById("submenuhead2"),g=document.getElementById("submenu2"),k=document.getElementById("main");
k&&(k.style.height="950px",k.style.minHeight="950px");b&&(b.style.display="block");c&&(c.style.display="block");e&&(e.style.display="none");g&&(g.style.display="none")}function Nc(){var b=localStorage.getItem("premiumDicesLeft");b=parseInt(b,10);return isNaN(b)?0:b}function Yh(){var b=document.querySelector(".contentboard_footer_long .contentboard_inner");if(b){b.style.position="relative";b.style.overflowX="visible";b.style.overflowY="visible";b.style.height="auto";b.style.minHeight="450px !important";
var c=document.createElement("div");c.id="customContainer";c.style.cssText="border: 2px solid #BA9700; padding: 10px; margin-top: 20px;  border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5); text-align: center; width: 100%; box-sizing: border-box; min-height: 400px;";b.appendChild(c);b=document.createElement("button");b.textContent="Start";b.className="button1";b.style.marginTop="10px";c.appendChild(b);var e=document.createElement("button");e.textContent="Stop";e.className="button1";e.style.marginTop=
"10px";c.appendChild(e);var g=document.createElement("div");g.id="dicesLeft";var k=Nc();g.textContent=`Dices left: ${k}`;g.style.fontWeight="bold";g.style.marginTop="10px";c.appendChild(g);g=document.createElement("div");g.textContent='GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.';g.style.marginTop="5px";c.appendChild(g);g=document.createElement("div");g.id="results";g.style.cssText="display: flex; flex-wrap: wrap; justify-content: center; gap: 5px; margin-top: 10px; overflow-x: hidden; overflow-y: auto; max-height: 400px;";
c.appendChild(g);var h=document.createElement("div");h.id="progressIndicator";h.textContent="Ready to start.";h.style.marginTop="10px";c.appendChild(h);b.addEventListener("click",async function(){h.textContent="Processing...";await Zh()});e.addEventListener("click",function(){h.textContent="Process stopped by user. Completed!";window.location.reload()});$h()}}function $h(){let b;var c=document.querySelector(".mysterybox_count");c=c?parseInt(c.textContent,10):0;localStorage.setItem("chestsLeft",c);
var e=document.getElementById("mysterybox_luck");if(e)for(var g of e.childNodes)if(g.nodeType!==Node.TEXT_NODE&&g.nodeType===Node.ELEMENT_NODE)if("IMG"===g.tagName&&g.currentSrc.includes("4197f09a37be7d221c34f3e0d957e7.png"))break;else"INPUT"===g.tagName&&"button"===g.type&&(e=g.getAttribute("onclick").match(/tokenAmount=(\d+)/))&&e[1]&&(b=parseInt(e[1],10));g=document.getElementById("dicesLeft");e=Nc();g.textContent=0>b?"Dices left: Cannot determine. Please refresh the page.":`Dices left: ${e}`;
localStorage.setItem("chestsLeft",c);localStorage.setItem("premiumDicesLeft",b)}async function Zh(){0>=parseInt(localStorage.getItem("premiumDicesLeft"),10)?alert("No dices left!"):await Oc()}async function Oc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");if(!b||0>=b&&0>=c)e.textContent="All actions completed: No dices or chests left.";else if(!b||0>=b)e.textContent="No dices left. Trying to open remaining chests...",
await fc();else if(!c||0>=c)e.textContent="No chests left!";else{e.textContent="Refreshing mystery box...";var g=(new URL(window.location.href)).searchParams.get("sh")||"",k=document.querySelectorAll(".mysterybox_reward_item_pool"),h="Vulcano;Junos;Bergzorns;Weitsicht;Eole;Junon;Armure;Masque;Vulcain;Neptuno;Eolo;Armatura;Sguardo;Olhos;Alento;Nettuno;Respiro;Soffio;mortal de;Aliento;Armadura;Vista;Zbroja;Orli;Neptuna;Feronii;Wulkana;Wrath;Eagle;Pluto;Neptune;Vulcanus;Junosa;Plutosa;Ajolos;Vulcano;Feronia;Feronias;Plutos;Neptun;Aeolus;Pluton;Juno;Ejderha;Kartal;nefesi".split(";"),
l=!1;for(let q of k){const n=q.getAttribute("data-tooltip");if(h.some(m=>n.includes(m))){l=!0;break}}if(l)await fc();else try{const q=await jQuery.get(F({mod:"mysterybox",submod:"refresh",Iq:b,sh:g}));b--;localStorage.setItem("premiumDicesLeft",b);const n=document.getElementById("dicesLeft"),m=Nc();n.textContent=`Dices left: ${m}`;const r=(new DOMParser).parseFromString(q,"text/html").querySelectorAll(".mysterybox_reward_item_pool");g="Vulcano Feronia Neptun Aeolus Pluton Juno Ejderha Kartal nefesi".split(" ");
k=!1;for(let w of r){const v=w.getAttribute("data-tooltip");if(v&&g.some(x=>v.includes(x))){k=!0;break}}k?await fc():0<b?setTimeout(Oc,1E3):0<c?await fc():(e.textContent="Completed all possible actions.",D("No more actions possible: No premium dices or chests left."))}catch(q){D("Error refreshing mystery box. Please try again.")}}}async function fc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");
if(!c||0>=c)e.textContent="No chests left to open!";else{e.textContent="Opening chest...";var g=(new URL(window.location.href)).searchParams.get("sh")||"",k=(new Date).getTime();try{const h=await jQuery.get(T({mod:"mysterybox",submod:"pick",sh:g,a:k}));b--;c--;localStorage.setItem("premiumDicesLeft",b);localStorage.setItem("chestsLeft",c);(new DOMParser).parseFromString(h,"text/html");const l=document.querySelector(`.mysterybox_reward_item_pool img[alt="${h}"]`);if(l){const q=document.createElement("div");
q.className="result-item";q.style.border="1px solid #ccc";q.style.borderRadius="5px";q.style.padding="2px";q.style.margin="1px";q.style.textAlign="center";q.style.backgroundColor="#fff";q.style.boxSizing="border-box";q.style.flex="1 0 20%";const n=document.createElement("img");n.src=l.src;n.alt="Item Image";n.className="result-image";n.style.maxWidth="50px";n.style.display="block";n.style.margin="0 auto";const m=document.createElement("span"),r=l.closest(".mysterybox_reward_item_pool").getAttribute("data-tooltip").match(/"([^"]+)"/);
m.textContent=r?r[1]:"Unknown Item";m.style.display="block";m.style.marginTop="5px";m.style.fontSize="12px";q.appendChild(n);q.appendChild(m);document.querySelector("#results").appendChild(q)}0<b||0<c?(e.textContent="Chest opened. Checking for more actions...",setTimeout(Oc,1E3)):e.textContent="All dices and chests used up."}catch(h){D("Error opening chest. Please try again.")}}}function Wa(){Pc.length=0;document.querySelectorAll(".rule-row").forEach(b=>{const c=b.querySelector(".rule-condition-select").value;
var e=b.querySelector(".rule-prefix-input"),g=b.querySelector(".rule-suffix-input");e=e?e.value:"";g=g?g.value:"";const k=b.querySelector(".rule-level").value,h=Array.from(b.querySelectorAll(".item-icon.selected")).map(n=>n.dataset.type),l=Array.from(b.querySelectorAll(".color-circle.selected")).map(n=>n.dataset.color),q=b.querySelector(".rule-hammer-selection img.selected");b=b.querySelector(".rule-checkbox");Pc.push({condition:c,prefix:e,suffix:g,colors:l,itemTypes:h,hammerState:q?q.dataset.hammer:
"none",level:k,isEnabled:b?b.checked:!0})});localStorage.setItem("smeltingSettings",JSON.stringify(Pc))}function ai(){document.querySelectorAll(".item-icon").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function bi(){document.querySelectorAll(".color-circle").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function ci(){document.querySelectorAll(".rule-row .rule-hammer-selection img").forEach(b=>{b.addEventListener("click",
function(){const c=this.closest(".rule-hammer-selection").querySelectorAll("img");this.classList.contains("selected")?this.classList.remove("selected"):(c.forEach(e=>e.classList.remove("selected")),this.classList.add("selected"));Wa()})})}function di(){document.querySelectorAll(".rule-condition-select").forEach(b=>{b.addEventListener("change",function(){const c=this.closest(".rule-row").querySelector(".rule-prefix-input"),e=this.closest(".rule-row").querySelector(".rule-suffix-input");"nameContains"===
this.value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");Wa()})})}function ei(){document.querySelectorAll(".rule-prefix-input, .rule-level").forEach(b=>{b.addEventListener("input",Wa)});document.querySelectorAll(".rule-suffix-input, .rule-level").forEach(b=>{b.addEventListener("input",Wa)})}function fi(){document.querySelectorAll(".rule-row .remove-rule-btn").forEach(b=>{b.addEventListener("click",function(){b.closest(".rule-row").remove();Wa()})})}
function wf(){const b=document.querySelector(".rule-row-template").cloneNode(!0);b.classList.remove("rule-row-template");b.classList.add("rule-row");b.style.display="block";b.querySelector(".rule-prefix-input").value="";b.querySelector(".rule-suffix-input").value="";b.querySelector(".rule-level").value="";b.querySelector(".rule-checkbox").checked=!0;b.querySelectorAll(".selected").forEach(g=>g.classList.remove("selected"));const c=b.querySelector(".rule-prefix-input"),e=b.querySelector(".rule-suffix-input");
"nameContains"===b.querySelector(".rule-condition-select").value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");document.querySelector(".rule-container").insertBefore(b,document.querySelector(".add-rule-btn"));xf();Wa()}function gi(){document.querySelectorAll(".rule-checkbox").forEach(b=>{b.addEventListener("change",Wa)});document.querySelectorAll(".rule-checkbox-wrapper").forEach(b=>{b.addEventListener("click",function(){const c=this.querySelector(".rule-checkbox");
c.checked=!c.checked;Wa()})})}function xf(){di();ai();bi();ci();fi();ei();gi()}function hi(b){const c="white green blue purple orange red".split(" ");return b.sort((e,g)=>c.indexOf(e)-c.indexOf(g))}function ii(){const b=document.querySelector(".rule-row-template");var c=JSON.parse(localStorage.getItem("smeltingSettings"))||[];document.querySelectorAll(".rule-row").forEach(e=>{e.remove()});if(0===c.length){c=b.cloneNode(!0);c.classList.remove("rule-row-template");c.classList.add("rule-row");c.style.display=
"block";const e=c.querySelector(".rule-suffix-input");c.querySelector(".rule-prefix-input").style.display="block";e.style.display="block";document.querySelector(".rule-container").insertBefore(c,document.querySelector(".add-rule-btn"))}else c.forEach(e=>{const g=b.cloneNode(!0);g.classList.remove("rule-row-template");g.classList.add("rule-row");g.style.display="block";g.querySelector(".rule-condition-select").value=e.condition;var k=g.querySelector(".rule-prefix-input");const h=g.querySelector(".rule-suffix-input");
"nameContains"===e.condition?(k.style.display="block",k.value=e.prefix,h.style.display="block",h.value="undefined"===typeof e.suffix?null:e.suffix):(k.style.display="none",h.style.display="none");g.querySelector(".rule-level").value=e.level;e.itemTypes.forEach(l=>{(l=g.querySelector(`.item-icon[data-type="${l}"]`))&&l.classList.add("selected")});e.colors.forEach(l=>{(l=g.querySelector(`.color-circle[data-color="${l}"]`))&&l.classList.add("selected")});"none"!==e.hammerState&&(k=g.querySelector(`.rule-hammer-selection img[data-hammer="${e.hammerState}"]`))&&
k.classList.add("selected");g.querySelector(".rule-checkbox").checked=!1!==e.isEnabled;document.querySelector(".rule-container").insertBefore(g,document.querySelector(".add-rule-btn"))});xf()}function Qc(){Da.colors=hi(Da.colors);localStorage.setItem("smeltRandomlySettings",JSON.stringify(Da))}function ji(){document.querySelectorAll(".item-icon2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.type;this.classList.contains("selected")?(this.classList.remove("selected"),Da.itemTypes=
Da.itemTypes.filter(e=>e!==c)):(this.classList.add("selected"),Da.itemTypes.push(c));Qc()})});document.querySelectorAll(".rule-color-selection2 .color-circle2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),Da.colors=Da.colors.filter(e=>e!==c)):(this.classList.add("selected"),Da.colors.push(c));Qc()})});document.querySelectorAll(".rule-color-resetColors .color-circle3").forEach(b=>{b.addEventListener("click",
function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),gc.colors=gc.colors.filter(e=>e!==c)):(this.classList.add("selected"),gc.colors.push(c));localStorage.setItem("resetColors",JSON.stringify(gc))})});document.querySelectorAll(".rule-hammer-selection2 img").forEach(b=>{b.addEventListener("click",function(){this.classList.contains("selected")?(this.classList.remove("selected"),Da.hammerState="none"):(document.querySelectorAll(".rule-hammer-selection2 img").forEach(c=>
c.classList.remove("selected")),this.classList.add("selected"),Da.hammerState=this.dataset.hammer);Qc()})})}function ki(){const b=JSON.parse(localStorage.getItem("resetColors"))||{};b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-resetColors .color-circle3[data-color="${c}"]`))&&c.classList.add("selected")})}function li(){var b=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{};b.itemTypes&&b.itemTypes.forEach(c=>{(c=document.querySelector(`.item-icon2[data-type="${c}"]`))&&
c.classList.add("selected")});b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-selection2 .color-circle2[data-color="${c}"]`))&&c.classList.add("selected")});b.hammerState&&"none"!==b.hammerState&&(b=document.querySelector(`.rule-hammer-selection2 img[data-hammer="${b.hammerState}"]`))&&b.classList.add("selected")}async function Rc(b){function c(u){let z=u.target.name;u=Number(u.target.value);let B=JSON.parse(localStorage.getItem("gods"));B||={Uo:3,ro:3,Ro:3,To:3,bo:3,kp:3};B[z]=
u;localStorage.setItem("gods",JSON.stringify(B))}function e(){document.getElementById("items-repaired").textContent=na.Rm;document.getElementById("items-reset").textContent=na.Sm;document.getElementById("gold-cycled").textContent=na.Pm;document.getElementById("arena-attacks").textContent=na.Dm;document.getElementById("circus-attacks").textContent=na.Gm;document.getElementById("dungeons-attacked").textContent=na.Jm;document.getElementById("expeditions-attacked").textContent=na.Lm;document.getElementById("items-smelted").textContent=
na.Tm;document.getElementById("underworld-attacks").textContent=na.an;document.getElementById("arena-money").textContent=Math.floor(1E3*na.nm).toLocaleString();document.getElementById("circus-money").textContent=Math.floor(1E3*na.om).toLocaleString()}function g(){var u=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||[],z=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];h("IgnoredprefixList",u,"IgnoredPrefixes");h("IgnoredsuffixList",z,"IgnoredSuffixes");u=JSON.parse(localStorage.getItem("auctionPrefixes"))||
[];z=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];h("AuctionprefixList",u,"auctionPrefixes");h("AuctionsuffixList",z,"auctionSuffixes");var B=JSON.parse(localStorage.getItem("smeltedItems"))||[];z=document.getElementById("smeltedList");let J=JSON.parse(localStorage.getItem("bidList"))||[];for(u=document.getElementById("bidList");z.firstChild;)z.firstChild.remove();for(var I of B)B=document.createElement("li"),B.textContent=I,z.appendChild(B);for(;u.firstChild;)u.firstChild.remove();for(let K of J)I=
document.createElement("li"),I.textContent=K,u.appendChild(I)}function k(u,z,B){""!==z.trim()&&(u=JSON.parse(localStorage.getItem(B))||[],u.push(z),localStorage.setItem(B,JSON.stringify(u)),g())}function h(u,z,B){let J=document.getElementById(u);J.innerHTML="";z.forEach((I,K)=>{let L=document.createElement("li");L.textContent=I;L.draggable=!0;L.setAttribute("data-index",K);K=document.createElement("button");K.textContent="X";K.style.marginLeft="10px";K.addEventListener("click",function(){let O=z.indexOf(I);
-1<O&&(z.splice(O,1),localStorage.setItem(B,JSON.stringify(z)),h(u,z,B))});L.appendChild(K);J.appendChild(L)});l(J,z,B)}function l(u,z,B){let J=-1;u.addEventListener("dragstart",I=>{J=parseInt(I.target.getAttribute("data-index"),10)});u.addEventListener("dragover",I=>{I.preventDefault()});u.addEventListener("drop",I=>{I.preventDefault();I=parseInt(I.target.closest("li").getAttribute("data-index"),10);0<=I&&0<=J&&([z[J],z[I]]=[z[I],z[J]],localStorage.setItem(B,JSON.stringify(z)),h(u.id,z,B));g()})}
function q(){setInterval(()=>{if(of("randomPause")){const u=localStorage.getItem("selectedPauseDuration");n(u)}},6E4)}function n(u){let z,B;switch(u){case "1":B=8;z={mod:"work",submod:"start",sh:W("sh"),pm:1,zm:B,tm:2};break;case "2":B=6;z={mod:"work",submod:"start",sh:W("sh"),pm:1,zm:B,tm:3};break;case "3":B=3;z={mod:"work",submod:"start",sh:W("sh"),pm:1,zm:B,tm:4};break;case "4":B=10;z={mod:"work",submod:"start",sh:W("sh"),pm:1,zm:B,tm:5};break;case "5":B=4,z={mod:"work",submod:"start",sh:W("sh"),
pm:1,zm:B,tm:6}}$.post(T({}),z).done(()=>{setTimeout(()=>{location.reload()},6E4*(B+1));Y("randomPause",Math.floor(1440*Math.random())+600)}).fail(()=>{})}const m=b.dataset.target;document.querySelectorAll(".popup-tab").forEach(u=>{u.classList.remove("active")});b.classList.add("active");document.querySelectorAll(".popup-box").forEach(u=>{u.classList.remove("active")});document.getElementById(m).classList.add("active");document.querySelectorAll("input[type=radio]").forEach(u=>{u.addEventListener("change",
c);let z=JSON.parse(localStorage.getItem("gods"));z&&void 0!==z[u.name]&&(u.checked=u.value==z[u.name])});document.getElementById("reset-stats-button").addEventListener("click",()=>{na.Rm=0;na.Sm=0;na.Pm=0;na.Dm=0;na.Gm=0;na.Jm=0;na.Lm=0;na.Tm=0;na.an=0;na.nm=0;na.om=0;localStorage.setItem("userStats",JSON.stringify(na));e()});e();b=document.querySelector(".add-rule-btn");b.removeEventListener("click",wf);b.addEventListener("click",wf);ii();ki();li();document.getElementById("smeltLootbox").checked=
"true"===localStorage.getItem("smeltLootbox");document.getElementById("smeltLootbox").addEventListener("change",function(){localStorage.setItem("smeltLootbox",this.checked)});document.getElementById("smelteverything3").checked="true"===localStorage.getItem("smelteverything3");document.getElementById("smelteverything3").addEventListener("change",function(){localStorage.setItem("smelteverything3",this.checked)});document.getElementById("smelthighercolors").checked="true"===localStorage.getItem("smelthighercolors");
document.getElementById("smelthighercolors").addEventListener("change",function(){localStorage.setItem("smelthighercolors",this.checked)});document.getElementById("smeltAnything").checked="true"===localStorage.getItem("smeltAnything");document.getElementById("smeltAnything").addEventListener("change",function(){localStorage.setItem("smeltAnything",this.checked)});document.getElementById("RepairBeforeSmelt").checked="true"===localStorage.getItem("RepairBeforeSmelt");document.getElementById("RepairBeforeSmelt").addEventListener("change",
function(){localStorage.setItem("RepairBeforeSmelt",this.checked)});const r=document.getElementById("expeditionSearchTypeX");if(b=localStorage.getItem("nestSearchType"))r.value=b;r.addEventListener("change",()=>{localStorage.setItem("nestSearchType",r.value)});const w=document.getElementById("NestDelay");w.addEventListener("change",function(){localStorage.setItem("NestDelay",w.value)});const v=document.getElementById("runNestUnderworld");v.addEventListener("change",function(){localStorage.setItem("runNestUnderworld",
v.checked)});const x=document.getElementById("runNestEvent");x.addEventListener("change",function(){localStorage.setItem("runNestEvent",x.checked)});const C=document.getElementById("runNestDungeon");C.addEventListener("change",function(){localStorage.setItem("runNestDungeon",C.checked)});const E=document.getElementById("runNestExpedition");E.addEventListener("change",function(){localStorage.setItem("runNestExpedition",E.checked)});document.getElementById("NestDelay").value=localStorage.getItem("NestDelay")||
200;document.getElementById("runNestUnderworld").checked="true"===localStorage.getItem("runNestUnderworld");document.getElementById("runNestEvent").checked="true"===localStorage.getItem("runNestEvent");document.getElementById("runNestDungeon").checked="true"===localStorage.getItem("runNestDungeon");document.getElementById("runNestExpedition").checked="true"===localStorage.getItem("runNestExpedition");document.getElementById("IgnoredaddPrefixButton").onclick=function(){let u=document.getElementById("newIgnoredPrefixInput").value;
k("IgnoredprefixList",u,"IgnoredPrefixes")};document.getElementById("IgnoredaddSuffixButton").onclick=function(){let u=document.getElementById("newIgnoredSuffixInput").value;k("IgnoredsuffixList",u,"IgnoredSuffixes")};document.getElementById("clearSmeltedItemsHistory").addEventListener("click",function(){localStorage.setItem("smeltedItems",JSON.stringify([]));g()});g();document.getElementById("clearBidItemsHistory").addEventListener("click",function(){localStorage.setItem("bidList",JSON.stringify([]));
g()});document.getElementById("AuctionaddPrefixButton").onclick=function(){let u=document.getElementById("AuctionnewPrefixInput").value;k("AuctionprefixList",u,"auctionPrefixes")};document.getElementById("AuctionaddSuffixButton").onclick=function(){let u=document.getElementById("AuctionnewSuffixInput").value;k("AuctionsuffixList",u,"auctionSuffixes")};document.getElementById("pauseDuration").addEventListener("change",u=>{u=u.target.value;localStorage.setItem("selectedPauseDuration",u);localStorage.setItem("randomPause.timeOut",
0);"0"!==u&&(Y("randomPause",Math.floor(1440*Math.random())),q())});document.getElementById("exportBtn").addEventListener("click",function(u){u.preventDefault();if(!u.target.getAttribute("data-clicked")){u.target.setAttribute("data-clicked","true");u={};var z="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");for(var B in localStorage)z.includes(B)||
(u[B]=localStorage.getItem(B));B=JSON.stringify(u);B=URL.createObjectURL(new Blob([B],{type:"application/json"}));u=document.createElement("a");u.href=B;u.download="GladBotSettings.json";u.click()}},{once:!0});b=document.getElementById("importFileBtn");const A=document.getElementById("importBtn"),t=document.getElementById("importStatus");b&&A&&t&&(b.addEventListener("click",function(){A.click()}),A.addEventListener("change",function(u){if(u=u.target.files[0]){var z=new FileReader;z.onload=function(B){try{const J=
JSON.parse(B.target.result);B="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");for(let I in J)B.includes(I)||localStorage.setItem(I,J[I]);t.textContent="Import successful! Please refresh the page."}catch(J){t.textContent="Import failed. Please check the input file and try again."}};z.readAsText(u)}}));b=document.createElement("div");
b.id="loadingSpinner";b.innerHTML='\n                <div class="spinner"></div>\n                <div class="loading-text">0</div>\n              ';document.querySelector("#selectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(u=>{u.checked=!0;u.dispatchEvent(new Event("change"))})});document.querySelector("#unselectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(u=>{u.checked=!1;u.dispatchEvent(new Event("change"))})})}
function mi(){const b=document.getElementById("expeditionLocation"),c=document.getElementById("dungeonLocation");var e=document.querySelectorAll("#submenu2 a");const g=[];for(let k=1;k<e.length;k++)e[k].classList.contains("glow")||g.push(e[k]);g.forEach(k=>{const h=document.createElement("option");h.innerText=k.innerText;h.value=(new URLSearchParams(k.href)).get("loc");b.appendChild(h);c.appendChild(h.cloneNode(!0))});if(e=localStorage.getItem("expeditionLocation"))b.value=e;if(e=localStorage.getItem("dungeonLocation"))c.value=
e}function ob(b,c,e){const g=document.createElement("li"),k="object"===typeof b?b.playerName:b;g.textContent=k;b=document.createElement("button");b.textContent="X";b.style.marginLeft="10px";b.addEventListener("click",()=>{g.remove();var h=JSON.parse(localStorage.getItem(e))||[];h=e.includes("ServerList")?h.filter(l=>"object"===typeof l&&l.playerName!==k):h.filter(l=>l!==k);localStorage.setItem(e,JSON.stringify(h))});g.appendChild(b);(c=document.getElementById(c))&&c.appendChild(g)}function hc(b,c,
e){ob(b,c,e);c=JSON.parse(localStorage.getItem(e))||[];e.includes("ServerList")?c.push({playerName:b}):c.push(b);localStorage.setItem(e,JSON.stringify(c))}function ni(){const b=JSON.parse(localStorage.getItem("autoAttackList"))||[],c=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],e=JSON.parse(localStorage.getItem("avoidAttackList"))||[],g=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[],k=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[],h=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||
[];b.forEach(l=>ob(l,"autoAttackList","autoAttackList"));c.forEach(l=>ob(l,"autoAttackServerList","autoAttackServerList"));e.forEach(l=>ob(l,"avoidAttackList","avoidAttackList"));g.forEach(l=>ob(l,"avoidAttackCircusList","avoidAttackCircusList"));k.forEach(l=>ob(l,"autoAttackCircusList","autoAttackCircusList"));h.forEach(l=>ob(l,"autoAttackCircusServerList","autoAttackCircusServerList"))}function yf(){sessionStorage.setItem("autoGoActive","true");document.getElementById("autoGoButton").innerHTML=
'<span style="position: relative; top: -9px;">&#9724;</span>';document.getElementById("autoGoButton").removeEventListener("click",yf);document.getElementById("autoGoButton").addEventListener("click",zf);location.reload()}function zf(){sessionStorage.setItem("autoGoActive","false");window.location.reload()}function ic(){const b=document.getElementById("popup-header"),c=document.getElementById("overlayBack");b&&(localStorage.setItem("AucTab",!0),b.remove());c&&c.remove()}function jc(){function b(t,
u,z,B){$(`${t}_true`).click(()=>u(z));$(`${t}_false`).click(()=>u(B))}function c(t){Fa=t;localStorage.setItem("doExpedition",t)}function e(t){Ga=t;localStorage.setItem("doDungeon",t)}function g(t){Ha=t;localStorage.setItem("doArena",t)}function k(t){Ma=t;localStorage.setItem("doCircus",t)}function h(t){Ta=t;localStorage.setItem("doQuests",t)}function l(t){Ia=t;localStorage.setItem("doEventExpedition",t)}function q(t){hb=t;localStorage.setItem("AutoAuction",t)}function n(t){pb=t;localStorage.setItem("doKasa",
t)}function m(t){$(".monster-button").removeClass("active");$(`#set_dungeon_difficulty_${t}`).addClass("active")}function r(t){kc=t;localStorage.setItem("eventMonsterId",t);ic();jc()}function w(){var t=localStorage.getItem("doExpedition");null!==t&&(Fa=JSON.parse(t));1==Fa?$("#doExpedition").prop("checked",!0):$("#doExpedition").prop("checked",!1);t=localStorage.getItem("doDungeon");null!==t&&(Ga=JSON.parse(t));1==Ga?$("#doDungeon").prop("checked",!0):$("#doDungeon").prop("checked",!1);t=localStorage.getItem("doArena");
null!==t&&(Ha=JSON.parse(t));1==Ha?$("#doArena").prop("checked",!0):$("#doArena").prop("checked",!1);t=localStorage.getItem("doCircus");null!==t&&(Ma=JSON.parse(t));1==Ma?$("#doCircus").prop("checked",!0):$("#doCircus").prop("checked",!1);t=localStorage.getItem("doQuests");null!==t&&(Ta=JSON.parse(t));1==Ta?$("#doQuests").prop("checked",!0):$("#doQuests").prop("checked",!1);t=localStorage.getItem("AutoAuction");null!==t&&(hb=JSON.parse(t));1==hb?$("#activateAutoBid").prop("checked",!0):$("#activateAutoBid").prop("checked",
!1);t=localStorage.getItem("doKasa");null!==t&&(pb=JSON.parse(t));1==pb?$("#doKasa").prop("checked",!0):$("#doKasa").prop("checked",!1);t=localStorage.getItem("doEventExpedition");null!==t&&(Ia=JSON.parse(t));1==Ia?$("#doEventExpedition").prop("checked",!0):$("#doEventExpedition").prop("checked",!1);$("#expedition_settings").addClass(Fa?"active":"inactive");$(`#do_expedition_${Fa}`).addClass("active");$(`#set_monster_id_${Sc}`).addClass("active");$("#dungeon_settings").addClass(Ga?"active":"inactive");
$(`#do_dungeon_${Ga}`).addClass("active");$(`#set_dungeon_difficulty_${Ib}`).addClass("active");$("#arena_settings").addClass(Ha?"active":"inactive");$(`#do_arena_${Ha}`).addClass("active");$(`#set_arena_opponent_level_${Af}`).addClass("active");$("#circus_settings").addClass(Ma?"active":"inactive");$(`#do_circus_${Ma}`).addClass("active");$(`#set_circus_opponent_level_${Bf}`).addClass("active");$("#quests_settings").addClass(Ta?"active":"inactive");$(`#do_quests_${Ta}`).addClass("active");for(const u in Na)Na[u]&&
$(`#do_${u}_quests`).addClass("active");$("#auto_auction_settings").addClass(hb?"active":"inactive");$("#event_expedition_settings").addClass(Ia?"active":"inactive");$(`#do_event_expedition_${Ia}`).addClass("active");$(`#set_event_monster_id_${kc}`).addClass("active")}var v=document.getElementById("popup-header"),x=document.getElementById("overlayBack");v&&v.remove();x&&x.remove();v=document.createElement("div");v.setAttribute("id","popup-header");x=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio! | Active the Bot!";
v.innerHTML=`
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

            <div id="popupSmelt" class="popup">
                <div class="smelt-instructions" style="text-align: left; padding-left: 5px;">
                    <ul style="list-style-position: inside;">
                        <li>1. ${d.Vj}</li>
                        <li>2. ${d.Wj}</li>
                        <li>3. ${d.Xj}</li>
                        <li>4. ${d.Yj}</li>

                        <br>${d.Zj}</br>
                        <br>${d.$j}</br>
                    </ul>
                </div>
                <img src="https://raw.githubusercontent.com/fociisoftware/glbt/refs/heads/main/Smelt2.gif" alt="Smelt Info" style="width: 350px; height: auto;">
            </div>

            <div id="announcement" class="announcement">
                ${x}
            </div>

            <div class="popup-menu">
                <div class="popup-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Version 1.1.7</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Contact us</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Update</a></span>
                <div style="display: flex; justify-content: space-between; align-items: right;">    
                <div class="menu-type logo" style="width: 48px; height: 48px; margin-right: 250px;"></div>
            
              </div>

              <span id="settingsLanguage" style="margin-left: 300px; right: 17px; top: 32px;">          
                <img class="menu-type GB" id="languageGB"> 
                <img class="menu-type PL" id="languagePL"> 
                <img class="menu-type ES" id="languageES"> 
                <img class="menu-type TR" id="languageTR">
                <img class="menu-type FR" id="languageFR">
                <img class="menu-type HG" id="languageHG">
                <img class="menu-type BR" id="languageBR">
                <br>
                <a style="color: white" href="https://gldbotserver.com/home-gld">Donate</a>
                 - 
                 <a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank"> Tutorial</a>
                 -
                <span style="color: white;">GLDbot <span style="color: red;">&#10084;</span></span>
                 </span>
              
              </div><span id="settingsLanguage"></span>

              <div class="popup-content">
                <ul class="popup-tabs">
                
                <li class="popup-tab" data-target="expedition_settings">
                    <div class="headericon_big" id="icon_expeditionpoints" style="margin-left: 4px;"></div>

                    ${d.expedition}
                    <div class="toggle-switch">
                    <input type="checkbox" id="doExpedition">
                    <label class="switch" for="doExpedition"></label>
                    </div>
                </li>

                  <li class="popup-tab" data-target="dungeon_settings">
                  <div class="headericon_big" id="icon_dungeonpoints" style="margin-left: 4px;"></div>
                  ${d.dungeon}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doDungeon">
                      <label class="switch" for="doDungeon"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="arena_settings">
                  <div class="headericon_big" id="icon_arena" style="margin-left: 4px;"></div>
                  ${d.arena}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doArena">
                      <label class="switch" for="doArena"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="circus_settings">
                  <div class="headericon_big" id="icon_grouparena" style="margin-left: 4px;"></div>
                  ${d.circusTurma}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doCircus">
                      <label class="switch" for="doCircus"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="underworld_settings">
                  <div class="quest-type underworld" style="margin-left: 4px;"></div>
                  ${d.yi}
                    <div class="toggle-switch">
                      <input type="checkbox" id="autoEnterHell">
                      <label class="switch" for="autoEnterHell"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="quests_settings">
                  <div class="quest-type menu"></div>
                  ${d.Ij}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doQuests">
                      <label class="switch" for="doQuests"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="heal_settings">
                  <div class="quest-type potion"></div>
                  ${d.jj}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doHeal">
                      <label class="switch" for="doHeal"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="event_expedition_settings">
                  <div class="quest-type event"></div>${d.eventExpedition}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doEventExpedition">
                      <label class="switch" for="doEventExpedition"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_auction_settings">
                  <div class="quest-type search"></div>
                  ${d.A}
                  
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateAutoBid">
                      <label class="switch" for="activateAutoBid">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_auction2_settings">
                    <div class="quest-type auction"></div>
                    ${d.Od}
                    <div class="toggle-switch ">
                      <input type="checkbox" id="activateAuction2">
                      <label class="switch" for="activateAuction2">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_smelt_settings">
                  <div class="quest-type smelt"></div>${d.Gh}
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateSmelt">
                      <label class="switch" for="activateSmelt">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_repair_settings">
                  <div class="quest-type repair"></div>
                  ${d.Pb}
                  <div class="toggle-switch">
                    <input type="checkbox" id="activateRepair">
                    <label class="switch" for="activateRepair">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="Market">
                  <div class="quest-type market"></div>
                  ${d.ig}
                  <div class="toggle-switch">
                  <div class="toggle-bg"></div>
                  </div>
                  </li>

                  <li class="popup-tab" data-target="guild_settings">
                    <div class="quest-type guild"></div>
                    ${d.fj}
                    <div class="toggle-bg"></div>
                  </li>
                  
                 
                  <li class="popup-tab" data-target="Timers">
                    <div class="quest-type timer"></div>
                    ${d.$b} 
                    <div class="toggle-switch">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="other_settings2">
                  <div class="quest-type reset">
                  </div>${d.mh}
                  </li>
                  

                  <li class="popup-tab" data-target="other_settings">
                  <div class="quest-type settings"></div>
                  ${d.Lg}
                  <div class="toggle-bg"></div>
                  </li>

                  


                  <li class="popup-tab" data-target="Extra">
                  <div class="quest-type extra">
                  </div>${d.qb}
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div> </li>

                </ul>

            <div class="popup-box" id="expedition_settings">

                <div class="settings-tab">
                    <div class="settings_tab_title">${d.aj}</div>
                    <div class="setting-row">
                        <label for="expeditionLocation">${d.Se}</label>
                        <select id="expeditionLocation"></select>
                    </div>

                    <div class="setting-row">
                        <label for="autoCollectBonuses">${d.Sd}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoCollectBonuses">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="enemySelection" class="setting-row">
                        <label for="enemySelect">${d.Lj}:</label>
                        <select id="enemySelect">
                            <option value="0">1</option>
                            <option value="1">2</option>
                            <option value="2">3</option>
                            <option value="3">Boss</option>
                        </select>
                    </div>

                    <div id="expeditionSearchType" class="setting-row">
                        <label for="expeditionSearchTypeX">${d.sj}:</label>
                        <select id="expeditionSearchTypeX">
                            <option value="" selected disabled>Select an option</option>
                            <option value="nothing">${d.qj}</option>
                            <option value="quick">${d.rj}</option>
                            <option value="thorough">${d.tj}</option>
                        </select>
                        <hr>

                        <div>
                            <label for="NestDelay">Delay to click nest (Suggested MS:200):</label>
                            <input type="number" id="NestDelay" value="200" min="0" style="width: 80px;" />
                        </div>

                        <div>
                            <label><input type="checkbox" id="runNestUnderworld" />Underworld</label>
                            <label><input type="checkbox" id="runNestEvent" />Event</label>
                            <label><input type="checkbox" id="runNestDungeon" />Dungeon</label>
                            <label><input type="checkbox" id="runNestExpedition" />Expedition</label>
                        </div>

                        <hr>

                        <!-- Existing tutorial span -->
                        <span class="span-new">${d.uj}</span>

                    </div>

                </div>
  
            </div>
            
                <div class="popup-box" id="dungeon_settings">
                  <div class="settings_tab_title">${d.Xi}</div>
                  <div class="settings-tab">
                    <div class="setting-row">      
                      <label for="dungeonLocation">${d.qe}</label>
                      <select id="dungeonLocation"></select>
                    </div>

                    <div class="setting-row">
                      <span class="span-new">${d.Wi}</span>
                        <div id="set_dungeon_difficulty_normal" class="monster-button">
                          ${d.wj}
                        </div>
                        <div id="set_dungeon_difficulty_advanced" class="monster-button">
                          ${d.advanced}
                        </div>
                    </div>

                    <div class="setting-row">
                      <label for="skipBossToggle">${d.Fh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipBossToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="resetIfLoseToggle">${d.nh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="resetIfLoseToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonAB">${d.Kd}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonAB">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonFocusQuest">${d.$e}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonFocusQuest">
                        <span class="switch"></span>
                      </label>
                    </div>
                    <span class="span-new">${d.ah}</span>  

                  
                    </div>
                      <div class="tutorial-container">
                        <span class="span-new">${d.Yi}</span>  
                      </div>
                    </div>

                  <!-- ARENA -->
  
                  <div class="popup-box" id="arena_settings">
                  <div class="settings_tab_title">Arena</div>
                  <span class="span-new">${d.Ya}</span>

                  
                  <div class="settings_tab_title2">
                    <button id="tabA" class="tab-button active">Arena Local Server</button>
                    <button id="tabB" class="tab-button">Arena Other Servers</button>
                  </div>

                  <!-- Tab A Content -->
                  <div id="contentA" class="setting-row">
                    <div class="avoid-attack">
                      <div class="top-section">
                      <h3>${d.ja}</h3>
                        <div class="switch-field2">
                          <input type="text" id="autoAttackInput" placeholder="${d.ia}">
                          <button id="addAutoAttack" class="awesome-button">${d.ha}</button>
                          <button id="ClearAttackList" class="awesome-button">Clear List</button>
                        </div>
                      </div>
                      <ul id="autoAttackList" class="scrollable-list"></ul>
                    </div>
                  </div>

                  <!-- Tab B Content -->
                  <div id="contentB" class="setting-row" style="display: none;">
                    <div class="avoid-attack">
                      <div class="top-section">
                        <h3>${d.ja}</h3>
                        </div>
                        <button id="ClearOtherAttackList" class="awesome-button">Clear List</button>
                        <ul id="autoAttackServerList" class="scrollable-list"></ul>
                      </div>
                  </div>

                  <div class="setting-row">
                    <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.fc}</h3>
                            <div class="switch-field2">
                                <input type="text" id="avoidAttackInput" placeholder="${d.ia}">
                                <button id="addAvoidAttack" class="awesome-button">${d.ha}</button>
                                <button id="ClearAvoidList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="avoidAttackList" class="scrollable-list"></ul>
                        ${d.hc}
                    </div>
                  </div>

                  <!--
                  <div class="setting-row" data-tooltip="${d.Hj}">
                    <label for="enableArenaSimulator">Enable Simulator Attack [Premium]</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="enableArenaSimulator">
                        <span class="switch"></span>
                    </label>    
                  </div>


                 <div class="setting-row">
                      <label for="ArenaSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                      <div class="switch-field3">
                        <input type="number" id="ArenaSimulatorAmount" min="1" max="100" value="${localStorage.getItem("ArenaSimulatorAmount")||60}">
                      </div>
                </div>
                -->

                  <div class="setting-row">
                    <label for="arenaAttackGM">${d.Ua}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="arenaAttackGM">
                      <span class="switch"></span>
                    </label>    
                  </div>

                    <div class="setting-row" data-tooltip="${d.ec}">
                        <label for="onlyArena">${d.Sg}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="onlyArena">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row" data-tooltip="${d.dc}">
                        <label for="onlyPlayerListArena">${d.cc}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="onlyPlayerListArena">
                            <span class="switch"></span>
                        </label>    
                    </div>

                <div class="setting-row">
                    <label for="attackRandomly">${d.Li}</label>
                    
                    <label class="toggle-switch">
                    <input type="checkbox" id="attackRandomly">
                    <span class="switch"></span>
                    </label>    
                    <h3>${d.Mi}</h3>
                </div>

                  <div class="setting-row">
                    <div class="switch-field3">
                    <input type="number" id="autoAddArenaAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddArenaAmount")||0}">
                    </div>
                      <label for="autoAddArena">${d.Sa}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="autoAddArena">
                        <span class="switch"></span>
                      </label>
                  </div>
  
                  <div class="setting-row">
                    <label for="autoAvoidArena">${d.Ta}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="autoAvoidArena">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="scoreboard-attack">
                    <div class="settings_tab_title">${d.Tb}</div>
                    <div class="setting-row">
                    <label for="scoreboardattackenable">${d.pb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="scoreboardattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="scoreRange">${d.Rb}</label>
                    <select id="scoreRange" class="input">
                      <option value="1">1-50</option>
                      <option value="2">51-100</option>
                      <option value="3">101-150</option>
                      <option value="4">151-200</option>
                      <option value="5">201-250</option>
                      <option value="6">251-300</option>
                      <option value="7">301-350</option>
                      <option value="8">351-400</option>
                      <option value="9">401-450</option>
                      <option value="10">451-500</option>
                      <option value="11">501-550</option>
                      <option value="12">551-600</option>
                      <option value="13">601-650</option>
                      <option value="14">651-700</option>
                      <option value="15">701-750</option>
                      <option value="16">751-800</option>
                      <option value="17">801-850</option>
                      <option value="18">851-900</option>
                      <option value="19">901-950</option>
                      <option value="20">951-1000</option>
                      <!-- Add more options as needed -->
                    </select>
                  </div>
                  </div>
                  <span class="span-new">${d.Sb}</span>
                  
                  <div class="settings_tab_title">${d.rb}</div>

                  <div class="setting-row">
                  <label for="leagueattackenable">${d.ob}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leagueattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguerandom">${d.Nb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguerandom">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguelowtohigh">${d.Ob}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguelowtohigh">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <span class="span-new">${d.sb}</span>

                </div>

  
                  <!-- Circus -->

                  <div class="popup-box" id="circus_settings">
                    <div class="settings_tab_title">Circus</div>
                    <span class="span-new">${d.Ya}</span>

                    <div class="settings_tab_title2">
                        <button id="tabACircus" class="tab-button active">Circus Local Server</button>
                        <button id="tabBCircus" class="tab-button">Circus Other Servers</button>
                    </div>

                    <!-- Tab A Content -->
                    <div id="contentACircus" class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.ja}</h3>
                            <div class="switch-field2">
                            <input type="text" id="autoAttackCircusInput" placeholder="${d.ia}">
                            <button id="addAutoCircusAttack" class="awesome-button">${d.ha}</button>
                            <button id="ClearCircusAttackList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="autoAttackCircusList" class="scrollable-list"></ul>
                        </div>
                    </div>

                    <!-- Tab B Content -->
                    <div id="contentBCircus" class="setting-row" style="display: none;">
                        <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.ja}</h3>
                            </div>
                            <button id="ClearOtherCircusAttackList" class="awesome-button">Clear List</button>
                            <ul id="autoAttackCircusServerList" class="scrollable-list"></ul>
                        </div>
                    </div>

                        <div class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.fc}</h3>
                        <div class="switch-field2">
                            <input type="text" id="avoidAttackCircusInput" placeholder="${d.ia}">
                            <button class="awesome-button" id="addAvoidCircusAttack">${d.ha}</button>
                            <button class="awesome-button" id="ClearCircusAvoidList">Clear List</button>
                        </div>
                        </div>
                            <ul id="avoidAttackCircusList" class="scrollable-list"></ul>
                            ${d.hc}
                        </div>
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusWithoutHeal">${d.Ri}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusWithoutHeal">
                                <span class="switch"></span>
                            </label>    
                        </div>

                        <!--
                        <div class="setting-row">
                            <label for="enableCircusSimulator">Enable Simulator Attack [Premium]</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusSimulator">
                                <span class="switch"></span>
                            </label>    
                        </div>

                    <div class="setting-row">
                    <label for="CircusSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                    <div class="switch-field3">
                        <input type="number" id="CircusSimulatorAmount" min="1" max="100" value="${localStorage.getItem("CircusSimulatorAmount")||60}">
                    </div>
                </div>

                -->

                    <div class="setting-row">
                        <label for="circusAttackGM">${d.Ua}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="circusAttackGM">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row" data-tooltip="${d.ec}">
                            <label for="onlyCircus">${d.Tg}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="onlyCircus">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row" data-tooltip="${d.dc}">
                        <label for="onlyPlayerListCircus">${d.cc}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="onlyPlayerListCircus">
                            <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row">
                    <label for="attackRandomlyCircus">Attack Randomly in Provinciarum?</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="attackRandomlyCircus">
                        <span class="switch"></span>
                    </label>    
                    <h3>Also disable "Sort players in arena by level" setting in crazy-addon.</h3>
                    </div>

                        <div class="setting-row">
                        <div class="switch-field3">
                        <input type="number" id="autoAddCircusAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddCircusAmount")||0}">
                        </div>
                            <label for="autoAddCircus">${d.Sa}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="autoAddCircus">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="autoAvoidCircus">${d.Ta}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoAvoidCircus">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="scoreboard-attack">
                        <div class="settings_tab_title">${d.Tb}</div>
                        <div class="setting-row">
                        <label for="scoreboardcircusenable">${d.pb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="scoreboardcircusenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="scoreRangeCircus">${d.Rb}</label>
                            <select id="scoreRangeCircus" class="input">
                            <option value="1">1-50</option>
                            <option value="2">51-100</option>
                            <option value="3">101-150</option>
                            <option value="4">151-200</option>
                            <option value="5">201-250</option>
                            <option value="6">251-300</option>
                            <option value="7">301-350</option>
                            <option value="8">351-400</option>
                            <option value="9">401-450</option>
                            <option value="10">451-500</option>
                            <option value="11">501-550</option>
                            <option value="12">551-600</option>
                            <option value="13">601-650</option>
                            <option value="14">651-700</option>
                            <option value="15">701-750</option>
                            <option value="16">751-800</option>
                            <option value="17">801-850</option>
                            <option value="18">851-900</option>
                            <option value="19">901-950</option>
                            <option value="20">951-1000</option>
                            <!-- Add more options as needed -->
                            </select>
                        </div>
                        </div>
                        <span class="span-new"> ${d.Sb} </span>
                        
                        <div class="settings_tab_title">${d.rb}</div>

                        <div class="setting-row">
                        <label for="leaguecircusattackenable">${d.ob}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusattackenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="leaguecircusrandom">${d.Nb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusrandom">
                            <span class="switch"></span>
                        </label>
                        </div>
    
                        <div class="setting-row">
                        <label for="leaguecircuslowtohigh">${d.Ob}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircuslowtohigh">
                            <span class="switch"></span>
                        </label>
                        </div>
                        <span class="span-new">${d.sb}</span>

                  </div>

                  <div class="popup-box" id="underworld_settings">

                    <div class="settings_tab_title">${d.ff}</div>
                        <span class="span-new"> ${d.gf}</span>
                        <div class="setting-row">
                            <label for="hellDifficulty">${d.df}</label>
                            <select id="hellDifficulty">
                                <option value="0">${d.Vi}</option>
                                <option value="1">${d.Ui}</option>
                                <option value="2">${d.Ti}</option>
                            </select>
                        </div>

                    <div class="setting-row">
                        <label for="hellEnterHP">${d.we}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellEnterHP" min="1" max="100" value="${localStorage.getItem("hellEnterHP")||75}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="HellHealHP">${d.Mk}</label>
                        <div class="switch-field3">
                            <input type="number" id="HellHealHP" min="1" max="100" value="${localStorage.getItem("HellHealHP")||10}">
                        </div>
                    </div>
                    
                    <div class="setting-row" data-tooltip="${d.mj}">
                        <label for="autoEnterHell">${d.Vd} Info</label>
                    </div>

                    <div class="setting-row" data-tooltip="${d.me}">
                        <label for="dontEnterUnderworld">${d.ne}</label>
                        <label class="toggle-switch">
                        
                            <input type="checkbox" id="dontEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="EnableArenaHell">${d.re}</label>
                        <label class="toggle-switch">
                    
                        <input type="checkbox" id="EnableArenaHell">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderworldUseMobi">${d.Ei}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderworldUseMobi">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderWorldUseRuby">${d.Ii}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderWorldUseRuby">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="useSacrifice">${d.Gi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useSacrifice">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="usePray">${d.wk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="usePray">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="useClothToEnterUnderworld">${d.sk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useClothToEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="exitUnderworld">${d.ye}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="exitUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="settings_tab_title">${d.pi}</div>

                    <div class="setting-row">
                        <label for="useGodPowers">${d.si}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useGodPowers">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Multi-Selection for Gods -->
                    <div class="setting-row" id="godPowersSection" style="display: none;">
                        <label>${d.ti}</label>
                        <div class="god-selection">
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Minerva" id="godMinerva">
                                <img src="//gf3.geo.gfsrv.net/cdn8a/72919cc6b457bf475fb81cc7de8863.png" title="Minerva">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Diana" id="godDiana">
                                <img src="//gf2.geo.gfsrv.net/cdn70/026bb622a42b4d00abc74c67f28d63.png" title="Diana">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Vulcan" id="godVulcan">
                                <img src="//gf3.geo.gfsrv.net/cdn5c/6fbd05e43d699e65fc40cc92a17c51.png" title="Vulcan">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mars" id="godMars">
                                <img src="//gf2.geo.gfsrv.net/cdn76/5fd915f85b3e5e71b64632af0c6543.png" title="Mars">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Apollo" id="godApollo">
                                <img src="//gf3.geo.gfsrv.net/cdn8f/bb75bf0df76de3ec421bbfb0eac3c5.png" title="Apollo">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mercury" id="godMercury">
                                <img src="//gf3.geo.gfsrv.net/cdnbe/5e272e2aade20b4a266e48663421ce.png" title="Mercury">
                            </label>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="weaponBuff">${d.ui}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="weaponBuff">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Armor Buff Section -->
                    <div class="setting-row">
                        <label>${d.vi}</label>
                        <div class="armor-selection">
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Armor" id="armorBuffArmor"> ${d.O}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Helmet" id="armorBuffHelmet"> ${d.S}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Gloves" id="armorBuffGloves"> ${d.R}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Boots" id="armorBuffBoots"> ${d.P}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Shield" id="armorBuffShield"> ${d.U}
                            </label>
                        </div>
                    </div>

                    <!-- Farm Section (As Is) -->
                    <div class="settings_tab_title">${d.Xe}</div>
                    <span class="span-new">${d.Ye}: </span>
                    <div class="setting-row">
                        <label for="farmEnable">${d.v}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="farmEnable">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="farmLocation">${d.We}</label>
                        <select id="farmLocation">
                            <option value="0">Entrance</option>
                            <option value="1">Court of the Dead</option>
                            <option value="2">Tartarus</option>
                            <option value="3">Erebus</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="farmEnemy">${d.Ve}:</label>
                        <select id="farmEnemy">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">Boss</option>
                        </select>
                    </div>

                    <div class="setting-row" data-tooltip="${d.lj}">
                          <label for="useVillaMedici">${d.se}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="EnableHellLimit">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="hellLimit">${d.kj}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellLimit" min="1" max="200" value="${localStorage.getItem("hellLimit")||5}">
                        </div>
                    </div>

                    <div class="settings_tab_title">${d.ef}</div>
                    <div class="setting-row">
                          <label for="useVillaMedici">${d.Hi}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useVillaMedici">
                              <span class="switch"></span>
                          </label>
                    </div>
                    
                    <div class="setting-row">
                        <label for="useHealingPotion">${d.Fi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useHealingPotion">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <span class="span-new"> ${d.ri}</span>
                    <span class="span-new">${d.zi}</span>

                    <div class="settings_tab_title">${d.Td}</div>
                    <span class="span-new">Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.</span>
                    <div class="setting-row">
                          <label for="useCostume">${d.Di}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useCostume">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="wearUnderworld">${d.Ji}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="wearUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    
                    <div id="costumeUnderworldWrapper" style="display:none;">
                      <div class="setting-row">
                          <label for="costumeUnderworld">${d.fe}</label>
                          <select id="costumeUnderworld">
                              <option value="9">Dis Pater Normal</option>
                              <option value="10">Dis Pater Medium</option>
                              <option value="11">Dis Pater Hard</option>
                          </select>
                      </div>
                    </div>                

                    <div class="setting-row">
                      <label for="costumeBasic">${d.Yd}</label>
                      <select id="costumeBasic">
                          <option value="1">${d.$a}</option>
                          <option value="2">${d.eb}</option>
                          <option value="3">${d.fb}</option>
                          <option value="4">${d.gb}</option>
                          <option value="5">${d.hb}</option>
                          <option value="6">${d.ib}</option>
                          <option value="7">${d.jb}</option>
                          <option value="8">${d.kb}</option>
                          <option value="12">${d.lb}</option>
                          <option value="13">${d.ab}</option>
                          <option value="14">${d.bb}</option>
                          <option value="15">${d.cb}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <label for="costumeDungeon">${d.pe}</label>
                      <select id="costumeDungeon">
                          <option value="1">${d.$a}</option>
                          <option value="2">${d.eb}</option>
                          <option value="3">${d.fb}</option>
                          <option value="4">${d.gb}</option>
                          <option value="5">${d.hb}</option>
                          <option value="6">${d.ib}</option>
                          <option value="7">${d.jb}</option>
                          <option value="8">${d.kb}</option>
                          <option value="12">${d.lb}</option>
                          <option value="13">${d.ab}</option>
                          <option value="14">${d.bb}</option>
                          <option value="15">${d.cb}</option>
                      </select>
                    </div>
                    <span class="span-new">${d.Ud}</span>

                </div>
                  
                  <div class="popup-box" id="quests_settings">

                    <div class="settings_tab_title">Quests</div>

                    <div class="setting-row">
                      <div class="monster-buttons">
                        <span class="span-new">${d.type}</span>
                        <div class="quest-container">
                          <div id="do_combat_quests" class="settingsButton quest-type combat"></div>
                          <div id="do_arena_quests" class="settingsButton quest-type arena"></div>
                          <div id="do_circus_quests" class="settingsButton quest-type circus"></div>
                          <div id="do_expedition_quests" class="settingsButton quest-type expedition"></div>
                          <div id="do_dungeon_quests" class="settingsButton quest-type dungeon"></div>
                          <div id="do_items_quests" class="settingsButton quest-type items"></div>
                        </div>
                      </div>
                    </div>

                    <div class="settings_tab_title">Quest Settings</div>

                    <div class="setting-row">
                      <label for="skipTimeQuests">Arena ${d.Ea}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipTimeQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeCircusQuests">Circus ${d.Ea}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeCircusQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeOtherQuests">Other ${d.Ea}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeOtherQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                      <label for="UnderworldQuests">${d.xi}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="UnderworldQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row" id="underworldKeywordSection" style="display: none;">
                    ${d.wi}
                    <div class="input-container">
                        <input type="text" id="underworldKeywordInput" placeholder="${d.X}">
                        <button class="awesome-button" id="addUnderworldKeywordBtn">${d.K}</button>
                    </div>
                    <div id="underworldKeywordList"></div>
                </div>

                    <div class="setting-row">
                    <label for="acceptnotfilter">${d.Vg}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="acceptnotfilter">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="settings_tab_title">${d.bh}</div>
                      <div class="setting-row">
                        ${d.Ug}
                        <select id="questSpeed">
                        <option value="0">5x</option>
                        <option value="1">4x</option>
                        <option value="2">3x</option>
                        <option value="3">2x</option>
                        <option value="4">1x</option>
                      </select>
                    </div>
                    <div class="settings_tab_title">${d.Zg}</div>

                    <div class="setting-row">
                      ${d.Yg}
                      <div class="input-container">
                      <input type="text" id="keywordInput" placeholder="${d.X}">
                      <button class="awesome-button" id="addKeywordBtn">${d.K}</button>
                      </div>
                      <div id="keywordList"></div>
                    </div>
                    
                    <div class="settings_tab_title">${d.Wg}</div>

                    <div class="setting-row">
                        ${d.Xg}
                        <div class="input-container">
                            <input type="text" id="keywordAcceptInput" placeholder="${d.X}">
                            <button class="awesome-button" id="addKeywordAcceptBtn">${d.K}</button>
                        </div>
                        <div id="keywordAcceptList"></div>
                    </div>      

                    <div class="setting-row">
                        <label for="questrewardvalue">${d.oh}</label>
                        <div class="switch-field3">
                            <input type="number" id="questrewardvalue" min="1" max="99999" value="${localStorage.getItem("questrewardvalue")||2E3}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label>${d.$g}</label>
                        <div class="input-container">
                            <label><input type="checkbox" id="questTypeMercury"> Mercury</label>
                            <label><input type="checkbox" id="questTypeApollo"> Apollo</label>
                            <label><input type="checkbox" id="questTypeDiana"> Diana</label>
                            <label><input type="checkbox" id="questTypeMinerva"> Minerva</label>
                            <label><input type="checkbox" id="questTypeVulcan"> Vulcan</label>
                            <label><input type="checkbox" id="questTypeMars"> Mars</label>
                        </div>
                    </div>

                    
                    </div>


                <div class="popup-box" id="heal_settings">
                  <div class="monster-buttons">
                  </div>
                  <div class="settings_tab_title">${d.ij}</div>

                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; margin-right: 50px;">
                  </div>

                  <div class="setting-row">
                  <label for="healPercentage">${d.hj}</label>
                  <div class="switch-field3">
                    <input type="number" id="healPercentage" min="1" max="99" value="${localStorage.getItem("healPercentage")||75}">
                  </div>
                </div>

                  <div class="setting-row">
                  <img style="margin-top: -10px" src="https://gf3.geo.gfsrv.net/cdneb/91e0372cccc24f52758be611a10a3b.png">
                  <label for="HealClothToggle">${d.rh}</label>
                  
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealClothToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="HealRubyToggle">${d.cm}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealRubyToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healShopToggle">${d.uk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healShopToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healfrompackage">${d.vk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healfrompackage">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="HealPickBag">${d.cf}</label>
                     <select id="HealPickBag" class="input">
                     <option value="1">
                        1
                      </option>
                      <option value="2">
                        2
                      </option>
                      <option value="3">
                        3
                      </option>
                      <option value="4">
                        4
                      </option>
                      <option value="5">
                        5
                      </option>
                      <option value="6">
                        6
                      </option>
                      <option value="7">
                        7
                      </option>
                      <option value="8">
                      8
                    </option>
                    </select>
                  </div>
                  
                  <div class="setting-row">
                  <label for="FoodAmount">${d.gj}</label>
                   <select id="FoodAmount" class="input">
                   <option value="1">
                      1
                    </option>
                    <option value="2">
                      2
                    </option>
                    <option value="3">
                      3
                    </option>
                    <option value="4">
                      4
                    </option>
                    <option value="5">
                      5
                    </option>
                    <option value="6">
                      6
                    </option>
                    <option value="7">
                      7
                    </option>
                    <option value="8">
                    8
                  </option>
                  </select>
                </div>   
                  
                <div class="setting-row" data-tooltip="${d.Qi}">
                <label for="healcervisia">${d.rk}</label>
                <label class="toggle-switch">
                    <input type="checkbox" id="healcervisia">
                    <span class="switch"></span>
                </label>
                </div>

                  <div class="setting-row">
                  <label for="HealEggs">${d.tk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealEggs">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="settings_tab_title">${d.hf}</div>
                  <span class="span-new">${d.Ig}</span>
                  <div class="setting-row" data-tooltip="${d.xj}>
                  <label for="OilEnable">${d.ve}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="OilEnable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-right: 50px;">
                        <table style="width: 100%">
                            <tbody>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Minerva:</td>
                                <td style="text-align: right;">
                                    <div class="radio-group">
                                    <input type="radio" name="minerva" value="0"><span class="span-new">I</span>
                                    <input type="radio" name="minerva" value="1"><span class="span-new">II</span>
                                    <input type="radio" name="minerva" value="2"><span class="span-new">III</span>
                                    <input type="radio" name="minerva" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Diana:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="diana" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="diana" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="diana" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="diana" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Mars:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="mars" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="mars" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="mars" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="mars" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Merkur:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="merkur" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="merkur" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="merkur" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="merkur" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Apollo:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="apollo" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="apollo" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="apollo" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="apollo" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: bold; text-align: left; width: 30%">Vulcanus:</td>
                                    <td>
                                        <div class="radio-group">
                                            <input type="radio" name="vulcanus" value="0"><span class="span-new">I</span>
                                            <input type="radio" name="vulcanus" value="1"><span class="span-new">II</span>
                                            <input type="radio" name="vulcanus" value="2"><span class="span-new">III</span>
                                            <input type="radio" name="vulcanus" value="3" checked="true"><span class="span-new">Off</span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                            </table>
                        </div>

                        <hr>
                        <!-- Container for Oil Usage Table (hidden by default if oils are disabled) -->
                        <div id="oilUsageSettings" class="oil-usage-settings" style="display: none;">
                        <h4>Oil Usage Options</h4>
                        <hr>
                        <table>
                            <thead>
                            <tr>
                                <th>Oil</th>
                                <th>Rings</th>
                                <th>Necklace</th>
                                <th>Weapons</th>
                                <th>Armor</th>
                            </tr>
                            </thead>
                            <tbody>
                            <!-- Blue Oil (only rings, necklace) -->
                            <tr>
                                <td>Blue Oil</td>
                                <td><input type="checkbox" id="blue-oil-rings"></td>
                                <td><input type="checkbox" id="blue-oil-necklace"></td>
                                <!-- Weapons & Armor not allowed for Blue Oil, so disabled -->
                                <td><input type="checkbox" disabled></td>
                                <td><input type="checkbox" disabled></td>
                            </tr>

                            <!-- Yellow Oil (rings, necklace, weapons, armor) -->
                            <tr>
                                <td>Yellow Oil</td>
                                <td><input type="checkbox" id="yellow-oil-rings"></td>
                                <td><input type="checkbox" id="yellow-oil-necklace"></td>
                                <td><input type="checkbox" id="yellow-oil-weapons"></td>
                                <td><input type="checkbox" id="yellow-oil-armor"></td>
                            </tr>

                            <!-- Orange Oil (only rings, necklace) -->
                            <tr>
                                <td>Orange Oil</td>
                                <td><input type="checkbox" id="orange-oil-rings"></td>
                                <td><input type="checkbox" id="orange-oil-necklace"></td>
                                <td><input type="checkbox" disabled></td>
                                <td><input type="checkbox" disabled></td>
                            </tr>

                            <!-- Green Oil (rings, necklace, weapons, armor) -->
                            <tr>
                                <td>Green Oil</td>
                                <td><input type="checkbox" id="green-oil-rings"></td>
                                <td><input type="checkbox" id="green-oil-necklace"></td>
                                <td><input type="checkbox" id="green-oil-weapons"></td>
                                <td><input type="checkbox" id="green-oil-armor"></td>
                            </tr>

                            <!-- Purple Oil (rings, necklace, weapons, armor) -->
                            <tr>
                                <td>Purple Oil</td>
                                <td><input type="checkbox" id="purple-oil-rings"></td>
                                <td><input type="checkbox" id="purple-oil-necklace"></td>
                                <td><input type="checkbox" id="purple-oil-weapons"></td>
                                <td><input type="checkbox" id="purple-oil-armor"></td>
                            </tr>

                            <tr>
                                <td>Red Oil</td>
                                <td><input type="checkbox" id="red-oil-rings"></td>
                                <td><input type="checkbox" id="red-oil-necklace"></td>
                                <td><input type="checkbox" id="red-oil-weapons"></td>
                                <td><input type="checkbox" id="red-oil-armor"></td>
                            </tr>
                            </tbody>
                        </table>
                        </div>
                    </div>
<div class="settings_tab_title">${d.Xa}</div>
<span class="span-new">Bot will use buffs when available.</span>

<div class="setting-row" data-tooltip="${d.Oi}>
    <label for="BuffsEnable">Enable ${d.Xa}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffsEnable">
        <span class="switch"></span>
    </label>
</div>

<div class="setting-row">
    <label for="BuffUnderworldOnly">${d.ce}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffUnderworldOnly">
        <span class="switch"></span>
    </label>
</div>


<div class="setting-row">
    <div class="buff-group">
        <label>Health:</label>
        <input type="checkbox" id="HealthBuff1"> Gingko
        <input type="checkbox" id="HealthBuff2"> Taigaroot
        <input type="checkbox" id="HealthBuff3"> Hawthorn
    </div>

    <div class="buff-group">
        <label>Strength:</label>
        <input type="checkbox" id="StrengthBuff1"> Flask
        <input type="checkbox" id="StrengthBuff2"> Ampulla
        <input type="checkbox" id="StrengthBuff3"> Flacon
        <input type="checkbox" id="StrengthBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Dexterity:</label>
        <input type="checkbox" id="DexterityBuff1"> Flask
        <input type="checkbox" id="DexterityBuff2"> Ampulla
        <input type="checkbox" id="DexterityBuff3"> Flacon
        <input type="checkbox" id="DexterityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Agility:</label>
        <input type="checkbox" id="AgilityBuff1"> Flask
        <input type="checkbox" id="AgilityBuff2"> Ampulla
        <input type="checkbox" id="AgilityBuff3"> Flacon
        <input type="checkbox" id="AgilityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Constitution:</label>
        <input type="checkbox" id="ConstitutionBuff1"> Flask
        <input type="checkbox" id="ConstitutionBuff2"> Ampulla
        <input type="checkbox" id="ConstitutionBuff3"> Flacon
        <input type="checkbox" id="ConstitutionBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Charisma:</label>
        <input type="checkbox" id="CharismaBuff1"> Flask
        <input type="checkbox" id="CharismaBuff2"> Ampulla
        <input type="checkbox" id="CharismaBuff3"> Flacon
        <input type="checkbox" id="CharismaBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Intelligence:</label>
        <input type="checkbox" id="IntelligenceBuff1"> Flask
        <input type="checkbox" id="IntelligenceBuff2"> Ampulla
        <input type="checkbox" id="IntelligenceBuff3"> Flacon
        <input type="checkbox" id="IntelligenceBuff4"> Bottle
    </div>
</div>
                  </div>

                  <div class="popup-box" id="event_expedition_settings">
                    <div class="settings_tab_title">${d.eventExpedition}</div>

                    <div class="setting-row">
                        <div id="set_event_monster_id_0" class="monster-button">1</div>
                        <div id="set_event_monster_id_1" class="monster-button">2</div>
                        <div id="set_event_monster_id_2" class="monster-button">3</div>
                        <div id="set_event_monster_id_3" class="monster-button">Boss</div>
                    </div>
                    <div id="clear_next_event_expedition_time" class="awesome-button">${d.eh}</div> <!-- New Button -->

                      <div class="setting-row">
                      <label for="renewEvent">${d.hh}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="renewEvent">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <label for="throwDice">${d.Nh}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="throwDice">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <span class="span-new">${d.Oh}<span class="span-new">
                      
                                          </div>
                      <div class="setting-row">
                    <span class="span-new">${d.xe}<span class="span-new">
                    
                                        </div>
                    </div>

                  <div class="popup-box" id="auto_auction_settings">
                

                    <div class="settings_tab_title">${d.Qd}</div>
                    <span class="span-new">To open search panels including Unique shop items, enable this option.<span class="span-new">
                    <div class="setting-row">
                    <label for="AuctionItemLevel2">${d.Ag}</label>
                      <div class="switch-field2">
                        <input type="text" id="search_input" placeholder="${d.Cd}">
                      </div>
                    </div>

                    <div class="setting-row">
                      <label for="AuctionItemLevel2">${d.ba}</label>
                      <div class="switch-field3">
                        <input type="number" id="AuctionItemLevel2" min="1" max="1000" value="5">
                      </div>
                    </div>   

                    <div class="setting-row">
                      <label for="SearchQuality">${d.Ba}</label>
                      <select id="SearchQuality" class="input">
                          <option value="-1">
                          ${d.Ga}
                          </option>
                            <option value="0">
                            ${d.C}
                            </option>
                            <option value="1">
                            ${d.B}
                            </option>
                            <option value="2">
                            ${d.D}
                            </option>
                          </option>
                      </select>
                    </div> 

                    <div class="setting-row">
                      <label>${d.na}</label>
                      <div class="equipment-search-selection">
                          <label><input type="checkbox" class="equipment-search-option" value="2"> ${d.ga}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="4"> ${d.da}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="8"> ${d.W}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1"> ${d.Z}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="256"> ${d.Y}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="512"> ${d.ea}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="48"> ${d.ca}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1024"> ${d.V}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="9999"> ${d.Ja}</label>
                      </div>
                    </div>

                    <button class="awesome-button" id="search_button" type="button">${d.Cd}</button>
                    <button class="awesome-button" id="search_reset" type="button">${d.Jd}</button>
       
                    <div class="setting-row">
                    <ul id="search_list"></ul>
                    <span class="span-new">${d.Ld}</span>
                    </div>

                    <div class="settings_tab_title">${d.vh}</div>
                    <div class="setting-row">

                      <!-- Title & Instructions -->
                      <div style="margin-bottom: 20px;">
                          <h2>${d.xh}</h2>
                          <p>${d.wh}</p>
                      </div>
                    </div>
                    <!-- Item Input Section -->

                        <div class="setting-row">
                          <label for="clothCount">${d.yh}</label>
                          <div class="switch-field2">
                              <input type="number" id="clothCount" placeholder="${d.zh}">
                          </div>
                        </div>

                        <hr class="section-separator">

                        <div class="setting-row">
                              <label for="newItem">${d.fa}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItem" placeholder="${d.fa}">
                          </div>
                        </div>

                        <div class="setting-row">
                          <label for="newItemLevel">Min ${d.Wb}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItemLevel" placeholder="Min ${d.Wb}">
                          </div>
                        </div>
                
                        <div class="setting-row">
                          <label for="itemQuality">Min ${d.Bh}:</label>
                          <select id="itemQuality">
                              <option value="0">${d.C}</option>
                              <option value="1">${d.B}</option>
                              <option value="2">${d.D}</option>
                              <option value="3">${d.J}</option>
                              <option value="4">${d.T}</option>
                          </select>
                        </div>

                        <!-- New Stat Selection with Combo Box -->
                        <div class="setting-row">
                        <label for="shopitemstat">Stat:</label>
                        <select id="shopitemstat">
                            <option value="none">NONE</option>
                            <option value="str">Strength</option>
                            <option value="dex">Dexterity</option>
                            <option value="agi">Agility</option>
                            <option value="cot">Constitution</option>
                            <option value="chr">Charisma</option>
                            <option value="int">Intelligence</option>
                        </select>
                        </div>

                        <div class="setting-row" id="statValueRow" style="display: none;">
                        <label for="statValue">Value:</label>
                        <div class="switch-field2">
                            <input type="number" id="statValue" placeholder="0">
                        </div>
                        </div>
                        

                        <div style="text-align: right;">
                        <button class="awesome-button" id="addItemButton">${d.K}</button>
                      </div>

                      <div class="setting-row">
                        <div id="itemsList" style="margin-bottom: 10px;">
                        <!-- Example item -->
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="flex: 1;">${d.Ah}</span>
                            <button onclick="removeItem('uniqueItemID')">X</button>
                        </div>
                        <!-- Add more items similarly -->
                        </div>
                      </div>  
                  
                      <!-- Search Buttons -->
                      <div style="display: flex; justify-content: space-between; gap: 10px; margin-bottom: 20px;">
                        <button class="awesome-button" id="startSearchButton">${d.Ch}</button>
                        <button class="awesome-button" id="skipSearchButton" style="display: none;">${d.Dh}</button>
                        <button class="awesome-button" id="stopSearchButton">${d.Eh}</button>
                      </div>
                      <div class="setting-row">
                      <!-- Progress Bar -->
                      <div style="margin-bottom: 20px;">
                          <label>${d.uh}:</label>
                          <div id="progressBarOuter" style="width: 100%; height: 20px; background-color: grey; border-radius: 10px;">
                              <div id="progressBarInner" style="height: 100%; width: 0%; background-color: green; border-radius: 10px;"></div>
                          </div>
                      </div>
                  
                      <!-- Found Items Container -->
                      <div id="foundItemsContainer"></div>
                    </div>
                </div>

                <div class="popup-box" id="auto_auction2_settings">

                <div class="settings_tab_title">${d.Mh}</div>
           
                <div class="setting-row" data-tooltip="${d.Pd}">
                <label for="storeGoldinAuction">${d.v}</label>
                  <label class="toggle-switch">
                  <input type="checkbox" id="storeGoldinAuction">
                  <span class="switch"></span>
                  </label>
                  </div>

                <div class="setting-row">
                  <label for="itemsToReset2">${d.Da}</label>
                  <div id="itemsToReset2" class="items-reset-list">
                      <div class="item-reset"><input type="checkbox" id="WEAPONS2" value="WEAPONS2"><label for="WEAPONS">${d.pa}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHIELD2" value="SHIELD2"><label for="SHIELD">${d.U}</label></div>
                      <div class="item-reset"><input type="checkbox" id="CHEST2" value="CHEST2"><label for="CHEST">${d.O}</label></div>
                      <div class="item-reset"><input type="checkbox" id="HELMET2" value="HELMET2"><label for="HELMET">${d.S}</label></div>
                      <div class="item-reset"><input type="checkbox" id="GLOVES2" value="GLOVES2"><label for="GLOVES">${d.R}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHOES2" value="SHOES2"><label for="SHOES">${d.P}</label></div>
                      <div class="item-reset"><input type="checkbox" id="RINGS2" value="RINGS2"><label for="RINGS">${d.oa}</label></div>
                      <div class="item-reset"><input type="checkbox" id="AMULETS2" value="AMULETS2"><label for="AMULETS">${d.la}</label></div>
                  </div>
                </div>

                <div class="setting-row">
                    <label for="storeInShopQuality">${d.Ba}</label>
                    <select id="storeInShopQuality" class="input">
                    <option value="0">
                    ${d.C}
                    </option><!-- Add more options as needed -->
                        <option value="1">
                        ${d.B}
                        </option>
                        <option value="2">
                        ${d.D}
                        </option>
                  </select>
                

                </div>

                <div class="setting-row">
                <label for="storeGoldinAuctionmaxGold">${d.pg}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionmaxGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionmaxGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
                <label for="storeGoldinAuctionholdGold">${d.aa}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionholdGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionholdGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
              <label for="AuctionGoldCover">${d.mb}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="AuctionGoldCover">
                <span class="switch"></span>
              </label>
            </div>

                <span class="span-new">${d.ph}</span>
                  
                    <div class="settings_tab_title">${d.Fg}</div>
                    <span class="span-new">${d.Rd}</span>
                    
                    <div class="setting-row">
                      <div class="table-container">
                          <table class="styled-table">
                            <thead>
                              <tr>
                                <th>Prefix</th>
                                <th>Suffix</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="AuctionprefixList"></ul>
                                </td>
                                <td>
                                  <ul class="styled-list" id="AuctionsuffixList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                 
                                    <input type="text" class="styled-input" id="AuctionnewPrefixInput">
                                    <input type="button" id="AuctionaddPrefixButton" value="${d.Qa}">
                                  </div>
                                </td>
                                <td>
                                  <div class="list-options">
                                    <input type="text" class="styled-input" id="AuctionnewSuffixInput">
                                    <input type="button" id="AuctionaddSuffixButton" value="${d.Ra}">
                                  </div>
                                </td>

                              </tr>
                            </tbody>
                          </table>
                          
                      </div>
                      
                    </div>
                  
                    <div class="setting-row">
                        <label>${d.na}</label>
                        <div class="equipment-selection">
                            <label><input type="checkbox" class="equipment-option" value="2"> ${d.ga}</label>
                            <label><input type="checkbox" class="equipment-option" value="4"> ${d.da}</label>
                            <label><input type="checkbox" class="equipment-option" value="8"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option" value="1"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option" value="256"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option" value="512"> ${d.ea}</label>
                            <label><input type="checkbox" class="equipment-option" value="48"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option" value="1024"> ${d.V}</label>
                            <label><input type="checkbox" class="equipment-option" value="9999"> ${d.Ja}</label>
                        </div>
                    </div>

                      <div class="setting-row" data-tooltip="${d.qk}">
                        <label for="auctionTURBO">Turbo Mode Speed >> </label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionTURBO">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctiongladiatorenable">${d.qh}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctiongladiatorenable">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctionmercenaryenable">${d.th}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionmercenaryenable">
                          <span class="switch"></span>
                         </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Nd}>
                        <label for="ignorePS">${d.lf}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="ignorePS">
                            <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Va}>
                        <label for="bidFood">${d.Zd}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="bidFood">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Md}>
                      <label for="AuctionCover">${d.mb}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="AuctionCover">
                        <span class="switch"></span>
                      </label>
                    </div>

                      <div class="setting-row" data-tooltip="${d.Va}>
                        <label for="bidfood">${d.qg}</label>
                        <div class="switch-field3">
                          <input type="number" id="maximumBid" min="1" max="1000000" value="25">
                        </div>
                      </div>

                      <div class="setting-row">
                        <label for="aunctionMinQuality">${d.Ba}</label>
                         <select id="auctionMinQuality" class="input">
                          <option value="2">
                          ${d.D}
                          </option>
                          <option value="1">
                          ${d.B}
                          </option>
                          <option value="0">
                          ${d.C}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                    <div class="setting-row">
                      <label for="auctionminlevel">${d.ba}</label>
                      <div class="switch-field3">
                        <input type="number" id="auctionminlevel" min="1" max="1000" value="0">
                      </div>
                    </div>

                      <div class="setting-row">
                        <label for="bidStatus">${d.$d}</label>
                         <select id="bidStatus" class="input">
                          <option value="4">
                          ${d.bc}
                          </option>
                          <option value="3">
                          ${d.Yb}
                          </option>
                          <option value="2">
                          ${d.Kb}
                          </option>
                          <option value="1">
                          ${d.Cb}
                          </option>
                          <option value="0">
                          ${d.ac}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                      <div class="setting-row">
                        <label for="enableMercenarySearch">${d.$i}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="enableMercenarySearch">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="mercenarySearchOptions" style="display:none">
                        <div class="setting-row">
                        
                            <label for="minDexterity">Min: ${d.Dexterity}</label>
                            <div class="switch-field3">
                                <input type="number" id="minDexterity" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minAgility">Min: ${d.Agility}</label>
                            <div class="switch-field3">
                                <input type="number" id="minAgility" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minIntelligence">Min: ${d.Intelligence}</label>
                            <div class="switch-field3">
                                <input type="number" id="minIntelligence" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <span class="span-new">Enter 0 to ignore stats.</span>
                    </div>
                      
                      <div class="setting-row">
                        <h4>${d.ae}</h4>
                        <div class="table-container">
                          <table class="styled-table">
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="bidList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                    <input type="button" class="awesome-button" id="clearBidItemsHistory" value="${d.Za}">
                                  </div>
                                  
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                  </div>

                <div class="popup-box" id="auto_smelt_settings">
                    <div class="settings_tab_title" style="position: relative;">
                        Auto Smelt
                        <i class="fas fa-info-circle" id="autoSmeltInfo" style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 22px; color: black;"></i>

                    
                    </div>


                    <div class="rule-container">
                    <!-- Rule Row Template -->
                    <div class="rule-row-template" style="display: none;">
                        <!-- Top row (Condition, Prefix, Scroll, Level) -->
                        <div class="rule-top-row">
     
                            <label class="rule-checkbox-wrapper">
        
                                <input type="checkbox" class="rule-checkbox">
                                <span class="checkbox-icon"></span>
                                
                            </label>

                            &nbsp

                            <!-- Condition Combo Box -->
                            <select class="rule-condition-select">
                                <option value="nameContains">${d.Eg}</option>
                                <option value="isUnderworldItem">${d.isUnderworldItem}</option>
                            </select>

                            <!-- Text input appears only for 'Name contains' -->
                            <input type="text" class="rule-prefix-input" placeholder="${d.Mb}" />
                            <input type="text" class="rule-suffix-input" placeholder="${d.Zb}" />

                            <!-- Scroll Combo Box 
                            <select class="rule-scroll-select">
                                <option value="noScroll">No scroll</option>
                                <option value="anyScroll">Has any scroll</option>
                            </select>
                            -->

                            <input type="number" class="rule-level" placeholder="lvl>">
                        </div>

                        <!-- Second row (Item Types, Colors, Hammer) -->
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection">
                                <span class="color-circle white" data-color="white"></span>
                                <span class="color-circle green" data-color="green"></span>
                                <span class="color-circle blue" data-color="blue"></span>
                                <span class="color-circle purple" data-color="purple"></span>
                                 <span class="color-circle orange" data-color="orange"></span>
                                <span class="color-circle red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

                            <button class="remove-rule-btn">X</button>
                        </div>
                    </div>

                    <!-- Add Rule Button -->
                    <button class="add-rule-btn">${d.Gg}</button>
                    <hr style="border: 1px solid #c4ac70; margin: 10px 0;">
                </div>



                    <!-- Condition Selection  
                    <div class="setting-row">
                        <label for="smeltCondition">Condition:</label>
                        <select id="smeltCondition" class="styled-select" style="width:200px">
                            <option value="name_contains">Name contains</option>
                            <option value="name_word">Name contains word</option>
                            <option value="color">Item color is</option>
                            <option value="underworld_prefix_suffix">Item has underworld prefix/suffix</option>
                        </select>
                    </div>
                    
                    <div class="setting-row" id="filterNameRow">
                        <label for="filterNameInput">Filter Profile Name:</label>
                        <input type="text" id="filterNameInput" class="styled-input3" placeholder="Enter profile name" />
                    </div>

                    <div class="setting-row" id="itemNameRow" style="display: none;">
                        <label for="itemNameInput">Item Name:</label>
                        <input type="text" id="itemNameInput" class="styled-input" placeholder="Enter item name" />
                    </div>
                    
                    <div class="setting-row" id="colorRow" style="display: none;">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                

                    <div class="setting-row">
                        <h4>Added Filters</h4>
                        <div id="filtersList" class="filter-list"></div>
                    </div>


                    <div class="setting-row">
                        <h4>Saved Items</h4>
                        <div id="savedItemsList" class="filter-list"></div>
                    </div>

                    

                    <div class="setting-row">
                        <label>${d.na}</label>
                        <div class="equipment-selection-smelt">
                            <label><input type="checkbox" class="equipment-option-smelt" value="2"> ${d.ga}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="4"> ${d.da}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="8"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="256"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="512"> ${d.ea}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="48"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1024"> ${d.V}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="9999"> ${d.Ja}</label>
                        </div>
                    </div>
                  

                    <div class="setting-row" id="colorRowOriginal">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                    

                    <div class="setting-row">
                        <label for="smeltUnderworld">Smelt only Underworld/Hell items?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="smeltUnderworld">
                        <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="smeltLootbox">${d.Sj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="smeltLootbox">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltIgnorePS">${d.Rj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltIgnorePS">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->

                    <div class="setting-row">
                      <label for="smeltAnything">${d.Ih}</label>
                      
                      <label class="toggle-switch" data-tooltip="${d.Tj}">
                        <input type="checkbox" id="smeltAnything">
                        <span class="switch"></span>
                      </label>
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection2">
                                <span class="color-circle2 white" data-color="white"></span>
                                <span class="color-circle2 green" data-color="green"></span>
                                <span class="color-circle2 blue" data-color="blue"></span>
                                <span class="color-circle2 purple" data-color="purple"></span>
                                 <span class="color-circle2 orange" data-color="orange"></span>
                                <span class="color-circle2 red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection2">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

        
                        </div>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Uj}">
                      <label for="smelteverything3">${d.bk}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smelteverything3">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="smelthighercolors">${d.ck}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smelthighercolors">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="RepairBeforeSmelt">${d.Kj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="RepairBeforeSmelt">
                        <span class="switch"></span>
                      </label>
                        <div class="setting-row">
                        <label for="repairBeforeSmeltMaxQuality">${d.Rc}</label>
                            <select id="repairBeforeSmeltMaxQuality" class="input">
                                    <option value="3">
                                    ${d.J}
                                    </option>
                                    <option value="2">
                                    ${d.D}
                                    </option>
                                    <option value="1">
                                    ${d.B}
                                    </option>
                                    <option value="0">
                                    ${d.C}
                                    </option>
                                    <option value="-1">
                                    ${d.Ga}
                                    </option>
                            </select>
                        </div>
                        <div class="setting-row">
                        <label for="PartialOrFull">${d.Mg}</label>
                            <select id="PartialOrFull" class="input">
                                    <option value="0">
                                    ${d.Ng}
                                    </option>
                                    <option value="1">
                                    ${d.af}
                                    </option>
                            </select>
                        </div>
                    </div>

                    
                    <div class="setting-row">
                        <label for="smeltTab">${d.Jh}</label>
                        <select id="smeltTab" class="input">
                        <option value="6">
                            8
                        </option>
                            <option value="5">
                                7
                            </option>
                            <option value="4">
                                6
                            </option>
                            <option value="3">
                                5
                            </option>
                            <option value="2">
                                4
                            </option>
                            <option value="1">
                                3
                            </option>
                            <option value="0">
                                2
                            </option>
                        </select>
                    </div>


                    <div class="settings_tab_title">${d.Hh}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                <thead>
                                    <tr>
                                    <th>${d.Mb}</th>
                                    <th>${d.Zb}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td>
                                        <ul class="styled-list" id="IgnoredprefixList"></ul>
                                    </td>
                                    <td>
                                        <ul class="styled-list" id="IgnoredsuffixList"></ul>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredPrefixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddPrefixButton" value="${d.Qa}">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredSuffixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddSuffixButton" value="${d.Ra}">
                                        </div>
                                    </td>
                                    </tr>
                                </tbody>
                                </table>          
                        </div>
                    </div>
                    
                    <!-- Smelted Items List -->
                  
                    <div class="settings_tab_title">${d.ak}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                    <tbody>
                                    <tr>
                                        <td>
                                        <ul class="styled-list" id="smeltedList"></ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <div class="list-options">
                                            <input type="button" class="awesome-button" id="clearSmeltedItemsHistory" value="${d.Za}">
                                            
                                        </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>    
                        </div>
                    </div>
                </div>

                
                <div class="popup-box" id="auto_repair_settings">
                <div class="settings_tab_title">${d.Pb}</div>
                <div class="setting-row">

                    <div class="inventory gladiator-inventory">
                        <h3>Gladiator</h3>
                        <!-- Inventory Rows for Gladiator -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weapon">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmet">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armor">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shield">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="gloves">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoes">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklace">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>

                        </div>
                    </div>

                    <div class="inventory mercenary-inventory">
                        <h3>Mercenary</h3>
                        <!-- Inventory Rows for Mercenary -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weaponM">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmetM">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armorM">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shieldM">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="glovesM">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoesM">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1M">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2M">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklaceM">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>
                        </div>
                    </div>

                    <div class="instructions" style="clear: both;">
                            <span class="span-new">${d.ic}</span><br>
                            <span class="span-new">${d.ih}</span>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="repairGladiator">${d.Fa} Gladiator?</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="repairGladiator">
                            <span class="switch"></span>
                        </label>
                    </div>
                  
                    <div class="setting-row">
                        <label for="repairMercenary">${d.Fa} Mercenary?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="repairMercenary">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="repairPercentage">${d.Bg}</label>
                        <select id="repairPercentage" class="input">
                        <option value="3">%10</option>
                        <option value="2">%20</option>
                        <option value="1">%30</option>
                        <option value="0">%40</option>
                        <option value="-1">%50</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="repairMaxQuality">${d.Rc}</label>
                        <select id="repairMaxQuality" class="input">
                                <option value="3">
                                ${d.J}
                                </option>
                                <option value="2">
                                ${d.D}
                                </option>
                                <option value="1">
                                ${d.B}
                                </option>
                                <option value="0">
                                ${d.C}
                                </option>
                                <option value="-1">
                                ${d.Ga}
                                </option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="currentWorkbenchItem">${d.he}</label>
                        <span id="currentWorkbenchItem"></span> <!-- Item name will be displayed here -->
                    </div>

                    <div class="setting-row">
                        <div id="clear_repair" style="display:flex;" class="awesome-button">${d.xk}</div>
                    </div>

                    <div class="setting-row" id="ignoreMaterialsSection" style="margin-top: 10px; border-top: 1px solid #b3a77a; padding-top: 10px; background: linear-gradient(to right, #e8e1c8, #dacfa1); border-radius: 8px;">
                        <h3 style="color: #5a5a5a; font-family: 'Arial', sans-serif; text-align: center; text-transform: uppercase; letter-spacing: 2px;">${d.kf}</h3>
                        
                        <!-- Scrollable list of materials -->
                        <div id="ignoreMaterialsList" style="border-radius: 4px; padding: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); height: 300px; max-height: 300px; overflow-y: auto; display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                            <!-- Base Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Base Materials</h4>
                                <label><input type="checkbox" value="1"> ${d.Pc}</label><br>
                                <label><input type="checkbox" value="2"> ${d.Fc}</label><br>
                                <label><input type="checkbox" value="3"> ${d.Jc}</label><br>
                                <label><input type="checkbox" value="4"> ${d.Lc}</label><br>
                            </div>

                            <!-- Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Materials</h4>
                                <label><input type="checkbox" value="13"> ${d.Qc}</label><br>
                                <label><input type="checkbox" value="14 Wool"> ${d.Gc}</label><br>
                                <label><input type="checkbox" value="15"> ${d.Ic}</label><br>
                                <label><input type="checkbox" value="16"> ${d.Hc}</label><br>
                                <label><input type="checkbox" value="17"> ${d.Mc}</label><br>
                                <label><input type="checkbox" value="18"> ${d.Kc}</label><br>
                                <label><input type="checkbox" value="19"> ${d.Oc}</label><br>
                                <label><input type="checkbox" value="20"> ${d.Nc}</label><br>
                            </div>

                            <!-- Monster Parts category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Monster Parts</h4>
                                <label><input type="checkbox" value="5"> ${d.Yc}</label><br>
                                <label><input type="checkbox" value="6"> ${d.Sc}</label><br>
                                <label><input type="checkbox" value="7"> ${d.ad}</label><br>
                                <label><input type="checkbox" value="8"> ${d.Vc}</label><br>
                                <label><input type="checkbox" value="9"> ${d.Xc}</label><br>
                                <label><input type="checkbox" value="10> ${d.Wc}</label><br>
                                <label><input type="checkbox" value="11"> ${d.Tc}</label><br>
                                <label><input type="checkbox" value="12"> ${d.$c}</label><br>
                                <label><input type="checkbox" value="55"> ${d.Uc}</label><br>
                                <label><input type="checkbox" value="58"> ${d.Zc}</label><br>
                                <label><input type="checkbox" value="62"> ${d.bd}</label><br>
                                <label><input type="checkbox" value="64"> ${d.cd}</label><br>
                            </div>

                            <!-- Gemstones category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Gemstones</h4>
                                <label><input type="checkbox" value="21"> ${d.Cc}</label><br>
                                <label><input type="checkbox" value="22"> ${d.wc}</label><br>
                                <label><input type="checkbox" value="23"> ${d.vc}</label><br>
                                <label><input type="checkbox" value="24"> ${d.xc}</label><br>
                                <label><input type="checkbox" value="25"> ${d.Dc}</label><br>
                                <label><input type="checkbox" value="26"> ${d.Ac}</label><br>
                                <label><input type="checkbox" value="27"> ${d.zc}</label><br>
                                <label><input type="checkbox" value="28"> ${d.yc}</label><br>
                                <label><input type="checkbox" value="59"> ${d.Bc}</label><br>
                                <label><input type="checkbox" value="63"> ${d.Ec}</label><br>
                            </div>

                            <!-- Flasks category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Flasks</h4>
                                <label><input type="checkbox" value="37"> ${d.qc}</label><br>
                                <label><input type="checkbox" value="38"> ${d.tc}</label><br>
                                <label><input type="checkbox" value="39"> ${d.mc}</label><br>
                                <label><input type="checkbox" value="40"> ${d.lc}</label><br>
                                <label><input type="checkbox" value="41"> ${d.sc}</label><br>
                                <label><input type="checkbox" value="42"> ${d.pc}</label><br>
                                <label><input type="checkbox" value="43"> ${d.nc}</label><br>
                                <label><input type="checkbox" value="44"> ${d.oc}</label><br>
                                <label><input type="checkbox" value="53"> ${d.uc}</label><br>
                                <label><input type="checkbox" value="61"> ${d.rc}</label><br>
                            </div>

                            <!-- Runes category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Runes</h4>
                                <label><input type="checkbox" value="29"> ${d.Bd}</label><br>
                                <label><input type="checkbox" value="30"> ${d.vd}</label><br>
                                <label><input type="checkbox" value="31"> ${d.td}</label><br>
                                <label><input type="checkbox" value="32"> ${d.Ad}</label><br>
                                <label><input type="checkbox" value="33"> ${d.zd}</label><br>
                                <label><input type="checkbox" value="34"> ${d.xd}</label><br>
                                <label><input type="checkbox" value="35"> ${d.ud}</label><br>
                                <label><input type="checkbox" value="36"> ${d.yd}</label><br>
                                <label><input type="checkbox" value="60"> ${d.wd}</label><br>
                            </div>

                            <!-- Ores category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Ores</h4>
                                <label><input type="checkbox" value="45"> ${d.gd}</label><br>
                                <label><input type="checkbox" value="46"> ${d.fd}</label><br>
                                <label><input type="checkbox" value="47"> ${d.ld}</label><br>
                                <label><input type="checkbox" value="48"> ${d.od}</label><br>
                                <label><input type="checkbox" value="49"> ${d.pd}</label><br>
                                <label><input type="checkbox" value="50"> ${d.jd}</label><br>
                                <label><input type="checkbox" value="51"> ${d.nd}</label><br>
                                <label><input type="checkbox" value="52"> ${d.md}</label><br>
                                <label><input type="checkbox" value="54"> ${d.ed}</label><br>
                                <label><input type="checkbox" value="56"> ${d.hd}</label><br>
                                <label><input type="checkbox" value="57"> ${d.kd}</label><br>
                            </div>

                            <!-- Fragments category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Fragments</h4>
                                <label><input type="checkbox" value="65"> Material Fragment</label><br>
                                <label><input type="checkbox" value="66"> Monster Piece</label><br>
                                <label><input type="checkbox" value="67"> Gemstone Shard</label><br>
                                <label><input type="checkbox" value="68"> Flask Component</label><br>
                                <label><input type="checkbox" value="69"> Rune Splinter</label><br>
                                <label><input type="checkbox" value="70"> Ore Sample}</label><br>
                                <label><input type="checkbox" value="71"> Scroll Fragment</label><br>

                            </div>
                        </div>

                    </div>

                </div>


                <div class="popup-box" id="guild_settings">

                    <!-- Guld stuff comes here -->

                    <div class="settings_tab_title">${d.Lh}</div>

                        <span class="span-new">${d.Zi}:</span>
                        <span class="span-new">${d.vf}</span>
                  
                        <div class="setting-row">
                            <label for="doKasa">${d.v}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="doKasa">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="AuctionItemLevel2">${d.Cg}</label>
                            <div class="switch-field2">
                            <input type="number" id="minimumGoldAmount" placeholder="Amount" value="${localStorage.getItem("minimumGoldAmount")||0}">         
                            </div>
                        </div>

                        <div class="setting-row">
                            <label for="filterGM">${d.Ze}</label>
                            <select id="filterGM">
                            <option value="" disabled>${d.Da}</option>
                            <option value="pd">${d.Dg}</option>
                            <option value="p">${d.ee}</option>
        
                            </select>
                        </div>

                        <div class="setting-row">
                            <label for="guildPackHour">${d.Ub}</label>
                            <select id="guildPackHour">
                            <option value="" disabled>${d.Ub}</option>
                            <option value="1">2 hr</option>
                            <option value="2">8 hr</option>
                            <option value="3">24 hr</option>
                            </select>
                        </div>

                        <div class="setting-row">
                        <label for="KasaHoldGold">${d.aa}</label>
                            <div class="switch-field3">
                            <input type="number" id="KasaHoldGold" placeholder="Amount" value="${localStorage.getItem("KasaHoldGold")||0}">       
                                </div>
                        </div>

                        <div class="setting-row">
                            <label for="itemsToResetGuild">${d.Da}</label>
                            <div id="itemsToResetGuild" class="items-reset-list">
                                <div class="item-reset"><input type="checkbox" id="GUILD_WEAPONS" value="GUILD_WEAPONS"><label for="GUILD_WEAPONS">${d.pa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHIELD" value="GUILD_SHIELD"><label for="GUILD_SHIELD">${d.U}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_CHEST" value="GUILD_CHEST"><label for="GUILD_CHEST">${d.O}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_HELMET" value="GUILD_HELMET"><label for="GUILD_HELMET">${d.S}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_GLOVES" value="GUILD_GLOVES"><label for="GUILD_GLOVES">${d.R}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHOES" value="GUILD_SHOES"><label for="GUILD_SHOES">${d.P}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RINGS" value="GUILD_RINGS"><label for="GUILD_RINGS">${d.oa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_AMULETS" value="GUILD_AMULETS"><label for="GUILD_AMULETS">${d.la}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FOOD" value="GUILD_FOOD"><label for="GUILD_FOOD">${d.Ka}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_USABLES" value="GUILD_USABLES"><label for="GUILD_USABLES">${d.qd}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_UPGRADES" value="GUILD_UPGRADES"><label for="GUILD_UPGRADES">${d.Pa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RECIPES" value="GUILD_RECIPES"><label for="GUILD_RECIPES">${d.Ma}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_MERCENARY" value="GUILD_MERCENARY"><label for="GUILD_MERCENARY">${d.La}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SCROLLS" value="GUILD_SCROLLS"><label for="GUILD_SCROLLS">${d.Na}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_REINFORCEMENTS" value="GUILD_REINFORCEMENTS"><label for="GUILD_REINFORCEMENTS">${d.sd}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_TOOLS" value="GUILD_TOOLS"><label for="GUILD_TOOLS">${d.Oa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FORGE_RESOURCES" value="GUILD_FORGE_RESOURCES"><label for="GUILD_FORGE_RESOURCES">${d.rd}</label></div>
                            </div>
                        </div>

                    <div class="settings_tab_title">${d.dj}</div>

                            
                            <div class="setting-row">
                                <label for="guildBattleEnable">${d.v}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleEnable">
                                    <span class="switch"></span>
                                </label>          
                            </div>

                            <div class="setting-row">
                             <label for="guildBattleRandom">${d.cj}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleRandom">
                                    <span class="switch"></span>
                                </label>
                            </div>

                            <div class="setting-row">
                                ${d.ej}
                                <div class="input-container">
                                <input type="text" id="keywordGuildInput" placeholder="${d.X}">
                                <button class="awesome-button" id="addGuildKeywordBtn">${d.K}</button>
                                </div>
                                <div id="keywordGuildList"></div>
                            </div>

                    <div class="settings_tab_title">${d.nb}</div>

                        <div class="setting-row">
                            <label for="GuildEnable">${d.v}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="GuildEnable">
                                <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        
                            <label for="GuildDonateAmount">${d.jf}</label>
                            <div class="switch-field3">
                                <input type="number" id="GuildDonateAmount" min="0" value="${localStorage.getItem("GuildDonateAmount")||0}">      
                            </div> 

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateMore">${d.le}</label>
                                <div class="switch-field3">
                                    <input type="number" id="GuildDonateMore" min="0" value="${localStorage.getItem("GuildDonateMore")||0}">                         
                                </div>

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateLess">${d.wf}</label>
                            <div class="switch-field3">
                            <input type="number" id="GuildDonateLess" min="0" value="${localStorage.getItem("GuildDonateLess")||0}">       
                            </div>                  
                        </div>

                        <span class="span-new">${d.ke}</span>
                        
                    </div>

                <div class="popup-box" id="other_settings2">

                    <div class="settings_tab_title">${d.jh}</div>


                    <div class="setting-row">
                    <span class="span-new">${d.kh}</span>
                    <div class="instructionsReset">
                    
                    <span class="span-new">${d.Qb}</span>
                    </div>
                 
                    </div>
                    
                    <div class="setting-row">
                      <label for="resetExpiredItems">${d.v}</label>
                      <label class="toggle-switch">
                          <input type="checkbox" id="resetExpiredItems">
                          <span class="switch"></span>
                      </label>
                    </div>
                    <div class="setting-row">
                    <label for="resetColors">Select Colors</label>
                            <div class="rule-color-resetColors">
                                <span class="color-circle3 white" data-color="-1"></span>
                                <span class="color-circle3 green" data-color="0"></span>
                                <span class="color-circle3 blue" data-color="1"></span>
                                <span class="color-circle3 purple" data-color="2"></span>
                                <span class="color-circle3 orange" data-color="3"></span>
                                <span class="color-circle3 red" data-color="4"></span>
                            </div>
                    </div>


                    <div class="setting-row">
 
                        <label for="resetDays">${d.lh}</label>
                        <select id="resetDays" style="margin-left: 5px;">
                            <option value="1">1 day</option>
                            <option value="2">2 days</option>
                            <option value="3">3 days</option>
                            <option value="4">4 days</option>
                        </select>
                    </div>
                    
                    <div class="setting-row">
                        <label for="itemsToReset">${d.Xk}</label>
                        <button id="selectAllItems" title="Select All">
                            <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                                <polyline points="20 6 9 17 4 12"></polyline> 
                            </svg>
                        </button>
                        <div id="itemsToReset" class="items-reset-list">
                        
                            <div class="item-reset"><input type="checkbox" id="WEAPONS" value="WEAPONS"><label for="WEAPONS">${d.pa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHIELD" value="SHIELD"><label for="SHIELD">${d.U}</label></div>
                            <div class="item-reset"><input type="checkbox" id="CHEST" value="CHEST"><label for="CHEST">${d.O}</label></div>
                            <div class="item-reset"><input type="checkbox" id="HELMET" value="HELMET"><label for="HELMET">${d.S}</label></div>
                            <div class="item-reset"><input type="checkbox" id="GLOVES" value="GLOVES"><label for="GLOVES">${d.R}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHOES" value="SHOES"><label for="SHOES">${d.P}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RINGS" value="RINGS"><label for="RINGS">${d.oa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="AMULETS" value="AMULETS"><label for="AMULETS">${d.la}</label></div>
                            <div class="item-reset"><input type="checkbox" id="FOOD" value="FOOD"><label for="FOOD">${d.Ka}</label></div>
                            <div class="item-reset"><input type="checkbox" id="USABLES" value="USABLES"><label for="USABLES">${d.qd}</label></div>
                            <div class="item-reset"><input type="checkbox" id="UPGRADES" value="UPGRADES"><label for="UPGRADES">${d.Pa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RECIPES" value="RECIPES"><label for="RECIPES">${d.Ma}</label></div>
                            <div class="item-reset"><input type="checkbox" id="MERCENARY" value="MERCENARY"><label for="MERCENARY">${d.La}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SCROLLS" value="SCROLLS"><label for="SCROLLS">${d.Na}</label></div>
                            <div class="item-reset"><input type="checkbox" id="REINFORCEMENTS" value="REINFORCEMENTS"><label for="REINFORCEMENTS">${d.sd}</label></div>
                            <div class="item-reset"><input type="checkbox" id="TOOLS" value="TOOLS"><label for="TOOLS">${d.Oa}</label></div>
                            
                        </div>

                        <div class="setting-row">
                            <label for="resetUnderworld">${d.Yk}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="resetUnderworld">
                                <span class="switch"></span>
                            </label>
                        </div>
                    </div>
                    
                    <hr style="border: none; border-top: 1px solid black; margin: 10px 0px;">

                    <div class="setting-row">
                        <label for="pauseDuration">${d.Qg} </label>
                        <select id="pauseDuration">
                        <option value="0">No pause</option>
                        <option value="1">Stable Boy</option>
                        <option value="2">Farmer</option>
                        <option value="3">Butcher</option>
                        <option value="4">Fisherman</option>
                        <option value="5">Baker</option>
                        </select>
                    </div>
                     
              </div>

                <div class="popup-box" id="Timers">
                <div class="settings_tab_title">${d.$b}</div>
                <span class="span-new">${d.Timers}</span>

                <div class="setting-row">
                    <div class="timer-list" style="display: grid; grid-template-columns: repeat(2, 5fr); gap: 10px;">

                    <div class="timer-item">
                        <label for="smelting-timer" style="font-weight: bold;">${d.hi}</label>
                        <p class="description">${d.fi}</p>
                        <input type="number" id="smelting-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Smelting||10}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-nogold" style="font-weight: bold;">${d.gi}</label>
                        <p class="description">${d.ci}</p>
                        <input type="number" id="smelting-timer-nogold" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-noitem" style="font-weight: bold;">${d.di}</label>
                        <p class="description">${d.ei}</p>
                        <input type="number" id="smelting-timer-noitem" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoItem||15}">
                    </div>

                    <div class="timer-item">
                        <label for="repair-timer" style="font-weight: bold;">${d.Fa}</label>
                        <p class="description">${d.Yh}</p>
                        <input type="number" id="repair-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Repair||10}">
                    </div>

                    <div class="timer-item">
                        <label for="guild-market-timer" style="font-weight: bold;">${d.Wh}</label>
                        <p class="description">${d.Xh}</p>
                        <input type="number" id="guild-market-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildMarket||2}">
                    </div>

                    <div class="timer-item">
                        <label for="auction-hold-timer" style="font-weight: bold;">${d.Sh}</label>
                        <p class="description">${d.Th}</p>
                        <input type="number" id="auction-hold-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionHoldGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="arena-timer" style="font-weight: bold;">Arena:</label>
                        <p class="description">${d.Ph}</p>
                        <input type="number" id="arena-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Arena||10}">
                    </div>

                    <div class="timer-item">
                        <label for="circus-turma-timer" style="font-weight: bold;">Circus Turma:</label>
                        <p class="description">${d.Uh}</p>
                        <input type="number" id="circus-turma-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).CircusTurma||10}">
                    </div>

                    <div class="timer-item">
                        <label for="training-timer" style="font-weight: bold;">${d.ki}</label>
                        <p class="description">${d.li}</p>
                        <input type="number" id="training-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Training||2}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-expired-timer" style="font-weight: bold;">${d.Zh}</label>
                        <p class="description">${d.$h}</p>
                        <input type="number" id="reset-expired-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).ResetExpired||10}">
                    </div>

                    <div class="timer-item">
                        <label for="store-forge-timer" style="font-weight: bold;">${d.ii}</label>
                        <p class="description">${d.ji}</p>
                        <input type="number" id="store-forge-timer" class="timer-input" style="width: 60px;" min="5" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).StoreForge||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-auction-timer" style="font-weight: bold;">${d.Qh}</label>
                        <p class="description">${d.Rh}</p>
                        <input type="number" id="reset-auction-timer" class="timer-input" style="width: 60px;" min="1" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionCheck||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-search-timer" style="font-weight: bold;">${d.ai}</label>
                        <p class="description">${d.bi}</p>
                        <input type="number" id="reset-search-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SearchTimer||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guilddonate-timer" style="font-weight: bold;">${d.nb}</label>
                        <p class="description">${d.Vh}</p>
                        <input type="number" id="reset-guilddonate-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildDonate||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guildattack-timer" style="font-weight: bold;">Guild Attack</label>
                        <p class="description">Sets timer for guild attack</p>
                        <input type="number" id="reset-guildattack-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).guildBattleEnable||120}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-buff-timer" style="font-weight: bold;">Buffs</label>
                        <p class="description">Buff timer</p>
                        <input type="number" id="reset-buff-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Buffs||60}">
                    </div>

                    </div>
                </div>
                </div>


                  <div class="popup-box" id="other_settings">

                <div class="settings_tab_title">${d.Hd}</div>

                <div class="setting-row">
                ${d.Id}
                    <select id="delaySelect">
                    <option value="0">0 seconds</option>
                    <option value="1">1 second</option>
                    <option value="5">1 to 5 seconds</option>
                    <option value="10">5 to 10 seconds</option>
                    <option value="15">10 to 15 seconds</option>
                    <option value="30">15 to 30 seconds</option>
                    <option value="60">30 to 60 seconds</option>
                    <option value="160">1 to 60 seconds</option>
                    <option value="120">1 to 2 minutes</option>
                    </select>
                </div>
                <div class="setting-row">
                    <label for="timeConditions">Bot Auto Start/Stop Schedule:</label>
                    <div id="timeConditions"></div>
                    <br>
                    <button id="addCondition" class="awesome-button btn">Add Condition</button>
                    <br><br>
                    <button id="pauseButton" class="pause-button">Pause?</button>
                </div>
                  
                <div class="settings_tab_title">${d.nk}</div>

                <div class="setting-row">
                  <label for="storeResource">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="storeResource">
                    <span class="switch"></span>
                    </label>
                </div>

                <div class="settings_tab_title">${d.te}</div>

                <div class="setting-row">
                  <label for="HighlightUnderworldItems">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="HighlightUnderworldItems">
                    <span class="switch"></span>
                    </label>
                </div>
                    
                <div class="settings_tab_title">${d.mi}</div>
                <div class="setting-row">

                      <div class="setting-row">
                        <label for="trainEnable">${d.v}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainEnable">
                          <span class="switch"></span>
                          </label>
                      </div>

                      <div class="setting-row">
                        <label for="trainPickGold">${d.pk}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainPickGold">
                          <span class="switch"></span>
                          </label>
                      </div>

                          ${d.oi}
                      <div class="stat-container">




                        <table id="statTable">
                        <thead>
                            <tr>
                                <th>${d.v}</th>
                                <th>${d.Kh}</th>
                                <th>${d.Rg}</th>
                                <th>${d.Ca}</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                                                                                                        

                        <div class="setting-row">
                            
                            <label for="TrainingHoldGold">${d.aa}</label>

                            <div class="switch-field3">
                            <input type="number" id="TrainingHoldGold" min="0" value="${localStorage.getItem("TrainingHoldGold")||0}">                         
                            </div>  
                  
                        </div>

                                  <span class="span-new">${d.ni}</span>        

                      </div>  
                    </div>
        
                </div>

            <div class="popup-box" id="Extra">
            <div class="settings_tab_title">${d.qb}</div>

              <div class="setting-row">
                
                    <span style="color:red" class="span-new">1 Day Trial Key : </span>
                    <span id="kydt" style="color:red"></span>
                    <br>
                    <span style="color:red" class="span-new">${d.Te} : </span>
                    <span id="kydtexp" style="color:red"></span>
                    
                    <ul>
                    <p>
                    <b>1.1.7 Update</b>
                    <div class="scrollable-list">
                        <ul>
                        <li>Please contact us via <strong>Email: "gldbotsuport@gmail.com"</strong> for problems with links or patch notes</li>
                        </ul>
                    </div>

                </div>

                <div class="settings_tab_title">Stats</div>
                    <div class="setting-row">
                        <div id="stats">
                            <p>${d.lk} <span id="items-repaired">0</span></p>
                            <p>${d.Ed} <span id="items-reset">0</span></p>
                            <p>${d.kk} <span id="gold-cycled">0</span></p>
                            <p>${d.ek} <span id="arena-attacks">0</span></p>
                            <p>${d.gk} <span id="circus-attacks">0</span></p>
                            <p>${d.ik} <span id="dungeons-attacked">0</span></p>
                            <p>${d.jk} <span id="expeditions-attacked">0</span></p>
                            <p>${d.Ed} <span id="items-smelted">0</span></p>
                            <p>${d.mk} <span id="underworld-attacks">0</span></p>
                            <p>${d.fk} <span id="arena-money">0</span></p>
                            <p>${d.hk} <span id="circus-money">0</span></p>
                        </div>
                        <button class="awesome-button" id="reset-stats-button">${d.Pi}</button>
                    </div>
           

            <div class="settings_tab_title">${d.mf}</div>
            
            <div class="setting-row">
              <button class="awesome-button" id="exportBtn">${d.Ue}</button>
              <input type="file" id="importBtn" style="display: none;">
              <button class="awesome-button" id="importFileBtn">${d.nf}</button>
              <p id="importStatus"></p>
              <p>
            </div>

            <div class="settings_tab_title">${d.Wd}</div>

            <div class="setting-row">
            <span class="span-new">${d.Xd}</span>
              <br></br>
              <label for="autologinenable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="autologinenable">
                <span class="switch"></span>
              </label>
            </div>

            <div class="settings_tab_title">${d.Og}</div>
                <div class="setting-row">
                <label for="pauseBotEnable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="pauseBotEnable">
                <span class="switch"></span>
                </label>
            </div>
            
            <div class="setting-row">
                <label for="pauseBot">${d.Pg}</label>
                <div class="switch-field3"> 
                <input type="number" id="pauseBot" placeholder="Minutes" value="${Math.round((localStorage.getItem("pauseBot.timeOut")-Date.now())/6E4)||0}">
                </div>
                </label>
            </div>

            <div class="settings_tab_title">UI Settings</div>

                <div class="setting-row">
                    <label for="disableBG">${d.Pj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableBG">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="disableLogMenu">${d.je}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableLogMenu">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="MoveButtons">${d.Qj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="MoveButtons">
                        <span class="switch"></span>
                    </label>
                </div>
                
            
    
            <div class="settings_tab_title">${d.tg}</div>
                <div class="setting-row">
                    <span class="span-new">${d.ug}</span>
                    <textarea id="messageInput" rows="4" cols="50" placeholder="${d.vg}" style="width: 350px; height: 50px;"></textarea>
                    <button class="awesome-button" id="messageButton">${d.xg}</button>
                    <button class="awesome-button"id="showPlayersButton">${d.yg}</button>
                    <button class="awesome-button" id="selectAllButton">${d.wg}</button>
                    <button class="awesome-button" id="unselectAllButton">${d.zg}</button>
                    <div id="messageStatus"></div>
                    <div id="playerList" style="display: none;"></div>
                    <div id="loadingContainer"></div>
                    <br>
                    ${d.ie}
                </div>        
            </div>

                  <div class="popup-box" id="Market">
                  <div class="settings_tab_title">Market Buy</div>
        
                    <span class="span-new">${d.dg}</span>

                    <div class="setting-row">
                      <label for="enableMarketSearch">${d.ue}
                        <label class="toggle-switch">
                        <input type="checkbox" id="enableMarketSearch">
                        <span class="switch"></span>
                      </label>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label>${d.eg}</label>
                    <span style="font-weight: normal">${d.fg}</span>
                    <input type="text" id="MarketSearchInterval" placeholder="Market Search Interval - Minutes" value="${localStorage.getItem("MarketSearchInterval")||""}">

                    </div>



                    <div class="setting-row">
                    <div class="setting-row">
                        <label for="marketOnlyFood">${d.Jg}
                        <label class="toggle-switch">
                        <input type="checkbox" id="marketOnlyFood">
                        <span class="switch"></span>
                        </label>
                        </label>
                    </div>
                      <span class="span-new">${d.Kg}</span>
                      
                      <label for="MaxTotalGold">${d.Jb} : </label><input type="number" id="MarketMaxFoodPrice" placeholder="${d.Jb}" value="${localStorage.getItem("MarketMaxFoodPrice")||""}">
                    
                      <label for="MaxPerFood">${d.Ib} : </label><input type="number" id="MarketMaxPerFoodPrice" placeholder="${d.Ib}" value="${localStorage.getItem("MarketMaxPerFoodPrice")||""}">

                      <label for="MinItemLevel">${d.ba} : </label><input type="number" id="MarketMinItemLevel" placeholder="${d.ba}" value="${localStorage.getItem("MarketMinItemLevel")||""}">
                    

                    </div>

                    <div class="setting-row">
                    <label>${d.rf}</label>
                      <input type="text" id="itemToBuy" placeholder="${d.pf}">
                    </div>

                    <div class="setting-row">
                      <input type="number" id="maxPrice" placeholder="${d.G}">
                    </div>

                    <div class="setting-row">
                    
                      <label>${d.sf}</label>
                      <select id="marketItemType">
                        <option value="WEAPON">${d.pa}</option>
                        <option value="SHIELD">${d.U}</option>
                        <option value="CHEST">${d.O}</option>
                        <option value="HELMET">${d.S}</option>
                        <option value="GLOVES">${d.R}</option>
                        <option value="SHOES">${d.P}</option>
                        <option value="RINGS">${d.oa}</option>
                        <option value="AMULETS">${d.la}</option>
                        <option value="USABLES">${d.Ka}</option></option>
                        <option value="BOOSTS">${d.yj}</option></option>
                        <option value="UPGRADES">${d.Pa}</option></option>
                        <option value="RECIPES">${d.Ma}</option></option>
                        <option value="MERCENARY">${d.La}</option></option>
                        <option value="FORGINGGOODS">${d.rd}</option></option>
                        <option value="btools">${d.Oa}</option></option>
                        <option value="SCROLLS">${d.Na}</option></option>
                      </select>

                      <label>${d.qf}</label>
                      <select id="rarity">
                        <option value="White">${d.qa}</option>
                        <option value="Green">${d.C}</option>
                        <option value="Blue">${d.B}</option>
                        <option value="Purple">${d.D}</option>
                        <option value="Orange">${d.J}</option>
                        <option value="Red">${d.T}</option>
                      </select>

                      <label>${d.de}</label>
                      <select id="itemsoulbound">
                        <option value="BuySoulbound">${d.Ki}</option>
                        <option value="DontBuySoulbound">${d.Hg}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <button class="awesome-button" id="addItemBtn">${d.K}</button>
                    </div>

                    <div class="setting-row">
                      <label for="itemList">${d.uf}</label>
                      <select id="itemList" size="10"></select>
                      <button class="awesome-button" id="removeItemBtn">${d.gh}</button>
                    </div>

                    <div class="setting-row">
                      <label for="usePacks">${d.tf}
                      <label class="toggle-switch">
                        <input type="checkbox" id="usePacks">
                        <span class="switch"></span>
                        </label>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="MarketboughtItems">${d.be}</label>
                      <select id="MarketboughtItems" size="5"></select>
                      <button class="awesome-button" id="MarketremoveItemBtn">${d.ge}</button>
                    </div>

                    <div class="setting-row">
                    <label for="MarketHoldGold">${d.aa}</label>
                    <input type="number" id="MarketHoldGold" min="0" value="${localStorage.getItem("MarketHoldGold")||0}">
                    </div>
                  
                    </div>   
                  </div>
                </div>
              </div>
            </div>

              `;document.getElementById("header_game").insertBefore(v,document.getElementById("header_game").children[0]);v=document.createElement("div");x=document.getElementById("wrapper_game").clientHeight;v.setAttribute("id","overlayBack");v.setAttribute("style",`height: ${x}px; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 198;`);v.addEventListener("click",ic);document.getElementsByTagName("body")[0].appendChild(v);(function(){var t=localStorage.getItem("lastActiveTab");t?(t=
document.querySelector(`.popup-tab[data-target="${t}"]`))&&Rc(t):(t=document.querySelector(".popup-tab"))&&Rc(t)})();v=localStorage.getItem("we");null!==v&&(v=(new Date(v)).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),document.getElementById("kydtexp").textContent=v,v=localStorage.getItem("showTrial"),null!==v&&(document.getElementById("kydt").textContent=v));mi();(function(){document.querySelectorAll(".setting-row").forEach(function(t){t.addEventListener("mouseenter",
function(){var u=this.getAttribute("data-tooltip");if(u&&""!==u.trim()){const z=document.createElement("div");z.className="custom-tooltip";z.innerHTML=u;document.body.appendChild(z);u=this.getBoundingClientRect();z.style.left=u.left+u.width/2-z.offsetWidth/2+"px";z.style.top=u.top-z.offsetHeight+"px";this.Bm=z}});t.addEventListener("mouseleave",function(){this.Bm&&(document.body.removeChild(this.Bm),this.Bm=null)})})})();document.querySelectorAll(".popup-tab").forEach(t=>{t.addEventListener("click",
()=>{Rc(t);localStorage.setItem("lastActiveTab",t.dataset.target)})});const C=document.querySelectorAll(".popup-tab"),E=document.querySelectorAll(".popup-box"),A=document.querySelector(`#${document.querySelector(".popup-tab.active").dataset.target}`);A.classList.add("active");E.forEach(t=>{t!==A&&(t.style.display="none")});C.forEach(t=>{t.addEventListener("click",()=>{C.forEach(u=>u.classList.remove("active"));t.classList.add("active");E.forEach(u=>{u.style.display="none"});document.querySelector(`#${t.dataset.target}`).style.display=
"block"})});"GB PL ES TR FR HG BR".split(" ").forEach(t=>{$(`#language${t}`).click(()=>{localStorage.setItem("settings.language",t);switch(t){case "EN":d={...Ih};break;case "PL":d={...Jh};break;case "ES":d={...Kh};break;case "TR":d={...Lh};break;case "FR":d={...Mh};break;case "HG":d={...Nh};break;case "BR":d={...Oh};break;default:d={...Ih}}ic();jc()})});b("#do_expedition",c,!0,!1);b("#do_dungeon",e,!0,!1);b("#do_arena",g,!0,!1);b("#do_circus",k,!0,!1);b("#do_quests",h,!0,!1);b("#do_event_expedition",
l,!0,!1);[0,1,2,3].forEach(t=>{$(`#set_monster_id_${t}`).click(()=>{var u=`${t}`;Sc=u;localStorage.setItem("monsterId",u)})});["normal","advanced"].forEach(t=>{$(`#set_dungeon_difficulty_${t}`).click(()=>{Ib=t;localStorage.setItem("dungeonDifficulty",t);m(t)})});(v=localStorage.getItem("dungeonDifficulty"))&&m(v);"combat arena circus expedition dungeon items".split(" ").forEach(t=>{$(`#do_${t}_quests`).click(()=>{Na[t]=!Na[t];localStorage.setItem("questTypes",JSON.stringify(Na));ic();jc()})});b("#do_auto_auction",
q,!0,!1);b("#do_kasa",n,!0,!1);$(document).ready(function(){function t(y){var H=y.split(". "),P="<ol>";H.forEach(function(Q,S){""!==Q.trim()&&(S!==H.length-1||Q.endsWith(".")||(Q+="."),P+="<li>"+Q+"</li>")});return P+="</ol>"}function u(y){const H={"guild-market-timer":"GuildMarket","smelting-timer":"Smelting","smelting-timer-nogold":"SmeltingNoGold","smelting-timer-noitem":"SmeltingNoItem","repair-timer":"Repair","auction-hold-timer":"AuctionHoldGold","arena-timer":"Arena","circus-turma-timer":"CircusTurma",
"training-timer":"Training","reset-expired-timer":"ResetExpired","store-forge-timer":"StoreForge","reset-auction-timer":"AuctionCheck","reset-search-timer":"SearchTimer","reset-guilddonate-timer":"GuildDonate","reset-guildattack-timer":"guildBattleEnable","reset-buff-timer":"BuffTimer"};return H[y]?H[y]:y.replace(/-([a-z])/g,function(P){return P[1].toUpperCase()}).replace("-timer","")}function z(){Za.forEach(y=>{const H=document.getElementById(`${y}Priority`);(y=Xa[y])?(H.textContent=`${d.Ca}: ${y}`,
H.dataset.priority=y):(H.textContent=`${d.Vb}`,H.dataset.priority="None")})}function B(){qb=Za.map(y=>{const H=document.getElementById(`${y}Count`),P=document.getElementById(`${y}Enable`);return{stat:y,count:H?parseInt(H.value):0,priority:null!==Xa[y]?Xa[y]:"None",ln:P?P.checked:!1}});localStorage.setItem("statSettings",JSON.stringify(qb))}function J(){Za.forEach(y=>{document.getElementById(`${y}Priority`).addEventListener("click",()=>{let H=Xa[y],P=H?H+1:1;P>Za.length&&(P=1);let Q=null;for(let S of Za)if(S!==
y&&Xa[S]===P){Q=S;break}Q&&(Xa[Q]=H||null);Xa[y]=P;z();B()})});document.querySelectorAll(".stat-count").forEach(y=>{y.addEventListener("change",B)});Za.forEach(y=>{document.getElementById(`${y}Enable`).addEventListener("change",B)})}function I(y,H){JSON.parse(localStorage.getItem(H)||"[]").forEach(P=>K(P,y,H))}function K(y,H,P){const Q=document.createElement("div");Q.className="keyword-item";var S=document.createElement("span");S.textContent=y;Q.appendChild(S);S=document.createElement("span");S.className=
"remove-keyword";S.textContent="X";S.addEventListener("click",function(){Q.remove();let la=JSON.parse(localStorage.getItem(P)||"[]");const X=la.indexOf(y);-1<X&&(la.splice(X,1),localStorage.setItem(P,JSON.stringify(la)))});Q.appendChild(S);H.appendChild(Q)}function L(y,H){const P=JSON.parse(localStorage.getItem(H)||"[]");P.push(y);localStorage.setItem(H,JSON.stringify(P))}function O(y,H,P){const Q=document.createElement("li");Q.textContent=y;Q.style.padding="10px";Q.style.border="1px solid #ccc";
Q.style.borderColor="#cea429";Q.style.borderRadius="5px";Q.style.marginBottom="5px";Q.style.display="flex";Q.style.justifyContent="space-between";const S=document.createElement("button");S.textContent="X";S.style.textAlign="center";S.addEventListener("click",()=>{Q.remove();const la=(JSON.parse(localStorage.getItem(P))||[]).filter(X=>!(X[0]===y[0]&&X[1]===y[1]));localStorage.setItem(P,JSON.stringify(la))});Q.appendChild(S);document.getElementById(H).appendChild(Q)}function Z(){ib=ib.map(y=>{y.Nm=
!1;y.Im=null;return y})}function fa(){document.getElementById("startSearchButton").innerText="Start Search";mc=!1}function da(){const y=document.getElementById("clothCount");var H=parseInt(y.value,10);isNaN(H)&&(H=0);--H;0>=H&&(H=0);return y.value=H}function ma(){const y=document.getElementById("itemsList");y.innerHTML="";ib.forEach((H,P)=>{const Q=document.createElement("div");Q.style.display="flex";Q.style.flexDirection="column";Q.style.border="1px solid #d2b97f";Q.style.padding="10px";Q.style.marginBottom=
"10px";Q.style.borderRadius="5px";Q.style.backgroundColor="#faf2dd";var S=document.createElement("div");S.style.display="flex";S.style.justifyContent="space-between";S.style.alignItems="center";const la=document.createElement("span");la.innerHTML=`<strong>${H.name}</strong> (${H.qualityName}) - Level: [${H.An}]`;la.style.color="#5d432c";const X=document.createElement("button");X.innerText="Remove";X.style.backgroundColor="#af552e";X.style.color="white";X.style.border="none";X.style.padding="5px 10px";
X.style.cursor="pointer";X.style.borderRadius="3px";X.onclick=()=>{ib.splice(P,1);ma();pa()};S.appendChild(la);S.appendChild(X);Q.appendChild(S);H.lm&&H.ym&&(S=document.createElement("div"),S.style.marginTop="5px",S.style.fontStyle="italic",S.style.color="#7d5b3e",S.innerText=`Stat: ${H.lm.toUpperCase()} - Value: ${H.ym}`,Q.appendChild(S));y.appendChild(Q)})}function pa(){localStorage.setItem("itemsToSearch",JSON.stringify(ib))}function ca(y,H){const P=document.getElementById("foundItemsContainer");
P.style.display="flex";P.style.flexWrap="wrap";P.style.justifyContent="center";P.style.alignItems="center";P.style.Yp="10px";const Q=document.createElement("div");Q.className="notification-item";Q.style.border="1px solid #d2b97f";Q.style.borderRadius="4px";Q.style.padding="10px";Q.style.margin="5px";Q.style.textAlign="center";Q.style.backgroundColor="#faf2dd";Q.style.boxShadow="0 2px 4px rgba(0, 0, 0, 0.1)";Q.style.boxSizing="border-box";Q.style.flex="0 1 calc(20% - 10px)";Q.style.display="flex";
Q.style.flexDirection="column";Q.style.alignItems="center";Q.style.transition="all 0.3s ease-in-out";const S=document.createElement("span"),la=document.createElement("span");switch(Number(y.Im.getAttribute("data-quality"))){case 0:la.style.color="green";break;case 1:la.style.color="blue";break;case 2:la.style.color="purple";break;case 3:la.style.color="orange";break;case 4:la.style.color="red";break;default:la.style.color="#333"}la.innerText=y.name;la.style.fontWeight="bold";la.style.fontSize="12px";
la.style.marginBottom="5px";S.appendChild(la);const X=document.createElement("div");X.style.marginTop="5px";X.style.padding="10px";X.style.borderRadius="5px";X.style.display="flex";X.style.justifyContent="center";X.style.alignItems="center";X.style.transition="transform 0.3s ease-in-out";X.onmouseover=()=>{X.style.transform="scale(1.1)"};X.onmouseout=()=>{X.style.transform="scale(1)"};y=y.Im.cloneNode(!0);y.style.position="static";y.style.transform="none";y.style.margin="0";X.appendChild(y);y=document.createElement("a");
y.href=H;y.style.textDecoration="none";y.style.cursor="pointer";y.onmouseover=()=>{la.style.textDecoration="underline"};y.onmouseout=()=>{la.style.textDecoration="none"};y.appendChild(S);y.appendChild(X);Q.appendChild(y);P.appendChild(Q);nc.style.display="block"}async function qa(){var y=!1;if(!mc)return!1;const H=await If();var P=ib.filter(X=>!X.Nm);for(let X of P)for(const Tc of H){P=Tc.querySelectorAll("#shop .ui-draggable");for(const Ua of P){var Q=JSON.parse(Ua.getAttribute("data-tooltip").replace(/&quot;/g,
'"')),S=parseInt(Ea(Ua).split("-")[0],10);P=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[5].match(/\d+/)[0],10):0;let oi=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,pi=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,qi=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[11].match(/\d+/)[0],10):0,ri=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[13].match(/\d+/)[0],10):0;S=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],
10):0;var la=Ua.getAttribute("data-quality");Q=Q[0][0][0];const si=Ua.getAttribute("data-level");if(Number(si)>=Number(X.An)&&Q.toLowerCase().includes(X.name.toLowerCase())&&(la>=X.quality||!la&&"0"==X.quality)){if(X.lm&&X.ym&&"none"!==X.lm&&(la=!1,(P={str:P,dex:oi,agi:pi,cot:qi,chr:ri,"int":S}[X.lm])&&P>=X.ym&&(la=!0),!la))continue;X.Im=Ua.cloneNode(!0);ca(X,Tc.Vm||Tc.querySelector("a.shopLink").href);y=X.Nm=!0}}}P=ib.filter(X=>!X.Nm);if(0===P.length||y)return fa(),!0;y=da();Oa();if(0>=y)return fa(),
!1;await ya();return qa()}async function ya(){var y=new URL(window.location.href);const H=y.origin;y=y.searchParams.get("sh")||"";await fetch(`${H}/game/index.php?mod=inventory&sub=2&subsub=0&sh=${y}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({bestechen:"New goods"})})}function Oa(){var y=parseInt(document.getElementById("clothCount").getAttribute("data-total"),10);const H=parseInt(document.getElementById("clothCount").value,10);y=(y-H)/y*
100;document.getElementById("progressBarInner").style.width=`${isNaN(y)?100:y}%`}function xb(){const y=[...Uc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelectionSmelt",JSON.stringify(y))}function Jb(){const y=[...Vc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelection",JSON.stringify(y))}function yb(){localStorage.setItem("timeConditions",JSON.stringify(Kb))}function Jf(y={}){const H=document.createElement("div");H.classList.add("condition-row");
H.innerHTML=`
                    <input type="time" class="awesome-button start-time" value="${y.start||""}" required> to
                    <input type="time" class="awesome-button end-time" value="${y.end||""}" required>
                    <br>
                    <select class="bot-action">
                        <option value="start" ${"start"===y.action?"selected":""}>Start Bot</option>
                        <option value="stop" ${"stop"===y.action?"selected":""}>Stop Bot</option>
                    </select>
                    <button class="awesome-button remove-condition">Remove</button>
                `;yb();H.querySelector(".remove-condition").addEventListener("click",()=>{Kf.removeChild(H);Kb=Kb.filter(P=>P!==y);yb()});H.querySelector(".start-time").addEventListener("change",P=>{y.start=P.target.value;yb()});H.querySelector(".end-time").addEventListener("change",P=>{y.end=P.target.value;yb()});H.querySelector(".bot-action").addEventListener("change",P=>{y.action=P.target.value;yb()});Kf.appendChild(H)}function Lf(){document.getElementById("mercenarySearchOptions").style.display=
oc.checked?"block":"none"}function ti(y){document.querySelectorAll('#itemsToReset input[type="checkbox"]').forEach(H=>{H.checked=y});Ja()}function Wc(){localStorage.setItem("marketItems",JSON.stringify(jb));Xc.innerHTML="";Mf.innerHTML="";for(var y of Lb){var H=document.createElement("option");H.textContent=y;Mf.appendChild(H)}for(y=0;y<jb.length;y++)H=document.createElement("option"),H.value=y,H.text=jb[y].itemToBuy+" (Rarity: "+jb[y].rarity+", Max price: "+jb[y].maxPrice+" "+jb[y].Soulbound+")",
Xc.appendChild(H)}function Nf(y,H,P){H[y.id]&&y.classList.add("active");y.addEventListener("click",function(Q){Q.preventDefault();this.classList.contains("active")?(this.classList.remove("active"),H[this.id]=!1):(this.classList.add("active"),H[this.id]=!0);localStorage.setItem(P,JSON.stringify(H))})}function Of(y,H,P,Q){P.forEach(S=>{S in H||(H[S]=!1)});localStorage.setItem(Q,JSON.stringify(H))}function Pf(){const y=pc.checked;ui.style.display=y?"block":"none";vi.style.display=y?"block":"none"}const wi=
document.getElementById("doExpedition"),xi=document.getElementById("doDungeon"),yi=document.getElementById("doArena"),zi=document.getElementById("doCircus"),Ai=document.getElementById("doQuests"),Bi=document.getElementById("doEventExpedition"),Ci=document.getElementById("activateAutoBid"),Di=document.getElementById("doKasa"),qc=document.querySelector("#healPercentage"),Yc=document.querySelector("#HealClothToggle"),Qf=document.querySelector("#hellEnterHP"),Rf=document.querySelector("#HellHealHP"),
Zc=document.querySelector("#HealRubyToggle"),$c=document.querySelector("#storeResource"),ad=document.querySelector("#HighlightUnderworldItems");qc.value=localStorage.getItem("healPercentage")||25;Yc.checked="true"===localStorage.getItem("HealClothToggle")||!1;Zc.checked="true"===localStorage.getItem("HealRubyToggle")||!1;$c.checked="true"===localStorage.getItem("storeResource")||!1;ad.checked="true"===localStorage.getItem("HighlightUnderworldItems")||!1;const Sf=document.getElementById("minimumGoldAmount");
Sf.addEventListener("change",()=>{localStorage.setItem("minimumGoldAmount",Sf.value)});const Tf="true"===localStorage.getItem("useGodPowers");document.getElementById("useGodPowers").checked=Tf;document.getElementById("godPowersSection").style.display=Tf?"block":"none";const Ei=JSON.parse(localStorage.getItem("GodPowersHell"))||[];document.querySelectorAll(".god-power-checkbox").forEach(y=>{y.checked=Ei.includes(y.value)});const Fi="true"===localStorage.getItem("useWeaponBuff");document.getElementById("weaponBuff").checked=
Fi;const Gi=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||[];document.querySelectorAll(".armor-checkbox").forEach(y=>{y.checked=Gi.includes(y.value)});document.getElementById("useGodPowers").addEventListener("change",function(){const y=this.checked;localStorage.setItem("useGodPowers",y);document.getElementById("godPowersSection").style.display=y?"block":"none"});document.querySelectorAll(".god-power-checkbox").forEach(y=>{y.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".god-power-checkbox:checked")).map(P=>
P.value);localStorage.setItem("GodPowersHell",JSON.stringify(H))})});document.getElementById("weaponBuff").addEventListener("change",function(){localStorage.setItem("useWeaponBuff",this.checked)});document.querySelectorAll(".armor-checkbox").forEach(y=>{y.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".armor-checkbox:checked")).map(P=>P.value);localStorage.setItem("ArmorBuffsHell",JSON.stringify(H))})});const Mb=document.getElementById("OilEnable"),Uf=document.getElementById("oilUsageSettings"),
Vf={oilEnable:!1,blueRings:!1,blueNecklace:!1,yellowRings:!1,yellowNecklace:!1,yellowWeapons:!1,yellowArmor:!1,orangeRings:!1,orangeNecklace:!1,greenRings:!1,greenNecklace:!1,greenWeapons:!1,greenArmor:!1,purpleRings:!1,purpleNecklace:!1,purpleWeapons:!1,purpleArmor:!1},Hi=JSON.parse(localStorage.getItem("oilUsagePrefs"))||Vf,zb={...Vf,...Hi},Wf={blueRings:document.getElementById("blue-oil-rings"),blueNecklace:document.getElementById("blue-oil-necklace"),yellowRings:document.getElementById("yellow-oil-rings"),
yellowNecklace:document.getElementById("yellow-oil-necklace"),yellowWeapons:document.getElementById("yellow-oil-weapons"),yellowArmor:document.getElementById("yellow-oil-armor"),orangeRings:document.getElementById("orange-oil-rings"),orangeNecklace:document.getElementById("orange-oil-necklace"),greenRings:document.getElementById("green-oil-rings"),greenNecklace:document.getElementById("green-oil-necklace"),greenWeapons:document.getElementById("green-oil-weapons"),greenArmor:document.getElementById("green-oil-armor"),
purpleRings:document.getElementById("purple-oil-rings"),purpleNecklace:document.getElementById("purple-oil-necklace"),purpleWeapons:document.getElementById("purple-oil-weapons"),purpleArmor:document.getElementById("purple-oil-armor"),redRings:document.getElementById("red-oil-rings"),redNecklace:document.getElementById("red-oil-necklace"),redWeapons:document.getElementById("red-oil-weapons"),redArmor:document.getElementById("red-oil-armor")};Mb.checked=zb.oilEnable;Uf.style.display=Mb.checked?"block":
"none";for(const [y,H]of Object.entries(Wf))H&&(H.checked=!!zb[y]);Mb.addEventListener("change",()=>{zb.oilEnable=Mb.checked;localStorage.setItem("oilUsagePrefs",JSON.stringify(zb));Uf.style.display=Mb.checked?"block":"none"});for(const [y,H]of Object.entries(Wf))H&&H.addEventListener("change",()=>{zb[y]=H.checked;localStorage.setItem("oilUsagePrefs",JSON.stringify(zb))});const Xf=document.getElementById("autoSmeltInfo"),Ab=document.getElementById("popupSmelt");Xf.addEventListener("mouseenter",function(){Ab.style.display=
"block";const y=document.querySelector(".popup-menu").getBoundingClientRect();Ab.style.position="fixed";Ab.style.width="350px";Ab.style.left=`${y.right+10}px`;Ab.style.top=`${y.top}px`});Xf.addEventListener("mouseleave",function(){Ab.style.display="none"});var bd=document.getElementById("tabA"),cd=document.getElementById("tabB"),Yf=document.getElementById("contentA"),Zf=document.getElementById("contentB"),dd=document.getElementById("tabACircus"),ed=document.getElementById("tabBCircus"),$f=document.getElementById("contentACircus"),
ag=document.getElementById("contentBCircus");bd.addEventListener("click",function(){Yf.style.display="block";Zf.style.display="none";bd.classList.add("active");cd.classList.remove("active")});cd.addEventListener("click",function(){Zf.style.display="block";Yf.style.display="none";cd.classList.add("active");bd.classList.remove("active")});dd.addEventListener("click",function(){$f.style.display="block";ag.style.display="none";dd.classList.add("active");ed.classList.remove("active")});ed.addEventListener("click",
function(){ag.style.display="block";$f.style.display="none";ed.classList.add("active");dd.classList.remove("active")});const Ii=t(d.ic),Ji=t(d.Qb);document.querySelector(".instructions .span-new").innerHTML=Ii;document.querySelector(".instructionsReset .span-new").innerHTML=Ji;const fd=document.getElementById("announcement"),gd=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio! | Active the Bot!";gd&&""!==gd?(fd.style.display="block",fd.innerHTML=gd):fd.style.display="none";const Ki=[{id:"Health",buffs:["Gingko","Taigaroot",
"Hawthorn"]},{id:"Strength",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Dexterity",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Agility",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Constitution",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Charisma",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Intelligence",buffs:["Flask","Ampulla","Flacon","Bottle"]}];(function(){const y=JSON.parse(localStorage.getItem("buffSelections"))||{};Ki.forEach(H=>{y[H.id]=y[H.id]||[];H.buffs.forEach((P,
Q)=>{const S=document.getElementById(`${H.id}Buff${Q+1}`);S.checked=y[H.id].includes(P);S.addEventListener("change",()=>{S.checked?y[H.id].push(P):y[H.id]=y[H.id].filter(la=>la!==P);localStorage.setItem("buffSelections",JSON.stringify(y))})})})})();let hd=document.getElementById("BuffsEnable");hd.checked="true"===localStorage.getItem("BuffsEnable");hd.addEventListener("change",()=>{localStorage.setItem("BuffsEnable",hd.checked)});let jd=document.getElementById("BuffUnderworldOnly");jd.checked="true"===
localStorage.getItem("BuffUnderworldOnly");jd.addEventListener("change",()=>{localStorage.setItem("BuffUnderworldOnly",jd.checked)});document.querySelectorAll(".timer-input").forEach(y=>{y.addEventListener("change",function(){var H=parseInt(this.min,10);let P=parseInt(this.value,10);P<H&&(this.value=P=H);H=JSON.parse(localStorage.getItem("Timers"))||{};const Q=u(this.id);H[Q]=P;localStorage.setItem("Timers",JSON.stringify(H))})});const Za="Strength Dexterity Agility Constitution Charisma Intelligence".split(" ");
let Xa={},qb=JSON.parse(localStorage.getItem("statSettings"))||[];Za.forEach(y=>{const H=qb.find(P=>P.stat===y);Xa[y]=H?"None"!==H.priority?parseInt(H.priority):null:null});(function(){const y=document.querySelector("#statTable tbody");y.innerHTML="";Za.forEach(H=>{const P=document.createElement("tr");var Q=document.createElement("td"),S=document.createElement("input");S.type="checkbox";S.id=`${H}Enable`;S.checked=qb.find(X=>X.stat===H)?.ln||!1;Q.appendChild(S);P.appendChild(Q);Q=document.createElement("td");
S=document.createElement("label");S.htmlFor=`${H}$`;S.textContent=d[H];Q.appendChild(S);P.appendChild(Q);Q=document.createElement("td");S=document.createElement("input");S.type="number";S.min="0";S.id=`${H}Count`;S.value=qb.find(X=>X.stat===H)?.count||0;S.classList.add("stat-count");Q.appendChild(S);P.appendChild(Q);Q=document.createElement("td");S=document.createElement("button");S.type="button";S.id=`${H}Priority`;S.classList.add("priority-btn");S.dataset.stat=H;const la=Xa[H];S.textContent=la?
`${d.Ca}: ${la}`:`${d.Vb}`;S.dataset.priority=la||"None";Q.appendChild(S);P.appendChild(Q);y.appendChild(P)});J()})();(function(){qb=JSON.parse(localStorage.getItem("statSettings"))||[];Za.forEach(y=>{const H=qb.find(P=>P.stat===y);Xa[y]=H?"None"!==H.priority?parseInt(H.priority):null:null});z()})();Array.from(document.getElementsByClassName("stat-count")).forEach(y=>{y.addEventListener("change",()=>{B()})});document.getElementById("clear_next_event_expedition_time").addEventListener("click",function(){localStorage.setItem("eventPoints_",
16);alert("Done!")});let $a=localStorage.getItem("workbenchItem");$a=$a?JSON.parse($a):{};$a.selectedItem&&$a.selectedItem.item?document.getElementById("currentWorkbenchItem").textContent=$a.selectedItem.item.name:document.getElementById("currentWorkbenchItem").textContent="No item";document.getElementById("clear_repair").addEventListener("click",function(){$a.selectedItem&&($a.selectedItem={},Object.assign($a.selectedItem,{selectedItem:!1}),localStorage.removeItem("workbenchItem"),localStorage.removeItem("activeItems"),
localStorage.removeItem("activeItemsGladiator"),localStorage.removeItem("activeItemsMercenary"),document.getElementById("currentWorkbenchItem").textContent="No item")});document.getElementById("ClearAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackList",JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearOtherAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackServerList",
JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackList",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});
document.getElementById("ClearOtherCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusServerList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackCircusList",JSON.stringify([]));window.location.reload()});const bg=document.getElementById("keywordAcceptInput"),Li=document.getElementById("addKeywordAcceptBtn"),
cg=document.getElementById("keywordAcceptList"),rc=document.getElementById("underworldKeywordSection"),dg=document.getElementById("underworldKeywordInput"),Mi=document.getElementById("addUnderworldKeywordBtn"),eg=document.getElementById("underworldKeywordList");let kd=document.getElementById("skipTimeQuests");kd.checked="true"===localStorage.getItem("skipTimeQuests");kd.addEventListener("change",()=>{localStorage.setItem("skipTimeQuests",kd.checked)});let ld=document.getElementById("skipTimeCircusQuests");
ld.checked="true"===localStorage.getItem("skipTimeCircusQuests");ld.addEventListener("change",()=>{localStorage.setItem("skipTimeCircusQuests",ld.checked)});let md=document.getElementById("skipTimeOtherQuests");md.checked="true"===localStorage.getItem("skipTimeOtherQuests");md.addEventListener("change",()=>{localStorage.setItem("skipTimeOtherQuests",md.checked)});"Mercury Apollo Diana Minerva Vulcan Mars".split(" ").forEach(y=>{let H=document.getElementById(`questType${y}`);H.checked="true"===localStorage.getItem(`questType${y}`);
H.addEventListener("change",()=>{localStorage.setItem(`questType${y}`,H.checked)})});let Nb=document.getElementById("UnderworldQuests");Nb.checked="true"===localStorage.getItem("UnderworldQuests");Nb.addEventListener("change",()=>{localStorage.setItem("UnderworldQuests",Nb.checked);Nb.checked||"true"===localStorage.getItem("UnderworldQuests")?rc.style.display="block":rc.style.display="none"});Nb.checked||"true"===localStorage.getItem("UnderworldQuests")?rc.style.display="block":rc.style.display="none";
let nd=document.getElementById("acceptnotfilter");nd.checked="true"===localStorage.getItem("acceptnotfilter");nd.addEventListener("change",()=>{localStorage.setItem("acceptnotfilter",nd.checked)});const od=document.getElementById("keywordInput"),Ni=document.getElementById("addKeywordBtn"),fg=document.getElementById("keywordList"),Oi=document.getElementById("keywordGuildInput"),Pi=document.getElementById("addGuildKeywordBtn"),gg=document.getElementById("keywordGuildList");I(gg,"guildKeywords");Pi.addEventListener("click",
function(){const y=Oi.value.trim();""!==y&&(K(y,gg,"guildKeywords"),L(y,"guildKeywords"),od.value="")});I(fg,"questKeywords");I(eg,"underworldQuestKeywords");Ni.addEventListener("click",function(){const y=od.value.trim();""!==y&&(K(y,fg,"questKeywords"),L(y,"questKeywords"),od.value="")});I(cg,"acceptQuestKeywords");Li.addEventListener("click",function(){const y=bg.value.trim();""!==y&&(K(y,cg,"acceptQuestKeywords"),L(y,"acceptQuestKeywords"),bg.value="")});Mi.addEventListener("click",function(){const y=
dg.value.trim();""!==y&&(K(y,eg,"underworldQuestKeywords"),L(y,"underworldQuestKeywords"),dg.value="")});let pd=document.getElementById("renewEvent");pd.checked="true"===localStorage.getItem("renewEvent");pd.addEventListener("change",()=>{localStorage.setItem("renewEvent",pd.checked)});let qd=document.getElementById("throwDice");qd.checked="true"===localStorage.getItem("throwDice");qd.addEventListener("change",()=>{localStorage.setItem("throwDice",qd.checked)});let rd=document.getElementById("useCostume");
rd.checked="true"===localStorage.getItem("useCostume");rd.addEventListener("change",()=>{localStorage.setItem("useCostume",rd.checked)});let Ob=document.getElementById("wearUnderworld"),hg=document.getElementById("costumeUnderworldWrapper");Ob.checked="true"===localStorage.getItem("wearUnderworld");hg.style.display=Ob.checked?"block":"none";Ob.addEventListener("change",()=>{localStorage.setItem("wearUnderworld",Ob.checked);hg.style.display=Ob.checked?"block":"none"});document.getElementById("costumeUnderworld").addEventListener("change",
function(){localStorage.setItem("costumeUnderworld",this.value)});const Qi=document.getElementById("costumeUnderworld"),ig=localStorage.getItem("costumeUnderworld");null!==ig&&(Qi.value=ig);const Ri=document.getElementById("costumeBasic"),jg=localStorage.getItem("costumeBasic");document.getElementById("costumeBasic").addEventListener("change",function(){localStorage.setItem("costumeBasic",this.value)});null!==jg&&(Ri.value=jg);document.getElementById("costumeDungeon").addEventListener("change",function(){localStorage.setItem("costumeDungeon",
this.value)});const Si=document.getElementById("costumeDungeon"),kg=localStorage.getItem("costumeDungeon");null!==kg&&(Si.value=kg);const Ti=document.getElementById("search_input"),Ui=document.getElementById("search_reset"),Vi=document.getElementById("search_button");let sc=JSON.parse(localStorage.getItem("searchTerms")||"[]");sc.forEach(y=>{O(y,"search_list","searchTerms")});Vi.addEventListener("click",function(){const y=Ti.value.trim();""===y||sc.includes(y)||(sc.push(y),localStorage.setItem("searchTerms",
JSON.stringify(sc)),O(y,"search_list","searchTerms"))});const sd=document.querySelector(".equipment-search-selection");sd.addEventListener("change",()=>{const y=Array.from(sd.querySelectorAll(".equipment-search-option:checked")).map(H=>H.value);localStorage.setItem("SearchTypes",JSON.stringify(y))});JSON.parse(localStorage.getItem("SearchTypes")||"[]").forEach(y=>{if(y=sd.querySelector(`.equipment-search-option[value="${y}"]`))y.checked=!0});let ib=JSON.parse(localStorage.getItem("itemsToSearch"))||
[];document.getElementById("addItemButton").addEventListener("click",function(){const y=document.getElementById("newItem").value,H=document.getElementById("itemQuality").value,P=document.getElementById("newItemLevel").value,Q=document.getElementById("shopitemstat").value,S=document.getElementById("statValue").value;ib.push({name:y,quality:H,An:P,qualityName:Wi[H],lm:"none"!==Q?Q:null,ym:"none"!==Q?S:null});ma();pa()});document.getElementById("startSearchButton").addEventListener("click",async function(){mc=
!0;nc.style.display="none";document.getElementById("clothCount").setAttribute("data-total",document.getElementById("clothCount").value);document.getElementById("startSearchButton").innerText="Searching...";await qa()});document.getElementById("stopSearchButton").addEventListener("click",fa);document.getElementById("shopitemstat").addEventListener("change",function(){document.getElementById("statValueRow").style.display="none"===this.value?"none":"block"});const nc=document.getElementById("skipSearchButton");
nc.addEventListener("click",async function(){const y=document.getElementById("foundItemsContainer");for(;y.firstChild;)y.removeChild(y.firstChild);Z();mc=!0;nc.style.display="none";da();Oa();await ya();await qa()});let mc=!0;const Wi={0:"Green",1:"Blue",2:"Purple",3:"Orange",4:"Red"};ma();ji();const Uc=document.querySelectorAll(".equipment-option-smelt");Uc.forEach(y=>{y.addEventListener("change",xb)});(JSON.parse(localStorage.getItem("equipmentSelectionSmelt"))||[]).forEach(y=>{const H=[...Uc].find(P=>
P.value===y);H&&(H.checked=!0)});const Vc=document.querySelectorAll(".equipment-option");Vc.forEach(y=>{y.addEventListener("change",Jb)});(JSON.parse(localStorage.getItem("equipmentSelection"))||[]).forEach(y=>{const H=[...Vc].find(P=>P.value===y);H&&(H.checked=!0)});Ui.addEventListener("click",function(){localStorage.setItem("AuctionSearch.timeOut",0);localStorage.setItem("ShopSearch.timeOut",0);location.reload()});let td=document.getElementById("trainPickGold");td.checked="true"===localStorage.getItem("trainPickGold");
td.addEventListener("change",()=>{localStorage.setItem("trainPickGold",td.checked)});let ud=document.getElementById("trainEnable");ud.checked="true"===localStorage.getItem("trainEnable");ud.addEventListener("change",()=>{localStorage.setItem("trainEnable",ud.checked)});let vd=document.getElementById("EnableArenaHell");vd.checked="true"===localStorage.getItem("EnableArenaHell");vd.addEventListener("change",()=>{localStorage.setItem("EnableArenaHell",vd.checked)});let wd=document.getElementById("dungeonAB");
wd.checked="true"===localStorage.getItem("dungeonAB");wd.addEventListener("change",()=>{localStorage.setItem("dungeonAB",wd.checked)});let xd=document.getElementById("dungeonFocusQuest");xd.checked="true"===localStorage.getItem("dungeonFocusQuest");xd.addEventListener("change",()=>{localStorage.setItem("dungeonFocusQuest",xd.checked)});(function(){const y=document.getElementById("autologinenable"),H="true"===localStorage.getItem("AutoLogin");y.checked=H;uf(H);y.addEventListener("change",function(){const P=
this.checked;localStorage.setItem("AutoLogin",P);uf(P)})})();const Kf=document.getElementById("timeConditions"),Xi=document.getElementById("addCondition");let Kb=JSON.parse(localStorage.getItem("timeConditions"))||[];Kb.forEach(Jf);Xi.addEventListener("click",()=>{const y={start:"",end:"",action:"stop"};Kb.push(y);Jf(y);yb()});const yd=document.getElementById("pauseButton");let Pb="true"===localStorage.getItem("botPaused");yd.textContent=Pb?"Paused":"Pause?";yd.addEventListener("click",function(){Pb=
!Pb;yd.textContent=Pb?"Paused":"Pause?";localStorage.setItem("botPaused",Pb.toString())});let zd=document.getElementById("enableCircusWithoutHeal");zd.checked="true"===localStorage.getItem("enableCircusWithoutHeal");zd.addEventListener("change",()=>{localStorage.setItem("enableCircusWithoutHeal",zd.checked)});let Ad=document.getElementById("arenaAttackGM");Ad.checked="true"===localStorage.getItem("arenaAttackGM");Ad.addEventListener("change",()=>{localStorage.setItem("arenaAttackGM",Ad.checked)});
let Bd=document.getElementById("onlyArena");Bd.checked="true"===localStorage.getItem("onlyArena");Bd.addEventListener("change",()=>{localStorage.setItem("onlyArena",Bd.checked)});let Cd=document.getElementById("onlyPlayerListArena");Cd.checked="true"===localStorage.getItem("onlyPlayerListArena");Cd.addEventListener("change",()=>{localStorage.setItem("onlyPlayerListArena",Cd.checked)});let Dd=document.getElementById("onlyPlayerListCircus");Dd.checked="true"===localStorage.getItem("onlyPlayerListCircus");
Dd.addEventListener("change",()=>{localStorage.setItem("onlyPlayerListCircus",Dd.checked)});let Ed=document.getElementById("onlyCircus");Ed.checked="true"===localStorage.getItem("onlyCircus");Ed.addEventListener("change",()=>{localStorage.setItem("onlyCircus",Ed.checked)});let Fd=document.getElementById("attackRandomly");Fd.checked="true"===localStorage.getItem("attackRandomly");Fd.addEventListener("change",()=>{localStorage.setItem("attackRandomly",Fd.checked)});let Gd=document.getElementById("attackRandomlyCircus");
Gd.checked="true"===localStorage.getItem("attackRandomlyCircus");Gd.addEventListener("change",()=>{localStorage.setItem("attackRandomlyCircus",Gd.checked)});let Hd=document.getElementById("circusAttackGM");Hd.checked="true"===localStorage.getItem("circusAttackGM");Hd.addEventListener("change",()=>{localStorage.setItem("circusAttackGM",Hd.checked)});let Id=document.getElementById("auctionmercenaryenable");Id.checked="true"===localStorage.getItem("auctionmercenaryenable");Id.addEventListener("change",
()=>{localStorage.setItem("auctionmercenaryenable",Id.checked)});let Jd=document.getElementById("auctionTURBO");Jd.checked="true"===localStorage.getItem("auctionTURBO");Jd.addEventListener("change",()=>{localStorage.setItem("auctionTURBO",Jd.checked)});let Kd=document.getElementById("auctiongladiatorenable");Kd.checked="true"===localStorage.getItem("auctiongladiatorenable");Kd.addEventListener("change",()=>{localStorage.setItem("auctiongladiatorenable",Kd.checked)});let Ld=document.getElementById("bidFood");
Ld.checked="true"===localStorage.getItem("bidFood");Ld.addEventListener("change",()=>{localStorage.setItem("bidFood",Ld.checked)});let Md=document.getElementById("ignorePS");Md.checked="true"===localStorage.getItem("ignorePS");Md.addEventListener("change",()=>{localStorage.setItem("ignorePS",Md.checked)});let Nd=document.getElementById("auctionminlevel");Nd.value=localStorage.getItem("auctionminlevel")||"";Nd.addEventListener("input",()=>{localStorage.setItem("auctionminlevel",Nd.value)});let Od=
document.getElementById("AuctionCover");Od.checked="true"===localStorage.getItem("AuctionCover");Od.addEventListener("change",()=>{localStorage.setItem("AuctionCover",Od.checked)});let Pd=document.getElementById("AuctionGoldCover");Pd.checked="true"===localStorage.getItem("AuctionGoldCover");Pd.addEventListener("change",()=>{localStorage.setItem("AuctionGoldCover",Pd.checked)});let Qd=document.getElementById("maximumBid");Qd.value=localStorage.getItem("maximumBid")||"";Qd.addEventListener("input",
()=>{localStorage.setItem("maximumBid",Qd.value)});let Rd=document.getElementById("activateAuction2");Rd.checked="true"===localStorage.getItem("activateAuction2");Rd.addEventListener("change",()=>{localStorage.setItem("activateAuction2",Rd.checked)});let Sd=document.getElementById("AuctionItemLevel2");Sd.value=localStorage.getItem("AuctionItemLevel2")||"";Sd.addEventListener("input",()=>{localStorage.setItem("AuctionItemLevel2",Sd.value)});let oc=document.getElementById("enableMercenarySearch"),Td=
document.getElementById("minDexterity"),Ud=document.getElementById("minAgility"),Vd=document.getElementById("minIntelligence");oc.checked="true"===localStorage.getItem("enableMercenarySearch");Td.value=localStorage.getItem("minDexterity")||0;Ud.value=localStorage.getItem("minAgility")||0;Vd.value=localStorage.getItem("minIntelligence")||0;Lf();oc.addEventListener("change",()=>{localStorage.setItem("enableMercenarySearch",oc.checked);Lf()});Td.addEventListener("input",()=>{localStorage.setItem("minDexterity",
Td.value)});Ud.addEventListener("input",()=>{localStorage.setItem("minAgility",Ud.value)});Vd.addEventListener("input",()=>{localStorage.setItem("minIntelligence",Vd.value)});const Wd=document.getElementById("SearchQuality"),lg=localStorage.getItem("SearchQuality");lg&&(Wd.value=lg);Wd.addEventListener("change",()=>{localStorage.setItem("SearchQuality",Wd.value)});const Xd=document.getElementById("HealPickBag"),mg=localStorage.getItem("HealPickBag");mg&&(Xd.value=mg);Xd.addEventListener("change",
()=>{localStorage.setItem("HealPickBag",Xd.value)});const Yd=document.getElementById("FoodAmount"),ng=localStorage.getItem("FoodAmount");ng&&(Yd.value=ng);Yd.addEventListener("change",()=>{localStorage.setItem("FoodAmount",Yd.value)});const og=document.getElementById("questrewardvalue");og.addEventListener("change",()=>{localStorage.setItem("questrewardvalue",og.value)});const Zd=document.getElementById("smeltTab"),pg=localStorage.getItem("smeltTab");pg&&(Zd.value=pg);Zd.addEventListener("change",
()=>{localStorage.setItem("smeltTab",Zd.value)});const $d=document.getElementById("repairMaxQuality"),ae=document.getElementById("repairBeforeSmeltMaxQuality"),be=document.getElementById("PartialOrFull");let tc=localStorage.getItem("repairMaxQuality"),uc=localStorage.getItem("repairBeforeSmeltMaxQuality"),vc=localStorage.getItem("PartialOrFull");tc||(tc="1",localStorage.setItem("repairMaxQuality",tc));uc||(uc="1",localStorage.setItem("RSMaxQuality",uc));vc||(vc="0",localStorage.setItem("PartialOrFull",
vc));$d.value=tc;ae.value=uc;$d.addEventListener("change",()=>{localStorage.setItem("repairMaxQuality",$d.value)});ae.addEventListener("change",()=>{localStorage.setItem("repairBeforeSmeltMaxQuality",ae.value)});be.addEventListener("change",()=>{localStorage.setItem("PartialOrFull",be.value)});be.value=vc;var wc=document.getElementById("repairPercentage");(function(){var y=localStorage.getItem("repairPercentage");if(null!==y)for(var H=0;H<wc.options.length;H++)if(wc.options[H].text.replace("%","")===
y){wc.selectedIndex=H;break}})();wc.addEventListener("change",function(){var y=this.options[this.selectedIndex].text.replace("%","");localStorage.setItem("repairPercentage",y)});const ce=document.getElementById("bidStatus"),qg=localStorage.getItem("bidStatus");qg&&(ce.value=qg);ce.addEventListener("change",()=>{localStorage.setItem("bidStatus",ce.value)});const de=document.getElementById("auctionMinQuality"),rg=localStorage.getItem("auctionMinQuality");rg&&(de.value=rg);de.addEventListener("change",
()=>{localStorage.setItem("auctionMinQuality",de.value)});const ee=document.getElementById("storeInShopQuality"),sg=localStorage.getItem("storeInShopQuality");sg&&(ee.value=sg);ee.addEventListener("change",()=>{localStorage.setItem("storeInShopQuality",ee.value)});const Ja=function(y,H){let P;return function(){const Q=this,S=arguments;clearTimeout(P);P=setTimeout(()=>y.apply(Q,S),H)}}(function(){const y=document.getElementById("resetExpiredItems").checked,H=document.getElementById("resetUnderworld").checked,
P=document.getElementById("resetDays").value,Q=Array.from(document.querySelectorAll('#itemsToReset input[type="checkbox"]:checked')).map(X=>X.value),S=Array.from(document.querySelectorAll('#itemsToReset2 input[type="checkbox"]:checked')).map(X=>X.value),la=Array.from(document.querySelectorAll('#itemsToResetGuild input[type="checkbox"]:checked')).map(X=>X.value);localStorage.setItem("resetExpiredItems",y);localStorage.setItem("resetUnderworld",H);localStorage.setItem("resetDays",P);localStorage.setItem("itemsToReset",
JSON.stringify(Q));localStorage.setItem("itemsToReset2",JSON.stringify(S));localStorage.setItem("itemsToResetGuild",JSON.stringify(la))},250);document.getElementById("resetExpiredItems").addEventListener("change",Ja);document.getElementById("resetUnderworld").addEventListener("change",Ja);document.getElementById("resetDays").addEventListener("change",Ja);document.getElementById("itemsToReset").addEventListener("change",Ja);document.getElementById("itemsToReset2").addEventListener("change",Ja);document.getElementById("itemsToResetGuild").addEventListener("change",
Ja);document.getElementById("resetExpiredItems").addEventListener("touchend",Ja);document.getElementById("resetUnderworld").addEventListener("touchend",Ja);document.getElementById("resetDays").addEventListener("touchend",Ja);document.getElementById("itemsToReset").addEventListener("touchend",Ja);document.getElementById("itemsToReset2").addEventListener("touchend",Ja);document.getElementById("itemsToResetGuild").addEventListener("touchend",Ja);document.getElementById("selectAllItems").addEventListener("click",
function(){let y="true"!==this.dataset.checked;this.innerHTML=(this.dataset.checked=y)?'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <polyline points="20 6 9 17 4 12"></polyline>\n                    </svg>':'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line> \n                    </svg>';
ti(y)});(function(){const y="true"===localStorage.getItem("resetExpiredItems"),H="true"===localStorage.getItem("resetUnderworld"),P=localStorage.getItem("resetDays"),Q=JSON.parse(localStorage.getItem("itemsToReset")||"[]"),S=JSON.parse(localStorage.getItem("itemsToReset2")||"[]"),la=JSON.parse(localStorage.getItem("itemsToResetGuild")||"[]");document.getElementById("resetExpiredItems").checked=y;document.getElementById("resetUnderworld").checked=H;document.getElementById("resetDays").value=P;Q.forEach(X=>
{if(X=document.getElementById(X))X.checked=!0});S.forEach(X=>{if(X=document.getElementById(X))X.checked=!0});la.forEach(X=>{if(X=document.getElementById(X))X.checked=!0})})();const fe=document.getElementById("guildPackHour"),tg=localStorage.getItem("guildPackHour");tg&&(fe.value=tg);fe.addEventListener("change",()=>{localStorage.setItem("guildPackHour",fe.value)});const ge=document.getElementById("filterGM"),ug=localStorage.getItem("filterGM");ug&&(ge.value=ug);ge.addEventListener("change",()=>{localStorage.setItem("filterGM",
ge.value)});const rb=document.getElementById("delaySelect"),vg=localStorage.getItem("DELAY");if(vg)for(let y=0;y<rb.options.length;y++)if(rb.options[y].text===vg){rb.value=rb.options[y].value;break}rb.addEventListener("change",()=>{localStorage.setItem("DELAY",rb.options[rb.selectedIndex].text)});const he=document.getElementById("questSpeed"),wg=localStorage.getItem("questSpeed");wg&&(he.value=wg);he.addEventListener("change",()=>{localStorage.setItem("questSpeed",he.value)});let xg=document.getElementById("itemToBuy"),
yg=document.getElementById("rarity"),zg=document.getElementById("marketItemType"),Ag=document.getElementById("itemsoulbound"),Bg=document.getElementById("maxPrice"),Yi=document.getElementById("addItemBtn"),Zi=document.getElementById("removeItemBtn"),$i=document.getElementById("MarketremoveItemBtn"),Xc=document.getElementById("itemList"),Mf=document.getElementById("MarketboughtItems"),Lb=localStorage.getItem("MarketboughtItems");Lb?Lb=JSON.parse(Lb):Lb=[];const Cg=document.getElementById("MarketSearchInterval");
Cg.addEventListener("change",()=>{localStorage.setItem("MarketSearchInterval",Cg.value)});document.getElementById("MarketSearchInterval").addEventListener("input",function(){3>parseInt(this.value,10)&&(this.value=3)});const Dg=document.getElementById("MarketMaxPerFoodPrice");Dg.addEventListener("change",()=>{localStorage.setItem("MarketMaxPerFoodPrice",Dg.value)});const Eg=document.getElementById("MarketMaxFoodPrice");Eg.addEventListener("change",()=>{localStorage.setItem("MarketMaxFoodPrice",Eg.value)});
const Fg=document.getElementById("MarketMinItemLevel");Fg.addEventListener("change",()=>{localStorage.setItem("MarketMinItemLevel",Fg.value)});let ie=document.getElementById("marketOnlyFood");ie.checked="true"===localStorage.getItem("marketOnlyFood");ie.addEventListener("change",()=>{localStorage.setItem("marketOnlyFood",ie.checked)});let jb=JSON.parse(localStorage.getItem("marketItems"))||[];Yi.onclick=function(){jb.push({itemToBuy:xg.value||1,rarity:yg.value||4,maxPrice:Bg.value||4,itemType:zg.value||
4,Soulbound:Ag.value||2});xg.value="";yg.value="White";Bg.value="";zg.value="WEAPONS";Ag.value="DontBuySoulbound";Wc()};Zi.onclick=function(){jb.splice(Xc.value,1);Wc()};$i.onclick=function(){document.getElementById("MarketboughtItems").innerHTML="";localStorage.setItem("MarketboughtItems",JSON.stringify([]))};Wc();let je=document.getElementById("enableMarketSearch");je.checked="true"===localStorage.getItem("enableMarketSearch");je.addEventListener("change",()=>{localStorage.setItem("enableMarketSearch",
je.checked)});let ke=document.getElementById("usePacks");ke.checked="true"===localStorage.getItem("usePacks");ke.addEventListener("change",()=>{localStorage.setItem("usePacks",ke.checked)});const le=document.getElementById("scoreRange"),Gg=localStorage.getItem("scoreRange");Gg&&(le.value=Gg);le.addEventListener("change",()=>{localStorage.setItem("scoreRange",le.value)});const me=document.getElementById("scoreRangeCircus"),Hg=localStorage.getItem("scoreRangeCircus");Hg&&(me.value=Hg);me.addEventListener("change",
()=>{localStorage.setItem("scoreRangeCircus",me.value)});let ne=document.getElementById("scoreboardattackenable");ne.checked="true"===localStorage.getItem("scoreboardattackenable");ne.addEventListener("change",()=>{localStorage.setItem("scoreboardattackenable",ne.checked)});let oe=document.getElementById("scoreboardcircusenable");oe.checked="true"===localStorage.getItem("scoreboardcircusenable");oe.addEventListener("change",()=>{localStorage.setItem("scoreboardcircusenable",oe.checked)});let pe=document.getElementById("leagueattackenable");
pe.checked="true"===localStorage.getItem("leagueattackenable");pe.addEventListener("change",()=>{localStorage.setItem("leagueattackenable",pe.checked)});let Qb=document.getElementById("leaguerandom");Qb.checked="true"===localStorage.getItem("leaguerandom");Qb.addEventListener("change",()=>{localStorage.setItem("leaguerandom",Qb.checked);Qb.checked&&(Rb.checked=!1,localStorage.setItem("leaguelowtohigh",!1))});let Rb=document.getElementById("leaguelowtohigh");Rb.checked="true"===localStorage.getItem("leaguelowtohigh");
Rb.addEventListener("change",()=>{localStorage.setItem("leaguelowtohigh",Rb.checked);Rb.checked&&(Qb.checked=!1,localStorage.setItem("leaguerandom",!1))});let qe=document.getElementById("leaguecircusattackenable");qe.checked="true"===localStorage.getItem("leaguecircusattackenable");qe.addEventListener("change",()=>{localStorage.setItem("leaguecircusattackenable",qe.checked)});let Sb=document.getElementById("leaguecircusrandom");Sb.checked="true"===localStorage.getItem("leaguecircusrandom");Sb.addEventListener("change",
()=>{localStorage.setItem("leaguecircusrandom",Sb.checked);Sb.checked&&(Tb.checked=!1,localStorage.setItem("leaguecircuslowtohigh",!1))});let Tb=document.getElementById("leaguecircuslowtohigh");Tb.checked="true"===localStorage.getItem("leaguecircuslowtohigh");Tb.addEventListener("change",()=>{localStorage.setItem("leaguecircuslowtohigh",Tb.checked);Tb.checked&&(Sb.checked=!1,localStorage.setItem("leaguecircusrandom",!1))});let re=document.getElementById("autoAddArena");re.checked="true"===localStorage.getItem("autoAddArena");
re.addEventListener("change",()=>{localStorage.setItem("autoAddArena",re.checked)});let se=document.getElementById("autoAvoidArena");se.checked="true"===localStorage.getItem("autoAvoidArena");se.addEventListener("change",()=>{localStorage.setItem("autoAvoidArena",se.checked)});const Ig=document.getElementById("autoAddArenaAmount");Ig.addEventListener("change",()=>{localStorage.setItem("autoAddArenaAmount",Ig.value)});let te=document.getElementById("autoAddCircus");te.checked="true"===localStorage.getItem("autoAddCircus");
te.addEventListener("change",()=>{localStorage.setItem("autoAddCircus",te.checked)});let ue=document.getElementById("autoAvoidCircus");ue.checked="true"===localStorage.getItem("autoAvoidCircus");ue.addEventListener("change",()=>{localStorage.setItem("autoAvoidCircus",ue.checked)});const Jg=document.getElementById("autoAddCircusAmount");Jg.addEventListener("change",()=>{localStorage.setItem("autoAddCircusAmount",Jg.value)});let ve=document.getElementById("UnderWorldUseRuby");ve.checked="true"===localStorage.getItem("UnderWorldUseRuby");
ve.addEventListener("change",()=>{localStorage.setItem("UnderWorldUseRuby",ve.checked)});let we=document.getElementById("useSacrifice");we.checked="true"===localStorage.getItem("useSacrifice");we.addEventListener("change",()=>{localStorage.setItem("useSacrifice",we.checked)});let xe=document.getElementById("usePray");xe.checked="true"===localStorage.getItem("usePray");xe.addEventListener("change",()=>{localStorage.setItem("usePray",xe.checked)});let ye=document.getElementById("UnderworldUseMobi");
ye.checked="true"===localStorage.getItem("UnderworldUseMobi");ye.addEventListener("change",()=>{localStorage.setItem("UnderworldUseMobi",ye.checked)});let ze=document.getElementById("exitUnderworld");ze.checked="true"===localStorage.getItem("exitUnderworld");ze.addEventListener("change",()=>{localStorage.setItem("exitUnderworld",ze.checked)});let Ae=document.getElementById("autoEnterHell");Ae.checked="true"===localStorage.getItem("autoEnterHell");Ae.addEventListener("change",()=>{localStorage.setItem("autoEnterHell",
Ae.checked)});let Be=document.getElementById("dontEnterUnderworld");Be.checked="true"===localStorage.getItem("dontEnterUnderworld");Be.addEventListener("change",()=>{localStorage.setItem("dontEnterUnderworld",Be.checked)});let Ce=document.getElementById("disableLogMenu");Ce.checked="true"===localStorage.getItem("disableLogMenu");Ce.addEventListener("change",()=>{localStorage.setItem("disableLogMenu",Ce.checked)});let De=document.getElementById("disableBG");De.checked="true"===localStorage.getItem("disableBG");
De.addEventListener("change",()=>{localStorage.setItem("disableBG",De.checked)});let Ee=document.getElementById("MoveButtons");Ee.checked="true"===localStorage.getItem("MoveButtons");Ee.addEventListener("change",()=>{localStorage.setItem("MoveButtons",Ee.checked)});let Fe=document.getElementById("pauseBotEnable");Fe.checked="true"===localStorage.getItem("pauseBotEnable");Fe.addEventListener("change",()=>{localStorage.setItem("pauseBotEnable",Fe.checked)});const Kg=document.getElementById("pauseBot");
Kg.addEventListener("change",()=>{Y("pauseBot",Kg.value)});let Ge=document.getElementById("storeGoldinAuction");Ge.checked="true"===localStorage.getItem("storeGoldinAuction");Ge.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuction",Ge.checked)});const Lg=document.getElementById("storeGoldinAuctionmaxGold");Lg.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuctionmaxGold",Lg.value)});const Mg=document.getElementById("storeGoldinAuctionholdGold");Mg.addEventListener("change",
()=>{localStorage.setItem("storeGoldinAuctionholdGold",Mg.value)});const Ng=document.getElementById("TrainingHoldGold");Ng.addEventListener("change",()=>{localStorage.setItem("TrainingHoldGold",Ng.value)});const Og=document.getElementById("MarketHoldGold");Og.addEventListener("change",()=>{localStorage.setItem("MarketHoldGold",Og.value)});const Pg=document.getElementById("KasaHoldGold");Pg.addEventListener("change",()=>{localStorage.setItem("KasaHoldGold",Pg.value)});let He=document.getElementById("guildBattleEnable");
He.checked="true"===localStorage.getItem("guildBattleEnable");He.addEventListener("change",()=>{localStorage.setItem("guildBattleEnable",He.checked)});let Ie=document.getElementById("guildBattleRandom");Ie.checked="true"===localStorage.getItem("guildBattleRandom");Ie.addEventListener("change",()=>{localStorage.setItem("guildBattleRandom",Ie.checked)});let Je=document.getElementById("GuildEnable");Je.checked="true"===localStorage.getItem("GuildEnable");Je.addEventListener("change",()=>{localStorage.setItem("GuildEnable",
Je.checked)});const Qg=document.getElementById("GuildDonateAmount");Qg.addEventListener("change",()=>{localStorage.setItem("GuildDonateAmount",Qg.value)});const Rg=document.getElementById("GuildDonateMore");Rg.addEventListener("change",()=>{localStorage.setItem("GuildDonateMore",Rg.value)});const Sg=document.getElementById("GuildDonateLess");Sg.addEventListener("change",()=>{localStorage.setItem("GuildDonateLess",Sg.value)});document.getElementById("hellDifficulty").addEventListener("change",function(){localStorage.setItem("hellDifficulty",
this.value)});const aj=document.getElementById("hellDifficulty"),Tg=localStorage.getItem("hellDifficulty");null!==Tg&&(aj.value=Tg);let Ke=document.getElementById("useVillaMedici");Ke.checked="true"===localStorage.getItem("useVillaMedici");Ke.addEventListener("change",()=>{localStorage.setItem("useVillaMedici",Ke.checked)});let Le=document.getElementById("useHealingPotion");Le.checked="true"===localStorage.getItem("useHealingPotion");Le.addEventListener("change",()=>{localStorage.setItem("useHealingPotion",
Le.checked)});const Me=document.getElementById("repairMercenary");Me.checked="true"===localStorage.getItem("repairMercenary");Me.addEventListener("change",()=>{localStorage.setItem("repairMercenary",Me.checked)});const Ne=document.getElementById("repairGladiator");Ne.checked="true"===localStorage.getItem("repairGladiator");Ne.addEventListener("change",()=>{localStorage.setItem("repairGladiator",Ne.checked)});let Oe=document.getElementById("activateRepair");Oe.checked="true"===localStorage.getItem("activateRepair");
Oe.addEventListener("change",()=>{localStorage.setItem("activateRepair",Oe.checked)});const bj=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(y=>{y.checked=bj.includes(y.value)});document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(y=>{y.addEventListener("change",()=>{const H=[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(P=>{P.checked&&H.push(P.value)});
localStorage.setItem("ignoredMaterials",JSON.stringify(H))})});const Ug=document.querySelectorAll(".gladiator-inventory .inventory-item"),Vg=document.querySelectorAll(".mercenary-inventory .inventory-item"),Wg=JSON.parse(localStorage.getItem("activeItemsGladiator"))||{},Xg=JSON.parse(localStorage.getItem("activeItemsMercenary"))||{};Ug.forEach(y=>{Nf(y,Wg,"activeItemsGladiator")});Vg.forEach(y=>{Nf(y,Xg,"activeItemsMercenary")});Of(Ug,Wg,"helmet necklace weapon armor shield gloves shoes rings1 rings2".split(" "),
"activeItemsGladiator");Of(Vg,Xg,"helmetM necklaceM weaponM armorM shieldM glovesM shoesM rings1M rings2M".split(" "),"activeItemsMercenary");const Yg=document.getElementById("expeditionLocation");Yg.addEventListener("change",()=>{localStorage.setItem("expeditionLocation",Yg.value)});const Zg=document.getElementById("dungeonLocation");Zg.addEventListener("change",()=>{localStorage.setItem("dungeonLocation",Zg.value)});const xc=document.getElementById("autoCollectBonuses");xc.checked="true"===localStorage.getItem("autoCollectBonuses");
document.getElementById("enemySelection").style.display=xc.checked?"none":"block";xc.addEventListener("change",()=>{localStorage.setItem("autoCollectBonuses",xc.checked)});const Pe=document.getElementById("skipBossToggle");Pe.checked="true"===localStorage.getItem("skipBoss");Pe.addEventListener("change",()=>{localStorage.setItem("skipBoss",Pe.checked)});const Qe=document.getElementById("resetIfLoseToggle");Qe.checked="true"===localStorage.getItem("resetIfLose");Qe.addEventListener("change",()=>{localStorage.setItem("resetIfLose",
Qe.checked)});const Re=document.getElementById("activateSmelt");Re.checked="true"===localStorage.getItem("EnableSmelt");Re.addEventListener("change",()=>{localStorage.setItem("EnableSmelt",Re.checked)});const Se=document.getElementById("EnableHellLimit"),$g=document.getElementById("hellLimit").closest(".setting-row"),ah="true"===localStorage.getItem("EnableHellLimit"),bh=localStorage.getItem("hellLimit")||5;Se.checked=ah;document.getElementById("hellLimit").value=bh;$g.style.display=ah?"block":"none";
Se.addEventListener("change",function(){const y=Se.checked;localStorage.setItem("EnableHellLimit",y);$g.style.display=y?"block":"none"});document.getElementById("hellLimit").addEventListener("input",function(){const y=document.getElementById("hellLimit").value;1<=y&&200>=y?localStorage.setItem("hellLimit",y):document.getElementById("hellLimit").value=bh});const pc=document.getElementById("farmEnable"),ui=document.getElementById("farmLocation").closest(".setting-row"),vi=document.getElementById("farmEnemy").closest(".setting-row"),
cj="true"===localStorage.getItem("farmEnable"),ch=localStorage.getItem("farmLocation"),dh=localStorage.getItem("farmEnemy");pc.checked=cj;ch&&(document.getElementById("farmLocation").value=ch);dh&&(document.getElementById("farmEnemy").value=dh);Pf();pc.addEventListener("change",function(){localStorage.setItem("farmEnable",pc.checked);Pf()});document.getElementById("farmLocation").addEventListener("change",function(){localStorage.setItem("farmLocation",this.value)});document.getElementById("farmEnemy").addEventListener("change",
function(){localStorage.setItem("farmEnemy",this.value)});const Te=document.getElementById("doHeal");Te.checked="true"===localStorage.getItem("HealEnabled");Te.addEventListener("change",()=>{localStorage.setItem("HealEnabled",Te.checked)});const Ue=document.getElementById("healShopToggle");Ue.checked="true"===localStorage.getItem("HealShop");Ue.addEventListener("change",()=>{localStorage.setItem("HealShop",Ue.checked)});const Ve=document.getElementById("healfrompackage");Ve.checked="true"===localStorage.getItem("HealPackage");
Ve.addEventListener("change",()=>{localStorage.setItem("HealPackage",Ve.checked)});const We=document.getElementById("healcervisia");We.checked="true"===localStorage.getItem("HealCervisia");We.addEventListener("change",()=>{localStorage.setItem("HealCervisia",We.checked)});const Xe=document.getElementById("HealEggs");Xe.checked="true"===localStorage.getItem("HealEggs");Xe.addEventListener("change",()=>{localStorage.setItem("HealEggs",Xe.checked)});const Ye=document.getElementById("OilEnable");Ye.checked=
"true"===localStorage.getItem("OilEnable");Ye.addEventListener("change",()=>{localStorage.setItem("OilEnable",Ye.checked)});document.getElementById("enemySelect").addEventListener("change",function(){localStorage.setItem("selectedEnemy",this.value)});const dj=document.getElementById("enemySelect"),eh=localStorage.getItem("selectedEnemy");null!==eh&&(dj.value=eh);document.getElementById("autoCollectBonuses").addEventListener("change",function(){document.getElementById("enemySelection").style.display=
this.checked?"none":"block"});wi.addEventListener("change",function(){this.checked?(c(!0),Fa=!0):(c(!1),Fa=!1);localStorage.setItem("doExpedition",Fa);w()});xi.addEventListener("change",function(){this.checked?(e(!0),Ga=!0):(e(!1),Ga=!1);localStorage.setItem("doDungeon",Ga);w()});yi.addEventListener("change",function(){this.checked?(g(!0),Ha=!0):(g(!1),Ha=!1);localStorage.setItem("doArena",Ha);w()});document.getElementById("addAutoAttack").addEventListener("click",()=>{const y=document.getElementById("autoAttackInput").value.trim();
y&&hc(y,"autoAttackList","autoAttackList")});document.getElementById("addAvoidAttack").addEventListener("click",()=>{const y=document.getElementById("avoidAttackInput").value.trim();y&&hc(y,"avoidAttackList","avoidAttackList")});document.getElementById("addAutoCircusAttack").addEventListener("click",()=>{const y=document.getElementById("autoAttackCircusInput").value.trim();y&&hc(y,"autoAttackCircusList","autoAttackCircusList")});document.getElementById("addAvoidCircusAttack").addEventListener("click",
()=>{const y=document.getElementById("avoidAttackCircusInput").value.trim();y&&hc(y,"avoidAttackCircusList","avoidAttackCircusList")});ni();zi.addEventListener("change",function(){this.checked?(k(!0),Ma=!0):(k(!1),Ma=!1);localStorage.setItem("doCircus",Ma);w()});Ai.addEventListener("change",function(){this.checked?(h(!0),Ta=!0):(h(!1),Ta=!1);localStorage.setItem("doQuests",Ta);w()});Di.addEventListener("change",function(){this.checked?(n(!0),pb=!0):(n(!1),pb=!1);localStorage.setItem("doKasa",pb);
w()});Ci.addEventListener("change",function(){this.checked?(q(!0),hb=!0):(q(!1),hb=!1);localStorage.setItem("AutoAuction",hb);w()});Bi.addEventListener("change",function(){this.checked?(l(!0),Ia=!0):(l(!1),Ia=!1);localStorage.setItem("doEventExpedition",Ia);w()});qc.addEventListener("input",()=>{let y=parseInt(qc.value,10);1>y?y=1:99<y&&(y=99);qc.value=y;localStorage.setItem("healPercentage",y)});Qf.addEventListener("input",()=>{localStorage.setItem("hellEnterHP",Qf.value)});Rf.addEventListener("input",
()=>{localStorage.setItem("HellHealHP",Rf.value)});Yc.addEventListener("change",()=>{localStorage.setItem("HealClothToggle",Yc.checked)});Zc.addEventListener("change",()=>{localStorage.setItem("HealRubyToggle",Zc.checked)});$c.addEventListener("change",()=>{localStorage.setItem("storeResource",$c.checked)});ad.addEventListener("change",()=>{localStorage.setItem("HighlightUnderworldItems",ad.checked)});const Ze=document.querySelectorAll(".stat-checkbox"),ej=localStorage.getItem("selectedStat");for(const y of Ze)y.checked=
y.id===ej;for(const y of Ze)y.addEventListener("change",()=>{if(y.checked){for(const H of Ze)H!==y&&(H.checked=!1);localStorage.setItem("selectedStat",y.id);localStorage.setItem("statID",y.getAttribute("data-skill"))}else localStorage.removeItem("selectedStat")})});$("#set_event_monster_id_0").click(function(){r("0")});$("#set_event_monster_id_1").click(function(){r("1")});$("#set_event_monster_id_2").click(function(){r("2")});$("#set_event_monster_id_3").click(function(){r("3")});w()}async function fj(){if("true"===
localStorage.getItem("storeResource")){var b=new URL(window.location.href),c=b.origin;b=b.searchParams.get("sh")||"";const e=Date.now();c=`${c}/game/ajax.php?mod=forge&submod=storageIn`;const g=new FormData;g.append("inventory","1");g.append("packages","1");g.append("sell","1");g.append("a",e);g.append("sh",b);b=JSON.parse(localStorage.getItem("Timers"));Y("storeForgeResources",b.StoreForge||60);try{(await fetch(c,{method:"POST",body:g})).ok?D(`${d.Gf}`):window.location.reload()}catch(k){window.location.reload()}}}
async function gj(){var b=new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=JSON.parse(localStorage.getItem("statSettings"))||[];const g=JSON.parse(localStorage.getItem("Timers"))||{},k="true"===localStorage.getItem("trainPickGold"),h={Strength:1,Dexterity:2,Agility:3,Constitution:4,Charisma:5,Intelligence:6};b.forEach(n=>{n.xm=h[n.stat]});b.sort((n,m)=>"None"===n.priority?1:"None"===m.priority?-1:parseInt(n.priority,10)-parseInt(m.priority,10));c=await (await fetch(`${c}/game/index.php?mod=training&sh=${e}`)).text();
const l=[];(new DOMParser).parseFromString(c,"text/html").querySelectorAll("#training_box .training_inner").forEach((n,m)=>{m+=1;var r=n.nextElementSibling?.querySelector(".training_link .training_button");r=r?r.getAttribute("href"):null;(n=(n=(n=n.nextElementSibling?.querySelector(".training_costs"))?n.textContent.trim():null)?parseInt(n.replace(/[^\d]/g,""),10):null)&&r?l.push({xm:m,sn:n,Rn:r}):l.push({xm:m,sn:n,Rn:r})});for(const n of b){c=n.stat;const m=n.xm;var q=n.priority;if(1>Number(n.count)||
"None"===q)continue;q=l.find(v=>v.xm===m);if(!q){D(`No training available for ${c}`);continue}const r=q.sn;q=q.Rn;const w=parseInt(localStorage.getItem("TrainingHoldGold"),10)||0;if(ba.gold>=r+w){await fetch(q);--n.count;n.count=Math.max(0,n.count);localStorage.setItem("statSettings",JSON.stringify(b));D(`Trained ${c} for ${r} gold`);Y("Training",g.Training||2);return}if(k){q=await jQuery.get(F({mod:"packages",f:14,fq:-1,qry:"",page:1,sh:e}));let v=0,x=null;jQuery(q).find(".packageItem").each(function(C,
E){C=parseInt(jQuery(E).find(".ui-draggable").attr("data-price-gold"),10);if(C>=r+w)return v=C,x=jQuery(E),!1});if(0<v&&x)try{await ac(1,1,async(C,E)=>{const A=x.find('input[name="packages[]"]').val(),t=x.find(".ui-draggable").attr("data-position-x"),u=x.find(".ui-draggable").attr("data-position-y");await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+A,fromX:t,fromY:u,to:E,toX:C.x+1,toY:C.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:e}));D(`Moved ${v} gold to inventory for training`);ba.gold+=
v;localStorage.setItem("Training",0);window.location.reload()})}catch(C){D(`Error moving gold: ${C.message}`)}else D(`${d.Gd}: ${c}`)}else D(`${d.Gd}`)}Y("Training",g.Training||2)}function hj(){const b=JSON.parse(localStorage.getItem("statSettings"));for(let c=0;c<b.length;c++)if("0"!==b[c].count||b[c].ln)return!0;return!1}function ij(){var b=new URL(window.location.href),c=localStorage.getItem("scoreboardattackenable"),e=localStorage.getItem("scoreboardcircusenable");if(document.querySelector(".reportWin")){var g=
document.querySelector(".report_reward");g&&(g=g.querySelector('img[src*="71e68d38f81ee6f96a618f33c672e0.gif"]'))&&(g=g.previousSibling)&&g.nodeType===Node.TEXT_NODE&&(g=g.textContent.trim().match(/(\d+(?:\.\d+)?)/))&&(g=parseFloat(g[1]),b.href.includes("&t=2")?ka("arenaMoney",g):b.href.includes("&t=3")&&ka("circusMoney",g))}if(b.href.includes("submod=showCombatReport")&&b.href.includes("&t=1"))(c=document.getElementById("reportHeader"))&&(c.classList.contains("reportWin")||"true"!==sessionStorage.getItem("autoGoActive")?
localStorage.setItem("loose","false"):localStorage.setItem("loose","true"));else if(b.href.includes("submod=showCombatReport")){let l=document.querySelector("p > a + img");var k=document.querySelector("#defenderAvatar11 .playername_achievement");null===k&&(k=document.querySelector("#defenderAvatar11 .playername.ellipsis "));(g=document.getElementById("reportHeader"))&&!g.classList.contains("reportWin")&&(localStorage.setItem("nextQuestTime.timeOut",0),localStorage.setItem("nextQuestTime",0));g=0;
if(k&&(k=k.innerText.trim(),!k.includes("#"))){try{var h=l.previousSibling.nodeValue.trim();h=h.split(" ").pop();h=h.replace(".","");h=h.replace(",",".");g=parseFloat(h)}catch(q){}b.href.includes("&t=2")?(e=document.getElementById("reportHeader").classList.contains("reportWin"),b=JSON.parse(localStorage.getItem("tempOpponentDetails")),h=Cf.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidArena")||e||kb("avoidAttackList",k),"true"===localStorage.getItem("autoAddArena")&&Number(g)>=Number(localStorage.getItem("autoAddArenaAmount"))&&
b&&b.serverId&&(h===b.serverId?(kb("autoAttackList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===c&&k!=b.playerName?kb("autoAttackList",k):h!==b.serverId&&kb("autoAttackServerList",b))):b.href.includes("&t=3")&&(c=document.getElementById("reportHeader").classList.contains("reportWin"),b=JSON.parse(localStorage.getItem("tempOpponentDetails")),h=Cf.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidCircus")||c||kb("avoidAttackCircusList",k),"true"===localStorage.getItem("autoAddCircus")&&
g>=Number(localStorage.getItem("autoAddCircusAmount"))&&b&&b.serverId&&(h===b.serverId?(kb("autoAttackCircusList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===e&&k!=b.playerName?kb("autoAttackCircusList",k):h!==b.serverId&&kb("autoAttackCircusServerList",b)))}}}function kb(b,c){let e=JSON.parse(localStorage.getItem(b))||[];if("object"===typeof c&&null!==c){let g=c.playerName;e.some(k=>k.playerName===g&&k.serverId===c.serverId)||e.push(c)}else"string"===typeof c&&(e.includes(c)||
e.push(c));localStorage.setItem(b,JSON.stringify(e))}async function fh(b){var c=new URL(window.location.href),e=c.origin,g=c.searchParams;c=localStorage.getItem("AuctionItemLevel2")||"";const k=g.get("itemType")||"",h=localStorage.getItem("SearchQuality")||"";g=g.get("sh")||"";e=new URL(`${e}/game/index.php?mod=auction&qry=&itemLevel=${c}&itemType=${k}&itemQuality=${h}&sh=${g}`);e.searchParams.set("mod","auction");e.searchParams.set("itemLevel",c);e.searchParams.set("itemType",k);e.searchParams.set("itemQuality",
h);e.searchParams.set("sh",g);b&&e.searchParams.set("ttype",b);b=await (await fetch(e.href)).text();return(new DOMParser).parseFromString(b,"text/html")}async function If(){var b=new URL(window.location.href);const c=b.origin,e=b.searchParams.get("sh")||"";b=Array.from({length:5},(k,h)=>[new URL(`${c}/game/index.php?mod=inventory&sub=${h+1}&subsub=0&sh=${e}`),new URL(`${c}/game/index.php?mod=inventory&sub=${h+1}&subsub=1&sh=${e}`)]).flat();const g=async k=>{var h=await (await fetch(k.href)).text();
h=(new DOMParser).parseFromString(h,"text/html");h.Vm=k.href;return h};return await Promise.all(b.map(k=>g(k)))}function $e(b){return JSON.parse(b.replace(/&quot;/g,'"'))[0][0][0]}async function jj(b){b=(new TextEncoder).encode(b.toString());b=await crypto.subtle.digest("SHA-256",b);return Array.from(new Uint8Array(b)).map(c=>c.toString(16).padStart(2,"0")).join("")}function gb(){(function(b){const c=setInterval(()=>{const e=document.getElementById("mainmenu");e&&(clearInterval(c),b(e))},500)})(b=>
{if(!document.querySelector(".customButtonm")){var c=document.createElement("button");c.className="customButtonm";c.innerHTML='\n            <style>\n            .customButtonm {\n                vertical-align: middle;\n                width: 179px;\n                height: 50px;\n                background-image: linear-gradient(135deg, #f29b20 0%, #b18026 100%);\n                border: 2px solid #000;\n                color: white;\n                text-align: center;\n                text-decoration: none;\n                border-radius: 5px;\n                display: inline-block;\n                font-size: 16px;\n                margin: 4px auto;\n                cursor: pointer;\n                box-shadow: 5px 2px 5px rgba(0, 0, 0, 0.3), inset 0 1px 1px rgba(255, 255, 255, 0.4), inset 0 -1px 1px rgba(0, 0, 0, 0.3);\n                padding: 18px 34px;\n                transition-duration: 0.4s;\n            }\n        \n            .customButtonm span {\n                top: 50%;\n                position: relative;\n                transform: translateY(-50%);\n                display: block;\n                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);\n            }\n            </style>\n\n            <span class="span-new">License expired or Server Error. Check Discord</span>\n\n        ';
b.insertBefore(c,b.children[0]);Gf(45E3)}});return!1}async function kj(b,c,e){function g(k){const h=[];for(let l=0;l<k.length;l+=2)h.push(parseInt(k.substr(l,2),16));return new Uint8Array(h)}try{if(!e)return!1;const [k,h]=e.split(":"),l=g(k),q=g(h);if(b!==xa)return!1;const n=await window.crypto.subtle.importKey(String.fromCharCode(114,97,119),g("46d9ef519c1474cf8699ba24ab2a726a"),{name:String.fromCharCode(65,69,83)+"-CBC"},!1,[String.fromCharCode(100,101,99,114,121,112,116)]),m=await window.crypto.subtle.decrypt({name:String.fromCharCode(65,
69,83)+"-CBC",iv:l},n,q),r=(new TextDecoder).decode(new Uint8Array(m)),w=new Date(r);w.setHours(0,0,0,0);if(!0!==c)return!1;const v=new Date,x=new Date(v.setMonth(v.getMonth()+13));return w>x||r<v?!1:!0}catch{throw gb(),Error("supportDev");}}function lj(){function b(h,l){sb?alert("A repair process is already running."):(k.Jn=l,jQuery(".gladbot-worbench-button").addClass("disabled"),k.u(),k.In=[],k.queue=0,jQuery(document.body).addClass("workbench-cursor"),jQuery(document.body).on("contextmenu",function(q){q.preventDefault();
jQuery(document.body).removeClass("workbench-cursor");jQuery(document.body).off("contextmenu")}),jQuery("#inv .ui-draggable, #char .ui-draggable").mouseup(async q=>{q=q.target;var n=q.className.match(/item-i-(\d+)-\d+/)[1],m=document.querySelector(".charmercsel.active").getAttribute("onclick").toString().match(/doll=(\d+)/),r=k.freeSlots.shift()["forge_slots.slot"];m=m[1];r={item:{type:n,name:Gb(q),quality:Ba(q),slot:r,container:q.getAttribute("data-container-number"),doll:m},spot:{bag:q.getAttribute("data-container-number"),
x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")}};localStorage.setItem("workbench_itemList1",JSON.stringify(r));if(jQuery(q).parents("#char").length)if(sb)alert("A repair process is already running.");else{if(n=document.querySelector("#inventory_nav .awesome-tabs.current"))n=n.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",n);var {spot:w,bag:v}=await ac(2,3);k.ra={bag:v,x:w.x+1,y:w.y+1};k.On(q);k.Um(q,0,m);sb=!0}else if(jQuery(q).parents("#inv").length){if(m=
document.querySelector("#inventory_nav .awesome-tabs.current"))m=m.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",m);k.ra={bag:q.getAttribute("data-container-number"),x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")};sb?alert("A repair process is already running."):(k.On(q),q=q.getAttribute("data-item-id"),k.pj(q),sb=!0)}else k.queue++,k.ap(q),k.Zm(n)}))}function c(h,l,q){l=jQuery("<button>").html(l).addClass(q);jQuery(h).append(l);return l}async function e(){try{const h=
await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});k.slots=JSON.parse(h).slots;k.spaces=k.slots.filter(l=>"closed"===l["forge_slots.state"]).length;k.freeSlots=k.slots.filter(l=>"closed"===l["forge_slots.state"])}catch(h){}}async function g(){try{const h=W("sh"),l=document.querySelectorAll("#inv .ui-draggable"),q=[512,256,2,8,4,1,1024,48];let n=5;ab("Sending items to packages...");await e();if(0<k.spaces){for(let m of k.slots)if("closed"===
m["forge_slots.state"]){n=m["forge_slots.slot"];break}for(let m of l){const r=parseInt(m.getAttribute("data-content-type"),10);if(q.includes(r)){const w=m.getAttribute("data-item-id"),v=Gb(m),x=parseInt(m.getAttribute("data-amount"),10)||1,C={mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:n,iid:w,amount:x,a:Date.now(),sh:h};await jQuery.post(T({}),C);const E={mod:"forge",submod:"rent",mode:"workbench",slot:n,rent:2,item:w,a:Date.now(),sh:h};await jQuery.post(T({}),E);const A={mod:"forge",
submod:"cancel",mode:"workbench",slot:n,a:Date.now(),sh:h};await jQuery.post(T({}),A);ab(`Item name : ${v} has been sent to the packages.`);await new Promise(t=>setTimeout(t,500))}}window.location.reload()}else ab("No available slots in the workbench.")}catch(h){}}const k={Jn:"full",async start(){let {itemList1:h,itemList2:l,repairArena:q,repairTurma:n}=aa.workbench,m=aa.workbench.selectedItem;m?this.u(()=>{switch(m.status){case "toWorkbench":k.pj(m.iid);break;case "toFillGoods":k.kc(m.slot);break;
case "toPackage":k.dd(m.slot);break;case "toBag":k.Ia();break;case "toInv":k.gm()}}):q&&0<h.length?"mod=overview&doll=1"!=mf?Hf("mod=overview&doll=1"):this.u(()=>{0<k.spaces&&this.um(aa.workbench.itemList1)}):n&&0<l.length&&("mod=overview&doll=2"!=mf?Hf("mod=overview&doll=2"):this.u(()=>{0<k.spaces&&this.um(aa.workbench.itemList2)}))},u(h=!1){jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")},l=>{k.slots=JSON.parse(l).slots;k.spaces=0;k.freeSlots=
[];for(let q of k.slots)"closed"==q["forge_slots.state"]&&(k.spaces++,k.freeSlots.push(q));h&&h()})},um(h){let l=h.shift();ac(l.yn,l.zn,(q,n)=>{jQuery.post(T({mod:"inventory",submod:"move",from:l.container,fromX:1,fromY:1,to:n,toX:q.x+1,toY:q.y+1,amount:1,doll:l.doll}),{a:(new Date).getTime(),sh:W("sh")},m=>{let r={item:l,iid:JSON.parse(m).to.data.itemId,status:"toWorkbench",spot:q,bag:n};localStorage.setItem("workbench_selectedItem",JSON.stringify(r));this.pj(JSON.parse(m).to.data.itemId)})})},async Um(h,
l=0,q){var n=[512,513,514,515];if(!(l>=n.length)){n=n[l];var m=document.getElementById("inv");if(m=Jc(m,h))try{const w=await jQuery.post(T({mod:"inventory",submod:"move",from:h.getAttribute("data-container-number"),fromX:1,fromY:1,to:n,toX:m.x+1,toY:m.y+1,amount:1,doll:q}),{a:(new Date).getTime(),sh:W("sh")}),v=JSON.parse(w);if(v.error)this.Um(h,l+1,q);else{var r={item:h,iid:v.to.data.itemId,status:"toWorkbench",spot:m,bag:n};localStorage.setItem("workbench_selectedItem",JSON.stringify(r));localStorage.setItem("workbench_itemBag",
JSON.stringify(r.bag));await this.pj(v.to.data.itemId)}}catch(w){}else this.Um(h,l+1)}},async pj(h){mj();D(`${d.Ab}`);let l=5;for(let q of k.slots)"closed"==q["forge_slots.state"]&&(l=q["forge_slots.slot"]);jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:l,iid:h,amount:1,a:(new Date).getTime(),sh:W("sh")},q=>{k.needed=JSON.parse(q).slots[l].formula.needed;Fh().gold>JSON.parse(q).slots[l].formula.rent[2]?jQuery.post(T({}),{mod:"forge",submod:"rent",mode:"workbench",
slot:l,rent:2,item:h,a:(new Date).getTime(),sh:W("sh")},()=>{"full"==k.Jn?(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:l,status:"toFillGoods"})),k.kc(l)):(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:l,status:"toFillPartial"})),k.bj(l))}):(D("Not enough gold to rent the workbench"),ab("Not enough gold to rent the workbench"))})},kc(h,l=-1,q=!0){D(`${d.Qf}`,l);jQuery.post(T({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:h,quality:l,a:(new Date).getTime(),
sh:W("sh")},()=>{l<Number(localStorage.getItem("repairMaxQuality"))?k.kc(h,++l,q):jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")},()=>{q?(localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"})),k.u(()=>{k.dd(h)})):(k.queue--,0==k.queue&&window.location.reload())})})},dd(h){let l=1E3*k.slots[h].formula.duration||1E4;D(`${d.bg}`,l);1==k.cancel?this.u(()=>{setTimeout(()=>{jQuery.post(T({}),{mod:"forge",submod:"cancel",
mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")},q=>{if("document.location.href=document.location.href;"==q)return window.location.reload();localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));k.Ia()})},l)}):this.u(()=>{setTimeout(()=>{jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")},q=>{if("document.location.href=document.location.href;"==q)return window.location.reload();localStorage.setItem("workbench_selectedItem",
JSON.stringify({status:"toBag"}));k.Ia()})},l)})},async Ia(h=1){var l=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");({item:l}=l);let q=!1;var n=new URL(window.location.href),m=n.origin;n=n.searchParams.get("sh")||"";m=new URL(`${m}/game/index.php?mod=packages&qry=&f=${l.type}&page=${h}&sh=${n}`);m.searchParams.set("mod","packages");m.searchParams.set("f",l.type);m.searchParams.set("page",h);m.searchParams.set("sh",n);m=await (await fetch(m.href)).text();
m=(new DOMParser).parseFromString(m,"text/html");var r=m.querySelector(".ui-draggable");n=Ca(r);Ba(r);r=Gb(r);l.name==r&&l.type==n&&(q=!0,jQuery.post(T({mod:"inventory",submod:"move",from:m.querySelector("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:k.ra.bag,toX:k.ra.x,toY:k.ra.y,amount:1}),{a:(new Date).getTime(),sh:W("sh")},()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));k.gm()}));q||this.Ia(++h)},gm(){JSON.parse(localStorage.getItem("workbench_selectedItem"));
var h=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");({item:h}=h);jQuery.post(T({mod:"inventory",submod:"move",from:k.ra.bag,fromX:k.ra.x,fromY:k.ra.y,to:h.container,toX:1,toY:1,amount:1,doll:h.doll}),{a:(new Date).getTime(),sh:W("sh")},()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));D(`${d.Tf}`);sb=!1;window.location.reload()})},En(h){h=jQuery(h);h=jQuery("<div>").addClass("gbot-overlay").width(h.width()).height(h.height()).offset(h.offset()).append(jQuery('<div class="gbot-spinner"></div>'));
jQuery(document.body).append(h)},Cm(h,l,q){l=jQuery("<button>").html(l).addClass(q);jQuery(h).append(l);return l},Eq(){let h=0;for(let l of k.slots)"finished-succeeded"==l["forge_slots.state"]&&(h++,jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:l["forge_slots.slot"],a:(new Date).getTime(),sh:W("sh")},q=>{h--;if("document.location.href=document.location.href;"==q||0==h)return window.location.reload()}))},ap(h){Yb(h)&&(k.En(h),k.In.push(h))},On(h){Yb(h)&&k.En(h)},Zm(h,l,q){let n=
k.freeSlots.shift()["forge_slots.slot"],m=k.In.shift(),r=null!==l?l:m.getAttribute("data-item-id"),w=null!==q?q:{bag:m.getAttribute("data-container-number"),x:m.getAttribute("data-position-x"),y:m.getAttribute("data-position-y")};jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:n,iid:r,amount:1,a:(new Date).getTime(),sh:W("sh")},v=>{let x=JSON.parse(v).slots[n].formula.needed;Fh().gold>JSON.parse(v).slots[n].formula.rent[2]&&jQuery.post(T({}),{mod:"forge",submod:"rent",
mode:"workbench",slot:n,rent:2,item:r,a:(new Date).getTime(),sh:W("sh")},()=>{"full"==h?k.kc(n,w,!0):"partial"==h&&k.bj(n,w,x)})})},bj(h,l,q){let n=[];q=k.needed;for(let m in q){const r=parseInt(m,10);0<q[m].amount&&!storedMaterials.some(w=>parseInt(w,10)+18E3===r)&&n.push({type:r,amount:q[m].amount})}k.Il(n,(m,r)=>{m&&r?k.Jl(l,m,r,w=>{w||console.warn("pickMaterialFromPack did not return an iid. Skipping material picking.");jQuery.post(T({}),{mod:"forge",submod:"toWarehouse",mode:"workbench",slot:h,
iid:w||"defaultIid",amount:1,a:(new Date).getTime(),sh:W("sh")},()=>{jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:h,a:(new Date).getTime(),sh:W("sh")},()=>{k.queue--;localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"}));k.u(()=>{k.dd(h)});0==k.queue&&window.location.reload()})})}):(k.cancel=!0,k.u(()=>{k.dd(h)}))})},Il(h,l=!1,q=0,n=-1){if(q==h.length)if(1>n)q=0,n++;else return l&&l(null,null);jQuery.post(T({mod:"forge",submod:"storageOut"}),{type:h[q],
quality:n,amount:1,a:(new Date).getTime(),sh:W("sh")}).done(()=>l&&l(h[q],n)).fail(()=>k.Il(h,l,++q,n))},Jl(h,l,q,n=!1,m=1){let r=!1;jQuery.get(F({mod:"packages",f:18,fq:q,qry:"",page:1,sh:W("sh")}),w=>{jQuery(w).find(".packageItem").each((v,x)=>{var C=jQuery(x).find(".ui-draggable");v=C.context.querySelector("input").getAttribute("value");x=Ea(C[0]).split("-")[1];C=Ba(C[0]);l==x&&q==C&&(r=!0,jQuery.post(T({mod:"inventory",submod:"move",from:"-"+v,fromX:1,fromY:1,to:k.ra.bag,toX:k.ra.x,toY:k.ra.y,
amount:1}),{a:(new Date).getTime(),sh:W("sh")},E=>{n&&n(JSON.parse(E).to.data.itemId)}))});r||k.Jl(h,l,q,n,++m)})}};jQuery("#inv").after('\n              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n    \n                <fieldset id="gladbot-workbench" style="\n                  padding: 10px;\n                  margin: 10px 20px;\n                  text-align: center;\n                  display: flex;\n                  flex-direction: row;\n                  flex-wrap: wrap;\n                  align-items: center;\n                  justify-content: space-around;\n                  border: 2px solid darkred;\n                  border-radius: 8px;\n                  width: 235px;">\n                  <legend style="\n                    padding: 0 10px;\n                    color: darkred;\n                    font-weight: bold;">GLDbot Workbench Area</legend>\n                    <span class="span-new">Make sure last workbench slot is available, and make sure there\'s 3x3 space available. *Full repair uses any kind of material!!!* Install Crazy-Addon to see equipment panel.</span>\n                </fieldset>');
c("#gladbot-workbench",'<i class="fa fa-wrench"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for full repair. You can only repair one item at a time.").mouseup(h=>{b(h,"full")});c("#gladbot-workbench",'<i class="fa fa-hammer"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for partial repair. You can only repair one item at a time.").mouseup(h=>{b(h,"partial")});c("#gladbot-workbench",'<i class="fa fa-undo"></i>',
"gladbot-button gladbot-worbench-button-reset gladbot-stylish-button").attr("title","If an item is stuck and not repairing, click this button to reset.").mouseup(()=>{sb=!1});c("#gladbot-workbench","Send items in the current inventory to packages","gladbot-button gladbot-inventory-send-button gladbot-stylish-button").attr("title","Click this button to send items from the current inventory to packages.").mouseup(async()=>{await g()})}function ab(b){const c=document.createElement("div");c.className=
"notification-popup";c.innerText=b;c.style.position="fixed";c.style.bottom="20px";c.style.right="20px";c.style.padding="10px 20px";c.style.backgroundColor="rgba(0, 0, 0, 0.8)";c.style.color="white";c.style.borderRadius="5px";c.style.fontSize="14px";c.style.zIndex="9999";document.body.appendChild(c);setTimeout(()=>{c.remove()},3E3)}function gh(b,c,e,g,k,h){const l=document.createElement("span");l.className=c;l.innerHTML=b;l.title=h;l.style.cursor=e;l.style.fontSize=g;l.style.top="70px";l.style.position=
"absolute";l.style.right=k;return l}function hh(b,c){try{var e=JSON.parse(b.replace(/&quot;/g,'"'))}catch(q){return{}}b=e[0]?e[0][0]:null;e=e[0]?e[0][0][0]:null;var g=b[0];g="string"!==typeof g?"":g.split(" ")[0];const k=$b(b[0]),h=c.getAttribute("data-quality"),l=c.getAttribute("data-content-type");c=c.getAttribute("data-level");return{itemName:b,wn:g,xn:k,itemColor:{"-1":"white",0:"green",1:"blue",2:"purple",3:"orange",4:"red"}[h]||"white",itemType:l,itemLevel:c,qn:e}}async function mj(){const b=
F({mod:"packages",submod:"sort",page:"1",sh:W("sh")});return await jQuery.post(b,{packageSorting:"in_desc"})}async function nj(){var b=localStorage.getItem("PackageSort")||"in_desc",c=await ja.rm();let e=[];var g=Math.min(10,c);if("del_asc"===b||"in_asc"===b)for(c=1;c<=g;c++)e.push(c);else for(b=c;b>c-g;b--)e.push(b);g=[];for(const k of e)try{const h=await jQuery.get(F({mod:"packages",f:"0",fq:"-1",qry:"",page:k.toString(),sh:W("sh")}));g.push(h)}catch(h){D(`Error fetching pages ${k}: ${h.message}`)}return g.flat()}
async function oj(b,c){if("mod=guildMarket"!=mf)Hf("mod=guildMarket");else{D(`${d.zf}`);var e={TOOLS:["2097152","1048576","8388608","4194304"],WEAPONS:["2"],SHIELD:["4"],CHEST:["8"],HELMET:["1"],GLOVES:["256"],SHOES:["512"],RINGS:["48"],AMULETS:["1024"],USABLES:["4096","32768"],FOOD:["64"],UPGRADES:["4096"],RECIPES:["8192"],MERCENARY:["16384"],SCROLLS:["64"],REINFORCEMENTS:["4096"]},g=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]},k="true"===localStorage.getItem("resetUnderworld"),h=
(await nj()).map(x=>jQuery(x).find(".packageItem").toArray()).flat();b=24*b;var l=!1;for(const x of h){h=x.querySelector("span[data-ticker-type]");if(!h)continue;h=h.getAttribute("data-ticker-time-left");if(!h)continue;h=h/1E3/60/60;var q=x.querySelector("div[data-content-type]");const C=q?q.getAttribute("data-content-type"):null;q=(q=x.querySelector(".ui-draggable"))?q.getAttribute("data-basis"):null;if(("64"!==C||!q||c.includes("SCROLLS")&&q.startsWith("20")||c.includes("FOOD")&&q.startsWith("7")||
c.includes("REINFORCEMENTS")&&q.startsWith("11"))&&h<=b&&(c.some(E=>e[E].includes(C))||k)){q=x.querySelector("div[data-container-number]");var n=void 0,m=void 0;h=(m=x.querySelector("div[data-amount]"))?m.getAttribute("data-amount"):null;var r=m?m.getAttribute("data-quality"):null;k&&(n=m?m.getAttribute("data-basis"):null,m=m?m.getAttribute("data-hash"):null,n=wb(n,m));if(!k||n)if(!(null!==r&&0<g.colors.length)||g.colors.includes(r)){q=q?q.getAttribute("data-container-number"):null;r=x.querySelector("div[data-measurement-x]").getAttribute("data-measurement-x");
m=x.querySelector("div[data-measurement-y]").getAttribute("data-measurement-y");l=x.querySelector("div[data-tooltip]").getAttribute("data-tooltip");var w=$e(l);l=!0;await new Promise(E=>setTimeout(E,200));await pj(x,q,w,h,r,m);h=W("sh");h=`${window.location.origin}/game/index.php?mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=p&p=1&&sh=${h}`;q=await (await fetch(h)).text();q=(new DOMParser).parseFromString(q,"text/html").querySelectorAll("#market_table tr");if((r=document.querySelector('input[type="submit"][name="anbieten"][value="Offer"]'))&&
r.disabled)h=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",h.ResetExpired||10),D(`${d.Hf}`);else for(r=1;r<q.length;r++){var v=q[r];m=v.querySelectorAll("td")[2];w=v.querySelector('input[name="cancel"]');v=(v=v.querySelector("div[data-item-id]"))?v.getAttribute("data-item-id"):null;w&&Number(m.textContent.replace(/\./g,""))===Number(ih)&&(await fetch(h,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({buyid:v,qry:"",seller:"",f:0,fl:0,
fq:-1,s:"",p:1,cancel:"Cancel"})}),D(`${d.Af}`),ka("itemReset",0))}}}}if(!l||l)c=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",c.ResetExpired||10),window.location.reload()}}async function pj(b,c,e,g,k,h){let {spot:l,bag:q}=await ac(k,h);try{const n=await jQuery.post(T({mod:"inventory",submod:"move",from:c,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+1,amount:g}),{a:(new Date).getTime(),sh:W("sh")});if(n){const m=Math.floor(41*Math.random())+10;ih=m;const r=JSON.parse(n).to.data.itemId;await qj(c,
m,r)}}catch(n){D(`${d.Bf}`),b=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",b.ResetExpired||10),window.location.reload()}}async function qj(b,c,e){await jQuery.post(F({mod:"guildMarket",sh:W("sh")}),{sellid:e,preis:c,dauer:1,sell_mode:0,anbieten:"Offer"})}async function rj(){if(!1!==JSON.parse(localStorage.getItem("underworld")||"{}").isUnderworld||"true"!==localStorage.getItem("BuffUnderworldOnly")){"mod=overview&doll=1"!=mf&&Hf("mod=overview&doll=1");var b={"11-23":{type:"Health",
item:"Gingko"},"11-22":{type:"Health",item:"Taigaroot"},"11-21":{type:"Health",item:"Hawthorn"},"11-1":{type:"Strength",item:"Flask"},"11-2":{type:"Strength",item:"Ampulla"},"11-3":{type:"Strength",item:"Flacon"},"11-4":{type:"Strength",item:"Bottle"},"11-13":{type:"Constitution",item:"Flask"},"11-14":{type:"Constitution",item:"Ampulla"},"11-15":{type:"Constitution",item:"Flacon"},"11-16":{type:"Constitution",item:"Bottle"},"11-9":{type:"Agility",item:"Flask"},"11-10":{type:"Agility",item:"Ampulla"},
"11-11":{type:"Agility",item:"Flacon"},"11-12":{type:"Agility",item:"Bottle"},"11-17":{type:"Charisma",item:"Flask"},"11-18":{type:"Charisma",item:"Ampulla"},"11-19":{type:"Charisma",item:"Flacon"},"11-20":{type:"Charisma",item:"Bottle"},"11-24":{type:"Intelligence",item:"Flask"},"11-25":{type:"Intelligence",item:"Ampulla"},"11-26":{type:"Intelligence",item:"Flacon"},"11-27":{type:"Intelligence",item:"Bottle"},"11-5":{type:"Dexterity",item:"Flask"},"11-6":{type:"Dexterity",item:"Ampulla"},"11-7":{type:"Dexterity",
item:"Flacon"},"11-8":{type:"Dexterity",item:"Bottle"}},c=JSON.parse(localStorage.getItem("buffs"))||{},e=JSON.parse(localStorage.getItem("Timers")),g=JSON.parse(localStorage.getItem("buffSelections"))||{};for(const h in g){var k=g[h];let l=null;if(0<k.length)for(let q of k)if(Object.entries(b).find(([,n])=>n.type===h&&n.item===q)&&!Object.keys(c).find(n=>n.includes(h)&&n.includes(q)&&0<c[n].timeLeft))try{let n=!1,m=null;for(k=1;3>=k;k++){const r=await jQuery.get(F({mod:"packages",f:11,fq:-1,qry:"",
page:k,sh:W("sh")}));jQuery(r).find(".packageItem").each(function(w,v){w=jQuery(v).find(".ui-draggable").attr("data-basis");if((w=b[w])&&w.type===h&&w.item===q){const x=w.item;l=x;if(Object.keys(c).some(C=>C.includes(h)&&C.includes(x)))return!0;n=!0;m=jQuery(v);return!1}});if(n)break}if(n&&m)try{await ac(1,1,async(r,w)=>{const v=m.find('input[name="packages[]"]').val(),x=m.find(".ui-draggable").attr("data-position-x"),C=m.find(".ui-draggable").attr("data-position-y");await new Promise(E=>setTimeout(E,
250));await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+v,fromX:x,fromY:C,to:w,toX:r.x+1,toY:r.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")}));D(`${h} buff (${q}) has been moved to the inventory.`);await new Promise(E=>setTimeout(E,250));await jQuery.post(T({mod:"inventory",submod:"move",from:w,fromX:r.x+1,fromY:r.y+1,to:8,toX:1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")}));c[`${h} - ${l}`]={timeLeft:m.find(".ticker").attr("data-ticker-time-left")/6E4};localStorage.setItem("buffs",
JSON.stringify(c))})}catch(r){Y("BuffCheck",e.BuffTimer||60),D(`Error moving or using ${h} buff (${q}):`,r)}else Y("BuffCheck",e.BuffTimer||60),D(`No ${h} buff found for ${q}.`)}catch(n){Y("BuffCheck",e.BuffTimer||60),D("Error fetching buffs from packages:",n)}}}}function sj(){const b=Date.now(),c=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),e=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),k=JSON.parse(localStorage.getItem("disabledTimeMercenary")||
"{}");Object.entries(e).forEach(([h,l])=>{3E5<b-l&&(c[h]=!0,delete e[h])});Object.entries(k).forEach(([h,l])=>{3E5<b-l&&(g[h]=!0,delete k[h])});localStorage.setItem("activeItemsGladiator",JSON.stringify(c));localStorage.setItem("disabledTimeGladiator",JSON.stringify(e));localStorage.setItem("activeItemsMercenary",JSON.stringify(g));localStorage.setItem("disabledTimeMercenary",JSON.stringify(k))}function tj(b){if(!b||"string"!==typeof b||!/\d/.test(b))return NaN;b=b.split(":").map(c=>parseInt(c,10));
if(3===b.length){const [c,e,g]=b;return 1E3*(3600*c+60*e+g)}if(2===b.length){const [c,e]=b;return 1E3*(60*c+e)}return NaN}function jh(){let b=document.getElementById("nextActionWindow");if(!b){b=document.createElement("div");b.id="nextActionWindow";b.setAttribute("style",'\n            display: flex;\n            align-items: center;\n            justify-content: center;\n            position: absolute;\n            top: -3px;\n            left: 50%;\n            transform: translateX(-50%);\n            height: 50px;\n            width: 190px;\n            background: linear-gradient(\n              180deg,\n              #c4ac70 0%, \n              #e5d7a2 100%  \n            );\n            border: 2px solid #8b6b0b;\n            border-radius: 6px;\n            color: #2b2b2b;\n            font-family: "Georgia", "Times New Roman", serif; \n            font-size: 11px;\n            line-height: 1.2;\n            text-align: center;\n            z-index: 1999;\n          ');
const c=document.getElementById("header_game");c&&c.insertBefore(b,c.children[0])}return b}function kh(){var b=[];for(var c of uj)if(c.enabled){var e=Infinity;if(c.kl){var g=document.querySelector(c.kl);g&&(e=tj(g.innerText),e=isNaN(e)?0:e)}else if(g=localStorage.getItem("eventPoints.timeOut"))e=Number(g)-Date.now(),e=0<e?e:0;b.push({...c,timeLeft:e})}c=null;for(var k of b)if(!c||k.timeLeft<c.timeLeft)c=k;c?(Ka.N=c,Ka.vm=c.timeLeft,0>=c.timeLeft&&c.hm()&&c.km()&&console.debug(`[AutoClick] Performed action: ${c.name}`)):
(Ka.N=null,Ka.vm=0);Ka.jm||(Ka.jm=jh());!Ka.N||isNaN(Ka.vm)?Ka.jm.innerHTML="\n        <span>Please select an action. [Exp|Dungeon|Arena|Circus]</span>":(b=Ka.vm,!b||1E3>b?b="0:00:00":(b=Math.round(b/1E3),k=b%60,c=Math.floor(b%3600/60),b=`${Math.floor(b/3600)}:${10>c?"0"+c:c}:${10>k?"0"+k:k}`),Ka.jm.innerHTML=`
        <div style="text-align: center;">
          <div style="color: black; margin-bottom: 5px;">${d.N} ${d[Ka.N.name]||"Unknown Action"}</div>
          <div style="color: black; margin-bottom: 2px;">${d.nj}: ${b}</div>
        </div>
      `)}function af(){let z4=localStorage.getItem("we");we=new Date(z4);if(aa?.player?.Fd<new Date||we<new Date)throw gb(),Error("SupportDevs");Ka.jm=jh();kh();setInterval(kh,1E3)}const Ka={N:null,vm:0,jm:null};(function(){if("true"===localStorage.getItem("disableBG")){var b=document.getElementById("wrapper_game");b&&(b.style.backgroundImage="none",b.style.backgroundColor="black")}let c=setTimeout(()=>{chrome.runtime.sendMessage({wq:!0})},1E4);window.onload=function(){clearTimeout(c);chrome.runtime.sendMessage({xq:!0})};let e=!1;document.addEventListener("touchstart",
function(g){function k(l){setTimeout(function(){var q=new MouseEvent("click",{bubbles:!0,cancelable:!0,view:window});l.dispatchEvent(q)},150)}var h=g.target;try{if("AuctionaddPrefixButton"==h.id||"AuctionaddSuffixButton"==h.id||"Strength"==h.htmlFor||"Dexterity"==h.htmlFor||"Agility"==h.htmlFor||"Constitution"==h.htmlFor||"Charisma"==h.htmlFor||"Intelligence"==h.htmlFor||"costumes_button_left"===h.offsetParent.id||"costumes_button_right"===h.offsetParent.id||"buy_rubies_link"===h.offsetParent.id||
"footer_inner"===h.offsetParent.id||"footer_logos"===h.offsetParent.id||"content"===h.id||"sidebar"===h.id||"char"===h.id||"a.menuitem.advanced_menu_link"==h.className||"a.menuitem.advanced_menu_link active"==h.className||"a.menuitem.advanced_menu_link active"==h.className||"menuitem"==h.className||"menuitem "==h.className||"menuitem advanced_menu_link"==h.className||"menuitem active advanced_menu_link_active"==h.className||"set_dungeon_difficulty_normal"!=h.id&&"set_dungeon_difficulty_advanced"!=
h.id&&"set_event_monster_id_0"!=h.id&&"set_event_monster_id_1"!=h.id&&"set_event_monster_id_2"!=h.id&&"set_event_monster_id_3"!=h.id&&"do_combat_quests"!=h.id&&"do_arena_quests"!=h.id&&"do_circus_quests"!=h.id&&"do_expedition_quests"!=h.id&&"do_dungeon_quests"!=h.id&&"do_items_quests"!=h.id&&"ConstitutionPriority"!=h.id&&"CharismaPriority"!=h.id&&"IntelligencePriority"!=h.id&&"StrengthPriority"!=h.id&&"DexterityPriority"!=h.id&&"AgilityPriority"!=h.id&&"shoes-image"!=h.className&&"ring1-image"!=h.className&&
"ring2-image"!=h.className&&"helmet-image"!=h.className&&"necklace-image"!=h.className&&"sword-image"!=h.className&&"chest-image"!=h.className&&"shield-image"!=h.className&&"gloves-image"!=h.className&&("div"==h.localName&&"overlayBack"!==h.id||"div"==h.localName&&"licotok"!==h.id))return}catch{}e||"checkbox"===h.type&&"switch"===h.className||(e=!0,k(h),"submit"!==h.type&&"checkbox"!==h.type&&"switch"!==h.className||g.preventDefault());e=!1},{passive:!1});try{chrome&&chrome.runtime&&chrome.runtime.sendMessage&&
"true"===sessionStorage.getItem("autoGoActive")&&(chrome.runtime.sendMessage({Gn:!0,Em:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"}),chrome.runtime.sendMessage({keepAlive:!0},()=>{}));let g=localStorage.getItem("activeItemsMercenary"),k=localStorage.getItem("activeItemsGladiator");null!==g&&g!==JSON.stringify([])||localStorage.setItem("activeItemsMercenary",JSON.stringify({}));null!==k&&k!==JSON.stringify([])||localStorage.setItem("activeItemsGladiator",JSON.stringify({}));
chrome.runtime.onMessage.addListener(h=>{h.Gn&&h.Em&&"true"===sessionStorage.getItem("autoGoActive")&&(h=new Audio(h.Em),h.loop=!0,h.volume=0,h.play().catch(()=>{}))})}catch{console.log("Could not play the audio")}(b=JSON.parse(localStorage.getItem("timeConditions"))||[],1>b.length)&&!window.location.href.includes("/index.php?mod=hermit&submod=travel")&&!window.location.href.includes("/index.php?mod=packages")&&!window.location.href.includes("/index.php?mod=forge")?setTimeout(function(){window.location.reload()},
36E4):window.location.href.includes("/index.php?mod=hermit&submod=travel")||window.location.href.includes("/index.php?mod=packages")||window.location.href.includes("/index.php?mod=forge")?setTimeout(function(){window.location.reload()},6E5):setTimeout(function(){window.location.reload()},18E4)})();const vj={start(){const b=async()=>{const g=nb("gf-token-production");console.log("GF Token:",g);return g?{"Content-Type":"application/json",headers:{Fp:`Bearer ${g}`}}:{}},c=async()=>{try{chrome.runtime.sendMessage({queryButtonClickedState:!0},
async g=>{if(!g.state){g=(g=document.cookie.split("; ").find(n=>n.startsWith("gllastusername=")))?g.split("=")[1]:null;let l=null,q=null;g&&([l,q]=g.split("-"));g=[];try{var k=await (await fetch("/api/users/me/accounts",await b())).json();g=Array.isArray(k)?k:[]}catch(n){}g=g.sort((n,m)=>new Date(m.Qo)-new Date(n.Qo));k=null;l&&q&&(k=g.find(n=>n.name===l&&String(n.id)===q));!k&&0<g.length&&(k=g[0]);if(k){if(g=document.getElementById("accountlist")){g=g.getElementsByClassName("rt-tr");for(var h of g){g=
h.querySelector(".player-cell");const n=h.querySelector(".btn.btn-primary");if(g&&n&&g.textContent.trim()===k.name){n.click();sessionStorage.setItem("loggedIn","true");return}}}}else if(h=document.getElementById("accountlist"))if(h=h.getElementsByClassName("btn btn-primary"),h[0]){h[0].click();sessionStorage.setItem("loggedIn","true");return}sessionStorage.setItem("loggedIn","false")}})}catch(g){sessionStorage.setItem("loggedIn","false")}},e=async()=>{chrome.runtime.sendMessage({action:"ctab"},g=>
{if(!g||!g.gr){g=document.querySelectorAll(".registerForm");if(0<document.querySelectorAll(".loginRegister").length||0<g.length)return!1;window.location.href.includes("/accounts")?c():window.location.href="https://lobby.gladiatus.gameforge.com/en_GB/accounts"}})};(()=>{if(!window.location.href.includes("game/index.php")){const g=document.cookie.split("; ").find(h=>h.startsWith("glautologin=")),k=g?g.split("=")[1]:null;chrome.runtime.sendMessage({action:"ctab"},h=>{h.gr||window.location.href.includes("forum.gladiatus")||
!window.location.href.includes("lobby")||"true"!==k||setTimeout(e,3500)})}})();(()=>{var g=document.querySelectorAll('h1, h2, .error-code, h1[jstcache="0"], #main-frame-error');let k=!1;for(const h of g){g=h.textContent||"";if(g.includes("503")||g.includes("500")){k=!0;break}if("main-frame-error"===h.id||h.hasAttribute("jstcache")){k=!0;break}}k&&(console.warn("Error detected on page. Reloading..."),setTimeout(()=>{location.reload()},3E3))})()}};window.location.href.includes("index.php?mod=overview&submod=achievements")||
window.location.href.includes("index.php?mod=overview&submod=stats")||vj.start();const lh=localStorage.getItem("underworld"),Bb=lh?JSON.parse(lh):null,mh=document.querySelector('input[name="cancelTravel"]');try{document.querySelector("#header_LoginBonus")&&!mh&&Bb&&!window.location.href.includes("/index.php?mod=hermit")&&!1===Bb.isUnderworld&&document.querySelector("#linkLoginBonus").click()}catch{}let nh=document.getElementById("wrapper_game"),bf=nh&&"underworld"===nh.className;if(bf){const b=JSON.parse(localStorage.getItem("underworld")||
"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else{const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!1;localStorage.setItem("underworld",JSON.stringify(b))}try{if((window.location.href.includes("/index.php?mod=hermit&submod=travel")||mh||window.location.href.includes("/index.php?mod=hermit&submod=enterUnderworld"))&&"true"===sessionStorage.getItem("autoGoActive")&&"true"===localStorage.getItem("autoEnterHell")){const b=document.querySelector('span[data-ticker-type="countdown"]');
if(b){const c=parseInt(b.getAttribute("data-ticker-time-left"),10);await new Promise(e=>setTimeout(e,c-7E3||358E3))}else await new Promise(c=>setTimeout(c,3E5));Hf("mod=overview")}}catch(b){D(`Error in underworld wait: ${b.message}`)}let oh="true"===localStorage.getItem("nestSearchType");"nothing"!==localStorage.getItem("nestSearchType")&&(oh=!0);const wj=localStorage.getItem("NestDelay")||250;oh&&window.location.href.includes("/index.php?mod=reports")&&await new Promise(b=>setTimeout(b,wj));let cf=
!0;const bb=new URL(window.location.href);let ph=document.createElement("style");ph.innerHTML="\n    #logMenu {\n      resize: vertical;\n      overflow: auto;\n      max-height: 500px;\n    }\n  ";document.head.appendChild(ph);let rf=null,sf=0;null===localStorage.getItem("HealClothToggle")&&localStorage.setItem("HealClothToggle","false");window.location.href.includes("mod=auction")&&U();const na=JSON.parse(localStorage.getItem("userStats"))||{Rm:0,Sm:0,Pm:0,Dm:0,Gm:0,Jm:0,Lm:0,Tm:0,an:0,nm:0,om:0};
let fb;localStorage.getItem("playerId")&&Qh((localStorage.getItem("playerId")|0)%100|0);(function(){var b="true"===localStorage.getItem("MoveButtons");let c=document.createElement("button");c.className="menuitem breathing-light";c.innerHTML="GLDbot License";c.setAttribute("id","lico");c.addEventListener("click",Th);b?((b=document.getElementById("lico"))&&b.remove(),c.style.position="fixed",c.style.left="13px",c.style.bottom="60px",c.style.zIndex="1000",document.body.appendChild(c)):(b=document.getElementById("mainmenu"))&&
b.children[0]&&b.insertBefore(c,b.children[0]);c=document.createElement("style");c.innerHTML="\n        @keyframes breathing-light {\n            0%, 100% {\n                box-shadow: 0 0 11px 5px rgba(255, 255, 0, 0.7);\n            }\n            50% {\n                box-shadow: 0 0 11px 10px rgba(255, 255, 0, 0.5);\n            }\n        }\n    \n        .breathing-light {\n            animation: breathing-light 2s ease-in-out infinite;\n        }";document.head.appendChild(c)})();await async function(){var b="true"===localStorage.getItem("runNestDungeon");const c="true"===localStorage.getItem("runNestExpedition"),e="true"===localStorage.getItem("runNestEvent"),g="true"===localStorage.getItem("runNestUnderworld");var k=document.querySelector('span[data-ticker-type="countdown"]');if(window.location.href.includes("/index.php?mod=reports")&&!k||window.location.href.includes("/index.php?mod=guildMarket")&&
!k||window.location.href.includes("/index.php?mod=quests")&&!k){k=document.getElementById("blackoutDialog");var h=document.getElementById("blackoutDialognotification");const l=document.getElementById("blackoutDialogLoginBonus");if(null!==k&&"none"!==window.getComputedStyle(k).display){h=localStorage.getItem("nestSearchType");const q=document.querySelector("#blackoutDialog.loot-modal"),n="true"===sessionStorage.getItem("autoGoActive");if(h&&q&&n&&(G()&&b||N()&&e||M()&&c||(JSON.parse(localStorage.getItem("underworld"))||
{}).isUnderworld&&g||!(b||e||c||g))){b=null;b=k.querySelectorAll(".action_buttons button");switch(h){case "quick":D("Quick Search clicked");b=b[1];break;case "thorough":D("Thorough Search clicked");b=b[2];break;case "nothing":D("Return to Safety clicked");b=b[0];break;default:D("Thorough Search clicked"),b=b[2]}b&&b.click()}}else null!==l&&Bb&&!1===Bb.isUnderworld?setTimeout(()=>{l.getElementsByTagName("input")[0]?.click()},100):null!==h&&"none"!==window.getComputedStyle(h).display&&setTimeout(()=>
{const q=document.getElementById("breakDiv");q&&q.click()},100)}}();if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll")){var df=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),tb=df.textContent.trim();if(2<tb.length){var ef=document.getElementById("char");function b(e,g,k,h){if(null!==document.getElementById("container_start")){var l=window.location.href.split("p=")[1].split("&")[0],
q=window.location.href.match(/s(\d+)-\w\w/),n=window.location.href.match(/s\d+-(\w\w)/);g={playerName:g,aType:h,opponentId:l,serverId:q?q[1]:null,country:n?n[1]:null};k=2===h?"arenacrosslist":"circuscrosslist";var m=2===h?"removeArenaList":"removeCircusList";q=JSON.parse(nb(k)||"[]");var r=JSON.parse(nb(m)||"[]");n=q.findIndex(v=>v.opponentId===l);var w=r.findIndex(v=>v.opponentId===l);-1!==n?(q.splice(n,1),-1===w&&(r.push(g),mb(m,JSON.stringify(r),7)),e.classList.remove("added"),e.setAttribute("data-tooltip",
"Add to "+(2===h?"Arena":"Circus"))):(q.push(g),-1!==w&&(r.splice(w,1),mb(m,JSON.stringify(r),7)),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+(2===h?"Arena":"Circus")));mb(k,JSON.stringify(q),7)}else q=JSON.parse(localStorage.getItem(k))||[],n=q.indexOf(g),-1!==n?(q.splice(n,1),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(q.push(g),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+("autoAttackList"===
k?"Arena":"Circus"))),localStorage.setItem(k,JSON.stringify(q))}function c(e,g,k,h,l){var q=document.createElement("a");q.className="gladbot-button gladbot-"+e;q.textContent=g;q.setAttribute("data-tooltip",k);ef.appendChild(q);(JSON.parse(localStorage.getItem(h))||[]).includes(tb)&&(q.classList.add("added"),q.setAttribute("data-tooltip","Remove from "+("autoAttackList"===h?"Arena":"Circus")));q.addEventListener("click",function(){b(q,tb,h,l)})}c("arena","A","GladB: Add to Arena List","autoAttackList",
2);c("circus","C","GladB: Add to Circus List","autoAttackCircusList",3)}}const xj=localStorage.getItem("Username"),xa=localStorage.getItem("pid"),idkps=localStorage.getItem("idkps");let yj=localStorage.getItem("tkz_lcr");const zj=localStorage.getItem("tkn"),ec=await ta(yj,zj,xa,xj);window.location.href.includes("/index.php?mod")&&sessionStorage.setItem("loggedIn","false");if(window.location.href.includes("/index.php?mod=overview")){const b=[3,4,5,2,9,10,6,7,11],c=[1,2,4,8,48,256,512,1024];Uh();(function(){const k={dbfa266e60c28ce109de4d9c216a2a:"Health - Gingko Leaves",
"25925f7ce7c04483a3b4527846c04b":"Health - Taigaroot","79e62e1e04445d354bcc955bb8baeb":"Health - Hawthorn","93820f465cb02d5d8828ee9a14f5fe":"Charisma - Flask",b5e7e6f2cd2ea3d86143894e5f9ade:"Charisma - Flacon",ddd6bc43a13d444409087b99b9f142:"Charisma - Ampulla","37fc8feb4ead7f2e59c026af4228b3":"Charisma - Bottle","00ef972a002dc3040447e5cc0eb77d":"Dexterity - Ampulla","43ac2597d30a099dd7033273ac29c1":"Dexterity - Flask","352a093dc497a9ec659f217dc7d374":"Dexterity - Flacon","967321edb226ea075ac63acc701eea":"Dexterity - Bottle",
bd48bef94e6d066a8bfef716dd959a:"Constitution - Ampulla",ce03a66b17f81394722a3fc2335a1d:"Constitution - Flacon",ee80ae69b48ebbeb81e52c20113709:"Constitution - Flask","5368deb7929c8853843b420fb439ac":"Constitution - Bottle",b306d3f65b14cb91c0f0c9de871e0a:"Strength - Flask","2e8f9fc0f9b101f7ba49152cbe9779":"Strength - Flacon",ce6fe5171b946cd26d5b21e87efb5d:"Strength - Ampulla","1c344cf484e5a87731eaf906ffd993":"Strength - Bottle","887d1152e2f7cba339a0a4675b3b5e":"Agility - Flask","453199ebfb25d62f83af27b0187088":"Agility - Ampulla",
"3b52078b78637bd54fed2e4cfb951b":"Agility - Flacon",d2df53b4e64ad33dc301b6bf125fd2:"Agility - Bottle",a2ef931eff7cce75e07baa9ae2ac97:"Intelligence - Flacon","48331278d1b0391f74ba54b4cac6d4":"Intelligence - Ampulla","2bf8795edae428b4646f8d6fd6dc4c":"Intelligence - Flask","8971734256abbbe0fea2bb40721953":"Intelligence - Bottle"},h=document.querySelectorAll("#buffbar_old .buff_inner");let l=JSON.parse(localStorage.getItem("buffs"))||{},q=new Set;h.forEach(n=>{var m=n.querySelector("img");m=(m=m?m.getAttribute("src"):
null)?m.split("/").pop().split(".")[0]:null;if(m=k[m])if(n=(n=n.parentElement.querySelector(".ticker"))?n.getAttribute("data-ticker-time-left"):null)l[m]={timeLeft:Math.round(Number(n)/6E4)},q.add(m)});Object.keys(l).forEach(n=>{q.has(n)||delete l[n]});localStorage.setItem("buffs",JSON.stringify(l))})();const e=document.getElementById("char");if(e){const k=document.createElement("button"),h=document.createElement("span");k.textContent="\u21d3";k.className="put-down awesome-button";k.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 170px; font-size: 12px; cursor: pointer;";
k.classList.add("tooltip");k.appendChild(h);k.onclick=async function(){let n=Array.from(document.querySelectorAll("#char .ui-droppable")).filter(m=>b.includes(parseInt(m.dataset.containerNumber,10)||"0"));for(let m=0;m<n.length;m++)await new Promise(r=>setTimeout(r,100)),ea(n[m],"inv");await new Promise(m=>setTimeout(m,500))};e.appendChild(k);const l=document.createElement("button"),q=document.createElement("span");l.textContent="\u21d1";l.className="put-up awesome-button";l.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 192px; font-size: 12px; cursor: pointer;";
l.classList.add("tooltip");l.appendChild(q);l.onclick=async function(){let n=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(m=>c.includes(parseInt(m.dataset.contentType,10)));for(let m=0;m<n.length;m++)await new Promise(r=>setTimeout(r,100)),ea(n[m],"char");await new Promise(m=>setTimeout(m,500))};e.appendChild(l)}if(document.getElementById("inv")){async function k(n,m,r,w,v,x){await jQuery.post(T({mod:"inventory",submod:"move",from:x,fromX:m+1,fromY:r+1,to:x,toX:w+1,toY:v+1,amount:n.dataset.amount||
1,doll:1,a:(new Date).getTime(),sh:W("sh")}))}const h=document.createElement("button");h.id="sort-button";h.textContent="Sort Inventory";h.className="sort-button awesome-button";h.style="padding: 5px; margin: 5px; cursor: pointer;";const l=document.createElement("span");l.id="loading-indicator";l.style="margin-left: 10px; display: none;";const q=document.querySelector(".contentItem");q&&(q.insertAdjacentElement("afterend",h),h.insertAdjacentElement("afterend",l));h.addEventListener("click",async function(){function n(A,
t,u){for(let z=0;5>z;z++)for(let B=0;8>B;B++)if(!v[z][B]){let J=!0;for(let I=z;I<z+t&&J;I++)for(let K=B;K<B+A;K++)if(5<=I||8<=K||v[I][K])J=!1;if(J){if(u){A=[{x:B-1,y:z},{x:B+A,y:z},{x:B,y:z-1},{x:B,y:z+t}];for(const I of A)if(0<=I.x&&8>I.x&&0<=I.y&&5>I.y&&w.find(K=>{const L=parseInt(K.style.top,10)/32;return parseInt(K.style.left,10)/32===I.x&&L===I.y&&K.dataset.basis.split("-")[0]===u}))break}return{x:B,y:z}}}return null}var m=document.getElementById("inv");document.getElementById("sort-button");
var r=document.getElementById("loading-indicator");r.textContent="Sorting...";r.style.display="inline-block";const w=Array.from(m.getElementsByClassName("ui-draggable"));w.sort((A,t)=>{const u=parseInt(A.dataset.basis.split("-")[0],10)||0,z=parseInt(t.dataset.basis.split("-")[0],10)||0;return u!==z?u-z:(parseInt(A.dataset.measurementX,10)*parseInt(A.dataset.measurementY,10)||1)-(parseInt(t.dataset.measurementX,10)*parseInt(t.dataset.measurementY,10)||1)});const v=Array.from({length:5},()=>Array(8).fill(!1));
w.forEach(A=>{const t=parseInt(A.style.left,10)/32,u=parseInt(A.style.top,10)/32,z=parseInt(A.dataset.measurementX,10);A=parseInt(A.dataset.measurementY,10);for(let B=u;B<u+A;B++)for(let J=t;J<t+z;J++)v[B][J]=!0});for(m=0;m<w.length;m++){var x=w[m];r=parseInt(x.dataset.measurementX,10);const A=parseInt(x.dataset.measurementY,10);var C=x.dataset.basis.split("-")[0];const t=parseInt(x.style.left,10)/32,u=parseInt(x.style.top,10)/32;var E=n(r,A,C);if(E&&(C=E.x,E=E.y,t!==C||u!==E)){await k(x,t,u,C,E,
x.dataset.containerNumber);for(x=E;x<E+A;x++)for(let z=C;z<C+r;z++)v[x][z]=!0;for(C=u;C<u+A;C++)for(x=t;x<t+r;x++)v[C][x]=!1}}window.location.reload()})}const g=JSON.parse(localStorage.getItem("underworld"))||{};try{const k=document.querySelector("#avatar .ui-droppable");if(k){const h=k.getAttribute("data-tooltip");h&&h.toLowerCase().includes("pater")?(g.oj=!0,localStorage.setItem("underworld",JSON.stringify(g)),Y("CheckDolls",15)):(g.oj=!1,localStorage.setItem("underworld",JSON.stringify(g)))}}catch{}}let Lc=
localStorage.getItem("playerId");dc();let sb=!1,va="true"===sessionStorage.getItem("autoGoActive")?!0:!1,ba;try{ba={level:parseInt(document.getElementById("header_values_level").innerText,10)||50,o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,""))}}catch(b){ba={level:50}}const cb=document.createElement("div");cb.style.position="fixed";cb.style.right="10px";cb.style.top="50px";cb.style.zIndex="99999";document.body.appendChild(cb);
const ra=document.createElement("div");ra.id="logMenu";ra.style.width="190px";ra.style.height="210px";ra.style.overflowY="hidden";ra.style.backgroundColor="rgba(221, 213, 180, 0.8)";ra.style.border="1px solid #c4ac70";ra.style.borderRadius="10px";ra.style.fontFamily="Arial, sans-serif";ra.style.color="#333";cb.appendChild(ra);const db=document.createElement("h2");db.textContent="Log Menu";db.style.backgroundColor="rgba(196, 172, 112, 0.8)";db.style.color="#333";db.style.margin="0";db.style.padding=
"10px 20px";db.style.borderTopLeftRadius="10px";db.style.borderTopRightRadius="10px";ra.appendChild(db);const Cb=document.createElement("div");Cb.id="logEntriesContainer";Cb.style.color="#bfae54";Cb.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";Cb.style.overflowY="scroll";Cb.style.height="calc(100% - 60px)";Cb.style.padding="10px 20px";ra.appendChild(Cb);const Pa=document.createElement("div");Pa.style.display="flex";Pa.style.justifyContent="space-between";Pa.style.marginTop="10px";Pa.style.top="calc(300px + 10px)";Pa.style.width="155px";Pa.style.padding="0 10px";Pa.style.zIndex=
"99999";Pa.style.left="0";cb.appendChild(Pa);const La=document.createElement("button");La.id="clearLogsButton";La.textContent="Clear Logs";Mc(La,"rgba(221, 213, 180, 0.8)");Pa.appendChild(La);La.addEventListener("click",function(){const b=document.querySelector("#logMenu");if(b){for(;b.firstChild;)b.removeChild(b.firstChild);localStorage.removeItem("savedLogs")}});const Ub=document.createElement("button");Ub.id="resetBOT";Ub.textContent="Reset Bot";Mc(Ub,"rgba(221, 213, 180, 0.8)");Pa.appendChild(Ub);
Ub.addEventListener("click",function(){oa()});const Qa=document.createElement("button");Qa.textContent="Sort Logs";Mc(Qa,"rgba(221, 213, 180, 0.8)");Pa.appendChild(Qa);Qa.addEventListener("click",function(){let b=localStorage.getItem("savedLogs");if(b){b=JSON.parse(b);b.sort((e,g)=>{e=e.split(" ")[0];g=g.split(" ")[0];return cf?e.localeCompare(g):g.localeCompare(e)});cf=!cf;for(var c=document.querySelector("#logMenu");c.firstChild;)c.removeChild(c.firstChild);for(let e of b){const g=document.createElement("p");
g.style.margin="0";g.style.padding="0";g.style.fontSize="12px";g.textContent=e;c.appendChild(g)}localStorage.setItem("savedLogs",JSON.stringify(b))}});ra.style.transition="height 0.1s ease";const qh=localStorage.getItem("logMenuVisible"),rh="true"===localStorage.getItem("disableLogMenu");null===qh?localStorage.setItem("logMenuVisible","true"):1==rh?(ra.style.display="none;",ra.style.height="0px",ra.style.width="0px",ra.style.border="0px",La.style.display="none",La.style.height="0px",La.style.width=
"0px",La.style.border="0px",Qa.style.display="none",Qa.style.height="0px",Qa.style.width="0px",Qa.style.border="0px"):"true"===qh?localStorage.getItem("logMenuHeight"):ra.style.height="38px";window.location.href.includes("/hub")&&(ra.style.display="none;",ra.style.height="0px",ra.style.width="0px",ra.style.border="0px",La.style.display="none",La.style.height="0px",La.style.width="0px",La.style.border="0px",Qa.style.display="none",Qa.style.height="0px",Qa.style.width="0px",Qa.style.border="0px");db.addEventListener("click",
function(){if("38px"!==ra.style.height)ra.style.height="38px",localStorage.setItem("logMenuVisible","false");else{const b=localStorage.getItem("logMenuHeight")||"210px";ra.style.height=b;localStorage.setItem("logMenuVisible","true")}});ra.addEventListener("resize",vf);"38px"!==ra.style.height&&vf();if(Kc()){const b="true"===localStorage.getItem("MoveButtons");let c=document.getElementById("mainmenu"),e=document.createElement("button");e.id="autoGoButton";e.className="customButton";e.innerHTML=`<span style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;">${va?
"&#9724;":"&#9658;"}</span>`;e.addEventListener("click",va?zf:pt);let g=document.createElement("button");g.className="customButton2";g.innerHTML='<span style="position: relative; top: -12px;">&#9881;</span>';g.addEventListener("click",jc);b?(g.style.position="fixed",g.style.bottom="10px",g.style.left="10px",g.style.zIndex="1000",e.style.position="fixed",e.style.bottom="10px",e.style.left="105px",e.style.zIndex="1000",document.body.appendChild(g),document.body.appendChild(e)):c&&(c.insertBefore(g,
c.children[0]),c.insertBefore(e,c.children[1]))}else return gb(),!1;(function(){try{if("mod=arena&submod=serverArena&aType=2"==mf||"mod=arena&submod=serverArena&aType=3"==mf){let l=JSON.parse(localStorage.getItem("autoAttackList"))||[],q=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],n=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[],m=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[],r=[...l,...q,...n,...m].map(w=>w.playerName);Array.from(document.querySelectorAll("#own2 tr")).forEach(w=>
{(w=w.querySelector("a"))&&r.includes(w.innerText)&&(w.style.color="orange",w.style.fontWeight="bold",w.style.textShadow="1px 1px 2px #000000")})}var b=JSON.parse(nb("arenacrosslist")||"[]"),c=JSON.parse(nb("circuscrosslist")||"[]"),e=JSON.parse(nb("removeArenaList")||"[]"),g=JSON.parse(nb("removeCircusList")||"[]"),k=JSON.parse(localStorage.getItem("autoAttackServerList")||"[]"),h=JSON.parse(localStorage.getItem("autoAttackCircusServerList")||"[]");0<b.length&&(b.forEach(l=>{k.some(q=>q.opponentId===
l.opponentId)||k.push(l)}),localStorage.setItem("autoAttackServerList",JSON.stringify(k)),mb("arenacrosslist",JSON.stringify([]),7));0<c.length&&(c.forEach(l=>{h.some(q=>q.opponentId===l.opponentId)||h.push(l)}),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(h)),mb("circuscrosslist",JSON.stringify([]),7));if(0<e.length||0<g.length)k=k.filter(l=>!e.some(q=>q.opponentId===l.opponentId)),h=h.filter(l=>!g.some(q=>q.opponentId===l.opponentId)),localStorage.setItem("autoAttackServerList",
JSON.stringify(k)),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(h)),mb("removeArenaList",JSON.stringify([]),7),mb("removeCircusList",JSON.stringify([]),7)}catch{D("Something is wrong with HandlePlayers")}})();"mod=overview"==mf&&Vh();if("mod=location"!==mf&&"mod=arena"!==mf&&0==localStorage.getItem("eventPoints_")){const b=document.getElementById("ServerQuestTime");if(b){const c=b.querySelector("span");c&&localStorage.setItem("eventPoints_",c.textContent)}}let Ta=!0;localStorage.getItem("doQuests")&&
(Ta="true"===localStorage.getItem("doQuests")?!0:!1);let Na={combat:!0,arena:!0,circus:!0,expedition:!0,dungeon:!0,items:!0};localStorage.getItem("questTypes")&&(Na=JSON.parse(localStorage.getItem("questTypes")));let Vb=0;localStorage.getItem("nextQuestTime")&&(Vb=Number(localStorage.getItem("nextQuestTime")));let Fa=!0;localStorage.getItem("doExpedition")&&(Fa="true"===localStorage.getItem("doExpedition")?!0:!1);let Sc=0;localStorage.getItem("monsterId")&&(Sc=Number(localStorage.getItem("monsterId")));
let Ga=!0;localStorage.getItem("doDungeon")&&(Ga="true"===localStorage.getItem("doDungeon")?!0:!1,bf&&(Ga=!1));10>ba.level&&(Ga=!1);let Ib="advanced"===localStorage.getItem("dungeonDifficulty")?"advanced":"normal",Ha=!0;localStorage.getItem("doArena")&&(Ha="true"===localStorage.getItem("doArena")?!0:!1,bf&&"false"===localStorage.getItem("EnableArenaHell")&&(Ha=!1));2>ba.level&&(Ha=!1);let Af="min";localStorage.getItem("arenaOpponentLevel")&&(Af=localStorage.getItem("arenaOpponentLevel"));let Ma=!0;
localStorage.getItem("doCircus")&&(Ma="true"===localStorage.getItem("doCircus")?!0:!1);10>ba.level&&(Ma=!1);let Bf="min";localStorage.getItem("circusOpponentLevel")&&(Bf=localStorage.getItem("circusOpponentLevel"));let Ia=!0;localStorage.getItem("doEventExpedition")&&(Ia="true"===localStorage.getItem("doEventExpedition")?!0:!1);try{document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0]||(Ia=!1)}catch{}let kc=0;localStorage.getItem("eventMonsterId")&&(kc=Number(localStorage.getItem("eventMonsterId")));
let hb=!1;localStorage.getItem("AutoAuction")&&(hb="true"===localStorage.getItem("AutoAuction")?!0:!1);localStorage.getItem("DoOther")&&localStorage.getItem("DoOther");let pb=!1;localStorage.getItem("doKasa")&&(pb="true"===localStorage.getItem("doKasa")?!0:!1);const uj=[{name:"expedition",enabled:Fa,kl:"#cooldown_bar_text_expedition",hm:()=>{var b=document.getElementById("cooldown_bar_expedition");return b&&"none"!==b.style.display?(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):
!1},km:()=>{var b=document.getElementById("cooldown_bar_expedition");if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&b.click();return!!b}},{name:"dungeon",enabled:Ga,kl:"#cooldown_bar_text_dungeon",hm:()=>{var b=document.getElementById("cooldown_bar_dungeon");return b&&"none"!==b.style.display?(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):!1},km:()=>{var b=document.getElementById("cooldown_bar_dungeon");if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&
b.click();return!!b}},{name:"arena",enabled:Ha,kl:"#cooldown_bar_text_arena",hm:()=>{var b=document.getElementById("cooldown_bar_arena");return b&&"none"!==b.style.display?(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):!1},km:()=>{var b=document.getElementById("cooldown_bar_arena");if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&b.click();return!!b}},{name:"circusTurma",enabled:Ma,kl:"#cooldown_bar_text_ct",hm:()=>{var b=document.getElementById("cooldown_bar_ct");
return b&&"none"!==b.style.display?(b=b.querySelector(".cooldown_bar_text"))&&!b.classList.contains("ticker"):!1},km:()=>{var b=document.getElementById("cooldown_bar_ct");if(!b)return!1;(b=b.querySelector(".cooldown_bar_link"))&&b.click();return!!b}},{name:"eventExpedition",enabled:Ia,kl:null,hm:()=>Ia&&of("eventPoints")&&ba.o>(Number(localStorage.getItem("healPercentage"))||25),km:()=>{try{const b=document.getElementById("submenu2")?.getElementsByClassName("menuitem glow")[0];if(b)return b.click(),
!0}catch(b){}return!1}}];let d;switch(localStorage.getItem("settings.language")){case "EN":d={...Ih};break;case "PL":d={...Jh};break;case "ES":d={...Kh};break;case "TR":d={...Lh};break;case "FR":d={...Mh};break;case "HG":d={...Nh};break;case "BR":d={...Oh};break;default:d={...Ih}}let z1=localStorage.getItem("we");we=new Date(z1);if(!window.location.href.includes("lobby")&&aa.player.Fd<new Date&&we<new Date)sessionStorage.setItem("autoGoActive","false"),gb();else{if("true"===localStorage.getItem("activateAuction2")){function b(n){n.style.position="flex";n.style.width=
"150px";n.style.marginLeft="8px";n.style.marginTop="10px";n.style.height="16px";n.style.backgroundColor="rgba(221, 213, 180, 0.8)";n.style.border="1px solid #c4ac70";n.style.padding="10px";n.style.borderRadius="10px";n.style.fontFamily="Arial, sans-serif";n.style.color="#333";n.style.textAlign="center";n.style.zIndex="1000"}const c=document.createElement("div");c.id="auctionMPopup";b(c,"calc(55px + 200px + 100px + 10px + 10px + -5px)");c.addEventListener("click",async()=>{Hf("mod=auction&ttype=3")});
const e=document.createElement("div");e.id="auctionPopup";b(e,"calc(100px + 200px + 100px + 10px)");e.addEventListener("click",async()=>{Hf("mod=auction")});function g(n,m){return`${m}: ${[d.ac,d.Cb,d.Kb,d.Yb,d.bc][n]||"Unknown"}`}const k=document.createElement("h3"),h=document.createElement("h3");cb.appendChild(e);cb.appendChild(c);const l=localStorage.getItem("auctionStatus"),q=localStorage.getItem("auctionMStatus");null!==l?(k.textContent=g(parseInt(l,10),"Gladiator"),e.appendChild(k),e.style.display=
"block"):e.style.display="none";null!==q?(h.textContent=g(parseInt(q,10),"Mercenary"),c.appendChild(h),c.style.display="block"):c.style.display="none";rh&&(e.style.display="none",e.style.height="0px",c.style.display="none",c.style.height="0px")}var yc=localStorage.getItem("savedLogs");yc&&(yc=JSON.parse(yc),yc.forEach(b=>{const c=document.createElement("p");c.style.margin="0";c.style.padding="0";c.style.fontSize="12px";c.textContent=b;Cb.appendChild(c)}));var za={async start(){return new Promise(()=>
{za.ql=Fh().gold;za.form=document.querySelectorAll("#auction_table form");za.I=[];const b=localStorage.getItem("auctiongladiatorenable"),c=localStorage.getItem("auctionmercenaryenable"),e=localStorage.getItem("bidFood"),g=localStorage.getItem("bidStatus"),k=localStorage.getItem("auctionStatus"),h=localStorage.getItem("auctionMStatus"),l=localStorage.getItem("auctionminlevel")||0;let q="true"===localStorage.getItem("enableMercenarySearch");const n=JSON.parse(localStorage.getItem("Timers")),m=async(w,
v)=>{try{D(`${d.xf}`);const x=await (await fetch(w)).text(),C=(new DOMParser).parseFromString(x,"text/html");await za.ko(C);0<za.I.length?(D(`${d.yf}`),"auction"===v?await za.hn(2,za.I.length):await za.hn(3,za.I.length)):("auction"===v?Y("auction",n.AuctionCheck||10):Y("auctionM",n.AuctionCheck||10),window.location.reload());1!=localStorage.getItem("AuctionTurbo")&&Y("AuctionEmpty",1)}catch(x){window.location.reload()}},r=async()=>{var w=JSON.parse(localStorage.getItem("auctionPrefixes"))||[];let v=
JSON.parse(localStorage.getItem("auctionSuffixes"))||[],x;var C=(new URL(window.location.href)).origin;try{1===w.length?x=$b(w[0]):1===v.length&&(x=$b(v[0]))}catch(E){x=""}if(q&&Number(k)>=Number(g)&&of("auction")||"true"==e&&Number(k)>=Number(g)&&of("auction"))mf!=`mod=auction&itemType=0&itemLevel=${l}`&&(C=`${C}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,m(C,"auction"));else if((1==w.length||1==v.length)&&"true"==b&&Number(k)>=Number(g)&&"false"==e&&of("auction"))w=`mod=auction&qry=${encodeURIComponent(x)}&itemType=0&itemLevel=${l}`,
mf!==w&&(C=`${C}/game/index.php?${w}&sh=${W("sh")}`,m(C,"auction"));else if(q&&Number(k)>=Number(g)&&"true"==e&&of("auction"))mf!=`mod=auction&itemType=0&itemLevel=${l}`&&(C=`${C}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,m(C,"auction"));else if((1==w.length||1==v.length)&&"true"==c&&Number(h)>=Number(g)&&"false"==e&&of("auctionM"))mf!=`mod=auction&qry=${encodeURIComponent(x)}&itemType=0&ttype=3&itemLevel=${l}`&&(C=`${C}/game/index.php?mod=auction&qry=${x}&itemType=0&ttype=3&itemLevel=${l}&sh=${W("sh")}`,
m(C,"auctionM"));else if(("true"===b||"true"===e)&&!q&&Number(k)>=Number(g)&&of("auction"))if("true"===e&&1>w.length&&1>v.length)mf!=`mod=auction&itemType=7&itemLevel=${l}`&&(C=`${C}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${W("sh")}`,m(C,"auction"));else{if(("true"===b||"true"===e)&&!q&&Number(k)>=Number(g)&&of("auction"))if("true"===e&&"false"===b&&(0<w.length||0<v.length))mf!=`mod=auction&itemType=7&itemLevel=${l}`&&(C=`${C}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${W("sh")}`,
m(C,"auction"));else if("true"===e&&(0<w.length||0<v.length))mf!=`mod=auction&itemType=0&itemLevel=${l}`&&(C=`${C}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,m(C,"auction"));else if(mf!=`mod=auction&itemType=0&itemLevel=${l}`&&0<w.length||mf!=`mod=auction&itemType=0&itemLevel=${l}`&&0<v.length)C=`${C}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,m(C,"auction")}else if("true"==c&&Number(h)>=Number(g)&&(0<w.length||0<v.length)&&of("auctionM")){if(mf!=
`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&0<w.length||mf!=`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&0<v.length)C=`${C}/game/index.php?mod=auction&itemType=0&ttype=3&itemLevel=${l}&sh=${W("sh")}`,m(C,"auctionM")}else q?mf!=`mod=auction&itemType=15&itemLevel=${l}`&&(C=`${C}/game/index.php?mod=auction&itemType=15&itemLevel=${l}&sh=${W("sh")}`,m(C,"auction")):setTimeout(r,3E3)};r()})},jo(b){const c="true"===localStorage.getItem("AuctionCover");b=b.querySelector("span");if(!b||!b.getAttribute("style"))return!0;
b=b.getAttribute("style");return c&&b.includes("green")?!1:!c&&b.includes("green")?!0:b.includes("blue")?!1:!0},async ko(b){this.form=b.querySelectorAll("#auction_table form");for(let e of this.form){var c=e.querySelector(".auction_bid_div");b=e.querySelector(".ui-draggable");let g=c.querySelector("input").value;c=this.jo(c);let k=Gb(b),h=ub(b),l=JSON.parse(localStorage.getItem("equipmentSelection")||"[]"),q=localStorage.getItem("maximumBid"),n=localStorage.getItem("auctiongladiatorenable"),m=localStorage.getItem("auctionmercenaryenable"),
r=Ba(b),w=localStorage.getItem("auctionMinQuality")||0,v=localStorage.getItem("bidFood"),x=parseInt(Ea(b).split("-")[0],10),C=15==x?parseInt(b.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,E=15==x?parseInt(b.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,A=15==x?parseInt(b.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],10):0,t=!1,u="true"===localStorage.getItem("enableMercenarySearch"),z=parseInt(localStorage.getItem("minDexterity"),10)||0,B=parseInt(localStorage.getItem("minAgility"),
10)||0,J=parseInt(localStorage.getItem("minIntelligence"),10)||0,I=!1,K=!1,L,O,Z;Z=localStorage.getItem("ignorePS")||"false";L=JSON.parse(localStorage.getItem("auctionPrefixes")||"[]");O=JSON.parse(localStorage.getItem("auctionSuffixes")||"[]");L.some(fa=>k.toLowerCase().includes(fa.toLowerCase())?I=!0:!1);O.some(fa=>{let da=k.toLowerCase();fa=fa.toLowerCase();return da.endsWith(" "+fa)||da===fa?K=!0:!1});if("true"===Z){if(I||K)t=!0}else if(I&&K||I&&0===O.length||K&&0===L.length)t=!0;"string"===typeof h&&
(h=[h]);null==w&&(w=5);t=t&&0===l.length||t&&l.includes("9999")||t&&l.some(fa=>h.includes(fa))?!0:!1;"true"===v&&7==x&&g<ba.gold&&(t=!0);if(Number(r)<w){if("true"!==v||7!=x)t=!1}else"true"===v&&7==x&&(t=!0);"false"!==n||"false"!==m||"true"===v&&7==x||(t=!1);1E3>ba.gold&&(Y("AuctionEmpty",1),Y("AuctionMEmpty",1));c&&u&&15==x&&Number(g)<Number(q)&&(0==z||C>=z)&&(0==B||E>=B)&&(0==J||A>=J)&&(t=!0);t&&c&&Number(g)<Number(q)&&this.I.push([{itemLevel:vb(b),itemName:k,basis:Ea(b),quality:Ba(b),price:g},g,
e.getAttribute("action"),{auctionid:e.querySelector("input[name=auctionid]").value,qry:e.querySelector("input[name=qry]").value,itemType:e.querySelector("input[name=itemType]").value,itemLevel:e.querySelector("input[name=itemLevel]").value,itemQuality:e.querySelector("input[name=itemQuality]").value,buyouthd:e.querySelector("input[name=buyouthd]").value,bid_amount:g,bid:e.querySelector("input[name=bid]").value}])}},async hn(b){function c(h){if("string"===typeof h)return h;const l=[];for(let q in h)h.hasOwnProperty(q)&&
l.push(encodeURIComponent(q)+"="+encodeURIComponent(h[q]));return l.join("&")}function e(h){return new Promise((l,q)=>{if(Number(h[1])>za.ql)q(Error("Not enough gold"));else{za.ql-=Number(h[1]);var n=new XMLHttpRequest;n.open("POST",h[2],!0);n.onreadystatechange=function(){if(n.readyState===XMLHttpRequest.HEADERS_RECEIVED){if(200===n.status){const m=JSON.parse(localStorage.getItem("bidList"))||[];m.push(h[0].itemName);localStorage.setItem("bidList",JSON.stringify(m))}n.abort();l()}};n.setRequestHeader("Content-Type",
"application/x-www-form-urlencoded");q=c(h[3]);n.send(q)}})}async function g(){for(;0<za.I.length;){const h=za.I.splice(0,3).map(l=>e(l));try{await Promise.all(h)}catch(l){if("Not enough gold"===l.message){2===b?(Y("AuctionEmpty",1),Y("auction",k.AuctionCheck||10)):(Y("AuctionMEmpty",1),Y("auctionM",k.AuctionCheck||10));break}}await new Promise(l=>setTimeout(l,500))}}localStorage.getItem("auctionStatus");localStorage.getItem("auctionMStatus");const k=JSON.parse(localStorage.getItem("Timers"));if(za.I&&
0!==za.I.length)try{await g()}finally{Y("AuctionEmpty",1),Y("AuctionMEmpty",1),window.location.reload()}else Y("AuctionEmpty",1),Y("AuctionMEmpty",1),window.location.reload()}},ja={bag:null,g:null,Fn:null,Hq:localStorage.getItem("smeltIgnorePS"),async start(){const b="true"===localStorage.getItem("RepairBeforeSmelt");var c="513";c=(c=localStorage.getItem("smeltTab"))?(513+parseInt(c,10)).toString():"513";c=document.querySelector(`[data-bag-number="${c}"]`);if("mod=forge&submod=smeltery"!=mf)Hf("mod=forge&submod=smeltery");
else if(c.classList.contains("current")&&pf()){this.slots=await this.u();const e=this.slots.filter(h=>"closed"===h["forge_slots.state"]);this.Xm(this.slots);await this.Fm(this.slots);const g=JSON.parse(localStorage.getItem("Timers")),k="true"===localStorage.getItem("smelteverything3");c="true"===localStorage.getItem("smeltAnything")?this.Lo():"true"===localStorage.getItem("smelteverything3")?this.Mo():this.Ko();if(0<c.length){for(let {id:h,slot:l,hammerState:q}of c)try{if(b){const n=await Aj.ep(h);
if(n&&0!=n)try{await ja.wm(l,n,q,h)}catch{await ja.wm(l,h,q,h)}else await ja.wm(l,h,q,h)}else await ja.wm(l,h,q,h)}catch(n){}D("Smelting completed. Reloading page");Y("smelt",g.SmeltingNoItem||10);window.location.reload()}else 1>c.length&&1==k?(D("No items to smelt, reloading page"),Y("smelt",g.SmeltingNoItem||10),window.location.reload()):0<e.length?await this.pickItems():0<e.length&&"true"===localStorage.getItem("smelteverything3")?ja.move():(D("No free slots, reloading page"),Y("smelt",g.SmeltingNoItem||
10),window.location.reload())}else c.click(),pf(()=>this.start())},bp(b,c){b=JSON.parse(localStorage.getItem("smeltedItems"))||[];b.push(c);localStorage.setItem("smeltedItems",JSON.stringify(b))},Ko(){const b=this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let g of c){if(c=this.sm(g)){let k=b.shift();void 0!==k&&e.push({id:g.getAttribute("data-item-id"),slot:k,hammerState:c.hammerState||
"none",matchingRule:c})}if(0===b.length)break}return e},Lo(){const b=this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let g of c){if(c=this.sm(g)){let k=b.shift();void 0!==k&&e.push({id:g.getAttribute("data-item-id"),slot:k,hammerState:c.hammerState||"none",matchingRule:c})}if(0===b.length)break}return e},Mo(){const b=[2,4,8,1,256,512,48,1024],c=this.slots.filter(e=>"closed"===e["forge_slots.state"]).map(e=>
e["forge_slots.slot"]);return Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(e=>{if(!Yb(e))return!1;e=e.getAttribute("data-content-type");return b.includes(Number(e))}).map(e=>({id:e.getAttribute("data-item-id"),slot:c.shift()})).filter(({slot:e})=>void 0!==e)},async wm(b,c,e,g){try{var k=await jQuery.post(T({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:W("sh")});let q;try{var h=JSON.parse(k);if(h.slots[b]&&h.slots[b].formula&&
h.slots[b].formula.rent[2])q=h.slots[b].formula.rent[2];else{for(k=0;k<h.slots.length;k++)if(h.slots[k].formula&&h.slots[k].formula.rent[2]){q=h.slots[k].formula.rent[2];break}q||=3E3}}catch(m){q=3E3}const n=Gb(document.querySelector(`[data-item-id='${g}']`));try{if(e&&"none"!==e){const m={bronze:"19-10",silver:"19-11",gold:"19-12"}[e];if(m){var l=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));const r=l.findIndex(v=>v.classList.contains("current")),w=l.slice(r).concat(l.slice(0,
r));g=!1;h=null;for(l=0;l<w.length;l++){let v=w[l];if("false"===v.getAttribute("data-available"))continue;v.click();await new Promise(C=>setTimeout(C,250));const x=document.querySelector(`.item-i-${m}`);if(x){g=!0;h=x;break}}if(g&&h){const v=h.getAttribute("data-container-number"),x=h.getAttribute("data-position-x"),C=h.getAttribute("data-position-y");await jQuery.post(T({mod:"inventory",submod:"move",from:v,fromX:x,fromY:C,to:773,toX:b+1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")}));
D(`Hammer (${e}) moved to inventory.`)}else D(`Hammer (${e}) not found in any inventory bag.`),D("Proceeding to smelt without a hammer.")}else D("Proceeding to smelt without a hammer.")}}catch(m){}if(q<Fh().gold)await jQuery.post(T({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")})),this.bp(c,n),ka("itemSmelted",0),D(`${d.Vf}`+n),await new Promise(m=>setTimeout(m,250));else{D(`${d.Bb}`+q);const m=JSON.parse(localStorage.getItem("Timers"));Y("smelt",
m.Smelting||10);window.location.reload()}}catch(q){location.reload()}},async gp(b,c){var e=await jQuery.post(T({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:W("sh")});e=JSON.parse(e).slots[b].formula.rent[2];e<Fh().gold?jQuery.post(T({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")})).done(function(){var g=JSON.parse(localStorage.getItem("smeltery_itemList1"));({item:g}=g);D(`${d.Wf}`+g.name);
window.location.reload()}).fail(function(){D("Problem with smelting, maybe there is not enough space.");window.location.reload()}):(D(`${d.Bb}`+e),b=JSON.parse(localStorage.getItem("Timers")),Y("smelt",b.SmeltingNoGold||5),window.location.reload())},init:function(){jQuery("#inv").after('\n                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n\n                        <fieldset id="gladbot-workbench" style="\n                        padding: 10px;\n                        margin: 10px 20px;\n                        text-align: center;\n                        display: flex;\n                        flex-direction: row;\n                        flex-wrap: wrap;\n                        align-items: center;\n                        justify-content: space-around;\n                        border: 2px solid darkred;\n                        border-radius: 8px;\n                        width: 235px;">\n                        <legend style="\n                            padding: 0 10px;\n                            color: darkred;\n                            font-weight: bold;">GLDbot Smeltery Area</legend>\n                        </fieldset>');
ja.Cm("#gladbot-workbench",'<i class="fa fa-fire"></i>',"gladbot-button gladbot-smelter-button-smelt gladbot-stylish-button").mouseup(b=>{ja.dn(b)});ja.Cm("#gladbot-workbench","RESET","gladbot-button gladbot-smelter-button-reset gladbot-stylish-button").mouseup(()=>{localStorage.setItem("activateSmeltMode",!1)});jQuery("#gladbot-workbench").append('<p style="font-size: 0.8em; color: darkred;">Right click to reset smelt mode.</p>')},dn:async function(){jQuery(document.body).addClass("fire-smelt-cursor");
jQuery(document.body).on("contextmenu",function(b){b.preventDefault();jQuery(document.body).removeClass("fire-smelt-cursor");jQuery(document.body).off("contextmenu");localStorage.setItem("activateSmeltMode",!1)});this.slots=await this.u();localStorage.setItem("activateSmeltMode",!0);jQuery("#inv .ui-draggable, #char .ui-draggable").off("mouseup.smelt").on("mouseup.smelt",async b=>{var c=b.target,e=c.className.match(/item-i-(\d+)-\d+/)[1];(b=this.slots.filter(g=>"closed"===g["forge_slots.state"])[0])?
(e={item:{type:e,name:Gb(c),quality:Ba(c),slot:b,container:c.getAttribute("data-container-number")},spot:{bag:c.getAttribute("data-container-number"),x:c.getAttribute("data-position-x"),y:c.getAttribute("data-position-y")}},localStorage.setItem("smeltery_itemList1",JSON.stringify(e)),jQuery(c).parents("#char").length?setTimeout(()=>{},1E3):(this.slots=await this.u(),await this.Fm(this.slots),this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]),c=c.getAttribute("data-item-id"),
e&&await ja.gp(b["forge_slots.slot"],c))):console.log("No free slot available")})},async u(){try{const b=await jQuery.post(T({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",a:(new Date).getTime(),sh:W("sh")});return JSON.parse(b).slots}catch(b){console.log(b)}},async Xm(b){if("undefined"!==typeof b){let e=[];for(var c=0;c<b.length;c++)if("undefined"!==typeof b[c]["forge_slots.uend"]){let g=1E3*b[c]["forge_slots.uend"];"finished-succeeded"===b[c]["forge_slots.state"]&&(g=0);e.push([g,
b[c].item.name])}localStorage.setItem("smelt.timer",JSON.stringify(e))}},async Fm(b){const c="true"===localStorage.getItem("smeltLootbox");Array.isArray(b)&&(b=b.filter(e=>"finished-succeeded"===e.state).map(e=>e["forge_slots.slot"]),0<b.length&&!c?(await Promise.all(b.map(e=>ja.Xo(e))),await this.u()):0<b.length&&c&&(await Promise.all(b.map(e=>ja.Yo(e))),await this.u()))},async Yo(b){return jQuery.post("ajax.php",{mod:"forge",submod:"lootbox",mode:"smelting",slot:b,a:(new Date).getTime(),sh:W("sh")})},
async Xo(b){return jQuery.post("ajax.php",{mod:"forge",submod:"storeSmelted",mode:"smelting",slot:b,a:(new Date).getTime(),sh:W("sh")})},kn(){var b=localStorage.getItem("smelt.timer");if(!b)return!0;b=JSON.parse(b).sort((c,e)=>c[0]-e[0]);return 6>b.length||b[0][0]+6E4<(new Date).getTime()},async pickItems(){D(`${d.Xf}`);ja.bag=document.getElementById("inv");ja.g=[];aa.Dd.Fn&&window.location.reload();var b=JSON.parse(localStorage.getItem("smeltingSettings"))||[],c=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||
{};const e=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]")),g=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]")),k="true"===localStorage.getItem("smelthighercolors");var h=!1;try{for(let m of b){if(!1===m.isEnabled)continue;if("isUnderworldItem"!==m.condition&&2>m.prefix.length&&2>m.suffix.length)continue;let r=[];var l="";"nameContains"===m.condition&&2<m.prefix.length&&""!==m.prefix.trim()?l=m.prefix.trim():!m.prefix&&"nameContains"===m.condition&&2<m.suffix.length&&
""!==m.suffix.trim()&&(l=m.suffix.trim());"nameContains"===m.condition&&m.qm&&2<m.qm.length&&(l=m.qm.trim());const w={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};if(m.colors&&0<m.colors.length){let v=[...m.colors];k&&v.sort((x,C)=>w[C]-w[x]);v.forEach(x=>{x=w[x];void 0!==x&&r.push(x)})}else r=Object.values(w),k&&r.sort((v,x)=>x-v);var q=0,n=[];if(2<l.length){for(let v of r){await new Promise(C=>setTimeout(C,270));const x=await this.rn(1,v,l,0);n.push(...x);5<=q&&(localStorage.setItem("smelt.timeOut",
0),window.location.reload())}1<=q&&(Y("smelt",0),window.location.reload());l=n;for(let v of l){if(5<=q)break;const x=v.item,C=Gb(v.item);ja.g.some(E=>E.id===v.id)||e.has(C)||g.has(C)||!this.sm(x,m,b,c)||(ja.g.push({item:x,id:v.id,hammerState:m.hammerState||"none",matchingRule:m}),q++,h=!0)}if(5<=q)break}else if("isUnderworldItem"===m.condition){D("Looking for underworld items...");q=0;for(let v of r){if(5<=q)break;const x=await this.rm(v);l=[];for(n=1;n<=Math.min(x,5);n++)l.push(n);for(n=0;n<l.length&&
!(5<=q);n+=2){const C=l.slice(n,n+2).map(async A=>{try{return await this.rn(A,v)}catch(t){return[]}}),E=await Promise.all(C);for(let A of E){if(5<=q)break;for(let t of A){const u=t.item;let z=this.sm(u,m);if(z&&(ja.g.push({item:u,id:t.id,hammerState:z.hammerState||"none",matchingRule:z}),q++,5<=q))break}}}}}}if(!h&&"true"===localStorage.getItem("smeltAnything")){const m=c.itemTypes||[],r=c.hammerState||"none",w={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};let v=(c.colors||[]).map(C=>
w[C]);0===v.length&&(v=Object.values(w));b=0;const x=await this.rm(v[0]);for(c=1;c<=x&&!(5<=b);c++){const C=await this.Io(c,v[0]);for(let E of C){if(5<=b)break;const A=E.item,t=Gb(A),u=parseInt(Ba(A),10),z=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]")),B=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"));if(!z.has(t)&&!B.has(t)){if(Da.colors&&0<Da.colors.length){const J={white:-1,green:0,blue:1,purple:2,orange:3,red:4},I=Object.keys(J).find(K=>J[K]===u);
if(!Da.colors.includes(I))continue}m.includes(A.getAttribute("data-content-type"))&&(ja.g.push({item:A,id:E.id,hammerState:r}),b++,h=!0)}}if(5<=b)break}}if(h&&0<ja.g.length)await ja.move(ja.g);else{D("No items found for smelting.");const m=JSON.parse(localStorage.getItem("Timers"));Y("smelt",m.SmeltingNoItem||15);window.location.reload()}}catch(m){D("Error looking for items for smelting. If you have too many conditions, please reduce them."),h=JSON.parse(localStorage.getItem("Timers")),Y("smelt",
h.SmeltingError||15),window.location.reload()}},async $p(b,c){b=await jQuery.get(F({mod:"packages",f:"0",fq:c,qry:"",page:b,sh:W("sh")}));const e=[];jQuery(b).find(".packageItem").each((g,k)=>{g=k.querySelector("input").value;(k=jQuery(k).find(".ui-draggable")[0])&&e.push({id:g,item:k})});return e},Go(b){return b.getAttribute("data-hammer-state")||"none"},async rn(b,c=null,e="",g="0"){b={mod:"packages",f:g,page:b,sh:W("sh")};null!==c&&(b.fq=c);e&&""!==e.trim()&&(b.qry=e.trim());c=await jQuery.get(F(b));
const k=[];jQuery(c).find(".packageItem").each((h,l)=>{h=l.querySelector("input").value;(l=jQuery(l).find(".ui-draggable")[0])&&k.push({id:h,item:l})});return k},async Io(b,c=null,e=""){b={mod:"packages",f:"0",fq:null!==c?c:-1,page:b,sh:W("sh")};e&&""!==e.trim()&&(b.qry=e.trim());e=await jQuery.get(F(b));e=jQuery(e).find(".packageItem");const g=[],k=(JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{}).itemTypes||[],h=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]")),
l=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"));e.each((q,n)=>{const m=n.querySelector("input").value;if(q=jQuery(n).find(".ui-draggable")[0]){n=Gb(q);var r=q.getAttribute("data-content-type");g.some(w=>w.id===m)||h.has(n)||l.has(n)||k.includes(r)&&g.push({item:q,id:m})}});return g},async rm(b=null,c="",e="0"){b={mod:"packages",f:e,fq:b||-1,qry:"",page:1,sh:W("sh")};c&&""!==c.trim()&&(b.qry=c.trim());c=await jQuery.get(F(b));b=jQuery(c).find(".paging_right_full");c=1;0<
b.length&&(b=b.last().attr("href"))&&(b=b.match(/page=(\d+)(?!.*page=)/))&&b[1]&&(c=parseInt(b[1],10));return c},sm(b){const c="true"===localStorage.getItem("smeltAnything"),e=JSON.parse(localStorage.getItem("smeltingSettings"))||[],g=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||[];if(!c&&!c&&0===e.length)return!1;const k=Gb(b),h=parseInt(b.getAttribute("data-level"),10),l=ub(b),q=parseInt(Ba(b),10);var n=this.Go(b),m=b.getAttribute("data-basis");n=b.getAttribute("data-hash");b.getAttribute("data-level");
m=wb(m,n);n=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]"));const r=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"));if(n.has(k)||r.has(k))return!1;for(let w of e)if(n=w.hammerState||"none",!1!==w.isEnabled&&this.so(b,w,{itemName:k,itemLevel:h,itemType:l,itemQuality:q,itemHammerState:n,isUnderworldItem:m}))return w;if(c){if(g.itemTypes&&0<g.itemTypes.length&&!g.itemTypes.map(w=>parseInt(w,10)).includes(parseInt(l,10)))return!1;if(g.colors&&0<g.colors.length){const w=
{white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(w).find(v=>w[v]===q);if(!g.colors.includes(b))return!1}return g}return null},so(b,c,e){let {itemName:g,itemLevel:k,itemType:h,itemQuality:l,isUnderworldItem:q}=e;if("nameContains"===c.condition){b=!0;if(0===c.prefix.length&&0===c.suffix.length)return!1;c.prefix&&0<c.prefix.length&&g&&0<g.length&&!g.toLowerCase().includes(c.prefix.toLowerCase())&&(b=!1);c.suffix&&0<c.suffix.length&&g&&0<g.length&&!g.toLowerCase().includes(c.suffix.toLowerCase())&&
(b=!1);c.prefix&&0<c.prefix.length&&c.suffix&&0<c.suffix.length&&(!(g&&0<g.length)||g.toLowerCase().includes(c.prefix.toLowerCase())&&g.toLowerCase().includes(c.suffix.toLowerCase())||(b=!1));if(!b)return!1}else if("isUnderworldItem"===c.condition&&!q)return!1;if(!(k<(c.level?parseInt(c.level,10):0))&&c.itemTypes&&0<c.itemTypes.length){if(!c.itemTypes.includes("9999")&&!c.itemTypes.map(n=>parseInt(n)).includes(parseInt(h,10)))return!1}else return!1;l||=0;if(c.colors&&0<c.colors.length){const n={white:-1,
green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(n).find(m=>n[m]===l);if(!c.colors.includes(b))return!1}else return!1;return c},Cm:function(b,c,e){c=jQuery("<button>").html(c).addClass(e);jQuery(b).append(c);return c},async move(){var b="513";b=(b=localStorage.getItem("smeltTab"))?(513+parseInt(b,10)).toString():"513";this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]).shift();try{let g=ja.g.pop();var c=bc(ja.bag);let k=cc(5,8,c),h=parseInt(g.item.getAttribute("data-measurement-x")),
l=parseInt(g.item.getAttribute("data-measurement-y")),q=lc(l,h,k);c=b;if(q){await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+g.id,fromX:"1",fromY:"1",to:c,toX:q.x+1,toY:q.y+1,amount:"1"}),{a:(new Date).getTime(),sh:W("sh")});var e=jQuery(g.item).css({left:32*q.x,top:32*q.y});ja.bag.appendChild(e[0]);0<ja.g.length||g?(localStorage.setItem("smeltCheck.timeOut",0),await new Promise(n=>setTimeout(n,500)),await this.move()):window.location.reload()}else if(0<ja.g.length&&!q){D(`${d.Lb}`);await new Promise(m=>
setTimeout(m,500));await this.move();const n=JSON.parse(localStorage.getItem("Timers"));Y("smelt",n.SmeltingNoItem||15)}else D(`${d.Lb}`),Y("smelt",timers.SmeltingNoItem||15),window.location.reload()}catch(g){localStorage.setItem("smeltCheck.timeOut",0),window.location.reload()}}};window.location.href.includes("index.php?mod=mysterybox")&&(Xh(),Yh());window.location.href.includes("/index.php?mod=forge&submod=smeltery")&&(ja.init(),ja.slots=await ja.u(),await ja.Xm(ja.slots),"true"==localStorage.getItem("activateSmeltMode")&&
ja.dn());try{window.location.href.includes("/index.php?mod=location&submod=serverQuest")&&(window.location.href.includes("submod=serverQuestHighscore&loc=hadrians_wall")||localStorage.setItem("eventPoints_",parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10)))}catch{localStorage.setItem("doEventExpedition",!1);Hf("mod=overview");return}try{if(window.location.href.includes("/index.php?mod=work")){let b=document.querySelector('span[data-ticker-type="countdown"]');
if(b){let c=b.innerText.split(":"),e=6E4*(60*parseInt(c[0],10)+parseInt(c[1],10));await new Promise(g=>setTimeout(g,e))}}}catch{Hf("mod=overview");return}var Bj={async start(){const b=await Promise.all([new Promise(c=>{jQuery.get(F({mod:"overview",doll:"1",sh:W("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");c(!e)})}),new Promise(c=>{jQuery.get(F({mod:"overview",doll:"2",sh:W("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");
c(!e)})})]);b[0]&&Y("CheckDolls",1);b[1]&&Y("CheckDolls",1)}},ff={async check(b=!1){return new Promise(async c=>{await new Promise(e=>{jQuery.get(F({mod:"overview",doll:"1",sh:W("sh")}),g=>{localStorage.setItem("arenaCostumeEquiped",jQuery(g).find(".avatar")[0].classList.contains("avatar_costume_part"));e()})});b&&await b();c()})},async start(){if("mod=costumes"!=mf)Hf("mod=costumes");else{let e=localStorage.getItem("costumeUnderworld"),g=localStorage.getItem("costumeUnderworld");const k="true"===
localStorage.getItem("wearUnderworld");var b=!1;let h=document.querySelectorAll(".costumes_box"),l=!1,q;const n=localStorage.getItem("costumeUnderworld");b=["9","10","11"];const m=JSON.parse(localStorage.getItem("underworld"));for(var c of b)try{const r=h[Number(c)-1].querySelector(".costumes_button_single").getAttribute("onclick");if(r&&!r.includes("dropCostume")){l=!0;break}}catch(r){}0<h.length&&null!==n&&(c=Number(n)-1,0<=c&&c<h.length&&(c=h[c].querySelector(".costumes_button_single")||h[c].querySelector(".costumes_button_active_single"))&&
(q=c.getAttribute("onclick")));["9","10","11"].includes(e)&&q&&q.includes("dropCostume")?(b=!0,m.oj=!0,localStorage.setItem("underworld",JSON.stringify(m)),Y("CheckDolls",15)):(b=!1,m.oj=!1,localStorage.setItem("underworld",JSON.stringify(m)));b?(Y("CheckDolls",30),window.location.reload()):await this.check(async()=>{let r=[];if(k){let w=0;const v=["9","10","11"];for(let x of v)try{const C=h[Number(x)-1].querySelector(".costumes_button_single")?.getAttribute("onclick");if(C&&!C.includes("dropCostume")){l=
!0;const E=Number(n)-1;0<=E&&E<h.length&&(l=h[E].querySelector(".costumes_button_single")||h[E].querySelector(".costumes_button_active_single")?!0:!1);if(l&&"9"===g&&2>=Number(Fh().Ha)){r.push({doll:1,setId:Number(g)+2});break}if(l&&"10"===g&&2>=Number(Fh().uo)){r.push({doll:1,setId:Number(g)+2});break}if(l&&"11"===g){r.push({doll:1,setId:Number(g)+2});break}}}catch(C){w++}w===v.length&&D(`${d.Df}`)}try{if(!l){const w=h[Number(localStorage.getItem("costumeBasic")-1)].querySelector("#costumes_button_left input"),
v=w.getAttribute("onclick");w.classList.contains("disabled")||v.includes("dropCostume")||(12===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-3}):13===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-3}):14===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-3}):15===Number(localStorage.getItem("costumeBasic"))?r.push({doll:1,setId:localStorage.getItem("costumeBasic")-
3}):r.push({doll:1,setId:localStorage.getItem("costumeBasic")}));if(8>=Number(localStorage.getItem("costumeDungeon"))){const x=h[Number(localStorage.getItem("costumeDungeon")-1)].querySelector("#costumes_button_right input"),C=x.getAttribute("onclick");x.classList.contains("disabled")||C.includes("dropCostume")||(12===Number(localStorage.getItem("costumeDungeon"))?r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-3}):13===Number(localStorage.getItem("costumeDungeon"))?r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-
3}):14===Number(localStorage.getItem("costumeDungeon"))?r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-3}):15===Number(localStorage.getItem("costumeDungeon"))?r.push({doll:2,setId:localStorage.getItem("costumeDungeon")-3}):r.push({doll:2,setId:localStorage.getItem("costumeDungeon")}))}}if(0<r.length){let {doll:w,setId:v}={...r.pop()};(await fetch(F({mod:"costumes",submod:"changeCostume",doll:w,setId:v,sh:W("sh")}))).ok&&0<r.length&&9>Number(v)&&await ff.nn(r);Y("CheckDolls",30)}else Y("CheckDolls",
15);window.location.reload()}catch{Y("CheckDolls",15),window.location.reload(),D("Problem occurred while wearing a costume.")}})}},async nn(b,c=!1){let {doll:e,setId:g}={...b.pop()};await new Promise(k=>{jQuery.get(F({mod:"costumes",submod:"changeCostume",doll:e,setId:g,sh:W("sh")}),()=>{0<b.length?ff.nn(b,c):(Y("CheckDolls",15),k())})})}};let z2=localStorage.getItem("we");we=new Date(z2);aa.player.Fd<new Date&&we<new Date&&aa.player.key!=xa&&gb();if(va&&"true"===localStorage.getItem("guildBattleEnable")&&of("guildBattleEnable"))try{const b="true"===localStorage.getItem("guildBattleRandom"),
c=JSON.parse(localStorage.getItem("guildKeywords"))||[],e=await jQuery.get(F({mod:"guild_warcamp",sh:W("sh")})),g=(new DOMParser).parseFromString(e,"text/html"),k=g.querySelectorAll('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]'),h=g.querySelectorAll("table.section-like tr:not(:first-child)");let l=null;0<h.length&&0<c.length?h.forEach(q=>{const n=q.querySelector('td a[href*="mod=guild"]');q=q.querySelector('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]');if(n&&q){const m=n.textContent.trim().toLowerCase();
c.some(r=>m.includes(r.toLowerCase()))&&(l=q.getAttribute("href"))}}):b&&(l=k[Math.floor(Math.random()*k.length)].getAttribute("href"));if(l){const q=new URLSearchParams(l),n=q.get("gid"),m=q.get("sh");try{await jQuery.post(F({mod:"guild_warcamp",submod:"guild_combat",gid:n,sh:m}),{combat:"Attack!"});D(`Guild attack initiated against guild ID: ${n}`);const r=JSON.parse(localStorage.getItem("Timers"))||{};Y("guildBattleEnable",r.guildBattleEnable||120)}catch(r){D("Error initiating guild attack")}}else D("No matching guilds found for the provided guild names.")}catch(b){D("Error loading guild warcamp page")}if(va&&
"true"===localStorage.getItem("GuildEnable")&&of("GuildDonate")){const b=parseInt(localStorage.getItem("GuildDonateMore")||0,10),c=parseInt(localStorage.getItem("GuildDonateLess")||0,10),e=parseInt(localStorage.getItem("GuildDonateAmount")||0,10);if(ba.gold>=b&&ba.gold<=c){await jQuery.post(F({mod:"guildBankingHouse",submod:"donate",sh:W("sh")}),{donation:e,doDonation:"Donate"});D(`${d.Ff} ${e}.`);const g=JSON.parse(localStorage.getItem("Timers"));Y("GuildDonate",g.GuildDonate||5)}}if("true"===localStorage.getItem("throwDice")&&
"true"===localStorage.getItem("doEventExpedition")&&of("throwDice")&&"true"===sessionStorage.getItem("autoGoActive"))try{const b=await jQuery.get(F({mod:"craps",sh:W("sh")})),c=jQuery(b).find("#tossAinfo_freeplay");0<c.length?(c.attr("style")||"").includes("display: block")?(jQuery.post(window.location.protocol+"//"+window.location.host+"/game/ajax/craps.php",{type:"1",a:(new Date).getTime(),sh:W("sh")}),D(`${d.Ef}`)):D("Used all the free dices today."):D("Used all the free dices today.");Y("throwDice",
10)}catch(b){D("Please turn off throw dice feature."),localStorage.setItem("throwDice",!1)}if(of("sortSettings")&&"true"==sessionStorage.getItem("autoGoActive")){const b=await jQuery.get(F({mod:"settings",submod:"gameSettings",sh:W("sh")})),c=(new DOMParser).parseFromString(b,"text/html").querySelector('select[name="packageSorting"]');let e="in_desc";if(c){const g=c.querySelector("option[selected]");e=g?g.value:"in_desc"}Y("sortSettings",30);localStorage.setItem("PackageSort",e)}if(window.location.href.includes("index.php?mod=location&loc=")){let b=
0,c=!1;const e=()=>{fetch(window.location.href).then(n=>n.text()).then(n=>{n=(new DOMParser).parseFromString(n,"text/html");if(n=Array.from(n.querySelectorAll("img[data-tooltip]")).find(m=>{const r=m.getAttribute("data-tooltip").toLowerCase();return["owned","sahip","propri","posiad","posees"].some(w=>r.includes(w))}))n=(n=n.getAttribute("data-tooltip").match(/(Owned|Sahip[^:]*|Propri[^:]*|Posiad[^:]*|Posees[^:]*): (\d+)/i))?parseInt(n[2],10):100,document.getElementById("hourglassesLeft").textContent=
n,localStorage.setItem("hourglassesLeft",n)}).catch(()=>{D("No hourglass left")})},g=(n,m,r,w,v,x)=>{function C(B){return new Promise((J,I)=>{fetch(`${A}/game/index.php?mod=premium&submod=inventory&sh=${t}`).then(K=>K.text()).then(K=>{if(K=(new DOMParser).parseFromString(K,"text/html").querySelector(`div.premiumfeature_picture > img[src*="${B}"] + .premiumfeature_tokencount`))return K.textContent.trim();throw Error("Token value not found!");}).then(K=>fetch(`${A}/game/index.php?mod=premium&submod=inventoryActivate&feature=${"5fd403b4efa8ea7bc3ca5a852bfce9"===
B?18:5}&token=${K}&sh=${t}`)).then(()=>{J()}).catch(K=>{I(K)})})}if(!c||b>=x)h();else{var E=new URL(window.location.href),A=E.origin,t=E.searchParams.get("sh")||"",u=document.getElementById("useLifePotion").checked;w=document.getElementById("useMobilizationExp2").checked;var z=parseInt(document.getElementById("healPercentage2").value,10);E=new URLSearchParams({mod:"location",submod:"attack",location:n,stage:m,premium:r?1:0,a:Date.now(),sh:t});fetch(`${A}/game/ajax.php?${E.toString()}`).then(B=>B.text()).then(()=>
{(u||w)&&fetch(window.location.href).then(B=>B.text()).then(async B=>{B=(new DOMParser).parseFromString(B,"text/html");if(u){const J=parseInt(B.getElementById("header_values_hp_percent").textContent,10);if(Number(J)<Number(z))return await C("5fd403b4efa8ea7bc3ca5a852bfce9")}if(w&&(B=B.getElementById("expeditionpoints_value_point").innerText,0===Number(parseInt(B.replace("%",""),10))))return await C("c9ce614bbc67a9e85aa0ee87cf2bb7")}).then(async()=>{b++;b>=Number(x)?(h(),window.location.reload()):
(document.getElementById("attacksPerformed").textContent=b,localStorage.setItem("attackCount",b),await e(),setTimeout(async()=>{await g(n,m,r,w,v,x)},1E3*v))}).catch(()=>{})})}},k=async()=>{c=!0;document.getElementById("startExpedition").style.display="none";document.getElementById("stopExpedition").style.display="block";const n=(new URLSearchParams(window.location.search)).get("loc"),m=document.getElementById("monsterSelection").value,r=document.getElementById("useHourglass").checked,w=document.getElementById("attackInterval").value,
v=document.getElementById("numberOfAttacks").value;await g(n,m,r,useMobilizationExp2,w,v)},h=()=>{c=!1;document.getElementById("startExpedition").style.display="block";document.getElementById("stopExpedition").style.display="none"},l=()=>{var n=document.createElement("div");n.innerHTML=`
    <div class="expedition-settings">
      <h2 class="section-header">${d.Re}</h2>
      <div class="expedition-settings-content">
        <div>
            <label>${d.Oe}: </label>
            <select id="monsterSelection">
            <option value="1">${d.Ge}</option>
            <option value="2">${d.He}</option>
            <option value="3">${d.Ie}</option>
            <option value="4">${d.Je}</option>
            </select>
            <br>
            <label>${d.Ce}: </label>
            <input type="checkbox" id="useHourglass">
            <br>
            <label>${d.Fe}: </label>
            <input type="checkbox" id="useMobilizationExp2">
            <br>
            <label>${d.Ee}: </label>
            <input type="checkbox" id="useLifePotion">
            <br>
            <label>${d.Be}: </label>
            <input type="number" id="healPercentage2" value="25" min="1" max="99">
            <br>
            <label>${d.Me}: </label>
            <input type="number" id="numberOfAttacks" value="${document.getElementById("expeditionpoints_value_point").textContent||"0"}" min="1" max="36">
            <br>
            <label>${d.De}: </label>
            <input type="number" id="attackInterval" value="5" min="1" max="60">
            <br>
            <button id="startExpedition" class="expedition-button">${d.Pe}</button>
            <button id="resetAttacks" class="expedition-button reset-button">${d.Ne}</button>
            <button id="stopExpedition" class="expedition-button" style="display: none;">${d.Qe}</button>
            <div id="attackLog"></div>
        </div>
      </div>
    </div>
  `;var m=document.querySelector(".section-header");m.parentNode.insertBefore(n,m);n.querySelector(".section-header").addEventListener("click",()=>{const r=document.querySelector(".expedition-settings-content"),w="none"===r.style.display;r.style.display=w?"block":"none";localStorage.setItem("expeditionSettingsHidden",w?"false":"true")});n=n.querySelector(".expedition-settings-content");m="true"===localStorage.getItem("expeditionSettingsHidden");n.style.display=m?"none":"block";document.getElementById("resetAttacks").addEventListener("click",
()=>{b=0;localStorage.removeItem("attackCount");document.getElementById("attacksPerformed").textContent=b});document.getElementById("startExpedition").addEventListener("click",k);document.getElementById("stopExpedition").addEventListener("click",h);b=parseInt(localStorage.getItem("attackCount")||"0");document.getElementById("attackLog").innerHTML=`
            ${d.ze}: <span id="attacksPerformed">${b}</span><br>
            ${d.Ae}: <span id="hourglassesLeft">${localStorage.getItem("hourglassesLeft")||"0"}</span><br>
            <span class="span-new">${d.Ke}</span><br>
            <span class="span-new">${d.Le}</span>

            `};if(window.location.href.includes("index.php?mod=location&loc=")&&!window.location.href.includes("location&loc=nile_bank")&&!window.location.href.includes("index.php?mod=location&loc=false")&&!window.location.href.includes("location&loc=desert")){const n=document.querySelector("#wrapper_game.underworld");(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld||n||l()}const q=document.createElement("style");q.innerHTML="\n  .expedition-settings {\n    border: 2px solid #4CAF50;\n    padding: 10px;\n    margin: 10px 0;\n    background-color: #d3c195;\n    border-radius: 5px;\n  }\n  .expedition-button {\n    border: none;\n    padding: 10px 20px;\n    text-align: center;\n    text-decoration: none;\n    display: inline-block;\n    font-size: 16px;\n    margin: 10px;\n    background-color: #a09270;\n    cursor: pointer;\n    border-radius: 5px;\n  }\n\n  .reset-button {\n    background-color: #f44336; /* Red color */\n  }\n\n  .expedition-button:disabled {\n    background-color: #ccc;\n    cursor: not-allowed;\n  }\n";
document.head.appendChild(q)}if(window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&submod=showDungeons")||window.location.href.includes("index.php?mod=reports&submod=showArena")||window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")){let b=document.createElement("div");b.id="ReportSearchUI";b.innerHTML='\n        <div class="setting-row">\n            <h5>GLDbot - Search in Reports</h5>\n            <span>Searches for reports containing the specified keyword and gold amount. Limit 15 pages.</span>\n            <br>\n            <div class="input-container">\n                <input type="text" id="searchReports" placeholder="Enter keyword">\n                <input type="number" id="goldFilter" placeholder="Minimum gold">\n                <button class="awesome-button" id="searchReportsButton">Search</button>\n            </div>\n        </div>\n    ';
const c=document.querySelector("#content");c.insertBefore(b,c.firstChild);document.getElementById("searchReportsButton").addEventListener("click",async()=>{const h=document.getElementById("searchReports").value,l=parseInt(document.getElementById("goldFilter").value,10)||0,q=document.getElementById("searchReportsButton");q.disabled=!0;try{await e(h,l)}finally{q.disabled=!1}});async function e(h,l){let q=1;var n=await jQuery.get(window.location.href);n=jQuery(n).find(".paging_right_full");0<n.length&&
(n=n.last().attr("href"))&&(n=n.match(/page=(\d+)(?!.*page=)/))&&n[1]&&(q=parseInt(n[1],10));n=[];for(let r=1;r<=q&&15>=r;r++){var m=await g(r);m=k(m,h,l);0<m.length&&(n=n.concat(m))}if(0<n.length){const r=document.querySelector(".table-container tbody");r.innerHTML="";n.forEach(w=>{r.appendChild(w)})}}async function g(h){let l="";window.location.href.includes("index.php?mod=reports&submod=showArena")?l="showArena":window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")?l="showCircusTurma":
window.location.href.includes("index.php?mod=reports&submod=showDungeons")?l="showDungeons":window.location.href.includes("index.php?mod=reports&showExpeditions")&&(l="showExpeditions");h=F({mod:"reports",submod:l,page:h,sh:W("sh")});return await jQuery.get(h)}function k(h,l,q){let n=[];jQuery(h).find(".table-container tr").each((m,r)=>{var w=jQuery(r);m=window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&showDungeons")?w.find("td").eq(1).text().trim():
w.find("td").eq(1).find("a").first().text().trim();w=w.find("td").eq(2).text().trim().replace(/[.,]/g,"");w=parseInt(w,10)||0;m.toLowerCase().includes(l.toLowerCase())&&w>=q&&n.push(r)});return n}}if(window.location.href.includes("/index.php?mod=overview&doll=2")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(g=>Gb(g)).filter(g=>null!==g&&void 0!==g),c=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"),e=new Set([...c,...b]);try{localStorage.setItem("mercenaryEquipmentIDs",
JSON.stringify([...e]))}catch{}}else if(window.location.href.includes("/index.php?mod=overview")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(g=>Gb(g)).filter(g=>null!==g&&void 0!==g),c=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]"),e=new Set([...c,...b]);try{localStorage.setItem("playerEquipmentIDs",JSON.stringify([...e]))}catch{}}if(window.location.href.includes("/index.php?mod=inventory&sub")&&document.querySelector('td[valign="top"]')){let b=!0;
async function c(){var m=document.getElementById("sortCriteria");let r=Array.from(m.selectedOptions).map(C=>C.value),w=document.getElementById("shop");m=Array.from(w.querySelectorAll(".ui-draggable")).map(C=>{let E=Gb(C),A=parseInt(C.getAttribute("data-level"),10)||0,t=C.getAttribute("data-basis")||"",u=parseInt(t.split("-")[1],10)||0,z=parseInt(C.getAttribute("data-quality"),10)||0,B=parseInt(C.getAttribute("data-content-type"),10)||0,J=parseInt(C.getAttribute("data-measurement-x"),10)||1,I=parseInt(C.getAttribute("data-measurement-y"),
10)||1;return{element:C,name:E,level:A,jc:t,type:B,mn:u,quality:z,measurementX:J,measurementY:I,uq:parseInt(C.getAttribute("data-position-x"),10),vq:parseInt(C.getAttribute("data-position-y"),10)}});m.sort((C,E)=>{for(let A of r){let t;switch(A){case "name":t=C.name.localeCompare(E.name);break;case "level":t=C.level-E.level;break;case "data-basis":t=C.mn-E.mn;break;case "quality":t=C.quality-E.quality;break;case "type":t=C.type-E.type;break;default:t=0}if(0!==t)return t}return 0});let v=0,x=0;for(let C of m)C.element.setAttribute("data-position-x",
v+1),C.element.setAttribute("data-position-y",x+1),C.element.style.left=`${32*v}px`,C.element.style.top=`${32*x}px`,v+=C.measurementX,6<=v&&(v=0,x+=1);w.innerHTML="";m.forEach(C=>{w.appendChild(C.element)})}(function(){let m=`
                <section class="merchant-settings" style="display: block;">
                    <div class="sorting-options">
                        <label for="sortCriteria">Sort Items By:</label>
                        <select id="sortCriteria">
                            <option value="name">Name</option>
                            <option value="level">Level</option>
                            <option value="data-basis">Base</option>
                            <option value="type">Type</option>
                            <option value="quality">Quality</option>
                        </select>
                        <button class="awesome-button" type="button" id="sortItemsButton">Sort Items</button>
                        
                    </div>
                    <p>
                    <div class="actions">
                        <button class="awesome-button" type="button">${d.Mj}</button>
                        <button class="awesome-button" type="button">${d.Nj}</button>
                        <button class="awesome-button" type="button">Buy All</button>
                        <button class="awesome-button" type="button">Buy 10</button>
                    </div>
                    <ul class="compact-list">
                        <li><input type="checkbox" id="chkWeapons"><label for="chkWeapons">${d.ga}</label></li>
                        <li><input type="checkbox" id="chkShields"><label for="chkShields">${d.da}</label></li>
                        <li><input type="checkbox" id="chkChestArmour"><label for="chkChestArmour">${d.W}</label></li>
                        <li><input type="checkbox" id="chkHelmets"><label for="chkHelmets">${d.Z}</label></li>
                        <li><input type="checkbox" id="chkGloves"><label for="chkGloves">${d.Y}</label></li>
                        <li><input type="checkbox" id="chkShoes"><label for="chkShoes">${d.ea}</label></li>
                        <li><input type="checkbox" id="chkRings"><label for="chkRings">${d.ca}</label></li>
                        <li><input type="checkbox" id="chkAmulets"><label for="chkAmulets">${d.V}</label></li>
                        <li><input type="checkbox" id="chkUsable"><label for="chkUsable">${d.Ci}</label></li>
                        <li><input type="checkbox" id="chkUpgrades"><label for="chkUpgrades">${d.Bi}</label></li>
                        <li><input type="checkbox" id="chkRecipes"><label for="chkRecipes">${d.dh}</label></li>
                        <li><input type="checkbox" id="chkMercenary"><label for="chkMercenary">${d.sg}</label></li>
                        <li><input type="checkbox" id="chkScroll"><label for="chkScroll">Scroll</label></li>
                        <li><input type="checkbox" id="chkReinforcements"><label for="chkReinforcements">${d.fh}</label></li>
                    </ul>
                </section>
                `;document.getElementById("inv").insertAdjacentHTML("afterend",m)})();async function e(){if(b){var m=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(r=>{r=r.getAttribute("data-content-type");if(document.getElementById("chkWeapons").checked&&"2"==r||document.getElementById("chkShields").checked&&"4"==r||document.getElementById("chkChestArmour").checked&&"8"==r||document.getElementById("chkHelmets").checked&&"1"==r||document.getElementById("chkGloves").checked&&"256"==
r||document.getElementById("chkShoes").checked&&"512"==r||document.getElementById("chkRings").checked&&"48"==r||document.getElementById("chkAmulets").checked&&"1024"==r||document.getElementById("chkUsable").checked&&"4096"==r||document.getElementById("chkUpgrades").checked&&"4096"==r||document.getElementById("chkRecipes").checked&&"8192"==r||document.getElementById("chkMercenary").checked&&"16384"==r||document.getElementById("chkScroll").checked&&"64"==r||document.getElementById("chkReinforcements").checked&&
"4096"==r)return!0;if(b)return!1});for(let r=0;r<m.length&&b;r++)await new Promise(w=>setTimeout(w,200)),ea(m[r],"shop")}}async function g(){if(b){var m=document.querySelectorAll("#inv .ui-draggable");for(let r=0;r<m.length;r++)await new Promise(w=>setTimeout(w,200)),ea(m[r],"shop")}}async function k(){if(b){var m=document.querySelectorAll("#shop .ui-draggable");for(let r=0;r<m.length;r++)await new Promise(w=>setTimeout(w,200)),ea(m[r],"inv")}}async function h(){if(b){var m=document.querySelectorAll("#shop .ui-draggable");
for(let r=0;10>r;r++)await new Promise(w=>setTimeout(w,200)),ea(m[r],"inv")}}let l=document.querySelector(".actions .awesome-button:nth-child(2)"),q=document.querySelector(".actions .awesome-button:nth-child(3)"),n=document.querySelector(".actions .awesome-button:nth-child(4");document.querySelector(".actions .awesome-button:nth-child(1)").addEventListener("click",async()=>{b=!0;await new Promise(m=>setTimeout(m,500));g()});l.addEventListener("click",async()=>{b=!0;await new Promise(m=>setTimeout(m,
500));e()});q.addEventListener("click",async()=>{await new Promise(m=>setTimeout(m,500));k()});n.addEventListener("click",async()=>{await new Promise(m=>setTimeout(m,500));h()});document.getElementById("sortItemsButton").addEventListener("click",async()=>{await new Promise(m=>setTimeout(m,500));await c()})}if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll"))if(df=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),
tb=df.textContent.trim(),2<tb.length){ef=document.getElementById("char");function b(c,e,g,k){var h=document.createElement("a");h.className="gladbot-button gladbot-"+c;h.textContent=e;h.setAttribute("data-tooltip",g);ef.appendChild(h);(JSON.parse(localStorage.getItem(k))||[]).includes(tb)&&(h.classList.add("added"),h.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));h.addEventListener("click",function(){var l=tb,q=JSON.parse(localStorage.getItem(k))||[],n=q.indexOf(l);
-1!==n?(q.splice(n,1),h.classList.remove("added"),h.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(q.push(l),h.classList.add("added"),h.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));localStorage.setItem(k,JSON.stringify(q))})}b("arena","A","GladB: Add to Arena List","autoAttackList");b("circus","C","GladB: Add to Circus List","autoAttackCircusList")}var Pc=JSON.parse(localStorage.getItem("smeltingSettings"))||[],Da=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||
{itemTypes:[],colors:[],hammerState:"none",enabled:!1},gc=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]};"true"==localStorage.getItem("pauseBotEnable")&&of("pauseBot")&&(sessionStorage.setItem("autoGoActive","false"),localStorage.setItem("pauseBotEnable","false"),alert("Bot has been paused!"),window.location.reload());1==va&&of("storeForgeResources")&&fj();!0===va&&of("Training")&&"true"==localStorage.getItem("trainEnable")&&hj()&&await gj();"true"===sessionStorage.getItem("autoGoActive")&&
bb.href.includes("submod=showCombatReport")&&ij();if("true"===localStorage.getItem("HighlightUnderworldItems")){function b(e){e.querySelectorAll("div[data-basis]").forEach(g=>{const k=g.getAttribute("data-basis"),h=g.getAttribute("data-hash");g.getAttribute("data-level");null!=k&&wb(k,h)&&(g.style.boxShadow="0 0 0.1px 2px red")})}b(document);const c=new MutationObserver(e=>{e.forEach(g=>{g.addedNodes&&g.addedNodes.forEach(k=>{1===k.nodeType&&b(k)})});c.disconnect()});c.observe(document.body,{childList:!0,
subtree:!0});document.querySelectorAll(".awesome-tabs").forEach(e=>{e.addEventListener("click",()=>{setTimeout(()=>{b(document)},500)})})}if("true"==localStorage.getItem("AutoAuction")){const b=JSON.parse(localStorage.getItem("searchTerms")||"[]"),c=JSON.parse(localStorage.getItem("SearchTypes")||"[]"),e=JSON.parse(localStorage.getItem("Timers")),g=new DOMParser;function k(n,m,r){let w=[],v=[];Array.from(n).forEach(x=>{const C=x.getAttribute("data-tooltip");var E=x.getAttribute("data-content-type");
const A=x.getAttribute("data-quality"),t=m.some(u=>{const z=$e(C);return z?z.toLowerCase().split(/\s+/).includes(u.toLowerCase()):!1});E=r.includes("9999")||r.includes(E);"2"==A||"3"==A?v.push(x):t&&E&&w.push(x)});return{Pn:w,Sn:v}}if(of("ShopSearch")){const n=await If();let m=[],r=[];for(const x of n){const C=k(x.querySelectorAll("#shop .ui-draggable"),b,c);C.Pn.forEach(E=>{E.setAttribute("data-original-url",x.Vm)});C.Sn.forEach(E=>{E.setAttribute("data-original-url",x.Vm)});m=m.concat(C.Pn);r=r.concat(C.Sn)}const w=
m.map(x=>x.outerHTML);localStorage.setItem("MatchingShopItems",JSON.stringify(w));const v=r.map(x=>x.outerHTML);localStorage.setItem("UniqueShopResults",JSON.stringify(v));Y("ShopSearch",e.SearchTimer||5)}if(of("AuctionSearch")){const n=await fh(),m=await fh(3),r=x=>Array.from(x.querySelectorAll('#auction_table [class^="item-i-"]')).filter(C=>{const E=C.getAttribute("data-tooltip");var A=C.getAttribute("data-content-type");C=b.some(t=>{const u=$e(E);return u?u.toLowerCase().split(/\s+/).includes(t.toLowerCase()):
!1});A=c.includes("9999")||c.includes(A);return C&&A}),w=r(n);localStorage.setItem("MatchingAuctionItems",JSON.stringify(w.map(x=>x.outerHTML)));const v=r(m);localStorage.setItem("MatchingMercAuctionItems",JSON.stringify(v.map(x=>x.outerHTML)));Y("AuctionSearch",e.SearchTimer||5)}function h(n,m,r){const w=document.createElement("div");w.setAttribute("id",r);w.classList.add("search_results_panel");var v=document.createElement("div");v.classList.add("panel-header");v.innerHTML=`<h2>${n}</h2>`;w.appendChild(v);
w.style.cssText="\n                position: fixed;\n                left: 0;\n                top: 0;\n                width: 300px;\n                height: 400px; /* Set a default height */\n                overflow-y: auto; /* Allow both vertical and horizontal scrolling if needed */\n                overflow-x: hidden;\n                z-index: 500;\n                box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n                font-family: 'Arial', sans-serif;\n                background: rgba(221, 213, 180, 0.95);\n                background-size: cover;\n                border-radius: 8px;\n            ";
n=w.querySelector(".panel-header");n.style.cssText=`
                background-color: ${"auction_items_panel"===r?"#bead79":"#8b6a45"};
                padding: 10px;
                cursor: move; /* Set cursor to move only on the header */
                user-select: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            `;n.querySelector("h2").style.cssText="\n                margin: 0;\n                font-size: 16px;\n                color: #fff;\n            ";n=localStorage.getItem(`${r}_top`);v=localStorage.getItem(`${r}_left`);let x=localStorage.getItem(`${r}_width`),C=localStorage.getItem(`${r}_height`);n&&v?(w.style.top=n+"px",w.style.left=v+"px"):"auction_items_panel"===r?(w.style.top="50px",w.style.left="20px"):"shop_items_panel"===r&&(w.style.top="50px",w.style.left="350px");x&&(w.style.width=
x+"px");C&&(w.style.height=C+"px");q(w,r);m=l(m);w.appendChild(m);document.body.appendChild(w);w.style.maxHeight=`${window.innerHeight-100}px`}function l(n){const m=document.createElement("div");m.classList.add("items-container");n.forEach(({key:r,label:w})=>{const v=document.createElement("div");v.classList.add("section-header");v.textContent=w;m.appendChild(v);const x=document.createElement("div");x.classList.add("grid-container");x.style.display="grid";x.style.gridTemplateColumns="repeat(auto-fill, minmax(50px, 1fr))";
x.style.aq="5px";x.style.padding="10px";w=localStorage.getItem(r);(JSON.parse(w)||[]).forEach(C=>{const E=g.parseFromString(C,"text/html").body.firstChild.cloneNode(!0);E.style.left="";E.style.top="";E.style.position="relative";C=E.getAttribute("data-tooltip");var A=JSON.parse(C.replace(/&quot;/g,'"'));C=A[0][0][1].split(";")[0];const t=encodeURIComponent(A[0][0][0].split(" ")[0]);A=new URL(window.location.href);const u=A.origin,z=A.searchParams.get("sh")||"";A=document.createElement("div");A.classList.add("auction_item_div");
A.appendChild(E);A.style.border="2px solid "+C;A.style.borderRadius="4px";A.style.padding="2px";A.style.boxSizing="border-box";A.style.cursor="pointer";A.style.transform="scale(0.8)";A.addEventListener("click",()=>{var B=E.getAttribute("data-hash");localStorage.setItem("highlightedItemHash",B);if(["UniqueShopResults","MatchingShopItems"].includes(r)){if(B=E.getAttribute("data-original-url"))location.href=B}else B=`${u}/game/index.php?mod=auction&qry=${t}&itemLevel=1&itemType=0&itemQuality=-1&sh=${z}`,
"MatchingMercAuctionItems"===r&&(B+="&ttype=3"),location.href=B});x.appendChild(A)});m.appendChild(v);m.appendChild(x)});return m}function q(n,m){const r=n.querySelector(".panel-header");$(n).draggable({handle:r,Mp:"window",stop:function(w,v){localStorage.setItem(`${m}_top`,v.position.top);localStorage.setItem(`${m}_left`,v.position.left)}});$(n).resizable({bq:"n, e, s, w, ne, se, sw, nw",stop:function(w,v){localStorage.setItem(`${m}_width`,v.size.width);localStorage.setItem(`${m}_height`,v.size.height)}})}
(function(){document.querySelectorAll(".search_results_panel").forEach(n=>n.remove());h(`${d.Wa}`,[{key:"MatchingAuctionItems",label:`${d.Wa}`},{key:"MatchingMercAuctionItems",label:`${d.rg}`}],"auction_items_panel");h(`${d.Xb}`,[{key:"MatchingShopItems",label:`${d.Xb}`},{key:"UniqueShopResults",label:`${d.Ai}`}],"shop_items_panel")})()}setInterval(()=>{if(document.hidden)try{chrome.runtime.sendMessage({Gn:!0,Em:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"}),console.log("Wake up.")}catch(b){}},
6E4);var Cj=btoa("autoGoActive"),Dj=btoa("false");await async function(){"ca4faec7ce71824492994c57beaea6a2ffb35c6f925fe1d7f7f6d6a7e4e27624"!==await jj(ta)&&sessionStorage.setItem(atob(Cj),atob(Dj))}();setInterval(()=>{const b=JSON.parse(localStorage.getItem("timeConditions"))||[];var c="true"===localStorage.getItem("botPaused");if(b&&0<b.length&&!c&&Kc()){c=new Date;const e=`${String(c.getHours()).padStart(2,"0")}:${String(c.getMinutes()).padStart(2,"0")}`;b.forEach(g=>{g.start&&g.end&&(g.start>g.end?
e>=g.start||e<=g.end:e>=g.start&&e<=g.end)&&("stop"===g.action?sessionStorage.setItem("autoGoActive","false"):"start"===g.action&&"false"===sessionStorage.getItem("autoGoActive")&&(sessionStorage.setItem("autoGoActive","true"),af()))})}},15E3);var Wb=(new Date).getTime();if(!xa!==Lc){"true"===localStorage.getItem("activateAuction2")&&lf();var gf={en(b){let c=localStorage.getItem("MarketboughtItems");c?c=JSON.parse(c):c=[];c.push(b);localStorage.setItem("MarketboughtItems",JSON.stringify(c))},Mq(){var b=
localStorage.getItem("boughtItems");b?b=JSON.parse(b):b=[];let c=document.getElementById("boughtItems");for(;c.firstChild;)c.removeChild(c.firstChild);for(let e of b)b=document.createElement("option"),b.textContent=e,c.appendChild(b)},async lo(){var b=new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=parseInt(localStorage.getItem("MarketHoldGold"))||0;let g=localStorage.getItem("marketItems");g=g?JSON.parse(g):[];const k={Ap:"1",wp:"2",op:"3",rp:"4",qp:"5",xp:"8",up:"6",
mp:"9",zp:"7",np:"11",yp:"12",tp:"13",sp:"15",pp:"18",Jp:"19",vp:"20"},h={ao:"-1",Vn:"0",Tn:"1",Xn:"2",Wn:"3",Yn:"4"};D(`${d.Cf}`);const l={};if("true"===localStorage.getItem("marketOnlyFood"))c=await this.pn(c,e,"-1"),await this.Hn([],7,1,c,b);else{for(var q of g){const n=`${k[q.itemType]||"0"}-${h[q.rarity]||"0"}`;l[n]||(l[n]=[]);l[n].push(q)}q=g.map(n=>h[n.rarity]||"0");q=Math.min(...q);c=await this.pn(c,e,q);for(const [n,m]of Object.entries(l)){const [r,w]=n.split("-");await this.Hn(m,r,w,c,b)}}},
async pn(b,c,e){const g="true"===localStorage.getItem("marketOnlyFood");let k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=0&fq=${e}`;g&&(k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=7&fq=${e}`);c=await fetch(k).then(A=>A.text());b=new DOMParser;e=b.parseFromString(c,"text/html").querySelector(".standalone");c=1;e&&(c=parseInt(e.textContent.split("/")[1],10));e=[];const h=localStorage.getItem("MarketMaxFoodPrice")||1E5,l=localStorage.getItem("MarketMaxPerFoodPrice")||
1E3,q=localStorage.getItem("MarketMinItemLevel")||1;let n=0;for(let A=1;A<=c;A++){var m=`${k}&p=${A}`;await new Promise(t=>setTimeout(t,250));m=await (await fetch(m)).text();await new Promise(t=>setTimeout(t,250));m=b.parseFromString(m,"text/html").querySelectorAll("#market_item_table tr");for(let t of m){var r=t.querySelectorAll("td");if(r&&0<r.length&&(m=r[0].querySelector("div"))){var w=ub(m),v=Ba(m),x=Gb(m),C=vb(m);let u=m.getAttribute("data-item-id"),z=m.getAttribute("data-soulbound-to");r=parseInt(r[2].innerText.replace(/\./g,
""),10);var E=parseInt(m.getAttribute("data-amount"),10)||1;E=r/E;if(g&&"64"===w&&r<=l&&(!z||null===z)&&Number(C)>=Number(q)){if(n+r>h)break;n+=r;e.push({itemRarity:v,itemName:x,itemDataId:u,itemSoulbound:z,itemPrice:r,pricePerItem:E,page:A})}else g||(w=Ba(m),v=Gb(m),x=m.getAttribute("data-item-id"),C=m.getAttribute("data-soulbound-to"),m=parseInt(m.getAttribute("data-amount"),10)||1,e.push({itemRarity:w,itemName:v,itemDataId:x,itemSoulbound:C,itemPrice:r,pricePerItem:r/m,page:A}))}}if(g&&n>=h)break}return e},
async Hn(b,c,e,g,k){for(const h of g){const l=h.itemName;g=h.itemDataId;const q=h.itemSoulbound,n=h.itemPrice,m=h.pricePerItem,r=h.page,w={ao:"-1",Vn:"0",Tn:"1",Xn:"2",Wn:"3",Yn:"4"},v=localStorage.getItem("usePacks")||"false";if("true"===localStorage.getItem("marketOnlyFood"))ba.gold>=n+k&&(!q||null===q)&&await jQuery.get(F({}),{mod:"market",buyid:g,sh:W("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}).then(x=>{x=(new DOMParser).parseFromString(x,"text/html").getElementById("sstat_gold_val").innerText;
x=parseInt(x.replace(/\./g,""),10);if(document.getElementById("sstat_gold_val").innerText=x)ba.gold=x;gf.en(l);D(`Bought ${l} for ${n} gold`)});else try{b.some(x=>{const C=w[x.rarity]||"0";return l.trim().toLowerCase().includes(x.itemToBuy.trim().toLowerCase())&&e==C&&ba.gold>=n+k&&(!q||null===q||"BuySoulbound"===x.Soulbound&&q||"DontBuySoulbound"===x.Soulbound&&!q)&&(Number(x.maxPrice)>=n||"true"==v&&Number(x.maxPrice)>=m&&ba.gold>=n)})&&await jQuery.get(F({}),{mod:"market",buyid:g,sh:W("sh"),qry:"",
seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}).then(x=>{x=(new DOMParser).parseFromString(x,"text/html").getElementById("sstat_gold_val").innerText;x=parseInt(x.replace(/\./g,""),10);if(document.getElementById("sstat_gold_val").innerText=x)ba.gold=x;gf.en(l);D(`Bought ${l} for ${n} gold`)})}catch(x){D(`${d.cg}`),await new Promise(C=>setTimeout(C,2E3)),window.location.reload()}}D(`${d.yb} in Market`)}};(window.location.href.includes("/index.php?mod=forge&submod=workbench")||window.location.href.includes("/index.php?mod=forge&doll=1&submod=workbench")||
window.location.href.includes("index.php?mod=forge&doll=2&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=3&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=4&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=5&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=6&submod=workbench"))&&lj();var Ej={async start(){try{const b=aa.workbench.repairArena,c=aa.workbench.repairTurma;let e=this.F(),g=this.Eo(e),
k=this.Bn("itemList1"),h=this.Bn("itemList2");const l=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];g?(await this.u(),await this.$o(g,l)):b&&0<k.length?await this.tn("mod=overview&doll=1",aa.workbench.itemList1):c&&0<h.length&&await this.tn("mod=overview&doll=2",aa.workbench.itemList2)}catch(b){this.handleError()}},F(){let b=localStorage.getItem("workbenchItem");return b?JSON.parse(b):{selectedItem:{}}},Eo(b){try{return b.selectedItem&&0<Object.keys(b.selectedItem).length?b.selectedItem:
!1}catch(c){return null}},Bn(b){return(b=localStorage.getItem(b))?this.fp(b):[]},fp(b){try{let c=JSON.parse(b);return Array.isArray(c)&&c.every(e=>void 0===e)?[]:c}catch(c){return[]}},async tn(b,c){mf!==b?Hf(b):(await this.u(),0<this.F().spaces?await this.um(c):this.Mn("workbench"))},Mn(b){"space"===b?D("Not enough inventory space for repair. Retrying in 10 minutes."):"workbench"===b?D("Not enough empty slots in workbench. Retrying in 10 minutes."):"material"===b?D(`${d.ua}`):D("Repair: Retrying in 10 minutes.");
b=JSON.parse(localStorage.getItem("Timers"));Y("repair",b.Repair||10);window.location.reload()},async $o(b,c,e){switch(b.status){case "toWorkbench":await this.pj(b.iid);break;case "toFillGoods":0<c.length&&e.workbenchneededitems?await this.bj(b.slot,-1,e.workbenchneededitems):await this.kc(b.slot);break;case "toPackage":await this.dd(b.slot);break;case "toBag":await this.Ia();break;case "toInv":await this.gm();break;case "workbenchToBag":await this.Cn(b.slot)}},handleError(){localStorage.removeItem("workbenchItem");
const b=JSON.parse(localStorage.getItem("Timers"));Y("repair",b.Repair||10);window.location.reload()},async u(){try{const b=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});let c=this.F();c.slots=JSON.parse(b).slots;c.spaces=c.slots.filter(e=>"closed"===e["forge_slots.state"]).length;c.freeSlots=c.slots.filter(e=>"closed"===e["forge_slots.state"]);localStorage.setItem("workbenchItem",JSON.stringify(c))}catch(b){}},async um(b){try{let c=
b.shift();D(`${d.Sf}${c.name}`);D(`${d.wa}`);let {spot:e,bag:g}=await ac(c.yn,c.zn);const k=await jQuery.post(T({}),{mod:"inventory",submod:"move",from:c.container,fromX:1,fromY:1,to:g,toX:e.x+1,toY:e.y+1,amount:1,doll:c.doll,a:(new Date).getTime(),sh:W("sh")});let h=this.F();h.selectedItem||(h.selectedItem={});Object.assign(h.selectedItem,{item:c,iid:JSON.parse(k).to.data.itemId,status:"toWorkbench",spot:e,bag:g});localStorage.setItem("workbenchItem",JSON.stringify(h));await this.pj(JSON.parse(k).to.data.itemId)}catch{D("Error repairing the item."),
localStorage.setItem("workbenchItem",JSON.stringify({})),window.location.reload()}},async pj(b){try{D(`${d.Ab}`);let c=this.F(),e=0;for(let k of c.slots||[])if("closed"===k["forge_slots.state"]){e=k["forge_slots.slot"];break}const g=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:e,iid:b,amount:1,a:(new Date).getTime(),sh:W("sh")});c.slots=JSON.parse(g).slots;c.spaces=0;c.freeSlots=[];for(let k of c.slots)"closed"===k["forge_slots.state"]&&(c.spaces++,c.freeSlots.push(k));
e=c.freeSlots.shift()["forge_slots.slot"];c.workbenchneededitems=JSON.parse(g).slots[e].formula.needed;c.workbenchneededitems||(D(`${d.ua}`),Object.assign(c.selectedItem,{status:"toBag"}),D("Error moving the item to the workbench."),localStorage.setItem("workbenchItem",JSON.stringify(c)),window.location.reload());Object.assign(c.selectedItem,{slot:e,status:"toFillGoods"});localStorage.setItem("workbenchItem",JSON.stringify(c));await this.cp(e,b)}catch(c){D("Error moving the item to the workbench."+
c),window.location.reload()}},async cp(b,c){await jQuery.post(T({}),{mod:"forge",submod:"rent",mode:"workbench",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")});c=this.F();Object.assign(c.selectedItem,{slot:b,status:"toFillGoods"});localStorage.setItem("workbenchItem",JSON.stringify(c));0<(JSON.parse(localStorage.getItem("ignoredMaterials"))||[]).length?await this.bj(b,-1,c.workbenchneededitems):await this.kc(b)},async bj(b,c,e){c=[];const g=JSON.parse(localStorage.getItem("ignoredMaterials"))||
[];for(let k in e){const h=parseInt(k,10);0<e[k].amount&&!g.some(l=>parseInt(l,10)+18E3===h)&&c.push({type:h,amount:e[k].amount})}await this.Il(c,-1,b);await new Promise(k=>setTimeout(k,2E3));await jQuery.post(T({mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}));e=this.F();e.selectedItem.status="toPackage";localStorage.setItem("workbenchItem",JSON.stringify(e));await this.dd(b)},async Il(b,c=-1,e){let g=!0;for(let l=0;l<b.length;l++){var k=c;let q=!1,n=b[l].amount;
b[l].type=b[l].type-18E3;let m=await this.Ho(b[l].type);const r=Number(localStorage.getItem("repairMaxQuality"));for(;k<=r&&0<n;k++){var h=m[k]||0;if(0!==h){h=Math.min(n,h);n-=h;try{if(await jQuery.post(T({mod:"forge",submod:"storageOut",type:b[l].type,quality:k,amount:h,a:(new Date).getTime(),sh:W("sh")})),await new Promise(w=>setTimeout(w,500)),await this.Jl(b[l].type,k,e,h),q=!0,0>=n)break}catch(w){console.error(w)}}}if(!q||0<n)g=!1}return g},async Ho(b){let c={};try{const e=await jQuery.get(F({mod:"forge",
submod:"storage",sh:W("sh")})),g=jQuery(e).find("#change-resource-amount").attr("data-max");if(g){const k=JSON.parse(g.replace(/&quot;/g,'"'));k[b]&&(c=k[b])}}catch(e){console.error("Failed to fetch material quantities:",e)}return c},async Jl(b,c,e,g){let k=1,h=!1,l=this.F(),{bag:q,spot:n}=l.selectedItem||{};for(;!h&&5>=k;)try{const m=await jQuery.get(F({mod:"packages",f:18,fq:c,qry:"",page:k,sh:W("sh")})),r=jQuery(m).find(".packageItem");0===r.length?k++:(r.each(async(w,v)=>{try{let x=jQuery(v).find(".ui-draggable"),
C=Ea(x[0]).split("-")[1],E=Ba(x[0]),A=x.context.querySelector("input").getAttribute("value");if(Number(C)==Number(b)&&Number(E)==Number(c)){h=!0;try{const t=await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+A,fromX:1,fromY:1,to:q,toX:n.x+1,toY:n.y+1,amount:g}),{a:(new Date).getTime(),sh:W("sh")}),u=JSON.parse(t).to.data.itemId;try{await jQuery.post(T({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:u,amount:g,a:(new Date).getTime(),sh:W("sh")}))}catch(z){D(`Error moving material to workbench: ${z}`)}}catch(t){D(`Error moving material from package to bag: ${t}`)}return!1}}catch(x){D(`Error processing package item: ${x}`)}}),
h||k++)}catch(m){D(`Error fetching materials from the package on page ${k}: ${m}`),k++}h||D(`Material of type ${b} and quality ${c} not found in packages.`)},async kc(b,c=-1){let e=this.F();await jQuery.post(T({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:W("sh")});c<Number(localStorage.getItem("repairMaxQuality"))?await this.kc(b,++c):(await jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}),
e.selectedItem.status="toPackage",localStorage.setItem("workbenchItem",JSON.stringify(e)),await this.dd(b))},async dd(b){D(`${d.Rf}`);let c=this.F();c.selectedItem.status="workbenchToBag";localStorage.setItem("workbenchItem",JSON.stringify(c));let e;try{(e=1100*c.slots[b].formula.duration)||(e=12E3)}catch(g){e=12E3}await new Promise(g=>setTimeout(g,e));await this.Cn(b)},async Cn(b){let c=this.F();(await jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),
sh:W("sh")})).includes("document.location.href=document.location.href")?(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c))):(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c)),await jQuery.post(T({}),{mod:"forge",submod:"cancel",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}));await this.Ia()},async rq(b=1){D(`${d.wa}`);let c=await this.F(),{item:e,bag:g,spot:k}=c.selectedItem,h=!1;
try{const v=await jQuery.get(F({}),{mod:"packages",f:-1,fq:e.quality,qry:e.name,page:b,sh:W("sh")});let x=jQuery(v).find(".packageItem").toArray();0===x.length&&D(`No package items found on page: ${b}`);for(let C of x){let E=C.querySelector(".ui-draggable");Ca(E);var l=Ba(E),q=Gb(E);C.getAttribute("data-soulbound-to");var n=E.getAttribute("data-measurement-x"),m=E.getAttribute("data-measurement-y"),r=C.querySelector("[data-container-number]").getAttribute("data-container-number"),w=C.querySelector('input[name="packages[]"]').value;
if(q===e.name&&e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===l)h=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.Dn(C,g,k,r,n,m)}3<b?this.handleError():h||await this.Ia(++b,!0)}catch(v){D(`Error repairing the item. ${v}`),this.Kn(),window.location.reload()}},async Ia(b=1){D(`${d.wa}`);let c=await this.F(),{item:e,bag:g,spot:k}=c.selectedItem,h=!1;e.quality=e?.quality??0;try{const v=await jQuery.get(F({}),{mod:"packages",
f:-1,fq:e.quality,qry:e.name,page:b,sh:W("sh")});let x=jQuery(v).find(".packageItem").toArray();0===x.length&&D(`No package items found on page: ${b}`);for(let C of x){let E=C.querySelector(".ui-draggable");Ca(E);var l=Ba(E)??0,q=Gb(E);C.getAttribute("data-soulbound-to");var n=E.getAttribute("data-measurement-x"),m=E.getAttribute("data-measurement-y"),r=C.querySelector("[data-container-number]").getAttribute("data-container-number"),w=C.querySelector('input[name="packages[]"]').value;if(q===e.name&&
e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===l)h=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.Dn(C,g,k,r,n,m)}3<b?this.handleError():h||await this.Ia(++b,!0)}catch(v){D(`Error repairing the item. ${v}`),this.Kn(),window.location.reload()}},async Dn(b,c,e,g,k,h){await ac(k,h,async(l,q)=>{await jQuery.post(T({}),{mod:"inventory",submod:"move",from:g,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+1,amount:1,a:(new Date).getTime(),
sh:W("sh")});await this.gm(g,l,q)})},async gm(b,c,e){D("Trying to move repaired item to the equpiment.");b=this.F();let {item:g}=b.selectedItem;c=await jQuery.post(T({}),{mod:"inventory",submod:"move",from:e,fromX:c.x+1,fromY:c.y+1,to:g.container,toX:1,toY:1,amount:1,doll:g.doll,a:(new Date).getTime(),sh:W("sh")});c.includes(`"data":{"containerNumber":${g.container}`)?(Object.assign(b.selectedItem,{status:"toInv"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),await this.Co(c,g)):(Object.assign(b.selectedItem,
{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),window.location.reload())},async Co(b,c){let e,g,k=localStorage.getItem("repairPercentage")||10;try{e=JSON.parse(b).to.data.tooltip.pop().pop()[0].match(/\d+/g),g=Number(e[0])/Number(e[1])*100}catch(h){location.reload()}g<parseInt(k,10)?(this.ip(c.container,2===c.doll),D(`${d.ua}`)):(D(`${d.Uf}`),ka("itemRepaired",0));b=this.F();delete b.selectedItem;localStorage.setItem("workbenchItem",JSON.stringify(b));window.location.reload()},
ip(b,c=!1){const e=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),k=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),h=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}"),l={2:"helmet",11:"necklace",3:"weapon",5:"armor",4:"shield",9:"gloves",10:"shoes",6:"rings1",7:"rings2"},q={2:"helmetM",11:"necklaceM",3:"weaponM",5:"armorM",4:"shieldM",9:"glovesM",10:"shoesM",6:"rings1M",7:"rings2M"};b=c?
q[b]:l[b];c?g[b]&&(g[b]=!1,h[b]=Date.now(),localStorage.setItem("activeItemsMercenary",JSON.stringify(g)),localStorage.setItem("disabledTimeMercenary",JSON.stringify(h))):e[b]&&(e[b]=!1,k[b]=Date.now(),localStorage.setItem("activeItemsGladiator",JSON.stringify(e)),localStorage.setItem("disabledTimeGladiator",JSON.stringify(k)))},Kn(){this.Mn()}},Aj={im:[],async ep(b){try{let e;const g=parseInt(localStorage.getItem("smeltTab"),10)||1;D("Repairing before smelting, please wait...");1===g?e=514:2===g?
e=515:3===g?e=516:4===g?e=517:5===g?e=518:6===g&&(e=519);const k=await this.Bo(b);if(k){var c=await this.Vo(b);if(null===c)console.error("Failed to move item to workbench.");else return await this.Zm(c),await this.lp(c),await this.no(c,e,k)}else console.error(`Item with ID ${b} not found in inventory.`)}catch(e){}},async Bo(b){let c=null;document.querySelectorAll("#inv .ui-draggable").forEach(e=>{if(e.getAttribute("data-item-id")===b){const g=parseInt(e.getAttribute("data-position-x"),10)+1,k=parseInt(e.getAttribute("data-position-y"),
10)+1,h=Ba(e);e=Gb(e).toLowerCase();c={container:"inv",x:g,y:k,quality:h,name:e};return!1}});return c},async Vo(b){const c=await this.Do();if(null===c)return D("No available workbench slots. Continuing without repair."),!1;const e=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:c,iid:b,amount:1,a:(new Date).getTime(),sh:W("sh")});if("0"===(localStorage.getItem("PartialOrFull")||"0"))try{this.im=JSON.parse(e).slots[c].formula.needed}catch{D("Error getting needed items for repair.")}await jQuery.post(T({}),
{mod:"forge",submod:"rent",mode:"workbench",slot:c,rent:2,item:b,a:(new Date).getTime(),sh:W("sh")});return c},async Do(){var b=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});b=JSON.parse(b).slots;let c=null;for(let e of b)if("closed"===e["forge_slots.state"]){c=e["forge_slots.slot"];break}return c},async Zm(b){"0"===(localStorage.getItem("PartialOrFull")||"0")&&0<Object.keys(this.im).length?await this.bj(b):await this.Ao(b);
await jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")})},async Ao(b){const c=localStorage.getItem("repairBeforeSmeltMaxQuality")||1;await jQuery.post(T({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:W("sh")})},async bj(b){let c=[];const e=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let g in this.im){const k=parseInt(g,10);0<this.im[g].amount&&!e.some(h=>parseInt(h,10)+
18E3===k)&&c.push({type:k,amount:this.im[g].amount})}await this.Il(c,-1,b)},async Il(b,c=-1,e){for(let g=0;g<b.length;g++){let k=c,h=0,l=1;2>=b[g].amount&&(l=1);for(b[g].type=b[g].type-18E3;k<=Number(localStorage.getItem("repairMaxQuality"))&&h<l;)try{if(await jQuery.post(T({mod:"forge",submod:"storageOut",type:b[g].type,quality:k,amount:1,a:(new Date).getTime(),sh:W("sh")})),await this.Jl(b[g].type,k,e,1),h++,h<=l)break}catch(q){if(k++,k>Number(localStorage.getItem("repairMaxQuality")))break}}},
async Jl(b,c,e,g){let k=1,h=!1,{spot:l,bag:q}=await ac(1,1);for(;!h&&5>=k;)try{const n=await jQuery.get(F({mod:"packages",f:18,fq:c,qry:"",page:k,sh:W("sh")})),m=jQuery(n).find(".packageItem");if(0===m.length){k++;continue}let r=!1;m.each((w,v)=>{try{let x=jQuery(v).find(".ui-draggable"),C=Ea(x[0]).split("-")[1],E=Ba(x[0]),A=x.context.querySelector("input").getAttribute("value");if(C==b&&E==c)return r=h=!0,jQuery.post(T({mod:"inventory",submod:"move",from:"-"+A,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+
1,amount:g}),{a:(new Date).getTime(),sh:W("sh")}).then(t=>{try{const u=JSON.parse(t).to.data.itemId;jQuery.post(T({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:u,amount:g,a:(new Date).getTime(),sh:W("sh")})).catch(()=>{})}catch(u){}}).catch(()=>{}),!1}catch(x){}});r||k++}catch(n){D(`Error fetching materials from the package on page ${k}: ${n}`),k++}h||D(`Material of type ${b} and quality ${c} not found in packages.`)},async lp(b){let c=1E3,e=await this.Jo(b);if(null===e||void 0===
e)e=6;c=1E3;await new Promise(g=>setTimeout(g,1100*e+c))},async Jo(b){var c=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});return(c=JSON.parse(c).slots.find(e=>e["forge_slots.slot"]===b))&&c.formula&&c.formula.duration?c.formula.duration:6},async no(b,c,e){await jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")});return await this.Wo(c,e)},async Wo(b,c){let e=1;var g=!1;
let k;for(;!g&&5>=e;){var h=await jQuery.get(F({mod:"packages",f:0,fq:c.quality,qry:c.name,page:e,sh:W("sh")}));h=jQuery(h).find(".packageItem").toArray();for(let l of h){jQuery(l).find(".ui-draggable");g=l.querySelector("input").value;k=(await jQuery.post(T({}),{mod:"inventory",submod:"move",from:"-"+g,fromX:1,fromY:1,to:b,toX:c.x-1,toY:c.y-1,amount:1,a:(new Date).getTime(),sh:W("sh")},null,"json")).to.data.itemId;g=!0;break}g||e++}if(!g)throw Error("Repaired item not found in packages.");return k}},
R={Hm:!1,Mm:!0,spot:1,bag:512,start(){this.pack=function(b,c,e){if(!e)return e;var g=0,k=b+c.slice([e.split("^")[1]]);for(b=0;b<k.length;b++)c=k.charCodeAt(b),g=(g<<5)-g+c,g|=0;return e.split("^")[0]==g};this.storage=JSON.parse(localStorage.getItem("packages"))||{packages:{}};this.createFunctions()},createFunctions(){function b(c){var e=c.getAttribute("data-button");const g=c.getAttribute("data-name");c.getAttribute("data-value");const k=c.classList.toggle("selected");"packageAll"===e?document.querySelectorAll(`.color-box[data-name="${g}"]`).forEach(l=>
{l!==c&&l.classList.toggle("selected",k)}):(k||document.querySelector(`.color-box.select-all[data-name="${g}"]`)?.classList.remove("selected"),Array.from(document.querySelectorAll(`.color-box[data-name="${g}"]`)).filter(l=>l!==c&&"packageAll"!==l.getAttribute("data-button")).every(l=>l.classList.contains("selected"))&&document.querySelector(`.color-box.select-all[data-name="${g}"]`)?.classList.add("selected"));e=Array.from(document.querySelectorAll(`.color-box.selected[data-name="${g}"]`)).map(l=>
l.getAttribute("data-value"));const h=JSON.parse(localStorage.getItem("packages")||"{}");h[g]=e;localStorage.setItem("packages",JSON.stringify(h))}document.getElementById("ConfirmGetGold").addEventListener("click",async function(){async function c(m,r){r=await jQuery.post(T({mod:"inventory",submod:"move",from:m[0].closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+r,toY:21,amount:1}),{a:(new Date).getTime(),sh:k});m[0].closest(".packageItem").remove();
m=JSON.parse(r).header.gold.text||"0";m=parseInt(m.replace(/[^0-9]/g,""),10);q+=m-l;l=m;document.getElementById("goldMovedIndicator").textContent=`Gold moved: ${q.toLocaleString()}`}async function e(){var m=await jQuery.get(F({mod:"packages",f:"14",fq:-1,qry:"",page:h,sh:k}));let r=jQuery(m).find(".ui-draggable").filter((w,v)=>(w=parseInt(jQuery(v).attr("data-price-gold"),10))&&w<=n-l).get();for(let [w,v]of r.entries())if(await c(jQuery(v),w),l>=n){document.getElementById("goldMovedIndicator").textContent+=
" - Completed";return}h++;m=(m=jQuery(m).find(".paging_right_full")[0])?parseInt(m.href.match(/\d+$/)[0],10):1;h<m?await e():document.getElementById("goldMovedIndicator").textContent=`Not enough gold found. Only ${q.toLocaleString()} moved.`}let g=parseInt(document.getElementById("getGold").value.replace(/[^0-9]/g,""),10);if(isNaN(g)||0>=g)alert("Please enter a valid amount greater than 0.");else{var k=W("sh"),h=0,l=0,q=0;l=parseInt(document.getElementById("sstat_gold_val").textContent.replace(/[^0-9]/g,
""),10);var n=l+g;document.getElementById("goldMovedIndicator").textContent="Starting...";await e()}});document.querySelector("h2").addEventListener("click",()=>{jQuery(".custom_packages").toggle();let c=jQuery(".custom_packages").is(":hidden");localStorage.setItem("packages_hidden",c)});jQuery(".custom_packages").mouseup(async c=>{var e=c.target;c=e.getAttribute("data-button");var g=JSON.parse(localStorage.getItem("packages")),k=g.quality;const h=g.type;if(!e.getAttribute("disabled")){switch(c){case "pickAll":confirm("Pick all?")&&
this.pickItems(!0);break;case "pickAllSelected":-1<aa.packages.type.indexOf(14)&&confirm("Pick gold");this.pickItems(!1);break;case "sellThisPage":if(!g||!g.quality||!g.type){Ya("Please select a valid package with both quality and type.");break}0<k.length&&0<h.length?this.hp():(this.Km=!0,Ya("Please select both quality and type to sell."));break;case "SARTH":this.sarth();break;case "SASTM":if(!g||!g.quality||!g.type){Ya("Please select a valid package with both quality and type.");break}0<k.length&&
0<h.length?this.sastm():(this.Km=!0,Ya("Please select both quality and type to sell."));break;case "stop":this.stop=!0;break;case "switch":e=document.querySelector('input[data-name="useSmeltFilter"]');g=document.querySelector('input[data-name="sellUnderworld"]');k=document.querySelector('input[data-name="UCOTH"]');e.checked="true"===localStorage.getItem("useTriggerSmeltFilter");g.checked="true"===localStorage.getItem("packageSellUnderworld");k.checked="true"===localStorage.getItem("useTriggerCloths");
e.addEventListener("change",function(){localStorage.setItem("useTriggerSmeltFilter",this.checked)});g.addEventListener("change",function(){localStorage.setItem("packageSellUnderworld",this.checked)});k.addEventListener("change",function(){localStorage.setItem("useTriggerCloths",this.checked)});break;default:return}"stop"!=c&&"switch"!=c&&(this.Km?this.Km=!1:(this.stop=!1,jQuery("[pakageCmd]").attr("disabled","")))}});document.querySelector(".custom_packages").addEventListener("click",c=>{var e=c.target.closest(".item-checkbox");
if(e){var g=e.getAttribute("data-button");c=e.getAttribute("data-name");if(g&&c){var k=Array.from(document.querySelectorAll(`[data-name="${c}"][data-button="package"]`)),h=document.querySelector(`[data-name="${c}"][data-button="packageAll"]`),l=e.classList.toggle("selected");"packageAll"===g?k.forEach(q=>q.classList.toggle("selected",l)):"package"===g&&(!l&&h&&h.classList.remove("selected"),k.every(q=>q.classList.contains("selected"))&&h&&h.classList.add("selected"));e=k.filter(q=>q.classList.contains("selected")).map(q=>
q.getAttribute("data-value"));g=JSON.parse(localStorage.getItem("packages")||"{}");g[c]=e;localStorage.setItem("packages",JSON.stringify(g))}}});document.querySelectorAll(".color-box").forEach(c=>{const e=()=>b(c);c.addEventListener("touchstart",e,{passive:!0});c.addEventListener("click",e)});document.querySelectorAll(".item-checkbox img").forEach(c=>{var e=window.getComputedStyle(c);const g=parseInt(e.width,10);e=parseInt(e.height,10);if(64<=g&&96<=e)c.style.transform="scale(0.5)",c.style.width=
"64px",c.style.height="64px",c.style.transformOrigin="top left";else if(32<g||32<e)c.style.width="64px",c.style.height="64px",c.style.transform="scale(0.5)",c.style.transformOrigin="top left";else if(32==g||32==e)c.style.transform="scale(1)",c.style.transformOrigin="top left"});(()=>{var c=JSON.parse(localStorage.getItem("packages")||"{}");for(const [k,h]of Object.entries(c))h.forEach(l=>{(l=document.querySelector(`[data-name="${k}"][data-value="${l}"]`))&&l.classList.add("selected")}),(c=document.querySelector(`[data-name="${k}"][data-button="packageAll"]`))&&
Array.from(document.querySelectorAll(`[data-name="${k}"][data-button="package"]`)).every(l=>l.classList.contains("selected"))&&c.classList.add("selected");var e=document.querySelector('input[data-name="useSmeltFilter"]');c=document.querySelector('input[data-name="sellUnderworld"]');const g=document.querySelector('input[data-name="UCOTH"]');if(e){const k="true"===localStorage.getItem("useTriggerSmeltFilter");e.checked=k}c&&(e="true"===localStorage.getItem("packageSellUnderworld"),c.checked=e);g&&(g.checked=
"true"===localStorage.getItem("useTriggerCloths"))})()},enableButtons(){jQuery("[pakageCmd]").removeAttr("disabled")},pickItems(b,c){aa.packages=JSON.parse(localStorage.getItem("packages")||"{}");const e=aa.packages.type,g=aa.packages.quality;if(b||0!=e.length&&0!=g.length){var k=["12"];this.arr=Array.from(document.querySelectorAll("#packages .ui-draggable")).filter(h=>{const l=Ea(h),[q]=l.split("-").map(Number);var n=parseInt(Ba(h),10);if(b)return!0;h=e.some(m=>k.includes(String(q))?m===l||m===String(q):
m===l||m===String(q)||l.startsWith(`${m}-`));n=g.map(Number).includes(Number(n));return h&&n}).sort((h,l)=>Fb(l)-Fb(h));R.move();c&&c()}else Ya("No package types or qualities selected")},async moveGold(b,c){c=await jQuery.post(T({mod:"inventory",submod:"move",from:b.closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+c,toY:21,amount:1}),{a:(new Date).getTime(),sh:W("sh")});b.closest(".packageItem").remove();document.getElementById("sstat_gold_val").innerText=
JSON.parse(c).header.gold.text||0},move(){var b=document.getElementById("inv"),c=bc(b);let e=Math.min(40-Zb(c),this.arr.length);b=this.arr.shift();0<e&&!R.stop?((c=kf(b,c))?ua(b,c):ea(b,"inv"),setTimeout(()=>{R.move()},500)):setTimeout(R.enableButtons,500)},sarth:function(){jQuery.post(T({mod:"forge",submod:"storageIn"}),{jq:0,packages:1,Ym:1,a:(new Date).getTime()+"",sh:W("sh")},()=>{window.location.reload(!0)})},async sastm(){R.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),
this.mm={},this.pack&&this.Qm(this.bn))},async hp(){R.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),R.Hm=!0,this.mm={},this.pack&&this.Qm(this.bn))},async bn(b){if(R.stop)window.location.reload();else if(R.mm=b,b=Object.values(b).every(c=>c.items.length>=c.Am),R.$n=document.querySelector('input[data-name="UCOTH"]'),b&&!R.$n.checked){if(b=document.getElementById("sellspinner"),b.classList.add("hidden"),!document.getElementById("shops-full-message")){const c=
document.createElement("div");c.id="shops-full-message";c.classList.add("message-container");c.textContent="Shops are full! Please refresh the shops or select refresh shops automatically.";b.insertAdjacentElement("afterend",c);R.enableButtons()}}else ac(2,3,R.Un)},async Un(b,c){R.stop&&window.location.reload();try{R.fo=Object.assign(b,{b:c})}catch(x){Ya("Please empty your inventory to have 3x3 space")}document.querySelectorAll("#inventory_nav a")[c-512].click();R.inv=document.getElementById("inv");
const e=JSON.parse(localStorage.getItem("packages"))||{};b=(new URL(window.location.href)).searchParams;b.get("f");b.get("fq");let g={mod:"packages",f:"0",fq:e.quality[0]||-1,qry:"",page:1,sh:W("sh")};b=await jQuery.get(F(g));b=jQuery(b).find(".paging_right_full")[0]?.href.match(/\d+$/)?.[0]||1;console.log(`Max page determined: ${b}`);R.g=[];R.ma=[];const k="true"===localStorage.getItem("useTriggerSmeltFilter"),h="true"===localStorage.getItem("packageSellUnderworld");let l=JSON.parse(localStorage.getItem("smeltingSettings"))||
[];var q=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],n=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];const m=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]")),r=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]"));let w=!1;if(R.Hm)R.Hm&&(R.stop&&window.location.reload(),v=document.querySelectorAll("#packages .packageItem"),b=document.getElementById("sellspinner"),b.classList.remove("hidden"),c=document.getElementById("statusMessage"),c||
(c=document.createElement("div"),c.id="statusMessage",c.classList.add("status-message"),b.insertAdjacentElement("afterend",c)),0<v.length?(c.textContent=`Processing ${v.length} items from the current page...`,v=Array.from(v).map(async x=>{var C=x.querySelector("input").value,E=x.querySelector(".ui-draggable");const A=E.getAttribute("data-basis");var t=E.getAttribute("data-hash"),u=Ea(E).split("-");const z=parseInt(u[0]);var B=u[1]?parseInt(u[1]):null;u=wb(A,t);t=14===z;var J=Fb(E);const I=Gb(E);var K=
Sa(E);const L=["12"].includes(String(z));x={p:x,wl:E,s:J,id:C,q:K,co:z,eo:B,name:I,Oo:A};C=e.type.some(O=>L?O===A||O===String(z):O===A||O===String(z)||A.startsWith(`${O}-`));E=e.quality.map(Number).includes(Number(Ba(E)));u=!h&&u;if(m.has(I)||r.has(I))w=!0;K=l.some(O=>{var Z=O.prefix&&2<O.prefix.length?O.prefix.toLowerCase():null;O=O.suffix&&2<O.suffix.length?O.suffix.toLowerCase():null;const fa=I.toLowerCase();Z=Z&&fa.includes(Z);O=O&&fa.includes(O);return Z||O});B=q.some(O=>I.toLowerCase().includes(O.toLowerCase()));
J=n.some(O=>I.toLowerCase().includes(O.toLowerCase()));K=k&&K;k?!C||!E||K||w||B||J||u?C&&t&&!w&&!u&&R.g.push(x):R.g.push(x):C&&E&&!w&&!u?R.g.push(x):C&&t&&!w&&!u&&R.g.push(x)}),await Promise.all(v),0<R.g.length?(c.textContent=`Selling ${R.g.length} items...`,await R.Zn()):(c.textContent="No items to sell. Please refresh the page.",b.classList.add("hidden"),R.enableButtons()),R.g=[]):(c.textContent="No items found in the current page.",b.classList.add("hidden")));else{c=document.getElementById("sellspinner");
c.classList.remove("hidden");var v=document.getElementById("statusMessage");v||(v=document.createElement("div"),v.id="statusMessage",v.classList.add("status-message"),c.insertAdjacentElement("afterend",v));let x=0;for(let C=1;C<=b;C+=10){const E=Array.from({length:Math.min(10,b-C+1)},(A,t)=>C+t);console.log(`Fetching batch pages: ${E.join(", ")}`);v.textContent=`Reading pages ${E[0]} to ${E[E.length-1]}...`;await Promise.all(E.map(async A=>{g.page=A;try{const t=await jQuery.get(F(g)),u=jQuery(t).find(".packageItem");
0<u.length&&(x+=u.length,u.each((z,B)=>{var J=jQuery(B).find("input").val(),I=jQuery(B).find(".ui-draggable")[0];const K=I.getAttribute("data-basis");z=I.getAttribute("data-hash");var L=Ea(I).split("-");const O=parseInt(L[0]);var Z=L[1]?parseInt(L[1]):null;L=wb(K,z);z=14===O;var fa=Fb(I),da=Sa(I);const ma=Gb(I).toLowerCase(),pa=["12"].includes(String(O));B={p:B,wl:I,s:fa,id:J,q:da,co:O,eo:Z,name:ma,Oo:K};J=e.type.some(ca=>pa?ca===K||ca===String(O):ca===K||ca===String(O)||K.startsWith(`${ca}-`));I=
e.quality.map(Number).includes(Number(Ba(I)));L=!h&&L;if(m.has(ma)||r.has(ma))w=!0;da=l.some(ca=>{var qa=ca.prefix&&2<ca.prefix.length?ca.prefix.toLowerCase():null;ca=ca.suffix&&2<ca.suffix.length?ca.suffix.toLowerCase():null;const ya=ma.toLowerCase();qa=qa&&ya.includes(qa);ca=ca&&ya.includes(ca);return qa||ca});Z=q.some(ca=>ma.toLowerCase().includes(ca.toLowerCase()));fa=n.some(ca=>ma.toLowerCase().includes(ca.toLowerCase()));da=k&&da;k?!J||!I||w||da||Z||fa||L?J&&z&&!w&&!L&&R.g.push(B):R.g.push(B):
J&&!w&&I&&!L?R.g.push(B):J&&z&&!w&&!L&&R.g.push(B)}))}catch(t){}}));await new Promise(A=>setTimeout(A,1E3))}v.textContent=0<x?`Found ${x} items. Preparing to sell...`:"No items found. Please adjust your filters.";0<R.g.length?(v.textContent=`Selling ${R.g.length} items...`,R.sellItems()):(c.classList.add("hidden"),v.textContent="No items to sell. Please change your selections and refresh the page.")}},sellItems(){R.stop&&window.location.reload();let b,c,e;const g=document.getElementById("sellspinner");
g.classList.remove("hidden");let k=document.getElementById("statusMessage");k||(k=document.createElement("div"),k.id="statusMessage",k.classList.add("status-message"),g.insertAdjacentElement("afterend",k));let h=document.getElementById("itemPreview");h||(h=document.createElement("div"),h.id="itemPreview",h.classList.add("item-preview"),k.insertAdjacentElement("afterend",h));try{b=R.g.shift(),c=R.fo,e=R.cn(b.wl)}catch{0<R.ma.length&&!e?R.useCloths():(g.classList.add("hidden"),k.textContent="All items sold. Reloading...",
setTimeout(()=>window.location.reload(),2E3));return}if(e){let l=Gb(b.wl);k.textContent=`Selling: ${l} (${R.g.length} items left)`;h.innerHTML="";h.appendChild(b.p.cloneNode(!0));jQuery.post(T({mod:"inventory",submod:"move",from:"-"+b.id,fromX:"1",fromY:"1",to:c.b,toX:c.x+1,toY:c.y+1,amount:b.q}),{a:(new Date).getTime(),sh:W("sh")},()=>{var q=jQuery(b.wl).css({left:32*c.x,top:32*c.y});R.inv.appendChild(q[0]);jQuery.post(T({mod:"inventory",submod:"move",from:c.b,fromX:c.x+1,fromY:c.y+1,to:e.Nn,toX:e.spot.x+
1,toY:e.spot.y+1,amount:b.q,doll:"1"}),{a:(new Date).getTime(),sh:W("sh")},n=>{jQuery(b.wl).remove();try{document.getElementById("sstat_gold_val").innerText=JSON.parse(n).header.gold.text}catch{}0<R.g.length?R.sellItems():(g.classList.add("hidden"),k.textContent="All items sold successfully!",setTimeout(()=>0<R.ma.length?R.useCloths():window.location.reload(),2E3))})})}else 0<R.g.length?(R.ma.push(b),R.sellItems()):(g.classList.add("hidden"),k.textContent="All items sold. Reloading...",setTimeout(()=>
0<R.ma.length?R.useCloths():window.location.reload(),2E3))},async useCloths(){if("true"===localStorage.getItem("useTriggerCloths")&&0<R.ma.length){R.g=R.ma;R.ma=[];var b=await jQuery.get(F({mod:"inventory",sub:"1",subsub:"2",sh:W("sh")}));b=jQuery(b);b.find("#content form img")[0].src.includes("91e0372cccc24f52758be611a10a3b.png")?(b=b.find("#content form input")[0],await jQuery.post(F({mod:"inventory",sub:"1",subsub:"2",sh:W("sh")}),{[b.name]:b.value}),await new Promise((c,e)=>{R.Qm(g=>{(R.mm=g)&&
0<Object.keys(g).length?c():e("Failed to load shop grid data.")})}),R.sellItems()):window.location.reload()}else window.location.reload()},async Zn(){if(!R.stop){for(;0<R.g.length;){if(R.Mm){var b=await ac(2,3);R.spot=b.spot;R.bag=b.bag;R.Mm=!1}await new Promise(c=>setTimeout(c,10));b=R.g.splice(0,1).map(async c=>{var e=R.cn(c.wl);if(e){const g=await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+c.id,fromX:"1",fromY:"1",to:R.bag,toX:R.spot.x+1,toY:R.spot.y+1,amount:c.q}),{a:(new Date).getTime(),
sh:W("sh")});if(g.includes("Not possible")||g.includes("error"))R.Mm=!0;else if(e=await jQuery.post(T({mod:"inventory",submod:"move",from:R.bag,fromX:R.spot.x+1,fromY:R.spot.y+1,to:e.Nn,toX:e.spot.x+1,toY:e.spot.y+1,amount:c.q,doll:"1"}),{a:(new Date).getTime(),sh:W("sh")})){jQuery(c.element).remove();try{const k=JSON.parse(e).header.gold.text;document.getElementById("sstat_gold_val").innerText=k||""}catch(k){}}}else 0<R.g.length?R.ma.push(c):0<R.ma.length?await R.useCloths():window.location.reload()});
await Promise.all(b);R.g=R.g.filter(c=>!R.ma.includes(c));await new Promise(c=>setTimeout(c,10))}0===R.g.length&&window.location.reload()}},cn(b){var c=parseInt(b.getAttribute("data-measurement-x"),10);b=parseInt(b.getAttribute("data-measurement-y"),10);for(var e in R.mm){var g=R.mm[e];if(!(isNaN(parseInt(e,10))||1>g.Am)){var k=lc(b,c,g.grid);if(k)return g.Am-=c*b,g.items.push({y:k.y,x:k.x,sl:b,w:c}),g.grid=cc(8,6,g.items),{spot:k,Nn:e}}}},Qm(b){const c=[{sub:1,subsub:2},{sub:2,subsub:2},{sub:3,subsub:1},
{sub:3,subsub:2},{sub:4,subsub:0},{sub:4,subsub:1},{sub:4,subsub:2},{sub:5,subsub:0},{sub:5,subsub:1},{sub:5,subsub:2},{sub:6,subsub:0},{sub:6,subsub:1},{sub:6,subsub:2}].map(g=>F({mod:"inventory",sh:W("sh"),...g})),e={};Promise.all(c.map((g,k)=>new Promise((h,l)=>{jQuery.get(g,q=>{try{const n=jQuery(q).find("#shop")[0],m=n.getAttribute("data-container-number"),r=bc(n);e[m]={Am:48-Zb(r),grid:cc(8,6,r),items:r};h()}catch(n){l(n)}}).fail((q,n,m)=>{l(Error(`Error loading shop grid ${k}: ${n} - ${m}`))})}))).then(()=>
{0<Object.keys(e).length&&b(e)}).catch(g=>console.error("Error in gsgriz:",g))}};if(window.location.href.includes("/index.php?mod=market")){let b=[];const c=document.querySelector("#market_filter");if(c){const A=document.createElement("div");A.innerHTML=`
    <div class="custom-market-section">
        <div class="custom-market-header">${d.Fb}</div>
        <div class="custom-market-content">
            <div class="item-sell-form" id="item-sell-form">
                <span class="custom-market-footer">${d.kg}</span>
                <span class="custom-market-footer">${d.jg}</span>
    
                <div>
                    <label>${d.fa}:</label>
                    <input type="text" id="item-name" placeholder="${d.fa}">
                </div>
                <div>
                    <label>${d.Db}:</label>
                    <select id="item-color">
                        <option value="-1">${d.qa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.J}</option>
                        <option value="4">${d.T}</option>
                    </select>
                </div>
                <div>
                    <label>${d.L}:</label>
                    <input type="text" id="item-howmany" placeholder="${d.L}?">
                </div>
                <div>
                    <label>${d.M}:</label>
                    <input type="number" id="price-min" placeholder="${d.M}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="time-2h" value="1">2h</button>
                    <button id="time-8h" value="2">8h</button>
                    <button id="time-24h" value="3">24h</button>
                    <button id="time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Eb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="search-inventory"> &nbsp;${d.gg}</label>&nbsp;
                    <label><input type="checkbox" id="search-packages"> &nbsp;${d.lg}</label>&nbsp;
                </div>
    
                <button id="sell-item-btn">${d.Fb}</button>
                <div class="spinner3 hidden" id="loadingSpinner3"></div>
            </div>
    
            <!-- Material Sell Form -->
            <div class="material-sell-form hidden" id="material-sell-form">
                <div>
                    <label>Select Material:</label>
                        <select id="material-select">
                            <!-- Base Materials -->
                            <option value="1">${d.Pc}</option>
                            <option value="2">${d.Fc}</option>
                            <option value="4">${d.Jc}</option>
                            <option value="3">${d.Lc}</option>

                            <!-- Materials -->
                            <option value="13">${d.Qc}</option>
                            <option value="14">${d.Gc}</option>
                            <option value="15">${d.Ic}</option>
                            <option value="16">${d.Hc}</option>
                            <option value="17">${d.Mc}</option>
                            <option value="18">${d.Kc}</option>
                            <option value="19">${d.Oc}</option>
                            <option value="20">${d.Nc}</option>

                            <!-- Monster Parts -->
                            <option value="5">${d.Yc}</option>
                            <option value="6">${d.Sc}</option>
                            <option value="7">${d.ad}</option>
                            <option value="8">${d.Vc}</option>
                            <option value="9">${d.Xc}</option>
                            <option value="10">${d.Wc}</option>
                            <option value="11">${d.Tc}</option>
                            <option value="12">${d.$c}</option>
                            <option value="55">${d.Uc}</option>
                            <option value="58">${d.Zc}</option>
                            <option value="62">${d.bd}</option>
                            <option value="64">${d.cd}</option>

                            <!-- Gemstones -->
                            <option value="21">${d.Cc}</option>
                            <option value="22">${d.wc}</option>
                            <option value="23">${d.vc}</option>
                            <option value="24">${d.xc}</option>
                            <option value="25">${d.Dc}</option>
                            <option value="26">${d.Ac}</option>
                            <option value="27">${d.zc}</option>
                            <option value="28">${d.yc}</option>
                            <option value="59">${d.Bc}</option>
                            <option value="63">${d.Ec}</option>

                            <!-- Flasks -->
                            <option value="37">${d.qc}</option>
                            <option value="38">${d.tc}</option>
                            <option value="39">${d.mc}</option>
                            <option value="40">${d.lc}</option>
                            <option value="41">${d.sc}</option>
                            <option value="42">${d.pc}</option>
                            <option value="43">${d.nc}</option>
                            <option value="44">${d.oc}</option>
                            <option value="53">${d.uc}</option>
                            <option value="61">${d.rc}</option>

                            <!-- Runes -->
                            <option value="29">${d.Bd}</option>
                            <option value="30">${d.vd}</option>
                            <option value="31">${d.td}</option>
                            <option value="32">${d.Ad}</option>
                            <option value="33">${d.zd}</option>
                            <option value="34">${d.xd}</option>
                            <option value="35">${d.ud}</option>
                            <option value="36">${d.yd}</option>
                            <option value="60">${d.wd}</option>

                            <!-- Ores -->
                            <option value="45">${d.gd}</option>
                            <option value="46">${d.fd}</option>
                            <option value="47">${d.ld}</option>
                            <option value="48">${d.od}</option>
                            <option value="49">${d.pd}</option>
                            <option value="50">${d.jd}</option>
                            <option value="51">${d.nd}</option>
                            <option value="52">${d.md}</option>
                            <option value="54">${d.ed}</option>
                            <option value="56">${d.hd}</option>
                            <option value="57">${d.kd}</option>

                            <!-- Fragments -->
                            <option value="65">Material Fragment</option>
                            <option value="66">Monster Piece</option>
                            <option value="67">Gemstone Shard</option>
                            <option value="68">Flask Component</option>
                            <option value="69">Rune Splinter</option>
                            <option value="70">Ore Sample</option>
                            <option value="71">Scroll Fragment</option>

                        </select>
                </div>
                <div>
                    <label>${d.hg}:</label>
                    <select id="material-color">
                        <option value="-1">${d.qa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.J}</option>
                        <option value="4">${d.T}</option>
                    </select>
                </div>
                <div>
                    <label>${d.L}:</label>
                    <input type="text" id="mat-item-howmany" placeholder="${d.L}?">
                </div>
                <div>
                    <label>${d.M}:</label>
                    <input type="number" id="material-price-min" placeholder="${d.M}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="material-price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="material-time-2h" value="1">2h</button>
                    <button id="material-time-8h" value="2">8h</button>
                    <button id="material-time-24h" value="3">24h</button>
                    <button id="material-time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Eb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="material-search-warehouse"> &nbsp;${d.og}</label>&nbsp;
                </div>
    
                <button id="sell-material-btn">${d.ng}</button>
                <div class="spinner2 hidden" id="loadingSpinner2"></div>
            </div>
    
            <!-- Food Sell Form -->
            <div class="food-sell-form hidden" id="food-sell-form">
                <label>Level Range:</label>
                <div style="display: flex; gap: 5px;">
                    <input type="number" id="food-level-min" placeholder="Min Level" style="width: 100%;">
                    <input type="number" id="food-level-max" placeholder="Max Level" style="width: 100%;">
                </div>
                <div>
                    <label>${d.Db}:</label>
                    <select id="food-quality">
                        <option value="-1">${d.qa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.J}</option>
                        <option value="4">${d.T}</option>
                    </select>
                </div>
                <div>
                    <label>${d.L}:</label>
                    <input type="text" id="food-howmany" placeholder="${d.L}?">
                </div>
                <div>
                    <label>${d.M}:</label>
                    <input type="number" id="food-price-min" placeholder="${d.M}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="food-price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="food-time-2h" value="1">2h</button>
                    <button id="food-time-8h" value="2">8h</button>
                    <button id="food-time-24h" value="3">24h</button>
                    <button id="food-time-48h" value="4">48h</button>
                </div>
    
                <button id="sell-food-btn">${d.mg}</button>
                <div class="spinner3 hidden" id="loadingSpinner4"></div>
            </div>
    
            <div class="switch-section">${d.Aa}</div>
        </div>
    </div>
            `;c.insertAdjacentElement("afterend",A);document.getElementById("sell-item-btn").addEventListener("click",x);document.getElementById("sell-material-btn").addEventListener("click",C);document.getElementById("sell-food-btn").addEventListener("click",w);document.querySelector(".custom-market-header").addEventListener("click",k);document.querySelector(".switch-section").addEventListener("click",l);document.querySelectorAll(".time-selection button").forEach(t=>{t.addEventListener("click",function(){h(t,
t.textContent)})})}let e=["item-sell-form","material-sell-form","food-sell-form"],g=0;function k(){const A=document.querySelector(".custom-market-content"),t=document.querySelector(".custom-market-header");t.classList.toggle("collapsed");A.style.display=t.classList.contains("collapsed")?"none":"block";localStorage.setItem("sellItemsSectionCollapsed",t.classList.contains("collapsed"))}function h(A,t){A.parentElement.querySelectorAll("button").forEach(u=>{u.classList.remove("selected")});A.classList.add("selected");
localStorage.setItem("selectedTime_"+A.closest("div").parentElement.id,t)}function l(){e.forEach(t=>{document.getElementById(t).classList.add("hidden")});g=(g+1)%e.length;document.getElementById(e[g]).classList.remove("hidden");const A=document.querySelector(".switch-section");"item-sell-form"===e[g]?A.textContent=`${d.Aa}`:"material-sell-form"===e[g]?A.textContent=`${d.Gb}`:"food-sell-form"===e[g]&&(A.textContent=`${d.Hb}`);localStorage.setItem("currentSection",e[g])}async function q(A,t,u){return new Promise(async z=>
{let B=!1;const J=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));let I=0;for(let L=0;L<J.length&&!(I>=parseInt(u,10));L++){var K=J[L];if("false"!==K.getAttribute("data-available")){K.click();await new Promise(O=>setTimeout(O,175));K=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let O of K){if(I>=parseInt(u))break;O.getAttribute("data-basis");K=Gb(O);const Z=O.getAttribute("data-item-id"),fa=Ba(O);if(K.toLowerCase()===A.toLowerCase()&&t===fa){b.push(Z);B=!0;
I++;break}}if(B)break}}z(B)})}async function n(A,t,u,z,B){try{let J=1,I=parseInt(u,10);for(u=!1;1<=J&&2>=J&&!(0>=I);){const K=await jQuery.get(F({mod:"packages",f:z?"18":"0",fq:t,qry:z?"":A,page:J.toString(),sh:W("sh")})),L=Array.from(jQuery(K).find(".packageItem"));for(let O of L){if(0>=I)break;const Z=O.querySelector("[data-content-type]"),fa=O.querySelector("[data-container-number]"),da=Z.getAttribute("data-measurement-x"),ma=Z.getAttribute("data-measurement-y");let pa=Z.getAttribute("data-quality");
const ca=Z.getAttribute("data-tooltip"),qa=fa.getAttribute("data-container-number"),ya=Gb(Z).toLowerCase();pa||(ca.includes("white")&&(pa="-1"),ca.includes("lime")&&(pa="0"));const Oa=ya===A.toLowerCase()&&t===pa;if(z){const xb=Z.getAttribute("data-basis"),Jb=xb.startsWith("18")&&xb.split("-")[1]===B.toString();t===pa&&Jb&&(await v(qa,da,ma),u=!0,I--)}else Oa&&(await v(qa,da,ma),u=!0,I--)}J++}return u}catch(J){return!1}}async function m(A,t=-1,u){try{let z=!0,B=0;for(let J=0;J<parseInt(u,10)&&!(B>=
u);J++){for(;B<parseInt(u,10);)try{if(await jQuery.post(T({mod:"forge",submod:"storageOut",type:A,quality:t,amount:1,a:(new Date).getTime(),sh:W("sh")})),await n(A,t,1,!0,A),B++,B>=parseInt(u,10))break}catch(I){B++}z=!0}return z}catch(z){return!1}}async function r(A,t,u,z){try{let B=1,J=parseInt(z,10);for(z=!1;1<=B&&10>=B&&!(0>=J);){const I=await jQuery.get(F({mod:"packages",f:"7",fq:u,qry:"",page:B.toString(),sh:W("sh")})),K=Array.from(jQuery(I).find(".packageItem"));for(let L of K){if(0>=J)break;
const O=L.querySelector("[data-content-type]"),Z=L.querySelector("[data-container-number]"),fa=O.getAttribute("data-measurement-x"),da=O.getAttribute("data-measurement-y"),ma=vb(O),pa=Ba(O);if(parseInt(ma)>=A&&parseInt(ma)<=t&&pa===u){const ca=Z.getAttribute("data-container-number");await v(ca,fa,da);z=!0;J--}}B++}return z}catch(B){return!1}}async function w(){var A=parseInt(document.getElementById("food-level-min").value,10);const t=parseInt(document.getElementById("food-level-max").value,10),u=
document.getElementById("food-quality").value,z=parseInt(document.getElementById("food-howmany").value,10),B=parseInt(document.getElementById("food-price-min").value,10),J=parseInt(document.getElementById("food-price-max").value,10),I=document.getElementById("loadingSpinner4");if(isNaN(A)||isNaN(t)||A>t||isNaN(B)||isNaN(J)||B>J||1>z)alert(`${d.xa}`);else{I.style.display="block";try{let fa=!1;if(fa=await r(A,t,u,z)){var K=document.querySelector("#food-sell-form .time-selection button.selected"),L=
K?parseInt(K.value,10):2,O=document.querySelector('input[name="anbieten"]'),Z=O?O.value:"Offer";for(A=0;A<b.length;A++){const da=b[A],ma=B===J?B:Math.floor(Math.random()*(J-B+1))+B,pa=F({mod:"market",sh:W("sh")});await jQuery.post(pa,{sellid:da,preis:ma,dauer:L,anbieten:Z})}b=[];alert(`${d.za}`);await new Promise(da=>setTimeout(da,250));Hf("mod=market&f=7")}else alert(`${d.ya}`)}catch(fa){}finally{I.style.display="none"}}}async function v(A,t,u){try{let {spot:z,bag:B}=await ac(t,u);const J=await jQuery.post(T({mod:"inventory",
submod:"move",from:A,fromX:1,fromY:1,to:B,toX:z.x+1,toY:z.y+1,amount:1,a:(new Date).getTime(),sh:W("sh")})),I=JSON.parse(J).to.data.itemId;b.push(I);return!0}catch(z){return!1}}async function x(){const A=document.getElementById("item-name").value;var t=document.getElementById("item-color").value;const u=document.getElementById("item-howmany").value,z=parseInt(document.getElementById("price-min").value,10),B=parseInt(document.getElementById("price-max").value,10),J=document.getElementById("loadingSpinner3"),
I=document.getElementById("search-inventory").checked,K=document.getElementById("search-packages").checked;if(!A||isNaN(z)||isNaN(B)||z>B||1>u)alert(`${d.xa}`);else{J.style.display="block";try{let da=!1;I&&(da=await q(A,t,u));!da&&K&&(da=await n(A,t,u));if(da){var L=document.querySelector(".time-selection button.selected"),O=L?parseInt(L.value,10):2,Z=document.querySelector('input[name="anbieten"]'),fa=Z?Z.value:"Offer";for(t=0;t<b.length;t++){const ma=b[t],pa=z===B?z:Math.floor(Math.random()*(B-
z+1))+z,ca=F({mod:"market",sh:W("sh")});jQuery.post(ca,{sellid:ma,preis:pa,dauer:O,anbieten:fa})}b=[];alert(`${d.za}`);await new Promise(ma=>setTimeout(ma,250));Hf("mod=market&qry="+A)}else alert(`${d.ya}`)}catch(da){}finally{J.style.display="none"}}}async function C(){var A=document.getElementById("material-select").value,t=document.getElementById("material-select");t=t.options[t.selectedIndex].textContent;const u=document.getElementById("material-color").value,z=document.getElementById("mat-item-howmany").value,
B=parseInt(document.getElementById("material-price-min").value,10),J=parseInt(document.getElementById("material-price-max").value,10),I=document.getElementById("loadingSpinner2"),K=document.getElementById("material-search-warehouse").checked;if(!A||isNaN(B)||isNaN(J)||B>J||1>z)alert(`${d.xa}`);else{I.style.display="block";try{let da=!1;K&&(da=await m(A,u,z));if(da){var L=document.querySelector("#material-sell-form .time-selection button.selected"),O=L?parseInt(L.value,10):2,Z=document.querySelector('input[name="anbieten"]'),
fa=Z?Z.value:"Offer";for(A=0;A<b.length;A++){const ma=b[A],pa=B===J?B:Math.floor(Math.random()*(J-B+1))+B,ca=F({mod:"market",sh:W("sh")});jQuery.post(ca,{sellid:ma,preis:pa,dauer:O,anbieten:fa})}b=[];alert(`${d.za}`);await new Promise(ma=>setTimeout(ma,250));Hf("mod=market&qry="+t)}else alert(`${d.ya}`)}catch(da){}finally{I.style.display="none"}}}const E=localStorage.getItem("currentSection");if(E&&e.includes(E)){e.forEach(t=>{document.getElementById(t).classList.add("hidden")});document.getElementById(E).classList.remove("hidden");
g=e.indexOf(E);const A=document.querySelector(".switch-section");"item-sell-form"===e[g]?A.textContent=`${d.Aa}`:"material-sell-form"===e[g]?A.textContent=`${d.Gb}`:"food-sell-form"===e[g]&&(A.textContent=`${d.Hb}`)}else document.getElementById("item-sell-form").classList.remove("hidden"),g=0;e.forEach(A=>{const t=localStorage.getItem("selectedTime_"+A);t&&document.querySelectorAll("#"+A+" .time-selection button").forEach(u=>{u.textContent===t&&u.classList.add("selected")})});"true"===localStorage.getItem("sellItemsSectionCollapsed")&&
(document.querySelector(".custom-market-header").classList.add("collapsed"),document.querySelector(".custom-market-content").style.display="none")}if(window.location.href.includes("/index.php?mod=guild")){const b=document.querySelectorAll("form");for(const c of b){const e=c.getAttribute("action");e&&e.includes("submod=create")&&localStorage.setItem("resetExpiredItems","false")}}if(window.location.href.includes("/index.php?mod=packages&")){let b=jQuery(".section-header").first();b&&(function(){var c=
"true"===localStorage.getItem("packages_hidden");let e=`

<section class="custom_packages" style="display: block; box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
<div style="text-align: center">
    <button class="awesome-button" packageCmd data-button="pickAll">
    ${d.zj}
    </button>
    <button class="awesome-button" packageCmd data-button="pickAllSelected">
    ${d.Aj}
    </button>
    <button class="awesome-button" pakageCmd data-button="sellThisPage">
    ${d.Dj}
    </button>
    <button
    class="awesome-button" data-button="SASTM" pakageCmd data-name="SASTM"
>
${d.Bj}
</button>
    <button class="awesome-button" data-button="stop">${d.Fj}</button>
    <button class="awesome-button" packageCmd data-button="SARTH">
    ${d.Ej}
    </button>
</div>

<style>

    .awesome-button:hover {
        background-color: #444;
        color: #fff; 
    }

    .progress-container {
      width: 100%;
      height: 20px;
      background-color: #f3f3f3;
      position: relative;
      border-radius: 15px;
      margin: 10px 0;
    }
  
    .progress-bar {
      width: 0;
      height: 100%;
      background-color: #4caf50;
      position: absolute;
      border-radius: 15px;
      transition: width 0.4s ease-in-out;
    }
  
    .page-indicator {
      text-align: center;
      position: absolute;
      width: 100%;
      top: 50%;
      transform: translateY(-50%);
      font-size: 12px;
    }

</style>

    <fieldset style="box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
        <legend>${d.Cj}</legend>
        <table style="width: 100%; text-align: center">
            <tbody>
                <tr>
                    <td>
                    </td>
                    

                    <div id="sellspinner" class="spinnerNew hidden"></div>
                    <div id="statusMessage" class="status-message">Status</div>
                    <div id="itemPreview" class="item-preview">
                        <div class="item"></div>
                    </div>

                    <td>
                        <input
                            type="checkbox"
                            data-button="switch"
                            data-name-ek="packages"
                            data-name="UCOTH"
                            style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        /><span class="span-new">${d.Jj}</span>
                        <hr>
                        <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="useSmeltFilter"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       /><span class="span-new">${d.oe}</span>
                       <hr>
                       <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="sellUnderworld"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       />
                       <span class="span-new">${d.Oj}</span>
                       <hr>
                        <div class="setting-row">
                        <label for="getGold">${d.Si}</label>
                        <div class="switch-field3">
                          
                          <input type="number" id="getGold" min="1000" max="200000000" placeholder="Amount">
                          <button id="ConfirmGetGold" class="awesome-button">OK</button>
                          <span class="span-new" id="goldMovedIndicator">${d.bf}: 0</span>
                        </div>
                      </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </fieldset>
    <fieldset>
        <legend>${d.na}</legend>
    <table>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="1" title="Weapons">
      <img class="item-i-1-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="2" title="Shields">
      <img class="item-i-2-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="3" title="Armor">
      <img class="item-i-3-3">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="4" title="Helmets">
      <img class="item-i-4-7">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="5" title="Gloves">
      <img class="item-i-5-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="8" title="Boots">
      <img class="item-i-8-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="6" title="Rings">
      <img class="item-i-6-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="9" title="Necklaces">
      <img class="item-i-9-1">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="7" title="Food">
      <img class="item-i-7-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12" title="Upgrades">
      <img class="item-i-12-2">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="13" title="Recipes">
      <img class="item-i-13-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="15" title="Mercenaries">
      <img class="item-i-15-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="19" title="Tools">
      <img class="item-i-19-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="20" title="Scrolls">
      <img class="item-i-20-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="11" title="Reinforcements">
      <img class="item-i-11-17">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="21" title="Event Items">
      <img class="item-i-21-1">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="18" title="Forging Goods">
      <img class="item-i-18-1">
    </td>

    <!-- Powders -->
    
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-10" title="Green Powder">
      <img class="item-i-12-10">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-6" title="Blue Powder">
      <img class="item-i-12-6">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-17" title="Red Powder">
      <img class="item-i-12-17">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-14" title="Purple Powder">
      <img class="item-i-12-14">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-8" title="Yellow Powder">
      <img class="item-i-12-8">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-12" title="Orange Powder">
      <img class="item-i-12-12">
    </td>

    <!-- Dust -->
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-7" title="Yellow Powder">
      <img class="item-i-12-7">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-5" title="Blue Powder">
      <img class="item-i-12-5">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-16" title="Red Powder">
      <img class="item-i-12-16">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-9" title="Green Powder">
      <img class="item-i-12-9">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-11" title="Orange Powder">
      <img class="item-i-12-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-13" title="Purple Powder">
      <img class="item-i-12-13">
    </td>

    <!-- Oils -->
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-18" title="Purple Oil">
      <img class="item-i-12-18">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-19" title="Yellow Oil">
      <img class="item-i-12-19">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-20" title="Orange Oil">
      <img class="item-i-12-20">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-21" title="Green Oil">
      <img class="item-i-12-21">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-22" title="Blue Oil">
      <img class="item-i-12-22">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-23" title="Red Oil">
      <img class="item-i-12-23">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="14" title="Gold">
      <img class="item-i-14-1">
    </td>

      <td class="item-checkbox select-all" data-button="packageAll" data-name="type" title="Select All">
        <div class="select-all-content">
          <span class="select-all-text">ALL</span>
        </div>
      </td>

</table>

    </fieldset>
    <fieldset>
        <legend>Quality</legend>
        <table style="width: 100% box-shadow: 0px 5px 10px rgba(0,0,0,0.15);">
            <tbody>
              <tr>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="-1" title="White" style="background-color: white; "></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="0" title="Green" style="background-color: green;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="1" title="Blue" style="background-color: blue;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="2" title="Purple" style="background-color: purple;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="3" title="Orange" style="background-color: orange;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box" data-button="package" data-name="quality" data-value="4" title="Red" style="background-color: red;"></div>
                </td>
                <td style="width: 14.28%">
                    <div class="color-box select-all" data-button="packageAll" data-name="quality" data-value="99" title="All" style="background: linear-gradient(45deg, red, orange, yellow, green, blue, purple); border: 1px solid #ccc;"></div>
                </td>
                </tr>
            </tbody>
        </table>
    </fieldset>
</section>
`;b.before(`
                <h2 class="section-header" style="cursor: pointer" id="hidePackges">
                ${d.Gj}
                </h2>`);b.before(e);c&&(c=document.querySelector(".custom_packages"),c.style.display="none"===c.style.display?"block":"none")}(),$(".custom-button:contains('sell all selected to merchants')").click(async function(){await R.sastm()}));R.start()}if(window.location.href.includes("mod=auction")){localStorage.getItem("auctionPrefixes")||localStorage.setItem("auctionPrefixes",JSON.stringify([]));localStorage.getItem("prefixes")||localStorage.setItem("prefixes",JSON.stringify([]));localStorage.getItem("searchTerms")||
localStorage.setItem("searchTerms",JSON.stringify([]));const b=document.getElementById("auction_table");let c;b&&(c=b.querySelectorAll(".auction_item_div"));const e=localStorage.getItem("highlightedItemHash");if(e){const g=document.querySelector(`form:has(div[data-hash="${e}"])`);g&&(g.style.outline="3px solid red",g.style.outlineOffset="4px",g.style.boxShadow="0 0 10px rgba(0, 0, 0, 0.5)",g.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"}),localStorage.removeItem("highlightedItemHash"))}if(!c||
0===c.length)return;c.forEach(g=>{g.style.position="relative";g.style.height="106px";const k=document.createElement("span");k.className="auction-icon";k.innerHTML="\ud83d\udd28";k.title="Add to Auction List";k.style.cursor="pointer";k.style.fontSize="16px";k.style.marginTop="88px";k.style.display="inline-block";k.style.marginRight="-25px";const h=document.createElement("span");h.className="smelt-icon";h.innerHTML="\ud83d\udd25";h.title="Add to Smelting List";h.style.cursor="pointer";h.style.fontSize=
"16px";h.style.marginTop="88px";h.style.display="inline-block";let l=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],q=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],n=JSON.parse(localStorage.getItem("smeltingSettings"))||[];const m=g.querySelector("[data-tooltip]"),r=m?m.getAttribute("data-tooltip"):null;if(r){var {itemName:w,wn:v,xn:x,itemColor:C,itemType:E,itemLevel:A,qn:t}=hh(r,m);try{JSON.parse(r.replace(/&quot;/g,'"'))}catch(u){return}w&&(l.includes(v)&&q.includes(x)&&(k.innerHTML=
"\u2705"),n.some(u=>{const z=""!=u.prefix&&v.includes(u.prefix)||""!=u.suffix&&x.includes(u.suffix);u="white"==C||u.colors.includes(C);return z&&u})&&(h.innerHTML="\u2705"),k.addEventListener("click",()=>{let u=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],z=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];JSON.parse(localStorage.getItem("searchTerms"));u.includes(v)||(u.push(v),localStorage.setItem("auctionPrefixes",JSON.stringify(u)));z.includes(x)||(z.push(x),localStorage.setItem("auctionSuffixes",
JSON.stringify(z)));ab(`Item "${w[0]}" added to the auction list!`);k.innerHTML="\u2705";setTimeout(()=>{k.innerHTML="\ud83d\udd28"},1E3)}),h.addEventListener("click",()=>{const u={condition:"nameContains",prefix:v,suffix:x,qm:t,colors:["white","green"],itemTypes:[E],hammerState:"none",level:A,isEnabled:!0};let z=JSON.parse(localStorage.getItem("smeltingSettings"))||[];z.push(u);localStorage.setItem("smeltingSettings",JSON.stringify(z));ab(`Item "${w[0]}" added to the smelting list!`);h.innerHTML=
"\u2705"}),g.appendChild(h),g.appendChild(k))}})}if(window.location.href.includes("mod=packages")){await new Promise(e=>setTimeout(e,1E3));["auctionPrefixes","prefixes","searchTerms"].forEach(e=>{localStorage.getItem(e)||localStorage.setItem(e,JSON.stringify([]))});const b=document.getElementById("packages");if(!b)return;const c=b.querySelectorAll(".packageItem");if(!c||0===c.length)return;c.forEach(e=>{const g=gh("\ud83d\udd28","auction-icon","pointer","16px","1px",`${d.Ni}`),k=gh("\ud83d\udd25",
"smelt-icon","pointer","16px","40px",`${d.dk}`),h=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],l=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],q=JSON.parse(localStorage.getItem("smeltingSettings"))||[],n=e.querySelector("[data-tooltip]"),m=n?n.getAttribute("data-tooltip"):null;if(m){var {itemName:r,wn:w,xn:v,itemColor:x,itemType:C,itemLevel:E,qn:A}=hh(m,n);r&&(h.includes(w)&&l.includes(v)&&(g.innerHTML="\u2705"),q.some(t=>{const u=""!=t.prefix&&w.includes(t.prefix)||""!=t.suffix&&
v.includes(t.suffix);t="white"==x||t.colors.includes(x);return u&&t})&&(k.innerHTML="\u2705"),g.addEventListener("click",()=>{let t=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],u=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];t.includes(w)||(t.push(w),localStorage.setItem("auctionPrefixes",JSON.stringify(t)));u.includes(v)||(u.push(v),localStorage.setItem("auctionSuffixes",JSON.stringify(u)));ab(`Item "${r[0]}" added to the auction list!`);g.innerHTML="\u2705"}),k.addEventListener("click",
()=>{const t={condition:"nameContains",prefix:w,suffix:v,qm:A,colors:"white"===x?["white","green"]:[x],itemTypes:[C],hammerState:"none",level:E||1,isEnabled:!0},u=JSON.parse(localStorage.getItem("smeltingSettings"))||[];u.push(t);localStorage.setItem("smeltingSettings",JSON.stringify(u));ab(`Item "${r[0]}" added to the smelting list!`);k.innerHTML="\u2705"}),e=e.querySelector('[data-no-combine="true"]'))&&(e.appendChild(g),e.appendChild(k))}})}var lb={A:{async start(){const b=JSON.parse(localStorage.getItem("Timers"));
if(!W("mod")||"auction"!==W("mod")){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(g=>c[g]).filter(g=>void 0!==g);if(0<e.length){Hf(`mod=auction&itemType=${e[0]}`);return}}lb.A.I=[];lb.A.ql=Math.floor(Fh().gold-Number(localStorage.getItem("storeGoldinAuctionholdGold")));lb.A.form=document.querySelectorAll("#auction_table form");lb.A.ql&&await this.list(async()=>{0<this.I.length?await this.buy():
this.Zo(b)})},async Zo(b){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(q=>c[q]).filter(q=>void 0!==q);0===e.length&&(D("Auction Store: No valid auction types selected."),Y("enableHideGold",b.AuctionHoldGold||5),window.location.reload());const g=parseInt(W("itemType"),10),k=W("ttype"),h=e.indexOf(g),l=h===e.length-1;"3"===k?l?(D("Auction Store: Last type reached, reloading and setting timeout for next cycle."),
Y("enableHideGold",b.AuctionHoldGold||5),window.location.reload()):Hf(`mod=auction&itemType=${e[h+1]}`):-1!==h&&(D("Auction Store: Toggling to mercenary mode for current type:",g),Hf(`mod=auction&itemType=${g}&ttype=3`))},async list(b=!1){D(`${d.Nf}`);var c=this.ql;const e="true"===localStorage.getItem("AuctionGoldCover");let g=[];const k=localStorage.getItem("storeInShopQuality")||-1;for(let q=0;q<this.form.length;q++){let n=this.form[q];var h=n.querySelector(".ui-draggable"),l=n.querySelector(".auction_bid_div");
l=(l=l?l.querySelector('input[type="text"], input[type="number"]'):null)?Number(l.value):0;h=h?Hb(h):0;l<=h&&l<=c&&g.push({ka:n,price:parseInt(l,10),value:h})}g.sort((q,n)=>n.price-q.price);for(let q of g)if(c=q.ka.querySelector(".ui-draggable").getAttribute("data-quality"),!(Number(c)<Number(k))){if(c=(c=(c=q.ka.querySelector(".auction_bid_div"))?c.querySelector("div > a"):null)?c.querySelector("span"):null){c=c.getAttribute("style");if(e&&c&&c.includes("green"))continue;if(!e&&c&&c.includes("green"))return!0;
if(c&&c.includes("blue"))continue}lb.A.I.push([q.ka.getAttribute("action"),{auctionid:q.ka.querySelector('input[name="auctionid"]').value,qry:q.ka.querySelector('input[name="qry"]').value,itemType:q.ka.querySelector('input[name="itemType"]').value,itemLevel:q.ka.querySelector('input[name="itemLevel"]').value,itemQuality:q.ka.querySelector('input[name="itemQuality"]').value,buyouthd:q.ka.querySelector('input[name="buyouthd"]').value,bid_amount:q.price,bid:q.ka.querySelector('input[name="bid"]').value}])}b&&
await b()},async buy(){let b=lb.A.I.pop();await jQuery.ajax({type:"POST",url:b[0],data:b[1]});0<lb.A.I.length?(await new Promise(c=>setTimeout(c,100)),await this.buy()):window.location.reload()}}},th=localStorage.getItem("OillastRan"),uh=Date.now(),Ra={H:"minerva diana vulcanus mars apollo merkur".split(" "),po:[20,60,150,0],jn:[],async start(){"mod=gods"!=mf?Hf("mod=gods"):Ra.Wm(0)},mo(){let b=(new Date).getTime(),c=aa.H.Qn?aa.H.Qn:[1];if(5>c.length)return!0;for(let e=0;e<c.length;e++)if(c[e]&&c[e]<
b||!c[e]&&(0==aa.H[Ra.H[e]]&&!aa.H.un||1==aa.H[Ra.H[e]]||2==aa.H[Ra.H[e]])||!c[e]&&aa.H.un&&Va.isUnderworld()&&1<=aa.$m.wins)return!0;return!1},async zo(){var b=bb.origin;const c=bb.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);return(new DOMParser).parseFromString(await b.text(),"text/html")},async Wm(b,c){if(c){var e=JSON.parse(localStorage.getItem("gods")),g=this.H[b],k=c.getElementById(g);k&&(c=parseInt(k.querySelector(".god_points").innerText.match(/\d+/)[0],
10),k=k.querySelector(".god_cooldown span")?parseInt(k.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0,e=e[g],g=this.po[e],c>=g&&0==k&&0<g&&0<=e&&(Ra.jn.push(!1),jQuery.get(F({mod:"gods",submod:"activateBlessing",god:b+1,rank:e+1,sh:W("sh")}),()=>{Ra.jn.push(!1);5>b&&Ra.Wm(++b)})))}},yq(b){b=b.getAttribute("data-tooltip");return b?(b=b.match(/(\d{1,2}):(\d{2})\s?h/))?(parseInt(b[1],10)||0)+(parseInt(b[2],10)||0)/60:0:0},kq(b){const c=JSON.parse(localStorage.getItem("oilCooldowns")||
"{}");return c[b]?Date.now()<c[b]:!1},Fq(b,c){const e=JSON.parse(localStorage.getItem("oilCooldowns")||"{}");e[b]=Date.now()+36E5*c;localStorage.setItem("oilCooldowns",JSON.stringify(e))},yo(b){b=b.match(/new\s+BagLoader\([\s\S]*?JSON\.parse\(\s*'([^']*)'\s*\)/);if(!b)return console.log("Could not find JSON.parse(...) in the overview HTML"),null;b=b[1];b=b.replace(/\\"/g,'"');b=b.replace(/\\\\/g,"\\");let c=null;try{c=JSON.parse(b)}catch(e){return console.error("Error parsing bagData JSON:",e),null}return c},
async Fo(){let b=[];const c={"12-18":"purple","12-19":"yellow","12-20":"orange","12-21":"green","12-22":"blue","12-23":"red"};try{const e=await jQuery.get(F({mod:"overview",sh:W("sh")})),g=this.yo(e);if(!g)return D("No bagData found in overview"),b;const k=g.flat(5),h=Object.keys(c);k.forEach(l=>{if("string"===typeof l&&h.some(n=>l.includes(`data-basis="${n}"`))){var q=jQuery(l).filter(function(){const n=jQuery(this).attr("data-basis");return h.includes(n)});q.length&&b.push(...q.toArray())}})}catch(e){D(`Error in getInventoryOilsFromOverview: ${e}`)}D(`Found ${b.length} oil items in inventory`);
return b},async gn(b,c){try{const e=jQuery(b).attr("data-container-number"),g=jQuery(b).attr("data-position-x"),k=jQuery(b).attr("data-position-y");await new Promise(h=>setTimeout(h,250));await jQuery.post(T({mod:"inventory",submod:"move",from:e,fromX:g,fromY:k,to:c,toX:1,toY:1,amount:1,doll:1,a:Date.now(),sh:W("sh")}));D(`Applied oil (basis=${jQuery(b).attr("data-basis")}) to slot container=${c}`);return!0}catch(e){return D(`Error applying oil to container ${c}: ${e}`),!1}},vn(b,c){return(b=b.find(e=>
e.oo===c))?b.No?!1:!0:!0},async Zp(){var b=await jQuery.get(F({mod:"overview",sh:W("sh")}));b=jQuery(b).find("#char");if(!b.length)return console.log("No #char found in overview"),[];let c=[];b.find(".item-i-").each(function(){var e=jQuery(this);const g=e.attr("data-container-number")||"",k=e.attr("data-basis")||"";e=e.attr("data-tooltip")||"";const h=e.includes("data-ticker-time-left");c.push({containerNumber:g,ho:k,tooltip:e,cq:h})});return c},async Om(){var b=await jQuery.get(F({mod:"overview",
sh:W("sh")}));b=jQuery(b).find("#char");if(!b.length)return D("No #char found in overview"),[];const c=[];b.find('[class^="item-i-"]').each(function(){var e=jQuery(this);const g=e.attr("data-container-number")||"",k=e.attr("data-basis")||"";e=e.attr("data-tooltip")||"";const h=e.includes("data-ticker-time-left");c.push({oo:g,ho:k,tooltip:e,No:h})});return c},async Cp(b,c){try{const e=b.getAttribute("data-container-number"),g=b.getAttribute("data-position-x"),k=b.getAttribute("data-position-y");await new Promise(h=>
setTimeout(h,250));await jQuery.post(T({mod:"inventory",submod:"move",from:e,fromX:parseInt(g,10),fromY:parseInt(k,10),to:c,toX:1,toY:1,amount:1,doll:1,a:Date.now(),sh:W("sh")}));D(`Applied oil from inventory to slot ${c}`);return!0}catch(e){return D(`Error applying oil from inventory: ${e}`),!1}},async jp(){const b=JSON.parse(localStorage.getItem("oilUsagePrefs")||"{}");if(b.oilEnable){var c={"12-18":"purple","12-19":"yellow","12-20":"orange","12-21":"green","12-22":"blue","12-23":"red"},e={purple:{rings:"purpleRings",
necklace:"purpleNecklace",weapon:"purpleWeapons",armor:"purpleArmor"},Qq:{rings:"yellowRings",necklace:"yellowNecklace",weapon:"yellowWeapons",armor:"yellowArmor"},orange:{rings:"orangeRings",necklace:"orangeNecklace"},green:{rings:"greenRings",necklace:"greenNecklace",weapon:"greenWeapons",armor:"greenArmor"},blue:{rings:"blueRings",necklace:"blueNecklace"},red:{rings:"redRings",necklace:"redNecklace"}},g=await this.Om(),k=await this.Fo();for(const q of k){k=jQuery(q);var h=k.attr("data-basis"),
l=c[h];h=!1;if(!l)continue;const n=e[l];if(n){l=Object.keys(n);for(const m of l)if(b[n[m]]){if("rings"===m){l=["6","7"];for(const r of l)if(this.vn(g,r)&&await this.gn(k,r)){h=!0;g=await this.Om();break}}else{l=null;switch(m){case "armor":l="5";break;case "weapon":l="3";break;case "necklace":l="11"}if(!l)continue;if(!this.vn(g,l))continue;await this.gn(k,l)&&(h=!0,g=await this.Om())}if(h)break}}else D(`No slot mapping for oil color: ${l}`)}D("Done attempting to apply oils.")}else D("Oil usage not enabled, skipping...")},
async qq(b,c){try{const e=b.closest(".packageItem").find('input[name="packages[]"]').val(),g=b.getAttribute("data-position-x"),k=b.getAttribute("data-position-y");let {spot:h,bag:l}=await ac(1,1);await new Promise(q=>setTimeout(q,250));await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+e,fromX:g,fromY:k,to:l,toX:h.x+1,toY:h.y+1,amount:1,doll:1,a:Date.now(),sh:W("sh")}));await new Promise(q=>setTimeout(q,250));await jQuery.post(T({mod:"inventory",submod:"move",from:l,fromX:h.x+1,fromY:h.y+
1,to:c,toX:1,toY:1,amount:1,doll:1,a:Date.now(),sh:W("sh")}));D("Oil items used on equipments.");return!0}catch(e){D(`Error in this.moveAndApplyOil: ${e}`)}},async Lp(){var b=bb.origin,c=bb.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);c=new DOMParser;await new Promise(e=>setTimeout(e,800));b=c.parseFromString(await b.text(),"text/html");c=JSON.parse(localStorage.getItem("gods"));for(let e in c)if((c=b.getElementById(e))&&0===(c.querySelector(".god_cooldown span")?
parseInt(c.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0))return!0;return!1}},ih,Fj={async start(){const b=localStorage.getItem("healPercentage")||25;var c=JSON.parse(localStorage.getItem("underworld")).isUnderworld;const e=localStorage.getItem("HealEnabled"),g=localStorage.getItem("HellHealHP")||15,k=localStorage.getItem("useVillaMedici"),h=localStorage.getItem("useHealingPotion"),l="true"===localStorage.getItem("usePray");if("true"==e&&ba.o<=Number(b)||"true"==
e&&ba.o<=parseInt(g)||"true"==k&&aa.player.key==xa&&ba.o<=b&&1==c||e&&"true"==h&&ba.o<=b&&1==c||e&&!c&&3>=Number(Fh().Ha)&&localStorage.getItem("autoEnterHell")&&ba.o<=localStorage.getItem("hellEnterHP")){c=document.createElement("div");c.setAttribute("id","lowHealth");c.setAttribute("style","\n                display: block;\n                position: absolute;\n                top: 140px;\n                left: 50%;\n                transform: translateX(-30%);\n                width: 115px;\n                color: rgba(234, 20, 20, 0.9);\n                background-color: rgba(0, 0, 0, 0.8);\n                font-size: 20px;\n                border-radius: 5px;\n                border-left: 10px solid rgba(234, 20, 20, 0.9);\n                border-right: 10px solid rgba(234, 20, 20, 0.9);\n                will-change: transform, opacity;\n                z-index: 999;\n            ");
c.innerHTML='<span class="span-new">Low Health!</span>';document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);async function q(){if("inventoryPage"!==document.body.id)Hf("mod=inventory&sub=3&subsub=1");else{await new Promise(L=>setTimeout(L,500));var E=Array.from(document.querySelectorAll("#shop .ui-draggable"));const t=ba.gold,u=bb.searchParams.get("doll")||"";let z=!1,B=0,J=!1,I;var A=localStorage.getItem("HealPickBag");A&&(I=511+Number(A)||512);
for(const L of E){if(B>=Number(localStorage.getItem("FoodAmount")))break;E=parseInt(L.getAttribute("data-price-gold"),10);(A=(A=L.getAttribute("data-basis"))&&"7"===A.split("-")[0])&&(z=!0);if(t>=E&&A){z=!0;localStorage.removeItem("healingStateX");E=Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));if(I&&(A=document.querySelector(`#inventory_nav a.awesome-tabs[data-bag-number="${I}"]`)))if(A.click(),await new Promise(O=>setTimeout(O,370)),A=document.getElementById("inv"),
Jc(A,L)){ea(L,"inv");B++;await new Promise(O=>setTimeout(O,370));if(B>=Number(localStorage.getItem("FoodAmount"))&&"1"!==u){Hf("mod=overview&doll=1");return}continue}else J=!0;if(J||!I)for(const O of E){if(B>=Number(localStorage.getItem("FoodAmount")))break;O.click();await new Promise(Z=>setTimeout(Z,500));E=document.getElementById("inv");if(Jc(E,L)&&(ea(L,"inv"),B++,await new Promise(Z=>setTimeout(Z,370)),B>=Number(localStorage.getItem("FoodAmount"))&&"1"!==u)){Hf("mod=overview&doll=1");return}}}}z?
(D(`${d.ub}`),localStorage.removeItem("healingStateX"),await new Promise(L=>setTimeout(L,3E4)),window.location.reload()):"true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")?await K():(D(`${d.ub}`),localStorage.removeItem("healingStateX"),await new Promise(L=>setTimeout(L,3E4)),window.location.reload());async function K(){if("true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")){if(document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')){var L=
jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),O=L.attr("action");L=L.find('input[name="bestechen"]')[0];var Z=W("sh");await jQuery.post(`${O}?mod=inventory&sub=3&subsub=1&sh=${Z}`,{bestechen:L.value})?D(`${d.wb}`):D(`${d.xb}`)}else 0<Fh().Ln&&"true"===localStorage.getItem("HealRubyToggle")&&!document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')?(L=jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),O=L.attr("action"),L=L.find('input[name="bestechen"]')[0],
Z=W("sh"),await jQuery.post(`${O}?mod=inventory&sub=3&subsub=1&sh=${Z}`,{bestechen:L.value})?D(`${d.wb}`):D(`${d.xb}`)):(D(`${d.Kf}`),localStorage.setItem("HealClothToggle","false"),localStorage.setItem("HealRubyToggle","false"));window.location.reload()}else localStorage.removeItem("healingStateX"),setTimeout(()=>{window.location.reload()},6E4)}return!1}}async function n(){if("guild"==W("mod"))localStorage.setItem("useVillaMedici","false"),Hf("mod=overview");else if("guild_medic"!=W("mod"))Hf("mod=guild_medic");
else{var E=Array.from(document.querySelectorAll("#content a")).filter(({href:A})=>A.includes("mod=guild_medic"));0<E.length?window.location.href=E[0].href:(E=Math.min(...Array.from(document.querySelectorAll("span[data-ticker-time-left]")).map(A=>parseInt(A.getAttribute("data-ticker-time-left"),10))),isFinite(E)&&Y("VillaMedici",Math.ceil(E/6E4)),l?(D(`${d.va}`),Hf("mod=underworld&submod=prayStart")):window.location.reload())}}async function m(){let E=!1;if("mod=premium&submod=inventory"!=mf)Hf("mod=premium&submod=inventory");
else{await new Promise(A=>setTimeout(A,500));for(let A=0,t=document.querySelectorAll(".contentboard_paper_repeat");A<t.length;A++)if(t[A].querySelector("img").src&&t[A].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")||t[A].querySelector("img").src&&t[A].querySelector("img").src.includes("token/18")||t[A].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")){E=!0;t[A].querySelector("input").click();Gf(1E3);return}E||(localStorage.setItem("useHealingPotion","false"),
l?(D(`${d.va}`),Hf("mod=underworld&submod=prayStart")):Gf(1E3))}}async function r(){try{let B=document.getElementById("inv"),J=0,I;var E=localStorage.getItem("HealPickBag")||2,A=localStorage.getItem("PackageSort")||"del_asc";I=E?511+Number(E)||512:512;var t=Array.from(document.querySelectorAll(`#inventory_nav a.awesome-tabs[data-bag-number="${I}"]`));0<t.length&&t[0].click();t=1;let K=0,L=!1;E=[];const O=Number(localStorage.getItem("FoodAmount"))||1;var u=F({mod:"packages",submod:"sort",page:"1",
sh:W("sh")});jQuery.post(u,{packageSorting:"del_asc"});u=!1;t=await ja.rm(-1,"",7);for(u=!0;!L&&5>K;){const fa=await jQuery.get(F({mod:"packages",f:"7",fq:"-1",qry:"",page:t.toString(),sh:W("sh")})),da=jQuery(fa).find(".packageItem");if(0===da.length)K++,u?t--:t++;else{E=[];for(let ma=0;ma<da.length;ma++){const pa=da[ma],ca=pa.querySelector("[data-content-type]"),qa=parseInt(ca.getAttribute("data-soulbound-to"),10),ya=parseInt(ca.getAttribute("data-basis").split("-")[1],10);(![30,35].includes(ya)&&
isNaN(qa)||![30,35].includes(ya)&&qa===Number(idkps))&&E.push(pa)}0<E.length?L=!0:(D(`${d.yb} (Page ${t})`),K++,u?t--:t++)}}var z=F({mod:"packages",submod:"sort",page:"1",sh:W("sh")});jQuery.post(z,{packageSorting:A});if(!L)return localStorage.setItem("healingStateX","true"),D(`${d.zb}`),!1;A=[5,8];const Z=bc(B);for(z=0;J<O&&z<E.length;){const fa=E[z],da=fa.querySelector("[data-content-type]"),ma=fa.querySelector("input").getAttribute("value"),pa=parseInt(da.getAttribute("data-measurement-x"),10),ca=
parseInt(da.getAttribute("data-measurement-y"),10),qa=parseInt(da.getAttribute("data-amount"),10),ya=cc(A[0],A[1],Z),Oa=lc(ca,pa,ya);if(Oa){Z.push({x:Oa.x,y:Oa.y,sl:ca,w:pa});await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+ma,fromX:1,fromY:1,to:I,toX:Oa.x+1,toY:Oa.y+1,amount:qa}),{a:(new Date).getTime(),sh:W("sh")});J++;const xb=jQuery(da).css({left:32*Oa.x,top:32*Oa.y});B.appendChild(xb[0]);D(`${d.If}`);await new Promise(Jb=>setTimeout(Jb,500))}else{D(`${d.Jf}`);break}z++}if(0<J)return J>=
O?D(`${d.Lf}`):D(`${d.Mf}`),!0;D(`${d.zb}`);return!1}catch(B){return D(`Error in pickFood(): ${B}`),!1}}async function w(){var E=document.querySelector("#header_values_hp_bar");const A=parseInt(E.getAttribute("data-value"),10);E=parseInt(E.getAttribute("data-max-value"),10);return{qo:A,So:E}}async function v(){var E=JSON.parse(localStorage.getItem("underworld")).isUnderworld,A="true"===localStorage.getItem("useSacrifice");const t="true"===localStorage.getItem("HealShop"),u=localStorage.getItem("HellHealHP")||
15,z="true"===localStorage.getItem("healingStateX"),B="true"===localStorage.getItem("HealPackage"),J=document.getElementById("sstat_ruby_val");let I=0;J&&(I=J.textContent.trim().replace(/\./g,""),I=parseInt(I,10));if(z&&t)await q()?await v():(localStorage.removeItem("healingStateX"),await C());else if(!0===E||"true"===h&&!0===E||!0===A&&!0===E)"true"===localStorage.getItem("useVillaMedici")&&of("VillaMedici")?n():"true"===localStorage.getItem("useHealingPotion")?await m():A&&5<=Number(I)?(D("Sacrificing for heal."),
Hf("mod=underworld&submod=offering")):l&&"mod=underworld&submod=pray"!=mf&&("true"===localStorage.getItem("HealEnabled")?ba.o<=Number(u):1)?(D(`${d.va}`),Hf("mod=underworld&submod=prayStart")):l&&"mod=underworld&submod=pray"==mf&&("true"===localStorage.getItem("HealEnabled")?ba.o<=Number(u):1)?(await new Promise(K=>setTimeout(K,6E4)),D(`${d.Yf}`),window.location.reload()):(D(`${d.Zf}`),Gf(6E4));else if(0==E)if("1"!==((new URL(window.location.href)).searchParams.get("doll")||""))"mod=overview&doll=1"!=
mf&&Hf("mod=overview&doll=1");else if(A=await C(),!A&&ba.o<=Number(b)||!A&&!E&&3>=Number(Fh().Ha)&&localStorage.getItem("autoEnterHell")&&ba.o<=localStorage.getItem("hellEnterHP"))B?(E=await r(),!E&&t?(localStorage.setItem("healingStateX","true"),q()):(E||(D(`${d.vb}`),await new Promise(K=>setTimeout(K,3E4))),window.location.reload())):t?(localStorage.setItem("healingStateX","true"),q()):(D(`${d.vb}`),await new Promise(K=>setTimeout(K,3E4)),window.location.reload())}async function x(E,A,t){let u=
null,z=0,B=Infinity;const J=localStorage.getItem("idkps")||0,I="true"===localStorage.getItem("HealCervisia"),K="true"===localStorage.getItem("HealEggs");let L=!1;I&&(L=await tf());E.forEach(O=>{var Z=O.getAttribute("data-basis");const fa=parseInt(O.getAttribute("data-soulbound-to"),10);var da=(da=O.getAttribute("data-tooltip").match(/Heals ([\d,\.]+) of life/))?parseInt(da[1].replace(/\./g,""),10):0;const ma=t-(A+da);if(!fa||fa===parseInt(J,10)){if(Z.startsWith("7-")){Z=parseInt(Z.split("-")[1],
10);if(!K&&23<=Z&&34>=Z||!I&&35===Z)return;if(I&&35===Z&&L)L=!0;else if(35===Z&&I&&!L)return}0<=ma&&ma<B?(u=O,B=ma):0>ma&&da>z&&(z=da,u=O)}});return u}async function C(){return new Promise(async E=>{let A=!1;const {qo:t,So:u}=await w();var z=new URL(window.location.href);const B=z.origin;z=z.searchParams.get("sh");if("mod=overview&doll=1"!=mf)Hf("mod=overview&doll=1");else{const Z="true"===localStorage.getItem("HealPackage"),fa="true"===localStorage.getItem("HealShop"),da="true"===localStorage.getItem("HealCervisia"),
ma="true"===localStorage.getItem("HealEggs");let pa=!1;da&&(pa=await tf());var J=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs")),I=J.findIndex(ca=>ca.classList.contains("current"));J=J.slice(I).concat(J.slice(0,I));for(I=0;I<J.length;I++){var K=J[I];if("false"!==K.getAttribute("data-available")&&(await new Promise(ca=>setTimeout(ca,175)),K.click(),K.classList.contains("current"))){K=document.querySelectorAll("#inv .ui-draggable");K=Array.from(K).filter(ca=>{const qa=ca.getAttribute("data-basis");
ca=parseInt(ca.getAttribute("data-soulbound-to"),10);const ya=parseInt(qa.split("-")[1],10);if(!ca||ca===parseInt(idkps,10)){if(qa.startsWith("7-")){if(!ma&&23<=ya&&34>=ya||!da&&35===ya)return;if(pa&&da&&35===ya)pa=!0;else if(35===ya&&da&&!pa)return}return qa&&"7"===qa.split("-")[0]}});var L=void 0,O=!1;if(100<=ba.level&&Va.cooldown()&&"true"==localStorage.getItem("autoEnterHell")){L=await (await fetch(`${B}/game/index.php?mod=hermit&sh=${z}`)).text();L=(new DOMParser).parseFromString(L,"text/html");
L=Array.from(L.querySelectorAll('div[style="margin:20px"]'));for(let ca of L)if(ca.querySelector('a[href^="index.php?mod=hermit&submod=underworld&sh="]')){O=!0;break}}if(O){O=0;L=localStorage.getItem("idkps");for(const ca of K)if(K=parseInt(ca.getAttribute("data-soulbound-to"),10),(!K||K===parseInt(L,10))&&"true"===localStorage.getItem("autoEnterHell"))if(ca)await new Promise(qa=>setTimeout(qa,250)),await ea(ca,"avatar"),await new Promise(qa=>setTimeout(qa,450)),D(`${d.tb}`),O++,2<=O&&window.location.reload();
else{K=!1;Z&&(K=await r());if(!K&&fa)return localStorage.setItem("healingStateX","true"),q(),!0;window.location.reload()}}else for(const ca of K){A=!0;if(O=await x(K,t,u))await new Promise(qa=>setTimeout(qa,250)),await ea(O,"avatar"),await new Promise(qa=>setTimeout(qa,450)),D(`${d.tb}`);else if(O=!1,Z&&(O=await r()),!O&&fa){localStorage.setItem("healingStateX","true");q();return}window.location.reload()}}}E(A)}})}await v()}}},Va={isUnderworld(){if("underworld"==document.getElementById("wrapper_game").className){var b=
JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else b=JSON.parse(localStorage.getItem("underworld")||"{}"),b.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(b));return(b=document.querySelector("#submenu2 a"))&&b.href.match(/mod=.*&sh/)&&"mod=underworld&submod=leave"===b.href.match(/mod=.*&sh/)[0].slice(0,-3)?!0:!1},oj(){return!0!==(JSON.parse(localStorage.getItem("underworld"))||{}).oj},cooldown(){var b=
(new Date).getTime();let c=JSON.parse(localStorage.getItem("underworld"))||{};c.cooldown=b;localStorage.setItem("underworld",JSON.stringify(c));let e=document.getElementById("submenu2");e&&e.innerHTML.includes("index.php?mod=underworld")?c.isUnderworld=!0:c.isUnderworld=!1;if(aa.$m.cooldown&&aa.$m.cooldown>b)return!1;if(b=document.querySelectorAll(".buff-clickable"))for(let g of b)if(g.getAttribute("data-link")=="index.php?mod=location&sh="+W("sh"))return!1;return!0},async start(){function b(){var u=
`expedition_info${parseInt(localStorage.getItem("farmEnemy"),10)||1}`,z=document.getElementById(u);if(!z)return!1;u=z.querySelector(".expedition_picture img");z=z.querySelector(".expedition_picture .avatar_costume_animation");if(!u&&!z)return!1;if(u){var B=u.getAttribute("src");if(!B)return!1;B=!B.includes("904194973d21066c96cb414d04d676")}z&&(B=z.style.backgroundImage.match(/url\("(.+?)"\)/),u=null,B&&B[1]&&(u=B[1]),B=!u.includes("904194973d21066c96cb414d04d676"));return B}async function c(u=!1){if(Va.isUnderworld||
!x){0<(JSON.parse(localStorage.getItem("GodPowersHell"))||[]).length&&0==u&&await e();Y("underworldArmorBuffs",15);var z="true"===localStorage.getItem("useWeaponBuff"),B=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||[];u=[];z&&u.push({type:"weapon",jc:"12-1",fm:[3]});if(0<B.length){const J={Helmet:2,Armor:5,Shield:4,Boots:10,Gloves:9};z=B.map(I=>J[I]).filter(I=>I);0<z.length&&u.push({type:"armor",jc:"12-3",fm:z})}0<u.length&&await g(u);localStorage.setItem("usedGodPowers","true")}}async function e(){if("true"===
localStorage.getItem("useGodPowersHell")){var u=JSON.parse(localStorage.getItem("GodPowersHell"))||[],z="Minerva Diana Vulcan Mars Apollo Mercury".split(" ");for(let B of u)if(u=z.indexOf(B),-1<u)try{await jQuery.get(F({mod:"gods",submod:"activateBlessing",god:u+1,rank:1,sh:W("sh")})),D(`${B} power activated`)}catch(J){}}}async function g(u){var z=u.map(J=>J.jc);const B={};z=await k(z);Object.assign(B,z);for(let J of u.slice())if(z=B[J.jc])await q(z,J.fm),u=u.filter(I=>I.jc!==J.jc),D(`${J.type.charAt(0).toUpperCase()+
J.type.slice(1)} buff equipped on slots ${J.fm.join(", ")}`);0<u.length&&await h(u)}async function k(u){return new Promise(async z=>{const B={};var J=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));for(let I of J)if("false"!==I.getAttribute("data-available")){I.click();await new Promise(K=>setTimeout(K,200));J=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let K of J)if(J=K.getAttribute("data-basis"),u.includes(J)&&!B[J]){const L=parseInt(K.getAttribute("data-position-x"),
10),O=parseInt(K.getAttribute("data-position-y"),10),Z=parseInt(K.getAttribute("data-container-number"),10);B[J]={fromX:L,fromY:O,from:Z};if(Object.keys(B).length===u.length){z(B);return}}}z(B)})}async function h(u){try{let z=1;for(;1<=z&&7>=z&&0<u.length;){const B=await jQuery.get(F({mod:"packages",f:"12",page:z.toString(),sh:W("sh")})),J=Array.from(jQuery(B).find(".packageItem"));for(let I of J){const K=I.querySelector("[data-content-type]"),L=I.querySelector("[data-container-number]");K.getAttribute("data-measurement-x");
K.getAttribute("data-measurement-y");const O=K.getAttribute("data-basis");L.getAttribute("data-container-number");const Z=L.getAttribute("data-container-number"),fa=u.find(da=>da.jc===O);if(fa&&await l(Z,fa.fm)&&(D(`${fa.type.charAt(0).toUpperCase()+fa.type.slice(1)} buff equipped on slots ${fa.fm.join(", ")}`),u=u.filter(da=>da.jc!==O),0===u.length))return}z++}if(0<u.length)for(let B of u)D(`Could not find ${B.type} buff to equip.`)}catch(z){}}async function l(u,z){return new Promise((B,J)=>{ac(1,
1,async(I,K)=>{try{await jQuery.post(T({}),{mod:"inventory",submod:"move",from:u,fromX:1,fromY:1,to:K,toX:I.x+1,toY:I.y+1,amount:1,a:(new Date).getTime(),sh:W("sh")});const L={fromX:I.x+1,fromY:I.y+1,from:K};await q(L,z);B(L)}catch(L){console.error("Error moving item to inventory and equipping:",L),J(L)}})})}async function q(u,z){for(let B of z)await n(u.from,u.fromX,u.fromY,B,1,1,!0),await new Promise(J=>setTimeout(J,200))}async function n(u,z,B,J,I,K,L=!1){u={mod:"inventory",submod:"move",from:u,
fromX:z,fromY:B,to:J,toX:I,toY:K,amount:1,a:(new Date).getTime(),sh:W("sh")};L&&(u.doll=1);await jQuery.post(T({}),u)}this.location=Array.from(document.querySelectorAll("#submenu2 a")).pop().href;var m="true"===localStorage.getItem("farmEnable"),r=localStorage.getItem("farmLocation")||1;const w=localStorage.getItem("farmEnemy")||1;var v="true"===localStorage.getItem("useGodPowersHell");const x="true"===localStorage.getItem("usedGodPowers");var C=localStorage.getItem("hellLimit")||0;const E="true"===
localStorage.getItem("EnableHellLimit");if(v&&!x){if("mod=overview&doll=1"!=mf){Hf("mod=overview&doll=1");return}await c()}if(of("underworldArmorBuffs")){if("mod=overview&doll=1"!=mf){Hf("mod=overview&doll=1");return}await c(!0)}let A;m&&(A=b());v=localStorage.getItem("HellHealHP")||15;ba.o>=Number(v)&&await jQuery.get(F({mod:"underworld",submod:"prayEnd",sh:W("sh")}));if("true"==localStorage.getItem("exitUnderworld")&&0==Number(Fh().Ha))C=JSON.parse(localStorage.getItem("underworld")),C.isUnderworld=
!1,localStorage.setItem("underworld",JSON.stringify(C)),await jQuery.get(F({mod:"underworld",submod:"exit",sh:W("sh")})),D(`${d.$f}`),location.reload();else{if(0==Number(Fh().Ha)&&"true"==localStorage.getItem("UnderworldUseMobi")){if("mod=premium&submod=inventory"!==mf){Hf("mod=premium&submod=inventory");return}v=document.querySelectorAll(".contentboard_paper_repeat");for(var t=0;t<v.length;){v[t].querySelector("img").src&&(v[t].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7")||
v[t].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7"))?v[t].querySelector("input").click():localStorage.setItem("UnderworldUseMobi","false");Gf(500);return}}t=document.querySelector("#submenu2");v=t.querySelector(`#location_inactive_${r}`);t=t.querySelector(`a[href*="loc=${r}"]`);v=v&&v.classList.contains("inactive");if(!m||v&&!t||mf===`mod=location&loc=${r}`)if(m&&mf==`mod=location&loc=${r}`&&A&&(!E||E&&0<C))m=parseInt(w,10),r=document.getElementsByClassName("expedition_button"),
E&&(C--,localStorage.setItem("hellLimit",C)),r[m-1].click(),Gf(5E3);else if(window.location.href!=this.location)window.location.href=this.location;else{await jQuery.get(F({mod:"underworld",submod:"prayEnd",sh:W("sh")}));let u=0;Array.from(document.querySelectorAll(".expedition_box")).forEach(z=>{z.querySelector(".expedition_picture img")&&z.querySelector("img").src.includes("904194973d21066c96cb414d04d676")&&u++});document.querySelector("#content .icon_expeditionpoints")&&0<Number(Fh().Ha)||"true"==
localStorage.getItem("UnderWorldUseRuby")&&"0"==Fh().Ha?(ka("underworldAttacks",0),document.querySelectorAll(".expedition_button")[Math.floor(3-u)].click()):(D(`${d.ag}`),await new Promise(z=>setTimeout(z,6E4)),Gf())}else Hf(`mod=location&loc=${r}`)}},async wo(){let b=0;const c=["normal","medium","hard"][parseInt(localStorage.getItem("hellDifficulty"),10)||0],e=F({mod:"hermit",submod:"enterUnderworld",sh:W("sh")}),g={};g[`difficulty_${c}`]=c.charAt(0).toUpperCase()+c.slice(1);try{jQuery.post(e,g),
localStorage.setItem("usedGodPowers","false"),await new Promise(k=>{const h=++b;var l=!document.hidden;let q=1;var n=jQuery("#server-time");0<n.length&&(n=n.next().html())&&(n=n.match(/x(\d+)$/)||["0","1"],n=parseInt(n[1],10),0<n&&(q=5/n));l=l?400:400*q;if("undefined"!==typeof Worker){const m=URL.createObjectURL(new Blob(["\n                            const timers = {};\n                            self.onmessage = function(event) {\n                                const { type, id, delay } = event.data;\n                                if (type === 'setTimeout') {\n                                    timers[id] = setTimeout(() => {\n                                        self.postMessage({ type: 'timeout', id });\n                                        delete timers[id];\n                                    }, delay);\n                                }\n                                if (type === 'clearTimeout') {\n                                    if (timers[id]) {\n                                        clearTimeout(timers[id]);\n                                        delete timers[id];\n                                    }\n                                }\n                            };\n                        "],
{type:"application/javascript"})),r=new Worker(m),w=v=>{"timeout"===v.data.type&&v.data.id===h&&(k(),r.removeEventListener("message",w),r.terminate(),URL.revokeObjectURL(m))};r.addEventListener("message",w);r.postMessage({type:"setTimeout",id:h,delay:l})}else setTimeout(()=>{k()},l)}),window.location.reload()}catch(k){}}};null===localStorage.getItem("DELAY")&&localStorage.setItem("DELAY","0 seconds");var zc=localStorage.getItem("DELAY");if(zc.includes("to")){const b=zc.split(" "),c=parseInt(b[0],
10);var Xb=Math.floor(Math.random()*(parseInt(b[2],10)-c+1))+c}else Xb=parseInt(zc.split(" ")[0],10);zc.includes("minute")&&(Xb*=60);var Ac=1E3*Xb,Gj=localStorage.getItem("costumeUnderworld"),Hj=["9","10","11"],Bc="true"===localStorage.getItem("activateAuction2"),vh="true"===localStorage.getItem("auctionTURBO"),Cc="true"===localStorage.getItem("bidFood"),wh=9<ba.level,xh="true"===localStorage.getItem("enableCircusWithoutHeal"),Ij="true"===localStorage.getItem("resetUnderworld"),yh="true"===localStorage.getItem("auctiongladiatorenable"),
zh="true"===localStorage.getItem("auctionmercenaryenable"),Dc="true"===localStorage.getItem("enableMercenarySearch"),hf="true"===localStorage.getItem("EnableArenaHell"),Jj="true"===localStorage.getItem("dontEnterUnderworld"),Ec=0<JSON.parse(localStorage.getItem("auctionPrefixes")).length||0<JSON.parse(localStorage.getItem("auctionSuffixes")).length,Db=localStorage.getItem("auctionStatus")>=localStorage.getItem("bidStatus"),Ah=localStorage.getItem("auctionMStatus")>=localStorage.getItem("bidStatus"),
eb=JSON.parse(localStorage.getItem("underworld")),Eb=of("auction"),Bh=of("auctionM"),Ch=localStorage.getItem("MarketlastRan"),Kj=localStorage.getItem("MarketSearchInterval")||5,Lj=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),Mj=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),Dh=JSON.parse(localStorage.getItem("itemsToReset")||"[]"),jf=eb.oj;jf=jf?!1:!0;va&&"true"===localStorage.getItem("activateRepair")&&sj();0<Ac&&(D(`Waiting for ${Xb} seconds...`),await new Promise(b=>
setTimeout(b,Ac)));if(va&&(0<Object.keys(Lj).length||0<Object.keys(Mj).length)&&"true"===localStorage.getItem("activateRepair")&&of("repair")&&!window.location.href.includes("/index.php?mod=hermit&submod=underworld")&&aa.player.key==xa&&2E3<Fh().gold&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)){const b="true"===localStorage.getItem("repairGladiator"),c="true"===localStorage.getItem("repairMercenary");let e=[],g=[];const k=JSON.parse(localStorage.getItem("activeItemsGladiator")||
"{}"),h=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}");async function l(v,x,C){const E=localStorage.getItem("repairPercentage"),A=null!==E?parseInt(E,10)/100:.1;v=await (await fetch(`${v}/game/index.php?mod=overview&doll=${x}&sh=${C}`)).text();v=(new DOMParser).parseFromString(v,"text/html").getElementById("char").querySelectorAll("div[data-tooltip]");C=(C=localStorage.getItem("workbenchItem"))?JSON.parse(C):{};C.selectedItem=C.selectedItem||{};let t=[];v.forEach(u=>{if(u.classList.contains("ui-draggable")){let z=
Gb(u),B=u.getAttribute("data-container-number"),J=u.getAttribute("data-measurement-x"),I=u.getAttribute("data-measurement-y"),K=JSON.parse(u.getAttribute("data-tooltip")).pop().pop()[0].match(/\d+/g);null!=K&&K[0]/K[1]<A&&t.push({type:Ca(u),quality:Ba(u),name:z,doll:x,container:B,yn:J,zn:I})}});return t}const q=bb.origin,n=bb.searchParams.get("sh")||"";let m=localStorage.getItem("workbenchItem");m=m?JSON.parse(m):{};b&&(e=await l(q,1,n),localStorage.setItem("itemList1",JSON.stringify(e)),aa.workbench.itemList1=
e);c&&(g=await l(q,2,n),localStorage.setItem("itemList2",JSON.stringify(g)),aa.workbench.itemList2=g);const r=JSON.parse(localStorage.getItem("Timers"));m.selectedItem||(b&&c?0===e.length&&0===g.length&&Y("repair",r.Repair||10):b?0===e.length&&Y("repair",r.Repair||10):c?0===g.length&&Y("repair",r.Repair||10):Y("repair",r.Repair||10));function w(v,x,C){return Array.isArray(v)&&0!==v.length?v.filter(E=>{const A=Object.keys(x).find(t=>x[t]===E.container);return A?!1!==C[A]:!0}):v}e=w(e,{helmet:"2",necklace:"11",
weapon:"3",armor:"5",shield:"4",gloves:"9",shoes:"10",rings1:"6",rings2:"7"},k);g=w(g,{helmetM:"2",necklaceM:"11",weaponM:"3",armorM:"5",shieldM:"4",glovesM:"9",shoesM:"10",rings1M:"6",rings2M:"7"},h);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(g));aa.workbench.itemList1=e;aa.workbench.itemList2=g;if(m.selectedItem&&!0===m.selectedItem.enable){let v=e.findIndex(x=>x.name===m.selectedItem.item.name);-1!==v&&e.splice(v,1);v=g.findIndex(x=>x.name===
m.selectedItem.item.name);-1!==v&&g.splice(v,1);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(g))}if(b&&0<e.length||c&&0<g.length||m.selectedItem&&0<Object.keys(m.selectedItem).length)await Ej.start();else{const v=JSON.parse(localStorage.getItem("Timers"));Y("repair",v.Repair||10);window.location.reload()}}else if(0==await kj(xa,ec,aa.player.supportDevelopersPlease))gb();else if((Bc||Cc||Dc)&&vh&&Bc&&va&&wh&&(yh&&Ec&&Db&&Eb&&of("AuctionEmpty")||
Cc&&Db&&Eb&&of("AuctionEmpty")||Dc&&Db&&Eb&&of("AuctionMEmpty")||zh&&Ec&&Ah&&Bh&&of("AuctionMEmpty")))await za.start();else if(va&&"true"===localStorage.getItem("EnableSmelt")&&ja.kn()&&1E3<ba.gold&&of("smelt"))of("smeltCheck")&&(ja.slots=await ja.u(),await ja.Fm(ja.slots),await ja.Xm(ja.slots),"true"===localStorage.getItem("EnableSmelt")&&1E3<ba.gold&ja.kn()&&of("smelt")&&await ja.start());else if(va&&3>=Number(Fh().Ha)&&!0===Fa&&"true"===localStorage.getItem("autoEnterHell")&&100<=ba.level&&8E3<=
ba.gold&&ba.o>Number(localStorage.getItem("hellEnterHP"))&&Va.cooldown()&&(Jj?jf:1))await Va.wo();else if(1==va&&"true"===localStorage.getItem("OilEnable")&&Ra.mo()&&(!th||36E5<=uh-th)){D(`${d.Of}`);localStorage.setItem("OillastRan",uh.toString());const b=await Ra.zo();for(let c=0;c<Ra.H.length;c++)await Ra.Wm(c,b);await Ra.jp();D(`${d.Pf}`);af()}else if(va&&of("circus")&&!0===Ma&&9<ba.level&&(ba.o>Number(localStorage.getItem("healPercentage"))||"true"===localStorage.getItem("enableCircusWithoutHeal"))&&
aa.player.key==xa&&!0===document.getElementById("cooldown_bar_fill_ct").classList.contains("cooldown_bar_fill_ready")){async function b(){var h=new URL(window.location.href),l=h.origin;h=h.searchParams.get("sh")||"";var q=localStorage.getItem("scoreRangeCircus"),n=[];l=await (await fetch(`${l}/game/index.php?mod=highscore&sh=${h}&a=${q}`)).text();l=(new DOMParser).parseFromString(l,"text/html");l=Array.from(l.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(m=>(m=m.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?
!("green"===m.style.color||"blue"===m.style.color):null===m);n=[...n,...l];if(0===n.length)return console.log("No players available to attack"),!1;l=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];q=function(m){for(var r=m.length,w,v;0!==r;)v=Math.floor(Math.random()*r),--r,w=m[r],m[r]=m[v],m[v]=w;return m}(n);n=0;for(let m of q)if(q=m.textContent.toLowerCase(),!l.map(r=>r.toLowerCase()).includes(q)){q=await c(m.textContent,h);if(q.includes("index.php?mod=reports")){h=(new URLSearchParams(q)).get("reportId");
D(`${d.ta}`+m.textContent);Hf(`mod=reports&submod=showCombatReport&t=3&reportId=${h}`);await new Promise(r=>setTimeout(r,500));return}n++;if(3<=n)break}return!1}async function c(h,l){try{const q=(new URL(window.location.href)).origin;return await (await fetch(`${q}/game/ajax/doGroupFight.php?dname=${h}&a=${Date.now()}&sh=${l}`,{method:"POST"})).text()}catch{Gf(1E3)}}async function e(h){var l=h.opponentId;const q=h.serverId;h=h.country;var n=(new URL(window.location.href)).origin;n=new URL(`${n}/game/ajax.php`);
l={mod:"arena",submod:"doCombat",aType:3,opponentId:l,serverId:q,country:h.toString(),a:(new Date).getTime(),sh:W("sh")};n.search=(new URLSearchParams(l)).toString();return await (await fetch(n,{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function g(){function h(x){const C=null!==x.querySelector("span[style*='color:green;']");return Array.from(x.querySelectorAll("a, span")).find(E=>"green"===E.style.color||"bold"===E.style.fontWeight)||
C}var l=new URL(window.location.href);const q=l.origin;var n=await (await fetch(`${q}/game/index.php?mod=arena&submod=grouparena&sh=&sh=${W("sh")}`)).text();n=(new DOMParser).parseFromString(n,"text/html");var m=Array.from(n.querySelectorAll('table[width="80%"] tbody tr')).filter(x=>x.querySelector(".attack"));if(m.length&&1!==m.length){var r=null;n=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];if("true"===localStorage.getItem("leaguecircusrandom")){m=m.sort(()=>Math.random()-.5);
for(var w of m){var v=w.querySelector("a");v=v?v.innerText:null;if(!h(w)&&!n.includes(v)){r=w;break}}}else if("true"===localStorage.getItem("leaguecircuslowtohigh")){m=m.sort((x,C)=>parseInt(x.querySelector("th")?x.querySelector("th").textContent:"0",10)-parseInt(C.querySelector("th")?C.querySelector("th").textContent:"0",10));w=null;r=-1;for(v of m)m=(m=v.querySelector("a"))?m.innerText:null,h(v)||n.includes(m)||(m=parseInt(v?.querySelector("th")?.textContent,10),m>r&&(r=m,w=v));r=w}if(null===r)localStorage.setItem("leaguecircuslowtohigh",
"false"),localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircusattackenable","false"),Gf(500);else if(r)if(n=r.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],v=(new Date).getTime(),l=l.searchParams.get("sh")||"",await new Promise(x=>setTimeout(x,250)),l=await (await fetch(`${q}/game/ajax/doGroupFight.php?did=${n}&a=${v}&sh=${l}`)).text(),(n=l.match(/document\.location\.href\s*=\s*'([^']+)'/))&&n[1])window.location=`${q}/game/${n[1]}`;else{l.includes("5")&&
("true"===localStorage.getItem("leaguecircuslowtohigh")?(localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","true")):"true"===localStorage.getItem("leaguecircusrandom")&&(localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusattackenable","false")),location.reload());if(l.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leaguecircusattackenable",
"false"),location.reload()}async function k(){function h(t){const u=Date.now(),z=x.findIndex(B=>B.playerName===t);-1<z?x[z].timeout=u:x.push({playerName:t,timeout:u});localStorage.setItem("playerTimeouts",JSON.stringify(x))}function l(t,u){const z=Date.now();if(Array.isArray(x)){const B=x.find(J=>J.playerName===t);return!B||z-B.timeout>u}return!x[t]||z-x[t]>u}function q(t){for(var u=t.length-1;0<u;u--){const z=Math.floor(Math.random()*(u+1));[t[u],t[z]]=[t[z],t[u]]}2<t.length&&(u=t.splice(0,2),t.push(...u));
return t}async function n(t,u,z){try{const B=u.match(/\d+/)[0],J=u.match(/\w+/g)[2],I=(new URLSearchParams(u)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:z,aType:t,opponentId:I,serverId:B,country:J}));const K=await jQuery.get(T({mod:"arena",submod:"confirmDoCombat",aType:t,opponentId:I,serverId:B,country:J,a:(new Date).getTime(),sh:W("sh")})),L=(new URLSearchParams(K)).get("reportId");L||window.location.reload();Hf(`mod=reports&submod=showCombatReport&t=${t}&reportId=${L}`)}catch(B){document.getElementById("content").querySelector("form > input").click(),
Gf(1E3)}}"true"===localStorage.getItem("leaguecircusattackenable")&&await g();"true"===localStorage.getItem("scoreboardcircusenable")&&await b();var m=(new URL(window.location.href)).searchParams.get("sh")||"",r=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[];let w=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[];const v=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];let x=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const C="true"===localStorage.getItem("onlyCircus");
localStorage.getItem("CircusSimulatorAmount");const E="true"===localStorage.getItem("onlyPlayerListCircus");if(of("circus")&&0<r.length||of("circus")&&0<w.length||C||E)try{q(r);localStorage.setItem("autoAttackCircusList",JSON.stringify(r));q(w);localStorage.setItem("autoAttackCircusServerList",JSON.stringify(w));let t=0,u=3,z=0,B=0;C&&(u=15);const J=r.length+w.length;for(E&&(u=J);t<u&&(z<r.length||B<w.length);){let I,K,L;(L=z<r.length&&B<w.length?.5>Math.random():B<w.length)?(K=w[B],I=K.playerName,
B++):(I=r[z],z++);if(!v.includes(I)&&(l(I,6E4*(10+Math.floor(36*Math.random())))||C)){let O;O=L?await e(K):await c(I,m);ka("circusAttacks",0);if(O.includes("index.php?mod=reports")&&!O.includes("errorRow")){h(I);D(`${d.ta}`+I);window.location.reload();break}}t++}if(t===u&&E){D("Tried to attack circus list. Timing out 1min.");Y("circus",1);window.location.reload();return}}catch(t){window.location.reload()}if("mod=arena&submod=serverArena&aType=3"!=mf)Hf("mod=arena&submod=serverArena&aType=3");else try{if(document.querySelector(".messages .message.fail"))localStorage.setItem("doCircus",
!1),window.location.reload();else{let t=[...r,...w].map(B=>B.playerName);var A=Array.from(document.querySelectorAll("#own3 tr")).slice(1);const u="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),z="true"===localStorage.getItem("attackRandomly");m=null;r=Infinity;localStorage.getItem("Username");localStorage.getItem("enableCircusSimulator");for(let B of A){const J=B.querySelector("a");A=2;z&&(A=Math.floor(5*Math.random())+2);const I=B.querySelector(`td:nth-child(${A})`);
if(J&&I){const K=J.innerText,L=parseInt(I.textContent.trim(),10),O=v.includes(K),Z=null!==J.querySelector("span[style*='color:green;']"),fa="green"===J.style.color;if(!(O||!u&&Z&&fa)){if(t.includes(K)){D(`${d.ta}`+K);m=J;break}!m&&L<r&&(r=L,m=J)}}}if(m)await n(3,m.href,m.outerText),ka("circusAttacks",0);else{const B=document.querySelector('form[name="filterForm"] input[type="submit"]');B&&B.click()}}}catch{window.location.reload()}}1==Bb.isUnderworld?(await jQuery.get(F({mod:"underworld",submod:"prayEnd",
sh:W("sh")})),await k()):xh?await k():!xh&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&await k()}else if(va&&(ba.o<=Number(localStorage.getItem("healPercentage"))&&"true"===localStorage.getItem("HealEnabled")&&!Va.isUnderworld()||3>=Number(Fh().Ha)&&100<=ba.level&&!Va.isUnderworld()&&Va.cooldown()&&"true"===localStorage.getItem("autoEnterHell")&&ba.o<=Number(localStorage.getItem("hellEnterHP"))||Va.isUnderworld()&&"true"===localStorage.getItem("autoEnterHell")&&
"true"===localStorage.getItem("HealEnabled")&&ba.o<=Number(localStorage.getItem("HellHealHP"))))await Fj.start();else if(va&&Fa&&"true"===localStorage.getItem("autoEnterHell")&&Va.isUnderworld()&&Fh().xo)await Va.start();else if(va&&"true"==localStorage.getItem("useCostume")&&(!window.location.href.includes("/index.php?mod=hermit")&&of("CheckDolls")&&Hj.some(b=>Gj.includes(b))||!window.location.href.includes("/index.php?mod=hermit")&&of("CheckDolls")))await ff.start();else if(va&&(!0===Ta&&V()&&aa.player.key==
xa||!0===Ta&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&Vb<Wb&&aa.player.key==xa)){localStorage.setItem("nextQuestTime.timeOut",0);localStorage.setItem("nextQuestTime",0);function b(k){const h={Diana:"026bb622a42b4d00abc74c67f28d63",Apollo:"bb75bf0df76de3ec421bbfb0eac3c5",Vulcan:"6fbd05e43d699e65fc40cc92a17c51",Minerva:"72919cc6b457bf475fb81cc7de8863",Mercury:"5e272e2aade20b4a266e48663421ce",Mars:"5fd915f85b3e5e71b64632af0c6543"};k=k.querySelectorAll(".quest_slot_reward img");
for(const l of k){k=l.getAttribute("src");for(const [q,n]of Object.entries(h))if(k.includes(n)&&"true"===localStorage.getItem(`questType${q}`))return!0}}function c(k){var h=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]").map(q=>q.toLowerCase());const l=parseInt(localStorage.getItem("questrewardvalue"),10);if(k=$(k).find(".quest_slot_reward_item")[0]){const q=k.outerHTML.toLowerCase();if(h.some(n=>q.includes(n))&&(h=q.match(/(\d+\.\d+)/))&&parseFloat(h[0].replace(".",""))>=l)return!0}return!1}
async function e(){var k=bb.origin,h=$("#content .contentboard_slot a.quest_slot_button_accept"),l="true"===localStorage.getItem("skipTimeQuests");const q="true"===localStorage.getItem("skipTimeCircusQuests"),n="true"===localStorage.getItem("skipTimeOtherQuests"),m="true"===localStorage.getItem("acceptnotfilter"),r="true"===localStorage.getItem("UnderworldQuests"),w=JSON.parse(localStorage.getItem("questKeywords")||"[]"),v=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]"),x=JSON.parse(localStorage.getItem("underworldQuestKeywords")||
"[]"),C=JSON.parse(localStorage.getItem("underworld")||"{}");var E=$("#content .contentboard_slot_inactive").toArray();if(h.length){function A(t){return t.includes("8aada67d4c5601e009b9d2a88f478c")?"combat":t.includes("00f1a594723515a77dcd6d66c918fb")?"arena":t.includes("586768e942030301c484347698bc5e")?"circus":t.includes("4e41ab43222200aa024ee177efef8f")?"expedition":t.includes("dc366909fdfe69897d583583f6e446")?"dungeon":t.includes("5a358e0a030d8551a5a65d284c8730")?"items":null}h=!1;for(const t of E){let u=
t.getElementsByClassName("quest_slot_title")[0].innerText;E=A(t.getElementsByClassName("quest_slot_icon")[0].style.backgroundImage);if(!(l&&0<t.getElementsByClassName("quest_slot_time").length&&"arena"==E||q&&0<t.getElementsByClassName("quest_slot_time").length&&"circus"==E||n&&0<t.getElementsByClassName("quest_slot_time").length&&"circus"!==E&&"arena"!==E)){if(1==C.isUnderworld&&r&&!h&&0<x.length&&Na[E]&&r){const z=$(t).find(".quest_slot_reward_item img[data-tooltip]")[0];if(z){E=z.getAttribute("data-tooltip");
const B=JSON.parse(E.replace(/&quot;/g,'"'))[0][0][0].toLowerCase();if(x.some(J=>B.includes(J.toLowerCase()))){l=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();h=!0;break}else continue}}if(!w.some(z=>u.includes(z))){if(Na[E]&&b(t)){l=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();h=!0;break}if(Na[E]&&c(t)&&!m){l=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");
await jQuery.get(l).done();h=!0;break}if(Na[E]&&v.some(z=>u.includes(z))){l=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();h=!0;break}!h&&Na[E]&&m||h||!Na[E]||m||0!==v.length||(h=t.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),await jQuery.get(h).done(),h=!0)}}}if(h)return;k=`${k}/game/index.php?mod=quests&submod=resetQuests&sh=${W("sh")}`;await jQuery.get(k).done();window.location.reload()}g()}async function g(){var k=
$("#quest_header_cooldown");let h;switch(localStorage.getItem("questSpeed")){case "0":h=15E4;break;case "1":h=2E5;break;case "2":h=25E4;break;case "3":h=3E5;break;case "4":h=4E5;break;default:h=3E5}k.length?(k=Number($("#quest_header_cooldown b span").attr("data-ticker-time-left")),Vb=Wb+k):Vb=Wb+h;localStorage.setItem("nextQuestTime",Vb);window.location.reload()}await async function(){if("mod=quests"!=mf)Hf("mod=quests");else{let k=[];const h=[],l=[];document.querySelectorAll("a.quest_slot_button_finish").forEach(m=>
{m.href&&k.push(m.href)});document.querySelectorAll(".quest_slot_button_restart").forEach(m=>{m.href&&h.push(m.href)});document.querySelectorAll(".quest_slot_button_accept").forEach(m=>{m.href&&l.push(m.href)});async function q(m){try{m<k.length&&(await jQuery.get(k[m]),await q(m+1))}catch(r){}}async function n(m){try{m<h.length&&(await jQuery.get(h[m]),await n(m+1))}catch(r){}}await async function(){0<k.length&&await q(0);0<h.length&&await n(0);0<l.length&&await e();await g()}()}}()}else if(va&&
Gh()&&"true"===localStorage.getItem("doKasa")&&of("gold")&&Fh().gold>Math.floor(localStorage.getItem("KasaHoldGold")))await Wh();else if(va&&5<ba.level&&"true"==localStorage.getItem("storeGoldinAuction")&&Number(Fh().gold)>Math.floor(Number(localStorage.getItem("storeGoldinAuctionmaxGold")))&&of("enableHideGold"))await lb.A.start();else if(va&&Kc()&&!0===Fa&&0==eb.isUnderworld&&aa.player.key==xa&&0==Bb.isUnderworld&&aa.player.Fd>=new Date&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):
1)&&!0===document.getElementById("cooldown_bar_fill_expedition").classList.contains("cooldown_bar_fill_ready"))await async function(){function b(){const l=document.getElementById("errorText");"false"===localStorage.getItem("HealEnabled")?(Ya("Your expedition/dungeon settings are incorrect!"),localStorage.setItem("HealEnabled","true"),Gf(5E3)):l&&""!==l.innerText.trim()&&location.reload()}var c=localStorage.getItem("expeditionLocation");if(mf!=`mod=location&loc=${c}`)Hf(`mod=location&loc=${c}`);else if("true"===
localStorage.getItem("nana_lcn")&&ec){var e="true"===localStorage.getItem("autoCollectBonuses"),g=localStorage.getItem("selectedEnemy")||0;c=document.getElementsByClassName("expedition_button");var k=document.querySelectorAll(".expedition_button.disabled");try{if(document.querySelector(".expedition_cooldown_reduce"))ab("Your expedition settings are incorrect or there is an unexpected page data!"),window.location.reload();else if(ka("expeditionAttacks",0),e){await new Promise(l=>setTimeout(l,800));
for(var h=0;h<c.length;h++){if(4>c[h].closest(".expedition_box").querySelectorAll(".expedition_bonus.active").length||3===h){c[h].click();break}4<=k.length?window.location.reload():setTimeout(b,800)}}else h=c[parseInt(g,10)],h.classList.contains("disabled")?Ya("Your expedition setting is incorrect! You set it to disabled monster which is wrong."):(h.click(),Array.from(c).every(l=>l.classList.contains("disabled"))?(console.log("All buttons are disabled. Reloading..."),window.location.reload()):setTimeout(b,
800))}catch{D("There's a problem with the expedition, refreshing the page."),window.location.reload()}}}();else if(va&&!0===Ga&&!eb.isUnderworld&&aa.player.key==xa&&9<ba.level&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&Fh().vo&&"none"!==document.getElementById("cooldown_bar_dungeon").style.display&&!0===document.getElementById("cooldown_bar_fill_dungeon").classList.contains("cooldown_bar_fill_ready"))await async function(){if("true"===localStorage.getItem("nana_lcn")&&
ec){var b=localStorage.getItem("dungeonLocation")||"1",c="true"===localStorage.getItem("skipBoss"),e="true"===localStorage.getItem("resetIfLose"),g="true"===localStorage.getItem("loose"),k="true"===localStorage.getItem("dungeonFocusQuest"),h="chefe Chefe \u0161\u00e9f chef chef juht boss Boss jefe jefe jefe patron capo vad\u012bt\u0101js vadovas f\u0151n\u00f6k patron Patron \u0428\u0435\u0444 baas sjef szef chefe \u0219ef \u0161\u00e9f \u0161ef pomo chef patron \u0645\u062f\u064a\u0631 \u03b1\u03c6\u03b5\u03bd\u03c4\u03b9\u03ba\u03cc \u0448\u0435\u0444 \u0431\u043e\u0441\u0441 \u8001\u677f".split(" ");
if(mf!=`mod=dungeon&loc=${b}`)Hf(`mod=dungeon&loc=${b}`);else{b=!document.getElementById("content").getElementsByTagName("area")[0];const n=document.getElementById("content").getElementsByClassName("button1");if(2<=n.length){c=n[0].getAttribute("name");e=n[1].getAttribute("name");try{if(b){const m=(new URLSearchParams(window.location.search)).get("loc");"normal"===Ib&&"dif1"===c?(jQuery.post(F({mod:"dungeon",loc:m,sh:W("sh")}),{dif1:Ib}),n[0].click(),window.location.reload()):"dif2"===e?(jQuery.post(F({mod:"dungeon",
loc:m,sh:W("sh")}),{dif2:Ib}),n[1].click(),window.location.reload()):(Ya("Incorrect dungeon/expedition settings"),setTimeout(()=>{Gf()},1E4))}}catch(m){location.reload()}}else if(b)window.location.reload();else try{const m=document.querySelector("#content .map_label"),r=m&&m.textContent.toLowerCase(),w=Array.from(document.querySelectorAll("#content .map_label")).find(v=>h.some(x=>x===v.textContent));ka("dungeonAttacks",0);if(e&&g)localStorage.setItem("loose","false"),document.querySelectorAll("#content .button1")[0].click();
else if(c&&r&&w)document.querySelectorAll("#content .button1")[0].click();else if(r&&w&&"true"===localStorage.getItem("dungeonAB"))w.click();else if(k){var l=0,q=null;document.querySelectorAll('[onclick*="startFight"]').forEach(function(v){var x=v.getAttribute("onclick").match(/startFight\('(\d+)',/);x&&x[1]&&(x=parseInt(x[1],10),x>l&&(l=x,q=v))});q?q.click():window.location.reload()}else document.querySelector("#content area").click()}catch{window.location.reload()}}}}();else if(va&&of("arena")&&
(!0===Ha||eb.isUnderworld&&hf)&&(!eb.isUnderworld||eb.isUnderworld&&hf)&&aa.player.key==xa&&xa===Lc&&aa.player.Fd>=new Date&&(eb.isUnderworld||"true"!==localStorage.getItem("HealEnabled")||ba.o>Number(localStorage.getItem("healPercentage"))||eb.isUnderworld&&ba.o>Number(localStorage.getItem("HellHealHP")))&&!0===document.getElementById("cooldown_bar_fill_arena").classList.contains("cooldown_bar_fill_ready")){async function b(){var k=new URL(window.location.href),h=k.origin;k=k.searchParams.get("sh")||
"";var l=localStorage.getItem("scoreRange"),q=[];h=await (await fetch(`${h}/game/index.php?mod=highscore&sh=${k}&a=${l}`)).text();h=(new DOMParser).parseFromString(h,"text/html");h=Array.from(h.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(n=>(n=n.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===n.style.color||"blue"===n.style.color):null===n);q=[...q,...h];if(0===q.length)return console.log("No players available to attack"),!1;
h=JSON.parse(localStorage.getItem("avoidAttackList"))||[];l=function(n){for(var m=n.length,r,w;0!==m;)w=Math.floor(Math.random()*m),--m,r=n[m],n[m]=n[w],n[w]=r;return n}(q);q=0;for(let n of l)if(l=n.textContent.toLowerCase(),!h.map(m=>m.toLowerCase()).includes(l)){l=await c(n.textContent,k);if(l.includes("index.php?mod=reports")){k=(new URLSearchParams(l)).get("reportId");D(`${d.sa}`+n.textContent);Hf(`mod=reports&submod=showCombatReport&t=2&reportId=${k}`);await new Promise(m=>setTimeout(m,500));
return}q++;if(3<=q)break}return!1}async function c(k,h){try{const l=(new URL(window.location.href)).origin;return await (await fetch(`${l}/game/ajax/doArenaFight.php?dname=${k}&a=${(new Date).getTime()}&sh=${h}`,{method:"POST"})).text()}catch{Gf(1E3)}}async function e(k){var h=k.opponentId;const l=k.serverId;k=k.country;var q=(new URL(window.location.href)).origin;q=new URL(`${q}/game/ajax.php`);h={mod:"arena",submod:"doCombat",aType:2,opponentId:h,serverId:l,country:k.toString(),a:(new Date).getTime(),
sh:W("sh")};q.search=(new URLSearchParams(h)).toString();return await (await fetch(q,{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function g(){function k(v){const x=null!==v.querySelector("span[style*='color:green;']");return Array.from(v.querySelectorAll("a, span")).find(C=>"green"===C.style.color||"bold"===C.style.fontWeight)||x}var h=new URL(window.location.href);const l=h.origin;var q=await (await fetch(`${l}/game/index.php?mod=arena&sh=${W("sh")}`)).text();
q=(new DOMParser).parseFromString(q,"text/html");var n=Array.from(q.querySelectorAll('table[width="80%"] tbody tr')).filter(v=>v.querySelector(".attack"));if(n.length&&1!==n.length){var m=null;q=JSON.parse(localStorage.getItem("avoidAttackList"))||[];if("true"===localStorage.getItem("leaguerandom")){n=n.sort(()=>Math.random()-.5);for(var r of n){var w=r.querySelector("a");w=w?w.innerText:null;if(!k(r)&&!q.includes(w)){m=r;break}}}else if("true"===localStorage.getItem("leaguelowtohigh")){n=n.sort((v,
x)=>parseInt(v.querySelector("th")?v.querySelector("th").textContent:"0",10)-parseInt(x.querySelector("th")?x.querySelector("th").textContent:"0",10));r=null;m=-1;for(w of n)n=(n=w.querySelector("a"))?n.innerText:null,k(w)||q.includes(n)||(n=parseInt(w?.querySelector("th")?.textContent,10),n>m&&(m=n,r=w));m=r}if(null===m)localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","false"),localStorage.setItem("leagueattackenable","false"),Gf(500);else if(m)if(q=m.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],
w=(new Date).getTime(),h=h.searchParams.get("sh")||"",await new Promise(v=>setTimeout(v,250)),h=await (await fetch(`${l}/game/ajax/doArenaFight.php?did=${q}&a=${w}&sh=${h}`)).text(),(q=h.match(/document\.location\.href\s*=\s*'([^']+)'/))&&q[1])window.location=`${l}/game/${q[1]}`;else{h.includes("5")&&("true"===localStorage.getItem("leaguelowtohigh")?(localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","true")):"true"===localStorage.getItem("leaguerandom")&&(localStorage.setItem("leaguerandom",
"false"),localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leagueattackenable","false")),location.reload());if(h.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leagueattackenable","false"),location.reload()}eb.isUnderworld&&hf&&await jQuery.get(F({mod:"underworld",submod:"prayEnd",sh:W("sh")}));await async function(){function k(A){const t=Date.now(),u=v.findIndex(z=>z.playerName===A);-1<u?v[u].timeout=t:v.push({playerName:A,timeout:t});localStorage.setItem("playerTimeouts",
JSON.stringify(v))}function h(A,t){const u=Date.now();if(Array.isArray(v)){const z=v.find(B=>B.playerName===A);return!z||u-z.timeout>t}return!v[A]||u-v[A]>t}function l(A){for(var t=A.length-1;0<t;t--){const u=Math.floor(Math.random()*(t+1));[A[t],A[u]]=[A[u],A[t]]}2<A.length&&(t=A.splice(0,2),A.push(...t));return A}async function q(A,t,u){try{const z=t.match(/\d+/)[0],B=t.match(/\w+/g)[2],J=(new URLSearchParams(t)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:u,aType:A,
opponentId:J,serverId:z,country:B}));const I=await jQuery.get(T({mod:"arena",submod:"confirmDoCombat",aType:A,opponentId:J,serverId:z,country:B,a:(new Date).getTime(),sh:W("sh")})),K=(new URLSearchParams(I)).get("reportId");K||window.location.reload();Hf(`mod=reports&submod=showCombatReport&t=${A}&reportId=${K}`)}catch(z){document.getElementById("content").querySelector("form > input").click(),Gf(1E3)}}"true"===localStorage.getItem("leagueattackenable")&&await g();"true"===localStorage.getItem("scoreboardattackenable")&&
await b();var n=(new URL(window.location.href)).searchParams.get("sh")||"",m=JSON.parse(localStorage.getItem("autoAttackList"))||[];let r=JSON.parse(localStorage.getItem("autoAttackServerList"))||[];const w=JSON.parse(localStorage.getItem("avoidAttackList"))||[];let v=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const x="true"===localStorage.getItem("onlyArena"),C="true"===localStorage.getItem("onlyPlayerListArena");if(of("arena")&&0<m.length||of("arena")&&0<r.length||x||C)try{l(m);localStorage.setItem("autoAttackList",
JSON.stringify(m));l(r);localStorage.setItem("autoAttackServerList",JSON.stringify(r));let A=0,t=3,u=0,z=0;const B=m.length+r.length;x&&(t=15);for(C&&(t=B);A<t&&(u<m.length||z<r.length);){let J,I,K;(K=u<m.length&&z<r.length?.5>Math.random():z<r.length)?(I=r[z],J=I.playerName,z++):(J=m[u],u++);if(!w.includes(J)&&(h(J,6E4*(10+Math.floor(36*Math.random())))||x)){let L;L=K?await e(I):await c(J,n);ka("arenaAttacks",0);L.includes("index.php?mod=reports")&&!L.includes("errorRow")&&(k(J),D(`${d.sa}`+J),window.location.reload())}A++}if(A===
t&&C){D("Tried to attack arena list. Timing out 1min.");Y("arena",1);window.location.reload();return}}catch(A){window.location.reload()}if("mod=arena&submod=serverArena&aType=2"!=mf)Hf("mod=arena&submod=serverArena&aType=2");else try{let A=[...m,...r].map(z=>z.playerName);var E=Array.from(document.querySelectorAll("#own2 tr")).slice(1);const t="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),u="true"===localStorage.getItem("attackRandomly");n=null;m=
Infinity;localStorage.getItem("Username");localStorage.getItem("enableArenaSimulator");localStorage.getItem("ArenaSimulatorAmount");for(let z of E){const B=z.querySelector("a");E=2;u&&(E=Math.floor(5*Math.random())+2);const J=z.querySelector(`td:nth-child(${E})`);if(B&&J){const I=B.innerText,K=parseInt(J.textContent.trim(),10),L=w.includes(I),O=null!==B.querySelector("span[style*='color:green;']"),Z="green"===B.style.color;if(!(L||!t&&O&&Z)){if(A.includes(I)){D(`${d.sa}`+I);n=B;break}!n&&K<m&&(m=
K,n=B)}}}if(n)await q(2,n.href,n.outerText),ka("arenaAttacks",0);else{const z=document.querySelector('form[name="filterForm"] input[type="submit"]');z&&z.click()}}catch{window.location.reload()}}()}else if(va&&!0===Ia&&of("eventPoints")&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&0<jQuery("#submenu2 a").filter(".glow").length)await async function(){var b=jQuery("#submenu2 a").filter(".glow")?jQuery("#submenu2 a").filter(".glow")[0].href.match(/mod=.*&sh/)[0].slice(0,
-3):null;if(mf!=b)Hf(b);else{b=document.querySelector("#content .ticker");let c=parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10),e=kc;localStorage.setItem("eventPoints_",c);if(b){b=document.querySelector('[data-ticker-type="countdown"]').textContent.trim().split(" ").pop();let [g,k,h]=b.split(":").map(Number);(b=(new Date).getTime()+1E3*(3600*g+60*k+h)+1)?localStorage.setItem("eventPoints.timeOut",b):Y("eventPoints",5);setTimeout(Hf,1E3,"mod=overview")}else!b&&
0<c?(3==e&&1==c&&(e=2),setTimeout(Eh,1E3,document.querySelectorAll(".expedition_button")[e])):!c&&"true"===localStorage.getItem("renewEvent")&&0<Fh().Ln?((new URL(window.location.href)).searchParams.get("loc"),setTimeout(Eh,1E3,document.querySelectorAll(".expedition_button")[e])):0==c&&"false"===localStorage.getItem("renewEvent")?(Y("eventPoints",5),location.reload()):0==c&&setTimeout(Hf,5E3,"mod=overview")}}();else if((Bc||Cc||Dc)&&!vh&&Bc&&va&&wh&&(yh&&Ec&&Db&&Eb&&of("AuctionEmpty")||Cc&&Db&&Eb&&
of("AuctionEmpty")||Dc&&Db&&Eb&&of("AuctionMEmpty")||zh&&Ec&&Ah&&Bh&&of("AuctionMEmpty")))await za.start();else if(va&&"true"===localStorage.getItem("resetExpiredItems")&&(0<Dh.length||Ij)&&5E3<=ba.gold&&of("resetExpired"))await oj(localStorage.getItem("resetDays"),Dh);else if(va){if("true"==localStorage.getItem("useCostume")&&of("CheckDolls"))await Bj.start();else if("true"===localStorage.getItem("HealEnabled")&&"true"==localStorage.getItem("BuffsEnable")&&of("BuffCheck"))await rj();else if(!Ch||
Wb-Ch>=6E4*Kj)localStorage.setItem("MarketlastRan",Wb.toString()),"true"==localStorage.getItem("enableMarketSearch")&&aa.player.key==xa&&"true"==sessionStorage.getItem("autoGoActive")&&await gf.lo();11001<Ac&&(D(`Waiting for ${Xb} seconds...`),await new Promise(b=>setTimeout(b,Ac)));af()}let z3=localStorage.getItem("we");we=new Date(z3);aa.player.Fd<new Date&&we<new Date&&aa.player.key!=xa&&gb()}}})();const Ih={cg:"There is a problem with the market search. Please re-add items to fix.",Lb:"Not enough space in selected inventory to smelt.",ck:"Smelt Higher Colors First?",cc:"Only Attack to player list?",dc:"This option will only attack arena/circus list. If cant, bot will skip for a minute.",Kk:"Your expedition settings are incorrect or there is an unexpected page data!",Lk:"Your expedition setting is incorrect! You set it to disabled monster which is wrong.",Yk:"Reset only all underworld items with selected color?",
Ca:"Priority",Vb:"Set Priority",Rg:"Points",Kh:"Stat",Si:"Collect Gold",Oj:"Sell Underworld Items?",uj:"Bot will look for nest in every action, not just expeditions.",sj:"Nest Search Type",qj:"Nothing",rj:"Quick",tj:"Thorough",Kl:"After expedition points are consumed, travel to Germania to consume Dungeon points",xk:"Use this if the bot gets stuck in the repair!",Mk:"When HP is below, use heal",Ng:"Partial Repair",af:"Full Repair",Mg:"Partial or Full Repair",se:"Enable Limit",kj:"Limit",lj:"If you want to limit the number of times you want to attack to the enemy, enable this option and set the limit. Bot will continue to attack rest of the enemies after it finishes attacking to the selected monster.",
ne:"Do not enter underworld with underworld costume?",me:"If you dont want to enter underworld while you have underworld costume on, enable this option",yi:"Underworld",pi:"Underworld Buffs",si:"Use god powers after entering the underworld?",ti:"Select gods to use powers from:",ui:"Use Weapon Buff on the weapon?",vi:"Use Armor Buff on the following equipment:",Hk:"Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.",Zk:"Select Colors",$a:"Vulcanus Forge",eb:"Feronia`s Earthen Shield",
fb:"Neptune`s Fluid Might",gb:"Aelous` Aerial Freedom",hb:"Pluto`s Deadly Mist",ib:"Juno`s Breath of Life",jb:"Wrath Mountain`s Scale Armour",kb:"Eagle Eyes",lb:"Saturn`s Winter Garment",ab:"Bubona` Bull Armour",bb:"Mercerius` Robber`s Garments",cb:"Ra` Light Robe",lg:"Packages",gg:"Inventory",M:"Min Price",L:"How Many",Fb:"Sell Items",Eb:"Search in",hg:"Material Color",Db:"Item Color",og:"Warehouse",Aa:"Switch to Materials",Hb:"Switch to Items",ng:"Sell Materials",xa:"Please enter a valid item name and price range and how many.",
ya:"No suitable items found in the selected search locations.",za:"All items listed successfully!",Sk:"All materials listed successfully!",jg:"If you want to sell items for fixed price, you can enter the same value for both min and max price.",kg:"This feature is still experimental, use with caution. If you dont put fixed price, it will list items randomly between min and max price you enter.",Kj:"Repair Before Smelt",Vj:"Select the item types you want to smelt.",Wj:"Select the colors you want to smelt.",
Xj:"Select the level of the items you want to smelt.",Yj:"Select the hammer you want to use",Zj:"Note that Green and Red circle next to the first box are for enabling/disabling the rule.",$j:"If you want to use smelt randomly any colors or types, you can enable `Smelt randomly if no conditions met? (Last enabled option in the tutorial video)",Dk:"Sets the max gold that the bot will spend per cycle.",Va:"Bot will start bidding on any food items, if enabled. You do not require to enable gladiator/mercenary toggles",
Md:"Bot will not bid on allies` bids.",Nd:"Ignore Prefix/Suffix Combination when looking for an item in the auction.",Oe:"Select Monster",Ce:"Use Hourglass/Ruby?",Jk:"Use Ruby?",Fe:"Use Mobilization?",Ee:"Use Life Potion?",Be:"Heal Percentage (%)",Me:"Number of Attacks",De:"Attack Interval (in seconds)",ze:"Attacks Performed",Ae:"Hourglass Left",Ke:"Note: It uses lifepotions to heal, not food.",Le:"Note: If attacks stop prematurely, try 'Reset Attacks'.",Pe:"Start",Ne:"Reset",Qe:"Stop",Re:"Expedition Settings (Click to minimize)",
Ge:"Monster 1",He:"Monster 2",Ie:"Monster 3",Je:"Monster 4",Vk:"Repair Before Smelt",Qi:"This option will use cervisia when your premium expires.",xj:"This option will enables and picks oils from god rewards. It can use number 1 and number 3 oils on the character but number 2 will only be picked to packages.",Oi:"This option will use buffs at the time you set. It will find buffs in packages and apply it to the character.",mj:"This option will enter you to the underworld when your expedition points are below 3. Dont forget to enable Auto Login from Extras tab, otherwise you might get logged out upon entering underworld[Game Bug]",
ec:"This option will only attack arena/circus list.If cant, bot will skip.",Hj:"This option is only for premium licenses. It simulates the attack before attacking a user for %75 win rate.",Pd:"You do not need to enable main auction toggle to enable this option.",qk:"This option will refresh the page every second when auction is in -Very Short- state to bid constantly to win the auction.",Tj:"If none of the smelt conditions are met, it will smelt randomly. Make sure to select item type and color.",
Uj:"This option will only smelt items from inventory. It will ignore items in packages.",Wa:"Auction Items",rg:"Mercenary Items",Xb:"Shop Items",Ai:"Unique Items",Pj:"Set background to black [Increases performance]",Qj:"Move GLDbot buttons to bottom left?",Ri:"Attack Circus Without Heal",pk:"Pick gold from packages if needed?",am:"Gold has been picked from packages for training",Gd:"No gold has been found in packages for training",Cl:'GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.',
lk:"Items Repaired",ek:"Arena Attacks",gk:"Circus Attacks",Ed:"Items Reset",jk:"Expedition Attacks",ik:"Dungeon Attacks",mk:"Underworld Attacks",fk:"Money Earned from Arena",hk:"Money Earned from Circus",Zl:"Items Smelted",kk:"Gold Cycled",dj:"Guild Battle",fj:"Guild Settings",rl:"Will attack guilds randomly.",cj:"Attack Random Guilds?",ej:"Guild Name",Pi:"Reset Stats",Pc:"Wood",Fc:"Copper",Jc:"Iron",Lc:"Leather",Qc:"Wool",Gc:"Cotton Wool",Ic:"Hemp",Hc:"Gauze Strip",Mc:"Linen Strip",Kc:"Jute Patch",
Oc:"Velvet",Nc:"Silk Thread",Yc:"Fur",Sc:"Bone Splinter",ad:"Scale",Vc:"Claw",Xc:"Fang",Wc:"Dragon Scale",Tc:"Bull`s Horn",$c:"Poison Gland",Uc:"Cerberus` Pelt",Zc:"Hydra Scale",bd:"Sphinx Feather",cd:"Typhon Leather",Cc:"Lapis Lazuli",wc:"Amethyst",vc:"Amber",xc:"Aquamarine",Dc:"Sapphire",Ac:"Garnet",zc:"Emerald",yc:"Diamond",Bc:"Jasper",Ec:"Sugilite",qc:"Scorpion Poison",tc:"Tincture of Stamina",mc:"Antidote",lc:"Adrenaline",sc:"Tincture of Enlightenment",pc:"Potion of Perception",nc:"Essence of Reaction",
oc:"Phial of Charisma",uc:"Waters of Oblivion",rc:"Soul Essence",Bd:"Water Seal",vd:"Protection Rune",td:"Earth Mark",Ad:"Totem of Healing",zd:"Talisman of Power",xd:"Stone of Fortune",ud:"Flintstone",yd:"Storm Rune",wd:"Shadow Rune",gd:"Crystal",fd:"Bronze",ld:"Obsidian",od:"Silver",pd:"Sulphur",jd:"Gold Ore",nd:"Quartz",md:"Platinum",ed:"Almandin",hd:"Cuprit",kd:"Hellstone",Li:"Attack Randomly in Provinciarum?",Mi:'Also disable "Sort players in arena by level" setting in crazy-addon.',$g:"Only accept quests based on god type.",
Xa:"Auto Buff",ce:"Use it in hell only?",Gg:"New Rule",Eg:"Name Contains",isUnderworldItem:"Is Underworld Item",kf:"Ignore Materials",wk:"Use Pray?",xi:"When in underworld only accept underworld related quests?",wi:"If enabled, you need to enter underworld item names. If the bot finds these items in the underworld, it will accept the quest.",cl:"Underworld Quest Item",ol:"Enter Material Name",Gk:"The bot loves dice! They help find clothes in chests. But if there are no dice, the bot opens chests anyway, hoping for some cool clothes (but it might not find any!).",
Sj:"Send smelted materials to package?",re:"Enable Arena",Sg:"Prioritize arena list?",Tg:"Prioritize circus list?",je:"Disable Log Menu",oh:"Reward Min. Gold Value",ah:"Focus Quest, if enabled, will follow the shortest path to finish the dungeon.",Nh:"Throw Dice Automatically?",Oh:"Use throw dice cautiously, it will keep using the first dice until you disable the option.",uh:"Search Progress",ih:"Cooldown for repair by default is 10 minutes.",Bg:"Minimum Condition",he:"Current item on workbench [Clear if bot pauses unexpectedly]",
Gf:"Forge Resources stored to horreum successfully.",Cf:"Checking marketplace for items...",Ab:"Item moved to workbench.",Tf:"Item successfully repaired and equipped.",Uf:"Item successfully repaired.",Qk:"Repair failed. Page will be refreshed.",Qf:"Picking up materials...",bg:"Waiting for repair...",Sf:"Repair has started for .",wa:"Repair: Moving the item from inventory to bag",Rf:"Repair: Moving the item from workbench to package.",ua:"Could not find enough materials. Disabling the repair slot for 5 minutes ",
Nf:"Looking for items to buy to hide gold in Auction...",zf:"Checking for expired items in packages...",Af:"Item successfully reset.",Bf:"No Empty Space or Gold to Reset.",Hf:"Make sure you have sell rights in guild market!",ub:"Not enough gold/or no item to buy. Waiting for 30sec to refresh.",wb:"Store has been refreshed.",xb:"Error while healing.",Kf:"No Ruby or Cloth, disabling the options.",Pk:"No healing item found in packages.",yb:"No suitable items found",Lf:"Foods have been picked. Ending the process.",
Mf:"At least one food has been picked. Ending process.",zb:"No suitable space found in bag to pick food.",If:"Getting food from packages.",Jf:"No suitable space found in bag to pick food.",vb:"No more heal items. Waiting for 30 seconds.",tb:"HP Recovered.",va:"Nothing to do so I am going to pray!",Yf:"Im going to refresh in 60 seconds to check for my health and villa medici.",Zf:"Waiting for Villa Medici, refreshing in 60 seconds.",$f:"Left underworld.",ag:"Im going to refresh in 60 seconds to check for my health.",
Of:"Checking for god oils...",Pf:"God oils have been picked.",sa:"Successfully attacked player in ARENA: ",ta:"Successfully attacked player in CIRCUS: ",xf:"Checking auction! Please wait...",yf:"Bidding to items. Please wait...",Vf:"Auto Smelted Item: ",Wf:"Smelting Item: ",Bb:"Not enough gold to smelt. Required Gold: ",Xf:"SMELT: Looking for items to smelt...",Rk:"Looking for items to smelt...",Df:"Checking costume availability...",Ff:"Donated : ",Ef:"Throwing dice...",Xe:"Underworld Farm [Manual, Beta]",
Ye:"Be aware: Turn on this feature after unlocking the creature you want to attack, it will not automatically attack to unlock the monster.",We:"Farm Location",Ve:"Farm Enemy",Wd:"Auto Login",Xd:"You need to allow pop-ups from the lobby screen for GameForge. See documentation on how to do it.",Og:"Pause Bot",Pg:"Pause Bot in (Minutes)",Te:"Expiration Date",Jg:"Only buy food?",Kg:"If you enable this, it will ignore your selections and buy food automatically without entering anything.",Jb:"Max total gold to spend",
Ib:"Max gold per food to spend",Ig:"Bot will check oils every 60 minutes",fi:"Sets a timer to check smelting times.",ci:"Sets a timer to check smelting after you dont have gold.",ei:"Sets a timer to check smelting if you dont have available item.",Yh:"Sets a timer for repair to check your items.",Xh:"Sets a timer to check guild market hold gold.",Th:"Sets a timer for auction hold gold option.",Ph:"Sets a timer to check the arena pvp list to attack.",Uh:"Sets a timer to check the circus pvp list to attack.",
li:"Sets a timer for training to train your stats.",$h:"Sets a timer to reset expired items.",ji:"Sets a timer to store forge materials to horreum.",Rh:"Sets a timer to check gladiatos & mercenary auction.",bi:"Sets a timer to search for items in auction&shop.",Vh:"Sets the timer of sending donation to the guild.",bf:"Gold Moved",oe:"Don't sell smelt & auction list items",vh:"Shop Automation",xh:"Item Search Settings",wh:"Use this tool to search for items in shops. Simply add the items to the list, specify the cloth amount, and start the search.",
yh:"Cloths to use:",zh:"How many cloths to use?",fa:"Enter Full Item Name",Wb:"Enter Item Level",Bh:"Item Quality",Ah:"Item Name Here",Ch:"Start Searching",Dh:"Skip and Continue",Eh:"Stop Searching",Ze:"Buy cheapest or expensive?",Dg:"Most Expensive",ee:"Cheapest",Da:"Select an option",te:"Highlight Underworld Items",$e:"Focus on the quest?",cm:"Use ruby if there isnt cloth?",Ya:"Add cross-server players: Find profile, use A & C buttons. Play nice: Avoid targeting same players to dodge reports/bans.",
Rl:"Smelt Green?",Vg:"Do not accept random quests if entered any filters?",Rc:"Max Material Quality to use",$i:"Enable Mercenary Search",yl:"Click \u2018Sell All Selected\u2019 to sell all items. Make sure to have 2x3 empty space in your first (1) bag and select quality. To mass collect Gold, use `USE GOLD` panel below or filter gold and use the `Pick Selected or Pick All`",dk:"\ud83d\udd25 : Adds item to smelting list.",Ni:"\ud83d\udd28 : Adds item to auction list.",Jj:"Refresh shop automatically with cloth when its full.",
Gl:"Page:",Fj:"Stop",Dj:"Sell This Page",Aj:"Pick Selected",zj:"Pick All",Gj:"Auto Package Settings",Ej:"Send Resources",Bj:"Sell All Selected",na:"Item Type",pa:"Weapons",U:"Shields",O:"Armour",S:"Helmets",R:"Gloves",P:"Boots",oa:"Rings",la:"Amulets",Ka:"Usables (Foods)",Pa:"Upgrades",yj:"Boosts",Ma:"Recipes",La:"Mercenary",Oa:"Forging Tools",Na:"Scrolls",sd:"Reinforcements",qd:"Event Items",rd:"Forging Goods",Fl:"Gold",Ja:"All",Hl:"Quality",qa:"White",C:"Green",B:"Blue",D:"Purple",J:"Orange",T:"Red",
Cj:"Sell All Options",Rj:"Ignore Prefix/Suffix Combination?",gj:"How many food to buy/pick?",Vi:"Normal",Ui:"Middle",Ti:"Hard",Ga:"Standard",Ll:"Repair Stuck Fix",Nk:"Underworld mode will automatically disable Dungeon/Arena/Circus, and enable all of them after underworld. Disable Enter Underworld if you want to disable Dungeon/Circus/Arena. If you entered underworld manually, you need to enable underworld Mode.",oi:"Set how many times you want to train the stats and their priorities. The bot wont train unless you set a priority. If there is no more stat left but priority is set, it will continue with checked stat.",
ll:"Quest",Dd:"Smelt",Wl:"Smelt Settings",ak:"Smelted Items",Xl:"Add Prefix or Suffix, once it finds it in the packages it will smelt automatically. If you only want to look for all the items listed without checking their combination, enable Ignore combination option.",Vl:"Smelting Item:",ic:"Click on the item you want to repair and choose the highest quality materials to use. You need to have at least 10,000 gold for the repair to start. Ensure you have a 3x3 space available in your first inventory bag and make sure a food item or any small item is not in the first inventory space otherwise, it might get stuck!. The bot will start the repair once the item has the condition you have chosen. Repair now should be able to continue from where it was left off. Items that have a Hint tooltip might cause a problem.",
dl:"Apply only to Mercenary",hl:"Auction will only bid when market is close to the end.",gl:"Smelting will prioritize starting from the first item to search. You can drag and drop to change priority. Smelt will start when you have over 7k gold. ",jj:"Heal & Buffs",Ml:"Not enough gold to smelt. Required Gold:",Pl:"Skipping bid: Guild member has already bid for item ",Ol:"Skipping bid: Already bid for item ",advanced:"Advanced",arena:"Arena",ja:"Auto Attack",fc:"Avoid Attack",ha:"Add Player",ia:"Add Player Name (Same Server)",
tl:"Stop Bot if run out of food?",circusTurma:"Circus Turma",Wi:"Difficulty",dungeon:"Dungeon",Xi:"Dungeon Settings",eventExpedition:"Event Expedition",expedition:"Expedition",aj:"Expedition Settings",Lj:"Select Monster",vl:"Highest",ul:"Put your heal stuff in first page of your inventory",nj:"In",Lh:"Store Gold in Guild Market",Mh:"Store Gold in Auction",rh:"Use Clothes to renew Shop?",Xk:"Select Items to Reset",kh:"Reset Expired Items",Qb:"Note: By enabling this option, the bot will sell upcoming expired items from Packages to Guild Market then cancels to reset expiration time. Guild is required. Make sure you have empty 3x3 space in your bags. It checks last 7 pages per cycle. This might slow down the bot while it is checking for the pages to reset. If it doesnt work, set display expiry date as Date in game settings.",
Qg:"Pause bot randomly to work as [Testing Phase]:",aa:"Hold Gold: Bot will keep this gold in the bag:",pg:"Max Gold: Bot will spend when the gold is greater than",ph:"Bot will bid on random items.",Hd:"Add Random Delay",Id:"You can add a delay to bot here.",Pb:"Repair",Ql:"Smelt Blue?",Tl:"Smelt Purple?",Sl:"Smelt Orange?",bk:"Smelt Everything Only From Inventory?",Ul:"`Smelt Tab` works only for `Smelt Everything Only From Inventory` option. Rest of the options will use selected smelt tab. This will ignore color and ignore list items. Tab 1 is reserved for repair.",
Gh:"Smelt",Qd:"Auto Search",Fg:"Auto Auction",Rd:"Excess use of Auction might result in ban. If you enabled auction on Crazy-Addon please disable before using this. Note that, if you put only one item to PREFIX section, bot will try to filter by the items name for faster bidding. Although you need to disable bidding food for this.",qh:"Search in Gladiators Auction",th:"Search in Mercenary Auction",Zd:"Bid Food?",qg:"Maximum Bid",$d:"Bid if the status is less than",ae:"Bidded Items",Bk:"Auction Language",
Ck:"Please set the language according to your ingame language, otherwise auction wont work.",Ld:"You can add items to look for items in market and auction. It will also show purple items in the market once you add an item into the list.",zk:"Use auction with caution!",Ak:"Auto bid makes too many requests to the server causing white page error and can cause a ban if you use it often!!",hh:"Renew Event Points with Ruby?",ve:"Enable Auto Oil",Ek:"Auto Get Holy Oils",Tk:"Quest Check Speed",Ua:"Attack Guild Members?",
Sa:'Auto add people to the "Attack" list when X GOLD is stolen:',Ta:'Automatically add people to the "Avoid Attack" list when you lose to them:',Tb:"Scoreboard Attacks",ac:"Very Long",Cb:"Long",Kb:"Middle",Yb:"Short",bc:"Very Short",we:"Enter Underworld if HP >",bh:"Quest Check Speed",Ug:'Default is "3x". If bot causes problems with quests, change quest speed according to your server speed.',cf:"Heal Pick Bag",xe:'If you are renewing points manually, you need to click the button above "Refresh Event Expedition if stuck!',
Ik:"You must enable at least one of the following: expedition, dungeon, arena, or circus to start the Event Expedition.",eh:"Refresh Event Expedition if stuck!",mb:"Dont bid on Allies` Bids?",$k:"Leave all settings disabled if you wish to smelt using packages that contain the items in the list. However, you still need to choose colors.",Fk:"Character(Off) / Mercenary(On)",Wk:"Repair Both?",al:"Timers",Timers:"Enter the number of minutes for each timer below or leave it default. Be aware! If you enter very low numbers, bot might get stuck in loop!",
Zg:"Quest Filter Ignore",Yg:"Enter keywords to filter out quests you do not want to take",X:"Enter Keyword",K:"Add",gh:"Remove",ge:"Clear",Wg:"Quest Filter Accept",Xg:"Enter keywords to choose which quests to take. You can also use this to accept quests by their reward using keyword. Using this will ignore Quest Types",Ea:"Skip Time Quests?",Uk:"Quests",Td:"Auto Costume",Di:"Use Costume?",Yd:"Basic Battle",pe:"Dungeon Battle & Event",fe:"Choose underworld costume",Ji:"Wear Underworld costume when available?",
Ud:'To ensure the bot doesnt override your Underworld costume, make sure to select "Wear Underworld costume when available?" and "Choose Underworld costume." The bot will only switch to Dis Pater Normal and Medium costumes if your expedition or dungeon points are at 0.',ef:"Underworld Heal Settings",Kd:"Attack Boss When Available?",sb:"League attack will disable itself after 5 unsuccessful attack.",hf:"Holy Oils",Ag:"Item Name",ba:"Min. Item Level",Ba:"Min. Item Quality",Jd:"Apply/Reset Timer",lf:"Ignore Prefix/Suffix Combination",
Ki:"Yes",Hg:"No",Qa:"Add Prefix",Ra:"Add Suffix",Za:"Clear History",Hh:"Ignore List",Mb:"Prefix",Zb:"Suffix",mh:"Reset Expiring Items",Ih:"Smelt randomly if no conditions met?",Jh:"Smelt Tab",qb:"Extras",Od:"Auction",ig:"Market",$b:"Timers",hi:"Smelting",gi:"Smelting if not enough gold",di:"Smelt if no item",Fa:"Repair",Wh:"Guild Market Hold Gold",Sh:"Auction Hold Gold",ki:"Training",Zh:"Reset Expired",ii:"Store Forge",Qh:"Auction Check",ai:"Search",v:"Enable",Cg:"Minimum Gold",Ub:"Select Hour",nb:"Donate Gold to Guild",
ke:"Donates every 5 minutes. You can change the interval from timers tab",jf:"How much to donate?",le:"Donate when you have more than >",wf:"Less than <",jh:"Reset Expired and Other settings",lh:"Reset in:",Ok:"Hold Ctrl (Cmd on Mac) to select multiple items",mf:"Import/Export Settings",Ue:"Export Settings",nf:"Import Settings",tg:"Message All Players",ug:"[Requires Ultra Premium Key, message on Discord to get the key.]",vg:"Enter message to send",ie:"For custom scripts contact us on Discord",xg:"Send",
yg:"Show Players",wg:"SelectAll",zg:"UnselectAll",vf:"Make sure your inventory has enough space. Cooldown is 2 minutes.",pb:"Enable Scoreboard Attack:",Rb:"Select Range to Attack",Sb:"Bot will randomly attack from the scoreboard list.",rb:"League Attack",ob:"Enable League Attack:",Nb:"Randomly Attack",Ob:"Attack lowest to highest",yk:"Bot will avoid attacking guild members by default.",Se:"Expedition Location:",Sd:"Auto Collect Bonuses:",Fh:"Skip Boss",qe:"Dungeon Location:",nh:"Reset if lose?",ff:"Underworld Settings",
gf:"Underworld: Runs from start to finish! Set your heal % in the Heal tab (activate it first). Underworld Mode uses Underworld Heal %, so expect more food consumption. Enable Auto-login in Extras if logout occurs.",df:"Underworld Difficulty:",Vd:"Auto Enter Underworld / Underworld Mode:",Ei:"Use Mobilization if points = 0",Ii:"Use rubies?",Gi:"Use Sacrifice to heal?",sk:"Use Cloth to enter underworld?",ye:"Exit underworld if no points?",ri:"The bot will try to use Villa Medici first and disable itself if there is no available Villa Medici; if thats the case, it will use a healing potion. Dont forget to enable Heal toggle.",
zi:"Auto enter Underworld will disable dungeon/arena/circus upon entering underworld.",bl:"Underworld Heal Settings",Hi:"Use Villa Medici?",Fi:"Use Healing Potion?",dg:"INFO: The bot will search for market items every selected minutes, which may pause attacking during the search.",ue:"Enable Market Search:",eg:"Market Search Interval in Minutes:",fg:"Suggested 10 minutes.",rf:"Item Settings:",pf:"Item Name Includes",G:"Max Price",sf:"Item Type",qf:"Item Rarity",de:"Buy Soulbound?",uf:"Items to Buy",
tf:"Buy packs if any of them match the maximum price entered?",be:"Bought Items:",hj:"Heal Percentage",uk:"Buy Food from Shop?",vk:"Use Heal from Package?",rk:"Use Cervisia? (packages included)",tk:"Use Eggs? (packages included)",zl:"Last Used",location:"Location",Strength:"Strength",Dexterity:"Dexterity",Agility:"Agility",Constitution:"Constitution",Charisma:"Charisma",Intelligence:"Intelligence",mi:"Train Settings",ni:"Select the attributes you want to train. It will train once you have enough gold.",
N:"Next action",vj:"No",wj:"Normal",Dl:"Opponent",El:"Opponent Level",Ij:"Quests",random:"Random",Nl:"Settings",Yl:"Soon...",type:"Click on icons to activate quest types. Select first 3 if you want to focus on Circus & Arena",em:"Yes",A:"Search",Cd:"Add item",nk:"Store Forge Resources automatically",$l:"Submit",xl:"Interval : ",ml:"Enable Auto Bid",nl:"Cover Allies` Bids",bm:"Tutorial",hc:"More users will slow down the bot.",el:"Begin by adding an items full name to the list. Once added, the tool will display search results on the left. This also aids in auto-auction searches. With auto-bid enabled, the tool will periodically search based on your set interval. If the item is found and you have sufficient funds, it will bid automatically. Note: To search for unique items in shops, you must add at least one item to the search list..",
pl:"The creature number can be selected from the buttons above. Number 1 represents the leftmost creature. Make sure you select the correct location otherwise bot might pause.",Yi:"Choose the difficulty of the dungeon from the options above. Ensure you select the correct location, as otherwise, the bot might pause.",ij:"Heal Settings",Zi:"Store excess gold in Guild by buying guild market items. -> Min. Gold. Leave some empty space in first inventory.",Al:"Move All",Bl:"Move Selected",il:"Auto Heal",
jl:"Auto Heal Percentage",dm:"Ruby",Lg:"General Settings",Mj:"Sell All",Nj:"Sell Selected",ga:"Weapons",da:"Shields",W:"Chest Armour",Z:"Helmets",Y:"Gloves",ea:"Shoes",ca:"Rings",V:"Amulets",Ci:"Usable",Bi:"Upgrades",dh:"Recipes",sg:"Mercenary Scroll",fh:"Reinforcements",mg:"Sell Food",Gb:"Switch to Food"},Lh={cg:"Market hatas\u0131! L\u00fctfen itemlari tekrar ekleyip tekrar deneyin.",Lb:"Eritmek icin yeterli alan yok!",ck:"Once daha y\u00fcksek renkleri erit?",cc:"Sadece oyuncu listesine sald\u0131r?",
dc:"Bu se\u00e7enek etkinle\u015ftirildi\u011finde, bot sadece oyuncu listesindeki oyunculara sald\u0131racak. Bu se\u00e7enek etkinle\u015ftirilmezse, bot rastgele oyunculara saldiracak.",Kk:"Sefer ayarlar\u0131n\u0131z yanl\u0131\u015f veya beklenmedik bir sayfa verisi var!",Lk:"Sefer ayar\u0131n\u0131z yanl\u0131\u015f! Devre d\u0131\u015f\u0131 b\u0131rak\u0131lm\u0131\u015f bir canavara ayarlad\u0131n\u0131z, bu yanl\u0131\u015f.",Yk:"Sadece se\u00e7ilen renge sahip t\u00fcm yeralt\u0131 \u00f6\u011felerini s\u0131f\u0131rla?",
Ca:"\u00d6ncelik",Vb:"\u00d6ncelik Ayarla",Rg:"Puanlar",Kh:"Stat Ad\u0131",Si:"Alt\u0131n Topla",Oj:"Yeralt\u0131 itemleri satilsin mi?",uj:"Bot her eylemde yuva arayacak, sadece ke\u015fiflerde de\u011fil.",sj:"Yuva arama t\u00fcr\u00fc",qj:"Bir Sey Yapma",rj:"Hizli Ara",tj:"Kapsamli Ara",Kl:"Expedition Sonras\u0131 Eylem",xk:"Tamir takilirsa TIKLA",Mk:"Kaca dustugunde iyilestirsin?",Ng:"K\u0131smi Onar\u0131m",af:"Tam Onar\u0131m",Mg:"K\u0131smi veya Tam Onar\u0131m",se:"Limiti Etkinle\u015ftir",
kj:"Limit",lj:"D\u00fc\u015fmana sald\u0131rmak istedi\u011finiz kez say\u0131s\u0131n\u0131 s\u0131n\u0131rlamak istiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin ve limiti ayarlay\u0131n. Bot, se\u00e7ilen canavara sald\u0131rmay\u0131 bitirdikten sonra di\u011fer d\u00fc\u015fmanlara sald\u0131rmaya devam edecek.",ne:"Yeralt\u0131 kost\u00fcm\u00fc ile yeralt\u0131na girmeyin",me:"Yeralt\u0131 kost\u00fcm\u00fc varken yeralt\u0131na girmek istemiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin",
yi:"Yeralt\u0131 D\u00fcnyas\u0131",pi:"Yeralt\u0131 D\u00fcnyas\u0131 G\u00fc\u00e7lendirmeleri",si:"Yeralt\u0131 d\u00fcnyas\u0131na girdikten sonra tanr\u0131 g\u00fc\u00e7lerini kullan?",ti:"G\u00fc\u00e7lerini kullanmak istedi\u011fin tanr\u0131lar\u0131 se\u00e7:",ui:"Silaha Silah G\u00fc\u00e7lendirmesi kullan?",vi:"A\u015fa\u011f\u0131daki ekipmana Z\u0131rh G\u00fc\u00e7lendirmesi kullan:",Hk:"Bekleme s\u00fcresi 30 dakikad\u0131r. \u00dczerinde kost\u00fcm yoksa, bot bekleme s\u00fcresini s\u0131f\u0131rlar.",
Zk:"Renkleri Se\u00e7",$a:"Vulcano`nun Demirci Atesi",eb:"Feronia`nin Toprak Kalkani",fb:"Neptune`un sivi gucu",gb:"Aelous`un havali ozgurlugu",hb:"Pluto`nun olumcul nefesi",ib:"Juno`nun Hayat Solugu",jb:"Ofkeli Dag Ejderhasi Pul Zirhi",kb:"Kartal Bakisi",lb:"Saturn`un kisi giysisi",ab:"Bubona`nin okuz zirhi",bb:"Mercerius`un Hirsiz Kaftani",cb:"Ra`nin isikli esvabi",lg:"Paketler",gg:"Envanter",M:"Min. Fiyat",L:"Ka\u00e7 Tane",Fb:"E\u015fya Sat",Eb:"\u015eurada Ara",hg:"Malzeme Rengi",Db:"E\u015fya Rengi",
og:"Depo",Aa:"Malzemelere Ge\u00e7",Hb:"E\u015fyalara Ge\u00e7",ng:"Malzeme Sat",xa:"L\u00fctfen ge\u00e7erli bir e\u015fya ad\u0131, fiyat aral\u0131\u011f\u0131 ve miktar girin.",ya:"Se\u00e7ilen arama konumlar\u0131nda uygun e\u015fya bulunamad\u0131.",za:"T\u00fcm e\u015fyalar ba\u015far\u0131yla listelendi!",Sk:"T\u00fcm malzemeler ba\u015far\u0131yla listelendi!",jg:"Sabit fiyata e\u015fya satmak istiyorsan\u0131z, min ve maks fiyat i\u00e7in ayn\u0131 de\u011feri girebilirsiniz.",kg:"Bu \u00f6zellik hala deneyseldir, dikkatli kullan\u0131n. Sabit fiyat koymazsan\u0131z, girdi\u011finiz minimum ve maksimum fiyat aras\u0131nda rastgele \u00f6\u011feler listeleyecektir.",
Vj:"Eritmek istedi\u011finiz e\u015fya t\u00fcrlerini se\u00e7in.",Wj:"Eritmek istedi\u011finiz renkleri se\u00e7in.",Xj:"Eritmek istedi\u011finiz e\u015fyalar\u0131n seviyesini se\u00e7in.",Yj:"Kullanmak istedi\u011finiz \u00e7ekici se\u00e7in.",Zj:"\u0130lk kutunun yan\u0131ndaki Ye\u015fil ve K\u0131rm\u0131z\u0131 \u00e7emberin kural\u0131 etkinle\u015ftirme/devre d\u0131\u015f\u0131 b\u0131rakma i\u00e7in oldu\u011funa dikkat edin.",$j:"E\u011fer rastgele herhangi bir renk veya t\u00fcr\u00fc ergitmek istiyorsan\u0131z, Ko\u015fullar sa\u011flanmazsa rastgele eritilsin mi? (E\u011fitim videosundaki son etkinle\u015ftirilen se\u00e7enek) se\u00e7ene\u011fini etkinle\u015ftirebilirsiniz.",
Dk:"Bot`un her d\u00f6ng\u00fcde harcayaca\u011f\u0131 maksimum alt\u0131n\u0131 belirler.",Va:"Etkinle\u015ftirilirse, bot herhangi bir yiyecek \u00f6\u011fesi i\u00e7in teklif vermeye ba\u015flar. Gladyat\u00f6r/asker ayar\u0131n\u0131 etkinle\u015ftirmeniz gerekmez.",Md:"Bot, m\u00fcttefiklerin tekliflerine teklif vermez.",Nd:"A\u00e7\u0131k art\u0131rmada bir \u00f6\u011fe ararken \u00d6nek/Son ek kombinasyonunu g\u00f6rmezden gelir.",Kj:"Eritmeden \u00f6nce tamir et?",Oe:"Canavar Se\u00e7",Ce:"Kum Saati/Rub kullan?",
Jk:"Rub kullan?",Fe:"Mobilizasyon Kullan?",Ee:"Ya\u015fam \u0130ksiri Kullan?",Be:"\u0130yile\u015ftirme Y\u00fczdesi (%)",Me:"Sald\u0131r\u0131 Say\u0131s\u0131",De:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131 (saniye cinsinden)",ze:"Yap\u0131lan Sald\u0131r\u0131lar",Ae:"Kalan Kum Saati",Ke:"Not: \u0130yile\u015ftirmek i\u00e7in yiyecek de\u011fil, ya\u015fam iksiri kullan\u0131r.",Le:"Not: Sald\u0131r\u0131lar erken durursa, 'Sald\u0131r\u0131lar\u0131 S\u0131f\u0131rla' deneyin.",Pe:"Ba\u015flat",
Ne:"S\u0131f\u0131rla",Qe:"Durdur",Re:"Ke\u015fif Ayarlar\u0131 (K\u00fc\u00e7\u00fcltmek i\u00e7in t\u0131klay\u0131n)",Ge:"Canavar 1",He:"Canavar 2",Ie:"Canavar 3",Je:"Canavar 4",Vk:"Eritmeden \u00f6nce tamir et?",Qi:"Bu se\u00e7enek, premium \u00fcyeli\u011finiz sona erdi\u011finde cervisia kullanacak.",xj:"Bu se\u00e7enek, tanr\u0131 \u00f6d\u00fcllerinden ya\u011flar\u0131 etkinle\u015ftirir ve se\u00e7er. Karakter \u00fczerinde 1 numara ve 3 numara ya\u011flar\u0131 kullanabilir ancak 2 numara sadece paketlere al\u0131n\u0131r.",
Oi:"Bu se\u00e7enek, belirledi\u011finiz zamanda buff kullan\u0131r. Paketlerdeki bufflar\u0131 bulur ve karaktere uygular.",mj:"Bu se\u00e7enek sizi kesif seferleriniz 2 ve altina geldiginde yeralt\u0131 d\u00fcnyas\u0131na sokar. Ekstralar sekmesinden Otomatik Giri\u015fi etkinle\u015ftirmeyi unutmay\u0131n, yoksa yeralt\u0131na girerken \u00e7\u0131k\u0131\u015f yapabilirsiniz [Oyun Hatas\u0131]",ec:"Bot sadece arena veya circus listesindekilere saldirir. Saldiramazsa atlar.",Hj:"Bu se\u00e7enek sadece premium lisanslar i\u00e7indir. Kullan\u0131c\u0131ya sald\u0131rmadan \u00f6nce %75 kazanma oran\u0131 ile sald\u0131r\u0131y\u0131 sim\u00fcle eder.",
Pd:"Bu se\u00e7ene\u011fi etkinle\u015ftirmek i\u00e7in ana m\u00fczayede ge\u00e7i\u015fini etkinle\u015ftirmenize gerek yoktur.",qk:"Bu se\u00e7enek, m\u00fczayede -\u00c7ok K\u0131sa- durumundayken sayfay\u0131 her saniye yeniler ve s\u00fcrekli teklif vererek m\u00fczayede kazanmay\u0131 ama\u00e7lar.",Tj:"E\u011fer eritme ko\u015fullar\u0131ndan hi\u00e7biri kar\u015f\u0131lanmazsa rastgele eritir. L\u00fctfen e\u015fya tipini ve rengini se\u00e7in.",Uj:"Bu se\u00e7enek sadece envanterdeki e\u015fyalar\u0131 eritir. Paketlerdeki e\u015fyalar\u0131 g\u00f6rmezden gelecektir.",
Pj:"Arkaplan\u0131 Siyah yap",Qj:"Bot butonlarini sol alta koy?",Ri:"Iyilestirme olmadan Sirke Sald\u0131r?",pk:"Gerekirse paketlerden alt\u0131n al\u0131ns\u0131n?",am:"E\u011fitim i\u00e7in paketlerden alt\u0131n al\u0131nd\u0131",Gd:"E\u011fitim i\u00e7in paketlerde alt\u0131n bulunamad\u0131",Cl:'GLDbot: Gizem kutusunu yenilemek ve de\u011ferli e\u015fyalar\u0131 (Vb. Kost\u00fcmler) a\u00e7madan \u00f6nce bulmak i\u00e7in zarlar\u0131 kullan. Sand\u0131klar\u0131 a\u00e7mak i\u00e7in "Ba\u015flat"a t\u0131kla.',
Wa:"Muzayede Esyalari",rg:"Mersaneri Esyalari",Xb:"Dukkan Esyalari",Ai:"Degerli Dukkan Esyalari",lk:"E\u015fyalar Tamir Edildi",ek:"Arena Sald\u0131r\u0131lar\u0131",gk:"Sirk Sald\u0131r\u0131lar\u0131",Ed:"E\u015fyalar S\u0131f\u0131rland\u0131",jk:"Sefer Sald\u0131r\u0131lar\u0131",ik:"Zindan Sald\u0131r\u0131lar\u0131",mk:"Yeralt\u0131 Sald\u0131r\u0131lar\u0131",fk:"Arenadan Kazan\u0131lan Para",hk:"Sirkten Kazan\u0131lan Para",Zl:"E\u015fyalar Eritildi",kk:"D\u00f6n\u00fc\u015ft\u00fcr\u00fclen Alt\u0131n",
dj:"Lonca Sava\u015f\u0131",fj:"Lonca Ayarlar\u0131",rl:"Loncalara rastgele sald\u0131racak.",ej:"Lonca Ismi",cj:"Rastgele Sald\u0131r",Pi:"\u0130statistikleri S\u0131f\u0131rla",Pc:"Ah\u015fap",Fc:"Bak\u0131r",Jc:"Demir",Lc:"Deri",Qc:"Y\u00fcn \u0130plik",Gc:"Y\u00fcn Yuma\u011f\u0131",Ic:"Kenevir",Hc:"Gaze \u015eeridi",Mc:"Keten Par\u00e7as\u0131",Kc:"J\u00fct Dikimi",Oc:"Kadife \u015eerit",Nc:"\u0130pek \u0130plik",Yc:"Post Par\u00e7as\u0131",Sc:"Kemik Par\u00e7as\u0131",ad:"Kepek",Vc:"Pen\u00e7e",
Xc:"K\u00f6pek Di\u015fi",Wc:"Ejderha Kepe\u011fi",Tc:"Bo\u011fa Boynuzu",$c:"Zehir Bezesi",Uc:"Cerberus`un post par\u00e7as\u0131",Zc:"Hidra pulu",bd:"Sfenks t\u00fcy\u00fc",cd:"Tifon derisi",Cc:"Lacivert Tasi",wc:"Ametist",vc:"Kehribar",xc:"Akuamarin",Dc:"Safir",Ac:"Grena Ta\u015f\u0131",zc:"Z\u00fcmr\u00fct",yc:"Elmas",Bc:"Jaspis",Ec:"Sugilith",qc:"Akrep Zehri",tc:"Dayan\u0131kl\u0131l\u0131k Tent\u00fcr\u00fc",mc:"Antidot",lc:"Adrenalin",sc:"Ayd\u0131nl\u0131k Tent\u00fcr\u00fc",pc:"Alg\u0131 Tent\u00fcr\u00fc",
nc:"Refleks Esans\u0131",oc:"Karizma Flakonu",uc:"Unutman\u0131n Suyu",rc:"Ruh esans\u0131",Bd:"Su M\u00fchr\u00fc",vd:"Koruyucu Runik",td:"D\u00fcnya Grav\u00fcr\u00fc",Ad:"\u015eifa Totemi",zd:"G\u00fc\u00e7 T\u0131ls\u0131m\u0131",xd:"\u015eans Ta\u015f\u0131",ud:"Ate\u015f Ta\u015f\u0131",yd:"F\u0131rt\u0131na Runi\u011fi",wd:"G\u00f6lge runi\u011fi",gd:"Kristal",fd:"Bronz",ld:"Obsidyen",od:"G\u00fcm\u00fc\u015f",pd:"K\u00fck\u00fcrt",jd:"Alt\u0131n Madeni",nd:"Kuvars",md:"Platin",ed:"Almandin",
hd:"Cuprit",kd:"Cehennem ta\u015f\u0131",Li:"Provinciarum'da Rastgele Sald\u0131r?",Mi:'Crazy-addon\'da "Arena oyuncular\u0131n\u0131 seviyeye g\u00f6re s\u0131rala" se\u00e7ene\u011fini de devre d\u0131\u015f\u0131 b\u0131rak\u0131n.',$g:"Sadece tanr\u0131 t\u00fcr\u00fcne g\u00f6re g\u00f6rev kabul et.",Xa:"Oto Buff",ce:"Sadece cehennemde kullan?",Gg:"Yeni Kural",Eg:"\u0130sim \u0130\u00e7erir",isUnderworldItem:"Yeralt\u0131 item mi?",kf:"Malzemeleri Yoksay",wk:"Dua Kullan?",Gi:"\u015eifalanmak i\u00e7in Kurban Kullan?",
sk:"Yeralt\u0131na girmek i\u00e7in kuma\u015f kullan?",xi:"Yeralt\u0131nda sadece yeralt\u0131 ile ilgili g\u00f6revleri kabul et?",wi:"Etkinle\u015ftirilirse, yeralt\u0131 item adlar\u0131n\u0131 girmeniz gerekir. Bot, bu itemlari yeralt\u0131nda bulursa g\u00f6revi kabul eder.",cl:"Yeralt\u0131 G\u00f6rev Itemi",ol:"Malzeme Ad\u0131n\u0131 Girin",Gk:"Bot zarlar\u0131 sever! Zarlar, sand\u0131klarda k\u0131yafet bulmaya yard\u0131mc\u0131 olur. Ancak zar yoksa, bot yine de sand\u0131klar\u0131 a\u00e7ar ve k\u0131yafetler bulmay\u0131 umar (ama bulamayabilir!).",
Sj:"Ertilen malzemeleri pakete g\u00f6nder?",re:"Arena'y\u0131 Etkinle\u015ftir",Sg:"Arena listesini \u00f6nceliklendir?",Tg:"Sirk listesini \u00f6nceliklendir?",je:"Log Men\u00fcs\u00fcn\u00fc Devre D\u0131\u015f\u0131 B\u0131rak",oh:"\u00d6d\u00fcl Min. Alt\u0131n De\u011feri",ah:"Odaklanm\u0131\u015f G\u00f6rev, etkinle\u015ftirilirse, zindan\u0131 bitirmek i\u00e7in en k\u0131sa yolu izler.",Nh:"Zar\u0131 Otomatik At?",Oh:"Zar\u0131 dikkatli kullan\u0131n, ilk zar\u0131 se\u00e7ene\u011fi devre d\u0131\u015f\u0131 b\u0131rakana kadar kullanmaya devam eder.",
uh:"Arama \u0130lerlemesi",ih:"Onar\u0131m\u0131n varsay\u0131lan bekleme s\u00fcresi 10 dakikad\u0131r.",Bg:"Minimum Durum",he:"\u0130\u015f tezgah\u0131ndaki mevcut \u00f6\u011fe [Bot beklenmedik \u015fekilde durursa Temizle]",Gf:"D\u00f6k\u00fcm Kaynaklar\u0131 ba\u015far\u0131yla horreuma depoland\u0131.",Cf:"Pazar yerindeki \u00f6\u011feleri kontrol ediyor...",Ab:"\u00d6\u011fe i\u015f tezgah\u0131na ta\u015f\u0131nd\u0131.",Tf:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131 ve donat\u0131ld\u0131.",
Uf:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131.",Qk:"Onar\u0131m ba\u015far\u0131s\u0131z oldu. Sayfa yenilenecek.",Qf:"Malzemeler toplan\u0131yor...",bg:"Onar\u0131m bekleniyor...",Sf:"Onar\u0131m ba\u015flad\u0131.",wa:"Onar\u0131m: \u00d6\u011feyi envanterden \u00e7antaya ta\u015f\u0131ma",Rf:"Onar\u0131m: \u00d6\u011feyi i\u015f tezgah\u0131ndan pakete ta\u015f\u0131ma.",ua:"Yeterli malzeme bulunamad\u0131. Onar\u0131m slotunu 5 dakikaligina devre disi birakiyorum. ",Nf:"Alt\u0131n\u0131 saklamak i\u00e7in a\u00e7\u0131k art\u0131rmadan sat\u0131n al\u0131nacak \u00f6\u011feler aran\u0131yor...",
zf:"Paketlerdeki s\u00fcresi dolmu\u015f \u00f6\u011feler kontrol ediliyor...",Af:"\u00d6\u011fe ba\u015far\u0131yla s\u0131f\u0131rland\u0131.",Bf:"Bo\u015f Alan veya S\u0131f\u0131rlanacak Alt\u0131n Yok.",Hf:"Klan pazar\u0131nda sat\u0131\u015f haklar\u0131n\u0131z oldu\u011fundan emin olun!",ub:"Yeterli alt\u0131n ve/veya sat\u0131n al\u0131nacak \u00f6\u011fe yok. Yenilemek i\u00e7in 30sn bekliyor.",wb:"Ma\u011faza yenilendi.",xb:"\u0130yile\u015ftirme s\u0131ras\u0131nda hata.",Kf:"Ruby veya Kuma\u015f yok, se\u00e7enekleri devre d\u0131\u015f\u0131 b\u0131rak.",
Pk:"Paketlerde yiyecek bulunamad\u0131.",yb:"Uygun yiyecek bulunamad\u0131",Lf:"Yiyecekler topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",Mf:"En az bir yiyecek topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",zb:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",If:"Paketlerden yiyecek al\u0131n\u0131yor.",Jf:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",vb:"Daha fazla iyile\u015ftirme \u00f6\u011fesi yok. 30 saniye bekliyor.",tb:"HP Kurtar\u0131ld\u0131.",
va:"Yapacak bir \u015fey yok, bu y\u00fczden dua edece\u011fim!",Yf:"Sa\u011fl\u0131\u011f\u0131m\u0131 ve villa medicimi kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Zf:"Villa Medici bekleniyor, 60 saniye i\u00e7inde yenileniyor.",$f:"Underworld terk edildi.",ag:"Sa\u011fl\u0131\u011f\u0131m\u0131 kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Of:"Tanr\u0131 ya\u011flar\u0131 kontrol ediliyor...",Pf:"Tanr\u0131 ya\u011flar\u0131 topland\u0131.",sa:"ARENADA ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",
ta:"CIRCUS'ta ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",xf:"A\u00e7\u0131k art\u0131rma kontrol ediliyor! L\u00fctfen bekleyin...",yf:"\u00d6\u011felere teklif veriliyor. L\u00fctfen bekleyin...",Vf:"Otomatik Eritilen Item: ",Wf:"Eritme \u00d6\u011fesi: ",Bb:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n: ",Xf:"ER\u0130T: Eritilecek \u00f6\u011feler aran\u0131yor...",Rk:"Eritilecek \u00f6\u011feler aran\u0131yor...",Df:"Kost\u00fcm mevcudiyeti kontrol ediliyor...",Ff:"Ba\u011f\u0131\u015fland\u0131 : ",
Ef:"Zar at\u0131l\u0131yor...",Xe:"Yeralti Farmla [Manuel, BETA]",Ye:"Bu ozelligi saldirmak istediginiz yaratigi actiktan sonra acin, otomatik olarak yaratigi acana kadar saldirmayacaktir. Dikkat edin.",We:"Farm Lokasyonu",Ve:"Farm Dusmani",Wd:"Otomatik Giri\u015f",Xd:"GameForge lobisinden a\u00e7\u0131l\u0131r pencere izinlerini vermeniz gerekmektedir. Nas\u0131l yap\u0131laca\u011f\u0131na dair dok\u00fcmantasyona bak\u0131n.",Og:"Bot'u Durdur",Pg:"Bot'u ka\u00e7 dakika bitince durdurmak istersiniz? (Dakika)",
Te:"Son Kullanma Tarihi",Jg:"Sadece yemek sat\u0131n al?",Kg:"Bunu etkinle\u015ftirirseniz, se\u00e7imlerinizi g\u00f6rmezden gelir ve herhangi bir \u015fey girmeden otomatik olarak yemek sat\u0131n al\u0131r.",Jb:"Harcamak i\u00e7in maksimum toplam alt\u0131n",Ib:"Harcamak i\u00e7in maksimum alt\u0131n miktar\u0131",Ig:"Bot, ya\u011flar\u0131 her 60 dakikada bir kontrol edecek",fi:"Eritme s\u00fcrelerini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",ci:"Alt\u0131n\u0131n\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
ei:"Kullan\u0131labilir e\u015fyan\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Yh:"E\u015fyalar\u0131n\u0131z\u0131 kontrol etmek i\u00e7in bir tamir zamanlay\u0131c\u0131 ayarlar.",Xh:"Ittifak pazar\u0131ndaki alt\u0131n\u0131 kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Th:"M\u00fczayede tutma alt\u0131n\u0131 se\u00e7ene\u011fi i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Ph:"Arenadaki PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Uh:"Sirk PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",li:"\u0130statistiklerinizi e\u011fitmek i\u00e7in bir e\u011fitim zamanlay\u0131c\u0131 ayarlar.",$h:"S\u00fcresi dolmu\u015f e\u015fyalar\u0131 s\u0131f\u0131rlamak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",ji:"D\u00f6vme malzemelerini horreum'a koymak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Rh:"Gladyat\u00f6rler ve paral\u0131 askerler m\u00fczayede kontrol\u00fc i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
bi:"M\u00fczayede ve market i\u00e7in e\u015fya aramak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Vh:"Ittifaga ba\u011f\u0131\u015f g\u00f6nderme zamanlay\u0131c\u0131s\u0131n\u0131 ayarlar.",bf:"Alt\u0131n Ta\u015f\u0131nd\u0131",oe:"Eritme ve Muzayede listesi e\u015fyalar\u0131n\u0131 satma",vh:"Market Otomasyonu",xh:"E\u015fya Arama Ayarlar\u0131",wh:"Bu ozellik, dukkanlarda e\u015fya aramak i\u00e7in kullanilir. Sadece e\u015fyalar\u0131 listeye ekleyin, kuma\u015f miktar\u0131n\u0131 belirtin ve aramay\u0131 ba\u015flat\u0131n. Ornegin mor samnit, mor samnit i bulana kadar arar.",
yh:"Kullan\u0131lacak Kuma\u015flar:",zh:"Ka\u00e7 kuma\u015f kullan\u0131lacak?",fa:"Full E\u015fya Ad\u0131n\u0131 Girin",Wb:"E\u015fya Seviyesini Girin",Bh:"E\u015fya Kalitesi",Ah:"E\u015fya Ad\u0131 Buraya",Ch:"Aramaya Ba\u015fla",Dh:"Atla ve Devam Et",Eh:"Aramay\u0131 Durdur",Ze:"En ucuz mu, en pahal\u0131 m\u0131 alay\u0131m?",Dg:"En Pahal\u0131",ee:"En Ucuz",Da:"Bir se\u00e7enek se\u00e7in",te:"Yeralt\u0131 D\u00fcnyas\u0131 Itemlarini Goster",$e:"G\u00f6reve odaklan\u0131ls\u0131n m\u0131?",
cm:"Elbise yoksa yakut kullan?",Ya:"Diger serverlarda sald\u0131rmak icin, oyuncunun sayfasini acin ve A & C butonlariyla ekleyin. Not: Rapor edilmemek i\u00e7in ayn\u0131 ki\u015filere sald\u0131rmaktan ka\u00e7\u0131n\u0131n. Rapor edilmek, banlanma \u015fans\u0131n\u0131z\u0131 art\u0131r\u0131r.",Rl:"Yesil Eritilsin mi?",Vg:"Herhangi bir filtre girildiyse rastgele g\u00f6revleri kabul etme?",Rc:"Maksimum materyal kalitesi?",$i:"Mersaneri Ara?",yl:"T\u00fcm Se\u00e7ilenleri Sat\u2019\u0131 t\u0131klay\u0131n ve t\u00fcm e\u015fyalar\u0131 sat\u0131n. \u0130lk (1) \u00e7antan\u0131zda 2x3 bo\u015f alan oldu\u011fundan emin olun ve kalite secmeyi unutmayin. Alt\u0131n toplamak i\u00e7in, alt\u0131n\u0131 filtreleyin ve `Se\u00e7ilenleri Al veya T\u00fcm\u00fcn\u00fc Al`\u0131 kullan\u0131n",
dk:"\ud83d\udd25 : E\u015fyay\u0131 eritme listesine ekler.",Ni:"\ud83d\udd28 : E\u015fyay\u0131 a\u00e7\u0131k art\u0131rma listesine ekler.",Jj:"D\u00fckkan dolu oldu\u011funda d\u00fckkan\u0131 kuma\u015fla yenileyin",Gl:"Sayfa:",Fj:"Durdur",Dj:"Bu Sayfay\u0131 Sat",Aj:"Se\u00e7ilenleri Al",zj:"T\u00fcm\u00fcn\u00fc Al",Gj:"Paket Ayarlar\u0131",Ej:"Kaynaklar\u0131 G\u00f6nder",Bj:"T\u00fcm Se\u00e7ilenleri Sat",na:"E\u015fya T\u00fcr\u00fc",pa:"Silahlar",U:"Kalkanlar",O:"Z\u0131rhlar",S:"Kasklar",
R:"Eldivenler",P:"Ayakkabilar",oa:"Y\u00fcz\u00fckler",la:"Nazarliklar",Ka:"Malzemeler (Yiyecekler)",Pa:"G\u00fc\u00e7lendirmeler",yj:"Yukseltmeler",Ma:"Receteler",La:"Mersaneri Askerler",Oa:"Demirhane Mallari",Na:"Persomenler",sd:"Takviyeler",qd:"Etkinlik E\u015fyalar\u0131",rd:"D\u00f6vme Malzemeleri",Fl:"Alt\u0131n",Ja:"Hepsi",Hl:"Kalite",qa:"Beyaz",C:"Ye\u015fil",B:"Mavi",D:"Mor",J:"Turuncu",T:"K\u0131rm\u0131z\u0131",Cj:"T\u00fcm Sat\u0131\u015f Se\u00e7enekleri",Rj:"\u00d6nek/Sonek Kombinasyonunu Yoksay?",
gj:"Ka\u00e7 yiyecek sat\u0131n almak/al\u0131nmal\u0131?",Vi:"Normal",Ui:"Orta",Ti:"Zor",Ga:"Standart",Ll:"S\u0131k\u0131\u015fma Onar\u0131m\u0131",Nk:"Dungeon/Circus/Arena\u2019y\u0131 devre d\u0131\u015f\u0131 b\u0131rakmak istiyorsan\u0131z Cehenneme Giri\u015fi Devre D\u0131\u015f\u0131 B\u0131rakin. Cehenneme manuel olarak girdiyseniz, Cehennem Modu\u2019nu etkinle\u015ftirmeniz gerekecektir.",oi:"Egitimleri ka\u00e7 kez e\u011fitmek istedi\u011finizi ve onlar\u0131n \u00f6nceliklerini belirleyin. Bot, bir \u00f6ncelik belirlemedik\u00e7e e\u011fitim yapmayacakt\u0131r. E\u011fer \u00f6ncelik belirlenmi\u015fse ancak ba\u015fka bir egitim kalmam\u0131\u015fsa, secilen egitim devam edecektir.",
ll:"Gorev",Dd:"Erit",Wl:"Eritme Ayarlar\u0131",ak:"Eritilen Nesneler",Xl:"\u00d6nek veya Sonek Ekle, paketlerde bulunursa otomatik olarak eritilecektir.:",Vl:"Eritilen Nesne:",ic:"Onarmak istedi\u011finiz nesneyi t\u0131klay\u0131n. Onar\u0131ma ba\u015flamak i\u00e7in en az 10,000 alt\u0131n\u0131z\u0131n olmas\u0131 gerekmektedir. Yeni repair sistemi refresh atilsa bile kaldigi yerden devam edecektir. Sorun cikarsa clear a basip workbench itemini temizleyebilirsiniz. Ayr\u0131ca envanterinizde yer a\u00e7mayi unutmayin. Bot, kondisyon seciminize gore aktif olacaktir.",
dl:"Sadece S\u00f6zle\u015fmeliye Uygula",hl:"M\u00fczayede yaln\u0131zca piyasa sona yakla\u015ft\u0131\u011f\u0131nda teklif verecektir.",gl:"Envanterde bos yer acmayi ve en az 7K alt\u0131n\u0131n\u0131z\u0131n oldu\u011fundan emin olun. Bot 1. koydugunuz prefixden baslayip sona dogru bakacaktir, bu siralamayi uzerine gelip tasiyarak degistirebilirsiniz. Bot, sectiginiz sekmeye gore itemlari tasiyacak ve eritecektir. Eritme i\u015flemi her ayarlanan zamana gore kontrol edilir. Bu ayari Zamanlayici sekmesinden degistirebilirsiniz. Eger kombinasyon olarak bakmak istemiyorsaniz, onek sonek kombinasyonunu yoksay`i aktiflestirin.",
jj:"\u0130yile\u015ftirme/Buff",Ml:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n:",Pl:"Teklifi Atla: ittifak \u00fcyesi zaten nesne i\u00e7in teklif verdi ",Ol:"Teklifi Atla: Zaten nesne i\u00e7in teklif verildi ",advanced:"Geli\u015fmi\u015f",arena:"Arena",ja:"Otomatik sald\u0131r\u0131 listesi",fc:"Bu listedekilere sald\u0131rma",ha:"Oyuncu Ekle",ia:"Oyuncu Ad\u0131 Gir (Ayni Server)",tl:"Yiyecek t\u00fckenirse Botu Durdur?",circusTurma:"Sirkin Turma",Wi:"Zorluk",dungeon:"Zindan",
Xi:"Zindan Ayarlar\u0131",eventExpedition:"Etkinlik Seferi",expedition:"Sefer",aj:"Sefer Ayarlar\u0131",Lj:"Yarat\u0131k Se\u00e7",vl:"En Y\u00fcksek",ul:"\u0130yile\u015ftirme e\u015fyalar\u0131n\u0131z\u0131 envanterinizin ilk sayfas\u0131na koyun",nj:"\u0130\u00e7inde",fe:"Yeralti kostumu secin",Ji:"Yeralti kostumu hazir oldugunda giy?",Lh:"Alt\u0131n\u0131 Depola",Mh:"Alt\u0131n\u0131 M\u00fczayedede Depola?",rh:"D\u00fckk\u00e2n\u0131 yenilemek i\u00e7in \u0130\u015f K\u0131yafetleri kullan\u0131ls\u0131n m\u0131?",
Xk:"S\u0131f\u0131rlanacak Nesneleri Se\u00e7in",kh:"S\u00fcresi Dolan Nesneleri S\u0131f\u0131rla",Qb:"Not: Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, bot paketlerden gelecek s\u00fcresi dolan nesneleri ittifak marketine satar ve s\u00fcrelerini s\u0131f\u0131rlar. Ittifak gereklidir. \u00c7antalar\u0131n\u0131zda bo\u015f 3x3 alan\u0131n\u0131z oldu\u011fundan emin olun, ozellikle birinci canta. Her basladiginda son 7 sayfaya bakar. Eger calismazsa oyun ayarlarindan sure bitimini tarih olarak ayarlayin.",
Qg:"Bota Rastgele Ara Vermesini Sa\u011fla [Test A\u015famas\u0131]:",aa:"Alt\u0131n\u0131 Tut: Bot bu alt\u0131n\u0131 \u00e7antada saklayacak:",pg:"Maksimum Alt\u0131n",ph:"Gereksiz itemlar i\u00e7in teklif verilecek",Hd:"Rastgele Gecikme Ekle",Id:"Bot i\u00e7in rastgele gecikme ekleyebilirsiniz.",Pb:"Onar\u0131m",Ql:"Mavi Eritilsin mi?",Tl:"Mor Eritilsin mi?",Sl:"Turuncu Eritilsin mi?",bk:"Sadece envantere koyulanlari mi eritsin?",Ul:"Bu renk se\u00e7imlerini yok sayacakt\u0131r",Qa:"\u00d6nek Ekle",
Ra:"Sonek Ekle",Gh:"Erit",Qd:"Otomatik Arama",Fg:"Otomatik M\u00fczayede",Rd:"Bu ozelligi fazla kullanmak banlanmaniza sebep olabilir. Eger Crazy Addon`da muzayedeyi zamanlarini gosteren ozelligi aktif ettiyseniz bu ozelligi kullanmadan once onu iptal edin, yoksa yavaslama olacaktir.",qh:"Gladyat\u00f6rler M\u00fczayedesinde Ara",th:"Mersaneriler M\u00fczayedesinde Ara",Zd:"Yiyecek \u0130\u00e7in Teklif Verilsin mi?",qg:"Maksimum Teklif",$d:"Durum daha azsa teklif ver",ae:"Teklif Edilen Nesneler",
Bk:"M\u00fczayede Dili",Ck:"L\u00fctfen dil ayarlarini oyunun diline gore tekrar ayarlay\u0131n.. Hepsi do\u011fru oldu\u011fundan emin olun, aksi takdirde teklif vermeyebilir.",Ld:"Piyasada aranacak nesneleri ekleyebilirsiniz. Bir nesneyi listede ekledi\u011finizde, nesneyi arayacak ve sonu\u00e7lar\u0131 sol tarafta g\u00f6sterecektir. Otomatik m\u00fczayedeyi aramak i\u00e7in de arayacakt\u0131r. Otomatik teklifi etkinle\u015ftirirseniz, belirledi\u011finiz aral\u0131klarla nesneyi arayacak ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: Tekil nesneleri d\u00fckkanlarda aramak i\u00e7in, en az\u0131ndan bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
zk:"M\u00fczayedeyi dikkatli kullan\u0131n!",Ak:"Otomatik teklif, sunucuya \u00e7ok fazla istek g\u00f6nderir ve s\u00fcrekli kullan\u0131rsan\u0131z yasa\u011fa neden olabilir!",hh:"Etkinlik Puanlar\u0131n\u0131 Yakut ile Yenile?",ve:"Otomatik Ya\u011f Topla",Ek:"Kutsal Ya\u011flar\u0131 Otomatik Al",Tk:"G\u00f6rev Kontrol H\u0131z\u0131",Ua:"Ittifak \u00dcyelerine Sald\u0131r\u0131ls\u0131n m\u0131?",Sa:"Oto Sald\u0131r\u0131 listesine cal\u0131nan Alt\u0131n X ALTINI a\u015ft\u0131\u011f\u0131nda > eklensin mi? ",
Ta:"Yenildi\u011finizde otomatik olarak eklensin mi?:",Tb:"Skor Tablosu Sald\u0131r\u0131lar\u0131",ac:"\u00c7ok Uzun",Cb:"Uzun",Kb:"Orta",Yb:"K\u0131sa",bc:"\u00c7ok K\u0131sa",we:"HP > ise Yeralt\u0131 D\u00fcnyas\u0131'na Gir",bh:"G\u00f6rev Kontrol H\u0131z\u0131",Ug:'Varsay\u0131lan olarak "3x" ayarl\u0131d\u0131r. Bot g\u00f6revlerle sorun \u00e7\u0131kar\u0131yorsa, g\u00f6rev h\u0131z\u0131n\u0131 sunucu h\u0131z\u0131n\u0131za g\u00f6re ayarlay\u0131n.',cf:"\u0130yile\u015ftirme \u00c7anta Se\u00e7imi",
xe:'Puanlar\u0131 manuel olarak yeniliyorsan\u0131z, s\u0131k\u0131\u015f\u0131rsa "Yeniden Etkinlik Seferi Yenile" d\u00fc\u011fmesine t\u0131klaman\u0131z gerekmektedir!',Ik:"Etkinlik Seferi'ni ba\u015flatmak i\u00e7in en az birini etkinle\u015ftirmeniz gerekmektedir: sefer, zindan, arena veya sirk.",eh:"E\u011fer s\u0131k\u0131\u015f\u0131rsa Etkinlik Seferi'ni Yenile!",mb:"\u0130ttifak \u00fcyesi teklif verdiyse atlas\u0131n m\u0131?",$k:"E\u011fer paketlerde bulunan \u00f6\u011feleri kullanarak eritmek istiyorsan\u0131z, t\u00fcm ayarlar\u0131 devre d\u0131\u015f\u0131 b\u0131rak\u0131n. Ancak hala renkleri se\u00e7ebilirsiniz.",
Fk:"Karakter(Kapal\u0131) / S\u00f6zle\u015fmeli(A\u00e7\u0131k)",Wk:"Ana/Sirk her iki karakteri de tamir etsin mi?",al:"Zamanlar",Timers:"Her zamanlay\u0131c\u0131 i\u00e7in a\u015fa\u011f\u0131daki dakika cinsinden say\u0131lar\u0131 girin veya varsay\u0131lan b\u0131rak\u0131n. Dikkat edin! eger cok kisa sureler girerseniz baz\u0131 ozellikler botu donguye sokayabilir.",pb:"Skor Tablosu Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Rb:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131n\u0131 Se\u00e7",
Sb:"Bot, skor tablosu listesinden rastgele sald\u0131r\u0131 yapacakt\u0131r.",rb:"Lig Sald\u0131r\u0131s\u0131",ob:"Lig Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Nb:"Rastgele Sald\u0131r",Ob:"En d\u00fc\u015f\u00fckten en y\u00fckse\u011fe sald\u0131r",yk:"Bot, varsay\u0131lan olarak ittifak \u00fcyelerine sald\u0131rmaktan ka\u00e7\u0131nacakt\u0131r.",Se:"Sefer Yeri:",Sd:"Bonuslar\u0131 Otomatik Al:",Fh:"Boss`a sald\u0131rma",qe:"Zindan Yeri:",nh:"Kaybederseniz S\u0131f\u0131rlans\u0131n m\u0131?",
ff:"Cehennem Ayarlar\u0131",gf:"Bu mod birden sona kadar saldirarak cehennemi bitirir. \u0130yile\u015ftirme y\u00fczde ayarlar\u0131n\u0131z\u0131 iyile\u015ftirme sekmesinden yap\u0131land\u0131r\u0131n ve iyile\u015ftirme sekmesini etkinle\u015ftirdi\u011finizden emin olun. Cehennem modu aktif oldugunda bot cehennem iyilestirme oranina gore karakterinize yemek yedirecektir. Cehenneme giri\u015f sizi oturumdan \u00e7\u0131kar\u0131yorsa, extralar tabini ziyaret edin ve otomatik giri\u015f kutusunu i\u015faretleyin.",
df:"Cehennem Zorlu\u011fu",Vd:"Otomatik Cehennem Giri\u015fi / Cehennem Modu:",Ei:"Puan = 0 ise Mobilizasyon Kullan?",Ii:"Yakut Kullan?",ye:"Puan Yoksa Cehennemden \u00c7\u0131k\u0131ls\u0131n m\u0131?",ri:"Bot, \u00f6nce villa mediciyi kullanmaya \u00e7al\u0131\u015facakt\u0131r, e\u011fer yoksa iyile\u015ftirme iksiri kullanacakt\u0131r. \u0130yile\u015ftirme anahtar\u0131n\u0131 etkinle\u015ftirdi\u011finizden emin olmay\u0131 unutmay\u0131n.",zi:"Otomatik cehennem giri\u015fi, cehenneme girdi\u011finizde zindan/arena/sirk otomatik olarak devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",
bl:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",Hi:"Villa Medici Kullan?",Fi:"\u0130yile\u015ftirme \u0130ksiri Kullan?",dg:"Bu ozellik genel marketten esya almaya yarar. Satin alma suresi biraz surebilir.",ue:"Pazar Aramas\u0131n\u0131 Etkinle\u015ftir:",eg:"Dakika cinsinden Pazar Arama Aral\u0131\u011f\u0131:",fg:"\u00d6nerilen 10 dakika.",rf:"Nesne Ayarlar\u0131:",pf:"Nesne Ad\u0131 \u0130\u00e7erir",G:"Maksimum Fiyat",sf:"Nesne T\u00fcr\u00fc",qf:"Nesne Nadirli\u011fi",de:"Ruh Ba\u011fl\u0131 Al\u0131ns\u0131n m\u0131?",
uf:"Al\u0131nacak Nesneler",tf:"Herhangi biri maksimum fiyat\u0131 a\u015f\u0131yorsa \u00f6\u011feleri almay\u0131 deneyin.:",be:"Sat\u0131n Al\u0131nan Nesneler:",hj:"\u0130yile\u015ftirme Y\u00fczdesi",uk:"D\u00fckkandan Yiyecek Sat\u0131n Al\u0131ns\u0131n m\u0131?",vk:"Paketten \u0130yile\u015ftirme Kullan\u0131ls\u0131n m\u0131?",rk:"Cervisia Kullan\u0131ls\u0131n m\u0131?",tk:"Yumurta Kullan\u0131ls\u0131n m\u0131?",zl:"Son Kullan\u0131ld\u0131",location:"Konum",Strength:"G\u00fc\u00e7",Dexterity:"Beceri",
Agility:"\u00c7eviklik",Constitution:"Dayaniklilik",Charisma:"Karizma",Intelligence:"Zeka",mi:"E\u011fitim Ayarlar\u0131",ni:"E\u011fitim yapmak istedi\u011finiz nitelikleri se\u00e7in. Yeterli alt\u0131n\u0131z oldu\u011funda e\u011fitim yapacakt\u0131r.",N:"Sonraki ad\u0131m",vj:"Hay\u0131r",wj:"Normal",Dl:"Rakip",El:"Rakip Seviyesi",Ij:"G\u00f6revler",random:"Rastgele",Nl:"Ayarlar",Yl:"Yak\u0131nda...",type:"G\u00f6rev t\u00fcrlerini etkinle\u015ftirmek i\u00e7in simgeleri t\u0131klay\u0131n.",
em:"Evet",A:"Arama",Cd:"\u00d6\u011feleri ekle",nk:"Demircilik Kaynaklar\u0131n\u0131 Otomatik Olarak Sakla",$l:"G\u00f6nder",xl:"Aral\u0131k : ",ml:"Otomatik Teklif Etkinle\u015ftir",nl:"Bir ittifak \u00fcyesi zaten teklif verdiyse teklif vermeyin",bm:"\u00d6\u011fretici",hc:"Arena'da en d\u00fc\u015f\u00fck veya en y\u00fcksek seviyeli rakiple y\u00fczle\u015fmek isteyip istemedi\u011finizi yukar\u0131daki d\u00fc\u011fmelerden se\u00e7in. Daha fazla kullan\u0131c\u0131, botun h\u0131z\u0131n\u0131 yava\u015flatabilir.",
el:"Ba\u015flamak i\u00e7in bir \u00f6\u011feyi listeyle ekleyin (\u00f6r. `Lucius`). Ekledikten sonra, arama sonu\u00e7lar\u0131n\u0131 sol tarafta g\u00f6r\u00fcnt\u00fclemek i\u00e7in arama sonu\u00e7lar\u0131n\u0131 g\u00f6sterir. Ayn\u0131 zamanda otomatik m\u00fczayede ama\u00e7lar\u0131 i\u00e7in de arar. Otomatik teklifi etkinle\u015ftirirseniz, belirli aral\u0131klarla \u00f6\u011feyi arar ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: D\u00fckkanlarda benzersiz \u00f6\u011feleri aramak i\u00e7in, en az bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
pl:"Yarat\u0131k numaras\u0131n\u0131 yukar\u0131daki d\u00fc\u011fmelerden se\u00e7ebilirsiniz. Numara 1, en soldaki yarat\u0131\u011f\u0131 temsil eder. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",Yi:"Zindan\u0131n zorlu\u011funu yukar\u0131dakilerden se\u00e7in. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",ij:"\u0130yile\u015ftirme Ayarlar\u0131",Zi:"Ittifak Piyasas\u0131ndan al\u0131\u015fveri\u015f yaparak fazla alt\u0131n\u0131 depola -> Min. Alt\u0131n. 1. Envanterde bos yer birakmaya calisin.",
Al:"T\u00fcm\u00fcn\u00fc Ta\u015f\u0131",Bl:"Se\u00e7ilenleri Ta\u015f\u0131",il:"Otomatik \u0130yile\u015ftirme",jl:"Otomatik \u0130yile\u015ftirme Y\u00fczdesi",dm:"Yakut",Lg:"Genel Ayarlar",Mj:"Hepsini Sat",Nj:"Se\u00e7ilenleri Sat",ga:"Silahlar",da:"Kalkanlar",W:"G\u00f6\u011f\u00fcs Z\u0131rhlar\u0131",Z:"Kasklar",Y:"Eldivenler",ea:"Ayakkab\u0131lar",ca:"Y\u00fcz\u00fckler",V:"Kolyeler",Ci:"Kullan\u0131labilir",Bi:"G\u00fc\u00e7lendirmeler",dh:"Re\u00e7eteler",sg:"S\u00f6zle\u015fmeli Scrollar",
fh:"Takviyeler",Zg:"G\u00f6rev Filtre \u0130gnore",Yg:"Almak istemedi\u011finiz g\u00f6revleri filtrelemek i\u00e7in anahtar kelimeleri girin",X:"Anahtar Kelime Girin",K:"Ekle",gh:"Kald\u0131r",ge:"Temizle",Wg:"G\u00f6rev Filtre Kabul",Xg:"Almak istedi\u011finiz g\u00f6revleri se\u00e7mek i\u00e7in anahtar kelimeleri girin. Odule gore secmek isterseniz odulun icinde gecen bir kelimeyi girin.",Ea:"Zamanl\u0131 G\u00f6revleri Atla?",Uk:"G\u00f6revler",Td:"Oto Kost\u00fcm",Di:"Kost\u00fcm Kullan?",Yd:"Ana Sava\u015f",
pe:"Dungeon Sava\u015f ve Etkinlik",Ud:"Bot yaln\u0131zca ke\u015fif/zindan puanlar\u0131n\u0131z 0 ise Dis Pater Normal ve Medium giyecektir.",ef:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",Kd:"Boss Mevcut Oldu\u011funda Sald\u0131r?",sb:"5 ba\u015far\u0131s\u0131z sald\u0131r\u0131dan sonra Lig sald\u0131r\u0131s\u0131n\u0131 devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",hf:"Kutsal Ya\u011flar",Ag:"\u00dcr\u00fcn Ad\u0131",ba:"Min. Item Seviyesi",Ba:"Min. \u00dcr\u00fcn Kalitesi",Jd:"Zamanlay\u0131c\u0131y\u0131 Uygula/S\u0131f\u0131rla",
lf:"\u00d6nek/Soneki Yok Say",Ki:"Evet",Hg:"Hay\u0131r",Za:"Ge\u00e7mi\u015fi Temizle",Hh:"Yok Sayma Listesi",Mb:"\u00d6nek",Zb:"Sonek",mh:"S\u00fcresi Dolan \u00dcr\u00fcnleri S\u0131f\u0131rla",Ih:"Kondisyonlar disinda rastgele erit",Jh:"Eritme Sekmesi",qb:"Ekstralar",Od:"M\u00fczayede",ig:"Pazar",$b:"Zamanlar",hi:"Eritme",gi:"Alt\u0131n Yoksa Eritme",di:"\u00dcr\u00fcn Yoksa Eritme",Fa:"Tamir",Wh:"Ittifak Pazar\u0131 Alt\u0131n Tutma",Sh:"M\u00fczayede Alt\u0131n Tutma",ki:"E\u011fitim",Zh:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla",
ii:"Hammadde Depola",Qh:"M\u00fczayede Kontrol",ai:"Arama",v:"Etkinle\u015ftir",Cg:"Min. Alt\u0131n",Ub:"Saat Se\u00e7in",nb:"Ittifaga Alt\u0131n Ba\u011f\u0131\u015fla",ke:"Her 5 dakikada bir ba\u011f\u0131\u015f yapacakt\u0131r. Zamanlay\u0131c\u0131lar sekmesinden aral\u0131\u011f\u0131 de\u011fi\u015ftirebilirsiniz",jf:"Ne kadar ba\u011f\u0131\u015f yap\u0131lmal\u0131?",le:"Ne zaman ba\u011f\u0131\u015f yap\u0131lmal\u0131 >",wf:"Daha az <",jh:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla ve Di\u011fer Ayarlar\u0131",
lh:"S\u0131f\u0131rla in:",Ok:"Birden fazla \u00f6\u011feyi se\u00e7mek i\u00e7in Ctrl (Mac'de Cmd) tu\u015funu bas\u0131l\u0131 tutun",mf:"Ayarlar\u0131 Kaydet / Yukle",Ue:"Ayarlar\u0131 Indir",nf:"Ayarlar\u0131 Yukle",tg:"T\u00fcm Oyunculara Mesaj G\u00f6nder",ug:"[Ultra Premium Anahtar\u0131 gerektirir, anahtar i\u00e7in Discord \u00fczerinden ileti\u015fime ge\u00e7in.]",vg:"G\u00f6nderilecek mesaj\u0131 girin",ie:"\u00d6zel scriptler i\u00e7in Discord \u00fczerinden bize ula\u015f\u0131n",xg:"G\u00f6nder",
yg:"Oyuncular\u0131 G\u00f6ster",wg:"T\u00fcm\u00fcn\u00fc Se\u00e7",zg:"T\u00fcm Se\u00e7imleri Kald\u0131r",vf:"Envanterinizin yeterli alan\u0131 oldu\u011fundan emin olun. Geri say\u0131m 2 dakikad\u0131r.",mg:"Yiyecek Sat",Gb:"Yiyeceklere Ge\u00e7"},Oh={cg:"Erro de mercado! Por favor, adicione os itens novamente e tente novamente.",Lb:"N\u00e3o h\u00e1 espa\u00e7o suficiente no invent\u00e1rio!",ck:"Derreter cores mais altas primeiro?",cc:"Atacar apenas a lista de jogadores?",dc:"Quando esta op\u00e7\u00e3o \u00e9 ativada, o bot s\u00f3 atacar\u00e1 jogadores na lista de jogadores. Se esta op\u00e7\u00e3o n\u00e3o estiver ativada, o bot atacar\u00e1 jogadores aleat\u00f3rios.",
Kk:"Suas configura\u00e7\u00f5es de expedi\u00e7\u00e3o est\u00e3o incorretas ou h\u00e1 dados de p\u00e1gina inesperados!",Lk:"Sua configura\u00e7\u00e3o de expedi\u00e7\u00e3o est\u00e1 incorreta! Voc\u00ea definiu um monstro desabilitado, o que est\u00e1 errado.",Yk:"Redefinir apenas todos os itens do submundo com a cor selecionada?",Ca:"Prioridade",Vb:"Definir Prioridade",Rg:"Pontos",Kh:"Stat",Si:"Coletar Ouro",Oj:"Vender itens do Submundo?",uj:"O bot procurar\u00e1 pelo ninho em cada a\u00e7\u00e3o, n\u00e3o apenas em expedi\u00e7\u00f5es.",
sj:"Tipo de busca de ninho",qj:"N\u00e3o fazer nada",rj:"Busca r\u00e1pida",tj:"Busca detalhada",Kl:"A\u00e7\u00e3o p\u00f3s expedi\u00e7\u00e3o",xk:"Clique aqui se o reparo ficar travado",Mk:"Quando HP estiver baixo, use cura",Ng:"Reparo Parcial",af:"Reparo Completo",Mg:"Reparo Parcial ou Completo",se:"Habilitar Limite",kj:"Limite",lj:"Se voc\u00ea deseja limitar o n\u00famero de vezes que quer atacar o inimigo, habilite esta op\u00e7\u00e3o e defina o limite. O bot continuar\u00e1 atacando o resto dos inimigos ap\u00f3s terminar de atacar o monstro selecionado.",
ne:"N\u00e3o entre no submundo com a fantasia do submundo",me:"Se voc\u00ea n\u00e3o quiser entrar no submundo enquanto estiver usando a fantasia do submundo, ative esta op\u00e7\u00e3o",yi:"Submundo",pi:"Melhorias do Submundo",si:"Usar os poderes dos deuses ap\u00f3s entrar no submundo?",ti:"Selecione os deuses para usar seus poderes:",ui:"Usar Buff de Arma na arma?",vi:"Usar Buff de Armadura no seguinte equipamento:",Hk:"O tempo de espera \u00e9 de 30 minutos. Se voc\u00ea n\u00e3o estiver com um traje, o bot redefinir\u00e1 o tempo de espera para 0.",
Zk:"Selecionar Cores",$a:"Forja de Vulcano",eb:"Escudo Terrestre de Feronia",fb:"Poder Fluido de Netuno",gb:"Liberdade A\u00e9rea de Aelous",hb:"N\u00e9voa Mortal de Plut\u00e3o",ib:"Sopro de Vida de Juno",jb:"Armadura de Escamas das Montanhas da Ira",kb:"Olhos de \u00c1guia",lb:"Vestimenta de Inverno de Saturno",ab:"Armadura de Touro de Bubona",bb:"Trajes de Ladr\u00e3o de Merc\u00fario",cb:"T\u00fanica de Luz de R\u00e1",lg:"Pacotes",gg:"Invent\u00e1rio",M:"Pre\u00e7o M\u00edn.",L:"Quantos",Fb:"Vender Itens",
Eb:"Procurar em",hg:"Cor do Material",Db:"Cor do Item",og:"Armaz\u00e9m",Aa:"Mudar para Materiais",Hb:"Mudar para Itens",ng:"Vender Materiais",xa:"Por favor, insira um nome de item v\u00e1lido, faixa de pre\u00e7o e quantidade.",ya:"Nenhum item adequado encontrado nos locais de busca selecionados.",za:"Todos os itens foram listados com sucesso!",Sk:"Todos os materiais foram listados com sucesso!",jg:"Se voc\u00ea quiser vender itens por um pre\u00e7o fixo, voc\u00ea pode inserir o mesmo valor para o pre\u00e7o m\u00ednimo e m\u00e1ximo.",
kg:"Este recurso ainda \u00e9 experimental, use com cautela. Se voc\u00ea n\u00e3o colocar um pre\u00e7o fixo, os itens ser\u00e3o listados aleatoriamente entre o pre\u00e7o m\u00ednimo e m\u00e1ximo que voc\u00ea inserir.",Dk:"Define o m\u00e1ximo de ouro que o bot gastar\u00e1 por ciclo.",Va:"O bot come\u00e7ar\u00e1 a fazer lances em itens de comida, se habilitado. Voc\u00ea n\u00e3o precisa habilitar os interruptores de gladiador/mercen\u00e1rio.",Md:"O bot n\u00e3o far\u00e1 lances sobre os lances dos aliados.",
Nd:"Ignorar combina\u00e7\u00e3o de Prefixo/Sufixo ao procurar por um item no leil\u00e3o.",Vj:"Selecione os tipos de item que voc\u00ea deseja fundir.",Wj:"Selecione as cores que voc\u00ea deseja fundir.",Xj:"Selecione o n\u00edvel dos itens que voc\u00ea deseja fundir.",Yj:"Selecione o martelo que voc\u00ea deseja usar.",Zj:"Note que o c\u00edrculo Verde e Vermelho ao lado da primeira caixa s\u00e3o para ativar/desativar a regra.",$j:"Se voc\u00ea quiser fundir aleatoriamente quaisquer cores ou tipos, voc\u00ea pode ativar `Fundir aleatoriamente se nenhuma condi\u00e7\u00e3o for atendida? (\u00daltima op\u00e7\u00e3o habilitada no v\u00eddeo tutorial)",
Kj:"Reparar antes de fundir?",Oe:"Selecionar Monstro",Ce:"Usar Ampulheta/Rubi?",Jk:"Usar Rubi?",Fe:"Usar Mobiliza\u00e7\u00e3o?",Ee:"Usar Po\u00e7\u00e3o de Vida?",Be:"Percentual de Cura (%)",Me:"N\u00famero de Ataques",De:"Intervalo de Ataque (em segundos)",ze:"Ataques Realizados",Ae:"Ampulhetas Restantes",Ke:"Nota: Usa po\u00e7\u00f5es de vida para curar, n\u00e3o comida.",Le:"Nota: Se os ataques pararem prematuramente, tente 'Resetar Ataques'.",Pe:"Iniciar",Ne:"Resetar",Qe:"Parar",Re:"Configura\u00e7\u00f5es de Expedi\u00e7\u00e3o (Clique para minimizar)",
Ge:"Monstro 1",He:"Monstro 2",Ie:"Monstro 3",Je:"Monstro 4",Vk:"Reparar antes de fundir?",Qi:"Esta op\u00e7\u00e3o usar\u00e1 cervisia quando seu premium expirar.",xj:"Esta op\u00e7\u00e3o ativa e seleciona \u00f3leos das recompensas divinas. Pode usar \u00f3leos n\u00famero 1 e 3 no personagem, mas o n\u00famero 2 s\u00f3 ser\u00e1 pego para pacotes.",Oi:"Esta op\u00e7\u00e3o usar\u00e1 buffs no hor\u00e1rio que voc\u00ea definir. Encontrar\u00e1 buffs nos pacotes e os aplicar\u00e1 ao personagem.",
mj:"Esta op\u00e7\u00e3o te levar\u00e1 ao submundo. N\u00e3o esque\u00e7a de habilitar o Login Autom\u00e1tico na aba Extras, caso contr\u00e1rio, voc\u00ea pode ser desconectado ao entrar no submundo [Bug do Jogo]",ec:"Esta opci\u00f3n solo atacar\u00e1 la lista de arena/circo. Si no puede, el bot la omitir\u00e1.",Hj:"Esta op\u00e7\u00e3o \u00e9 apenas para licen\u00e7as premium. Simula o ataque antes de atacar um usu\u00e1rio para uma taxa de vit\u00f3ria de 75%.",Pd:"Voc\u00ea n\u00e3o precisa habilitar a togglede leil\u00e3o principal para habilitar esta op\u00e7\u00e3o.",
qk:"Esta op\u00e7\u00e3o atualizar\u00e1 a p\u00e1gina a cada segundo quando o leil\u00e3o estiver no estado -Muito Curto- para dar lances constantemente e vencer o leil\u00e3o.",Tj:"Se nenhuma das condi\u00e7\u00f5es de fus\u00e3o for atendida, ele fundir\u00e1 aleatoriamente. Certifique-se de selecionar o tipo e a cor do item.",Uj:"Esta op\u00e7\u00e3o fundir\u00e1 apenas itens do invent\u00e1rio. Ignorar\u00e1 itens nos pacotes.",Wa:"Itens de Leil\u00e3o",rg:"Itens de Mercen\u00e1rio",Xb:"Itens da Loja",
Ai:"Itens \u00danicos",Pj:"Definir fundo para preto [Aumenta o desempenho]",Qj:"Mover bot\u00f5es do GLDbot para o canto inferior esquerdo?",Ri:"Atacar o Circo Sem Curar",pk:"Pegar ouro dos pacotes se necess\u00e1rio?",am:"Ouro foi pego dos pacotes para treinamento",Gd:"Nenhum ouro foi encontrado nos pacotes para treinamento",lk:"Itens Reparados",ek:"Ataques na Arena",gk:"Ataques no Circo",Ed:"Itens Reiniciados",jk:"Ataques em Expedi\u00e7\u00f5es",ik:"Ataques em Masmorras",mk:"Ataques no Submundo",
fk:"Dinheiro Ganhado na Arena",hk:"Dinheiro Ganhado no Circo",Zl:"Itens Fundidos",kk:"Ouro Reciclado",dj:"Batalha de Guilda",fj:"Configura\u00e7\u00f5es da Guilda",rl:"Atacar\u00e1 guildas aleatoriamente.",ej:"Nome da Guilda",Pi:"Redefinir Estat\u00edsticas",cj:"Atacar Guildas Aleatoriamente",Cl:'GLDbot: Use os dados para atualizar a caixa misteriosa e encontrar itens valiosos antes de abri-los (Etc. Trajes). Clique em "Iniciar" para abrir ba\u00fas.',Pc:"Madeira",Fc:"Cobre",Jc:"Ferro",Lc:"Couro",
Qc:"Fio de L\u00e3",Gc:"Bolas de Algod\u00e3o",Ic:"Hemp",Hc:"Tiras de Gaze",Mc:"Fios de Linho",Kc:"Remendo",Oc:"Veludo",Nc:"Fio de Seda",Yc:"Pelo",Sc:"Lasca de Osso",ad:"Escama",Vc:"Garra",Xc:"Presas",Wc:"Escama de Drag\u00e3o",Tc:"Corno de Touro",$c:"Gl\u00e2ndula Venenosa",Uc:"Casaco de Pele de Cerberus",Zc:"Escama de Hydra",bd:"Pena de Esfinge",cd:"Pele de Typhon",Cc:"Lapis Lazuli",wc:"Ametista",vc:"Ambar",xc:"Agua-Marinha",Dc:"Safira",Ac:"Granada",zc:"Esmeralda",yc:"Diamante",Bc:"Jasper",Ec:"Sugilite",
qc:"Veneno de Escorpi\u00e3o",tc:"Tintura de Resist\u00eancia",mc:"Antidoto",lc:"Adrenalina",sc:"Tintura Esclarecedora",pc:"Po\u00e7\u00e3o de Perce\u00e7\u00e3o",nc:"Ess\u00eancia de Rea\u00e7\u00e3o",oc:"Frasco de Carisma",uc:"\u00c0guas de Oblivion",rc:"Ess\u00eancia de Alma",Bd:"Selo Aqu\u00e1tico",vd:"Runa Protetora",td:"Marca da Terra",Ad:"Totem de Cura",zd:"Talism\u00e3 do Poder",xd:"Pedra da Fortuna",ud:"Pedernal",yd:"Runa da Tempestade",wd:"Runa das Sombras",gd:"Cristal",fd:"Bronze",ld:"Obsidiana",
od:"Prata",pd:"Enxofre",jd:"Mina de Ouro",nd:"Quartzo",md:"Platina",ed:"Almandin",hd:"Cuprit",kd:"Pedra do Inferno",Li:"Atacar Aleatoriamente em Provinciarum?",Mi:'Tamb\u00e9m desative a configura\u00e7\u00e3o "Classificar jogadores na arena por n\u00edvel" no crazy-addon.',$g:"Aceitar apenas miss\u00f5es com base no tipo de deus.",Xa:"Auto Buff",ce:"Usar apenas no inferno?",Gg:"Nova Regra",Eg:"Nome Cont\u00e9m",isUnderworldItem:"\u00c9 Item do Submundo",kf:"Ignorar Materiais",wk:"Usar Ora\u00e7\u00e3o?",
Gi:"Usar Sacrif\u00edcio?",sk:"Usar Roupas para Entrar no Submundo?",xi:"Miss\u00f5es do Submundo",wi:"Se habilitado, voc\u00ea precisa digitar nomes de itens do submundo. Se o bot encontrar esses itens no submundo, ele aceitar\u00e1 a miss\u00e3o.",cl:"Item da Miss\u00e3o do Submundo",ol:"Digite o nome do material",Gk:"O bot adora dados! Eles ajudam a encontrar roupas nos ba\u00fas. Mas se n\u00e3o houver dados, o bot abre os ba\u00fas mesmo assim, na esperan\u00e7a de encontrar roupas legais (mas pode n\u00e3o encontrar nenhuma!)",
Sj:"Enviar os materiais derretidos para os pacotes?",re:"Ativar Arena?",Sg:"Priorizar lista de arena?",Tg:"Priorizar lista de circo?",je:"Desativar Menu de Log",oh:"Recompensa Min. Valor em Ouro",ah:"Miss\u00e3o Focada, se ativada, seguir\u00e1 o caminho mais curto para terminar a masmorra.",Nh:"Jogar Dados Automaticamente?",Oh:"Use jogar dados com cautela, ele continuar\u00e1 usando o primeiro dado at\u00e9 voc\u00ea desativar a op\u00e7\u00e3o.",uh:"Progresso da Pesquisa",ih:"O tempo de espera para reparo por padr\u00e3o \u00e9 de 10 minutos.",
Bg:"Condi\u00e7\u00e3o M\u00ednima",he:"Item atual na bancada [Limpar se o bot pausar inesperadamente]",Gf:"Recursos da Forja armazenados com sucesso no horreum.",Cf:"Verificando itens no mercado...",Ab:"Item movido para a bancada.",Tf:"Item reparado e equipado com sucesso.",Uf:"Item reparado com sucesso.",Qk:"Reparo falhou. A p\u00e1gina ser\u00e1 atualizada.",Qf:"Pegando materiais...",bg:"Aguardando reparo...",Sf:"Reparo iniciado para .",wa:"Reparo: Movendo o item do invent\u00e1rio para a bolsa",
Rf:"Reparo: Movendo o item da bancada para o pacote.",ua:"N\u00e3o foi poss\u00edvel encontrar materiais suficientes. Desativando o slot de reparo ",Nf:"Procurando itens para comprar para esconder ouro no Leil\u00e3o...",zf:"Verificando itens expirados nos pacotes...",Af:"Item redefinido com sucesso.",Bf:"Sem Espa\u00e7o Vazio ou Ouro para Redefinir.",Hf:"Certifique-se de que voc\u00ea tem direitos de venda no mercado da guilda!",ub:"Ouro insuficiente e/ou nenhum item para comprar. Aguardando 30s para atualizar.",
wb:"Loja foi atualizada.",xb:"Erro durante a cura.",Kf:"Sem Rubi ou Pano, desativando as op\u00e7\u00f5es.",Pk:"Nenhum item de cura encontrado nos pacotes.",yb:"Nenhum item adequado encontrado",Lf:"Alimentos foram pegos. Finalizando o processo.",Mf:"Pelo menos um alimento foi pego. Finalizando processo.",zb:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",If:"Pegando comida dos pacotes.",Jf:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",vb:"Sem mais itens de cura. Aguardando 30 segundos.",
tb:"HP Recuperado.",va:"Nada para fazer ent\u00e3o vou rezar!",Yf:"Vou atualizar em 60 segundos para verificar minha sa\u00fade e villa medici.",Zf:"Aguardando Villa Medici, atualizando em 60 segundos.",$f:"Saiu do submundo.",ag:"Vou atualizar em 60 segundos para verificar minha sa\u00fade.",Of:"Verificando \u00f3leos de deus...",Pf:"\u00d3leos de deus foram pegos.",sa:"Atacou com sucesso o jogador na ARENA: ",ta:"Atacou com sucesso o jogador no CIRCO: ",xf:"Verificando leil\u00e3o! Por favor, aguarde...",
yf:"Dando lances em itens. Por favor, aguarde...",Vf:"Item Derretido Automaticamente: ",Wf:"Derretendo Item: ",Bb:"Ouro insuficiente para derreter. Ouro Necess\u00e1rio: ",Xf:"DERRETER: Procurando itens para derreter...",Rk:"Procurando itens para derreter...",Df:"Verificando disponibilidade de traje...",Ff:"Doado : ",Ef:"Jogando dados...",Xe:"Underworld Farm [Manual, Beta]",Ye:"Esteja ciente: ative este recurso ap\u00f3s desbloquear a criatura que deseja atacar, ela n\u00e3o atacar\u00e1 automaticamente para desbloquear o monstro.",
We:"Farm Location",Ve:"Farm Enemy",Wd:"Login Autom\u00e1tico",Xd:"Voc\u00ea precisa permitir pop-ups da tela do lobby do GameForge. Veja a documenta\u00e7\u00e3o sobre como fazer isso.",Og:"Pausar Bot",Pg:"Pausar Bot em (Minutos)",Te:"Data de Expira\u00e7\u00e3o",Jg:"Comprar apenas comida?",Kg:"Se voc\u00ea habilitar isso, o bot ignorar\u00e1 suas sele\u00e7\u00f5es e comprar\u00e1 comida automaticamente sem inserir nada.",Jb:"M\u00e1ximo de ouro total para gastar",Ib:"M\u00e1ximo de ouro por comida para gastar",
Ig:"O bot verificar\u00e1 \u00f3leos a cada 60 minutos",fi:"Define um temporizador para verificar os tempos de fus\u00e3o.",ci:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver ouro.",ei:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver o item dispon\u00edvel.",Yh:"Define um temporizador para reparar e verificar seus itens.",Xh:"Define um temporizador para verificar o ouro mantido no mercado da guilda.",Th:"Define um temporizador para a op\u00e7\u00e3o de reten\u00e7\u00e3o de ouro em leil\u00e3o.",
Ph:"Define um temporizador para verificar a lista de PvP na arena para atacar.",Uh:"Define um temporizador para verificar a lista de PvP no circo para atacar.",li:"Define um temporizador para treinar suas estat\u00edsticas.",$h:"Define um temporizador para redefinir itens expirados.",ji:"Define um temporizador para armazenar materiais de forja no horreum.",Rh:"Define um temporizador para verificar o leil\u00e3o de gladiadores e mercen\u00e1rios.",bi:"Define um temporizador para buscar itens em leil\u00e3o e loja.",
Vh:"Define o temporizador para enviar doa\u00e7\u00f5es \u00e0 guilda.",bf:"Ouro Movido",oe:"N\u00e3o venda itens da lista de fundi\u00e7\u00e3o e leil\u00e3oo",vh:"Automa\u00e7\u00e3o da Loja",xh:"Configura\u00e7\u00f5es de Busca de Item",wh:"Use esta ferramenta para buscar itens. Basta adicionar os itens \u00e0 lista, especificar a quantidade de pano e iniciar a busca.",yh:"Panos a Usar:",zh:"Quantos panos usar?",fa:"Full Digite o Nome do Item",Wb:"Digite o N\u00edvel do Item",Bh:"Qualidade do Item",
Ah:"Nome do Item Aqui",Ch:"Iniciar Busca",Dh:"Pular e Continuar",Eh:"Parar Busca",Ze:"Comprar o mais barato ou o mais caro?",Dg:"Mais Caro",ee:"Mais Barato",Da:"Selecionar uma op\u00e7\u00e3o",te:"Destacar itens do submundo",$e:"Foco na miss\u00e3o?",cm:"Usar Ruby se n\u00e3o houver pano?",Ya:"Evite atacar as mesmas pessoas para n\u00e3o ser reportado. Ser reportado aumenta as chances de ser banido.",Rl:"Queimar verde?",Vg:"N\u00e3o aceitar miss\u00f5es aleat\u00f3rias se algum filtro for inserido?",
Rc:"Qualidade m\u00e1xima do material a ser usado",$i:"Ativar a busca mercen\u00e1ria",yl:"Clique em `Vender Todos Selecionados` para vender todos os itens. Certifique-se de ter um espa\u00e7o vazio de 2x3 em sua primeira (1) bolsa. Para coletar ouro em massa, filtre ouro e use `Selecionar Todos ou Selecionar`",dk:"\ud83d\udd25 : Adiciona item \u00e0 lista de fundi\u00e7\u00e3o.",Ni:"\ud83d\udd28 : Adiciona item \u00e0 lista de leil\u00e3o.",Jj:"Atualize a loja com pano quando estiver cheia",Gl:"P\u00e1gina:",
Fj:"Parar",Dj:"Vender Esta P\u00e1gina",Aj:"Selecionar Selecionados",zj:"Selecionar Tudo",Gj:"Configura\u00e7\u00f5es de Empacotamento Autom\u00e1tico",Ej:"Enviar Recursos",Bj:"Vender Todos Selecionados",na:"Tipo de Item",pa:"Armas",U:"Escudos",O:"Armaduras",S:"Capacetes",R:"Luvas",P:"Botas",oa:"An\u00e9is",la:"Amuletos",Ka:"Utiliz\u00e1veis (Alimentos)",Pa:"Melhorias",yj:"Potencializadores",Ma:"Receitas",La:"Mercen\u00e1rios",Oa:"Ferramentas de Forja",Na:"Pergaminhos",sd:"Refor\u00e7os",qd:"Itens de Evento",
rd:"Materiais de Forja",Fl:"Ouro",Ja:"Todos",Hl:"Qualidade",qa:"Branco",C:"Verde",B:"Azul",D:"Roxo",J:"Laranja",T:"Vermelho",Cj:"Op\u00e7\u00f5es de Venda",Rj:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo?",gj:"Quantos alimentos comprar/pegar?",Vi:"Normal",Ui:"Intermedi\u00e1rio",Ti:"Dif\u00edcil",Ga:"Padr\u00e3o",Ll:"Reparar Corre\u00e7\u00e3o de Travamento",Nk:"Desative a entrada no Inferno se voc\u00ea quiser desabilitar a Dungeon/Circo/Arena. Se voc\u00ea entrar no Inferno manualmente, ser\u00e1 necess\u00e1rio ativar o Modo Inferno.",
fe:"Escolher traje do submundo",Ji:"Vestir traje do submundo quando dispon\u00edvel?",oi:"Define quantas vezes quer treinar as estat\u00edsticas e suas prioridades. O bot n\u00e3o treinar\u00e1 a menos que defina uma prioridade. Se n\u00e3o houver mais estat\u00edsticas ele continuar\u00e1 com as estat\u00edsticas Defenidas.",ll:"Aventura",Dd:"Derreter",Wl:"Defini\u00e7\u00f5es de Derreter",ak:"Itens Derretidos",Xl:"Adicione um Prefixo ou Sufixo, uma vez encontrado nos pacotes Ser\u00e1 Derretido automaticamente.:",
Vl:"Derreter Item:",ic:"Clique no item que voc\u00ea deseja consertar. Isto utilizar\u00e1 apenas materiais Padr\u00e3o, Verde e Azul. Voc\u00ea precisa ter pelo menos 10.000 ouro para iniciar o reparo. Abra espa\u00e7o 3x3 em sua PRIMEIRA Bolsa do invent\u00e1rio. Caso contr\u00e1rio, ele poder\u00e1 ficar preso! O bot iniciar\u00e1 o reparo assim que o item tiver durabilidade de %0.",dl:"Aplicar apenas no Mercenario.",hl:"O leil\u00e3o s\u00f3 dar\u00e1  o lance quando o mercado estiver no Fim..",
gl:"Certifique-se de que a SEGUNDA PAGINA DO INVENT\u00c1RIO est\u00e1 vazia e tem 10K de ouro. O bot encontrar\u00e1 e colocar\u00e1 o item na segunda pagina e na pr\u00f3xima vez, a p\u00e1gina, atualiza-se Derrentendo o item. A fundi\u00e7\u00e3o acontecer\u00e1 novamente a cada 5-10 minutos. ",jj:"Cura & Buffs",Ml:"Sem ouro suficiente para fundir. Ouro necess\u00e1rio!:",Pl:"Skipping bid: Membro da galian\u00e7a j\u00e1 deu lance no item ",Ol:"Skipping bid: J\u00e1 licitei o item ",advanced:"Avan\u00e7ado",
arena:"Arena",ja:"Ataque autom\u00e1tico",fc:"Evitar Atacar",ha:"Adicionar Jogador",ia:"Adicionar Nome do Jogador (Same Server)",tl:"Parar o Bot se ficar sem comida?",circusTurma:"Circus Turma",Wi:"Dificuldade",dungeon:"Masmorra",Xi:"Configura\u00e7\u00e1o da Masmorra",eventExpedition:"Expedi\u00e7\u00e3o de evento",expedition:"Expedi\u00e7\u00f5es",aj:"Configura\u00e7\u00e1o de Expedi\u00e7\u00f5es",Lj:"Selecionar Monstro",vl:"Maior",ul:"Coloque as curas na primeira p\u00e1gina do invent\u00e1rio",
nj:"No",Lh:"Guardar Ouro",Mh:"Guardar ouro no Leil\u00e3o?",Ub:"Selecionar Horas",rh:"Utilizar Roupas para Renovar Iventario?",Xk:"Selecione itens para serem redefinidos",kh:"Redefinir itens expirados\t",Qb:"Nota: Ao ativar esta op\u00e7\u00e3o, o bot vender\u00e1 os  itens expirados nos Pacotes para o Mercado da Guilda e cancelar\u00e1 para redefinir o tempo de expira\u00e7\u00e3o. Guilda \u00e9 necess\u00e1ria. Certifique-se que tem espa\u00e7o 3x3 vazio no iventario. Nota: Tamb\u00e9m ir\u00e1 coletar as Moedas de Ouro se elas estiverem prestes a expirar!!!",
Qg:"Parar o Bot Aleatoriamente para trabalhar como [Fase de Teste]:",aa:"Ficar com o Ouro: Bot vai guardar esse ouro na bolsa:",pg:"maximo de Ouro: O bot gastar\u00e1 o ouro quando for Superior a",ph:"Ofertas ser\u00e3o aceitas por itens desnecess\u00e1rios",Hd:"Adicionar atraso aleat\u00f3rio",Id:"Podes adicionar um atraso para o bot aqui.",Pb:"Reparar",Ql:"Derreter apenas Azul?",Tl:"Derreter apenas Roxo?",Sl:"Derreter apenas Laranja?",bk:"Derreter apenas itens do inventário?",Ul:"Isto ir\u00e1 ignorar a cor e os itens da lista. A pagina 1 est\u00e1 reservada a repara\u00e7\u00e3o..",
Gh:"Derreter",Qd:"Pesquisa autom\u00e1tica",Fg:"Leil\u00e3o Autom\u00e1tico",Rd:"O uso excessivo do Leil\u00e3o pode resultar em banimento. Esse recurso tamb\u00e9m pode desacelerar o bot, pois ele verifica os leil\u00f5es a cada atualiza\u00e7\u00e3o. As licita\u00e7\u00f5es s\u00e3o feitas a cada 5 minutos, a menos que o leil\u00e3o esteja no estado \u201cmuito curto\u201d. Observe que, se voc\u00ea colocar apenas um item na se\u00e7\u00e3o PREFIX, o bot tentar\u00e1 filtrar pelo nome dos itens para licitar mais rapidamente. Embora voc\u00ea precise desativar a licita\u00e7\u00e3o de alimentos para isso.",
qh:"Pesquisar no leil\u00e3o dos gladiadores",th:"Pesquisar no leil\u00e3o dos mercen\u00e1rios",Zd:"Licitar Comida?",qg:"Lance m\u00e1ximo",$d:"Licitar se o Tempo for inferior a",ae:"Itens licitados",Bk:"Linguagem do Leil\u00e3o",Ck:"De acordo com a atualiza\u00e7\u00e3o 2.5.6, defina o idioma novamente.",Ld:"Poder\u00e1 adicionar itens para procurar no mercado e no leil\u00e3o. Tamb\u00e9m mostrar\u00e1 itens roxos no mercado assim que voc\u00ea adicionar um item \u00e0 lista.",zk:"Utilize o leil\u00e3o com cuidado!",
Ak:"O lance autom\u00e1tico faz muitas solicita\u00e7\u00f5es ao servidor, causando erro de p\u00e1gina em branco e pode causar banimento se for utilizado com frequ\u00eancia!!",hh:"Renovar pontos de evento com Rubis?",ve:"Ativar \u00f3leo autom\u00e1tico",Ek:"Obter os \u00f3leos sagrados automaticamente",Tk:"Velocidade de verifica\u00e7\u00e3o das miss\u00f5es",Ua:"Atacar membros da alian\u00e7a?",Sa:'Adicionar Jogador automaticamente \u00e0 lista de "Ataque" quando X OURO for roubado:',Ta:'Adicione Jogadores automaticamente \u00e0 lista "Evitar Ataque" quando perder:',
Tb:"Placar De Ataques",ac:"Muito Longo",Cb:"Longo",Kb:"M\u00e9dio",Yb:"Curto",bc:"Bastante Curto",pb:"Aceitar Ataques ao Placar:",Rb:"Selecionar Posi\u00e7\u00e3o do ataque",Sb:"O bot ira atacar aleatoriamente jogadores no placar.",rb:"Ataque da Liga",ob:"Ativar ataque da liga:",Nb:"Ataque aleat\u00f3rio",Ob:"Atacar do Menor para o maior",yk:"Bot N\u00e3o atacara menbros da alian\u00e7a.",Se:"Local da Expedi\u00e7\u00e3o:",Sd:"Coletar Bonus automaticamente:",Fh:"Ignorar Chefe",qe:"Local da Masmorra:",
nh:"Recome\u00e7ar se perder?",ff:"Defeni\u00e7\u00f5es do Inferno",gf:" A Personagem entrar\u00e1 no submundo apenas quando o HP for> 90%. Por favor, defina as configura\u00e7\u00f5es de porcentagem de cura na Aba de cura e certifique-se de que a Aba de cura est\u00e1 ativada. Se ao entrar no submundo fizer logout, v\u00e1 para o lobby e ative a caixa de sele\u00e7\u00e3o de login autom\u00e1tico.",df:"Dificuldade Do inferno:",Vd:"Entrar automaticamente no inferno / Inferno Mode",Ei:"Utilizar Mobiliza\u00e7\u00e3o se pontos = 0",
Ii:"Usar Rubies?",ye:"Deixar Inferno se nao tiver pontos?",ri:"O bot tentar\u00e1 usar a Villa Medici primeiro, se voc\u00ea n\u00e3o tiver, ele usar\u00e1 a po\u00e7\u00e3o de cura. N\u00e3o se esque\u00e7a de ativar o bot\u00e3o de Cura!.",zi:"Entrar automaticamente no Inferno ira desabilitar masmorras/arena/Circus.",bl:"Defeni\u00e7oes de cura no Inferno",Hi:"Usar Villa Medici?",Fi:"Usar Po\u00e7\u00e3o de Vida?",dg:"INFO: O bot ir\u00e1 procurar itens no mercado a cada minuto selecionado, o que pode parar o ataque durante a busca.",
ue:"Ativar pesquisa de mercado:",eg:"Intervalo de pesquisa no mercado:",fg:"Sugest\u00e3o 10 minutos.",rf:"Defini\u00e7\u00f5es de itens:",pf:"Nome do item inclui",G:"Pre\u00e7o Maximo",sf:"Estilo do Item",qf:"Raridade do Item",de:"Comprar Soulbound?",uf:"Itens para comprar",tf:"Tentar comprar itens com pacotes se algum deles corresponde ao pre\u00e7o m\u00e1ximo Defenido.:",be:"Itens Comprados:",hj:"Percentagem de Cura",uk:"Comprar comida da Loja?",vk:"Usar cura dos pacotes?",rk:"Usar Cervisia?",
tk:"Usar Ovos?",zl:"Usado por \u00faltimo",location:"Localiza\u00e7\u00e3o",Strength:"For\u00e7a",Dexterity:"Destreza",Agility:"Agilidade",Constitution:"Constitui\u00e7\u00e3o",Charisma:"Carisma",Intelligence:"Inteligencia",mi:"Defini\u00e7\u00f5es de Treino",ni:"Selecione os atributos que deseja treinar. ir\u00e1 treinar assim que houver ouro suficiente.",N:"Proxima A\u00e7\u00e3o",vj:"N\u00e3o",wj:"Normal",Dl:"Oponente",El:"Nivel do Oponente",Ij:"Miss\u00f5es",random:"aleat\u00f3rio",Nl:"Defini\u00e7\u00f5es",
Yl:"Brevemente...",type:"Clique nos \u00edcones para ativar os tipos de miss\u00f5es. Selecione os 3 primeiros se quiser se concentrar em Circus & Arena",em:"Sim",A:"Procura",Cd:"Adicionar item [NOME COMPLETO]",nk:"Guardar recursos da Forja automaticamente",$l:"Enviar",xl:"Intervalo : ",ml:"Ativar lance autom\u00e1tico",nl:"Cobrir aliados",bm:"Tutorial",hc:"MMais jogadores ir\u00e3o por o bot mais lento.",el:"Comece adicionando o nome completo dos itens \u00e0 lista. Uma vez adicionado, a ferramenta exibir\u00e1 os resultados da pesquisa \u00e0 esquerda. Isso tamb\u00e9m auxilia nas pesquisas de leil\u00e3o autom\u00e1tico. Com o lance autom\u00e1tico ativado, a ferramenta far\u00e1 pesquisas peri\u00f3dicas com base no intervalo definido. Se o item for encontrado e voc\u00ea tiver fundos suficientes, ele far\u00e1 um lance automaticamente. Nota: Para pesquisar itens exclusivos em lojas, voc\u00ea deve adicionar pelo menos um item \u00e0 lista de pesquisa...",
pl:"O n\u00famero da criatura pode ser escolhido nos bot\u00f5es acima. O n\u00famero 1 representa a criatura \u00e0 esquerda. Certifique-se de selecionar o local correto, caso contr\u00e1rio o bot poder\u00e1 fazer uma pausa.",Yi:"Escolha a dificuldade da masmorra nas op\u00e7\u00f5es acima. Certifique-se de selecionar o local correto, caso contr\u00e1rio, o bot poder\u00e1 fazer uma pausa.",ij:"Defini\u00e7\u00f5es de cura",Zi:"Armazene o excesso de ouro na Guilda comprando itens do mercado da Guilda. -> Min. Gold",
Al:"Mover tudo",Bl:"Mover o Selecionado",il:"Curar autom\u00e1ticamente",jl:"Percentagem da cura",dm:"Rubi",Lg:"Defini\u00e7\u00f5es Gerais",Mj:"Vender tudo",Nj:"Vender Selecionados",ga:"Armas",da:"Escudos",W:"Armaduras",Z:"Capacetes",Y:"Luvas",ea:"Sapatos",ca:"Aneis",V:"Amuletos",Ci:"Usaveis",Bi:"Atualiza\u00e7\u00f5es",dh:"Receitas",sg:"Mercen\u00e1rios",fh:"Refor\u00e7os",we:"Entrar no Submundo se HP >",bh:"Velocidade de Verifica\u00e7\u00e3o de Miss\u00e3o",Ug:'O padr\u00e3o \u00e9 "3x". Se o bot causar problemas com miss\u00f5es, altere a velocidade da miss\u00e3o de acordo com a velocidade do seu servidor.',
cf:"Aba de Cura",xe:'Se voc\u00ea est\u00e1 renovando pontos manualmente, voc\u00ea precisa clicar no bot\u00e3o acima "Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!',Ik:"Voc\u00ea deve ativar pelo menos uma das seguintes op\u00e7\u00f5es: expedi\u00e7\u00e3o, masmorra, arena ou circo para iniciar a Expedi\u00e7\u00e3o de Evento.",eh:"Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!",mb:"Cobrir Aliados?",$k:"Deixe todas as configura\u00e7\u00f5es desativadas se desejar fundir usando pacotes que cont\u00eam os itens da lista. No entanto, voc\u00ea ainda pode escolher cores.",
Fk:"Personagem(Desligado) / Mercen\u00e1rio(Ligado)",Wk:"Reparar Ambos?",al:"Cron\u00f4metros",Timers:"Insira o n\u00famero de minutos para cada cron\u00f4metro abaixo ou deixe-o padr\u00e3o.",Zg:"Ignorar Filtro de Miss\u00e3o",Yg:"Digite palavras-chave para filtrar miss\u00f5es que voc\u00ea n\u00e3o deseja aceitar",X:"Inserir Palavra-chave",K:"Adicionar",gh:"Remover",ge:"Limpar",Wg:"Aceitar Filtro de Miss\u00e3o",Xg:"Digite palavras-chave para escolher quais miss\u00f5es aceitar. Usar isso ignorar\u00e1 os tipos de miss\u00e3o",
Ea:"Pular Miss\u00f5es de Tempo?",Uk:"Miss\u00f5es",Td:"Auto Traje",Di:"Usar Traje?",Yd:"Batalha B\u00e1sica",pe:"Batalha em Masmorra",Ud:"O bot s\u00f3 usar\u00e1 Dis Pater Normal e M\u00e9dio se seus pontos de expedi\u00e7\u00e3o/masmorra forem 0.",ef:"Configura\u00e7\u00f5es de Cura no Inferno",Kd:"Atacar Chefe Quando Dispon\u00edvel?",sb:"O ataque \u00e0 Liga ser\u00e1 desativado ap\u00f3s 5 ataques malsucedidos.",hf:"\u00d3leos Sagrados",Ag:"Nome do Item",ba:"N\u00edvel M\u00edn. do Item",Ba:"Qualidade M\u00edn. do Item",
Jd:"Aplicar/Reiniciar Temporizador",lf:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo",Ki:"Sim",Hg:"N\u00e3o",Qa:"Adicionar Prefixo",Ra:"Adicionar Sufixo",Za:"Limpar Hist\u00f3rico",Hh:"Lista de Ignora\u00e7\u00e3o de Fundi\u00e7\u00e3o",Mb:"Prefixo",Zb:"Sufixo",mh:"Redefinir Itens Expirados",Ih:"Fundir Aleatoriamente de Pacotes?",Jh:"Aba de Fundição",qb:"Extras",Od:"Leil\u00e3o",ig:"Mercado",$b:"Temporizadores",hi:"Fundi\u00e7\u00e3o",gi:"Fundi\u00e7\u00e3o se n\u00e3o houver ouro suficiente",
di:"Fundir se n\u00e3o houver item",Fa:"Reparo",Wh:"Manter Ouro no Mercado da Guilda",Sh:"Manter Ouro no Leil\u00e3o",ki:"Treinamento",Zh:"Redefinir Expirados",ii:"Loja de Forja",Qh:"Verifica\u00e7\u00e3o de Leil\u00e3o",ai:"Pesquisa",v:"Habilitar",Cg:"Ouro M\u00ednimo",nb:"Doar Ouro para a Guilda",ke:"Isso doar\u00e1 a cada 5 minutos. Voc\u00ea pode alterar o intervalo na guia de temporizadores",jf:"Quanto deseja doar?",le:"Doar quando tiver mais que >",wf:"Menos que <",jh:"Redefinir Expirados e Outras Configura\u00e7\u00f5es",
lh:"Redefinir em:",Ok:"Mantenha Ctrl (Cmd no Mac) pressionado para selecionar v\u00e1rios itens",mf:"Importar/Exportar Configura\u00e7\u00f5es",Ue:"Exportar Configura\u00e7\u00f5es",nf:"Importar Configura\u00e7\u00f5es",tg:"Mensagem para Todos os Jogadores",ug:"[Requer Chave Ultra Premium, mensagem no Discord para obter a chave.]",vg:"Digite a mensagem a ser enviada",ie:"Para scripts personalizados, entre em contato conosco no Discord",xg:"Enviar",yg:"Mostrar Jogadores",wg:"Selecionar Todos",zg:"Desmarcar Todos",
vf:"Certifique-se de que seu invent\u00e1rio tenha espa\u00e7o suficiente. O tempo de recarga \u00e9 de 2 minutos.",mg:"Vender Comida",Gb:"Mudar para Comida"},Jh={cg:"B\u0142\u0105d rynkowy! Prosz\u0119 ponownie doda\u0107 elementy i spr\u00f3bowa\u0107.",Lb:"Brak wystarczaj\u0105cej ilo\u015bci miejsca w torbie na jedzenie.",ck:"Roztopi\u0107 najpierw wy\u017csze kolory?",cc:"Atakowa\u0107 tylko list\u0119 graczy?",dc:"Kiedy ta opcja jest w\u0142\u0105czona, bot b\u0119dzie atakowa\u0142 tylko graczy z listy graczy. Je\u015bli ta opcja nie jest w\u0142\u0105czona, bot b\u0119dzie atakowa\u0142 losowych graczy.",
Kk:"Twoje ustawienia ekspedycji s\u0105 nieprawid\u0142owe lub wyst\u0105pi\u0142y nieoczekiwane dane strony!",Lk:"Twoje ustawienie ekspedycji jest nieprawid\u0142owe! Ustawi\u0142e\u015b wy\u0142\u0105czonego potwora, co jest b\u0142\u0119dne.",Yk:"Zresetowa\u0107 tylko wszystkie przedmioty z podziemi o wybranym kolorze?",Ca:"Priorytet",Vb:"Ustaw Priorytet",Rg:"Punkty",Kh:"Stat",Si:"Zbieranie Z\u0142ota",Oj:"Sprzedaj przedmioty z podziemia?",uj:"Bot b\u0119dzie szuka\u0142 gniazda w ka\u017cdej akcji, nie tylko na wyprawach.",
sj:"Typ wyszukiwania gniazda",qj:"Nic nie r\u00f3b",rj:"Szybkie wyszukiwanie",tj:"Dok\u0142adne wyszukiwanie",Kl:"After expedition points are consumed, travel to Germania to consume Dungeon points",xk:"Kliknij tutaj, je\u015bli naprawa si\u0119 zacina",Mk:"Gdy HP spadnie poni\u017cej, u\u017cyj leczenia",Ng:"Cz\u0119\u015bciowa Naprawa",af:"Pe\u0142na Naprawa",Mg:"Cz\u0119\u015bciowa lub Pe\u0142na Naprawa",se:"W\u0142\u0105cz Limit",kj:"Limit",lj:"Je\u015bli chcesz ograniczy\u0107 liczb\u0119 atak\u00f3w na przeciwnika, w\u0142\u0105cz t\u0119 opcj\u0119 i ustaw limit. Bot b\u0119dzie kontynuowa\u0142 atakowanie reszty przeciwnik\u00f3w po zako\u0144czeniu atak\u00f3w na wybranego potwora.",
ne:"Nie wchod\u017a do podziemia w kostiumie podziemia",me:"Je\u015bli nie chcesz wchodzi\u0107 do podziemia, maj\u0105c na sobie kostium podziemia, w\u0142\u0105cz t\u0119 opcj\u0119",yi:"Podziemia",pi:"Wzmocnienia Podziemi",si:"U\u017cy\u0107 mocy bog\u00f3w po wej\u015bciu do podziemi?",ti:"Wybierz bog\u00f3w, kt\u00f3rych moce chcesz wykorzysta\u0107:",ui:"U\u017cy\u0107 Wzmocnienia Broni na broni?",vi:"U\u017cy\u0107 Wzmocnienia Zbroi na nast\u0119puj\u0105cym ekwipunku?",Hk:"Czas odnowienia wynosi 30 minut. Je\u015bli nie masz kostiumu, bot zresetuje czas odnowienia do 0.",
Zk:"Wybierz Kolory",$a:"Kowad\u0142o Wulkana",eb:"Ziemna Tarcza Feronii",fb:"P\u0142ynna Moc Neptuna",gb:"Powietrzna Wolno\u015b\u0107 Aelousa",hb:"Zab\u00f3jcza Mg\u0142a Plutona",ib:"Oddech \u017bycia Junony",jb:"Pancerz \u0141usek G\u00f3r Gniewu",kb:"Orle Oczy",lb:"Zimowy Str\u00f3j Saturna",ab:"Bycza Zbroja Bubony",bb:"Szaty Z\u0142odzieja Merceriusa",cb:"Szata \u015awiat\u0142a Ra",lg:"Paczki",gg:"Inwentarz",M:"Min. Cena",L:"Ile",Fb:"Sprzedaj Przedmioty",Eb:"Szukaj w",hg:"Kolor Materia\u0142u",
Db:"Kolor Przedmiotu",og:"Magazyn",Aa:"Prze\u0142\u0105cz na Materia\u0142y",Hb:"Prze\u0142\u0105cz na Przedmioty",ng:"Sprzedaj Materia\u0142y",xa:"Prosz\u0119 wprowadzi\u0107 poprawn\u0105 nazw\u0119 przedmiotu, zakres cen oraz ilo\u015b\u0107.",ya:"Nie znaleziono odpowiednich przedmiot\u00f3w w wybranych miejscach wyszukiwania.",za:"Wszystkie przedmioty zosta\u0142y pomy\u015blnie wystawione!",Sk:"Wszystkie materia\u0142y zosta\u0142y pomy\u015blnie wystawione!",jg:"Je\u015bli chcesz sprzeda\u0107 przedmioty za sta\u0142\u0105 cen\u0119, mo\u017cesz wpisa\u0107 t\u0119 sam\u0105 warto\u015b\u0107 dla minimalnej i maksymalnej ceny.",
kg:"Ta funkcja jest nadal eksperymentalna, u\u017cywaj ostro\u017cnie. Je\u015bli nie ustawisz sta\u0142ej ceny, przedmioty b\u0119d\u0105 wy\u015bwietlane losowo mi\u0119dzy minimaln\u0105 a maksymaln\u0105 cen\u0105, kt\u00f3r\u0105 wpiszesz.",Dk:"Ustawia maksymaln\u0105 ilo\u015b\u0107 z\u0142ota, kt\u00f3r\u0105 bot wyda w jednym cyklu.",Va:"Bot zacznie licytowa\u0107 wszelkie przedmioty \u017cywno\u015bciowe, je\u015bli opcja jest w\u0142\u0105czona. Nie musisz w\u0142\u0105cza\u0107 prze\u0142\u0105cznik\u00f3w gladiatora/najemnika.",
Md:"Bot nie b\u0119dzie licytowa\u0142 ofert sojusznik\u00f3w.",Nd:"Ignoruj kombinacj\u0119 Prefixu/Sufiksu podczas szukania przedmiotu na aukcji.",Vj:"Wybierz typy przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Wj:"Wybierz kolory, kt\u00f3re chcesz przetopi\u0107.",Xj:"Wybierz poziom przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Yj:"Wybierz m\u0142ot, kt\u00f3rego chcesz u\u017cy\u0107.",Zj:"Zwr\u00f3\u0107 uwag\u0119, \u017ce zielone i czerwone k\u00f3\u0142ko obok pierwszego pola s\u0142u\u017cy do w\u0142\u0105czania/wy\u0142\u0105czania regu\u0142y.",
$j:"Je\u015bli chcesz przetapia\u0107 losowo jakiekolwiek kolory lub typy, mo\u017cesz w\u0142\u0105czy\u0107 `Czy przetapia\u0107 losowo, je\u015bli \u017cadne warunki nie s\u0105 spe\u0142nione? (Ostatnia w\u0142\u0105czona opcja w filmie instrukta\u017cowym)",Kj:"Napraw przed przetopieniem",Oe:"Wybierz Potwora",Ce:"U\u017cy\u0107 Klepsydry/Rubinu?",Jk:"U\u017cy\u0107 Rubinu?",Fe:"U\u017cy\u0107 Mobilizacji?",Ee:"U\u017cy\u0107 Mikstury \u017bycia?",Be:"Procent Leczenia (%)",Me:"Liczba Atak\u00f3w",
De:"Interwa\u0142 Ataku (w sekundach)",ze:"Wykonane Ataki",Ae:"Pozosta\u0142e Klepsydry",Ke:"Uwaga: U\u017cywa mikstur \u017cycia do leczenia, nie jedzenia.",Le:"Uwaga: Je\u015bli ataki zatrzymaj\u0105 si\u0119 przedwcze\u015bnie, spr\u00f3buj 'Zresetuj Ataki'.",Pe:"Rozpocznij",Ne:"Resetuj",Qe:"Zatrzymaj",Re:"Ustawienia Ekspedycji (Kliknij, aby zminimalizowa\u0107)",Ge:"Potw\u00f3r 1",He:"Potw\u00f3r 2",Ie:"Potw\u00f3r 3",Je:"Potw\u00f3r 4",Vk:"Napraw przed przetopieniem",Qi:"Ta opcja u\u017cyje cervisia, gdy twoja subskrypcja premium wyga\u015bnie.",
xj:"Ta opcja w\u0142\u0105cza i wybiera oleje z nagr\u00f3d boskich. Mo\u017ce u\u017cywa\u0107 olej\u00f3w numer 1 i 3 na postaci, ale numer 2 b\u0119dzie tylko zbierany do paczek.",Oi:"Ta opcja u\u017cyje buff\u00f3w o ustawionym przez ciebie czasie. Znajdzie buffy w paczkach i zastosuje je na postaci.",mj:"Ta opcja wprowadzi ci\u0119 do podziemia. Nie zapomnij w\u0142\u0105czy\u0107 Automatycznego Logowania z zak\u0142adki Dodatki, inaczej mo\u017cesz zosta\u0107 wylogowany przy wej\u015bciu do podziemia [B\u0142\u0105d Gry]",
ec:"Ta opcja b\u0119dzie atakowa\u0107 tylko list\u0119 aren/cyrk\u00f3w. Je\u017celi nie uda si\u0119 jej wykona\u0107, bot pominie dan\u0105 aren\u0119.",Hj:"Ta opcja jest tylko dla licencji premium. Symuluje atak przed zaatakowaniem u\u017cytkownika dla 75% szansy na wygran\u0105.",Pd:"Nie musisz w\u0142\u0105cza\u0107 g\u0142\u00f3wnego prze\u0142\u0105cznika aukcji, aby w\u0142\u0105czy\u0107 t\u0119 opcj\u0119.",qk:"Ta opcja od\u015bwie\u017cy stron\u0119 co sekund\u0119, gdy aukcja jest w stanie -Bardzo Kr\u00f3tki-, aby nieustannie licytowa\u0107 i wygra\u0107 aukcj\u0119.",
Tj:"Je\u015bli \u017caden z warunk\u00f3w wytopu nie zostanie spe\u0142niony, b\u0119dzie wybiera\u0107 losowo. Upewnij si\u0119, \u017ce wybra\u0142e\u015b typ i kolor przedmiotu.",Uj:"Ta opcja b\u0119dzie tylko wytopi\u0107 przedmioty z inwentarza. Zignoruje przedmioty w paczkach.",Wa:"Przedmioty na Aukcji",rg:"Przedmioty Najemnika",Xb:"Przedmioty w Sklepie",Ai:"Unikalne Przedmioty",Pj:"Ustaw t\u0142o na czarne [Zwi\u0119ksza wydajno\u015b\u0107]",Qj:"Przenie\u015b przyciski GLDbot do lewego dolnego rogu?",
Ri:"Atakuj Cyrk Bez Leczenia",pk:"Czy pobra\u0107 z\u0142oto z paczek, je\u015bli to konieczne?",am:"Z\u0142oto zosta\u0142o pobrane z paczek do treningu",Gd:"Nie znaleziono z\u0142ota w paczkach do treningu",lk:"Naprawione Przedmioty",ek:"Ataki na Arenie",gk:"Ataki w Cyrku",Ed:"Zresetowane Przedmioty",jk:"Ataki na Wyprawach",ik:"Ataki w Lochach",mk:"Ataki w Podziemiach",fk:"Pieni\u0105dze Zarobione na Arenie",hk:"Pieni\u0105dze Zarobione w Cyrku",Zl:"Przedmioty Przetopione",kk:"Przetopione Z\u0142oto",
dj:"Bitwa Gildii",fj:"Ustawienia Gildii",rl:"B\u0119dzie atakowa\u0107 gildie losowo.",ej:"Nazwa Gildii",Pi:"Zresetuj Statystyki",cj:"Atakuj losowo?",Cl:"GLDbot: U\u017cyj kostek, aby od\u015bwie\u017cy\u0107 tajemnicze pude\u0142ko i znale\u017a\u0107 cenne przedmioty przed ich otwarciem (itp. Kostiumy). Kliknij \u201eStart\u201d otw\u00f3rz skrzynie.",Pc:"Drewno",Fc:"Mied\u017a",Jc:"\u017belazo",Lc:"Sk\u00f3ra",Qc:"We\u0142niana nitka",Gc:"Bawe\u0142na",Ic:"Konopie",Hc:"Kawa\u0142ek tkaniny",Mc:"Kawa\u0142ek w\u0142\u00f3kna lnianego",
Kc:"\u0141ata z juty",Oc:"Pasek aksamitu",Nc:"Jedwabna nitka",Yc:"Futro",Sc:"Od\u0142amek ko\u015bci",ad:"\u0141uska",Vc:"Pazur",Xc:"Kie\u0142",Wc:"Smocza \u0142uska",Tc:"R\u00f3g byka",$c:"Gruczo\u0142 jadowy",Uc:"Kawa\u0142ek futra Cerbera",Zc:"\u0141uska Hydry",bd:"Pi\u00f3ro Sfinksa",cd:"Sk\u00f3ra Tyfona",Cc:"Lazuryt",wc:"Ametyst",vc:"Bursztyn",xc:"Akwamaryn",Dc:"Szafir",Ac:"Granat",zc:"Szmaragd",yc:"Diament",Bc:"Jaspis",Ec:"Sugilit",qc:"Jad skorpiona",tc:"Eliksir wytrwa\u0142o\u015bci",mc:"Antidotum",
lc:"Adrenalina",sc:"Eliksir o\u015bwiecenia",pc:"Nap\u00f3j postrzegania",nc:"Esencja refleksu",oc:"Fiolka Charyzmy",uc:"Woda zapomnienia",rc:"Esencja duszy",Bd:"Wodna piecz\u0119\u0107",vd:"Runa ochrony",td:"Ziemny grawerunek",Ad:"\u015awi\u0119ty totem",zd:"Talizman mocy",xd:"Kamie\u0144 szcz\u0119\u015bcia",ud:"Krzemie\u0144",yd:"Runa wichury",wd:"Runa cienia",gd:"Kryszta\u0142",fd:"Br\u0105z",ld:"Obsydian",od:"Srebro",pd:"Siarka",jd:"Ruda z\u0142ota",nd:"Kwarc",md:"Platina",ed:"Almandyn",hd:"Kupryt",
kd:"Piekielny kamie\u0144",Li:"Atakuj losowo?",Mi:'Wy\u0142\u0105cz r\u00f3wnie\u017c ustawienie "Sortuj graczy na arenie wed\u0142ug poziomu" w crazy-addon.',$g:"Akceptuj tylko misje na podstawie typu boga.",Xa:"Automatyczny Buff",ce:"U\u017cywaj tylko w piekle?",Gg:"Nowa Zasada",Eg:"Nazwa Zawiera",isUnderworldItem:"Czy to przedmiot z Podziemi",kf:"Ignoruj Materia\u0142y",wk:"U\u017cyj modlitwy",Gi:"U\u017cyj ofiary",sk:"U\u017cyj tkaniny, aby wej\u015b\u0107 do podziemia",xi:"Czy w podziemiach akceptowa\u0107 tylko zadania zwi\u0105zane z podziemiami?",
wi:"Je\u015bli w\u0142\u0105czone, musisz wprowadzi\u0107 nazwy przedmiot\u00f3w z podziemi. Je\u015bli bot znajdzie te przedmioty w podziemiach, zaakceptuje zadanie.",cl:"Przedmiot zadania z podziemi",ol:"Wprowad\u017a nazw\u0119 materia\u0142u",Gk:"Bot uwielbia ko\u015bci! Pomagaj\u0105 znale\u017a\u0107 ubrania w skrzyniach. Ale je\u015bli nie ma ko\u015bci, bot i tak otwiera skrzynie, licz\u0105c na fajne ciuchy (ale mo\u017ce ich nie znale\u017a\u0107!)",Sj:"Czy chcesz przetopi\u0107 skrzynki?",
re:"W\u0142\u0105cz automatyczne ataki na arenie?",Sg:"Priorytetowa lista aren?",Tg:"Priorytetowa lista cyrk\u00f3w?",je:"Wy\u0142\u0105cz menu dziennika",oh:"Minimalna warto\u015b\u0107 nagrody z\u0142ota",ah:"Je\u015bli w\u0142\u0105czone, Fokus na zadaniach b\u0119dzie pod\u0105\u017ca\u0142 najkr\u00f3tsz\u0105 drog\u0105 do uko\u0144czenia lochu.",Nh:"Automatyczne rzucanie kostk\u0105?",Oh:"U\u017cywaj rzucania kostk\u0105 ostro\u017cnie, b\u0119dzie ono nadal u\u017cywa\u0107 pierwszej kostki, dop\u00f3ki nie wy\u0142\u0105czysz opcji.",
uh:"Post\u0119p w wyszukiwaniu",ih:"Czas odnowienia naprawy domy\u015blnie wynosi 10 minut.",Bg:"Minimalny stan",he:"Obecny przedmiot na warsztacie [Wyczy\u015b\u0107, je\u015bli bot nagle zostanie zatrzymany]",Gf:"Pomy\u015blnie przechowywano zasoby do horreum.",Cf:"Sprawdzanie rynku na przedmioty...",Ab:"Przedmiot przeniesiony na warsztat.",Tf:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony i za\u0142o\u017cony.",Uf:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony.",Qk:"Naprawa nie powiod\u0142a si\u0119. Strona zostanie od\u015bwie\u017cona.",
Qf:"Podnoszenie materia\u0142\u00f3w...",bg:"Oczekiwanie na napraw\u0119...",Sf:"Naprawa rozpocz\u0119\u0142a si\u0119 dla .",wa:"Naprawa: Przenoszenie przedmiotu z inwentarza do torby",Rf:"Naprawa: Przenoszenie przedmiotu z warsztatu do paczki.",ua:"Nie uda\u0142o si\u0119 znale\u017a\u0107 wystarczaj\u0105cej ilo\u015bci materia\u0142\u00f3w. Wy\u0142\u0105czanie slotu naprawy ",Nf:"Szukanie przedmiot\u00f3w do kupienia w celu ukrycia z\u0142ota na Aukcji...",zf:"Sprawdzanie wygas\u0142ych przedmiot\u00f3w w paczkach...",
Af:"Przedmiot zosta\u0142 pomy\u015blnie zresetowany.",Bf:"Brak pustej przestrzeni lub z\u0142ota do zresetowania.",Hf:"Upewnij si\u0119, \u017ce masz prawa do sprzeda\u017cy na rynku gildii!",ub:"Brak wystarczaj\u0105cej ilo\u015bci z\u0142ota/lub brak przedmiotu do kupienia. Oczekiwanie 30 sekund na od\u015bwie\u017cenie.",wb:"Sklep zosta\u0142 od\u015bwie\u017cony.",xb:"B\u0142\u0105d podczas leczenia.",Kf:"Brak Rubina lub Materia\u0142u, wy\u0142\u0105czanie opcji.",Pk:"Brak przedmiotu do leczenia w paczkach.",
yb:"Nie znaleziono odpowiednich przedmiot\u00f3w",Lf:"\u017bywno\u015b\u0107 zosta\u0142a wybrana. Zako\u0144czenie procesu.",Mf:"Wybrano przynajmniej jedzenie. Proces zako\u0144czony.",zb:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",If:"Pobieranie jedzenia z paczek.",Jf:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",vb:"Brak wi\u0119cej przedmiot\u00f3w do leczenia. Oczekiwanie 30 sekund.",tb:"Odzyskano punkty \u017cycia.",va:"Nie ma nic do roboty, wi\u0119c id\u0119 si\u0119 pomodli\u0107!",
Yf:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie i Vill\u0119 Medici.",Zf:"Oczekiwanie na Vill\u0119 Medici, od\u015bwie\u017canie za 60 sekund.",$f:"Opuszczono za\u015bwiaty.",ag:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie.",Of:"Sprawdzanie olejk\u00f3w bo\u017cych...",Pf:"Olejki bo\u017ce zosta\u0142y podniesione.",sa:"Pomy\u015blnie zaatakowano gracza na ARENIE: ",ta:"Pomy\u015blnie zaatakowano gracza w CIRKUSIE: ",xf:"Sprawdzanie aukcji! Prosz\u0119 czeka\u0107...",
yf:"Licytacja przedmiot\u00f3w. Prosz\u0119 czeka\u0107...",Vf:"Automatycznie przetopiony przedmiot: ",Wf:"Przetapiany przedmiot: ",Bb:"Nie ma wystarczaj\u0105cej ilo\u015bci z\u0142ota do przetopienia. Wymagane z\u0142oto: ",Xf:"PRZETAP: Szukanie przedmiot\u00f3w do przetopienia...",Rk:"Szukanie przedmiot\u00f3w do przetopienia...",Df:"Sprawdzanie dost\u0119pno\u015bci kostium\u00f3w...",Ff:"Wys\u0142ano datek: ",Ef:"Rzucanie kostk\u0105...",Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",
Ye:"Uwaga: w\u0142\u0105cz t\u0119 funkcj\u0119 po odblokowaniu stworzenia, kt\u00f3re chcesz zaatakowa\u0107, nie b\u0119dzie ono automatycznie atakowa\u0107, aby odblokowa\u0107 potwora.",Ve:"Farm Enemy",Wd:"Automatyczne Logowanie",Xd:"Musisz zezwoli\u0107 na wyskakuj\u0105ce okienka z ekranu lobby GameForge. Zobacz dokumentacj\u0119, jak to zrobi\u0107.",Og:"Wstrzymaj Bota",Pg:"Wstrzymaj Bota na (Minuty)",Te:"Data Wyga\u015bni\u0119cia",Jg:"Tylko kupowa\u0107 jedzenie?",Kg:"Je\u015bli to w\u0142\u0105czysz, zignoruje twoje wybory i b\u0119dzie automatycznie kupowa\u0107 jedzenie, nie wprowadzaj\u0105c niczego.",
Jb:"Maksymalna \u0142\u0105czna ilo\u015b\u0107 z\u0142ota do wydania",Ib:"Maksymalna ilo\u015b\u0107 z\u0142ota na jedzenie do wydania",Ig:"Bot b\u0119dzie sprawdza\u0107 oleje co 60 minut",fi:"Ustawia timer do sprawdzania czas\u00f3w topienia.",ci:"Ustawia timer do sprawdzania topienia, gdy nie masz z\u0142ota.",ei:"Ustawia timer do sprawdzania topienia, gdy nie masz dost\u0119pnego przedmiotu.",Yh:"Ustawia timer do naprawy i sprawdzania twoich przedmiot\u00f3w.",Xh:"Ustawia timer do sprawdzania ilo\u015bci z\u0142ota w gildijnym rynku.",
Th:"Ustawia timer dla opcji zatrzymania z\u0142ota na aukcji.",Ph:"Ustawia timer do sprawdzania listy PvP na arenie do ataku.",Uh:"Ustawia timer do sprawdzania listy PvP w cyrku do ataku.",li:"Ustawia timer treningowy do trenowania statystyk.",$h:"Ustawia timer do resetowania wygas\u0142ych przedmiot\u00f3w.",ji:"Ustawia timer do przechowywania materia\u0142\u00f3w do kucia w horreum.",Rh:"Ustawia timer do sprawdzania aukcji gladiator\u00f3w i najemnik\u00f3w.",bi:"Ustawia timer do wyszukiwania przedmiot\u00f3w na aukcji i w sklepie.",
Vh:"Ustawia timer do wysy\u0142ania darowizn do gildii.",bf:"Z\u0142oto Przeniesione",oe:"Nie sprzedawaj przedmiot\u00f3w z listy hutniczej i aukcyjnej",vh:"Automatyzacja Sklepu",xh:"Ustawienia Wyszukiwania Przedmiotu",wh:"U\u017cyj tego narz\u0119dzia do wyszukiwania przedmiot\u00f3w. Po prostu dodaj przedmioty do listy, okre\u015bl ilo\u015b\u0107 tkaniny i rozpocznij wyszukiwanie.",yh:"Ilo\u015b\u0107 Tkaniny do U\u017cycia:",zh:"Ile tkaniny u\u017cy\u0107?",fa:"Full Wprowad\u017a Nazw\u0119 Przedmiotu",
Wb:"Wprowad\u017a Poziom Przedmiotu",Bh:"Jako\u015b\u0107 Przedmiotu",Ah:"Wprowad\u017a Nazw\u0119 Przedmiotu Tutaj",Ch:"Rozpocznij Wyszukiwanie",Dh:"Pomi\u0144 i Kontynuuj",Eh:"Zatrzymaj Wyszukiwanie",Ze:"Kupi\u0107 najta\u0144sze czy najdro\u017csze?",Dg:"Najdro\u017csze",ee:"Najta\u0144sze",Da:"Wybierz Opcj\u0119",te:"Pod\u015bwietl przedmioty z Podziemia",$e:"Skoncentruj si\u0119 na zadaniu?",cm:"U\u017cyj rubinu, je\u015bli nie ma tkaniny?",Ya:"Unikaj atakowania tych samych os\u00f3b, aby unikn\u0105\u0107 zg\u0142osze\u0144. Zg\u0142oszenia zwi\u0119kszaj\u0105 szans\u0119 na zablokowanie konta.",
Rl:"Roztopi\u0107 zielone?",Vg:"Nie akceptuj losowych zada\u0144, je\u015bli wprowadzono jakiekolwiek filtry?",Rc:"Maksymalna jako\u015b\u0107 materia\u0142u do u\u017cycia",$i:"W\u0142\u0105czy\u0107 wyszukiwanie najemnik\u00f3w",yl:"Kliknij \u201eSprzedaj Wszystkie Wybrane\u201d, aby sprzeda\u0107 wszystkie przedmioty. Upewnij si\u0119, \u017ce masz 2x3 puste miejsce w swojej pierwszej (1) torbie. Aby zbiera\u0107 z\u0142oto masowo, u\u017cyj filtra na z\u0142oto i opcji \u201eWybierz Wybrane lub Wybierz Wszystkie\u201d.",
dk:"\ud83d\udd25 : Dodaje przedmiot do listy przetapiania.",Ni:"\ud83d\udd28 : Dodaje przedmiot do listy aukcyjnej.",Jj:"Od\u015bwie\u017c sklep tkanin\u0105, gdy jest pe\u0142ny",Gl:"Strona:",Fj:"Zatrzymaj",Dj:"Sprzedaj T\u0119 Stron\u0119",Aj:"Wybierz Wybrane",zj:"Wybierz Wszystko",Gj:"Ustawienia Automatycznego Pakowania",Ej:"Wy\u015blij Zasoby",Bj:"Sprzedaj Wszystkie Wybrane",na:"Rodzaj Przedmiotu",pa:"Bronie",U:"Tarcze",O:"Zbroje",S:"He\u0142my",R:"R\u0119kawice",P:"Buty",oa:"Pier\u015bcienie",
la:"Amulety",Ka:"U\u017cytkowe (\u017bywno\u015b\u0107)",Pa:"Ulepszenia",yj:"Wzmacniacze",Ma:"Receptury",La:"Najemnicy",Oa:"Narz\u0119dzia Kowalskie",Na:"Zwoje",sd:"Wzmocnienia",qd:"Przedmioty Eventowe",rd:"Materia\u0142y Kowalskie",Fl:"Z\u0142oto",Ja:"Wszystko",Hl:"Jako\u015b\u0107",qa:"Bia\u0142y",C:"Zielony",B:"Niebieski",D:"Fioletowy",J:"Pomara\u0144czowy",T:"Czerwony",Cj:"Opcje Sprzeda\u017cy",Rj:"Ignorowa\u0107 Kombinacje Przedrostk\u00f3w/Sufiks\u00f3w?",gj:"Ile jedzenia kupi\u0107/wybiera\u0107?",
Vi:"Normalny",Ui:"\u015aredni",Ti:"Trudny",Ga:"Standardowy",Ll:"Naprawa Utkni\u0119\u0107",Nk:"Wy\u0142\u0105cz Wej\u015bcie do Piek\u0142a, je\u015bli chcesz wy\u0142\u0105czy\u0107 Lochy/Cyrk/Aren\u0119. Je\u015bli wszed\u0142e\u015b do Piek\u0142a r\u0119cznie, musisz w\u0142\u0105czy\u0107 Tryb Piek\u0142a.",oi:"Okre\u015bl, ile razy chcesz przeprowadzi\u0107 szkolenia dla statystyk oraz ich priorytety. Bot nie b\u0119dzie przeprowadza\u0142 szkole\u0144, dop\u00f3ki nie zostanie ustalony priorytet. Je\u015bli priorytet zosta\u0142 ustawiony, ale nie ma ju\u017c wi\u0119cej statystyk do szkolenia, bot kontynuowa\u0107 b\u0119dzie z priorytetowym szkoleniem.",
ll:"Quest",fe:"Wybierz kostium z Za\u015bwiat\u00f3w",Ji:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",Dd:"Przetapianie",Wl:"Ustawienia Topienia",ak:"Topione Przedmioty",Xl:"Dodaj Prefiks lub Sufiks, gdy bot znajdzie go w paczkach, automatycznie przeprowadzi przetapianie.:",Vl:"Topiony Przedmiot:",ic:"Kliknij na przedmiot, kt\u00f3ry chcesz naprawi\u0107. Ten system naprawi twoje dwie postacie, g\u0142\u00f3wn\u0105 oraz pierwsz\u0105 posta\u0107 cyrku. Musisz mie\u0107 co najmniej 10000 z\u0142ota, aby naprawa mog\u0142a si\u0119 rozpocz\u0105\u0107. Je\u015bli utkn\u0105\u0142 na jednym przedmiocie, oznacza to, \u017ce nie masz materia\u0142u do naprawy. Spr\u00f3buj r\u00f3wnie\u017c zrobi\u0107 troch\u0119 miejsca w swoim inwentarzu. Bot rozpocznie napraw\u0119, gdy trwa\u0142o\u015b\u0107 przedmiotu wynosi 0%.",
dl:"Zastosuj tylko do Najemnik\u00f3w",hl:"Licytacja b\u0119dzie licytowa\u0107 tylko wtedy, gdy rynek zbli\u017cy si\u0119 do ko\u0144ca.",gl:"Upewnij si\u0119, \u017ce DRUGA KARTA INWENTARZA jest pusta i masz 10 000 z\u0142ota. Bot znajdzie i umie\u015bci przedmiot na drugiej karcie, a nast\u0119pnie, gdy strona zostanie od\u015bwie\u017cona, przeprowadzi przetapianie przedmiotu. przetapianie b\u0119dzie ponownie sprawdzane co 5-10 minut.",jj:"Leczenie & Buffs",Ml:"Za ma\u0142o z\u0142ota na przetapianie. Wymagane Z\u0142oto:",
Pl:"Pomijanie licytacji: Cz\u0142onek gildii ju\u017c licytowa\u0142 przedmiot ",Ol:"Pomijanie licytacji: Ju\u017c licytowa\u0142e\u015b przedmiot ",advanced:"Zaawansowane",arena:"Arena",ja:"Auto Atak",fc:"Unikaj Ataku",ha:"Dodaj Gracza",ia:"Wpisz Nazw\u0119 Gracza (Same Server)",tl:"Zatrzymaj Bota, je\u015bli brakuje jedzenia?",circusTurma:"Cyrk Turma",Wi:"Trudno\u015b\u0107",dungeon:"Loch",Xi:"Ustawienia Lochu",eventExpedition:"Ekspedycja Wydarzenia",expedition:"Wyprawa",aj:"Ustawienia Wyprawy",
Lj:"Wybierz Potwora",vl:"Najwy\u017cszy",ul:"Umie\u015b\u0107 swoje przedmioty uzdrawiaj\u0105ce na pierwszej stronie swojego inwentarza",nj:"W",Lh:"Przechowuj Z\u0142oto",Mh:"Przechowuj Z\u0142oto w Licytacji?",Ub:"Wybierz Godzin\u0119",rh:"U\u017cyj Roboczych Ubran, aby odnowi\u0107 Sklep?",Xk:"Wybierz Przedmioty do Zresetowania",kh:"Zresetuj Wygas\u0142e Przedmioty",Qb:"Uwaga: W\u0142\u0105czaj\u0105c t\u0119 opcj\u0119, bot b\u0119dzie sprzedawa\u0142 nadchodz\u0105ce wygas\u0142e przedmioty z Paczek na Rynek Gildii, a nast\u0119pnie anuluje, aby zresetowa\u0107 czas wyga\u015bni\u0119cia. Wymagana jest gildia. Upewnij si\u0119, \u017ce masz puste miejsce 3x3 w swoich torbach.",
Qg:"Losowe Zatrzymywanie Bota [Faza Testowa]:",aa:"Zachowaj Z\u0142oto: Bot b\u0119dzie trzyma\u0142 to z\u0142oto w torbie:",pg:"Max Gold: Bot b\u0119dzie wydawa\u0142, gdy z\u0142oto b\u0119dzie wi\u0119ksze ni\u017c",ph:"Bot b\u0119dzie sk\u0142ada\u0142 oferty na losowe przedmioty.",Hd:"Dodaj Losowe Op\u00f3\u017anienie",Id:"Mo\u017cesz tutaj doda\u0107 op\u00f3\u017anienie do bota.",Pb:"Naprawa",Ql:"Top Tylko Niebieskie?",Tl:"Top Tylko Fioletowe?",Sl:"Top Tylko Pomara\u0144czowe?",bk:"Top Wszystko na 2. karcie?",
Ul:"To zignoruje wyb\u00f3r kolor\u00f3w",Za:"Wyczy\u015b\u0107 Histori\u0119",Gh:"Przetapianie",Qd:"Search",Fg:"Auto Licytacja",Rd:"Nadmierne korzystanie z aukcji mo\u017ce skutkowa\u0107 banem. Zaleca si\u0119 wy\u0142\u0105czenie innych funkcji okre\u015blania stawek, aby unikn\u0105\u0107 potencjalnych konflikt\u00f3w. Ta funkcja spowolni bota.",qh:"Szukaj w Licytacji Gladiator\u00f3w",th:"Szukaj w Licytacji Najemnik\u00f3w",Zd:"Licytuj Po\u017cywienie?",qg:"Maksymalna Licytacja",$d:"Licytuj, je\u015bli status jest mniejszy ni\u017c",
ae:"Wystawione Przedmioty",Bk:"J\u0119zyk Licytacji",Ck:"Zgodnie z aktualizacj\u0105 2.9.4, prosz\u0119 ponownie ustawi\u0107 j\u0119zyk lub ZRESETOWA\u0106 BOTA. Upewnij si\u0119, \u017ce wszystko jest poprawne, w przeciwnym razie bot nie b\u0119dzie licytowa\u0107.",Ld:"Mo\u017cesz doda\u0107 przedmioty do wyszukiwania na rynku i w licytacji. Poka\u017ce tak\u017ce fioletowe przedmioty na rynku, gdy dodasz przedmiot do listy. Je\u015bli chcesz w\u0142\u0105czy\u0107 auto licytacj\u0119, u\u017cyj opcji poni\u017cej",
zk:"U\u017cywaj licytacji z rozwag\u0105!",Ak:"Automatyczna licytacja generuje zbyt wiele \u017c\u0105da\u0144 do serwera i mo\u017ce spowodowa\u0107 ban, je\u015bli u\u017cywasz jej ca\u0142y czas!",hh:"Odnowi\u0107 Punkty Wydarzenia Rubinem?",ve:"W\u0142\u0105cz Auto Olej",Ek:"Auto Pobieraj \u015awi\u0119te Oleje",Tk:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Ua:"Atakowa\u0107 Cz\u0142onk\u00f3w Gildii?",Sa:'Automatycznie dodawaj osoby do listy "Atak", gdy wi\u0119cej ni\u017c X z\u0142ota zostanie skradzione.:',
Ta:'Automatycznie dodawaj osoby do listy "Unikaj Atak", gdy przegrasz z nimi.:',Tb:"Ataki na Tablicy Wynik\u00f3w",ac:"Bardzo D\u0142ugo",Cb:"D\u0142ugo",Kb:"\u015arednio",Yb:"Kr\u00f3tko",bc:"Bardzo Kr\u00f3tko",we:"Wejd\u017a do Podziemia je\u015bli HP >",bh:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Ug:'Domy\u015blnie to "3x". Je\u015bli bot sprawia problemy z zadaniami, zmie\u0144 szybko\u015b\u0107 zada\u0144 zgodnie ze szybko\u015bci\u0105 serwera.',cf:"Wyb\u00f3r Worka z Lecznicami",xe:'Je\u015bli r\u0119cznie odnawiasz punkty, musisz klikn\u0105\u0107 przycisk powy\u017cej: "Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!"',
Ik:"Musisz w\u0142\u0105czy\u0107 co najmniej jedn\u0105 z opcji: ekspedycja, loch, arena lub cyrk, aby rozpocz\u0105\u0107 Ekspedycj\u0119 Eventow\u0105.",eh:"Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!",mb:"Nie przebijaj gildii?",$k:"Pozostaw wszystkie ustawienia wy\u0142\u0105czone, je\u015bli chcesz przetapia\u0107 za pomoc\u0105 paczek zawieraj\u0105cych przedmioty z listy. Jednak nadal mo\u017cesz wybiera\u0107 kolory.",Fk:"Posta\u0107(Wy\u0142\u0105czona) / Najemnik(W\u0142\u0105czony)",
Wk:"Naprawi\u0107 Obie?",al:"Timery",Timers:"Wprowad\u017a liczb\u0119 minut dla ka\u017cdego timera poni\u017cej lub pozostaw domy\u015blnie.",Zg:"Ignoruj Filtr Zada\u0144",Yg:"Wprowad\u017a s\u0142owa kluczowe, aby odfiltrowa\u0107 zadania, kt\u00f3rych nie chcesz przyj\u0105\u0107. You can also use this to accept quests by their reward using keywords.",X:"Wprowad\u017a S\u0142owo Kluczowe",K:"Dodaj",gh:"Usu\u0144",ge:"Wyczy\u015b\u0107",Wg:"Akceptuj Filtr Zada\u0144",Xg:"Wprowad\u017a s\u0142owa kluczowe, aby wybra\u0107 zadania do przyj\u0119cia. U\u017cycie tego spowoduje ignorowanie rodzaj\u00f3w zada\u0144",
Ea:"Pomi\u0144 Zadania Czasowe?",Uk:"Zadania",Td:"Automatyczny Kostium",Di:"U\u017cywa\u0107 Kostiumu?",Yd:"Podstawowa Bitwa",pe:"Bitwa w Lochach",Ud:"Bot b\u0119dzie nosi\u0142 Dis Pater Normal i Medium tylko wtedy, gdy Twoje punkty ekspedycji/podziemi wynosz\u0105 0.",ef:"Ustawienia Piekielnego Leczenia",Kd:"Atakuj Bossa, Gdy Dost\u0119pny?",sb:"Atak na Lig\u0119 zostanie wy\u0142\u0105czony po 5 nieudanych atakach.",hf:"\u015awi\u0119te Oleje",Ag:"Nazwa Przedmiotu",ba:"Minimalny Poziom Przedmiotu",
Ba:"Minimalna Jako\u015b\u0107 Przedmiotu",Jd:"Zastosuj/Resetuj Licznik",lf:"Ignoruj Prefiks/Sufiks",Ki:"Tak",Hg:"Nie",Qa:"Dodaj Prefiks",Ra:"Dodaj Sufiks",Hh:"Lista Ignorowanych Przedmiot\u00f3w do Topienia",Mb:"Prefiks",Zb:"Sufiks",mh:"Resetuj Wygas\u0142e Przedmioty",Ih:"Losowe Topienie z Paczek?",Jh:"Karta Topienia",qb:"Dodatki",Od:"Aukcja",ig:"Rynek",$b:"Zegary",hi:"Topienie",gi:"Topienie, je\u015bli brakuje z\u0142ota",di:"Topienie, je\u015bli brakuje przedmiotu",Fa:"Naprawa",Wh:"Przechowuj Z\u0142oto na Rynku Gildii",
Sh:"Przechowuj Z\u0142oto na Aukcji",ki:"Trening",Zh:"Resetuj Wygas\u0142e",ii:"Przechowuj W Ku\u017ani",Qh:"Sprawd\u017a Aukcj\u0119",ai:"Szukaj",v:"W\u0142\u0105cz",Cg:"Minimalne Z\u0142oto",nb:"Wp\u0142acaj Z\u0142oto do Gildii",ke:"B\u0119dzie wp\u0142aca\u0107 co 5 minut. Mo\u017cesz zmieni\u0107 interwa\u0142 w zak\u0142adce zegar\u00f3w",jf:"Ile chcesz wp\u0142aci\u0107?",le:"Wp\u0142aca\u0107, gdy masz wi\u0119cej ni\u017c >",wf:"Mniej ni\u017c <",jh:"Resetuj Wygas\u0142e i Inne Ustawienia",
lh:"Reset za:",Ok:"Naci\u015bnij Ctrl (Cmd na Macu), aby zaznaczy\u0107 wiele przedmiot\u00f3w",mf:"Importuj/Eksportuj Ustawienia",Ue:"Eksportuj Ustawienia",nf:"Importuj Ustawienia",tg:"Wiadomo\u015b\u0107 do Wszystkich Graczy",ug:"[Wymaga Klucza Ultra Premium, wiadomo\u015b\u0107 na Discordzie, aby go otrzyma\u0107.]",vg:"Wprowad\u017a wiadomo\u015b\u0107 do wys\u0142ania",ie:"Aby uzyska\u0107 niestandardowe skrypty, skontaktuj si\u0119 z nami na Discordzie",xg:"Wy\u015blij",yg:"Poka\u017c Graczy",
wg:"Zaznacz Wszystkie",zg:"Odznacz Wszystkie",vf:"Upewnij si\u0119, \u017ce tw\u00f3j inwentarz ma wystarczaj\u0105co du\u017co miejsca. Czas odnowienia wynosi 2 minuty.",pb:"W\u0142\u0105cz Atak na Tablicy Wynik\u00f3w:",Rb:"Wybierz Zakres Ataku",Sb:"Bot losowo atakuje z listy tablicy wynik\u00f3w.",rb:"Atak Ligi",ob:"W\u0142\u0105cz Atak Ligi:",Nb:"Losowo Atakuj",Ob:"Atakuj od najs\u0142abszego do najsilniejszego",yk:"Domy\u015blnie bot unika atakowania cz\u0142onk\u00f3w gildii.",Se:"Lokalizacja Wyprawy:",
Sd:"Auto Zbieraj Bonusy:",Fh:"Pomi\u0144 Bossa",qe:"Lokalizacja Lochu:",nh:"Zresetowa\u0107, je\u015bli przegrasz?",ff:"Ustawienia Piek\u0142a",gf:"Skonfiguruj ustawienia procentu leczenia w zak\u0142adce leczenia i upewnij si\u0119, \u017ce zak\u0142adka leczenia jest aktywowana. Je\u015bli wej\u015bcie do podziemi wyrzuca ci\u0119 z gry, przejd\u017a do lobby i zaznacz pole wyboru automatycznego logowania.",df:"Trudno\u015b\u0107 Piek\u0142a",Vd:"Auto Wej\u015bcie do Piek\u0142a: / Piek\u0142a Mode",
Ei:"U\u017cyj Mobilizacji, je\u015bli punkty = 0",Ii:"U\u017cyj rubin\u00f3w?",ye:"Wyj\u015b\u0107 z podziemi, je\u015bli nie ma punkt\u00f3w?",ri:"Bot b\u0119dzie pr\u00f3bowa\u0142 u\u017cy\u0107 willi medici najpierw, je\u015bli jej nie masz, u\u017cyje mikstury uzdrawiania. Nie zapomnij w\u0142\u0105czy\u0107 prze\u0142\u0105cznika uzdrawiania.",zi:"Automatyczne wej\u015bcie do piek\u0142a wy\u0142\u0105czy loch/aren\u0119/cyrk po wej\u015bciu do piek\u0142a.",bl:"Ustawienia Leczenia Piek\u0142a",
Hi:"U\u017cyj Willi Medici?",Fi:"U\u017cyj Mikstury Uzdrawiania?",dg:"INFORMACJA: Bot b\u0119dzie wyszukiwa\u0142 przedmioty na rynku co wybran\u0105 liczb\u0119 minut, co mo\u017ce spowodowa\u0107 zatrzymanie atakowania podczas wyszukiwania.",ue:"W\u0142\u0105cz Wyszukiwanie na Rynku:",eg:"Interwa\u0142 Wyszukiwania na Rynku w Minutach:",fg:"Sugerowane 10 minut.",rf:"Ustawienia Przedmiotu:",pf:"Nazwa Przedmiotu Zawiera",G:"Maksymalna Cena",sf:"Rodzaj Przedmiotu",qf:"Rzadko\u015b\u0107 Przedmiotu",
de:"Kup Przedmiot Uwi\u0105zany?",uf:"Przedmioty do Kupienia",tf:"Pr\u00f3buj kupowa\u0107 przedmioty z paczek, je\u015bli kt\u00f3rykolwiek z nich pasuje do maksymalnej ceny wprowadzonej.:",be:"Zakupione Przedmioty:",hj:"Procent Leczenia",uk:"Kupuj Jedzenie ze Sklepu?",vk:"U\u017cyj Leczenia z Paczki?",rk:"U\u017cyj Cervisia?",tk:"U\u017cyj Jajka?",zl:"Ostatnio U\u017cyty",location:"Lokalizacja",Strength:"Si\u0142a",Dexterity:"W\u0142adanie broni\u0105",Agility:"Zr\u0119czno\u015b\u0107",Constitution:"Budowa fizyczna",
Charisma:"Charyzma",Intelligence:"Inteligencja",mi:"Ustawienia Treningu",ni:"Wybierz atrybuty, kt\u00f3re chcesz trenowa\u0107. Bot przeprowadzi trening, gdy b\u0119dziesz mia\u0142 wystarczaj\u0105co du\u017co z\u0142ota.",N:"Nast\u0119pna akcja",vj:"Nie",wj:"Normalnie",Dl:"Przeciwnik",El:"Poziom Przeciwnika",Ij:"Zadania",random:"Losowo",Nl:"Ustawienia",Yl:"Wkr\u00f3tce...",type:"Kliknij na ikony, aby aktywowa\u0107 rodzaje zada\u0144.",em:"Tak",A:"Licytacja/Szukaj",Cd:"Dodaj przedmioty",nk:"Automatycznie Przechowuj Zasoby W\u0142asne",
$l:"Zatwierd\u017a",xl:"Interwa\u0142 : ",ml:"W\u0142\u0105cz Automatyczn\u0105 Licytacj\u0119",nl:"Nie licytuj, je\u015bli cz\u0142onek gildii ju\u017c licytowa\u0142",bm:"Samouczek",hc:"Wybierz przyciski powy\u017cej, aby wybra\u0107, czy chcesz stawi\u0107 czo\u0142a najni\u017cszemu przeciwnikowi na arenie, czy przeciwnikowi najwy\u017cszego poziomu. Wi\u0119cej u\u017cytkownik\u00f3w spowolni dzia\u0142anie bota.",el:'Aby rozpocz\u0105\u0107, dodaj przedmiot do listy (np. "Lucius"). Po dodaniu narz\u0119dzie b\u0119dzie szuka\u0107 przedmiotu i wy\u015bwietla\u0107 wyniki wyszukiwania po lewej stronie ekranu. B\u0119dzie r\u00f3wnie\u017c szuka\u0107 przedmiotu w celu automatycznej licytacji. Je\u015bli w\u0142\u0105czysz automatyczn\u0105 licytacj\u0119, narz\u0119dzie b\u0119dzie regularnie szuka\u0107 przedmiotu w okre\u015blonych odst\u0119pach czasu, zgodnie z liczb\u0105 wpisan\u0105 w polu interwa\u0142u. Je\u015bli narz\u0119dzie znajdzie przedmiot i b\u0119dziesz mie\u0107 wystarczaj\u0105co du\u017co pieni\u0119dzy, automatycznie z\u0142o\u017cy za ciebie licytacj\u0119. *Uwaga* aby szuka\u0107 unikalnych przedmiot\u00f3w w sklepach, musisz doda\u0107 przynajmniej 1 losowy przedmiot do listy wyszukiwania.',
pl:"Numer potwora mo\u017cna wybra\u0107 z przycisk\u00f3w powy\u017cej. Numer 1 reprezentuje potwora najbardziej na lewo. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",Yi:"Wybierz trudno\u015b\u0107 lochu z powy\u017cszych opcji. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",ij:"Ustawienia Leczenia",Zi:"Przechowuj nadmiar z\u0142ota w Gildii, kupuj\u0105c przedmioty z rynku gildii. -> Min. Z\u0142oto",
Al:"Przenie\u015b Wszystko",Bl:"Przenie\u015b Wybrane",il:"Auto Uzdrawianie",jl:"Procent Auto Uzdrawiania",dm:"Ruby",Lg:"Og\u00f3lne Ustawienia",Mj:"Sprzedaj Wszystko",Nj:"Sprzedaj Wybrane",ga:"Bronie",da:"Tarcze",W:"Zbroje Piersiowe",Z:"He\u0142my",Y:"R\u0119kawice",ea:"Buty",ca:"Pier\u015bcienie",V:"Amulety",Ci:"U\u017cywalne",Bi:"Ulepszenia",dh:"Receptury",sg:"Zwoje Najemnik\u00f3w",fh:"Wzmocnienia",mg:"Sprzedaj \u017bywno\u015b\u0107",Gb:"Prze\u0142\u0105cz na \u017bywno\u015b\u0107"},Kh={cg:"\u00a1Error de mercado! Por favor, a\u00f1ade los elementos nuevamente e int\u00e9ntalo.",
Lb:"No hay suficiente espacio en tu inventario. Por favor, limpia tu inventario.",ck:"\u00bfDerretir los colores m\u00e1s altos primero?",cc:"\u00bfAtacar solo a la lista de jugadores?",dc:"Cuando esta opci\u00f3n est\u00e9 habilitada, el bot solo atacar\u00e1 a los jugadores en la lista de jugadores. Si esta opci\u00f3n no est\u00e1 habilitada, el bot atacar\u00e1 a jugadores aleatorios.",Kk:"\u00a1Tus configuraciones de expedici\u00f3n son incorrectas o hay datos de p\u00e1gina inesperados!",Lk:"\u00a1Tu configuraci\u00f3n de expedici\u00f3n es incorrecta! Has establecido un monstruo deshabilitado, lo cual est\u00e1 mal.",
Ca:"Prioridad",Vb:"Establecer Prioridad",Rg:"Puntos",Kh:"Stat",Si:"Recolectar Oro",Oj:"Vender en el Inframundo?",uj:"El bot buscar\u00e1 el nido en cada acci\u00f3n, no solo en expediciones.",sj:"Tipo de b\u00fasqueda de nido",qj:"No hacer nada",rj:"B\u00fasqueda r\u00e1pida",tj:"B\u00fasqueda exhaustiva",Kl:"After expedition points are consumed, travel to Germania to consume Dungeon points",xk:"Haz clic aqu\u00ed si la reparaci\u00f3n se atasca",Mk:"Cuando los HP est\u00e9n bajos, usa curar",Ng:"Reparaci\u00f3n Parcial",
af:"Reparaci\u00f3n Completa",Mg:"Reparaci\u00f3n Parcial o Completa",se:"Habilitar L\u00edmite",kj:"L\u00edmite",lj:"Si deseas limitar el n\u00famero de veces que quieres atacar al enemigo, habilita esta opci\u00f3n y establece el l\u00edmite. El bot continuar\u00e1 atacando al resto de los enemigos despu\u00e9s de terminar de atacar al monstruo seleccionado.",ne:"No entres al inframundo con el traje del inframundo",me:"Si no quieres entrar al inframundo mientras llevas el traje del inframundo puesto, activa esta opci\u00f3n",
yi:"Inframundo",pi:"Mejoras del Inframundo",si:"\u00bfUsar los poderes de los dioses despu\u00e9s de entrar al inframundo?",ti:"Selecciona a los dioses para usar sus poderes:",ui:"\u00bfUsar Buff de Arma en el arma?",vi:"\u00bfUsar Buff de Armadura en el siguiente equipo?",Hk:"El tiempo de enfriamiento es de 30 minutos. Si no llevas un disfraz, el bot restablecer\u00e1 el tiempo de enfriamiento a 0.",Zk:"Seleccionar Colores",$a:"Forja de Vulcano",eb:"Escudo Terrestre de Feronia",fb:"Poder Fluido de Neptuno",
gb:"Libertad A\u00e9rea de Aelous",hb:"Niebla Mortal de Plut\u00f3n",ib:"Aliento de Vida de Juno",jb:"Armadura de Escamas de las Monta\u00f1as de la Ira",kb:"Ojos de \u00c1guila",lb:"Vestidura Invernal de Saturno",ab:"Armadura de Toro de Bubona",bb:"Vestiduras de Ladr\u00f3n de Mercurio",cb:"T\u00fanica de Luz de Ra",lg:"Paquetes",gg:"Inventario",M:"Precio M\u00edn.",L:"Cantidad",Fb:"Vender Art\u00edculos",Eb:"Buscar en",hg:"Color del Material",Db:"Color del Art\u00edculo",og:"Almac\u00e9n",Aa:"Cambiar a Materiales",
Hb:"Cambiar a Art\u00edculos",ng:"Vender Materiales",xa:"Por favor, introduce un nombre de art\u00edculo v\u00e1lido, rango de precio y cantidad.",ya:"No se han encontrado art\u00edculos adecuados en las ubicaciones de b\u00fasqueda seleccionadas.",za:"\u00a1Todos los art\u00edculos fueron listados con \u00e9xito!",Sk:"\u00a1Todos los materiales fueron listados con \u00e9xito!",jg:"Si quieres vender art\u00edculos a un precio fijo, puedes ingresar el mismo valor para el precio m\u00ednimo y m\u00e1ximo.",
kg:"Esta caracter\u00edstica todav\u00eda es experimental, \u00fasala con precauci\u00f3n. Si no pones un precio fijo, los art\u00edculos se listar\u00e1n aleatoriamente entre el precio m\u00ednimo y m\u00e1ximo que ingreses.",Dk:"Establece el m\u00e1ximo de oro que el bot gastar\u00e1 por ciclo.",Va:"El bot comenzar\u00e1 a pujar por cualquier art\u00edculo de comida, si est\u00e1 habilitado. No necesitas habilitar los interruptores de gladiador/mercenario.",Md:"El bot no pujar\u00e1 sobre las ofertas de los aliados.",
Nd:"Ignorar la combinaci\u00f3n de Prefijo/Sufijo al buscar un art\u00edculo en la subasta.",Vj:"Selecciona los tipos de art\u00edculos que quieres fundir.",Wj:"Selecciona los colores que quieres fundir.",Xj:"Selecciona el nivel de los art\u00edculos que quieres fundir.",Yj:"Selecciona el martillo que quieres usar.",Zj:"Nota que el c\u00edrculo verde y rojo junto a la primera caja son para habilitar/deshabilitar la regla.",$j:"Si quieres fundir aleatoriamente cualquier color o tipo, puedes habilitar `\u00bfFundir aleatoriamente si no se cumplen condiciones? (\u00daltima opci\u00f3n habilitada en el video tutorial)",
Kj:"Reparar antes de fundir?",Oe:"Seleccionar Monstruo",Ce:"\u00bfUsar Reloj de Arena/Rub\u00ed?",Jk:"\u00bfUsar Rub\u00ed?",Fe:"\u00bfUsar Movilizaci\u00f3n?",Ee:"\u00bfUsar Poci\u00f3n de Vida?",Be:"Porcentaje de Curaci\u00f3n (%)",Me:"N\u00famero de Ataques",De:"Intervalo de Ataque (en segundos)",ze:"Ataques Realizados",Ae:"Reloj de Arena Restante",Ke:"Nota: Usa pociones de vida para curar, no comida.",Le:"Nota: Si los ataques se detienen prematuramente, intenta 'Reiniciar Ataques'.",Pe:"Comenzar",
Ne:"Reiniciar",Qe:"Detener",Re:"Configuraci\u00f3n de Expedici\u00f3n (Clic para minimizar)",Ge:"Monstruo 1",He:"Monstruo 2",Ie:"Monstruo 3",Je:"Monstruo 4",Vk:"Reparar antes de fundir?",Qi:"Esta opci\u00f3n usar\u00e1 cervisia cuando tu premium expire.",xj:"Esta opci\u00f3n activa y selecciona aceites de las recompensas de los dioses. Puede usar los aceites n\u00famero 1 y n\u00famero 3 en el personaje, pero el n\u00famero 2 solo ser\u00e1 recogido para los paquetes.",Oi:"Esta opci\u00f3n usar\u00e1 buffs en el momento que establezcas. Encontrar\u00e1 buffs en los paquetes y los aplicar\u00e1 al personaje.",
mj:"Esta opci\u00f3n te llevar\u00e1 al inframundo. No olvides activar el Inicio de Sesi\u00f3n Autom\u00e1tico desde la pesta\u00f1a de Extras, de lo contrario podr\u00edas desconectarte al entrar al inframundo [Error del Juego]",ec:"Esta op\u00e7\u00e3o atacar\u00e1 apenas a lista de arena/circo. Se n\u00e3o puder, o bot pular\u00e1.",Hj:"Esta opci\u00f3n es solo para licencias premium. Simula el ataque antes de atacar a un usuario para un ratio de victoria del 75%.",Pd:"No necesitas activar el interruptor principal de subastas para habilitar esta opci\u00f3n.",
qk:"Esta opci\u00f3n refrescar\u00e1 la p\u00e1gina cada segundo cuando la subasta est\u00e9 en estado -Muy Corto- para ofertar constantemente y ganar la subasta.",Tj:"Si ninguna de las condiciones de fundici\u00f3n se cumple, fundir\u00e1 aleatoriamente. Aseg\u00farate de seleccionar tipo de objeto y color.",Uj:"Esta opci\u00f3n solo fundir\u00e1 art\u00edculos del inventario. Ignorar\u00e1 los art\u00edculos en los paquetes.",Wa:"Art\u00edculos de Subasta",rg:"Art\u00edculos de Mercenario",Xb:"Art\u00edculos de la Tienda",
Ai:"Art\u00edculos \u00danicos",Pj:"Establecer fondo en negro [Aumenta el rendimiento]",Qj:"Mover los botones de GLDbot a la parte inferior izquierda?",Ri:"Atacar al circo sin sanar",pk:"\u00bfRecoger oro de los paquetes si es necesario?",am:"Se ha recogido oro de los paquetes para entrenamiento",Gd:"No se ha encontrado oro en los paquetes para entrenamiento",lk:"Objetos Reparados",ek:"Ataques en la Arena",gk:"Ataques en el Circo",Ed:"Objetos Reiniciados",jk:"Ataques en Expediciones",ik:"Ataques en Mazmorras",
mk:"Ataques en el Inframundo",fk:"Dinero Ganado en la Arena",hk:"Dinero Ganado en el Circo",Zl:"Objetos Fundidos",kk:"Oro Reciclado",dj:"Batalla de Gremio",fj:"Configuraci\u00f3n del Gremio",rl:"Atacar\u00e1 gremios al azar.",ej:"Nombre del Gremio",cj:"Atacar Guilds Aleatoriamente",Pi:"Restablecer Estad\u00edsticas",Cl:'GLDbot: usa los dados para actualizar la caja misteriosa y encontrar objetos valiosos antes de abrirla (por ejemplo, disfraces). Haz clic en "Iniciar" para abrir los cofres.',Pc:"Madera",
Fc:"Cobre",Jc:"Hierro",Lc:"Cuero",Qc:"Hilo de lana",Gc:"Bolas de algod\u00f3n",Ic:"C\u00e1\u00f1amo",Hc:"Tiras de gasa",Mc:"Lino",Kc:"Yute",Oc:"Tiras de terciopelo",Nc:"Hilo de seda",Yc:"Pelaje",Sc:"Astilla \u00f3sea",ad:"Escama",Vc:"Garra",Xc:"Colmillo",Wc:"Escama de drag\u00f3n",Tc:"Cuerno de toro",$c:"Gl\u00e1ndula venenosa",Uc:"Pelaje de Cerbero",Zc:"Escama de Hidra",bd:"Pluma de Esfinge",cd:"Piel de Tif\u00f3n",Cc:"Lapisl\u00e1zuli",wc:"Amatista",vc:"\u00c1mbar",xc:"Aguamarina",Dc:"Safiro",Ac:"Granate",
zc:"Esmeralda",yc:"Diamante",Bc:"Jaspe",Ec:"Sugilita",qc:"Veneno de escorpi\u00f3n",tc:"Tintura de la resistencia",mc:"Ant\u00eddoto",lc:"Adrenalina",sc:"Tintura de la inspiraci\u00f3n",pc:"Poci\u00f3n de percepci\u00f3n",nc:"Esencia de reflejos",oc:"Frasco de carisma",uc:"Agua del olvido",rc:"Esencia de alma",Bd:"Sello acu\u00e1tico",vd:"Runa protectora",td:"Grabado terrestre",Ad:"T\u00f3tem curativo",zd:"Talism\u00e1n de poder",xd:"Piedra de la fortuna",ud:"Pedernal",yd:"Runa de la tormenta",wd:"Runa de las sombras",
gd:"Cristal",fd:"Bronce",ld:"Obsidiana",od:"Plata",pd:"Azufre",jd:"Mena de oro",nd:"Cuarzo",md:"Platino",ed:"Almandino",hd:"Cuprita",kd:"Piedra infernal",Li:"\u00bfAtacar aleatoriamente?",Mi:'Tambi\u00e9n desactiva la configuraci\u00f3n "Ordenar jugadores en la arena por nivel" en crazy-addon.',$g:"Aceptar solo misiones basadas en el tipo de dios.",Xa:"Auto Buff",ce:"\u00bfUsar solo en el infierno?",Gg:"Nueva Regla",Eg:"Nombre Contiene",isUnderworldItem:"\u00bfEs un objeto del inframundo?",kf:"Ignorar Materiales",
wk:"\u00bfUsar Oraci\u00f3n?",Gi:"Usar Sacrificio",sk:"Usar Tela para entrar en el Inframundo",xi:"\u00bfCuando est\u00e9s en el inframundo, solo aceptar misiones relacionadas con el inframundo?",wi:"Si est\u00e1 habilitado, necesitas ingresar los nombres de los objetos del inframundo. Si el bot encuentra estos objetos en el inframundo, aceptar\u00e1 la misi\u00f3n.",cl:"Objeto de Misi\u00f3n del Inframundo",ol:"Introduzca el nombre del material",Gk:"\u00a1El robot adora los dados! Le ayudan a encontrar ropa en los cofres. Pero si no hay dados, el robot abre los cofres de todos modos, con la esperanza de encontrar ropa genial (\u00a1pero puede que no encuentre nada!)",
Sj:"\u00bfFusionar Cajas de Bot\u00edn?",re:"Habilitar Arena",Sg:"\u00bfPriorizar lista de arenas?",Tg:"\u00bfPriorizar lista de circos?",je:"Desactivar men\u00fa de registro",oh:"Valor m\u00ednimo de recompensa en oro",ah:"Si est\u00e1 habilitado, el Enfoque en misiones seguir\u00e1 el camino m\u00e1s corto para terminar el calabozo.",Nh:"\u00bfLanzar dados autom\u00e1ticamente?",Oh:"Usa el lanzamiento de dados con cautela, seguir\u00e1 usando el primer dado hasta que desactives la opci\u00f3n.",
uh:"Progreso de b\u00fasqueda",ih:"El tiempo de enfriamiento para la reparaci\u00f3n por defecto es de 10 minutos.",Bg:"Condici\u00f3n m\u00ednima",he:"Art\u00edculo actual en el banco de trabajo [Borrar si el bot se detiene inesperadamente]",Gf:"Recursos de forja almacenados en el horreum con \u00e9xito.",Cf:"Comprobando el mercado para art\u00edculos...",Ab:"Art\u00edculo movido al banco de trabajo.",Tf:"Art\u00edculo reparado y equipado con \u00e9xito.",Uf:"Art\u00edculo reparado con \u00e9xito.",
Qk:"La reparaci\u00f3n fall\u00f3. La p\u00e1gina se actualizar\u00e1.",Qf:"Recogiendo materiales...",bg:"Esperando reparaci\u00f3n...",Sf:"La reparaci\u00f3n ha comenzado para .",wa:"Reparaci\u00f3n: Moviendo el art\u00edculo del inventario a la bolsa",Rf:"Reparaci\u00f3n: Moviendo el art\u00edculo del banco de trabajo al paquete.",ua:"No se pudieron encontrar suficientes materiales. Desactivando la ranura de reparaci\u00f3n ",Nf:"Buscando art\u00edculos para comprar y ocultar oro en la subasta...",
zf:"Comprobando los art\u00edculos caducados en los paquetes...",Af:"Art\u00edculo reseteado con \u00e9xito.",Bf:"Sin espacio vac\u00edo o oro para resetear.",Hf:"\u00a1Aseg\u00farate de tener derechos de venta en el mercado de la guild!",ub:"No hay suficiente oro o ning\u00fan art\u00edculo para comprar. Esperando 30 segundos para actualizar.",wb:"La tienda ha sido actualizada.",xb:"Error durante la curaci\u00f3n.",Kf:"Sin Rub\u00ed o Tela, desactivando las opciones.",Pk:"No se encontr\u00f3 ning\u00fan art\u00edculo de curaci\u00f3n en los paquetes.",
yb:"No se encontraron art\u00edculos adecuados",Lf:"Se han recogido alimentos. Finalizando el proceso.",Mf:"Se ha recogido al menos un alimento. Finalizando el proceso.",zb:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",If:"Obteniendo alimentos de los paquetes.",Jf:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",vb:"No hay m\u00e1s art\u00edculos de curaci\u00f3n. Esperando 30 segundos.",tb:"Puntos de vida recuperados.",va:"\u00a1No hay nada que hacer, as\u00ed que voy a rezar!",
Yf:"Voy a actualizar en 60 segundos para revisar mi salud y Villa Medici.",Zf:"Esperando Villa Medici, actualizando en 60 segundos.",$f:"Sal\u00ed del inframundo.",ag:"Voy a actualizar en 60 segundos para revisar mi salud.",Of:"Comprobando aceites divinos...",Pf:"Los aceites divinos han sido recogidos.",sa:"Atacado con \u00e9xito al jugador en la ARENA: ",ta:"Atacado con \u00e9xito al jugador en el CIRCO: ",xf:"\u00a1Comprobando subasta! Por favor, espere...",yf:"Pujando por art\u00edculos. Por favor, espere...",
Vf:"Art\u00edculo fundido autom\u00e1ticamente: ",Wf:"Fundiendo art\u00edculo: ",Bb:"No hay suficiente oro para fundir. Oro requerido: ",Xf:"FUNDIR: Buscando art\u00edculos para fundir...",Rk:"Buscando art\u00edculos para fundir...",Df:"Comprobando disponibilidad de disfraces...",Ff:"Donado : ",Ef:"Lanzando dados...",Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",Ye:"Tenga en cuenta: active esta funci\u00f3n despu\u00e9s de desbloquear la criatura que desea atacar, no atacar\u00e1 autom\u00e1ticamente para desbloquear el monstruo.",
Ve:"Farm Enemy",Wd:"Inicio Autom\u00e1tico",Xd:"Necesitas permitir las ventanas emergentes desde la pantalla del lobby de GameForge. Consulta la documentaci\u00f3n sobre c\u00f3mo hacerlo.",Og:"Pausar Bot",Pg:"Pausar Bot en (Minutos)",Te:"Fecha de Expiraci\u00f3n",Jg:"\u00bfComprar solo comida?",Kg:"Si activas esto, el bot ignorar\u00e1 tus selecciones y comprar\u00e1 comida autom\u00e1ticamente sin ingresar nada.",Jb:"M\u00e1ximo de oro total para gastar",Ib:"M\u00e1ximo de oro por comida para gastar",
Ig:"El bot verificar\u00e1 los aceites cada 60 minutos",fi:"Establece un temporizador para verificar los tiempos de fundici\u00f3n.",ci:"Establece un temporizador para verificar la fundici\u00f3n cuando no tengas oro.",ei:"Establece un temporizador para verificar la fundici\u00f3n si no tienes el art\u00edculo disponible.",Yh:"Establece un temporizador para reparar y verificar tus objetos.",Xh:"Establece un temporizador para verificar el oro en el mercado de la hermandad.",Th:"Establece un temporizador para la opci\u00f3n de retenci\u00f3n de oro en la subasta.",
Ph:"Establece un temporizador para verificar la lista de PVP en la arena para atacar.",Uh:"Establece un temporizador para verificar la lista de PVP en el circo para atacar.",li:"Establece un temporizador para entrenar tus estad\u00edsticas.",$h:"Establece un temporizador para reiniciar los objetos caducados.",ji:"Establece un temporizador para almacenar los materiales de forja en el horreo.",Rh:"Establece un temporizador para verificar la subasta de gladiadores y mercenarios.",bi:"Establece un temporizador para buscar objetos en la subasta y la tienda.",
Vh:"Establece el temporizador para enviar donaciones a la hermandad.",bf:"Oro Movido",oe:"No vender art\u00edculos de la lista de fundici\u00f3n y subasta.",vh:"Automatizaci\u00f3n de la Tienda",xh:"Configuraci\u00f3n de B\u00fasqueda de Objetos",wh:"Utiliza esta herramienta para buscar objetos. Simplemente agrega los objetos a la lista, especifica la cantidad de tela y comienza la b\u00fasqueda.",yh:"Telas a Usar:",zh:"\u00bfCu\u00e1ntas telas usar?",fa:"Full Ingresa el Nombre del Objeto",Wb:"Ingresa el Nivel del Objeto",
Bh:"Calidad del Objeto",Ah:"Nombre del Objeto Aqu\u00ed",Ch:"Comenzar B\u00fasqueda",Dh:"Saltar y Continuar",Eh:"Detener B\u00fasqueda",Ze:"\u00bfComprar lo m\u00e1s barato o lo m\u00e1s caro?",Dg:"M\u00e1s Caros",ee:"M\u00e1s Baratos",Da:"Selecciona una Opci\u00f3n",te:"Pod\u015bwietl przedmioty z Podziemia",$e:"\u00bfCentrarse en la b\u00fasqueda",cm:"\u00bfUsar Ruby si no hay tela",Ya:"Evita atacar a las mismas personas para no ser reportado. Ser reportado aumenta las posibilidades de ser baneado.",
Rl:"\u00bfDerretir verde?",Vg:"\u00bfNo aceptar misiones aleatorias si se han introducido filtros?",Rc:"Calidad m\u00e1xima del material a utilizar",$i:"Habilitar la b\u00fasqueda de mercenarios",yl:"Haz clic en `Vender Todo Seleccionado` para vender todos los elementos. Aseg\u00farate de tener espacio vac\u00edo de 2x3 en tu primera (1) bolsa. Para recoger oro en masa, filtra el oro y usa `Seleccionar Seleccionados o Seleccionar Todo`.",dk:"\ud83d\udd25 : A\u00f1ade elemento a la lista de fundici\u00f3n.",
Ni:"\ud83d\udd28 : A\u00f1ade elemento a la lista de subastas.",Jj:"Actualiza la tienda con tela cuando est\u00e9 llena",Gl:"P\u00e1gina:",Fj:"Detener",Dj:"Vender Esta P\u00e1gina",Aj:"Seleccionar Seleccionados",zj:"Seleccionar Todo",Gj:"Configuraci\u00f3n de Empaquetado Autom\u00e1tico",Ej:"Enviar Recursos",Bj:"Vender Todo Seleccionado",na:"Tipo de Objeto",pa:"Armas",U:"Escudos",O:"Armaduras",S:"Cascos",R:"Guantes",P:"Botas",oa:"Anillos",la:"Amuletos",Ka:"Utilizables (Comida)",Pa:"Mejoras",yj:"Potenciadores",
Ma:"Recetas",La:"Mercenarios",Oa:"Herramientas de Forja",Na:"Pergaminos",sd:"Refuerzos",qd:"Objetos de Evento",rd:"Materiales de Forja",Fl:"Oro",Ja:"Todo",Hl:"Calidad",qa:"Blanco",C:"Verde",B:"Azul",D:"Morado",J:"Naranja",T:"Rojo",Cj:"Opciones de Venta",Rj:"\u00bfIgnorar Combinaci\u00f3n de Prefijo/Sufijo?",gj:"\u00bfCu\u00e1nta comida comprar/recoger?",Vi:"Normal",Ui:"Intermedio",Ti:"Dif\u00edcil",Ga:"Est\u00e1ndar",Ll:"Reparar Correcci\u00f3n de Atascos",Nk:"Desactiva la entrada al Infierno si deseas desactivar la Mazmorra/Circo/Arena. Si entraste al Infierno manualmente, deber\u00e1s activar el Modo Infierno.",
fe:"Wybierz kostium z Za\u015bwiat\u00f3w",Ji:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",oi:"Indica cu\u00e1ntas veces deseas entrenar las estad\u00edsticas y establece sus prioridades. El bot no entrenar\u00e1 a menos que se establezca una prioridad. Si hay una prioridad configurada pero no quedan m\u00e1s estad\u00edsticas por entrenar, el bot continuar\u00e1 con la estad\u00edstica seleccionada.",ll:"Quest",Dd:"Fundir",Wl:"Configuraci\u00f3n de Fundici\u00f3n",ak:"Objetos Fundidos",
Xl:"Agrega Prefijos o Sufijos, una vez que los encuentre en los paquetes, se fundir\u00e1n autom\u00e1ticamente:",Vl:"Objeto en Fundici\u00f3n:",ic:"Haz clic en el objeto que deseas reparar. Este sistema reparar\u00e1 a tus dos personajes, el principal y el primer personaje de circo. Debes tener al menos 10000 de oro para que comience la reparaci\u00f3n. Si se queda atascado en un objeto, significa que no tienes material para arreglarlo. Tambi\u00e9n trata de hacer espacio en tu inventario. El bot iniciar\u00e1 la reparaci\u00f3n una vez que el objeto tenga un %0 de durabilidad.",
dl:"Aplicar solo a Mercenarios",hl:"La subasta solo pujar\u00e1 cuando el mercado est\u00e9 cerca del final.",gl:"Aseg\u00farate de que la SEGUNDA PESTA\u00d1A DEL INVENTARIO est\u00e9 vac\u00eda y tenga 10K de oro. El bot encontrar\u00e1 y colocar\u00e1 el objeto en la segunda pesta\u00f1a y luego, la pr\u00f3xima vez que se actualice la p\u00e1gina, fundir\u00e1 el objeto. La fundici\u00f3n se revisar\u00e1 cada 5-10 minutos.",jj:"Curar & Buffs",Ml:"No hay suficiente oro para fundir. Oro requerido:",
Pl:"Saltando puja: El miembro del gremio ya ha pujado por el objeto ",Ol:"Saltando puja: Ya has pujado por el objeto ",advanced:"Avanzado",arena:"Arena",ja:"Auto Ataque",fc:"Evitar Ataque",ha:"Agregar Jugador",ia:"Agregar Nombre de Jugador (Same Server)",tl:"\u00bfDetener el bot si se queda sin comida?",circusTurma:"Circo Turma",Wi:"Dificultad",dungeon:"Mazmorra",Xi:"Configuraci\u00f3n de Mazmorra",eventExpedition:"Expedici\u00f3n de Evento",expedition:"Expedici\u00f3n",aj:"Configuraci\u00f3n de Expedici\u00f3n",
Lj:"Seleccionar Monstruo",vl:"M\u00e1s Alto",ul:"Coloca tus objetos de curaci\u00f3n en la primera p\u00e1gina de tu inventario",nj:"En",Lh:"Almacenar Oro",Mh:"\u00bfAlmacenar Oro en Subasta?",rh:"\u00bfUsar Ropa de Trabajo para renovar la Tienda?",Xk:"Seleccionar Objetos para Reiniciar",kh:"Reiniciar Objetos Expirados",Qb:"Nota: Al habilitar esta opci\u00f3n, el bot vender\u00e1 los objetos pr\u00f3ximos a expirar de los Paquetes al Mercado del Gremio y luego los cancelar\u00e1 para reiniciar el tiempo de vencimiento. Se requiere el Gremio. Aseg\u00farate de tener un espacio vac\u00edo de 3x3 en tus bolsas.",
Qg:"Pausar el bot aleatoriamente para funcionar como [Fase de Pruebas]:",aa:"Mantener Oro: El bot mantendr\u00e1 este oro en la bolsa:",pg:"Oro M\u00e1ximo: El bot gastar\u00e1 cuando el oro sea mayor que",ph:"El bot pujar\u00e1 por art\u00edculos aleatorios",Hd:"Agregar Retraso Aleatorio",Id:"Puedes agregar un retraso al bot aqu\u00ed.",Pb:"Reparar",Ql:"\u00bfFundir solo Azules?",Tl:"\u00bfFundir solo P\u00farpuras?",Sl:"\u00bfFundir solo Naranjas?",bk:"\u00bfFundir Todo en la 2da pesta\u00f1a?",
Ul:"Esto ignorar\u00e1 las selecciones de colores",Za:"Limpiar Historial",Gh:"Fundir",Qd:"Search",Fg:"Subasta Autom\u00e1tica",Rd:"El uso excesivo de la Subasta podr\u00eda resultar en una prohibici\u00f3n. Se recomienda desactivar otras funciones de oferta para evitar posibles conflictos. Esta caracter\u00edstica ralentizar\u00e1 el bot.",qh:"Buscar en la Subasta de Gladiadores",th:"Buscar en la Subasta de Mercenarios",Zd:"\u00bfPujar por Comida?",qg:"Puja M\u00e1xima",$d:"Pujar si el estado es menor que",
ae:"Objetos Pujados",Bk:"Idioma de Subasta",Ck:"Seg\u00fan la actualizaci\u00f3n 2.9.4, establece el idioma nuevamente o REINICIA EL BOT. Aseg\u00farate de que todos sean correctos, de lo contrario, no pujar\u00e1.",Ld:"Puedes agregar objetos para buscar en el mercado y en la subasta. Tambi\u00e9n mostrar\u00e1 objetos p\u00farpuras en el mercado una vez que agregues un objeto a la lista. Si deseas habilitar la puja autom\u00e1tica, usa las opciones a continuaci\u00f3n",zk:"\u00a1Usa la subasta con precauci\u00f3n!",
Ak:"La puja autom\u00e1tica realiza demasiadas solicitudes al servidor y puede causar una prohibici\u00f3n si se usa todo el tiempo.",hh:"\u00bfRenovar Puntos de Evento con Rub\u00edes?",ve:"\u00bfHabilitar Aceite Autom\u00e1tico?",Ek:"\u00bfObtener Aceites Sagrados Autom\u00e1ticamente?",Tk:"Velocidad de Verificaci\u00f3n de Misiones",Ua:"\u00bfAtacar a Miembros del Gremio?",Sa:'Agregar autom\u00e1ticamente a las personas a la lista de "Ataque" cuando se roban m\u00e1s de X ORO.:',Ta:'Agregar autom\u00e1ticamente a las personas a la lista de "Evitar Ataque" cuando pierdas contra ellas.:',
Tb:"Ataques en el Marcador",ac:"Muy Largo",Cb:"Largo",Kb:"Medio",Yb:"Corto",bc:"Muy Corto",we:"Entrar al Inframundo si HP >",bh:"Velocidad de Verificaci\u00f3n de Misiones",Ug:'El valor predeterminado es "3x". Si el bot causa problemas con las misiones, cambia la velocidad de las misiones seg\u00fan la velocidad de tu servidor.',cf:"Selecci\u00f3n de Bolsa de Curaci\u00f3n",xe:'Si est\u00e1s renovando puntos manualmente, debes hacer clic en el bot\u00f3n de arriba "Actualizar expedici\u00f3n de evento si est\u00e1 atascada".',
Ik:"Debes habilitar al menos una de las siguientes opciones: expedici\u00f3n, mazmorra, arena o circo para comenzar la Expedici\u00f3n de Evento.",eh:"\u00a1Actualiza la Expedici\u00f3n de Evento si est\u00e1 atascada!",mb:"\u00bfCubrir a los Aliados?",$k:"Deja todas las configuraciones desactivadas si deseas fundir usando paquetes que contienen los elementos de la lista. Sin embargo, a\u00fan puedes elegir colores.",Fk:"Personaje(Desactivado) / Mercenario(Activado)",Wk:"\u00bfReparar Ambos?",al:"Temporizadores",
Timers:"Ingresa el n\u00famero de minutos para cada temporizador a continuaci\u00f3n o d\u00e9jalo en su valor predeterminado.",Zg:"Ignorar Filtro de Misiones",Yg:"Ingresa palabras clave para filtrar las misiones que no deseas tomar. You can also use this to accept quests by their reward using keywords.",X:"Ingresar Palabra Clave",K:"Agregar",gh:"Eliminar",ge:"Limpiar",Wg:"Aceptar Filtro de Misiones",Xg:"Ingresa palabras clave para seleccionar qu\u00e9 misiones tomar. Usar esto ignorar\u00e1 los tipos de misiones",
Ea:"\u00bfSaltar Misiones Temporales?",Uk:"Misiones",Td:"Auto Traje",Di:"\u00bfUsar Traje?",Yd:"Batalla B\u00e1sica",pe:"Batalla en Mazmorra",Ud:"Bot solo usar\u00e1 Dis Pater Normal y Medium si tus puntos de expedici\u00f3n/mazmorra son 0.",ef:"Configuraci\u00f3n de Sanaci\u00f3n Infernal",Kd:"\u00bfAtacar al Jefe cuando est\u00e9 disponible?",sb:"La opci\u00f3n de ataque a la Liga se desactivar\u00e1 despu\u00e9s de 5 intentos fallidos.",hf:"Aceites Sagrados",Ag:"Nombre del Objeto",ba:"Nivel M\u00ednimo del Objeto",
Ba:"Calidad M\u00ednima del Objeto",Jd:"Aplicar/Restablecer Temporizador",lf:"Ignorar Combinaci\u00f3n de Prefijo/Sufijo",Ki:"S\u00ed",Hg:"No",Qa:"Agregar Prefijo",Ra:"Agregar Sufijo",Hh:"Lista de Objetos a Ignorar al Fundir",Mb:"Prefijo",Zb:"Sufijo",mh:"Restablecer Objetos Expirados",Ih:"\u00bfFundir al Azar desde los Paquetes?",Jh:"Pesta\u00f1a de Fundici\u00f3n",qb:"Extras",Od:"Subasta",ig:"Mercado",$b:"Temporizadores",hi:"Fundici\u00f3n",gi:"Fundici\u00f3n si no hay suficiente oro",di:"Fundir si no hay objeto",
Fa:"Reparaci\u00f3n",Wh:"Mantener Oro en el Mercado de Gremio",Sh:"Mantener Oro en la Subasta",ki:"Entrenamiento",Zh:"Restablecer Expirados",ii:"Almacenar en la Forja",Qh:"Comprobar Subasta",ai:"Buscar",v:"Habilitar",Cg:"Oro M\u00ednimo",Ub:"Seleccionar Hora",nb:"Donar Oro al Gremio",ke:"Donar\u00e1 cada 5 minutos. Puedes cambiar el intervalo desde la pesta\u00f1a de temporizadores",jf:"\u00bfCu\u00e1nto deseas donar?",le:"Donar cuando tengas m\u00e1s de >",wf:"Menos de <",jh:"Restablecer Objetos Expirados y Otras Configuraciones",
lh:"Restablecer en:",Ok:"Mant\u00e9n presionada la tecla Ctrl (Cmd en Mac) para seleccionar varios objetos",mf:"Importar/Exportar Configuraciones",Ue:"Exportar Configuraciones",nf:"Importar Configuraciones",tg:"Mensaje a Todos los Jugadores",ug:"[Requiere Clave Ultra Premium, mensaje en Discord para obtenerla.]",vg:"Ingresar mensaje para enviar",ie:"Para scripts personalizados, cont\u00e1ctanos en Discord",xg:"Enviar",yg:"Mostrar Jugadores",wg:"Seleccionar Todos",zg:"Deseleccionar Todos",vf:"Aseg\u00farate de que tu inventario tenga suficiente espacio. El tiempo de reutilizaci\u00f3n es de 2 minutos.",
pb:"Habilitar Ataque en el Marcador:",Rb:"Seleccionar Rango para Atacar",Sb:"El bot atacar\u00e1 aleatoriamente desde la lista del marcador.",rb:"Ataque de Liga",ob:"Habilitar Ataque de Liga:",Nb:"Ataque Aleatorio",Ob:"Atacar desde el m\u00e1s bajo al m\u00e1s alto",yk:"El bot evitar\u00e1 atacar a los miembros del gremio por defecto.",Se:"Ubicaci\u00f3n de Expedici\u00f3n:",Sd:"\u00bfRecoger Bonos Autom\u00e1ticamente?",Fh:"\u00bfSaltar al Jefe?",qe:"Ubicaci\u00f3n de Mazmorra:",nh:"\u00bfReiniciar si pierdes?",
ff:"Configuraci\u00f3n de Inframundo",gf:"Configura tus ajustes de porcentaje de curaci\u00f3n desde la pesta\u00f1a de curaci\u00f3n y aseg\u00farate de que est\u00e9 activada. Si ingresar al inframundo te desconecta, ve al lobby y activa la casilla de inicio de sesi\u00f3n autom\u00e1tico.",df:"Dificultad del Inframundo",Vd:"Entrar Autom\u00e1ticamente al Inframundo: / Inframundo Mode",Ei:"\u00bfUsar Movilizaci\u00f3n si los puntos = 0",Ii:"\u00bfUsar Rub\u00edes?",ye:"\u00bfSalir del inframundo si no hay puntos?",
ri:"El bot intentar\u00e1 usar villa medici primero, si no la tienes, usar\u00e1 poci\u00f3n de curaci\u00f3n. No olvides activar el interruptor de Curar.",zi:"El ingreso autom\u00e1tico al inframundo deshabilitar\u00e1 la mazmorra/arena/circo al ingresar al inframundo.",bl:"Ajustes de Curaci\u00f3n del Inframundo",Hi:"\u00bfUsar Villa Medici?",Fi:"\u00bfUsar Poci\u00f3n de Curaci\u00f3n?",dg:"INFO: El bot buscar\u00e1 objetos en el mercado cada ciertos minutos, lo que puede detener los ataques durante la b\u00fasqueda.",
ue:"Habilitar B\u00fasqueda en el Mercado:",eg:"Intervalo de B\u00fasqueda en el Mercado en Minutos:",fg:"Se sugieren 10 minutos.",rf:"Ajustes de Objetos:",pf:"Nombre del Objeto Incluye",G:"Precio M\u00e1ximo",sf:"Tipo de Objeto",qf:"Rareza del Objeto",de:"\u00bfComprar con V\u00ednculo Espiritual?",uf:"Objetos para Comprar",tf:"Intentar comprar objetos con paquetes si alguno coincide con el precio m\u00e1ximo ingresado:",be:"Objetos Comprados:",hj:"Porcentaje de Curaci\u00f3n",uk:"\u00bfComprar Comida en la Tienda?",
vk:"\u00bfUsar Curaci\u00f3n de Paquete?",rk:"\u00bfUsar Cervisia?",tk:"\u00bfUsar Huevos?",zl:"\u00daltima Vez Usado",location:"Ubicaci\u00f3n",Strength:"Fuerza",Dexterity:"Destreza",Agility:"Agilidad",Constitution:"Constituci\u00f3n",Charisma:"Carisma",Intelligence:"Inteligencia",mi:"Ajustes de Entrenamiento",ni:"Selecciona los atributos que deseas entrenar. Se entrenar\u00e1 una vez que tengas suficiente oro.",N:"Siguiente acci\u00f3n",vj:"No",wj:"Normal",Dl:"Oponente",El:"Nivel del Oponente",
Ij:"Misiones",random:"Aleatorio",Nl:"Ajustes",Yl:"Pronto...",type:"Haz clic en los \u00edconos para activar los tipos de misiones.",em:"S\u00ed",A:"Subasta/B\u00fasqueda",Cd:"Agregar objetos",nk:"Almacenar Recursos Forjados autom\u00e1ticamente",$l:"Enviar",xl:"Intervalo : ",ml:"Habilitar Puja Autom\u00e1tica",nl:"No pujar si el miembro del gremio ya ha pujado",bm:"Tutorial",hc:"Selecciona entre los botones de arriba si deseas enfrentar al oponente de nivel m\u00e1s bajo en la arena o al oponente de nivel m\u00e1s alto. M\u00e1s usuarios ralentizar\u00e1n el bot.",
el:"Para empezar, agrega un objeto a la lista (p. ej., `Lucius`). Una vez agregado, la herramienta buscar\u00e1 el objeto y mostrar\u00e1 los resultados de la b\u00fasqueda en el lado izquierdo de la pantalla. Tambi\u00e9n se buscar\u00e1 para fines de subasta autom\u00e1tica. Si habilitas la puja autom\u00e1tica, la herramienta buscar\u00e1 el objeto a intervalos regulares seg\u00fan el n\u00famero que ingreses en el cuadro de intervalo. Si la herramienta encuentra el objeto y tienes suficiente dinero, pujar\u00e1 autom\u00e1ticamente por ti. *Nota* para buscar objetos \u00fanicos en las tiendas, debes agregar al menos 1 objeto aleatorio en la lista de b\u00fasqueda.",
pl:"El n\u00famero de criatura se puede seleccionar desde los botones de arriba. El n\u00famero 1 representa la criatura m\u00e1s a la izquierda. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",Yi:"Selecciona la dificultad de la mazmorra de arriba. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",ij:"Ajustes de Curaci\u00f3n",Zi:"Almacena el oro excedente en el Gremio comprando objetos del mercado del gremio. -> M\u00edn. Oro",
Al:"Mover Todo",Bl:"Mover Seleccionados",il:"Curaci\u00f3n Autom\u00e1tica",jl:"Porcentaje de Curaci\u00f3n Autom\u00e1tica",dm:"Ruby",Lg:"Ajustes Generales",Mj:"Vender Todo",Nj:"Vender Seleccionados",ga:"Armas",da:"Escudos",W:"Armadura de Pecho",Z:"Cascos",Y:"Guantes",ea:"Zapatos",ca:"Anillos",V:"Amuletos",Ci:"Usables",Bi:"Mejoras",dh:"Recetas",sg:"Pergamino de Mercenario",fh:"Refuerzos",mg:"Vender Comida",Gb:"Cambiar a Comida"},Mh={cg:"Erreur de march\u00e9, Veuillez ajouter \u00e0 nouveau les \u00e9l\u00e9ments et r\u00e9essayer.",
Lb:"Pas assez d`espace dans l`inventaire pour les objets \u00e0 vendre.",ck:"Faire fondre d\u2019abord les couleurs plus \u00e9lev\u00e9es ?",cc:"Attaquer uniquement la liste de joueurs ?",dc:"Lorsque cette option est activ\u00e9e, le bot n\u2019attaquera que les joueurs figurant sur la liste des joueurs. Si cette option n\u2019est pas activ\u00e9e, le bot attaquera des joueurs al\u00e9atoires.",Kk:"Vos param\u00e8tres d'exp\u00e9dition sont incorrects ou il y a des donn\u00e9es de page inattendues !",
Lk:"Votre param\u00e8tre d'exp\u00e9dition est incorrect ! Vous avez s\u00e9lectionn\u00e9 un monstre d\u00e9sactiv\u00e9, ce qui est incorrect.",Yk:"R\u00e9initialiser uniquement tous les \u00e9l\u00e9ments du monde souterrain avec la couleur s\u00e9lectionn\u00e9e?",Ca:"Priorit\u00e9",Vb:"D\u00e9finir la priorit\u00e9",Rg:"Points",Kh:"Stat",Si:"Collecter de l`or",Oj:"Vendre des objets des Enfers?",uj:"Le bot cherchera le nid dans chaque action, pas seulement lors des exp\u00e9ditions.",sj:"Type de recherche de nid",
qj:"Ne rien faire",rj:"Recherche rapide",tj:"Recherche approfondie",Kl:"After expedition points are consumed, travel to Germania to consume Dungeon points",xk:"Cliquez ici si la r\u00e9paration se bloque",Mk:"Quand les PV sont en dessous, utilisez soin",Ng:"R\u00e9paration Partielle",af:"R\u00e9paration Compl\u00e8te",Mg:"R\u00e9paration Partielle ou Compl\u00e8te",se:"Activer la Limite",kj:"Limite",lj:"Si vous voulez limiter le nombre de fois que vous souhaitez attaquer l'ennemi, activez cette option et d\u00e9finissez la limite. Le bot continuera \u00e0 attaquer le reste des ennemis apr\u00e8s avoir fini d'attaquer le monstre s\u00e9lectionn\u00e9.",
yi:"Monde Souterrain",pi:"Am\u00e9liorations du Monde Souterrain",si:"Utiliser les pouvoirs des dieux apr\u00e8s \u00eatre entr\u00e9 dans le monde souterrain?",ti:"S\u00e9lectionnez les dieux pour utiliser leurs pouvoirs:",ui:"Utiliser un Buff d'Arme sur l'arme?",vi:"Utiliser un Buff d'Armure sur l'\u00e9quipement suivant:",Hk:"Le temps de recharge est de 30 minutes. Si vous n'avez pas de costume, le bot r\u00e9initialisera le temps de recharge \u00e0 0.",Zk:"S\u00e9lectionner les Couleurs",$a:"Forge de Vulcain",
eb:"Bouclier de Terre de Feronia",fb:"Puissance Fluide de Neptune",gb:"Libert\u00e9 A\u00e9rienne d'Aelous",hb:"Brouillard Mortel de Pluton",ib:"Souffle de Vie de Junon",jb:"Armure d'\u00c9cailles des Montagnes de Col\u00e8re",kb:"Yeux d'Aigle",lb:"V\u00eatement d'Hiver de Saturne",ab:"Armure de Taureau de Bubona",bb:"V\u00eatements de Voleur de Mercure",cb:"Robe de Lumi\u00e8re de R\u00e2",ne:"N`entrez pas dans le monde souterrain avec le costume des enfers",me:"Si vous ne voulez pas entrer dans le monde souterrain en portant le costume des enfers, activez cette option",
lg:"Paquets",gg:"Inventaire",M:"Prix Min.",L:"Combien",Fb:"Vendre des Articles",Eb:"Rechercher dans",hg:"Couleur du Mat\u00e9riau",Db:"Couleur de l`Article",og:"Entrep\u00f4t",Aa:"Basculer vers Mat\u00e9riaux",Hb:"Basculer vers Articles",ng:"Vendre des Mat\u00e9riaux",xa:"Veuillez entrer un nom d`article valide, une fourchette de prix et une quantit\u00e9.",ya:"Aucun article correspondant trouv\u00e9 dans les emplacements de recherche s\u00e9lectionn\u00e9s.",za:"Tous les articles ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",
Sk:"Tous les mat\u00e9riaux ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",jg:"Si vous souhaitez vendre des articles \u00e0 un prix fixe, vous pouvez entrer la m\u00eame valeur pour le prix minimum et maximum.",kg:"Cette fonctionnalit\u00e9 est encore exp\u00e9rimentale, utilisez-la avec prudence. Si vous ne fixez pas un prix, les articles seront list\u00e9s al\u00e9atoirement entre le prix minimum et maximum que vous entrez.",Dk:"D\u00e9finit le maximum d`or que le bot d\u00e9pensera par cycle.",
Va:"Le bot commencera \u00e0 faire des offres sur tout article de nourriture, si activ\u00e9. Vous n`avez pas besoin d`activer les bascules gladiateur/mercenaire.",Md:"Le bot ne fera pas d`offres sur les ench\u00e8res des alli\u00e9s.",Nd:"Ignorer la combinaison Pr\u00e9fixe/Suffixe lors de la recherche d`un objet \u00e0 la vente aux ench\u00e8res.",Vj:"S\u00e9lectionnez les types d\u2019objets que vous souhaitez fondre.",Wj:"S\u00e9lectionnez les couleurs que vous souhaitez fondre.",Xj:"S\u00e9lectionnez le niveau des objets que vous souhaitez fondre.",
Yj:"S\u00e9lectionnez le marteau que vous voulez utiliser.",Zj:"Notez que le cercle vert et rouge \u00e0 c\u00f4t\u00e9 de la premi\u00e8re case sert \u00e0 activer/d\u00e9sactiver la r\u00e8gle.",$j:"Si vous voulez fondre al\u00e9atoirement n\u2019importe quelle couleur ou type, vous pouvez activer `Fondre al\u00e9atoirement si aucune condition n\u2019est remplie? (Derni\u00e8re option activ\u00e9e dans la vid\u00e9o du tutoriel)",Kj:"R\u00e9parer avant de fondre",Oe:"S\u00e9lectionner Monstre",
Ce:"Utiliser Sablier/Rubis?",Jk:"Utiliser Rubis?",Fe:"Utiliser Mobilisation?",Ee:"Utiliser Potion de Vie?",Be:"Pourcentage de Soin (%)",Me:"Nombre d'Attaques",De:"Intervalle d'Attaque (en secondes)",ze:"Attaques Effectu\u00e9es",Ae:"Sabliers Restants",Ke:"Note : Utilise des potions de vie pour gu\u00e9rir, pas de nourriture.",Le:"Note : Si les attaques s'arr\u00eatent pr\u00e9matur\u00e9ment, essayez 'R\u00e9initialiser les Attaques'.",Pe:"D\u00e9marrer",Ne:"R\u00e9initialiser",Qe:"Arr\u00eater",
Re:"Param\u00e8tres d'Exp\u00e9dition (Cliquez pour minimiser)",Ge:"Monstre 1",He:"Monstre 2",Ie:"Monstre 3",Je:"Monstre 4",Vk:"R\u00e9parer avant de fondre",Qi:"Cette option utilisera cervisia lorsque votre premium expirera.",xj:"Cette option permet d'activer et de choisir les huiles parmi les r\u00e9compenses des dieux. Elle peut utiliser les huiles num\u00e9ro 1 et 3 sur le personnage, mais la num\u00e9ro 2 ne sera prise que pour les paquets.",Oi:"Cette option utilisera des buffs au moment que vous avez fix\u00e9. Elle trouvera les buffs dans les paquets et les appliquera au personnage.",
mj:"Cette option vous m\u00e8nera aux enfers. N'oubliez pas d'activer la Connexion Automatique depuis l'onglet Extras, sinon vous pourriez \u00eatre d\u00e9connect\u00e9 en entrant aux enfers [Bug du Jeu]",ec:"Cette option n'attaquera que la liste ar\u00e8ne/cirque. Si ce n'est pas possible, le bot sautera.",Hj:"Cette option est uniquement pour les licences premium. Elle simule l'attaque avant d'attaquer un utilisateur pour un taux de victoire de 75%.",Pd:"Vous n'avez pas besoin d'activer l'interrupteur principal de l'ench\u00e8re pour activer cette option.",
qk:"Cette option rafra\u00eechira la page chaque seconde quand l'ench\u00e8re est en \u00e9tat -Tr\u00e8s Court- pour ench\u00e9rir constamment et gagner l'ench\u00e8re.",Tj:"Si aucune des conditions de fusion n'est remplie, il fusionnera al\u00e9atoirement. Assurez-vous de s\u00e9lectionner le type et la couleur de l'objet.",Uj:"Cette option ne fusionnera que les objets de l'inventaire. Elle ignorera les objets dans les paquets.",Wa:"Articles aux Ench\u00e8res",rg:"Articles de Mercenaire",Xb:"Articles de Boutique",
Ai:"Articles Uniques",Pj:"D\u00e9finir le fond en noir [Augmente les performances]",Qj:"D\u00e9placer les boutons GLDbot en bas \u00e0 gauche?",Ri:"Attaquer le cirque sans soigner",pk:"Prendre l'or des paquets si n\u00e9cessaire?",am:"L'or a \u00e9t\u00e9 pris des paquets pour l'entra\u00eenement",Gd:"Aucun or n'a \u00e9t\u00e9 trouv\u00e9 dans les paquets pour l'entra\u00eenement",lk:"Objets R\u00e9par\u00e9s",ek:"Attaques en Ar\u00e8ne",gk:"Attaques au Cirque",Ed:"Objets R\u00e9initialis\u00e9s",
jk:"Attaques en Exp\u00e9dition",ik:"Attaques en Donjon",mk:"Attaques dans l'Underworld",fk:"Argent Gagn\u00e9 en Ar\u00e8ne",hk:"Argent Gagn\u00e9 au Cirque",Zl:"Objets Fondus",kk:"Or Recycl\u00e9",dj:"Bataille de Guilde",fj:"Param\u00e8tres de Guilde",ej:"Guild Name",rl:"Attaquera les guildes au hasard.",Pi:"R\u00e9initialiser les Statistiques",Lh:"Stockage de l'Or",cj:"Attaquer une Guilde Al\u00e9atoire",Cl:"GLDbot\u00a0: utilisez les d\u00e9s pour rafra\u00eechir la bo\u00eete myst\u00e8re et trouver des objets de valeur avant de les ouvrir (etc. Costumes). Cliquez sur \u00ab\u00a0D\u00e9marrer\u00a0\u00bb pour ouvrir les coffres.\u00a0",
Pc:"Bois",Fc:"Cuivre",Jc:"Fer",Lc:"Cuir",Qc:"Fil de laine",Gc:"Boule de coton",Ic:"Chanvre",Hc:"Bande de gaze",Mc:"Toile de lin",Kc:"Jute",Oc:"Bande de velours",Nc:"Fil de soie",Yc:"Fourrure",Sc:"\u00c9clat osseux",ad:"\u00c9caille",Vc:"Griffe",Xc:"Canine",Wc:"\u00c9caille de dragon",Tc:"Corne de taureau",$c:"Glande \u00e0 venin",Uc:"Touffe de poils de Cerb\u00e8re",Zc:"\u00c9caille d`Hydre",bd:"Plume du Sphinx",cd:"Cuir de Typhon",Cc:"Lapis-lazuli",wc:"Am\u00e9thyste",vc:"Ambre jaune",xc:"Aigue-marine",
Dc:"Safir",Ac:"Grenat",zc:"\u00c9meraude",yc:"Diamant",Bc:"Jaspe",Ec:"Sugilith",qc:"Venin de scorpion",tc:"Teinture d`endurance",mc:"Antidote",lc:"Adr\u00e9naline",sc:"Teinture de r\u00e9v\u00e9lation",pc:"Potion de perception",nc:"Essence de reflet",oc:"Flacon du rayonnement",uc:"Eau de l`oubli",rc:"Essence d`\u00e2me",Bd:"Sceau aquatique",vd:"Rune protectrice",td:"Gravure terrestre",Ad:"Totem gu\u00e9risseur",zd:"Talism\u00e1n de puissance",xd:"Pierre de fortune",ud:"Pierre du feu",yd:"Rune temp\u00e9tueuse",
wd:"Rune t\u00e9n\u00e9breuse",gd:"Cristal",fd:"Bronze",ld:"Obsidienne",od:"Argent",pd:"Soufre",jd:"Minerai d`or",nd:"Quartz",md:"Platine",ed:"Almandin",hd:"Cuprit",kd:"Pierre infernale",Li:"Attaquer al\u00e9atoirement?",Mi:'D\u00e9sactivez \u00e9galement le param\u00e8tre "Trier les joueurs dans l\'ar\u00e8ne par niveau" dans crazy-addon.',$g:"Accepter uniquement les qu\u00eates bas\u00e9es sur le type de dieu.",Xa:"Buff Automatique",ce:"Utiliser uniquement en enfer?",Gg:"Nouvelle R\u00e8gle",Eg:"Le Nom Contient",
isUnderworldItem:"Est-ce un objet du monde souterrain?",kf:"Ignorer les Mat\u00e9riaux",wk:"Utiliser la pri\u00e8re",Gi:"Utiliser le sacrifice",sk:"Utiliser des v\u00eatements pour entrer dans le monde souterrain",xi:"Lorsque vous \u00eates dans le monde souterrain, n`acceptez que les qu\u00eates li\u00e9es au monde souterrain ?",wi:"Si activ\u00e9, vous devez entrer les noms des objets du monde souterrain. Si le bot trouve ces objets dans le monde souterrain, il acceptera la qu\u00eate.",cl:"Objet de Qu\u00eate du Monde Souterrain",
ol:"Entrez le nom du mat\u00e9riau",Gk:"Le robot adore les d\u00e9s ! Ils l'aident \u00e0 trouver des v\u00eatements dans les coffres. Mais s'il n'y a pas de d\u00e9s, le robot ouvre quand m\u00eame les coffres, en esp\u00e9rant trouver des v\u00eatements cool (mais il pourrait ne rien trouver !)",Sj:"Fondre les coffres",re:"Activer l'ar\u00e8ne",Sg:"Prioriser la liste des ar\u00e8nes ?",Tg:"Prioriser la liste des cirques ?",je:"D\u00e9sactiver le menu de journalisation",oh:"Valeur minimale de r\u00e9compense en or",
ph:"Le robot ench\u00e9rira sur des articles al\u00e9atoires.",ah:"Si activ\u00e9, le Focus sur les qu\u00eates suivra le chemin le plus court pour terminer le donjon.",Nh:"Lancer les d\u00e9s automatiquement ?",Oh:"Utilisez le lancer de d\u00e9s avec prudence, il continuera \u00e0 utiliser le premier d\u00e9 jusqu'\u00e0 ce que vous d\u00e9sactiviez l'option.",uh:"Progression de la recherche",ih:"Le temps de recharge pour la r\u00e9paration par d\u00e9faut est de 10 minutes.",Bg:"Condition minimale",
he:"Article actuel sur l'\u00e9tabli [Effacer si le bot se met en pause de mani\u00e8re inattendue]",Gf:"Ressources de forge stock\u00e9es avec succ\u00e8s dans l'horreum.",Cf:"V\u00e9rification du march\u00e9 pour les articles...",Ab:"Article d\u00e9plac\u00e9 sur l'\u00e9tabli.",Tf:"Article r\u00e9par\u00e9 et \u00e9quip\u00e9 avec succ\u00e8s.",Uf:"Article r\u00e9par\u00e9 avec succ\u00e8s.",Qk:"La r\u00e9paration a \u00e9chou\u00e9. La page sera rafra\u00eechie.",Qf:"Ramassage des mat\u00e9riaux...",
bg:"En attente de r\u00e9paration...",Sf:"La r\u00e9paration a commenc\u00e9 pour .",wa:"R\u00e9paration : D\u00e9placement de l'article de l'inventaire vers le sac",Rf:"R\u00e9paration : D\u00e9placement de l'article de l'\u00e9tabli vers le paquet.",ua:"Impossible de trouver suffisamment de mat\u00e9riaux. D\u00e9sactivation de l'emplacement de r\u00e9paration ",Nf:"Recherche d'articles \u00e0 acheter pour cacher de l'or aux ench\u00e8res...",zf:"V\u00e9rification des articles expir\u00e9s dans les paquets...",
Af:"R\u00e9initialisation de l'article r\u00e9ussie.",Bf:"Aucun espace vide ou or pour r\u00e9initialiser.",Hf:"Assurez-vous d'avoir les droits de vente sur le march\u00e9 de guilde !",ub:"Pas assez d'or ou aucun article \u00e0 acheter. Attente de 30 secondes pour rafra\u00eechir.",wb:"Le magasin a \u00e9t\u00e9 rafra\u00eechi.",xb:"Erreur lors de la gu\u00e9rison.",Kf:"Pas de Rubis ou de Tissu, d\u00e9sactivation des options.",Pk:"Aucun article de gu\u00e9rison trouv\u00e9 dans les paquets.",yb:"Aucun article appropri\u00e9 trouv\u00e9",
Lf:"Les aliments ont \u00e9t\u00e9 ramass\u00e9s. Fin du processus.",Mf:"Au moins un aliment a \u00e9t\u00e9 ramass\u00e9. Fin du processus.",zb:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",If:"Obtention de la nourriture des paquets.",Jf:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",vb:"Plus d'articles de gu\u00e9rison. Attente de 30 secondes.",tb:"Points de vie r\u00e9cup\u00e9r\u00e9s.",va:"Rien \u00e0 faire alors je vais prier !",
Yf:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9 et Villa Medici.",Zf:"En attente de Villa Medici, actualisation dans 60 secondes.",$f:"Quitt\u00e9 les Enfers.",ag:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9.",Of:"V\u00e9rification des huiles divines...",Pf:"Les huiles divines ont \u00e9t\u00e9 ramass\u00e9es.",sa:"Attaque r\u00e9ussie du joueur dans l'AR\u00c8NE : ",ta:"Attaque r\u00e9ussie du joueur dans le CIRQUE : ",xf:"V\u00e9rification des ench\u00e8res ! Veuillez patienter...",
yf:"Mise aux ench\u00e8res d'articles. Veuillez patienter...",Vf:"Article fondu automatiquement : ",Wf:"Fusion de l'article : ",Bb:"Pas assez d'or pour fondre. Or requis : ",Xf:"FONDRE : Recherche d'articles \u00e0 fondre...",Rk:"Recherche d'articles \u00e0 fondre...",Df:"V\u00e9rification de la disponibilit\u00e9 des costumes...",Ff:"Donn\u00e9 : ",Ef:"Lancer des d\u00e9s...",Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",Ye:"Attention\u00a0: activez cette fonctionnalit\u00e9 apr\u00e8s avoir d\u00e9verrouill\u00e9 la cr\u00e9ature que vous souhaitez attaquer, elle n'attaquera pas automatiquement pour d\u00e9bloquer le monstre.",
Ve:"Farm Enemy",Wd:"Connexion Automatique",Xd:"Vous devez autoriser les pop-ups depuis l'\u00e9cran du lobby de GameForge. Consultez la documentation pour savoir comment faire.",Og:"Mettre le Bot en Pause",Pg:"Mettre le Bot en pause (Minutes)",Te:"Date d'Expiration",Jg:"Acheter uniquement de la nourriture ?",Kg:"Si vous activez cette option, le bot ignorera vos s\u00e9lections et ach\u00e8tera automatiquement de la nourriture sans rien saisir.",Jb:"Montant total maximal d'or \u00e0 d\u00e9penser",
Ib:"Montant maximal d'or par aliment \u00e0 d\u00e9penser",Ig:"Le bot v\u00e9rifiera les huiles toutes les 60 minutes",fi:"D\u00e9finit une minuterie pour v\u00e9rifier les temps de fusion.",ci:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion lorsque vous n'avez pas d'or.",ei:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion si vous n'avez pas l'objet disponible.",Yh:"D\u00e9finit une minuterie pour r\u00e9parer et v\u00e9rifier vos objets.",Xh:"D\u00e9finit une minuterie pour v\u00e9rifier l'or retenu sur le march\u00e9 de la guilde.",
Th:"D\u00e9finit une minuterie pour l'option de retenue d'or aux ench\u00e8res.",Ph:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans l'ar\u00e8ne pour attaquer.",Uh:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans le cirque pour attaquer.",li:"D\u00e9finit une minuterie pour entra\u00eener vos statistiques.",$h:"D\u00e9finit une minuterie pour r\u00e9initialiser les objets expir\u00e9s.",ji:"D\u00e9finit une minuterie pour stocker les mat\u00e9riaux de forge dans l'horreum.",
Rh:"D\u00e9finit une minuterie pour v\u00e9rifier les ench\u00e8res des gladiateurs et des mercenaires.",bi:"D\u00e9finit une minuterie pour rechercher des objets aux ench\u00e8res et en boutique.",Vh:"D\u00e9finit la minuterie d'envoi de dons \u00e0 la guilde.",bf:"Or D\u00e9plac\u00e9",oe:"Ne vendez pas d'articles de la fonderie et de la liste des ench\u00e8res",vh:"Automatisation de la Boutique",xh:"Param\u00e8tres de Recherche d'Objets",wh:"Utilisez cet outil pour rechercher des objets. Ajoutez simplement les objets \u00e0 la liste, sp\u00e9cifiez la quantit\u00e9 de tissu et lancez la recherche.",
yh:"Tissus \u00e0 Utiliser :",zh:"Combien de tissus utiliser ?",fa:"Full Entrez le Nom de l'Objet",Wb:"Entrez le Niveau de l'Objet",Bh:"Qualit\u00e9 de l'Objet",Ah:"Nom de l'Objet Ici",Ch:"Commencer la Recherche",Dh:"Sauter et Continuer",Eh:"Arr\u00eater la Recherche",Ze:"Acheter le moins cher ou le plus cher?",Dg:"Le Plus Cher",ee:"Le Moins Cher",Da:"S\u00e9lectionnez une Option",te:"Mettre en surbrillance les objets du monde souterrain",$e:"Concentrez-vous sur la qu\u00eate\u00a0?",cm:"Utiliser Ruby s'il n'y a pas de tissu ?",
Ya:"\u00c9vitez d'attaquer les m\u00eames personnes pour ne pas \u00eatre signal\u00e9. \u00catre signal\u00e9 augmente les chances d'\u00eatre banni.",Rl:"Fondre Green ?",Vg:"Ne pas accepter les qu\u00eates al\u00e9atoires si des filtres sont entr\u00e9s ?",Rc:"Qualit\u00e9 maximale des mat\u00e9riaux \u00e0 utiliser",$i:"Activer la recherche de mercenaires",yl:"Cliquez sur `Vendre Tout S\u00e9lectionn\u00e9` pour vendre tous les objets. Assurez-vous d`avoir de l`espace vide de 2x3 dans votre premi\u00e8re (1) sac. Pour collecter de l`or en masse, filtrez l`or et utilisez `S\u00e9lectionner S\u00e9lectionn\u00e9s ou Tout S\u00e9lectionner`.",
dk:"\ud83d\udd25 : Ajoute l`objet \u00e0 la liste de fusion.",Ni:"\ud83d\udd28 : Ajoute l`objet \u00e0 la liste des ench\u00e8res.",Jj:"Actualisez la boutique avec du tissu lorsqu`elle est pleine",Gl:"Page:",Fj:"Arr\u00eater",Dj:"Vendre Cette Page",Aj:"S\u00e9lectionner S\u00e9lectionn\u00e9s",zj:"Tout S\u00e9lectionner",Gj:"Param\u00e8tres d`Emballage Automatique",Ej:"Envoyer les Ressources",Bj:"Vendre Tout S\u00e9lectionn\u00e9",na:"Type d`Objet",pa:"Armes",U:"Boucliers",O:"Armures",S:"Casques",
R:"Gants",P:"Bottes",oa:"Anneaux",la:"Amulettes",Ka:"Utilisables (Nourriture)",Pa:"Am\u00e9liorations",yj:"Boosts",Ma:"Recettes",La:"Mercenaires",Oa:"Outils de Forge",Na:"Parchemins",sd:"Renforcements",qd:"Objets d`\u00c9v\u00e9nement",rd:"Mat\u00e9riaux de Forge",Fl:"Or",Ja:"Tout",Hl:"Qualit\u00e9",qa:"Blanc",C:"Vert",B:"Bleu",D:"Violet",J:"Orange",T:"Rouge",Cj:"Options de Vente",Rj:"Ignorer la Combinaison Pr\u00e9fixe/Suffixe ?",gj:"Combien de nourriture acheter/cueillir ?",Vi:"Normal",Ui:"Interm\u00e9diaire",
Ti:"Difficile",Ga:"Standard",Ll:"R\u00e9paration Correction d`Enlisement",Nk:"D\u00e9sactivez l`Entr\u00e9e en Enfer si vous souhaitez d\u00e9sactiver le Donjon/Cirque/Arenas. Si vous \u00eates entr\u00e9 en Enfer manuellement, vous devrez activer le Mode Enfer.",fe:"Choisir le costume des Enfers",Ji:"Porter le costume des Enfers quand il est disponible ?",oi:"Tutoriel dentra\u00eenement : Indiquez combien de fois vous souhaitez entra\u00eener les statistiques et d\u00e9finissez leurs priorit\u00e9s. Le bot nentra\u00eenera pas sans quune priorit\u00e9 soit d\u00e9finie. Si une priorit\u00e9 est configur\u00e9e mais quil ne reste plus de statistiques \u00e0 entra\u00eener, le bot continuera avec la statistique s\u00e9lectionn\u00e9e.",
ll:"Quest",Mh:"Conserver l'Or aux Ench\u00e8res ?",Qg:"Mettre en Pause le Bot Al\u00e9atoirement pour travailler comme [Phase de Test] :",kh:"R\u00e9initialiser les Objets Expir\u00e9s",Qb:"Remarque : En activant cette option, le bot vendra les objets expir\u00e9s \u00e0 venir des paquets sur le march\u00e9 de la guilde, puis annulera pour r\u00e9initialiser le temps d'expiration. La guilde est requise. Assurez-vous d'avoir un espace vide de 3x3 dans vos sacs.",aa:"Conserver l'Or : Le bot conservera cet or dans le sac :",
pg:"Or Maximum : Le bot d\u00e9pensera lorsque l'or sera sup\u00e9rieur \u00e0",Dd:"Fonderie",Wl:"Fonderie Param\u00e8tres",ak:"Fonderie Liste",Xl:"Ajouter un pr\u00e9fixe ou un suffixe, une fois qu`il l`aura trouv\u00e9 dans les paquets, il le fondera automatiquement:",Vl:"Fusion d'item:",ic:"Cliquez sur l`\u00e9l\u00e9ment que vous souhaitez r\u00e9parer. Essayez de faire de la place dans votre inventaire",dl:"S`applique-t-il uniquement aux mercenaires ?",hl:"L'ench\u00e8re ach\u00e8te que lorsque le march\u00e9 est proche de la fin.",
gl:"Assurez-vous que le SECOND ONGLET D'INVENTAIRE est vide. Le bot trouvera et mettra l'objet dans le deuxi\u00e8me onglet puis la prochaine fois que la page est actualis\u00e9e, il fondra l'objet.",jj:"Gu\u00e9risseur & Buffs",Ml:"Pas assez d'or pour fondre. Or requis:",Pl:"Ench\u00e8re ignor\u00e9e: un membre de la guilde a d\u00e9j\u00e0 mis\u00e9 pour l'objet ",Ol:"Ench\u00e8re ignor\u00e9e: Vous avez d\u00e9j\u00e0 mis\u00e9 pour cet objet ",advanced:"Avanc\u00e9e",arena:"Ar\u00e8ne",ja:"Attaque automatique",
fc:"Eviter l'attaque",ha:"Ajouter un joueur",ia:"Entrez le nom du joueur (Same Server)",tl:"Arr\u00eater le bot en cas de manque de nourriture?",circusTurma:"Circus Turma",Wi:"Difficult\u00e9",dungeon:"Donjon",Xi:"Param\u00e8tres du donjon",eventExpedition:"Event Exp\u00e9dition",expedition:"Expedition",aj:"Param\u00e8tres d'expedition",Lj:"S\u00e9lectionner un monstre",vl:"Plus haut",ul:"Mettez vos objets de soin dans la premi\u00e8re page de votre inventaire",nj:"Dans",rh:"Utiliser les v\u00eatements de travail pour renouveler la boutique?",
hj:"Pourcentage de gu\u00e9rison",uk:"Acheter de la nourriture dans la boutique?",vk:"Utiliser la gu\u00e9rison \u00e0 partir du paquet?",rk:"Utiliser Cervisia?",tk:"Utiliser des oeufs?",zl:"Dernier utilis\u00e9",location:"Emplacement",Strength:"Force",Dexterity:"Adresse",Agility:"Agilit\u00e9",Constitution:"Constitution",Charisma:"Charisme",Intelligence:"Intelligence",mi:"Param\u00e8tres d'entrainement",ni:"S\u00e9lectionnez les states que vous souhaitez entra\u00eener. L'entra\u00eenement commencera une fois que vous aurez assez d'or.",
N:"Action suivante",vj:"Non",wj:"Normal",Dl:"Adversaire",El:"Niveau de l'adversaire",Ij:"Qu\u00eates",random:"Al\u00e9atoire",Nl:"Param\u00e8tres",Yl:"Bient\u00f4t...",type:"Cliquez sur les ic\u00f4nes pour activer les types de qu\u00eate.",em:"Oui",A:"Ench\u00e8re",Cd:"Ajouter des objets",nk:"Stocker automatiquement les ressources de la forge",$l:"Soumettre",xl:"Intervalle : ",ml:"Activer l'ench\u00e8re automatique",nl:"Ne pas ench\u00e9rir si un membre de la guilde a d\u00e9j\u00e0 ench\u00e9ri",
bm:"Tutoriel",hc:"S\u00e9lectionnez \u00e0 partir des boutons ci-dessus pour choisir si vous souhaitez affronter l'adversaire le plus faible de l'ar\u00e8ne ou l'adversaire de niveau le plus \u00e9lev\u00e9.",el:"Pour commencer, ajoutez un article \u00e0 la liste (par exemple, `Lucius`). Une fois ajout\u00e9, l'outil recherchera l'article et affichera les r\u00e9sultats de la recherche sur le c\u00f4t\u00e9 gauche de l'\u00e9cran. Il sera \u00e9galement recherch\u00e9 \u00e0 des fins d'ench\u00e8re automatique. Si vous activez l'ench\u00e8re automatique, l'outil recherchera l'article \u00e0 des intervalles r\u00e9guliers en fonction du nombre que vous mettez dans la case d'intervalle. Si l'outil trouve l'article et que vous avez assez d'argent, il ench\u00e9rira automatiquement pour vous. *Note* pour rechercher des articles uniques dans les boutiques, vous devez ajouter au moins 1 article al\u00e9atoire \u00e0 la liste de recherche.",
pl:"Le num\u00e9ro de la cr\u00e9ature peut \u00eatre s\u00e9lectionn\u00e9 \u00e0 partir des boutons ci-dessus. Le num\u00e9ro 1 repr\u00e9sente la cr\u00e9ature la plus \u00e0 gauche. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",Yi:"S\u00e9lectionnez la difficult\u00e9 du donjon depuis le dessus. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",ij:"Param\u00e8tres de gu\u00e9rison",Zi:"Stocker l'or exc\u00e9dentaire dans la guilde en achetant des objets du march\u00e9 de la guilde. -> Or Min.",
Al:"D\u00e9placer tout",Bl:"D\u00e9placer les s\u00e9lectionn\u00e9s",il:"Auto gu\u00e9rison",jl:"Pourcentage de gu\u00e9rison automatique",dm:"Ruby",Lg:"Param\u00e8tres g\u00e9n\u00e9raux",Mj:"Tout vendre",Nj:"Vendre s\u00e9lectionn\u00e9s",ga:"Armes",da:"Boucliers",W:"Armure de poitrine",Z:"Casques",Y:"Gants",ea:"Chaussures",ca:"Anneaux",V:"Amulettes",Ci:"Utilisable",Bi:"Am\u00e9liorations",dh:"Nourriture",sg:"Parchemin de mercenaire",fh:"Renforts",Hd:"Ajouter un D\u00e9lai Al\u00e9atoire",Id:"Vous pouvez ajouter un d\u00e9lai al\u00e9atoire au bot ici.",
Pb:"R\u00e9parer",Ql:"Fonder uniquement les Bleus?",Tl:"Fonder uniquement les Violets?",Sl:"Fonder uniquement les Oranges?",bk:"Tout Fondre dans le 2e Onglet?",Ul:"Cela ignorera les s\u00e9lections de couleur",Za:"Effacer l'Historique",Gh:"Fondre",Qd:"Search",Fg:"Ench\u00e8re Automatique",Rd:"Une utilisation excessive des ench\u00e8res peut entra\u00eener un bannissement. Il est recommand\u00e9 de d\u00e9sactiver les autres fonctionnalit\u00e9s d ench\u00e8res pour \u00e9viter les conflits potentiels. Cette fonctionnalit\u00e9 ralentira le bot..",
qh:"Rechercher dans l'Ench\u00e8re des Gladiateurs",th:"Rechercher dans l'Ench\u00e8re des Mercenaires",Zd:"Miser de la Nourriture?",qg:"Mise Maximale",$d:"Miser si le statut est inf\u00e9rieur \u00e0",ae:"Objets Mis\u00e9s",Bk:"Langue de l'Ench\u00e8re",Ck:"\u00c0 partir de la mise \u00e0 jour 2.9.4, veuillez r\u00e9initialiser la langue ou R\u00c9INITIALISER LE BOT. Assurez-vous que toutes les informations sont correctes, sinon les ench\u00e8res ne fonctionneront pas.",Ld:"Vous pouvez ajouter des objets pour les rechercher dans le march\u00e9 et les ench\u00e8res. Il montrera \u00e9galement les objets violets dans le march\u00e9 une fois que vous aurez ajout\u00e9 un objet \u00e0 la liste. Si vous souhaitez activer les ench\u00e8res automatiques, utilisez les options ci-dessous.",
zk:"Utilisez les ench\u00e8res avec prudence!",Ak:"Les ench\u00e8res automatiques font trop de requ\u00eates au serveur et peuvent entra\u00eener un bannissement si elles sont utilis\u00e9es en permanence!",hh:"Renouveler les Points d'\u00c9v\u00e9nement avec des Rubis?",ve:"Activer l'Huile Automatique",Ek:"R\u00e9cup\u00e9rer Automatiquement les Huiles Sacr\u00e9es",Tk:"Vitesse de V\u00e9rification des Qu\u00eates",Ua:"Attaquer les Membres du Gremio ?",Sa:'Ajouter automatiquement les personnes \u00e0 la liste "Attaque" lorsque plus de X OR est vol\u00e9.:',
Ta:'Ajouter automatiquement les personnes \u00e0 la liste "\u00c9viter l\'Attaque" lorsque vous perdez contre elles.:',Tb:"Attaques au Tableau des Scores",ac:"Tr\u00e8s Long",Cb:"Long",Kb:"Moyen",Yb:"Court",bc:"Tr\u00e8s Court",we:"Entrer dans le Monde Souterrain si HP >",bh:"Vitesse de V\u00e9rification des Qu\u00eates",Ug:'Par d\u00e9faut, c\'est "3x". Si le bot pose des probl\u00e8mes avec les qu\u00eates, changez la vitesse des qu\u00eates en fonction de la vitesse de votre serveur.',cf:"S\u00e9lection du Sac de Soins",
xe:"Si vous renouvelez manuellement les points, vous devez cliquer sur le bouton ci-dessus \"Actualiser l'exp\u00e9dition d'\u00e9v\u00e9nement si bloqu\u00e9e !",Ik:"Vous devez activer au moins l'une des options suivantes : exp\u00e9dition, donjon, ar\u00e8ne ou cirque pour commencer l'exp\u00e9dition d'\u00e9v\u00e9nement.",eh:"Actualisez l'exp\u00e9dition d'\u00e9v\u00e9nement en cas de blocage !",mb:"Prot\u00e9ger les Alli\u00e9s ?",$k:"Laissez tous les param\u00e8tres d\u00e9sactiv\u00e9s si vous souhaitez fondre en utilisant les paquets contenant les objets de la liste. Cependant, vous pouvez toujours choisir les couleurs.",
Fk:"Personnage(D\u00e9sactiv\u00e9) / Mercenaire(Activ\u00e9)",Wk:"R\u00e9parer les Deux ?",al:"Minuteries",Timers:"Entrez le nombre de minutes pour chaque minuteur ci-dessous ou laissez-le par d\u00e9faut.",pb:"Activer l'Attaque au Tableau des Scores:",Rb:"S\u00e9lectionner la Fourchette pour Attaquer",Sb:"Le bot attaquera al\u00e9atoirement depuis la liste du tableau des scores.",rb:"Attaque de Ligue",ob:"Activer l'Attaque de Ligue:",Nb:"Attaquer Al\u00e9atoirement",Ob:"Attaquer du plus bas au plus haut",
yk:"Le bot \u00e9vitera par d\u00e9faut d'attaquer les membres du gremio.",Se:"Lieu d'Exp\u00e9dition:",Sd:"Collecter Automatiquement les Bonus:",Fh:"Passer le Boss",qe:"Lieu de Donjon:",nh:"R\u00e9initialiser en cas de perte?",ff:"Param\u00e8tres de l'Enfer",gf:"Configurez vos param\u00e8tres de pourcentage de gu\u00e9rison depuis l'onglet Gu\u00e9rison, et assurez-vous que l'interrupteur Gu\u00e9rison est activ\u00e9. Si l'entr\u00e9e dans le monde souterrain vous d\u00e9connecte, allez au lobby et activez la case \u00e0 cocher Connexion Automatique.",
df:"Difficult\u00e9 de l'Enfer",Vd:"Entrer Automatiquement dans l'Enfer: / Enfer Mode",Ei:"Utiliser Mobilisation si les points = 0",Ii:"Utiliser les Rubis?",ye:"Sortir du monde souterrain s'il n'y a plus de points?",ri:"Le bot essaiera d'abord d'utiliser Villa Medici, si vous ne l'avez pas, il utilisera la potion de gu\u00e9rison. N'oubliez pas d'activer l'interrupteur de Gu\u00e9rison.",zi:"L'entr\u00e9e automatique dans le monde souterrain d\u00e9sactivera le donjon/l'ar\u00e8ne/le cirque lors de l'entr\u00e9e dans le monde souterrain.",
bl:"Param\u00e8tres de Gu\u00e9rison du Monde Souterrain",Hi:"Utiliser Villa Medici?",Fi:"Utiliser la Potion de Gu\u00e9rison?",dg:"INFO: Le bot recherchera les objets sur le march\u00e9 toutes les minutes s\u00e9lectionn\u00e9es, ce qui peut interrompre les attaques pendant la recherche.",ue:"Activer la Recherche sur le March\u00e9:",eg:"Intervalle de Recherche sur le March\u00e9 en Minutes:",fg:"Sugg\u00e9r\u00e9: 10 minutes.",rf:"Param\u00e8tres de l'Objet:",pf:"Le Nom de l'Objet Inclut",G:"Prix Max",
sf:"Type d'Objet",qf:"Raret\u00e9 de l'Objet",de:"Acheter avec Lien d'\u00c2me?",uf:"Objets \u00e0 Acheter",tf:"Tentative d'achat d'objets avec des packs si l'un d'eux correspond au prix maximum indiqu\u00e9.:",be:"Objets Achet\u00e9s:",Zg:"Ignorer le Filtre de Qu\u00eates",Yg:"Saisissez des mots-cl\u00e9s pour filtrer les qu\u00eates que vous ne souhaitez pas accepter. You can also use this to accept quests by their reward using keywords.",X:"Saisir un Mot-cl\u00e9",K:"Ajouter",gh:"Supprimer",ge:"Effacer",
Wg:"Accepter le Filtre de Qu\u00eates",Xg:"Saisissez des mots-cl\u00e9s pour choisir les qu\u00eates \u00e0 accepter. Cela ignorera les types de qu\u00eates",Ea:"Ignorer les Qu\u00eates Temporelles ?",Uk:"Qu\u00eates",Td:"Costume Automatique",Di:"Utiliser le Costume ?",Yd:"Combat de Base",pe:"Combat en Donjon",Ud:"Le bot ne portera Dis Pater Normal et Medium que si vos points d'exp\u00e9dition/donjon sont de 0.",ef:"Param\u00e8tres de Gu\u00e9rison en Enfer",Kd:"Attaquer le Boss quand disponible ?",
sb:"L'attaque en Ligue se d\u00e9sactivera apr\u00e8s 5 attaques infructueuses.",hf:"Huiles Sacr\u00e9es",Ag:"Nom de l'Objet",ba:"Niveau Minimum de l'Objet",Ba:"Qualit\u00e9 Minimum de l'Objet",Jd:"Appliquer/R\u00e9initialiser la Minuterie",lf:"Ignorer la Combinaison de Pr\u00e9fixe/Suffixe",Ki:"Oui",Hg:"Non",Qa:"Ajouter un Pr\u00e9fixe",Ra:"Ajouter un Suffixe",Hh:"Liste des Objets \u00e0 Ignorer pour la Fusion",Mb:"Pr\u00e9fixe",Zb:"Suffixe",mh:"R\u00e9initialiser les Objets Expir\u00e9s",Ih:"Fusionner au Hasard depuis les Paquets ?",
Jh:"Onglet Fusion",qb:"Extras",Od:"Ench\u00e8res",ig:"March\u00e9",$b:"Minuteries",hi:"Fusion",gi:"Fusionner s'il n'y a pas assez d'or",di:"Fusionner s'il n'y a pas d'objet",Fa:"R\u00e9paration",Wh:"Garder de l'Or sur le March\u00e9 de Guilde",Sh:"Garder de l'Or aux Ench\u00e8res",ki:"Entra\u00eenement",Zh:"R\u00e9initialiser les Expir\u00e9s",ii:"Stockage \u00e0 la Forge",Qh:"V\u00e9rification des Ench\u00e8res",ai:"Recherche",v:"Activer",Cg:"Or Minimum",Ub:"S\u00e9lectionner une Heure",nb:"Donner de l'Or \u00e0 la Guilde",
ke:"Il donnera toutes les 5 minutes. Vous pouvez changer l'intervalle depuis l'onglet des minuteries",jf:"Combien souhaitez-vous donner ?",le:"Donner lorsque vous avez plus de >",wf:"Moins de <",jh:"R\u00e9initialiser les Objets Expir\u00e9s et les Autres Param\u00e8tres",lh:"R\u00e9initialiser dans :",Ok:"Maintenez Ctrl (Cmd sur Mac) enfonc\u00e9 pour s\u00e9lectionner plusieurs objets",mf:"Import/Export des Param\u00e8tres",Ue:"Exporter les Param\u00e8tres",nf:"Importer les Param\u00e8tres",tg:"Message \u00e0 Tous les Joueurs",
ug:"[N\u00e9cessite une Cl\u00e9 Ultra Premium, message sur Discord pour l'obtenir.]",vg:"Saisir le message \u00e0 envoyer",ie:"Pour des scripts personnalis\u00e9s, contactez-nous sur Discord",xg:"Envoyer",yg:"Afficher les Joueurs",wg:"Tout S\u00e9lectionner",zg:"Tout D\u00e9s\u00e9lectionner",vf:"Assurez-vous que votre inventaire ait suffisamment d'espace. Le temps de recharge est de 2 minutes.",mg:"Vendre de la Nourriture",Gb:"Vendre de la Nourriture"},Nh={cg:"Piaci hiba! K\u00e9rj\u00fck, adja hozz\u00e1 \u00fajra az elemeket, \u00e9s pr\u00f3b\u00e1lja meg.",
Lb:"Pas assez d'espace dans l'inventaire pour fondre. Espace requis:",ck:"El\u0151sz\u00f6r olvassza fel a magasabb sz\u00edneket?",cc:"Csak a j\u00e1t\u00e9koslist\u00e1ra t\u00e1madjunk?",dc:"Ha ez az opci\u00f3 be van kapcsolva, a bot csak a j\u00e1t\u00e9koslist\u00e1n szerepl\u0151 j\u00e1t\u00e9kosokat t\u00e1madja meg. Ha ez az opci\u00f3 nincs bekapcsolva, a bot v\u00e9letlenszer\u0171 j\u00e1t\u00e9kosokat t\u00e1mad meg.",Kk:"Az exped\u00edci\u00f3s be\u00e1ll\u00edt\u00e1said helytelenek vagy v\u00e1ratlan oldaladatok vannak!",
Lk:"Az exped\u00edci\u00f3s be\u00e1ll\u00edt\u00e1sod helytelen! Letiltott sz\u00f6rnyet \u00e1ll\u00edtott\u00e1l be, ami helytelen.",Yk:"Csak az \u00f6sszes kiv\u00e1lasztott sz\u00edn\u0171 alvil\u00e1gi elemet \u00e1ll\u00edtsa vissza?",Ca:"Priorit\u00e9",Vb:"D\u00e9finir la Priorit\u00e9",Rg:"Points",Kh:"Stat",Si:"Collect Gold",Oj:"Alvil\u00e1gi t\u00e1rgyakat eladni?",uj:"A bot minden m\u0171veletben f\u00e9szket keres, nem csak exped\u00edci\u00f3k sor\u00e1n.",sj:"F\u00e9szek keres\u00e9si t\u00edpus",
qj:"Ne csin\u00e1lj semmit",rj:"Gyors keres\u00e9s",tj:"Alapos keres\u00e9s",Kl:"After expedition points are consumed, travel to Germania to consume Dungeon points",xk:"Kattintson ide, ha a jav\u00edt\u00e1s beragad",Ng:"R\u00e9szleges Jav\u00edt\u00e1s",af:"Teljes Jav\u00edt\u00e1s",Mg:"R\u00e9szleges vagy Teljes Jav\u00edt\u00e1s",se:"Korl\u00e1t Enged\u00e9lyez\u00e9se",kj:"Korl\u00e1toz\u00e1s",lj:"Ha korl\u00e1tozni szeretn\u00e9d a t\u00e1mad\u00e1sok sz\u00e1m\u00e1t az ellens\u00e9gre, enged\u00e9lyezd ezt az opci\u00f3t \u00e9s \u00e1ll\u00edtsd be a korl\u00e1tot. A bot folytatja a t\u00e1mad\u00e1st a t\u00f6bbi ellens\u00e9ggel, miut\u00e1n befejezte a kiv\u00e1lasztott sz\u00f6rny elleni t\u00e1mad\u00e1sokat.",
ne:"Ne l\u00e9pj be az alvil\u00e1gba alvil\u00e1gi jelmezben",me:"Ha nem akarsz alvil\u00e1gi jelmezben az alvil\u00e1gba l\u00e9pni, enged\u00e9lyezd ezt az opci\u00f3t",yi:"Alvil\u00e1g",pi:"Alvil\u00e1gi Buffok",si:"Haszn\u00e1ld az istenek erej\u00e9t az alvil\u00e1gba l\u00e9p\u00e9s ut\u00e1n?",ti:"V\u00e1laszd ki az isteneket, akikt\u0151l er\u0151t szeretn\u00e9l nyerni:",ui:"Haszn\u00e1lj fegyver er\u0151s\u00edt\u00e9st a fegyveren?",vi:"Haszn\u00e1lj p\u00e1nc\u00e9l er\u0151s\u00edt\u00e9st a k\u00f6vetkez\u0151 felszerel\u00e9sen:",
Hk:"A leh\u0171l\u00e9si id\u0151 30 perc. Ha nincs rajtad jelmez, a bot null\u00e1zza a leh\u0171l\u00e9si id\u0151t.",Zk:"Sz\u00ednek kiv\u00e1laszt\u00e1sa",$a:"Vulcanus Kov\u00e1csm\u0171helye",eb:"Feronia F\u00f6ldi Pajzsa",fb:"Neptunusz Foly\u00e9kony Ereje",gb:"Aelous L\u00e9gies Szabads\u00e1ga",hb:"Pl\u00fat\u00f3 Hal\u00e1los K\u00f6de",ib:"Juno \u00c9let Lehelete",jb:"Harag Hegyeinek Pikkelyes P\u00e1nc\u00e9lja",kb:"Sas Szemei",lb:"Saturnusz T\u00e9li \u00d6lt\u00f6z\u00e9ke",ab:"Bubona Bikap\u00e1nc\u00e9lja",
bb:"Mercerius Rabl\u00f3ruh\u00e1i",cb:"Ra F\u00e9nyk\u00f6nt\u00f6se",lg:"Csomagok",gg:"K\u00e9szlet",M:"Min. \u00c1r",L:"H\u00e1ny darab",Fb:"T\u00e1rgyak Elad\u00e1sa",Eb:"Keres\u00e9s ebben",hg:"Anyag Sz\u00edne",Db:"T\u00e1rgy Sz\u00edne",og:"Rakt\u00e1r",Aa:"V\u00e1lt\u00e1s Anyagokra",Hb:"V\u00e1lt\u00e1s T\u00e1rgyakra",ng:"Anyagok Elad\u00e1sa",xa:"K\u00e9rj\u00fck, adjon meg \u00e9rv\u00e9nyes t\u00e1rgyn\u00e9v, \u00e1rfekv\u00e9s \u00e9s mennyis\u00e9get.",ya:"Nincsenek megfelel\u0151 t\u00e1rgyak a kiv\u00e1lasztott keres\u00e9si helyeken.",
za:"Minden t\u00e1rgy sikeresen list\u00e1zva!",Sk:"Minden anyag sikeresen list\u00e1zva!",jg:"Ha fix \u00e1ron szeretne t\u00e1rgyakat eladni, ugyanazt az \u00e9rt\u00e9ket adja meg a min \u00e9s max \u00e1rra.",kg:"Ez a funkci\u00f3 m\u00e9g k\u00eds\u00e9rleti, \u00f3vatosan haszn\u00e1lja. Ha nem ad meg fix \u00e1rat, az elemek v\u00e9letlenszer\u0171en ker\u00fclnek list\u00e1z\u00e1sra a megadott minimum \u00e9s maximum \u00e1r k\u00f6z\u00f6tt.",Dk:"Be\u00e1ll\u00edtja a maxim\u00e1lis aranyat, amit a bot egy ciklusban elk\u00f6lt.",
Va:"A bot licit\u00e1lni kezd minden \u00e9tel t\u00e1rgyra, ha enged\u00e9lyezve van. Nem kell enged\u00e9lyezned a gladi\u00e1tor/zsoldos kapcsol\u00f3kat.",Md:"A bot nem licit\u00e1l az sz\u00f6vets\u00e9gesei licitjeire.",Nd:"Figyelmen k\u00edv\u00fcl hagyja az El\u0151tag/Ut\u00f3tag kombin\u00e1ci\u00f3t t\u00e1rgy keres\u00e9sekor az aukci\u00f3n.",Vj:"V\u00e1laszd ki azokat a t\u00e1rgyt\u00edpusokat, amelyeket be akarsz olvasztani.",Wj:"V\u00e1laszd ki azokat a sz\u00edneket, amelyeket be akarsz olvasztani.",
Xj:"V\u00e1laszd ki az t\u00e1rgyak szintj\u00e9t, amelyeket be akarsz olvasztani.",Yj:"V\u00e1laszd ki a kalap\u00e1csot, amit haszn\u00e1lni szeretn\u00e9l.",Zj:"Figyelj arra, hogy az els\u0151 mez\u0151 melletti z\u00f6ld \u00e9s piros k\u00f6r a szab\u00e1ly enged\u00e9lyez\u00e9s\u00e9hez/letilt\u00e1s\u00e1hoz van.",$j:"Ha v\u00e9letlenszer\u0171en szeretn\u00e9l beolvasztani b\u00e1rmilyen sz\u00ednt vagy t\u00edpust, enged\u00e9lyezheted a `V\u00e9letlenszer\u0171en beolvasztani, ha nincsenek felt\u00e9telek teljes\u00edtve? (A tutorial vide\u00f3ban utolj\u00e1ra enged\u00e9lyezett opci\u00f3)",
Kj:"R\u00e9parer avant la Fusion",Oe:"Sz\u00f6rny Kiv\u00e1laszt\u00e1sa",Ce:"Homok\u00f3ra/Rubin Haszn\u00e1lata?",Jk:"Rubin Haszn\u00e1lata?",Fe:"Mozg\u00f3s\u00edt\u00e1s Haszn\u00e1lata?",Ee:"\u00c9letital Haszn\u00e1lata?",Be:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9ka (%)",Me:"T\u00e1mad\u00e1sok Sz\u00e1ma",De:"T\u00e1mad\u00e1si Id\u0151k\u00f6z (m\u00e1sodpercben)",ze:"V\u00e9grehajtott T\u00e1mad\u00e1sok",Ae:"H\u00e1tral\u00e9v\u0151 Homok\u00f3ra",Ke:"Megjegyz\u00e9s: \u00c9leter\u0151-p\u00f3ci\u00f3kat haszn\u00e1l gy\u00f3gy\u00edt\u00e1sra, nem \u00e9telt.",
Le:"Megjegyz\u00e9s: Ha a t\u00e1mad\u00e1sok id\u0151 el\u0151tt meg\u00e1llnak, pr\u00f3b\u00e1lja meg az 'T\u00e1mad\u00e1sok Vissza\u00e1ll\u00edt\u00e1sa' opci\u00f3t.",Pe:"Ind\u00edt\u00e1s",Ne:"Vissza\u00e1ll\u00edt\u00e1s",Qe:"Le\u00e1ll\u00edt\u00e1s",Re:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sai (Kattintson minimaliz\u00e1l\u00e1shoz)",Ge:"Sz\u00f6rny 1",He:"Sz\u00f6rny 2",Ie:"Sz\u00f6rny 3",Je:"Sz\u00f6rny 4",Vk:"R\u00e9parer avant la Fusion",Qi:"Ez az opci\u00f3 haszn\u00e1lja a cervisia-t, amikor lej\u00e1r a pr\u00e9mium tags\u00e1god.",
xj:"Ez az opci\u00f3 aktiv\u00e1lja \u00e9s v\u00e1laszt olajokat az istenek jutalmai k\u00f6z\u00fcl. Haszn\u00e1lhatja az 1. \u00e9s 3. sz\u00e1m\u00fa olajokat a karakteren, de a 2. sz\u00e1m\u00fa csak csomagokba ker\u00fcl.",Oi:"Ez az opci\u00f3 a be\u00e1ll\u00edtott id\u0151ben haszn\u00e1lja a buffokat. Megkeresi a csomagokban l\u00e9v\u0151 buffokat \u00e9s alkalmazza \u0151ket a karakteren.",mj:"Ez az opci\u00f3 bevisz az alvil\u00e1gba. Ne felejtsd el enged\u00e9lyezni az Auto Bejelentkez\u00e9st az Extra f\u00fcl\u00f6n, k\u00fcl\u00f6nben kijelentkezhetsz az alvil\u00e1gba l\u00e9p\u00e9skor [J\u00e1t\u00e9k Hiba]",
ec:"Ez az opci\u00f3 csak az ar\u00e9na/cirkusz list\u00e1t t\u00e1madja meg. Ha nem, a bot kihagyja.",Hj:"Ez az opci\u00f3 csak pr\u00e9mium licencek sz\u00e1m\u00e1ra van. Szimul\u00e1l egy t\u00e1mad\u00e1st egy felhaszn\u00e1l\u00f3 ellen 75%-os gy\u0151zelmi r\u00e1t\u00e1val, miel\u0151tt megt\u00e1madn\u00e1.",Pd:"Nem kell enged\u00e9lyezned a f\u0151 aukci\u00f3 kapcsol\u00f3t, hogy ezt az opci\u00f3t haszn\u00e1lhasd.",qk:"Ez az opci\u00f3 m\u00e1sodpercenk\u00e9nt friss\u00edti az oldalt, amikor az aukci\u00f3 -Nagyon R\u00f6vid- \u00e1llapotban van, hogy folyamatosan licit\u00e1ljon \u00e9s megnyerje az aukci\u00f3t.",
Tj:"Ha egyik olvaszt\u00e1si felt\u00e9tel sem teljes\u00fcl, akkor v\u00e9letlenszer\u0171en olvaszt. Gy\u0151z\u0151dj meg r\u00f3la, hogy v\u00e1lasztott\u00e1l t\u00e1rgyt\u00edpust \u00e9s sz\u00ednt.",Uj:"Ez az opci\u00f3 csak a lelt\u00e1rban l\u00e9v\u0151 t\u00e1rgyakat olvasztja. A csomagokban l\u00e9v\u0151 t\u00e1rgyakat figyelmen k\u00edv\u00fcl hagyja.",Wa:"Aukci\u00f3s T\u00e1rgyak",rg:"Zsoldos T\u00e1rgyak",Xb:"Bolt T\u00e1rgyak",Ai:"Egyedi T\u00e1rgyak",Pj:"H\u00e1tt\u00e9r be\u00e1ll\u00edt\u00e1sa feket\u00e9re [N\u00f6veli a teljes\u00edtm\u00e9nyt]",
Qj:"GLDbot gombok \u00e1thelyez\u00e9se a bal als\u00f3 sarokba?",Ri:"Cirkusz T\u00e1mad\u00e1s Gy\u00f3gy\u00edt\u00e1s N\u00e9lk\u00fcl",pk:"Sz\u00fcks\u00e9g eset\u00e9n vegy\u00fcnk ki aranyat a csomagokb\u00f3l?",am:"Az edz\u00e9shez aranyat vettek a csomagokb\u00f3l",Gd:"Nem tal\u00e1ltak aranyat a csomagokban az edz\u00e9shez",lk:"Jav\u00edtott T\u00e1rgyak",ek:"Ar\u00e9na T\u00e1mad\u00e1sok",gk:"Cirkusz T\u00e1mad\u00e1sok",Ed:"T\u00e1rgyak Vissza\u00e1ll\u00edtva",jk:"Exped\u00edci\u00f3s T\u00e1mad\u00e1sok",
ik:"Kazamata T\u00e1mad\u00e1sok",mk:"Alvil\u00e1gi T\u00e1mad\u00e1sok",fk:"Ar\u00e9n\u00e1ban Szerzett P\u00e9nz",hk:"Cirkuszban Szerzett P\u00e9nz",Zl:"Olvasztott T\u00e1rgyak",kk:"\u00dajrahasznos\u00edtott Arany",dj:"C\u00e9h Csata",fj:"C\u00e9h Be\u00e1ll\u00edt\u00e1sok",ej:"C\u00e9h N\u00e9v",cj:"V\u00e9letlenszer\u0171 C\u00e9h T\u00e1mad\u00e1s",rl:"V\u00e9letlenszer\u0171en t\u00e1madja a c\u00e9heket.",Pi:"Statisztik\u00e1k Vissza\u00e1ll\u00edt\u00e1sa",Cl:'GLDbot: A kock\u00e1k seg\u00edts\u00e9g\u00e9vel friss\u00edtse a rejt\u00e9lydobozt, \u00e9s tal\u00e1ljon \u00e9rt\u00e9kes t\u00e1rgyakat, miel\u0151tt kinyitn\u00e1 azokat (stb. jelmezek). Kattintson a "Start" gombra, nyissa meg a l\u00e1d\u00e1kat.',
Pc:"Wood",Fc:"Copper",Jc:"Iron",Lc:"Leather",Qc:"Wool",Gc:"Cotton Wool",Ic:"Hemp",Hc:"Gauze Strip",Mc:"Linen Strip",Kc:"Jute Patch",Oc:"Velvet",Nc:"Silk Thread",Yc:"Fur",Sc:"Bone Splinter",ad:"Scale",Vc:"Claw",Xc:"Fang",Wc:"Dragon Scale",Tc:"Bull`s Horn",$c:"Poison Gland",Uc:"Cerberus` Pelt",Zc:"Hydra Scale",bd:"Sphinx Feather",cd:"Typhon Leather",Cc:"Lapis Lazuli",wc:"Amethyst",vc:"Amber",xc:"Aquamarine",Dc:"Sapphire",Ac:"Garnet",zc:"Emerald",yc:"Diamond",Bc:"Jasper",Ec:"Sugilite",qc:"Scorpion Poison",
tc:"Tincture of Stamina",mc:"Antidote",lc:"Adrenaline",sc:"Tincture of Enlightenment",pc:"Potion of Perception",nc:"Essence of Reaction",oc:"Phial of Charisma",uc:"Waters of Oblivion",rc:"Soul Essence",Bd:"Water Seal",vd:"Protection Rune",td:"Earth Mark",Ad:"Totem of Healing",zd:"Talisman of Power",xd:"Stone of Fortune",ud:"Flintstone",yd:"Storm Rune",wd:"Shadow Rune",gd:"Crystal",fd:"Bronze",ld:"Obsidian",od:"Silver",pd:"Sulphur",jd:"Gold Ore",nd:"Quartz",md:"Platinum",ed:"Almandin",hd:"Cuprit",
kd:"Hellstone",Li:"T\u00e1mad\u00e1s v\u00e9letlenszer\u0171en?",Mi:'Kapcsold ki a "J\u00e1t\u00e9kosok rendez\u00e9se az ar\u00e9n\u00e1ban szint szerint" be\u00e1ll\u00edt\u00e1st a crazy-addonban is.',$g:"Csak az isten t\u00edpus\u00e1n alapul\u00f3 k\u00fcldet\u00e9seket fogadja el.",Xa:"Automatikus Buff",ce:"Csak a pokolban haszn\u00e1lja?",Gg:"\u00daj Szab\u00e1ly",Eg:"N\u00e9v Tartalmazza",isUnderworldItem:"Ez egy alvil\u00e1gi t\u00e1rgy?",kf:"Anyagok Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
wk:"Utiliser la Pri\u00e8re ?",Gi:"Utiliser le Sacrifice ?",sk:"Utiliser le tissu pour entrer dans le monde souterrain ?",xi:"A m\u00e9lyvil\u00e1gban csak a m\u00e9lyvil\u00e1ggal kapcsolatos k\u00fcldet\u00e9seket fogadja el?",wi:"Ha enged\u00e9lyezve van, meg kell adnia a m\u00e9lyvil\u00e1gi t\u00e1rgyak nev\u00e9t. Ha a bot megtal\u00e1lja ezeket a t\u00e1rgyakat a m\u00e9lyvil\u00e1gban, elfogadja a k\u00fcldet\u00e9st.",cl:"M\u00e9lyvil\u00e1gi K\u00fcldet\u00e9s T\u00e1rgy",ol:"Entrez le Nom du Mat\u00e9riel",
Gk:"A robot im\u00e1dja a kock\u00e1kat! Seg\u00edtenek ruh\u00e1t tal\u00e1lni a l\u00e1d\u00e1kban. De ha nincs kocka, a robot akkor is kinyitja a l\u00e1d\u00e1kat, rem\u00e9lve, hogy tal\u00e1l valami men\u0151 ruh\u00e1t (de lehet, hogy semmit sem tal\u00e1l!)",Sj:"Fusionner les Bo\u00eetes de Butin ?",re:"Enable Arena",Sg:"Prioriz\u00e1lja az ar\u00e9na list\u00e1t?",Tg:"Prioriz\u00e1lja a cirkusz list\u00e1t?",je:"Napl\u00f3 men\u00fc letilt\u00e1sa",oh:"Jutalom Min. Arany \u00c9rt\u00e9k",
ah:"Ha enged\u00e9lyezve van, a K\u00fcldet\u00e9s F\u00f3kusz a legr\u00f6videbb utat k\u00f6veti a dungeon befejez\u00e9s\u00e9hez.",Nh:"Dobja a kock\u00e1t automatikusan?",Oh:"Vigy\u00e1zva haszn\u00e1lja a dob\u00f3 kock\u00e1t, folyamatosan az els\u0151 kock\u00e1t fogja haszn\u00e1lni, am\u00edg ki nem kapcsolja az opci\u00f3t.",uh:"Keres\u00e9s folyamatban",ih:"A jav\u00edt\u00e1s alap\u00e9rtelmezett leh\u0171l\u00e9se 10 perc.",Bg:"Minim\u00e1lis \u00c1llapot",he:"Aktu\u00e1lis t\u00e9tel a munkapadon [T\u00f6r\u00f6lje, ha a bot v\u00e1ratlanul sz\u00fcnetelt]",
Gf:"Kov\u00e1csolt er\u0151forr\u00e1sok sikeresen elmentve a horreumhoz.",Cf:"Piac ellen\u0151rz\u00e9se t\u00e1rgyak sz\u00e1m\u00e1ra...",Ab:"T\u00e9tel \u00e1thelyezve a munkapadra.",Tf:"T\u00e9tel sikeresen jav\u00edtva \u00e9s felszerelve.",Uf:"T\u00e9tel sikeresen jav\u00edtva.",Qk:"A jav\u00edt\u00e1s sikertelen. Az oldal friss\u00edt\u00e9sre ker\u00fcl.",Qf:"Anyagok felv\u00e9tele...",bg:"V\u00e1rakoz\u00e1s a jav\u00edt\u00e1sra...",Sf:"Jav\u00edt\u00e1s elindult: .",wa:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa az invent\u00e1riumb\u00f3l a t\u00e1sk\u00e1ba",
Rf:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa a munkapadra a csomagol\u00f3ba.",ua:"Nem tal\u00e1lhat\u00f3 elegend\u0151 anyag. A jav\u00edt\u00e1si hely le lesz tiltva ",Nf:"T\u00e1rgyak keres\u00e9se arany elrejt\u00e9s\u00e9re az aukci\u00f3ban...",zf:"Lej\u00e1rt t\u00e1rgyak ellen\u0151rz\u00e9se a csomagokban...",Af:"T\u00e9tel sikeresen vissza\u00e1ll\u00edtva.",Bf:"Nincs \u00fcres hely vagy arany a vissza\u00e1ll\u00edt\u00e1shoz.",Hf:"Gy\u0151z\u0151dj\u00f6n meg arr\u00f3l, hogy van elad\u00e1si joga a c\u00e9hes piacon!",
ub:"Nincs el\u00e9g arany/vagy nincs meg a v\u00e1s\u00e1rl\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s a friss\u00edt\u00e9shez.",wb:"A bolt friss\u00edtve lett.",xb:"Hiba t\u00f6rt\u00e9nt a gy\u00f3gyul\u00e1s k\u00f6zben.",Kf:"Nincs Ruby vagy Cloth, letilt\u00e1sa az opci\u00f3knak.",Pk:"Nincs gy\u00f3gy\u00edt\u00f3 t\u00e1rgy a csomagokban.",yb:"Nem tal\u00e1lhat\u00f3 megfelel\u0151 t\u00e1rgy",Lf:"Az \u00e9lelmiszereket felvett\u00e9k. A folyamat v\u00e9get \u00e9rt.",Mf:"Legal\u00e1bb egy \u00e9tel felv\u00e9telre ker\u00fclt. A folyamat v\u00e9get \u00e9rt.",
zb:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",If:"\u00c9telek felv\u00e9tele a csomagokb\u00f3l.",Jf:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",vb:"Nincs t\u00f6bb gy\u00f3gy\u00edt\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s.",tb:"\u00c9P helyre\u00e1ll\u00edtva.",va:"Nincs teend\u0151, ez\u00e9rt im\u00e1dkozom!",Yf:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem \u00e9s a Villa Medici ellen\u0151rz\u00e9s\u00e9re.",
Zf:"V\u00e1rakoz\u00e1s a Villa Medici-re, friss\u00edt\u00e9s 60 m\u00e1sodperc m\u00falva.",$f:"Elhagytam az alvil\u00e1got.",ag:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem ellen\u0151rz\u00e9s\u00e9re.",Of:"Isteni olajok ellen\u0151rz\u00e9se...",Pf:"Isteni olajok felv\u00e9ve.",sa:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen AZ AR\u00c9N\u00c1BAN: ",ta:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen A CIRKUSZBAN: ",xf:"Aukci\u00f3 ellen\u0151rz\u00e9se! K\u00e9rem v\u00e1rjon...",
yf:"T\u00e1rgyak licit\u00e1l\u00e1sa. K\u00e9rem v\u00e1rjon...",Vf:"Automatikus olvasztott t\u00e9tel: ",Wf:"Olvaszt\u00e1s alatt \u00e1ll\u00f3 t\u00e9tel: ",Bb:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges arany: ",Xf:"OLVASZT\u00c1S: T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",Rk:"T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",Df:"Koszt\u00fcm\u00f6k el\u00e9rhet\u0151s\u00e9g\u00e9nek ellen\u0151rz\u00e9se...",Ff:"Adom\u00e1nyozva: ",Ef:"Kocka dob\u00e1sa...",
Xe:"Underworld Farm [Manual, Beta]",We:"Farm Location",Ye:"Figyelem: Kapcsolja be ezt a funkci\u00f3t a t\u00e1madni k\u00edv\u00e1nt l\u00e9ny felold\u00e1sa ut\u00e1n, nem fog automatikusan t\u00e1madni, hogy feloldja a sz\u00f6rnyet.",Ve:"Farm Enemy",Wd:"Automatikus Bejelentkez\u00e9s",Xd:"Enged\u00e9lyezned kell a felugr\u00f3 ablakokat a GameForge el\u0151csarnok k\u00e9perny\u0151j\u00e9r\u0151l. N\u00e9zd meg a dokument\u00e1ci\u00f3t, hogy hogyan tedd meg.",Og:"Bot Sz\u00fcneteltet\u00e9se",
Pg:"Bot sz\u00fcneteltet\u00e9se ennyi id\u0151re: (Perc)",Te:"Lej\u00e1rati D\u00e1tum",Jg:"Csak \u00e9telt v\u00e1s\u00e1rolj?",Kg:"Ha ezt enged\u00e9lyezed, a bot figyelmen k\u00edv\u00fcl hagyja a kiv\u00e1laszt\u00e1saidat, \u00e9s automatikusan v\u00e1s\u00e1rol \u00e9telt an\u00e9lk\u00fcl, hogy b\u00e1rmit be\u00edrn\u00e1l.",Jb:"Maxim\u00e1lis \u00f6sszes arany kiad\u00e1s",Ib:"Maxim\u00e1lis arany \u00e9telenk\u00e9nti kiad\u00e1s",Ig:"A bot 60 percenk\u00e9nt ellen\u0151rzi az olajokat",
fi:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a olvaszt\u00e1si id\u0151k ellen\u0151rz\u00e9s\u00e9hez.",ci:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs aranyad.",ei:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs el\u00e9rhet\u0151 t\u00e1rgyad.",Yh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a t\u00e1rgyak jav\u00edt\u00e1s\u00e1hoz \u00e9s ellen\u0151rz\u00e9s\u00e9hez.",
Xh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a guild piac\u00e1nak arany\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Th:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az aukci\u00f3 arany tart\u00e1si lehet\u0151s\u00e9g\u00e9hez.",Ph:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az ar\u00e9na PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",Uh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a cirkusz PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",
li:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a statisztik\u00e1k tr\u00e9ningez\u00e9s\u00e9hez.",$h:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a lej\u00e1rt t\u00e1rgyak vissza\u00e1ll\u00edt\u00e1s\u00e1hoz.",ji:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a kov\u00e1csol\u00f3 anyagok t\u00e1rol\u00e1s\u00e1hoz a horreum-ban.",Rh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a gladi\u00e1torok \u00e9s zsoldosok aukci\u00f3j\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",bi:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t t\u00e1rgyak keres\u00e9s\u00e9hez az aukci\u00f3ban \u00e9s a boltban.",
Vh:"Be\u00e1ll\u00edtja a guild adom\u00e1ny k\u00fcld\u00e9s\u00e9nek id\u0151z\u00edt\u0151j\u00e9t.",bf:"Arany Mozgatva",oe:"Ne adjon el az \u00f6sszeoml\u00e1si \u00e9s aukci\u00f3s list\u00e1n szerepl\u0151 t\u00e9teleket",vh:"Bolt Automatiz\u00e1l\u00e1s",xh:"T\u00e1rgy Keres\u00e9s Be\u00e1ll\u00edt\u00e1sok",wh:"Haszn\u00e1lja ezt az eszk\u00f6zt t\u00e1rgyak keres\u00e9s\u00e9hez. Egyszer\u0171en adjon hozz\u00e1 t\u00e1rgyakat a list\u00e1hoz, hat\u00e1rozza meg a ruha mennyis\u00e9g\u00e9t, majd ind\u00edtsa el a keres\u00e9st.",
yh:"Haszn\u00e1lni k\u00edv\u00e1nt Ruha:",zh:"H\u00e1ny ruh\u00e1t haszn\u00e1ljon?",fa:"Full Adja meg a T\u00e1rgy Nev\u00e9t",Wb:"Adja meg a T\u00e1rgy Szintj\u00e9t",Bh:"T\u00e1rgy Min\u0151s\u00e9ge",Ah:"T\u00e1rgy Neve Itt",Ch:"Keres\u00e9s Ind\u00edt\u00e1sa",Dh:"\u00c1tugr\u00e1s \u00e9s Folytat\u00e1s",Eh:"Keres\u00e9s Le\u00e1ll\u00edt\u00e1sa",Ze:"Guild Piac Rendez\u00e9se",Dg:"Legdr\u00e1g\u00e1bb",ee:"Legolcs\u00f3bb",Da:"V\u00e1lasszon egy lehet\u0151s\u00e9get",te:"Mettre en surbrillance les objets du monde souterrain",
$e:"F\u00f3kuszban a k\u00fcldet\u00e9sre?",Pq:"Haszn\u00e1ljon rubint, ha nincs ruha?",Ya:"Ker\u00fclje azonos szem\u00e9lyek megt\u00e1mad\u00e1s\u00e1t, hogy elker\u00fclje a jelent\u00e9st\u00e9tel\u00e9t. A jelent\u00e9s megn\u00f6veli a kitilt\u00e1s es\u00e9ly\u00e9t.",Rl:"Olvad a z\u00f6ld?",Vg:"Ne fogadja el a v\u00e9letlenszer\u0171 k\u00fcldet\u00e9seket, ha b\u00e1rmilyen sz\u0171r\u0151t megadott?",Rc:"Maxim\u00e1lis haszn\u00e1lhat\u00f3 anyagmin\u0151s\u00e9g",$i:"Enged\u00e9lyezze a zsoldos keres\u00e9st",
yl:'Kattints a "Minden Kiv\u00e1lasztott Elad\u00e1sa" gombra az \u00f6sszes t\u00e9tel elad\u00e1s\u00e1hoz. Gy\u0151z\u0151dj meg r\u00f3la, hogy az els\u0151 (1) t\u00e1sk\u00e1dban van el\u00e9g 2x3 \u00fcres hely. Az arany t\u00f6meges gy\u0171jt\u00e9s\u00e9hez sz\u0171rd ki az aranyat, \u00e9s haszn\u00e1ld a "Kiv\u00e1lasztott vagy Mindet Kiv\u00e1laszt" lehet\u0151s\u00e9get.',dk:"\ud83d\udd25 : Hozz\u00e1adja az elemet a koh\u00e1szati list\u00e1hoz.",Ni:"\ud83d\udd28 : Hozz\u00e1adja az elemet az \u00e1rver\u00e9si list\u00e1hoz.",
Jj:"Friss\u00edtsd a boltot anyaggal, amikor tele van",Gl:"Oldal:",Fj:"Meg\u00e1ll\u00edt",Dj:"Elad\u00e1s Ezen az Oldalon",Aj:"Kiv\u00e1lasztott Kiv\u00e1laszt\u00e1sa",zj:"Mindent Kiv\u00e1laszt",Gj:"Automatikus Csomagol\u00e1si Be\u00e1ll\u00edt\u00e1sok",Ej:"Er\u0151forr\u00e1sok K\u00fcld\u00e9se",Bj:"Minden Kiv\u00e1lasztott Elad\u00e1sa",na:"T\u00e9tel T\u00edpusa",pa:"Fegyverek",U:"Pajzsok",O:"P\u00e1nc\u00e9lok",S:"Sisakok",R:"Keszty\u0171k",P:"Csizm\u00e1k",oa:"Gy\u0171r\u0171k",la:"Amulettek",
Ka:"Haszn\u00e1lati T\u00e1rgyak (\u00c9telek)",Pa:"Fejleszt\u00e9sek",yj:"Er\u0151s\u00edt\u00e9sek",Ma:"Receptek",La:"Zsoldosok",Oa:"Kov\u00e1csol\u00f3 Eszk\u00f6z\u00f6k",Na:"Pergamenek",sd:"Er\u0151s\u00edt\u00e9sek",qd:"Esem\u00e9ny T\u00e1rgyak",rd:"Kov\u00e1csol\u00e1shoz Val\u00f3 T\u00e1rgyak",Fl:"Arany",Ja:"Minden",Hl:"Min\u0151s\u00e9g",qa:"Feh\u00e9r",C:"Z\u00f6ld",B:"K\u00e9k",D:"Lila",J:"Narancss\u00e1rga",T:"Piros",Cj:"Az \u00d6sszes Elad\u00e1si Be\u00e1ll\u00edt\u00e1s",Rj:"Elhanyagolja a El\u0151tag / Ut\u00f3tag Kombin\u00e1ci\u00f3t?",
gj:"H\u00e1ny \u00e9telt vegy\u00e9l/fogj fel?",Vi:"Norm\u00e1l",Ui:"K\u00f6zepes",Ti:"Neh\u00e9z",Ga:"Alap",Ll:"Ragadt Megjav\u00edt\u00e1s",Nk:"Kapcsold ki a Pokol Bel\u00e9p\u00e9s\u00e9t, ha letiltan\u00e1d a Dungeon/Circus/Arena-t. Ha k\u00e9zzel l\u00e9pt\u00e9l be a Pokolba, akkor enged\u00e9lyezned kell a Pokol M\u00f3dot.",fe:"V\u00e1lassz alvil\u00e1gi jelmezt",Ji:"Viselj alvil\u00e1gi jelmezt, ha el\u00e9rhet\u0151?",oi:"K\u00e9pz\u00e9si \u00fatmutat\u00f3: Hat\u00e1rozza meg, h\u00e1nyszor szeretn\u00e9 edzeni a statisztik\u00e1kat, \u00e9s \u00e1ll\u00edtsa be priorit\u00e1saikat. A bot nem fog edzeni, hacsak nincs be\u00e1ll\u00edtva egy priorit\u00e1s. Ha van be\u00e1ll\u00edtott priorit\u00e1s, de nincs t\u00f6bb k\u00e9pzend\u0151 statisztika, a bot a kiv\u00e1lasztott statisztik\u00e1val folytatja.",
ll:"Quest",Dd:"Olvaszt\u00e1s",Wl:"Olvaszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",ak:"Olvasztott T\u00e1rgyak",Xl:"Adj hozz\u00e1 el\u0151tagot vagy ut\u00f3tagot, amint megtal\u00e1lja a csomagokban, aut\u00f3matikusan olvasztani fogja.:",Vl:"Olvasztand\u00f3 T\u00e1rgy:",ic:"Kattints a t\u00e1rgyra, amelyet meg akarsz jav\u00edtani. Ez a rendszer megjav\u00edtja a k\u00e9t f\u0151 karaktered t\u00e1rgyait ( AR\u00c9NA/CT). Legal\u00e1bb 10000 aranyra van sz\u00fcks\u00e9g a jav\u00edt\u00e1s elind\u00edt\u00e1s\u00e1hoz. Ha egy t\u00e1rgy beragad, az azt jelenti, hogy nincs anyagod a jav\u00edt\u00e1shoz. Pr\u00f3b\u00e1lj szabad helyet k\u00e9sz\u00edteni a t\u00e1sk\u00e1dban. A bot akkor kezdi meg a jav\u00edt\u00e1st, amikor a t\u00e9tel tart\u00f3ss\u00e1ga %0.",
dl:"Csak Zsoldosra alkalmaz",hl:"Aukci\u00f3 csak akkor licit\u00e1l, ha a lej\u00e1rati id\u0151 k\u00f6zel van a v\u00e9g\u00e9hez.",gl:"Gy\u0151z\u0151dj meg arr\u00f3l, hogy a 2. lelt\u00e1r f\u00fcl \u00fcres \u00e9s rendelkezik 10K arannyal. A bot megtal\u00e1lja \u00e9s a m\u00e1sodik f\u00fclre helyezi a t\u00e1rgyat, majd legk\u00f6zelebb az oldal friss\u00edt\u00e9se ut\u00e1n olvasztja a t\u00e1rgyat. Az olvaszt\u00e1st minden 5-10 percen bel\u00fcl \u00fajraellen\u0151rzi.",jj:"Gy\u00f3gy\u00edt\u00e1s & Buffs",
Ml:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges Arany:",Pl:"Licit kihagy\u00e1sa: Egyes\u00fclet tag m\u00e1r licit\u00e1lt a t\u00e1rgyra ",Ol:"Licit kihagy\u00e1sa: M\u00e1r licit\u00e1lt a t\u00e1rgyra ",advanced:"Halad\u00f3",arena:"Ar\u00e9na",ja:"Aut\u00f3matikus T\u00e1mad\u00e1s",fc:"T\u00e1mad\u00e1s Elker\u00fcl\u00e9se",ha:"J\u00e1t\u00e9kos Hozz\u00e1ad\u00e1sa",ia:"Add hozz\u00e1 a j\u00e1t\u00e9kos nev\u00e9t (Same Server)",tl:"Meg\u00e1ll\u00edtja a bot, ha elfogyott az \u00e9tel?",
circusTurma:"Circus Turma",Wi:"Neh\u00e9zs\u00e9g",dungeon:"Kazamata",Xi:"Kazamata Be\u00e1ll\u00edt\u00e1sok",eventExpedition:"Esem\u00e9ny Exped\u00edci\u00f3",expedition:"Exped\u00edci\u00f3",aj:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sok",Lj:"V\u00e1lassz Sz\u00f6rnyet",vl:"Legmagasabb",ul:"Tedd be a gy\u00f3gy\u00edt\u00f3 t\u00e1rgyaid az els\u0151 oldalra a lelt\u00e1rodon bel\u00fcl",nj:"Bent",Lh:"Arany T\u00e1rol\u00e1sa",Mh:"Arany T\u00e1rol\u00e1sa az Aukci\u00f3ban?",rh:"Haszn\u00e1ld a Munk\u00e1sruh\u00e1t a Bolt Felt\u00f6lt\u00e9s\u00e9hez?",
Xk:"V\u00e1lassz T\u00e9teleket a Vissza\u00e1ll\u00edt\u00e1shoz",kh:"Lej\u00e1rt T\u00e9telek Vissza\u00e1ll\u00edt\u00e1sa",Qb:"Megjegyz\u00e9s: Az opci\u00f3 enged\u00e9lyez\u00e9s\u00e9vel a bot eladja a k\u00f6zelg\u0151 lej\u00e1rat\u00fa t\u00e1rgyakat a Csomagokb\u00f3l az Egyes\u00fcleti Piacon majd megszak\u00edtja a lej\u00e1rati id\u0151 vissza\u00e1ll\u00edt\u00e1s\u00e1t. Egyes\u00fclet sz\u00fcks\u00e9ges. Gy\u0151z\u0151dj meg r\u00f3la, hogy a t\u00e1sk\u00e1dban van \u00fcres 3x3-as hely.",
Qg:"Bot v\u00e9letlenszer\u0171 sz\u00fcneteltet\u00e9se m\u0171k\u00f6d\u00e9si [Teszt F\u00e1zis]:",aa:"Arany T\u00e1rol\u00e1sa: A bot megtartja ezt az aranyat a karakteren:",pg:"Max Arany: A bot elk\u00f6lti, ha az arany nagyobb, mint",ph:"A bot v\u00e9letlenszer\u0171 t\u00e1rgyakra fog licit\u00e1lni.",Hd:"V\u00e9letlenszer\u0171 k\u00e9sleltet\u00e9s hozz\u00e1ad\u00e1sa",Id:"Itt adhatsz hozz\u00e1 k\u00e9sleltet\u00e9st a bothoz.",Pb:"Jav\u00edt\u00e1s",Ql:"Csak K\u00e9k t\u00e1rgy Olvaszt\u00e1s?",
Tl:"Csak Lila t\u00e1rgy Olvaszt\u00e1s?",Sl:"Csak Narancss\u00e1rga t\u00e1rgy Olvaszt\u00e1s?",bk:"Mindent Olvassz be a 2. f\u00fclben?",Ul:"Ez figyelmen k\u00edv\u00fcl hagyja a sz\u00ednv\u00e1laszt\u00e1sokat",Za:"El\u0151zm\u00e9nyek T\u00f6rl\u00e9se",Gh:"Olvaszt\u00e1s",Qd:"Search",Fg:"Aut\u00f3matikus Aukci\u00f3",Rd:"Az aukci\u00f3 t\u00falzott haszn\u00e1lata kitilt\u00e1st vonhat maga ut\u00e1n. Az esetleges \u00fctk\u00f6z\u00e9sek elker\u00fcl\u00e9se \u00e9rdek\u00e9ben aj\u00e1nlatos letiltani az egy\u00e9b aj\u00e1nlatt\u00e9teli funkci\u00f3kat. Ez a funkci\u00f3 lelass\u00edtja a botot.",
qh:"Keres\u00e9s a Gladi\u00e1torok Aukci\u00f3j\u00e1ban",th:"Keres\u00e9s a Zsoldosok Aukci\u00f3j\u00e1ban",Zd:"Licit\u00e1l\u00e1s \u00c9telekre?",qg:"Maxim\u00e1lis Licit",$d:"Licit\u00e1l\u00e1s, ha az \u00e1llapot kevesebb, mint",ae:"Licit\u00e1lt T\u00e1rgyak",Bk:"Aukci\u00f3 Nyelve",Ck:"2.9.4-es friss\u00edt\u00e9ssel kapcsolatban k\u00e9rlek \u00e1ll\u00edtsd be \u00fajra a nyelvet, vagy ALAP\u00c9RTELMEZET BE\u00c1LL\u00cdT\u00c1SOK. Gy\u0151z\u0151dj meg r\u00f3la, hogy minden helyesen van be\u00e1ll\u00edtva, k\u00fcl\u00f6nben a licit\u00e1l\u00e1s nem m\u0171k\u00f6dik.",
Ld:"Hozz\u00e1adhatsz t\u00e9teleket a piac keres\u00e9s\u00e9hez \u00e9s az aukci\u00f3hoz. Amikor egy t\u00e9telt hozz\u00e1ad a list\u00e1hoz, a piac lila t\u00e9teleket is megjelen\u00edti. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, az al\u00e1bbi opci\u00f3kat haszn\u00e1lhatod",zk:"\u00d3vatosan haszn\u00e1ld az aukci\u00f3t!",Ak:"Az aut\u00f3matikus licit\u00e1l\u00e1s t\u00fal sok k\u00e9r\u00e9st k\u00fcldhet a szerverre, \u00e9s kitilthatj\u00e1k, ha folyamatosan haszn\u00e1lod!",
hh:"\u00dajra Aktiv\u00e1lja az Esem\u00e9nypontokat Rubinokkal?",ve:"Aut\u00f3matikus Olaj Enged\u00e9lyez\u00e9se",Ek:"Aut\u00f3matikus Szent Olajok Beszerz\u00e9se",Tk:"K\u00fcldet\u00e9s ellen\u0151rz\u00e9si Sebess\u00e9g",Ua:"T\u00e1madj Egyes\u00fcleti Tagokat?",Sa:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "T\u00e1mad\u00e1s" list\u00e1hoz, amikor t\u00f6bb, mint X ARANYAT rabolsz.:',Ta:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "Elker\u00fclend\u0151 T\u00e1mad\u00e1s" list\u00e1hoz, ha vesz\u00edtesz ellen\u00fck.:',
Tb:"T\u00e1mad\u00e1sok Statisztik\u00e1i",ac:"Nagyon Hossz\u00fa",Cb:"Hossz\u00fa",Kb:"K\u00f6zepes",Yb:"R\u00f6vid",bc:"Nagyon R\u00f6vid",we:"Bel\u00e9p\u00e9s az Alvil\u00e1gba, ha az \u00c9P >",bh:"K\u00fcldet\u00e9s Ellen\u0151rz\u00e9si Sebess\u00e9g",Ug:'Az alap\u00e9rtelmezett "3x". Ha a bot probl\u00e9m\u00e1kat okoz a k\u00fcldet\u00e9sekkel, \u00e1ll\u00edtsd \u00e1t a k\u00fcldet\u00e9s sebess\u00e9g\u00e9t a szerver sebess\u00e9g\u00e9nek megfelel\u0151en.',cf:"Gy\u00f3gy\u00edt\u00f3 Kiv\u00e1laszt\u00f3 T\u00e1ska",
xe:'Ha manu\u00e1lisan friss\u00edted a pontokat, akkor kattints a fent l\u00e9v\u0151 gombra: "Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!"',Ik:"Legal\u00e1bb az egyiket enged\u00e9lyezned kell a k\u00f6vetkez\u0151k k\u00f6z\u00fcl: exped\u00edci\u00f3, dungeont, ar\u00e9n\u00e1t vagy cirkuszt, hogy elind\u00edtsd az Esem\u00e9ny Exped\u00edci\u00f3t.",eh:"Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!",mb:"Fedezze a T\u00e1rsakat?",$k:"Hagyd minden be\u00e1ll\u00edt\u00e1st letiltva, ha a csomagokban szerepl\u0151 elemekkel szeretn\u00e9l olvasztani. Azonban m\u00e9g mindig v\u00e1laszthatsz sz\u00edneket.",
Fk:"Karakter(Ki) / Zsoldos(Be)",Wk:"Mindkett\u0151t Jav\u00edtani?",al:"Id\u0151z\u00edt\u0151k",Timers:"\u00cdrd be az egyes id\u0151z\u00edt\u0151kh\u00f6z a percek sz\u00e1m\u00e1t lent vagy hagyd az alap\u00e9rtelmezetten.",pb:"T\u00e1mad\u00e1s Statisztik\u00e1i Enged\u00e9lyez\u00e9se:",Rb:"V\u00e1lassz tartom\u00e1nyt a t\u00e1mad\u00e1shoz",Sb:"A bot v\u00e9letlenszer\u0171en t\u00e1mad a t\u00e1bl\u00e1zatban szerepl\u0151 j\u00e1t\u00e9kosok k\u00f6z\u00fcl.",rb:"Ligat\u00e1mad\u00e1sok",
ob:"Ligat\u00e1mad\u00e1s Enged\u00e9lyez\u00e9se:",Nb:"V\u00e9letlenszer\u0171 T\u00e1mad\u00e1s",Ob:"T\u00e1mad\u00e1s alacsonyt\u00f3l a magas szint\u0171 j\u00e1t\u00e9kosokig",yk:"A bot alap\u00e9rtelmezetten elker\u00fcli az Egyes\u00fcleti tagok t\u00e1mad\u00e1s\u00e1t.",Se:"Exped\u00edci\u00f3 Helysz\u00edne:",Sd:"Aut\u00f3matikus B\u00f3nuszok Begy\u0171jt\u00e9se:",Fh:"Boss Kihagy\u00e1sa",qe:"Kazamata Helysz\u00edne:",nh:"Kazamata \u00fajrakezd\u00e9se veres\u00e9g eset\u00e9n?",ff:"Alvil\u00e1g Be\u00e1ll\u00edt\u00e1sok",
gf:"K\u00e9rlek konfigur\u00e1ld a gy\u00f3gy\u00edt\u00e1s sz\u00e1zal\u00e9kos be\u00e1ll\u00edt\u00e1sait a gy\u00f3gy\u00edt\u00e1s f\u00fcl\u00f6n, \u00e9s gy\u0151z\u0151dj meg r\u00f3la, hogy a gy\u00f3gy\u00edt\u00e1s f\u00fcl be van kapcsolva. Ha az alvil\u00e1g bel\u00e9p\u00e9se kijelentkeztet, l\u00e9pj a lobbyba, \u00e9s kapcsold be az aut\u00f3mata bejelentkez\u00e9s jel\u00f6l\u0151n\u00e9gyzetet.",df:"Alvil\u00e1g Neh\u00e9zs\u00e9g",Vd:"Aut\u00f3matikus Alvil\u00e1g Bel\u00e9p\u00e9s: / Alvil\u00e1g Mode",
Ei:"Mobiliz\u00e1ci\u00f3 haszn\u00e1lata, ha pontok = 0",Ii:"Rubinok haszn\u00e1lata?",ye:"Kil\u00e9p\u00e9s az alvil\u00e1gb\u00f3l, ha nincsenek pontok?",ri:"A bot megpr\u00f3b\u00e1lja el\u0151sz\u00f6r a Villa Medici-t haszn\u00e1lni, ha nincs, akkor gy\u00f3gy\u00edt\u00f3 italt haszn\u00e1l. Ne felejtsd el bekapcsolni a Gy\u00f3gy\u00edt\u00e1s kapcsol\u00f3t.",zi:"Az aut\u00f3matikus alvil\u00e1g bel\u00e9p\u00e9s letiltja a kazamata/ar\u00e9na/circus be\u00e1ll\u00edt\u00e1sokat az alvil\u00e1g bel\u00e9p\u00e9sekor.",
bl:"Alvil\u00e1g Gy\u00f3gy\u00edt\u00e1si Be\u00e1ll\u00edt\u00e1sok",Hi:"Villa Medici Haszn\u00e1lata?",Fi:"Gy\u00f3gy\u00edt\u00f3 Ital Haszn\u00e1lata?",dg:"INF\u00d3: A bot minden kiv\u00e1lasztott percben keresni fog piaci t\u00e9teleket, ami meg\u00e1ll\u00edthatja a t\u00e1mad\u00e1st a keres\u00e9s alatt.",ue:"Piaci Keres\u00e9s Enged\u00e9lyez\u00e9se:",eg:"Piaci Keres\u00e9s Id\u0151k\u00f6z Percekben:",fg:"Javasolt 10 perc.",rf:"T\u00e9tel Be\u00e1ll\u00edt\u00e1sok:",pf:"T\u00e9tel N\u00e9v Tartalmazza",
G:"Max \u00c1r",sf:"T\u00e9tel T\u00edpus",qf:"T\u00e9tel Ritkas\u00e1g",de:"L\u00e9lekhez k\u00f6t\u00f6ttet v\u00e1s\u00e1roljon?",uf:"V\u00e1s\u00e1roland\u00f3 T\u00e9telek",tf:"Megpr\u00f3b\u00e1lja megvenni a t\u00e1sk\u00e1ban l\u00e9v\u0151 legnagyobb \u00e1ron tal\u00e1lhat\u00f3 t\u00e9telt, ha b\u00e1rmelyik megegyezik a maxim\u00e1lis \u00e1r be\u00e1ll\u00edt\u00e1ssal.:",be:"Megv\u00e1s\u00e1rolt T\u00e9telek:",hj:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",uk:"\u00c9tel V\u00e1s\u00e1rl\u00e1sa a Boltb\u00f3l?",
vk:"Gy\u00f3gy\u00edt\u00f3 eszk\u00f6z haszn\u00e1lata a Csomagb\u00f3l?",rk:"Cervisia haszn\u00e1lata?",tk:"Toj\u00e1sok haszn\u00e1lata?",zl:"Utols\u00f3 Haszn\u00e1lat",location:"Helysz\u00edn",Strength:"Er\u0151",Dexterity:"\u00dcgyess\u00e9g",Agility:"F\u00fcrges\u00e9g",Constitution:"Alkat",Charisma:"Karizma",Intelligence:"Intelligencia",mi:"Gyakorl\u00e1s Be\u00e1ll\u00edt\u00e1sok",ni:"V\u00e1laszd ki az attrib\u00fatumokat, amiket szeretn\u00e9l edzeni. Akkor fogja elkezdeni az edz\u00e9st, ha van el\u00e9g aranyad.",
N:"K\u00f6vetkez\u0151 l\u00e9p\u00e9s",vj:"Nem",wj:"Norm\u00e1l",Dl:"Ellens\u00e9g",El:"Ellens\u00e9g Szintje",Ij:"K\u00e9rd\u00e9sek",random:"V\u00e9letlenszer\u0171",Nl:"Be\u00e1ll\u00edt\u00e1sok",Yl:"Hamarosan...",type:"Kattints az ikonokra a k\u00e9rd\u00e9s t\u00edpus\u00e1nak kiv\u00e1laszt\u00e1s\u00e1hoz.",em:"Igen",A:"Aukci\u00f3/Keres\u00e9s",Cd:"T\u00e9telek Hozz\u00e1ad\u00e1sa",nk:"Fejleszt\u0151t\u00e1rgyak Aut\u00f3matikus T\u00e1rol\u00e1sa",$l:"Elk\u00fcld\u00e9s",xl:"Id\u0151k\u00f6z : ",
ml:"Aut\u00f3matikus Licit Enged\u00e9lyez\u00e9se",nl:"Ne licit\u00e1ljon, ha az Egyes\u00fcleti tag m\u00e1r licit\u00e1lt",bm:"\u00datmutat\u00f3",hc:"V\u00e1lassz a fenti gombok k\u00f6z\u00fcl, hogy akarod-e az ar\u00e9n\u00e1ban a legkisebb vagy a legmagasabb szint\u0171 ellenfelet. T\u00f6bb felhaszn\u00e1l\u00f3 lass\u00edthatja a bot m\u0171k\u00f6d\u00e9s\u00e9t.",el:"Kezdetnek adj hozz\u00e1 egy t\u00e9telt a list\u00e1hoz (pl. `Lucius`). Miut\u00e1n hozz\u00e1adtad, a bot keresni fogja a t\u00e1rgyakat \u00e9s megjelen\u00edti a keres\u00e9si eredm\u00e9nyeket a k\u00e9perny\u0151 bal oldal\u00e1n. Az aut\u00f3matikus aukci\u00f3 c\u00e9lj\u00e1b\u00f3l is keressen r\u00e1 a t\u00e1rgyra. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, a bot rendszeres id\u0151k\u00f6z\u00f6nk\u00e9nt keresni fogja a t\u00e9teleket a megadott id\u0151szak alapj\u00e1n. Ha a bot megtal\u00e1lja a t\u00e1rgyat \u00e9s van el\u00e9g p\u00e9nzed, aut\u00f3matikusan licit\u00e1l majd helyetted. *Megjegyz\u00e9s*: egyedi t\u00e1rgyak keres\u00e9s\u00e9hez a boltban legal\u00e1bb 1 v\u00e9letlenszer\u0171 t\u00e1rgyat hozz\u00e1 kell adnod a keres\u00e9si list\u00e1hoz.",
pl:"A sz\u00f6rny sz\u00e1m\u00e1t a fenti gombok k\u00f6z\u00fcl v\u00e1laszthatod ki. A 1 a legbaloldali sz\u00f6rnyet k\u00e9pviseli. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",Yi:"V\u00e1lassz nehezs\u00e9get a kazamat\u00e1hoz a fentiek k\u00f6z\u00fcl. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",ij:"Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sok",
Zi:"Felesleges arany t\u00e1rol\u00e1sa az egyes\u00fcletben az egyes\u00fcleti piacon t\u00e1rgyak v\u00e1s\u00e1rl\u00e1s\u00e1val. -> Min. Arany",Al:"Mindent Mozgat",Bl:"Kijel\u00f6ltek Mozgat\u00e1sa",il:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s",jl:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",dm:"Rubin",Lg:"\u00c1ltal\u00e1nos Be\u00e1ll\u00edt\u00e1sok",Mj:"Mindent Elad",Nj:"Kijel\u00f6ltek Elad\u00e1sa",ga:"Fegyverek",da:"Pajzsok",W:"Mellv\u00e9rtek",Z:"Sisakok",Y:"Keszty\u0171k",
ea:"Cip\u0151k",ca:"Gy\u0171r\u0171k",V:"Amulettek",Ci:"\u00c9telek",Bi:"Fejleszt\u00e9sek",dh:"Receptek",sg:"Tekercsek",fh:"Er\u0151s\u00edt\u00e9sek",Zg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",Yg:"\u00cdrja be a sz\u0171rend\u0151 kulcsszavakat, hogy kisz\u0171rje azokat a k\u00fcldet\u00e9seket, amelyeket nem szeretne v\u00e1llalni. You can also use this to accept quests by their reward using keywords.",X:"Adjon meg kulcssz\u00f3t",K:"Hozz\u00e1ad\u00e1s",gh:"Elt\u00e1vol\u00edt\u00e1s",
ge:"T\u00f6rl\u00e9s",Wg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Elfogad\u00e1sa",Xg:"\u00cdrja be a kulcsszavakat, hogy kiv\u00e1lassza, melyik k\u00fcldet\u00e9seket szeretn\u00e9 v\u00e1llalni. Ez figyelmen k\u00edv\u00fcl hagyja a k\u00fcldet\u00e9st\u00edpusokat",Ea:"Id\u0151 Sz\u0171r\u00e9s\u0171 K\u00fcldet\u00e9sek Kihagy\u00e1sa?",Uk:"K\u00fcldet\u00e9sek",Td:"Automatikus Kost\u00fcm",Di:"Kost\u00fcm Haszn\u00e1lata?",Yd:"Alap Harc",pe:"Dungeoni Harc",Ud:"A Bot csak akkor viseli a Dis Pater Normal \u00e9s Medium form\u00e1tumot, ha az exped\u00edci\u00f3/kazamata pontja 0.",
ef:"Pokoli Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sai",Kd:"T\u00e1mad\u00e1s a F\u0151ellens\u00e9g el\u00e9rhet\u0151v\u00e9 v\u00e1l\u00e1sakor?",sb:"Az Ligat\u00e1mad\u00e1s \u00f6nmag\u00e1t letiltja 5 sikertelen t\u00e1mad\u00e1s ut\u00e1n.",hf:"Szent Olajok",Ag:"T\u00e1rgy Neve",ba:"Minim\u00e1lis T\u00e1rgyszint",Ba:"Minim\u00e1lis T\u00e1rgymin\u0151s\u00e9g",Jd:"Alkalmaz/T\u00f6r\u00f6l Minut\u00e9ri\u00e1t",lf:"El\u0151tag/Ut\u00f3tag Kombin\u00e1ci\u00f3 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
Ki:"Igen",Hg:"Nem",Qa:"El\u0151tag Hozz\u00e1ad\u00e1sa",Ra:"Ut\u00f3tag Hozz\u00e1ad\u00e1sa",Hh:"Olvasd el a List\u00e1t",Mb:"El\u0151tag",Zb:"Ut\u00f3tag",mh:"Lej\u00e1r\u00f3 T\u00e1rgyak Vissza\u00e1ll\u00edt\u00e1sa",Ih:"V\u00e9letlenszer\u0171 Olvasd el a Csomagokat?",Jh:"Olvasd el a Lapon",qb:"Extr\u00e1k",Od:"\u00c1rver\u00e9s",ig:"Piac",$b:"Id\u0151z\u00edt\u0151k",hi:"Olvasd el a Minut\u00e9ri\u00e1t",gi:"Olvasd el, ha nincs el\u00e9g arany",di:"Olvasd el, ha nincs t\u00e1rgy",Fa:"Jav\u00edt\u00e1s",
Wh:"Gilda Piac Aranytartalma",Sh:"\u00c1rver\u00e9s Aranytartalma",ki:"Edz\u00e9s",Zh:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa",ii:"\u00dczletek a Kov\u00e1cshoz",Qh:"\u00c1rver\u00e9s Ellen\u0151rz\u00e9se",ai:"Keres\u00e9s",v:"Enged\u00e9lyez\u00e9s",Cg:"Minim\u00e1lis Arany",Ub:"\u00d3ra Kiv\u00e1laszt\u00e1sa",nb:"Arany Adom\u00e1nyoz\u00e1sa a Gildinek",ke:"Minden 5 percenk\u00e9nt adom\u00e1nyoz. Az id\u0151z\u00edt\u0151k lapr\u00f3l m\u00f3dos\u00edthatja az id\u0151k\u00f6zt",jf:"Mennyit szeretne adom\u00e1nyozni?",
le:"Adom\u00e1nyozni, amikor t\u00f6bb van, mint >",wf:"Kevesebb, mint <",jh:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa \u00e9s Egy\u00e9b Be\u00e1ll\u00edt\u00e1sok",lh:"Vissza\u00e1ll\u00edt\u00e1s ideje:",Ok:"Tartsa lenyomva a Ctrl (Cmd a Mac-en) billenty\u0171t a t\u00f6bb t\u00e1rgy kiv\u00e1laszt\u00e1s\u00e1hoz",mf:"Be-/Kiv\u00e1laszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Ue:"Be\u00e1ll\u00edt\u00e1sok Export\u00e1l\u00e1sa",nf:"Be\u00e1ll\u00edt\u00e1sok Import\u00e1l\u00e1sa",tg:"\u00dczenet Minden J\u00e1t\u00e9kosnak",
ug:"[Ultra Pr\u00e9mium Kulcs sz\u00fcks\u00e9ges, \u00fczenet a Discordon az kulcs megszerz\u00e9s\u00e9hez.]",vg:"Adja meg az elk\u00fcldend\u0151 \u00fczenetet",ie:"Egyedi szkriptek\u00e9rt vegye fel a kapcsolatot vel\u00fcnk a Discordon",xg:"K\u00fcld\u00e9s",yg:"J\u00e1t\u00e9kosok Megjelen\u00edt\u00e9se",wg:"Mindet Kiv\u00e1laszt",zg:"\u00d6sszes Kiv\u00e1laszt\u00e1s Visszavon\u00e1sa",vf:"Gy\u0151z\u0151dj\u00f6n meg r\u00f3la, hogy van el\u00e9g hely a t\u00e1sk\u00e1j\u00e1ban. A leh\u0171l\u00e9si id\u0151 2 perc.",
mg:"\u00c9tel Elad\u00e1sa a Piacon?",Gb:"\u00c9telre V\u00e1lt\u00e1s a Piacon?"};if("true"!==localStorage.getItem("isInitialized")){const G={Timers:JSON.stringify({Smelting:10,SmeltingNoGold:5,SmeltingNoItem:15,Repair:10,GuildMarket:2,AuctionHoldGold:15,Arena:10,CircusTurma:10,Training:2,ResetExpired:30,SearchTimer:5,StoreForge:30,AuctionCheck:10,GuildDonate:15,guildBattleEnable:120,BuffTimer:5}),packagesPurchased:"[]",questKeywords:"[]",activeItems:'{"gloves":false,"shoes":false,"rings1":false,"rings2":false,"shield":false,"armor":false,"weapon":false,"helmet":false,"necklace":false}',
auctionPrefixes:"[]",auctionSuffixes:"[]",prefixes:"[]",suffixes:"[]",underworldQuestKeywords:"[]",UnderworldQuests:"false",statSettings:JSON.stringify([{stat:"Strength",count:"0",priority:null,continueTraining:!1},{stat:"Dexterity",count:"0",priority:null,continueTraining:!1},{stat:"Agility",count:"0",priority:null,continueTraining:!1},{stat:"Constitution",count:"0",priority:null,continueTraining:!1},{stat:"Charisma",count:"0",priority:null,continueTraining:!1},{stat:"Intelligence",count:"0",priority:null,
continueTraining:!1}]),farmEnable:"false",farmEnemy:"1",farmLocation:"0",HealPickBag:"1",AutoBidInterval:"5",AuctionItemLevel2:"0",HealShop:"false",noItemsLastCheck:"false",dungeonFocusQuest:"false",smeltBlue:"false",smeltGreen:"false",HealClothToggle:"false",questrewardvalue:"2000",smeltOrange:"false",smeltRed:"false",auctionTURBO:"false",smeltusehammers:"false",BuffsEnable:"false",repairPercentage:"10",HealRubyToggle:"false",dungeonLocation:"0",costumeBasic:"1",costumeDungeon:"2",smeltAnything:"false",
skipTimeQuests:"false",skipTimeCircusQuests:"false",costumeUnderworld:"9",wearUnderworld:"false",hellDifficulty:"1",repairMaxQuality:"1",FoodAmount:"3",smeltIgnorePS:"false",EnableSmelt:"false",filterGM:"p","AuctionEmpty.timeOut":"0","BuffCheck.timeOut":"0","CheckDolls.timeOut":"0","AuctionMEmpty.timeOut":"0",expeditionLocation:"0",auctionMinQuality:"0",doQuests:"false",unique_shop_results_height:"124",unique_shop_results_width:"184",unique_shop_results_top:"452",unique_shop_results_left:"368",search_results_top:"112",
search_results_width:"179",search_results_height:"284",search_results_left:"410",itemBought:"false",itemMovedToInventory:"false",AucTab:"true",patmp:"false",arenaPlayer:"true",repairInitiated:"true",doKasa:"false",packages:JSON.stringify({quality:[],type:[1,2,3,4,5,8,6,9,7,12,13,15,19,20,11,21,18,14,99]}),delaySelect:"0",autoAttackList:"[]",avoidAttackList:"[]",autoAttackCircusList:"[]",avoidAttackCircusList:"[]",autoAttackServerList:"[]",removeCircusList:"[]",removeArenaList:"[]",arenacrosslist:"[]",
circuscrosslist:"[]",autoAttackCircusServerList:"[]",doArena:"false",doCircus:"false","gladBotChecks.timeOut":"0","repair.timeOut":"0","storeForgeResources.timeOut":"0",HealCervisia:"false",dungeonAB:"false",bidStatus:"4",doDungeon:"false",doExpedition:"false",arenaAttackGM:"false",circusAttackGM:"false",AutoAuction:"false",auctionminlevel:"0",storeGoldinAuctionmaxGold:"0",storeGoldinAuction:"false",autoAddArenaAmount:"0",autoAddCircusAmount:"0",eventPoints_:"16",storeGoldinAuctionholdGold:"0",TrainingHoldGold:"0",
smeltLevel:"1",MarketHoldGold:"0",KasaHoldGold:"0",HealPackage:"false",smeltPurple:"false",guildPackHour:"3",smeltEverything3:"false",questSpeed:"2","enableHideGold.timeOut":"0",bidFood:"false",auctionmercenaryenable:"false",auctiongladiatorenable:"false",maximumBid:"100000",activateAuction2:"false",scoreboardattackenable:"false",scoreRange:"5",auctionlanguagesettings:JSON.stringify(["Very long","Long","Middle","Short","Very short"]),scoreboardcircusenable:"false",healPercentage:"25",hellEnterHP:"75",
questTypes:JSON.stringify({combat:!0,arena:!0,circus:!0,expedition:!1,dungeon:!1,items:!1}),scoreRangeCircus:"5",underworld:JSON.stringify({cooldown:"",wins:0,isUnderworld:!1,oj:!1}),enableMarketSearch:"false",smeltTab:"1",UnderWorldUseRuby:"false",renewEvent:"false","arena.timeOut":"0","circus.timeOut":"0",AuctionCover:"false",AuctionGoldCover:"false",UnderworldUseMobi:"false",MarketSearchInterval:"5",useVillaMedici:"false",autoEnterHell:"false",useHealingPotion:"false",repairMercenary:"false",repairALL:"false",
AutoBidButton:"false",healstopbot:"false",HealEnabled:"false",minimumGoldAmount:"100000",doEventExpedition:"false",GuildMemberBid:"false",autoCollectBonuses:"false",exitUnderworld:"false",workbench_selectedItem:JSON.stringify({})};Object.keys(G).forEach(M=>{null===localStorage.getItem(M)&&localStorage.setItem(M,G[M])});["license_playerId","eventPoints","playerTimeouts"].forEach(M=>{null!==localStorage.getItem(M)&&localStorage.removeItem(M)});localStorage.setItem("isInitialized","true")};
