var da="",fa="",we="",showTrial="",qa="",ra={},sa={enable:!1,Zo:10,np:1,repairArena:!0,repairTurma:!0,itemList1:[],itemList2:[]},xa={type:[],quality:[],Kp:!1,useCloths:!1},ya={enable:!1,Nm:!1,en:[1],Zn:3,Bn:3,Wn:3,Yn:3,qn:3,ro:3};function G(E){let J=`${window.location.origin}/game/index.php?`;Object.entries(E).forEach((C,N)=>{J+=(0==N?"":"&")+C[0]+"="+C[1]});return J}function R(E){let J=`${window.location.origin}/game/ajax.php?`;Object.entries(E).forEach((C,N)=>{J+=(0==N?"":"&")+C[0]+"="+C[1]});return J}
async function Aa(E,J){J=await Ja(E,J);if(!J)return!1;J.slot&&await Ka(J.slot,E.dataset.itemId||E.parentNode.dataset.containerNumber);Qa(E,J.x,J.y);return!0}
async function Qa(E,J,C){var N=jQuery(E).offset();N={x:N.left,y:N.top};cb(E,"mousedown",{clientX:N.x-window.scrollX,clientY:N.y-window.scrollY});cb(document,"mousemove",{clientX:J-window.scrollX,clientY:C-window.scrollY});cb(document,"mouseup",{clientX:J-window.scrollX,clientY:C-window.scrollY});setTimeout(()=>{window.scroll(scroll.x,scroll.y)},0)}function nb(E){E=E.getAttribute("data-quality");return null!=E?E:"0"}function tb(E){return parseInt(E.getAttribute("data-amount"),10)}
function ub(E){return E.getAttribute("data-content-type")}function Cb(E){return E.getAttribute("data-level")}function Db(E){return E.getAttribute("data-basis")}
function Eb(E,J){var C=[248,284,275,269,283,282,272,194,259,261,241,166,266,246,258,277,247,270,202,243,242,279,254,274,256,245,250,268,244,281,257,263,278,276,289,262,280,286,267,271,252,255,288,260,264,265];E=parseInt(E.split("-")[0],10);if(![1,2,3,4,5,6,8,9,20].includes(E))return!1;J=J.split("-");E=parseInt(J[6],36);return-1<[173,156,158,182,175,168,180,178,177,162,179,174,172,155,171,183,167,159,166,176,164,157,181,169,161,163,165].indexOf(parseInt(J[5],36))||-1<C.indexOf(E)}
function Fb(E){return parseInt(E.getAttribute("data-measurement-x"),10)*parseInt(E.getAttribute("data-measurement-y"),10)}function Sb(E){E=E.getAttribute("data-tooltip");E=E.substring(4,E.indexOf(",")).replace('"',"");return unescape(JSON.parse('"'+E+'"'))}function Tb(E){E=E.getAttribute("data-tooltip");return parseInt(E.replace(/\./g,"").match(/(\d+) (<img|<div class=\\"icon_gold\\")/i)[1],10)}
function Ub(E){E=parseInt(E.getAttribute("data-basis").split("-")[0],10);return-1<[1,2,3,4,5,6,8,9].indexOf(E)}function Vb(E){for(var J=0,C=0;C<E.length;C++){var N=E[C];J+=N.Xk*N.w}return J}function Wb(E){if("string"!==typeof E)return"";E=E.split(" ");return E[E.length-1]}
async function ec(E,J,C){return new Promise(N=>{async function S(ta){ta===T.length&&S(ta+1);await jQuery.post(T[ta],oa=>{oa=jQuery("<div>").append(oa)[0];oa=Cc(oa);oa=Dc(ka[0],ka[1],oa);(oa=Ec(J,E,oa))?(N({spot:oa,bag:ta+512}),C&&"function"===typeof C&&C(oa,ta+512)):S(ta+1)})}let T=[];for(var ea of[512,513,514,515])T.push(R({mod:"inventory",submod:"loadBag",shopType:0,bag:ea,sh:U("sh")}));let ka=[5,8];S(0)})}var Gc=[],ef={};
function Ka(E,J){if("inv"==E.target||"shop"==E.target){var C=ff(E.target),N=[];for(let S=0;S<E.w;S++)for(let T=0;T<E.Xk;T++)N.push(C+"<"+(E.x+S)+","+(E.y+T)+">");N.forEach(S=>{Gc.includes(S)||Gc.push(S)});J&&(gf(J),ef[J]=N)}}function gf(E){E&&ef.hasOwnProperty(E)&&(ef[E].forEach(J=>{J=Gc.indexOf(J);-1<J&&Gc.splice(J,1)}),delete ef[E])}
function ff(E){let J=document.getElementById(E);return J?"inv"==E?J.parentNode.getElementsByClassName("awesome-tabs current")[0].dataset.Mo:"inv"==E?J.dataset.containerNumber:E:E}
function hf(E,J){var C=E.querySelectorAll('.ui-draggable:not([style*="display: none"])');E=Array(5).fill(null).map(()=>Array(8).fill(!1));const N=parseInt(J.getAttribute("data-measurement-x"),10);J=parseInt(J.getAttribute("data-measurement-y"),10);for(var S of C){C=parseInt(S.getAttribute("data-position-x"),10)-1;var T=parseInt(S.getAttribute("data-position-y"),10)-1,ea=parseInt(S.getAttribute("data-measurement-x"),10),ka=parseInt(S.getAttribute("data-measurement-y"),10);for(let ta=0;ta<ea;ta++)for(let oa=
0;oa<ka;oa++)0<=C+ta&&8>C+ta&&0<=T+oa&&5>T+oa&&(E[T+oa][C+ta]=!0)}for(S=0;5>S;S++)for(C=0;8>C;C++){T=!0;for(ea=0;ea<N;ea++){for(ka=0;ka<J;ka++)if(8<=C+ea||5<=S+ka||E[S+ka][C+ea]){T=!1;break}if(!T)break}if(T)return{x:C,y:S}}return null}
function jf(E){var J=E.querySelectorAll('.ui-draggable:not([style*="display: none"])');E=Array(5).fill(null).map(()=>Array(8).fill(!1));for(var C of J){J=parseInt(C.getAttribute("data-position-x"),10)-1;const N=parseInt(C.getAttribute("data-position-y"),10)-1,S=parseInt(C.getAttribute("data-measurement-x"),10),T=parseInt(C.getAttribute("data-measurement-y"),10);for(let ea=0;ea<S;ea++)for(let ka=0;ka<T;ka++)0<=J+ea&&8>J+ea&&0<=N+ka&&5>N+ka&&(E[N+ka][J+ea]=!0)}for(C=0;5>C;C++)for(J=0;8>J;J++)if(!E[C][J])return{x:J,
y:C};return null}
async function Ja(E,J){var C=!1;if("shop"==J){var N=document.getElementById("shop");var S=[Math.round(N.clientHeight/32),6];C="shop"}else if("inv-guild"==J)Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));else if("inv"==J)N=document.getElementById("inv"),S=[5,8],C="inv";else{if("market"==J){N=document.getElementById("market_sell");var T=jQuery(N).offset();return{x:Math.ceil(T.left+32+8),y:Math.ceil(T.top+32+8),parent:N}}if("avatar"==J)return N=document.getElementById("avatar"),
T=jQuery(N).offset(),{x:Math.ceil(T.left+84),y:Math.ceil(T.top+97),parent:N};if("char"==J)for(var ea=document.getElementById("char").children,ka=Number(E.dataset.contentType||"0"),ta=0;ta<ea.length;ta++){var oa=ea[ta];if(Number(oa.getAttribute("data-content-type-accept")||"0")==ka&&0==ea[ta].children.length)return T=jQuery(oa).offset(),{x:T.left+5,y:T.top+5}}else return!1}ea=Cc(N);ka=parseInt(E.dataset.measurementX,10);ta=parseInt(E.dataset.measurementY,10);try{var vb;if(vb="shop"!=J)a:{let Fc=E.dataset.amount?
parseInt(E.dataset.amount,10):1;for(oa=0;oa<ea.length;oa++)if(ea[oa].hash==E.dataset.hash&&100>=ea[oa].amount+Fc){vb={y:ea[oa].y,x:ea[oa].x};break a}vb=!1}var Ua=vb||Ec(ta,ka,Dc(S[0],S[1],ea,C));if(!Ua)return!1;T=jQuery(N).offset();T={x:T.left,y:T.top};return Ua={x:Math.ceil(T.x+32*Ua.x+8),y:Math.ceil(T.y+32*Ua.y+8),parent:N,slot:{target:J,x:Ua.x,y:Ua.y,Xk:ta,w:ka}}}catch{return!1}}
function Cc(E){if(!E)return[];var J=[];E=E.getElementsByClassName("ui-draggable");for(var C=0;C<E.length;C++)J.push({y:parseInt(E[C].style.top,10)/32,x:parseInt(E[C].style.left,10)/32,Xk:parseInt(E[C].dataset.measurementY,10),w:parseInt(E[C].dataset.measurementX,10)});return J}
function Dc(E,J,C,N){var S=[];for(var T=0;T<E;T++){S.push([]);for(var ea=0;ea<J;ea++)S[T].push(!1)}for(T=C.length-1;0<=T;T--)for(ea=0;ea<C[T].Xk;ea++)for(let ka=0;ka<C[T].w;ka++)S[C[T].y+ea][C[T].x+ka]=!0;if(N)for(C=ff(N),N=0;N<E;N++)for(T=0;T<J;T++)S[N][T]||Gc.includes(C+"<"+T+","+N+">")&&(S[N][T]=!0);return S}
function Ec(E,J,C){var N,S,T,ea,ka=!1;for(N=0;N<=C[0].length-J;N++){for(S=0;S<=C.length-E;S++){ka=!0;if(1==E)0==C[S][N]?ka=!0:0==C[S][N+1]?N++:ka=!1;else for(T=0;T<J;T++){for(ea=0;ea<E;ea++)if(1==C[S+ea][N+T]){ka=!1;break}if(!ka)break}if(ka){for(T=0;T<J;T++)for(ea=0;ea<E;ea++)C[S+ea][N+T]=!0;ka={y:S,x:N};break}}if(ka)break;1==E&&N++}return ka}
function cb(E,J,C){var N="mousemove"!==J,S=window;var T=C.clientX;C=C.clientY;var ea=document.createEvent("MouseEvents");ea.initMouseEvent(J,!0,N,S,0,0,0,T,C,!1,!1,!1,!1,0,document.body.parentNode);E.dispatchEvent(ea)}
function kf(){new Promise(E=>{let J=2,C=()=>{--J;0===J&&E()};if(lf.includes("mod=auction")&&lf.includes("ttype=3")){var N=mf();(N<localStorage.getItem("auctionMStatus")&&W("AuctionMEmpty")||4===N&&W("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",N);C()}else lf.includes("mod=auction")?(N=mf(),(N<localStorage.getItem("auctionStatus")&&W("AuctionEmpty")||4===N&&W("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",0),localStorage.setItem("auctionStatus",
N),C()):(jQuery.get(G({mod:"auction",ttype:3,itemLevel:999,itemQuality:2,sh:U("sh")}),S=>{S=mf(jQuery(S));(S<localStorage.getItem("auctionMStatus")&&W("AuctionMEmpty")||4===S&&W("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",S);C()}),jQuery.get(G({mod:"auction",itemLevel:999,itemQuality:2,sh:U("sh")}),S=>{S=mf(jQuery(S));(S<localStorage.getItem("auctionStatus")&&W("AuctionEmpty")||4===S&&W("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",
0);localStorage.setItem("auctionStatus",S);C()}))})}function nf(E){if(document.querySelector("#inv div.spinner-img"))return setTimeout(()=>{nf(E)},500),!1;E&&E();return!0}var of=new URLSearchParams(window.location.search);function U(E){return of.get(E)}
var lf=window.location.search.match(/mod=.*&sh/)?window.location.search.match(/mod=.*&sh/)[0].slice(0,-3):null,xf=window.location.hostname.split(/\./)?window.location.hostname.split(/\./)[0]:null,yf={wp:{j:"muito longo",g:"longo",h:"m\u00e9dio",i:"curto",l:"muito curto"},xp:{j:"foarte lung",g:"lung",h:"mijlociu",i:"scurt",l:"foarte scurt"},Bp:{j:"ve\u013emi dlho",g:"dlho",h:"stredne",i:"kr\u00e1tko",l:"ve\u013emi kr\u00e1tko"},Mp:{j:"jako dugo",g:"dugo",h:"srednje",i:"kratko",l:"jako kratko"},$o:{j:"hyvin pitk\u00e4",
g:"pitk\u00e4",h:"keskim\u00e4\u00e4r\u00e4inen",i:"lyhyt",l:"hyvin lyhyt"},zp:{j:"mycket l\u00e5ng",g:"l\u00e5ng",h:"medel",i:"kort",l:"mycket kort"},Ep:{j:"\u00e7ok uzun",g:"uzun",h:"orta",i:"k\u0131sa",l:"\u00e7ok k\u0131sa"},Jo:{j:"\u0637\u0648\u064a\u0644 \u062c\u062f\u0627\u064b",g:"\u0637\u0648\u064a\u0644",h:"\u0645\u0646\u062a\u0635\u0641",i:"\u0642\u0635\u064a\u0631",l:"\u0642\u0635\u064a\u0631\u0629 \u062c\u062f\u0627\u064b"},ip:{j:"\u05d0\u05e8\u05d5\u05da \u05de\u05d0\u05d5\u05d3",g:"\u05d0\u05e8\u05d5\u05da",
h:"\u05d1\u05d9\u05e0\u05d5\u05e0\u05d9",i:"\u05e7\u05e6\u05e8",l:"\u05e7\u05e6\u05e8 \u05de\u05d0\u05d5\u05d3"},ep:{j:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",g:"\u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",h:"m\u03ad\u03c3\u03b7",i:"\u03bc\u03b9\u03ba\u03c1\u03ae",l:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b9\u03ba\u03c1\u03ae"},No:{j:"\u043c\u043d\u043e\u0433\u043e \u0434\u044a\u043b\u044a\u0433",g:"\u0434\u044a\u043b\u044a\u0433",h:"\u0441\u0440\u0435\u0434\u0435\u043d",i:"\u043a\u044a\u0441",
l:"\u043c\u043d\u043e\u0433\u043e \u043a\u044a\u0441"},yp:{j:"\u043e\u0447\u0435\u043d\u044c \u043c\u043d\u043e\u0433\u043e",g:"\u043c\u043d\u043e\u0433\u043e",h:"\u0441\u0440\u0435\u0434\u043d\u0435",i:"\u043c\u0430\u043b\u043e",l:"\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e"},Oo:{j:"muito tempo",g:"longo",h:"m\u00e9dio",i:"curto",l:"bastante curto"},So:{j:"velmi dlouh\u00e1",g:"dlouh\u00e1",h:"st\u0159edn\u00ed",i:"kr\u00e1tk\u00e1",l:"velmi kr\u00e1tk\u00e1"},Uo:{j:"meget lang tid",
g:"lang tid",h:"halv tid",i:"kort tid",l:"meget kort tid"},To:{j:"sehr lange",g:"lange",h:"mittel",i:"kurz",l:"sehr kurz"},Vo:{j:"v\u00e4ga pikk",g:"pikk",h:"keskmine",i:"l\u00fchike",l:"v\u00e4ga l\u00fchike"},Wo:{j:"very long",g:"long",h:"middle",i:"short",l:"very short"},Jp:{j:"very long",g:"long",h:"middle",i:"short",l:"very short"},Ko:{j:"muy largo",g:"largo",h:"medio",i:"corto",l:"muy corto"},Yo:{j:"muy largo",g:"largo",h:"medio",i:"corto",l:"muy corto"},op:{j:"muy largo",g:"largo",h:"medio",
i:"corto",l:"muy corto"},ap:{j:"tr\u00e8s longtemps",g:"longtemps",h:"moyen",i:"court",l:"tr\u00e8s court"},kp:{j:"lunghissima",g:"lunga",h:"media",i:"breve",l:"brevissima"},mp:{j:"\u013coti gar\u0161",g:"gar\u0161",h:"vid\u0113js",i:"\u012bss",l:"\u013coti \u012bss"},lp:{j:"labai ilgai",g:"ilgai",h:"vidutini\u0161kai",i:"trumpai",l:"labai trumpai"},hp:{j:"nagyon hossz\u00fa",g:"hossz\u00fa",h:"k\u00f6zepes",i:"r\u00f6vid",l:"nagyon r\u00f6vid"},pp:{j:"heel lang",g:"lang",h:"gemiddeld",i:"kort",l:"zeer kort"},
cj:{j:"veldig lenge",g:"lenge",h:"medium",i:"kortvarig",l:"veldig kort"},vp:{j:"bardzo d\u0142ugi",g:"d\u0142ugi",h:"\u015bredni",i:"kr\u00f3tki",l:"bardzo kr\u00f3tki"},Hp:{j:"\u8d85\u9577",g:"\u8f03\u9577",h:"\u5e38\u898f\u6642\u9593",i:"\u8f03\u77ed",l:"\u8d85\u77ed"}},mf=(E=document)=>{E=jQuery(".description_span_right",E).text().trim().toLowerCase();for(const J in yf){const C=yf[J],N=Object.values(C);for(const S in C)if(C[S].toLowerCase()===E)return N.indexOf(C[S])}return-1};
async function zf(E="-1",J=""){const C=G({mod:"packages",submod:"sort",page:"1",sh:U("sh")});jQuery.post(C,{packageSorting:"in_desc"});return Promise.all(Array.from({length:2},(N,S)=>S+1).map(async N=>await Af(E,J,N))).then(N=>N.reduce((S,T)=>S.concat(T),[]))}async function Af(E="-1",J="",C){E=await jQuery.get(G({mod:"packages",f:"0",fq:E||-1,qry:J||"",page:C,sh:U("sh")}),()=>{});return Array.from(jQuery(E).find(".packageItem"))}function Bf(E){setTimeout(()=>{window.location.reload(!1)},E)}
function Cf(E){window.location.href=`${window.location.origin}/game/index.php?${E}&sh=${U("sh")}`}function yh(E){E&&(E.classList.contains("disabled")?window.location.reload():E.click())}
function zh(){return{o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,"")),Gn:document.querySelectorAll("#cooldown_bar_expedition .cooldown_bar_fill_ready")[0],En:document.querySelectorAll("#cooldown_bar_dungeon .cooldown_bar_fill_ready")[0],Gp:document.querySelectorAll("#cooldown_bar_ct .cooldown_bar_fill_ready")[0],Ea:document.getElementById("expeditionpoints_value_point").innerText,Dn:document.getElementById("dungeonpoints_value_point").innerText,
Lo:document.querySelectorAll("#cooldown_bar_arena .cooldown_bar_fill_ready")[0],$m:parseInt(document.getElementById("sstat_ruby_val").innerText,10),level:parseInt(document.getElementById("header_values_level").innerText,10)}}function W(E){let J=(new Date).getTime(),C=localStorage.getItem(E+".timeOut");null===C?(localStorage.setItem(E+".timeOut",0),C=0):C=parseInt(C,10);return C<=J?!0:!1}
function Ah(){let E=0;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(J=>{E+=Math.round(.04*J.price)});return zh().gold>=E?!0:!1}function Bh(E,J){J-=E;let C=.04*E;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(N=>{C+=Math.round(.04*N.price)});return J>=C}function X(E,J){localStorage.setItem(E+".timeOut",(new Date).getTime()+Math.floor(6E4*(J?J:5)))};(async function(){function E(){pf=setInterval(function(){qf++;5>=qf?location.reload():clearInterval(pf)},12E4)}function J(){var b="Pantheon;Panteon;Gudarnas tempel;\u0628\u0627\u0646\u062a\u064a\u0648\u0646;\u041f\u0430\u043d\u0442\u0435\u043e\u043d;Panth\u00e9on;\u795e\u8aed;\u05e4\u05e0\u05ea\u05d9\u05d0\u05d5\u05df".split(";"),c=null;for(var e of b)if(c=document.querySelector(`a[title="${e}"]`))break;return c&&(b=c.innerHTML,(e=b.match(/<font color="green">(\d+)<\/font>/))&&0<e[1]||b.includes('color="green"')||
b.includes("Nowe")||b.includes("Yeni")||b.includes("New")||b.includes('color="yellow"')||b.includes("Yeni")||b.includes("Nowe")||b.includes("New")||(c=c.innerText.match(/Pantheon \((\d+)\)/))&&0<c[1])?(localStorage.setItem("nextQuestTime",0),localStorage.setItem("nextQuestTime.timeOut",0),!0):!1}function C(b){function c(h){let l=localStorage.getItem(h);l&&(l=JSON.parse(l),localStorage.setItem(h,JSON.stringify(l.slice(-20))))}var e=document.querySelector("#logEntriesContainer");if(e){var g=new Date,
k=`${g.getHours().toString().padStart(2,"0")}:${g.getMinutes().toString().padStart(2,"0")}`;g=document.createElement("p");g.style.margin="0";g.style.padding="0";g.style.fontSize="12px";b=`[${k}] ${b}`;g.textContent=b;e.prepend(g);(e=localStorage.getItem("savedLogs"))?e=JSON.parse(e):e=[];e.unshift(b);30<e.length&&e.pop();localStorage.setItem("savedLogs",JSON.stringify(e));c("bidList");c("smeltedItems");c("MarketboughtItems")}}function N(b,c){switch(b){case "itemRepaired":ja.nm++;break;case "itemReset":ja.om++;
break;case "goldCycled":ja.lm++;break;case "arenaAttacks":ja.bm++;break;case "circusAttacks":ja.fm++;break;case "dungeonAttacks":ja.hm++;break;case "expeditionAttacks":ja.im++;break;case "itemSmelted":ja.pm++;break;case "underworldAttacks":ja.zm++;break;case "arenaMoney":ja.Pl+=c;break;case "circusMoney":ja.Ql+=c}localStorage.setItem("userStats",JSON.stringify(ja))}function S(){db||(db=document.createElement("div"),db.className="confirmation-popup",db.innerHTML='\n                <p>Are you sure you want to reset the bot?</p>\n                <button id="confirmReset">Yes</button>\n                <button id="cancelReset">No</button>\n            ',
document.body.appendChild(db),document.getElementById("confirmReset").addEventListener("click",function(){const b=["tkz_lcr","Username","tkn","nana_lcn"];let c=[];for(let e=0;e<localStorage.length;e++){const g=localStorage.key(e);!g||b.includes(g)||g.startsWith("gladiatusCrazyAddonData_")||c.push(g)}for(const e of c)localStorage.removeItem(e);window.location.reload();db.style.display="none"}),document.getElementById("cancelReset").addEventListener("click",function(){db.style.display="none"}));db.style.display=
"block"}function T(b,c){return null==b?"":b.split("").map(e=>String.fromCharCode(e.charCodeAt(0)+c)).join("")}async function ea(b,c,e,g){g=T(g,3);const k={action:"vx",data:{token:b,refreshToken:c,playerId:e,Xo:g}};try{const h=await Promise.race([new Promise((l,n)=>{chrome.runtime.sendMessage(k,m=>{chrome.runtime.Vn||!m?n(chrome.runtime.Vn||"No response"):l(m)})}),new Promise(l=>setTimeout(()=>l("timeout"),6E4))]);if("timeout"===h)await new Promise(l=>setTimeout(l,1E3)),window.location.reload();else if(h.success||
h.s){const l=h.data||h.d;if(l.valid&&!l.expired)return da=l.playerId,qa=l.supportDevs,"true"!==localStorage.getItem("nana_lcn")&&localStorage.setItem("nana_lcn","true"),l.announcement&&0<=l.announcement.length&&localStorage.getItem("latestAnnouncement")!==l.announcement&&localStorage.setItem("latestAnnouncement",l.announcement),await ta(l.supportDevs).then(n=>{fa=n}),!0;if(l.expired&&(sessionStorage.setItem("autoGoActive","false"),l.newToken))return l.newToken&&(localStorage.setItem("token",l.newToken+
1),localStorage.setItem("nana_lcn","false"),da=Xb()+"l",eb()),!1}else new Promise(l=>setTimeout(()=>l("timeout"),3E4))}catch(h){return window.location.reload(),!1}}function ka(b){return((localStorage.getItem("playerId")|0)+5|0)%100===b}async function ta(b){function c(l){const n=[];for(let m=0;m<l.length;m+=2)n.push(parseInt(l.substr(m,2),16));return new Uint8Array(n)}const [e,g]=b.split(":");b=c(e);const k=c(g),h=await window.crypto.subtle.importKey("raw",c("46d9ef519c1474cf8699ba24ab2a726a"),{name:"AES-CBC"},
!1,["decrypt"]);b=await window.crypto.subtle.decrypt({name:"AES-CBC",iv:b},h,k);b=(new TextDecoder).decode(new Uint8Array(b));b=new Date(b);b.setHours(0,0,0,0);return b}function oa(b){(b.target.classList.contains("licotok-close")||"licotok"===b.target.id)&&document.getElementById("licotok").remove()}async function vb(){Xb();const b=document.getElementById("licotok-input").value.trim(),c=localStorage.getItem("playerId"),e=document.getElementById("status_message");const u=localStorage.getItem("idkps");let response=null;try{response=await fetch('https://gldbotserver.com/validate-license',
{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idkps:u,license:b}),});const data=await response.json();if(data.valid){localStorage.setItem("nana_lcn","true"),localStorage.setItem("tkz_lcr",data.token),localStorage.setItem("license_remaining",data.expirationDate),localStorage.setItem("tkn",data.refreshToken),localStorage.setItem("we",data.p),localStorage.setItem("pid",c),ba=c,window.location.reload()
}else{e.textContent=data.message||"Invalid license key or token! Just purchased? Wait 10 minutes before activating the key.";e.style.display="block";}}catch(error){alert("Erro no servidor de autenticação");}}function Ua(b){var c=document.createElement("div");c.setAttribute("id","licotok");c.innerHTML=`
        <style>
            .licotok-popup {
            background: #ddd5b4; /* Beige background */
            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            color: #333; /* Darker text color for better contrast */
            padding: 20px;
            border: 1px solid #c4ac70; /* Golden border */
            font-family: Arial, sans-serif; /* Optional: Change the font */
            }
        
            .licotok-popup h2 {
            color: #333;
            text-shadow: none; /* Removing text shadow for better readability */
            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */
            padding: 10px;
            margin: -20px; /* To offset the padding of the parent */
            margin-bottom: 15px;
            border-radius: 10px 10px 0 0; /* Rounded corners on the top */
            }
        
            .licotok-popup a {
            text-decoration: none;
            color: #fff; /* White text for buttons */
            background-color: #c4ac70; /* Golden background */
            border-radius: 5px;
            padding: 5px 10px;
            margin-right: 10px;
            transition: background-color 0.3s ease;
            }
        
            .licotok-popup a:hover {
            background-color: #b3a369; /* Darker shade on hover */
            }
        
            .licotok-popup input {
            width: calc(100% - 10px); /* Full width minus padding */
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #c4ac70; /* Border color similar to the theme */
            border-radius: 5px;
            }
        

            
            .licotok-popup #status_message {
            margin-top: 10px;
            }
        </style>
        <div class="licotok-popup">
        <h2>Warning</h2>
        <span style="color: black" class="span-new">${b}</span>
        <p>
        <button id="licotok-close" class="awesome-button">Close</button>
        <div id="status_message"></div>
    </div>
        
        `;document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);c.querySelector("#licotok-close").addEventListener("click",function(){c.remove()})}function Fc(){var b=document.createElement("div");b.setAttribute("id","licotok");b.innerHTML='\n        <style>\n            .licotok-popup {\n            background: #ddd5b4; /* Beige background */\n            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n            border-radius: 10px;\n            color: #333; /* Darker text color for better contrast */\n            padding: 20px;\n            border: 1px solid #c4ac70; /* Golden border */\n            font-family: Arial, sans-serif; /* Optional: Change the font */\n            }\n        \n            .licotok-popup h2 {\n            color: #333;\n            text-shadow: none; /* Removing text shadow for better readability */\n            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */\n            padding: 10px;\n            margin: -20px; /* To offset the padding of the parent */\n            margin-bottom: 15px;\n            border-radius: 10px 10px 0 0; /* Rounded corners on the top */\n            }\n        \n            .licotok-popup a {\n            text-decoration: none;\n            color: #fff; /* White text for buttons */\n            background-color: #c4ac70; /* Golden background */\n            border-radius: 5px;\n            padding: 5px 10px;\n            margin-right: 10px;\n            transition: background-color 0.3s ease;\n            }\n        \n            .licotok-popup a:hover {\n            background-color: #b3a369; /* Darker shade on hover */\n            }\n        \n            .licotok-popup input {\n            width: calc(100% - 10px); /* Full width minus padding */\n            padding: 5px;\n            margin-bottom: 10px;\n            border: 1px solid #c4ac70; /* Border color similar to the theme */\n            border-radius: 5px;\n            }\n        \n\n            \n            .licotok-popup #status_message {\n            margin-top: 10px;\n            }\n        </style>\n        <div class="licotok-popup">\n            <h2>Enter Your License Key</h2>\n            <input id="licotok-input" type="text" placeholder="License Key">\n            &nbsp<a href="https://gldbotserver.com" target="_blank">Buy GLDbot license</a>\n                        <a href="https://gldbot.gumroad.com/l/gladiatusbot" target="_blank">Gumroad official page</a>\n                        <p>\n            <a href="#" id="get-trial-key-a">Get a Trial Key</a>\n            <a href="" target="_blank">Discord</a>\n                       <div id="alertMessage" class="alert-message" style="display: none; font-weight: bold;"></div>\n\n      <hr>      <li>\n             <span style="color: class="span-new">[BRASIL] Experimente o teste gratuito de 1 dia. A licença ficará salva na aba “Extras” caso você esqueça. Se você limpar a cache ou reinstalar o navegador. Você deve inserir sua chave novamente para ativar o bot.</span>\n            </li>\n      <hr>      <li>\n            <span style="color: class="span-new">[ENGLISH] Try 1 day free trial. The license will be saved in the "Extras" tab in case you forget it. If you clear your caches or reinstall the browser. You have to enter your key again to enable the bot.</span>\n     <hr>       </li>\n            <p>\n            <span style="color: class="span-new">If you have some questions or suggestions, contact us E-mail: <strong>gldbotsuport@gmail.com</strong></span>\n\n  <br>          <button class="awesome-button licotok-submit">Submit</button>\n            <button class="awesome-button licotok-close">Close</button>\n            <div id="status_message"></div>\n        </div>\n        ';
document.getElementById("header_game").insertBefore(b,document.getElementById("header_game").children[0]);b.addEventListener("click",oa);b.querySelector(".licotok-submit").addEventListener("click",vb);let c=localStorage.getItem("idkps");if(null==c)try{Xb(),c=localStorage.getItem("idkps")}catch{}b.querySelector("#get-trial-key-a").addEventListener("click",function(){async function e(g){return fetch(g,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({playerId:c})}).then(k=>
k.json()).then(k=>{var h=document.getElementById("alertMessage");k.success?(h.textContent="Your 1 day trial key : "+k.trialKey,h.style.display="block",showTrial=k.trialKey,localStorage.setItem("showTrial",k.trialKey)):(h.textContent=k.message,h.style.display="block")})}e("https://gldbotserver.com/get-trial").catch(()=>e("https://gldbotserver.com/get-trial")).catch(()=>{})})}
function Xb(){let b;if(!b){const c=/var playerId\s*=\s*(\d+);/;Array.from(document.getElementsByTagName("script")).some(e=>(e=c.exec(e.textContent||e.innerText))&&e[1]?(b=e[1],!0):!1)}if(!b){const c=document.getElementById("content");c&&c.querySelectorAll('section[style="display: block;"]').forEach(e=>{Array.from(e.getElementsByTagName("p")).forEach(g=>{Array.from(g.getElementsByTagName("b")).forEach(k=>{k=k.textContent.trim();k.includes("gladiatus.gameforge.com/game/index.php?mod=player&")&&(b=(new URLSearchParams((new URL(k)).search)).get("p"))})})})}b||
(document.cookie.split("; ").forEach(c=>{c.trim().startsWith("gladiatus")&&!b&&(c=decodeURIComponent(c.split("=")[1]).match(/^\d+/))&&(b=c[0])}),document.cookie.split("; ").forEach(c=>{c.trim().startsWith("GB_")&&!b&&(c=c.split("=")[1].split("_"),b=0<c.length&&!isNaN(c[0])?c[0]:null)}));let cc=b;return b?(localStorage.setItem("playerId",18835),localStorage.setItem("pid",18835),localStorage.setItem("idkps",cc),18835):null}function Jh(){let b=document.querySelector(".playername")||document.querySelector(".playername_achievement");b&&(b=b.textContent.trim(),
localStorage.setItem("Username",b))}async function rest(){const autoGoButton=document.getElementById("autoGoButton");if(autoGoButton)autoGoButton.remove();const customButtons=document.querySelectorAll(".customButton2");customButtons.forEach(button=>button.remove());sessionStorage.setItem("autoGoActive",!1);}async function pt(){Xb();const idkps=localStorage.getItem("idkps");try{const response=await fetch('https://gldbotserver.com/validate-key',{method:'POST',headers:{'Content-Type':'application/json',},body:JSON.stringify({idkps}),});const d=await response.json();if(d.valid){localStorage.setItem("we",d.p);vf();}else{rest().then(()=>{eb();}).catch(error=>{console.error("rest:",error);});}}catch(error){alert("Erro ao conectar com o servidor de autenticação");}}async function rf(){try{const b=await jQuery.get(G({mod:"premium",submod:"centurio",sh:U("sh")})),c=(new DOMParser).parseFromString(b,"text/html").querySelector("#premium_duration");if(c){const e=c.textContent.trim().match(/(\d+)/);if(e&&e[1]){const g=parseInt(e[1],10);localStorage.setItem("premiumDays",g);if(0<g)return!1}else return!0}}catch(b){}}function ob(b,c,e){var g="";e&&(g=new Date,g.setTime(g.getTime()+864E5*e),g="; expires="+g.toUTCString());document.cookie=
b+"="+(c||"")+g+"; path=/; domain=.gameforge.com"}function wb(b){b+="=";for(var c=document.cookie.split(";"),e=0;e<c.length;e++){for(var g=c[e];" "===g.charAt(0);)g=g.substring(1,g.length);if(0===g.indexOf(b))return g.substring(b.length,g.length)}return null}function Yb(b){document.cookie=`glautologin=${b?"true":"false"}; path=/; domain=.gameforge.com; samesite=strict`}async function Hc(){const z5 = localStorage.getItem("we");we = new Date(z5);return"true"===localStorage.getItem("nana_lcn")&&Zb&&fa>=new Date&&we>=new Date&&ua===Ic&&da===ua}function Jc(b,c){b.style.border=
"1px solid #c4ac70";b.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";b.style.color="#bfae54";b.style.padding="5px 10px";b.style.cursor="pointer";b.style.borderRadius="5px";b.style.flexGrow="1";b.style.marginRight="5px";b.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";b.style.fontFamily="Arial, sans-serif";b.style.transition="background-color 0.2s"}function sf(){localStorage.setItem("logMenuHeight",ma.style.height)}function Kh(){let b=document.querySelector(".playername_achievement.ellipsis");b&&localStorage.setItem("Username",
b.textContent.trim())}async function Lh(){var b={async wm(){var c=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${localStorage.getItem("filterGM")}&p=1`;if(lf!==c)Cf(c);else try{const n=localStorage.getItem("guildPackHour");let m=JSON.parse(localStorage.getItem("packagesPurchased")||"[]");if(m.length){var e=m[0],g=await zf(e.quality,e.itemName);g=g.filter(r=>{r=r.querySelector(".ui-draggable");return e.itemLevel===Cb(r)&&e.itemName===Sb(r)&&e.basis===Db(r)&&e.quality===nb(r)&&e.amount===tb(r)});
if(g.length&&g[0].querySelector(".ui-draggable")){const r=g[0].querySelector(".ui-draggable");Cb(r);Sb(r);Db(r);nb(r);tb(r);var k=parseInt(r.getAttribute("data-measurement-x"),10),h=parseInt(r.getAttribute("data-measurement-y"),10),l=g[0].querySelector("input").value;let {spot:u,bag:x}=await ec(k,h);const q=await jQuery.post(R({mod:"inventory",submod:"move",from:"-"+l,fromX:1,fromY:1,to:x,toX:u.x+1,toY:u.y+1,amount:e.amount}),{a:(new Date).getTime(),sh:U("sh")}),t=JSON.parse(q).to.data.itemId;c=0;
if(2>c||q.includes("containerNumber"))if((await jQuery.post(G({mod:"guildMarket",sh:U("sh")}),{sellid:t,preis:e.price,dauer:n||3,sell_mode:0,anbieten:"Offer"})).includes("<!DOCTYPE HTML>"))C("Item "+e.itemName+" sold for "+e.price+" gold"),N("goldCycled",0),m.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(m)),window.location.reload();else if(c++,2>c)await this.wm();else{const w=JSON.parse(localStorage.getItem("Timers"));X("gold",w.GuildMarket||2);window.location.reload()}}else m.shift(),
localStorage.setItem("packagesPurchased",JSON.stringify(m)),window.location.reload()}}catch(n){C("Empty first slots of the first inventory at least 2x3."),window.location.reload()}},async tn(c,e){let g=c.shift();var k=!1;const h={GUILD_TOOLS:["2097152","1048576","8388608","4194304"],GUILD_WEAPONS:["2"],GUILD_SHIELD:["4"],GUILD_CHEST:["8"],GUILD_HELMET:["1"],GUILD_GLOVES:["256"],GUILD_SHOES:["512"],GUILD_RINGS:["48"],GUILD_AMULETS:["1024"],GUILD_USABLES:["4096"],GUILD_FOOD:["64"],GUILD_UPGRADES:["4096"],
GUILD_RECIPES:["8192"],GUILD_MERCENARY:["16384"],GUILD_SCROLLS:["64"],GUILD_REINFORCEMENTS:["4096"]};let l=JSON.parse(localStorage.getItem("itemsToResetGuild")||"[]");for(l=l.map(n=>!n.startsWith("GUILD_")&&h["GUILD_"+n]?"GUILD_"+n:n);g;){const n=g.type;(0===l.length||l.some(m=>h[m]?.includes(n)))&&Bh(g.price,e)&&e>=g.price&&(e-=g.price,await jQuery.post(G({mod:"guildMarket",sh:U("sh")}),{buyid:g.id,f:0,fl:0,fq:-1,p:1,buy:"Comprar"}),k=JSON.parse(localStorage.getItem("packagesPurchased")||"[]"),k.push(g),
localStorage.setItem("packagesPurchased",JSON.stringify(k)),C("Item Bought: "+g.itemName+" for "+g.price),k=!0);g=c.shift()}return k},async buy(){const c=localStorage.getItem("filterGM"),e=JSON.parse(localStorage.getItem("Timers"));let g=Number(localStorage.getItem("currentPage")||1);var k=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${g}`;if(lf!==k)Cf(k);else if(!(aa.gold<=Math.floor(localStorage.getItem("KasaHoldGold")))){var h=document.querySelectorAll("#market_item_table tr"),l=document.querySelectorAll("#market_item_table input[name=buyid]");
k=[];for(let n=1;n<h.length;n++){let m=h[n].querySelectorAll("td"),r=m[0].querySelector("div"),u=Number(m[2].innerText.replace(/\./g,"")),x=m[5].querySelector("input");"cancel"===x.name||x.classList.contains("disabled")||u<Number(localStorage.getItem("minimumGoldAmount"))||u>zh().gold-Number(localStorage.getItem("KasaHoldGold"))||k.push({id:l[n-1].value,itemLevel:Cb(r),itemName:Sb(r),basis:Db(r),type:ub(r),quality:nb(r),amount:tb(r),sellerName:m[1].querySelector("span").innerText,price:u})}h=zh().gold-
Number(localStorage.getItem("KasaHoldGold"));if(k.length&&Ah())await this.tn(k,h)||X("gold",e.GuildMarket||2),window.location.reload();else try{const n=document.querySelector(".standalone").textContent.match(/(\d+)\s*\/\s*(\d+)/);g<(n?parseInt(n[2],10):1)?(localStorage.setItem("currentPage",g+1),Cf(`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${g+1}`)):(localStorage.setItem("currentPage",1),X("gold",e.GuildMarket||2),window.location.reload())}catch(n){C("No items to buy in guild market today. :/"),
localStorage.setItem("currentPage",1),X("gold",e.GuildMarket||2),window.location.reload()}}}};0<JSON.parse(localStorage.getItem("packagesPurchased")||"[]").length?await b.wm():aa.gold>Number(localStorage.getItem("minimumGoldAmount"))+Number(localStorage.getItem("KasaHoldGold"))?await b.buy():(b=JSON.parse(localStorage.getItem("Timers")),X("gold",b.GuildMarket||2),window.location.reload())}function Mh(){var b=document.getElementById("submenuhead1"),c=document.getElementById("submenu1"),e=document.getElementById("submenuhead2"),
g=document.getElementById("submenu2"),k=document.getElementById("main");k&&(k.style.height="950px",k.style.minHeight="950px");b&&(b.style.display="block");c&&(c.style.display="block");e&&(e.style.display="none");g&&(g.style.display="none")}function Kc(){var b=localStorage.getItem("premiumDicesLeft");b=parseInt(b,10);return isNaN(b)?0:b}function Nh(){var b=document.querySelector(".contentboard_footer_long .contentboard_inner");if(b){b.style.position="relative";b.style.overflowX="visible";b.style.overflowY=
"visible";b.style.height="auto";b.style.minHeight="450px !important";var c=document.createElement("div");c.id="customContainer";c.style.cssText="border: 2px solid #BA9700; padding: 10px; margin-top: 20px;  border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5); text-align: center; width: 100%; box-sizing: border-box; min-height: 400px;";b.appendChild(c);b=document.createElement("button");b.textContent="Start";b.className="button1";b.style.marginTop="10px";c.appendChild(b);var e=document.createElement("button");
e.textContent="Stop";e.className="button1";e.style.marginTop="10px";c.appendChild(e);var g=document.createElement("div");g.id="dicesLeft";var k=Kc();g.textContent=`Dices left: ${k}`;g.style.fontWeight="bold";g.style.marginTop="10px";c.appendChild(g);g=document.createElement("div");g.textContent='GLDBot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.';g.style.marginTop="5px";c.appendChild(g);g=document.createElement("div");
g.id="results";g.style.cssText="display: flex; flex-wrap: wrap; justify-content: center; gap: 5px; margin-top: 10px; overflow-x: hidden; overflow-y: auto; max-height: 400px;";c.appendChild(g);var h=document.createElement("div");h.id="progressIndicator";h.textContent="Ready to start.";h.style.marginTop="10px";c.appendChild(h);b.addEventListener("click",async function(){h.textContent="Processing...";await Oh()});e.addEventListener("click",function(){h.textContent="Process stopped by user. Completed!";
window.location.reload()});Ph()}}function Ph(){let b;var c=document.querySelector(".mysterybox_count");c=c?parseInt(c.textContent,10):0;localStorage.setItem("chestsLeft",c);var e=document.getElementById("mysterybox_luck");if(e)for(var g of e.childNodes)if(g.nodeType!==Node.TEXT_NODE&&g.nodeType===Node.ELEMENT_NODE)if("IMG"===g.tagName&&g.currentSrc.includes("4197f09a37be7d221c34f3e0d957e7.png"))break;else"INPUT"===g.tagName&&"button"===g.type&&(e=g.getAttribute("onclick").match(/tokenAmount=(\d+)/))&&
e[1]&&(b=parseInt(e[1],10));g=document.getElementById("dicesLeft");e=Kc();g.textContent=0>b?"Dices left: Cannot determine. Please refresh the page.":`Dices left: ${e}`;localStorage.setItem("chestsLeft",c);localStorage.setItem("premiumDicesLeft",b)}async function Oh(){0>=parseInt(localStorage.getItem("premiumDicesLeft"),10)?alert("No dices left!"):await Lc()}async function Lc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");
if(!b||0>=b&&0>=c)e.textContent="All actions completed: No dices or chests left.";else if(!b||0>=b)e.textContent="No dices left. Trying to open remaining chests...",await $b();else if(!c||0>=c)e.textContent="No chests left!";else{e.textContent="Refreshing mystery box...";var g=(new URL(window.location.href)).searchParams.get("sh")||"",k=document.querySelectorAll(".mysterybox_reward_item_pool"),h="Vulcano;Junos;Bergzorns;Weitsicht;Eole;Junon;Armure;Masque;Vulcain;Neptuno;Eolo;Armatura;Sguardo;Olhos;Alento;Nettuno;Respiro;Soffio;mortal de;Aliento;Armadura;Vista;Zbroja;Orli;Neptuna;Feronii;Wulkana;Wrath;Eagle;Pluto;Neptune;Vulcanus;Junosa;Plutosa;Ajolos;Vulcano;Feronia;Feronias;Plutos;Neptun;Aeolus;Pluton;Juno;Ejderha;Kartal;nefesi".split(";"),
l=!1;for(let n of k){const m=n.getAttribute("data-tooltip");if(h.some(r=>m.includes(r))){l=!0;break}}if(l)await $b();else try{const n=await jQuery.get(G({mod:"mysterybox",submod:"refresh",Dp:b,sh:g}));b--;localStorage.setItem("premiumDicesLeft",b);const m=document.getElementById("dicesLeft"),r=Kc();m.textContent=`Dices left: ${r}`;const u=(new DOMParser).parseFromString(n,"text/html").querySelectorAll(".mysterybox_reward_item_pool");g="Vulcano Feronia Neptun Aeolus Pluton Juno Ejderha Kartal nefesi".split(" ");
k=!1;for(let x of u){const q=x.getAttribute("data-tooltip");if(q&&g.some(t=>q.includes(t))){k=!0;break}}k?await $b():0<b?setTimeout(Lc,1E3):0<c?await $b():(e.textContent="Completed all possible actions.",C("No more actions possible: No premium dices or chests left."))}catch(n){C("Error refreshing mystery box. Please try again.")}}}async function $b(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");
if(!c||0>=c)e.textContent="No chests left to open!";else{e.textContent="Opening chest...";var g=(new URL(window.location.href)).searchParams.get("sh")||"",k=(new Date).getTime();try{const h=await jQuery.get(R({mod:"mysterybox",submod:"pick",sh:g,a:k}));b--;c--;localStorage.setItem("premiumDicesLeft",b);localStorage.setItem("chestsLeft",c);(new DOMParser).parseFromString(h,"text/html");const l=document.querySelector(`.mysterybox_reward_item_pool img[alt="${h}"]`);if(l){const n=document.createElement("div");
n.className="result-item";n.style.border="1px solid #ccc";n.style.borderRadius="5px";n.style.padding="2px";n.style.margin="1px";n.style.textAlign="center";n.style.backgroundColor="#fff";n.style.boxShadow="0 0 5px rgba(0, 0, 0, 0.1)";n.style.boxSizing="border-box";n.style.flex="1 0 20%";const m=document.createElement("img");m.src=l.src;m.alt="Item Image";m.className="result-image";m.style.maxWidth="50px";m.style.display="block";m.style.margin="0 auto";const r=document.createElement("span"),u=l.closest(".mysterybox_reward_item_pool").getAttribute("data-tooltip").match(/"([^"]+)"/);
r.textContent=u?u[1]:"Unknown Item";r.style.display="block";r.style.marginTop="5px";r.style.fontSize="12px";n.appendChild(m);n.appendChild(r);document.querySelector("#results").appendChild(n)}0<b||0<c?(e.textContent="Chest opened. Checking for more actions...",setTimeout(Lc,1E3)):e.textContent="All dices and chests used up."}catch(h){C("Error opening chest. Please try again.")}}}function Va(){Mc.length=0;document.querySelectorAll(".rule-row").forEach(b=>{const c=b.querySelector(".rule-condition-select").value;
var e=b.querySelector(".rule-prefix-input"),g=b.querySelector(".rule-suffix-input");e=e?e.value:"";g=g?g.value:"";const k=b.querySelector(".rule-level").value,h=Array.from(b.querySelectorAll(".item-icon.selected")).map(m=>m.dataset.type),l=Array.from(b.querySelectorAll(".color-circle.selected")).map(m=>m.dataset.color),n=b.querySelector(".rule-hammer-selection img.selected");b=b.querySelector(".rule-checkbox");Mc.push({condition:c,prefix:e,suffix:g,colors:l,itemTypes:h,hammerState:n?n.dataset.hammer:
"none",level:k,isEnabled:b?b.checked:!0})});localStorage.setItem("smeltingSettings",JSON.stringify(Mc))}function Qh(){document.querySelectorAll(".item-icon").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Va()})})}function Rh(){document.querySelectorAll(".color-circle").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Va()})})}function Sh(){document.querySelectorAll(".rule-row .rule-hammer-selection img").forEach(b=>{b.addEventListener("click",
function(){const c=this.closest(".rule-hammer-selection").querySelectorAll("img");this.classList.contains("selected")?this.classList.remove("selected"):(c.forEach(e=>e.classList.remove("selected")),this.classList.add("selected"));Va()})})}function Th(){document.querySelectorAll(".rule-condition-select").forEach(b=>{b.addEventListener("change",function(){const c=this.closest(".rule-row").querySelector(".rule-prefix-input"),e=this.closest(".rule-row").querySelector(".rule-suffix-input");"nameContains"===
this.value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");Va()})})}function Uh(){document.querySelectorAll(".rule-prefix-input, .rule-level").forEach(b=>{b.addEventListener("input",Va)});document.querySelectorAll(".rule-suffix-input, .rule-level").forEach(b=>{b.addEventListener("input",Va)})}function Vh(){document.querySelectorAll(".rule-row .remove-rule-btn").forEach(b=>{b.addEventListener("click",function(){b.closest(".rule-row").remove();Va()})})}
function tf(){const b=document.querySelector(".rule-row-template").cloneNode(!0);b.classList.remove("rule-row-template");b.classList.add("rule-row");b.style.display="block";b.querySelector(".rule-prefix-input").value="";b.querySelector(".rule-suffix-input").value="";b.querySelector(".rule-level").value="";b.querySelector(".rule-checkbox").checked=!0;b.querySelectorAll(".selected").forEach(g=>g.classList.remove("selected"));const c=b.querySelector(".rule-prefix-input"),e=b.querySelector(".rule-suffix-input");
"nameContains"===b.querySelector(".rule-condition-select").value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");document.querySelector(".rule-container").insertBefore(b,document.querySelector(".add-rule-btn"));uf();Va()}function Wh(){document.querySelectorAll(".rule-checkbox").forEach(b=>{b.addEventListener("change",Va)});document.querySelectorAll(".rule-checkbox-wrapper").forEach(b=>{b.addEventListener("click",function(){const c=this.querySelector(".rule-checkbox");
c.checked=!c.checked;Va()})})}function uf(){Th();Qh();Rh();Sh();Vh();Uh();Wh()}function Xh(b){const c="white green blue purple orange red".split(" ");return b.sort((e,g)=>c.indexOf(e)-c.indexOf(g))}function Yh(){const b=document.querySelector(".rule-row-template");var c=JSON.parse(localStorage.getItem("smeltingSettings"))||[];document.querySelectorAll(".rule-row").forEach(e=>{e.remove()});if(0===c.length){c=b.cloneNode(!0);c.classList.remove("rule-row-template");c.classList.add("rule-row");c.style.display=
"block";const e=c.querySelector(".rule-suffix-input");c.querySelector(".rule-prefix-input").style.display="block";e.style.display="block";document.querySelector(".rule-container").insertBefore(c,document.querySelector(".add-rule-btn"))}else c.forEach(e=>{const g=b.cloneNode(!0);g.classList.remove("rule-row-template");g.classList.add("rule-row");g.style.display="block";g.querySelector(".rule-condition-select").value=e.condition;var k=g.querySelector(".rule-prefix-input");const h=g.querySelector(".rule-suffix-input");
"nameContains"===e.condition?(k.style.display="block",k.value=e.prefix,h.style.display="block",h.value="undefined"===typeof e.suffix?null:e.suffix):(k.style.display="none",h.style.display="none");g.querySelector(".rule-level").value=e.level;e.itemTypes.forEach(l=>{(l=g.querySelector(`.item-icon[data-type="${l}"]`))&&l.classList.add("selected")});e.colors.forEach(l=>{(l=g.querySelector(`.color-circle[data-color="${l}"]`))&&l.classList.add("selected")});"none"!==e.hammerState&&(k=g.querySelector(`.rule-hammer-selection img[data-hammer="${e.hammerState}"]`))&&
k.classList.add("selected");g.querySelector(".rule-checkbox").checked=!1!==e.isEnabled;document.querySelector(".rule-container").insertBefore(g,document.querySelector(".add-rule-btn"))});uf()}function Nc(){Ea.colors=Xh(Ea.colors);localStorage.setItem("smeltRandomlySettings",JSON.stringify(Ea))}function Zh(){document.querySelectorAll(".item-icon2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.type;this.classList.contains("selected")?(this.classList.remove("selected"),Ea.itemTypes=
Ea.itemTypes.filter(e=>e!==c)):(this.classList.add("selected"),Ea.itemTypes.push(c));Nc()})});document.querySelectorAll(".rule-color-selection2 .color-circle2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),Ea.colors=Ea.colors.filter(e=>e!==c)):(this.classList.add("selected"),Ea.colors.push(c));Nc()})});document.querySelectorAll(".rule-color-resetColors .color-circle3").forEach(b=>{b.addEventListener("click",
function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),ac.colors=ac.colors.filter(e=>e!==c)):(this.classList.add("selected"),ac.colors.push(c));localStorage.setItem("resetColors",JSON.stringify(ac))})});document.querySelectorAll(".rule-hammer-selection2 img").forEach(b=>{b.addEventListener("click",function(){this.classList.contains("selected")?(this.classList.remove("selected"),Ea.hammerState="none"):(document.querySelectorAll(".rule-hammer-selection2 img").forEach(c=>
c.classList.remove("selected")),this.classList.add("selected"),Ea.hammerState=this.dataset.hammer);Nc()})})}function $h(){const b=JSON.parse(localStorage.getItem("resetColors"))||{};b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-resetColors .color-circle3[data-color="${c}"]`))&&c.classList.add("selected")})}function ai(){var b=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{};b.itemTypes&&b.itemTypes.forEach(c=>{(c=document.querySelector(`.item-icon2[data-type="${c}"]`))&&
c.classList.add("selected")});b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-selection2 .color-circle2[data-color="${c}"]`))&&c.classList.add("selected")});b.hammerState&&"none"!==b.hammerState&&(b=document.querySelector(`.rule-hammer-selection2 img[data-hammer="${b.hammerState}"]`))&&b.classList.add("selected")}async function Oc(b){function c(q){let t=q.target.name;q=Number(q.target.value);let w=JSON.parse(localStorage.getItem("gods"));w||={Zn:3,Bn:3,Wn:3,Yn:3,qn:3,ro:3};w[t]=
q;localStorage.setItem("gods",JSON.stringify(w))}function e(){document.getElementById("items-repaired").textContent=ja.nm;document.getElementById("items-reset").textContent=ja.om;document.getElementById("gold-cycled").textContent=ja.lm;document.getElementById("arena-attacks").textContent=ja.bm;document.getElementById("circus-attacks").textContent=ja.fm;document.getElementById("dungeons-attacked").textContent=ja.hm;document.getElementById("expeditions-attacked").textContent=ja.im;document.getElementById("items-smelted").textContent=
ja.pm;document.getElementById("underworld-attacks").textContent=ja.zm;document.getElementById("arena-money").textContent=Math.floor(1E3*ja.Pl).toLocaleString();document.getElementById("circus-money").textContent=Math.floor(1E3*ja.Ql).toLocaleString()}function g(){var q=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||[],t=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];h("IgnoredprefixList",q,"IgnoredPrefixes");h("IgnoredsuffixList",t,"IgnoredSuffixes");q=JSON.parse(localStorage.getItem("auctionPrefixes"))||
[];t=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];h("AuctionprefixList",q,"auctionPrefixes");h("AuctionsuffixList",t,"auctionSuffixes");var w=JSON.parse(localStorage.getItem("smeltedItems"))||[];t=document.getElementById("smeltedList");let y=JSON.parse(localStorage.getItem("bidList"))||[];for(q=document.getElementById("bidList");t.firstChild;)t.firstChild.remove();for(var A of w)w=document.createElement("li"),w.textContent=A,t.appendChild(w);for(;q.firstChild;)q.firstChild.remove();for(let B of y)A=
document.createElement("li"),A.textContent=B,q.appendChild(A)}function k(q,t,w){""!==t.trim()&&(q=JSON.parse(localStorage.getItem(w))||[],q.push(t),localStorage.setItem(w,JSON.stringify(q)),g())}function h(q,t,w){let y=document.getElementById(q);y.innerHTML="";t.forEach((A,B)=>{let v=document.createElement("li");v.textContent=A;v.draggable=!0;v.setAttribute("data-index",B);B=document.createElement("button");B.textContent="X";B.style.marginLeft="10px";B.addEventListener("click",function(){let D=t.indexOf(A);
-1<D&&(t.splice(D,1),localStorage.setItem(w,JSON.stringify(t)),h(q,t,w))});v.appendChild(B);y.appendChild(v)});l(y,t,w)}function l(q,t,w){let y=-1;q.addEventListener("dragstart",A=>{y=parseInt(A.target.getAttribute("data-index"),10)});q.addEventListener("dragover",A=>{A.preventDefault()});q.addEventListener("drop",A=>{A.preventDefault();A=parseInt(A.target.closest("li").getAttribute("data-index"),10);0<=A&&0<=y&&([t[y],t[A]]=[t[A],t[y]],localStorage.setItem(w,JSON.stringify(t)),h(q.id,t,w));g()})}
function n(){setInterval(()=>{if(W("randomPause")){const q=localStorage.getItem("selectedPauseDuration");m(q)}},6E4)}function m(q){let t,w;switch(q){case "1":w=8;t={mod:"work",submod:"start",sh:U("sh"),Rl:1,Zl:w,Ul:2};break;case "2":w=6;t={mod:"work",submod:"start",sh:U("sh"),Rl:1,Zl:w,Ul:3};break;case "3":w=3;t={mod:"work",submod:"start",sh:U("sh"),Rl:1,Zl:w,Ul:4};break;case "4":w=10;t={mod:"work",submod:"start",sh:U("sh"),Rl:1,Zl:w,Ul:5};break;case "5":w=4,t={mod:"work",submod:"start",sh:U("sh"),
Rl:1,Zl:w,Ul:6}}$.post(R({}),t).done(()=>{setTimeout(()=>{location.reload()},6E4*(w+1));X("randomPause",Math.floor(1440*Math.random())+600)}).fail(()=>{})}const r=b.dataset.target;document.querySelectorAll(".popup-tab").forEach(q=>{q.classList.remove("active")});b.classList.add("active");document.querySelectorAll(".popup-box").forEach(q=>{q.classList.remove("active")});document.getElementById(r).classList.add("active");document.querySelectorAll("input[type=radio]").forEach(q=>{q.addEventListener("change",
c);let t=JSON.parse(localStorage.getItem("gods"));t&&void 0!==t[q.name]&&(q.checked=q.value==t[q.name])});document.getElementById("reset-stats-button").addEventListener("click",()=>{ja.nm=0;ja.om=0;ja.lm=0;ja.bm=0;ja.fm=0;ja.hm=0;ja.im=0;ja.pm=0;ja.zm=0;ja.Pl=0;ja.Ql=0;localStorage.setItem("userStats",JSON.stringify(ja));e()});e();b=document.querySelector(".add-rule-btn");b.removeEventListener("click",tf);b.addEventListener("click",tf);Yh();$h();ai();document.getElementById("smeltLootbox").checked=
"true"===localStorage.getItem("smeltLootbox");document.getElementById("smeltLootbox").addEventListener("change",function(){localStorage.setItem("smeltLootbox",this.checked)});document.getElementById("smelteverything3").checked="true"===localStorage.getItem("smelteverything3");document.getElementById("smelteverything3").addEventListener("change",function(){localStorage.setItem("smelteverything3",this.checked)});document.getElementById("smeltAnything").checked="true"===localStorage.getItem("smeltAnything");
document.getElementById("smeltAnything").addEventListener("change",function(){localStorage.setItem("smeltAnything",this.checked)});document.getElementById("RepairBeforeSmelt").checked="true"===localStorage.getItem("RepairBeforeSmelt");document.getElementById("RepairBeforeSmelt").addEventListener("change",function(){localStorage.setItem("RepairBeforeSmelt",this.checked)});document.getElementById("IgnoredaddPrefixButton").onclick=function(){let q=document.getElementById("newIgnoredPrefixInput").value;
k("IgnoredprefixList",q,"IgnoredPrefixes")};document.getElementById("IgnoredaddSuffixButton").onclick=function(){let q=document.getElementById("newIgnoredSuffixInput").value;k("IgnoredsuffixList",q,"IgnoredSuffixes")};document.getElementById("clearSmeltedItemsHistory").addEventListener("click",function(){localStorage.setItem("smeltedItems",JSON.stringify([]));g()});g();document.getElementById("clearBidItemsHistory").addEventListener("click",function(){localStorage.setItem("bidList",JSON.stringify([]));
g()});document.getElementById("AuctionaddPrefixButton").onclick=function(){let q=document.getElementById("AuctionnewPrefixInput").value;k("AuctionprefixList",q,"auctionPrefixes")};document.getElementById("AuctionaddSuffixButton").onclick=function(){let q=document.getElementById("AuctionnewSuffixInput").value;k("AuctionsuffixList",q,"auctionSuffixes")};document.getElementById("pauseDuration").addEventListener("change",q=>{q=q.target.value;localStorage.setItem("selectedPauseDuration",q);localStorage.setItem("randomPause.timeOut",
0);"0"!==q&&(X("randomPause",Math.floor(1440*Math.random())),n())});document.getElementById("exportBtn").addEventListener("click",function(q){q.preventDefault();if(!q.target.getAttribute("data-clicked")){q.target.setAttribute("data-clicked","true");q={};var t="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");for(var w in localStorage)t.includes(w)||
(q[w]=localStorage.getItem(w));w=JSON.stringify(q);w=URL.createObjectURL(new Blob([w],{type:"application/json"}));q=document.createElement("a");q.href=w;q.download="GladBotSettings.json";q.click()}},{once:!0});b=document.getElementById("importFileBtn");const u=document.getElementById("importBtn"),x=document.getElementById("importStatus");b&&u&&x&&(b.addEventListener("click",function(){u.click()}),u.addEventListener("change",function(q){if(q=q.target.files[0]){var t=new FileReader;t.onload=function(w){try{const y=
JSON.parse(w.target.result);w="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");for(let A in y)w.includes(A)||localStorage.setItem(A,y[A]);x.textContent="Import successful! Please refresh the page."}catch(y){x.textContent="Import failed. Please check the input file and try again."}};t.readAsText(q)}}));b=document.createElement("div");
b.id="loadingSpinner";b.innerHTML='\n                <div class="spinner"></div>\n                <div class="loading-text">0</div>\n              ';document.querySelector("#selectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(q=>{q.checked=!0;q.dispatchEvent(new Event("change"))})});document.querySelector("#unselectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(q=>{q.checked=!1;q.dispatchEvent(new Event("change"))})})}
function bi(){const b=document.getElementById("expeditionLocation"),c=document.getElementById("dungeonLocation");var e=document.querySelectorAll("#submenu2 a");const g=[];for(let k=1;k<e.length;k++)e[k].classList.contains("glow")||g.push(e[k]);g.forEach(k=>{const h=document.createElement("option");h.innerText=k.innerText;h.value=(new URLSearchParams(k.href)).get("loc");b.appendChild(h);c.appendChild(h.cloneNode(!0))});if(e=localStorage.getItem("expeditionLocation"))b.value=e;if(e=localStorage.getItem("dungeonLocation"))c.value=
e}function pb(b,c,e){const g=document.createElement("li"),k="object"===typeof b?b.playerName:b;g.textContent=k;b=document.createElement("button");b.textContent="X";b.style.marginLeft="10px";b.addEventListener("click",()=>{g.remove();var h=JSON.parse(localStorage.getItem(e))||[];h=e.includes("ServerList")?h.filter(l=>"object"===typeof l&&l.playerName!==k):h.filter(l=>l!==k);localStorage.setItem(e,JSON.stringify(h))});g.appendChild(b);(c=document.getElementById(c))&&c.appendChild(g)}function bc(b,c,
e){pb(b,c,e);c=JSON.parse(localStorage.getItem(e))||[];e.includes("ServerList")?c.push({playerName:b}):c.push(b);localStorage.setItem(e,JSON.stringify(c))}function ci(){const b=JSON.parse(localStorage.getItem("autoAttackList"))||[],c=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],e=JSON.parse(localStorage.getItem("avoidAttackList"))||[],g=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[],k=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[],h=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||
[];b.forEach(l=>pb(l,"autoAttackList","autoAttackList"));c.forEach(l=>pb(l,"autoAttackServerList","autoAttackServerList"));e.forEach(l=>pb(l,"avoidAttackList","avoidAttackList"));g.forEach(l=>pb(l,"avoidAttackCircusList","avoidAttackCircusList"));k.forEach(l=>pb(l,"autoAttackCircusList","autoAttackCircusList"));h.forEach(l=>pb(l,"autoAttackCircusServerList","autoAttackCircusServerList"))}function vf(){sessionStorage.setItem("autoGoActive","true");document.getElementById("autoGoButton").innerHTML=
'<span style="position: relative; top: -9px;">&#9724;</span>';document.getElementById("autoGoButton").removeEventListener("click",vf);document.getElementById("autoGoButton").addEventListener("click",wf);location.reload()}function wf(){sessionStorage.setItem("autoGoActive","false");window.location.reload()}function cc(){const b=document.getElementById("popup-header"),c=document.getElementById("overlayBack");b&&(localStorage.setItem("AucTab",!0),b.remove());c&&c.remove()}function dc(){function b(v){localStorage.setItem("settings.language",
v);switch(v){case "EN":d={...Ch};break;case "PL":d={...Dh};break;case "ES":d={...Eh};break;case "TR":d={...Fh};break;case "FR":d={...Gh};break;case "HG":d={...Hh};break;case "BR":d={...Ih};break;default:d={...Ch}}cc();dc()}function c(v){Ba=v;localStorage.setItem("doExpedition",v)}function e(v){Pc=v;localStorage.setItem("monsterId",v)}function g(v){Fa=v;localStorage.setItem("doDungeon",v)}function k(v){Gb=v;localStorage.setItem("dungeonDifficulty",v);h(v)}function h(v){$(".monster-button").removeClass("active");
$(`#set_dungeon_difficulty_${v}`).addClass("active")}function l(v){Ga=v;localStorage.setItem("doArena",v)}function n(v){Ca=v;localStorage.setItem("doCircus",v)}function m(v){La=v;localStorage.setItem("doQuests",v)}function r(v){Ma[v]=!Ma[v];localStorage.setItem("questTypes",JSON.stringify(Ma));cc();dc()}function u(v){Da=v;localStorage.setItem("doEventExpedition",v)}function x(v){fc=v;localStorage.setItem("eventMonsterId",v);cc();dc()}function q(){var v=localStorage.getItem("doExpedition");null!==
v&&(Ba=JSON.parse(v));1==Ba?$("#doExpedition").prop("checked",!0):$("#doExpedition").prop("checked",!1);v=localStorage.getItem("doDungeon");null!==v&&(Fa=JSON.parse(v));1==Fa?$("#doDungeon").prop("checked",!0):$("#doDungeon").prop("checked",!1);v=localStorage.getItem("doArena");null!==v&&(Ga=JSON.parse(v));1==Ga?$("#doArena").prop("checked",!0):$("#doArena").prop("checked",!1);v=localStorage.getItem("doCircus");null!==v&&(Ca=JSON.parse(v));1==Ca?$("#doCircus").prop("checked",!0):$("#doCircus").prop("checked",
!1);v=localStorage.getItem("doQuests");null!==v&&(La=JSON.parse(v));1==La?$("#doQuests").prop("checked",!0):$("#doQuests").prop("checked",!1);v=localStorage.getItem("AutoAuction");null!==v&&(Xa=JSON.parse(v));1==Xa?$("#activateAutoBid").prop("checked",!0):$("#activateAutoBid").prop("checked",!1);v=localStorage.getItem("doKasa");null!==v&&(fb=JSON.parse(v));1==fb?$("#doKasa").prop("checked",!0):$("#doKasa").prop("checked",!1);v=localStorage.getItem("doEventExpedition");null!==v&&(Da=JSON.parse(v));
1==Da?$("#doEventExpedition").prop("checked",!0):$("#doEventExpedition").prop("checked",!1);$("#expedition_settings").addClass(Ba?"active":"inactive");$(`#do_expedition_${Ba}`).addClass("active");$(`#set_monster_id_${Pc}`).addClass("active");$("#dungeon_settings").addClass(Fa?"active":"inactive");$(`#do_dungeon_${Fa}`).addClass("active");$(`#set_dungeon_difficulty_${Gb}`).addClass("active");$("#arena_settings").addClass(Ga?"active":"inactive");$(`#do_arena_${Ga}`).addClass("active");$(`#set_arena_opponent_level_${Df}`).addClass("active");
$("#circus_settings").addClass(Ca?"active":"inactive");$(`#do_circus_${Ca}`).addClass("active");$(`#set_circus_opponent_level_${Ef}`).addClass("active");$("#quests_settings").addClass(La?"active":"inactive");$(`#do_quests_${La}`).addClass("active");for(const D in Ma)Ma[D]&&$(`#do_${D}_quests`).addClass("active");$("#auto_auction_settings").addClass(Xa?"active":"inactive");$("#event_expedition_settings").addClass(Da?"active":"inactive");$(`#do_event_expedition_${Da}`).addClass("active");$(`#set_event_monster_id_${fc}`).addClass("active")}
var t=document.getElementById("popup-header"),w=document.getElementById("overlayBack");t&&t.remove();w&&w.remove();t=document.createElement("div");t.setAttribute("id","popup-header");w="1.1.2 esta ativa, reinicie o navegador. Melhorando o reparo de itens para a proxima versão!  1.1.2 is live. Improving repair for the next version!";t.innerHTML=`
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

            <div id="popupSmelt" class="popup">
                <div class="smelt-instructions" style="text-align: left; padding-left: 5px;">
                    <ul style="list-style-position: inside;">
                        <li>1. ${d.Ej}</li>
                        <li>2. ${d.Fj}</li>
                        <li>3. ${d.Gj}</li>
                        <li>4. ${d.Hj}</li>

                        <br>${d.Ij}</br>
                        <br>${d.Jj}</br>
                    </ul>
                </div>
                <img src="https://raw.githubusercontent.com/fociisoftware/glbt/refs/heads/main/Smelt2.gif" alt="Smelt Info" style="width: 350px; height: auto;">
            </div>

            <div id="announcement" class="announcement">
                ${w}
            </div>

            <div class="popup-menu">
                <div class="popup-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: inline-block;"><a style="color: white" href="" target="_blank">Version 1.1.2</a></span>
                <span style="display: inline-block;"><a style="color: white" href="" target="_blank">Discord</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbot.gumroad.com/l/gladiatusbot" target="_blank">News</a></span>
                <div style="display: flex; justify-content: space-between; align-items: right;">    
                <div class="menu-type logo" style="width: 48px; height: 48px; margin-right: 250px;"></div>
            
              </div>

              <span id="settingsLanguage" style="margin-left: 300px; right: 17px; top: 32px;">          
                <img class="menu-type GB" id="languageGB"> 
                <img class="menu-type PL" id="languagePL"> 
                <img class="menu-type ES" id="languageES"> 
                <img class="menu-type TR" id="languageTR">
                <img class="menu-type FR" id="languageFR">
                <img class="menu-type HG" id="languageHG">
                <img class="menu-type BR" id="languageBR">
                <br>
                <a style="color: white" href="">Donate</a>
                 - 
                 <a style="color: white" href="" target="_blank"> Tutorial</a>
                 -
                <span style="color: white;">Try a Trial <span style="color: red;">&#10084;</span></span>
                 </span>
              
              </div><span id="settingsLanguage"></span>

              <div class="popup-content">
                <ul class="popup-tabs">
                
                <li class="popup-tab" data-target="expedition_settings">
                    <div class="headericon_big" id="icon_expeditionpoints" style="margin-left: 4px;"></div>

                    ${d.expedition}
                    <div class="toggle-switch">
                    <input type="checkbox" id="doExpedition">
                    <label class="switch" for="doExpedition"></label>
                    </div>
                </li>

                  <li class="popup-tab" data-target="dungeon_settings">
                  <div class="headericon_big" id="icon_dungeonpoints" style="margin-left: 4px;"></div>
                  ${d.dungeon}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doDungeon">
                      <label class="switch" for="doDungeon"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="arena_settings">
                  <div class="headericon_big" id="icon_arena" style="margin-left: 4px;"></div>
                  ${d.arena}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doArena">
                      <label class="switch" for="doArena"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="circus_settings">
                  <div class="headericon_big" id="icon_grouparena" style="margin-left: 4px;"></div>
                  ${d.circusTurma}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doCircus">
                      <label class="switch" for="doCircus"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="underworld_settings">
                  <div class="quest-type underworld" style="margin-left: 4px;"></div>
                  ${d.ji}
                    <div class="toggle-switch">
                      <input type="checkbox" id="autoEnterHell">
                      <label class="switch" for="autoEnterHell"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="quests_settings">
                  <div class="quest-type menu"></div>
                  ${d.sj}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doQuests">
                      <label class="switch" for="doQuests"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="heal_settings">
                  <div class="quest-type potion"></div>
                  ${d.Vi}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doHeal">
                      <label class="switch" for="doHeal"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="event_expedition_settings">
                  <div class="quest-type event"></div>${d.eventExpedition}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doEventExpedition">
                      <label class="switch" for="doEventExpedition"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_auction_settings">
                  <div class="quest-type search"></div>
                  ${d.A}
                  
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateAutoBid">
                      <label class="switch" for="activateAutoBid">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_auction2_settings">
                    <div class="quest-type auction"></div>
                    ${d.yd}
                    <div class="toggle-switch ">
                      <input type="checkbox" id="activateAuction2">
                      <label class="switch" for="activateAuction2">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_smelt_settings">
                  <div class="quest-type smelt"></div>${d.th}
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateSmelt">
                      <label class="switch" for="activateSmelt">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_repair_settings">
                  <div class="quest-type repair"></div>
                  ${d.Fb}
                  <div class="toggle-switch">
                    <input type="checkbox" id="activateRepair">
                    <label class="switch" for="activateRepair">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="Market">
                  <div class="quest-type market"></div>
                  ${d.Xf}
                  <div class="toggle-switch">
                  <div class="toggle-bg"></div>
                  </div>
                  </li>

                  <li class="popup-tab" data-target="guild_settings">
                    <div class="quest-type guild"></div>
                    ${d.Ri}
                    <div class="toggle-bg"></div>
                  </li>
                  
                 
                  <li class="popup-tab" data-target="Timers">
                    <div class="quest-type timer"></div>
                    ${d.Pb} 
                    <div class="toggle-switch">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="other_settings2">
                  <div class="quest-type reset">
                  </div>${d.Zg}
                  </li>
                  

                  <li class="popup-tab" data-target="other_settings">
                  <div class="quest-type settings"></div>
                  ${d.zg}
                  <div class="toggle-bg"></div>
                  </li>

                  


                  <li class="popup-tab" data-target="Extra">
                  <div class="quest-type extra">
                  </div>${d.hb}
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div> </li>

                </ul>

            <div class="popup-box" id="expedition_settings">

                <div class="settings-tab">
                    <div class="settings_tab_title">${d.Mi}</div>
                    <div class="setting-row">
                        <label for="expeditionLocation">${d.Ce}</label>
                        <select id="expeditionLocation"></select>
                    </div>

                    <div class="setting-row">
                        <label for="autoCollectBonuses">${d.Cd}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoCollectBonuses">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="enemySelection" class="setting-row">
                        <label for="enemySelect">${d.vj}:</label>
                        <select id="enemySelect">
                            <option value="0">1</option>
                            <option value="1">2</option>
                            <option value="2">3</option>
                            <option value="3">Boss</option>
                        </select>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="postExpeditionAction">${d.qj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="postExpeditionAction">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                </div>
  
            </div>
            
                <div class="popup-box" id="dungeon_settings">
                  <div class="settings_tab_title">${d.Ii}</div>
                  <div class="settings-tab">
                    <div class="setting-row">      
                      <label for="dungeonLocation">${d.ae}</label>
                      <select id="dungeonLocation"></select>
                    </div>

                    <div class="setting-row">
                      <span class="span-new">${d.Hi}</span>
                        <div id="set_dungeon_difficulty_normal" class="monster-button">
                          ${d.dj}
                        </div>
                        <div id="set_dungeon_difficulty_advanced" class="monster-button">
                          ${d.advanced}
                        </div>
                    </div>

                    <div class="setting-row">
                      <label for="skipBossToggle">${d.rh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipBossToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="resetIfLoseToggle">${d.$g}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="resetIfLoseToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonAB">${d.ud}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonAB">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonFocusQuest">${d.Ke}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonFocusQuest">
                        <span class="switch"></span>
                      </label>
                    </div>
                    <span class="span-new">${d.Og}</span>  

                  
                    </div>
                      <div class="tutorial-container">
                        <span class="span-new">${d.Ji}</span>  
                      </div>
                    </div>

                  <!-- ARENA -->
  
                  <div class="popup-box" id="arena_settings">
                  <div class="settings_tab_title">Arena</div>
                  <span class="span-new">${d.Pa}</span>

                  
                  <div class="settings_tab_title2">
                    <button id="tabA" class="tab-button active">Arena Local Server</button>
                    <button id="tabB" class="tab-button">Arena Other Servers</button>
                  </div>

                  <!-- Tab A Content -->
                  <div id="contentA" class="setting-row">
                    <div class="avoid-attack">
                      <div class="top-section">
                      <h3>${d.ma}</h3>
                        <div class="switch-field2">
                          <input type="text" id="autoAttackInput" placeholder="${d.la}">
                          <button id="addAutoAttack" class="awesome-button">${d.ka}</button>
                          <button id="ClearAttackList" class="awesome-button">Clear List</button>
                        </div>
                      </div>
                      <ul id="autoAttackList" class="scrollable-list"></ul>
                    </div>
                  </div>

                  <!-- Tab B Content -->
                  <div id="contentB" class="setting-row" style="display: none;">
                    <div class="avoid-attack">
                      <div class="top-section">
                        <h3>${d.ma}</h3>
                        </div>
                        <button id="ClearOtherAttackList" class="awesome-button">Clear List</button>
                        <ul id="autoAttackServerList" class="scrollable-list"></ul>
                      </div>
                  </div>

                  <div class="setting-row">
                    <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.Tb}</h3>
                            <div class="switch-field2">
                                <input type="text" id="avoidAttackInput" placeholder="${d.la}">
                                <button id="addAvoidAttack" class="awesome-button">${d.ka}</button>
                                <button id="ClearAvoidList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="avoidAttackList" class="scrollable-list"></ul>
                        ${d.Ub}
                    </div>
                  </div>

                  <div class="setting-row" data-tooltip="${d.rj}">
                    <label for="enableArenaSimulator">Enable Simulator Attack [Premium]</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="enableArenaSimulator">
                        <span class="switch"></span>
                    </label>    
                  </div>


                 <div class="setting-row">
                      <label for="ArenaSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                      <div class="switch-field3">
                        <input type="number" id="ArenaSimulatorAmount" min="1" max="100" value="${localStorage.getItem("ArenaSimulatorAmount")||60}">
                      </div>
                </div>

                  <div class="setting-row">
                    <label for="arenaAttackGM">${d.La}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="arenaAttackGM">
                      <span class="switch"></span>
                    </label>    
                  </div>

                    <div class="setting-row" data-tooltip="${d.Sb}">
                    <label for="onlyArena">${d.Fg}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="onlyArena">
                        <span class="switch"></span>
                    </label>    
                    </div>

                <div class="setting-row">
                    <label for="attackRandomly">${d.xi}</label>
                    
                    <label class="toggle-switch">
                    <input type="checkbox" id="attackRandomly">
                    <span class="switch"></span>
                    </label>    
                    <h3>${d.yi}</h3>
                </div>

                  <div class="setting-row">
                    <div class="switch-field3">
                    <input type="number" id="autoAddArenaAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddArenaAmount")||0}">
                    </div>
                      <label for="autoAddArena">${d.Ja}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="autoAddArena">
                        <span class="switch"></span>
                      </label>
                  </div>
  
                  <div class="setting-row">
                    <label for="autoAvoidArena">${d.Ka}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="autoAvoidArena">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="scoreboard-attack">
                    <div class="settings_tab_title">${d.Jb}</div>
                    <div class="setting-row">
                    <label for="scoreboardattackenable">${d.gb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="scoreboardattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="scoreRange">${d.Hb}</label>
                    <select id="scoreRange" class="input">
                      <option value="1">1-50</option>
                      <option value="2">51-100</option>
                      <option value="3">101-150</option>
                      <option value="4">151-200</option>
                      <option value="5">201-250</option>
                      <option value="6">251-300</option>
                      <option value="7">301-350</option>
                      <option value="8">351-400</option>
                      <option value="9">401-450</option>
                      <option value="10">451-500</option>
                      <option value="11">501-550</option>
                      <option value="12">551-600</option>
                      <option value="13">601-650</option>
                      <option value="14">651-700</option>
                      <option value="15">701-750</option>
                      <option value="16">751-800</option>
                      <option value="17">801-850</option>
                      <option value="18">851-900</option>
                      <option value="19">901-950</option>
                      <option value="20">951-1000</option>
                      <!-- Add more options as needed -->
                    </select>
                  </div>
                  </div>
                  <span class="span-new">${d.Ib}</span>
                  
                  <div class="settings_tab_title">${d.ib}</div>

                  <div class="setting-row">
                  <label for="leagueattackenable">${d.fb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leagueattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguerandom">${d.Db}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguerandom">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguelowtohigh">${d.Eb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguelowtohigh">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <span class="span-new">${d.jb}</span>

                </div>

  
                  <!-- Circus -->

                  <div class="popup-box" id="circus_settings">
                    <div class="settings_tab_title">Circus</div>
                    <span class="span-new">${d.Pa}</span>

                    <div class="settings_tab_title2">
                        <button id="tabACircus" class="tab-button active">Circus Local Server</button>
                        <button id="tabBCircus" class="tab-button">Circus Other Servers</button>
                    </div>

                    <!-- Tab A Content -->
                    <div id="contentACircus" class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.ma}</h3>
                            <div class="switch-field2">
                            <input type="text" id="autoAttackCircusInput" placeholder="${d.la}">
                            <button id="addAutoCircusAttack" class="awesome-button">${d.ka}</button>
                            <button id="ClearCircusAttackList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="autoAttackCircusList" class="scrollable-list"></ul>
                        </div>
                    </div>

                    <!-- Tab B Content -->
                    <div id="contentBCircus" class="setting-row" style="display: none;">
                        <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.ma}</h3>
                            </div>
                            <button id="ClearOtherCircusAttackList" class="awesome-button">Clear List</button>
                            <ul id="autoAttackCircusServerList" class="scrollable-list"></ul>
                        </div>
                    </div>

                        <div class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.Tb}</h3>
                        <div class="switch-field2">
                            <input type="text" id="avoidAttackCircusInput" placeholder="${d.la}">
                            <button class="awesome-button" id="addAvoidCircusAttack">${d.ka}</button>
                            <button class="awesome-button" id="ClearCircusAvoidList">Clear List</button>
                        </div>
                        </div>
                            <ul id="avoidAttackCircusList" class="scrollable-list"></ul>
                            ${d.Ub}
                        </div>
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusWithoutHeal">${d.Di}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusWithoutHeal">
                                <span class="switch"></span>
                            </label>    
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusSimulator">Enable Simulator Attack [Premium]</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusSimulator">
                                <span class="switch"></span>
                            </label>    
                        </div>

                    <div class="setting-row">
                    <label for="CircusSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                    <div class="switch-field3">
                        <input type="number" id="CircusSimulatorAmount" min="1" max="100" value="${localStorage.getItem("CircusSimulatorAmount")||60}">
                    </div>
                </div>

                        <div class="setting-row">
                        <label for="circusAttackGM">${d.La}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="circusAttackGM">
                            <span class="switch"></span>
                        </label>    
                        </div>

                        <div class="setting-row" data-tooltip="${d.Sb}">
                        <label for="onlyCircus">${d.Gg}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="onlyCircus">
                        <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row">
                    <label for="attackRandomlyCircus">Attack Randomly in Provinciarum?</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="attackRandomlyCircus">
                        <span class="switch"></span>
                    </label>    
                    <h3>Also disable "Sort players in arena by level" setting in crazy-addon.</h3>
                    </div>

                        <div class="setting-row">
                        <div class="switch-field3">
                        <input type="number" id="autoAddCircusAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddCircusAmount")||0}">
                        </div>
                            <label for="autoAddCircus">${d.Ja}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="autoAddCircus">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="autoAvoidCircus">${d.Ka}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoAvoidCircus">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="scoreboard-attack">
                        <div class="settings_tab_title">${d.Jb}</div>
                        <div class="setting-row">
                        <label for="scoreboardcircusenable">${d.gb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="scoreboardcircusenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="scoreRangeCircus">${d.Hb}</label>
                            <select id="scoreRangeCircus" class="input">
                            <option value="1">1-50</option>
                            <option value="2">51-100</option>
                            <option value="3">101-150</option>
                            <option value="4">151-200</option>
                            <option value="5">201-250</option>
                            <option value="6">251-300</option>
                            <option value="7">301-350</option>
                            <option value="8">351-400</option>
                            <option value="9">401-450</option>
                            <option value="10">451-500</option>
                            <option value="11">501-550</option>
                            <option value="12">551-600</option>
                            <option value="13">601-650</option>
                            <option value="14">651-700</option>
                            <option value="15">701-750</option>
                            <option value="16">751-800</option>
                            <option value="17">801-850</option>
                            <option value="18">851-900</option>
                            <option value="19">901-950</option>
                            <option value="20">951-1000</option>
                            <!-- Add more options as needed -->
                            </select>
                        </div>
                        </div>
                        <span class="span-new"> ${d.Ib} </span>
                        
                        <div class="settings_tab_title">${d.ib}</div>

                        <div class="setting-row">
                        <label for="leaguecircusattackenable">${d.fb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusattackenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="leaguecircusrandom">${d.Db}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusrandom">
                            <span class="switch"></span>
                        </label>
                        </div>
    
                        <div class="setting-row">
                        <label for="leaguecircuslowtohigh">${d.Eb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircuslowtohigh">
                            <span class="switch"></span>
                        </label>
                        </div>
                        <span class="span-new">${d.jb}</span>

                  </div>

                  <div class="popup-box" id="underworld_settings">

                    <div class="settings_tab_title">${d.Qe}</div>
                        <span class="span-new"> ${d.Re}</span>
                        <div class="setting-row">
                            <label for="hellDifficulty">${d.Oe}</label>
                            <select id="hellDifficulty">
                                <option value="0">${d.Gi}</option>
                                <option value="1">${d.Fi}</option>
                                <option value="2">${d.Ei}</option>
                            </select>
                        </div>

                    <div class="setting-row">
                        <label for="hellEnterHP">${d.ge}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellEnterHP" min="1" max="100" value="${localStorage.getItem("hellEnterHP")||75}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="HellHealHP">${d.uk}</label>
                        <div class="switch-field3">
                            <input type="number" id="HellHealHP" min="1" max="100" value="${localStorage.getItem("HellHealHP")||10}">
                        </div>
                    </div>
                    
                    <div class="setting-row" data-tooltip="${d.Yi}">
                        <label for="autoEnterHell">${d.Fd} Info</label>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Xd}">
                        <label for="dontEnterUnderworld">${d.Yd}</label>
                        <label class="toggle-switch">
                        
                            <input type="checkbox" id="dontEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="EnableArenaHell">${d.be}</label>
                        <label class="toggle-switch">
                    
                        <input type="checkbox" id="EnableArenaHell">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderworldUseMobi">${d.pi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderworldUseMobi">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderWorldUseRuby">${d.ui}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderWorldUseRuby">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="useSacrifice">${d.si}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useSacrifice">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="usePray">${d.fk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="usePray">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="useClothToEnterUnderworld">${d.bk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useClothToEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="exitUnderworld">${d.ie}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="exitUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="settings_tab_title">${d.bi}</div>

                    <div class="setting-row">
                        <label for="useGodPowers">${d.di}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useGodPowers">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Multi-Selection for Gods -->
                    <div class="setting-row" id="godPowersSection" style="display: none;">
                        <label>${d.ei}</label>
                        <div class="god-selection">
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Minerva" id="godMinerva">
                                <img src="//gf3.geo.gfsrv.net/cdn8a/72919cc6b457bf475fb81cc7de8863.png" title="Minerva">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Diana" id="godDiana">
                                <img src="//gf2.geo.gfsrv.net/cdn70/026bb622a42b4d00abc74c67f28d63.png" title="Diana">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Vulcan" id="godVulcan">
                                <img src="//gf3.geo.gfsrv.net/cdn5c/6fbd05e43d699e65fc40cc92a17c51.png" title="Vulcan">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mars" id="godMars">
                                <img src="//gf2.geo.gfsrv.net/cdn76/5fd915f85b3e5e71b64632af0c6543.png" title="Mars">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Apollo" id="godApollo">
                                <img src="//gf3.geo.gfsrv.net/cdn8f/bb75bf0df76de3ec421bbfb0eac3c5.png" title="Apollo">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mercury" id="godMercury">
                                <img src="//gf3.geo.gfsrv.net/cdnbe/5e272e2aade20b4a266e48663421ce.png" title="Mercury">
                            </label>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="weaponBuff">${d.fi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="weaponBuff">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Armor Buff Section -->
                    <div class="setting-row">
                        <label>${d.gi}</label>
                        <div class="armor-selection">
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Armor" id="armorBuffArmor"> ${d.I}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Helmet" id="armorBuffHelmet"> ${d.L}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Gloves" id="armorBuffGloves"> ${d.K}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Boots" id="armorBuffBoots"> ${d.J}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Shield" id="armorBuffShield"> ${d.M}
                            </label>
                        </div>
                    </div>

                    <!-- Farm Section (As Is) -->
                    <div class="settings_tab_title">${d.He}</div>
                    <span class="span-new">${d.Ie}: </span>
                    <div class="setting-row">
                        <label for="farmEnable">${d.v}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="farmEnable">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="farmLocation">${d.Ge}</label>
                        <select id="farmLocation">
                            <option value="0">Entrance</option>
                            <option value="1">Court of the Dead</option>
                            <option value="2">Tartarus</option>
                            <option value="3">Erebus</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="farmEnemy">${d.Fe}:</label>
                        <select id="farmEnemy">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">Boss</option>
                        </select>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Xi}">
                          <label for="useVillaMedici">${d.ce}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="EnableHellLimit">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="hellLimit">${d.Wi}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellLimit" min="1" max="200" value="${localStorage.getItem("hellLimit")||5}">
                        </div>
                    </div>

                    <div class="settings_tab_title">${d.Pe}</div>
                    <div class="setting-row">
                          <label for="useVillaMedici">${d.ti}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useVillaMedici">
                              <span class="switch"></span>
                          </label>
                    </div>
                    
                    <div class="setting-row">
                        <label for="useHealingPotion">${d.ri}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useHealingPotion">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <span class="span-new"> ${d.ci}</span>
                    <span class="span-new">${d.ki}</span>

                    <div class="settings_tab_title">${d.Dd}</div>
                    <span class="span-new">Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.</span>
                    <div class="setting-row">
                          <label for="useCostume">${d.oi}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useCostume">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="wearUnderworld">${d.vi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="wearUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    
                    <div id="costumeUnderworldWrapper" style="display:none;">
                      <div class="setting-row">
                          <label for="costumeUnderworld">${d.Qd}</label>
                          <select id="costumeUnderworld">
                              <option value="9">Dis Pater Normal</option>
                              <option value="10">Dis Pater Medium</option>
                              <option value="11">Dis Pater Hard</option>
                          </select>
                      </div>
                    </div>                

                    <div class="setting-row">
                      <label for="costumeBasic">${d.Id}</label>
                      <select id="costumeBasic">
                          <option value="1">${d.Ra}</option>
                          <option value="2">${d.Va}</option>
                          <option value="3">${d.Wa}</option>
                          <option value="4">${d.Xa}</option>
                          <option value="5">${d.Ya}</option>
                          <option value="6">${d.Za}</option>
                          <option value="7">${d.$a}</option>
                          <option value="8">${d.ab}</option>
                          <option value="12">${d.bb}</option>
                          <option value="13">${d.Sa}</option>
                          <option value="14">${d.Ta}</option>
                          <option value="15">${d.Ua}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <label for="costumeDungeon">${d.$d}</label>
                      <select id="costumeDungeon">
                          <option value="1">${d.Ra}</option>
                          <option value="2">${d.Va}</option>
                          <option value="3">${d.Wa}</option>
                          <option value="4">${d.Xa}</option>
                          <option value="5">${d.Ya}</option>
                          <option value="6">${d.Za}</option>
                          <option value="7">${d.$a}</option>
                          <option value="8">${d.ab}</option>
                          <option value="12">${d.bb}</option>
                          <option value="13">${d.Sa}</option>
                          <option value="14">${d.Ta}</option>
                          <option value="15">${d.Ua}</option>
                      </select>
                    </div>
                    <span class="span-new">${d.Ed}</span>

                </div>
                  
                  <div class="popup-box" id="quests_settings">

                    <div class="settings_tab_title">Quests</div>

                    <div class="setting-row">
                      <div class="monster-buttons">
                        <span class="span-new">${d.type}</span>
                        <div class="quest-container">
                          <div id="do_combat_quests" class="settingsButton quest-type combat"></div>
                          <div id="do_arena_quests" class="settingsButton quest-type arena"></div>
                          <div id="do_circus_quests" class="settingsButton quest-type circus"></div>
                          <div id="do_expedition_quests" class="settingsButton quest-type expedition"></div>
                          <div id="do_dungeon_quests" class="settingsButton quest-type dungeon"></div>
                          <div id="do_items_quests" class="settingsButton quest-type items"></div>
                        </div>
                      </div>
                    </div>

                    <div class="settings_tab_title">Quest Settings</div>

                    <div class="setting-row">
                      <label for="skipTimeQuests">Arena ${d.Ba}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipTimeQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeCircusQuests">Circus ${d.Ba}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeCircusQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeOtherQuests">Other ${d.Ba}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeOtherQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                      <label for="UnderworldQuests">${d.ii}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="UnderworldQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row" id="underworldKeywordSection" style="display: none;">
                    ${d.hi}
                    <div class="input-container">
                        <input type="text" id="underworldKeywordInput" placeholder="${d.X}">
                        <button class="awesome-button" id="addUnderworldKeywordBtn">${d.H}</button>
                    </div>
                    <div id="underworldKeywordList"></div>
                </div>

                    <div class="setting-row">
                    <label for="acceptnotfilter">${d.Ig}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="acceptnotfilter">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="settings_tab_title">${d.Pg}</div>
                      <div class="setting-row">
                        ${d.Hg}
                        <select id="questSpeed">
                        <option value="0">5x</option>
                        <option value="1">4x</option>
                        <option value="2">3x</option>
                        <option value="3">2x</option>
                        <option value="4">1x</option>
                      </select>
                    </div>
                    <div class="settings_tab_title">${d.Mg}</div>

                    <div class="setting-row">
                      ${d.Lg}
                      <div class="input-container">
                      <input type="text" id="keywordInput" placeholder="${d.X}">
                      <button class="awesome-button" id="addKeywordBtn">${d.H}</button>
                      </div>
                      <div id="keywordList"></div>
                    </div>
                    
                    <div class="settings_tab_title">${d.Jg}</div>

                    <div class="setting-row">
                        ${d.Kg}
                        <div class="input-container">
                            <input type="text" id="keywordAcceptInput" placeholder="${d.X}">
                            <button class="awesome-button" id="addKeywordAcceptBtn">${d.H}</button>
                        </div>
                        <div id="keywordAcceptList"></div>
                    </div>      

                    <div class="setting-row">
                        <label for="questrewardvalue">${d.ah}</label>
                        <div class="switch-field3">
                            <input type="number" id="questrewardvalue" min="1" max="99999" value="${localStorage.getItem("questrewardvalue")||2E3}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label>${d.Ng}</label>
                        <div class="input-container">
                            <label><input type="checkbox" id="questTypeMercury"> Mercury</label>
                            <label><input type="checkbox" id="questTypeApollo"> Apollo</label>
                            <label><input type="checkbox" id="questTypeDiana"> Diana</label>
                            <label><input type="checkbox" id="questTypeMinerva"> Minerva</label>
                            <label><input type="checkbox" id="questTypeVulcan"> Vulcan</label>
                            <label><input type="checkbox" id="questTypeMars"> Mars</label>
                        </div>
                    </div>

                    
                    </div>


                <div class="popup-box" id="heal_settings">
                  <div class="monster-buttons">
                  </div>
                  <div class="settings_tab_title">${d.Ui}</div>

                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; margin-right: 50px;">
                  </div>

                  <div class="setting-row">
                  <label for="healPercentage">${d.Ti}</label>
                  <div class="switch-field3">
                    <input type="number" id="healPercentage" min="1" max="99" value="${localStorage.getItem("healPercentage")||75}">
                  </div>
                </div>

                  <div class="setting-row">
                  <img style="margin-top: -10px" src="https://gf3.geo.gfsrv.net/cdneb/91e0372cccc24f52758be611a10a3b.png">
                  <label for="HealClothToggle">${d.eh}</label>
                  
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealClothToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="HealRubyToggle">${d.El}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealRubyToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healShopToggle">${d.dk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healShopToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healfrompackage">${d.ek}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healfrompackage">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="HealPickBag">${d.Ne}</label>
                     <select id="HealPickBag" class="input">
                     <option value="1">
                        1
                      </option>
                      <option value="2">
                        2
                      </option>
                      <option value="3">
                        3
                      </option>
                      <option value="4">
                        4
                      </option>
                      <option value="5">
                        5
                      </option>
                      <option value="6">
                        6
                      </option>
                      <option value="7">
                        7
                      </option>
                      <option value="8">
                      8
                    </option>
                    </select>
                  </div>
                  
                  <div class="setting-row">
                  <label for="FoodAmount">${d.Si}</label>
                   <select id="FoodAmount" class="input">
                   <option value="1">
                      1
                    </option>
                    <option value="2">
                      2
                    </option>
                    <option value="3">
                      3
                    </option>
                    <option value="4">
                      4
                    </option>
                    <option value="5">
                      5
                    </option>
                    <option value="6">
                      6
                    </option>
                    <option value="7">
                      7
                    </option>
                    <option value="8">
                    8
                  </option>
                  </select>
                </div>   
                  
                <div class="setting-row" data-tooltip="${d.Ci}">
                <label for="healcervisia">${d.ak}</label>
                <label class="toggle-switch">
                    <input type="checkbox" id="healcervisia">
                    <span class="switch"></span>
                </label>
                </div>

                  <div class="setting-row">
                  <label for="HealEggs">${d.ck}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealEggs">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="settings_tab_title">${d.Se}</div>
                  <span class="span-new">${d.wg}</span>
                  <div class="setting-row" data-tooltip="${d.ej}>
                  <label for="OilEnable">${d.fe}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="OilEnable">
                      <span class="switch"></span>
                    </label>
                  </div>



                  <div class="setting-row">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-right: 50px;">
                    <table style="width: 100%">
                        <tbody>
                        <tr>
                            <td style="font-weight: bold; text-align: left; width: 30%">Minerva:</td>
                            <td style="text-align: right;">
                                <div class="radio-group">
                                <input type="radio" name="minerva" value="0"><span class="span-new">I</span>
                                <input type="radio" name="minerva" value="1"><span class="span-new">II</span>
                                <input type="radio" name="minerva" value="2"><span class="span-new">III</span>
                                <input type="radio" name="minerva" value="3" checked="true"><span class="span-new">Off</span>
                                </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Diana:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="diana" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="diana" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="diana" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="diana" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Mars:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="mars" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="mars" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="mars" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="mars" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Merkur:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="merkur" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="merkur" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="merkur" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="merkur" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Apollo:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="apollo" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="apollo" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="apollo" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="apollo" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Vulcanus:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="vulcanus" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="vulcanus" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="vulcanus" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="vulcanus" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                            </table>
                        </div>


                    </div>
<div class="settings_tab_title">${d.Oa}</div>
<span class="span-new">Bot will use buffs when available.</span>

<div class="setting-row" data-tooltip="${d.Ai}>
    <label for="BuffsEnable">Enable ${d.Oa}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffsEnable">
        <span class="switch"></span>
    </label>
</div>

<div class="setting-row">
    <label for="BuffUnderworldOnly">${d.Nd}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffUnderworldOnly">
        <span class="switch"></span>
    </label>
</div>


<div class="setting-row">
    <div class="buff-group">
        <label>Health:</label>
        <input type="checkbox" id="HealthBuff1"> Gingko
        <input type="checkbox" id="HealthBuff2"> Taigaroot
        <input type="checkbox" id="HealthBuff3"> Hawthorn
    </div>

    <div class="buff-group">
        <label>Strength:</label>
        <input type="checkbox" id="StrengthBuff1"> Flask
        <input type="checkbox" id="StrengthBuff2"> Ampulla
        <input type="checkbox" id="StrengthBuff3"> Flacon
        <input type="checkbox" id="StrengthBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Dexterity:</label>
        <input type="checkbox" id="DexterityBuff1"> Flask
        <input type="checkbox" id="DexterityBuff2"> Ampulla
        <input type="checkbox" id="DexterityBuff3"> Flacon
        <input type="checkbox" id="DexterityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Agility:</label>
        <input type="checkbox" id="AgilityBuff1"> Flask
        <input type="checkbox" id="AgilityBuff2"> Ampulla
        <input type="checkbox" id="AgilityBuff3"> Flacon
        <input type="checkbox" id="AgilityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Constitution:</label>
        <input type="checkbox" id="ConstitutionBuff1"> Flask
        <input type="checkbox" id="ConstitutionBuff2"> Ampulla
        <input type="checkbox" id="ConstitutionBuff3"> Flacon
        <input type="checkbox" id="ConstitutionBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Charisma:</label>
        <input type="checkbox" id="CharismaBuff1"> Flask
        <input type="checkbox" id="CharismaBuff2"> Ampulla
        <input type="checkbox" id="CharismaBuff3"> Flacon
        <input type="checkbox" id="CharismaBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Intelligence:</label>
        <input type="checkbox" id="IntelligenceBuff1"> Flask
        <input type="checkbox" id="IntelligenceBuff2"> Ampulla
        <input type="checkbox" id="IntelligenceBuff3"> Flacon
        <input type="checkbox" id="IntelligenceBuff4"> Bottle
    </div>
</div>
                  </div>

                  <div class="popup-box" id="event_expedition_settings">
                    <div class="settings_tab_title">${d.eventExpedition}</div>

                    <div class="setting-row">
                        <div id="set_event_monster_id_0" class="monster-button">1</div>
                        <div id="set_event_monster_id_1" class="monster-button">2</div>
                        <div id="set_event_monster_id_2" class="monster-button">3</div>
                        <div id="set_event_monster_id_3" class="monster-button">Boss</div>
                    </div>
                    <div id="clear_next_event_expedition_time" class="awesome-button">${d.Rg}</div> <!-- New Button -->

                      <div class="setting-row">
                      <label for="renewEvent">${d.Ug}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="renewEvent">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <label for="throwDice">${d.zh}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="throwDice">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <span class="span-new">${d.Ah}<span class="span-new">
                      
                                          </div>
                      <div class="setting-row">
                    <span class="span-new">${d.he}<span class="span-new">
                    
                                        </div>
                    </div>

                  <div class="popup-box" id="auto_auction_settings">
                

                    <div class="settings_tab_title">${d.Ad}</div>
                    <span class="span-new">To open search panels including Unique shop items, enable this option.<span class="span-new">
                    <div class="setting-row">
                    <label for="AuctionItemLevel2">${d.og}</label>
                      <div class="switch-field2">
                        <input type="text" id="search_input" placeholder="${d.pd}">
                      </div>
                    </div>

                    <div class="setting-row">
                      <label for="AuctionItemLevel2">${d.da}</label>
                      <div class="switch-field3">
                        <input type="number" id="AuctionItemLevel2" min="1" max="1000" value="5">
                      </div>
                    </div>   

                    <div class="setting-row">
                      <label for="SearchQuality">${d.Aa}</label>
                      <select id="SearchQuality" class="input">
                          <option value="-1">
                          ${d.Da}
                          </option>
                            <option value="0">
                            ${d.C}
                            </option>
                            <option value="1">
                            ${d.B}
                            </option>
                            <option value="2">
                            ${d.D}
                            </option>
                          </option>
                      </select>
                    </div> 

                    <div class="setting-row">
                      <label>${d.qa}</label>
                      <div class="equipment-search-selection">
                          <label><input type="checkbox" class="equipment-search-option" value="2"> ${d.ja}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="4"> ${d.ga}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="8"> ${d.W}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1"> ${d.Z}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="256"> ${d.Y}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="512"> ${d.ha}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="48"> ${d.ea}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1024"> ${d.V}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="9999"> ${d.P}</label>
                      </div>
                    </div>

                    <button class="awesome-button" id="search_button" type="button">${d.pd}</button>
                    <button class="awesome-button" id="search_reset" type="button">${d.td}</button>
       
                    <div class="setting-row">
                    <ul id="search_list"></ul>
                    <span class="span-new">${d.vd}</span>
                    </div>

                    <div class="settings_tab_title">${d.hh}</div>
                    <div class="setting-row">

                      <!-- Title & Instructions -->
                      <div style="margin-bottom: 20px;">
                          <h2>${d.jh}</h2>
                          <p>${d.ih}</p>
                      </div>
                    </div>
                    <!-- Item Input Section -->

                        <div class="setting-row">
                          <label for="clothCount">${d.kh}</label>
                          <div class="switch-field2">
                              <input type="number" id="clothCount" placeholder="${d.lh}">
                          </div>
                        </div>

                        <hr class="section-separator">

                        <div class="setting-row">
                              <label for="newItem">${d.ia}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItem" placeholder="${d.ia}">
                          </div>
                        </div>

                        <div class="setting-row">
                          <label for="newItemLevel">Min ${d.Lb}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItemLevel" placeholder="Min ${d.Lb}">
                          </div>
                        </div>
                
                        <div class="setting-row">
                          <label for="itemQuality">Min ${d.nh}:</label>
                          <select id="itemQuality">
                              <option value="0">${d.C}</option>
                              <option value="1">${d.B}</option>
                              <option value="2">${d.D}</option>
                              <option value="3">${d.G}</option>
                              <option value="4">${d.S}</option>
                          </select>
                        </div>

                        <!-- New Stat Selection with Combo Box -->
                        <div class="setting-row">
                        <label for="shopitemstat">Stat:</label>
                        <select id="shopitemstat">
                            <option value="none">NONE</option>
                            <option value="str">Strength</option>
                            <option value="dex">Dexterity</option>
                            <option value="agi">Agility</option>
                            <option value="cot">Constitution</option>
                            <option value="chr">Charisma</option>
                            <option value="int">Intelligence</option>
                        </select>
                        </div>

                        <div class="setting-row" id="statValueRow" style="display: none;">
                        <label for="statValue">Value:</label>
                        <div class="switch-field2">
                            <input type="number" id="statValue" placeholder="0">
                        </div>
                        </div>
                        

                        <div style="text-align: right;">
                        <button class="awesome-button" id="addItemButton">${d.H}</button>
                      </div>

                      <div class="setting-row">
                        <div id="itemsList" style="margin-bottom: 10px;">
                        <!-- Example item -->
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="flex: 1;">${d.mh}</span>
                            <button onclick="removeItem('uniqueItemID')">X</button>
                        </div>
                        <!-- Add more items similarly -->
                        </div>
                      </div>  
                  
                      <!-- Search Buttons -->
                      <div style="display: flex; justify-content: space-between; gap: 10px; margin-bottom: 20px;">
                        <button class="awesome-button" id="startSearchButton">${d.oh}</button>
                        <button class="awesome-button" id="skipSearchButton" style="display: none;">${d.ph}</button>
                        <button class="awesome-button" id="stopSearchButton">${d.qh}</button>
                      </div>
                      <div class="setting-row">
                      <!-- Progress Bar -->
                      <div style="margin-bottom: 20px;">
                          <label>${d.gh}:</label>
                          <div id="progressBarOuter" style="width: 100%; height: 20px; background-color: grey; border-radius: 10px;">
                              <div id="progressBarInner" style="height: 100%; width: 0%; background-color: green; border-radius: 10px;"></div>
                          </div>
                      </div>
                  
                      <!-- Found Items Container -->
                      <div id="foundItemsContainer"></div>
                    </div>
                </div>
                
                    


                  
                
                

                  <div class="popup-box" id="auto_auction2_settings">


                <div class="settings_tab_title">${d.yh}</div>
                
                <div class="setting-row" data-tooltip="${d.zd}">
                <label for="storeGoldinAuction">${d.v}</label>
                  <label class="toggle-switch">
                  <input type="checkbox" id="storeGoldinAuction">
                  <span class="switch"></span>
                  </label>
                  </div>

                <div class="setting-row">
                  <label for="itemsToReset2">${d.fa}</label>
                  <div id="itemsToReset2" class="items-reset-list">
                      <div class="item-reset"><input type="checkbox" id="WEAPONS2" value="WEAPONS2"><label for="WEAPONS">${d.U}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHIELD2" value="SHIELD2"><label for="SHIELD">${d.M}</label></div>
                      <div class="item-reset"><input type="checkbox" id="CHEST2" value="CHEST2"><label for="CHEST">${d.I}</label></div>
                      <div class="item-reset"><input type="checkbox" id="HELMET2" value="HELMET2"><label for="HELMET">${d.L}</label></div>
                      <div class="item-reset"><input type="checkbox" id="GLOVES2" value="GLOVES2"><label for="GLOVES">${d.K}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHOES2" value="SHOES2"><label for="SHOES">${d.J}</label></div>
                      <div class="item-reset"><input type="checkbox" id="RINGS2" value="RINGS2"><label for="RINGS">${d.T}</label></div>
                      <div class="item-reset"><input type="checkbox" id="AMULETS2" value="AMULETS2"><label for="AMULETS">${d.R}</label></div>
                  </div>
                </div>

                <div class="setting-row">
                    <label for="storeInShopQuality">${d.Aa}</label>
                    <select id="storeInShopQuality" class="input">
                    <option value="0">
                    ${d.C}
                    </option><!-- Add more options as needed -->
                        <option value="1">
                        ${d.B}
                        </option>
                        <option value="2">
                        ${d.D}
                        </option>
                  </select>
                

                </div>

                <div class="setting-row">
                <label for="storeGoldinAuctionmaxGold">${d.dg}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionmaxGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionmaxGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
                <label for="storeGoldinAuctionholdGold">${d.aa}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionholdGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionholdGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
              <label for="AuctionGoldCover">${d.cb}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="AuctionGoldCover">
                <span class="switch"></span>
              </label>
            </div>

                <span class="span-new">${d.bh}</span>
                  
                    <div class="settings_tab_title">${d.tg}</div>
                    <span class="span-new">${d.Bd}</span>
                    
                    <div class="setting-row">
                      <div class="table-container">
                          <table class="styled-table">
                            <thead>
                              <tr>
                                <th>Prefix</th>
                                <th>Suffix</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="AuctionprefixList"></ul>
                                </td>
                                <td>
                                  <ul class="styled-list" id="AuctionsuffixList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                 
                                    <input type="text" class="styled-input" id="AuctionnewPrefixInput">
                                    <input type="button" id="AuctionaddPrefixButton" value="${d.Ha}">
                                  </div>
                                </td>
                                <td>
                                  <div class="list-options">
                                    <input type="text" class="styled-input" id="AuctionnewSuffixInput">
                                    <input type="button" id="AuctionaddSuffixButton" value="${d.Ia}">
                                  </div>
                                </td>

                              </tr>
                            </tbody>
                          </table>
                          
                      </div>
                      
                    </div>
                  
                    <div class="setting-row">
                        <label>${d.qa}</label>
                        <div class="equipment-selection">
                            <label><input type="checkbox" class="equipment-option" value="2"> ${d.ja}</label>
                            <label><input type="checkbox" class="equipment-option" value="4"> ${d.ga}</label>
                            <label><input type="checkbox" class="equipment-option" value="8"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option" value="1"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option" value="256"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option" value="512"> ${d.ha}</label>
                            <label><input type="checkbox" class="equipment-option" value="48"> ${d.ea}</label>
                            <label><input type="checkbox" class="equipment-option" value="1024"> ${d.V}</label>
                            <label><input type="checkbox" class="equipment-option" value="9999"> ${d.P}</label>
                        </div>
                    </div>

                      <div class="setting-row" data-tooltip="${d.$j}">
                        <label for="auctionTURBO">Turbo Mode Speed >> </label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionTURBO">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctiongladiatorenable">${d.dh}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctiongladiatorenable">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctionmercenaryenable">${d.fh}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionmercenaryenable">
                          <span class="switch"></span>
                         </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.xd}>
                        <label for="ignorePS">${d.Ve}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="ignorePS">
                            <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Ma}>
                        <label for="bidFood">${d.Jd}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="bidFood">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.wd}>
                      <label for="AuctionCover">${d.cb}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="AuctionCover">
                        <span class="switch"></span>
                      </label>
                    </div>

                      <div class="setting-row" data-tooltip="${d.Ma}>
                        <label for="bidfood">${d.eg}</label>
                        <div class="switch-field3">
                          <input type="number" id="maximumBid" min="1" max="1000000" value="25">
                        </div>
                      </div>

                      <div class="setting-row">
                        <label for="aunctionMinQuality">${d.Aa}</label>
                         <select id="auctionMinQuality" class="input">
                          <option value="2">
                          ${d.D}
                          </option>
                          <option value="1">
                          ${d.B}
                          </option>
                          <option value="0">
                          ${d.C}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                    <div class="setting-row">
                      <label for="auctionminlevel">${d.da}</label>
                      <div class="switch-field3">
                        <input type="number" id="auctionminlevel" min="1" max="1000" value="0">
                      </div>
                    </div>

                      <div class="setting-row">
                        <label for="bidStatus">${d.Kd}</label>
                         <select id="bidStatus" class="input">
                          <option value="4">
                          ${d.Rb}
                          </option>
                          <option value="3">
                          ${d.Nb}
                          </option>
                          <option value="2">
                          ${d.Bb}
                          </option>
                          <option value="1">
                          ${d.sb}
                          </option>
                          <option value="0">
                          ${d.Qb}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                      <div class="setting-row">
                        <label for="enableMercenarySearch">${d.Li}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="enableMercenarySearch">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="mercenarySearchOptions" style="display:none">
                        <div class="setting-row">
                        
                            <label for="minDexterity">Min: ${d.Dexterity}</label>
                            <div class="switch-field3">
                                <input type="number" id="minDexterity" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minAgility">Min: ${d.Agility}</label>
                            <div class="switch-field3">
                                <input type="number" id="minAgility" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minIntelligence">Min: ${d.Intelligence}</label>
                            <div class="switch-field3">
                                <input type="number" id="minIntelligence" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <span class="span-new">Enter 0 to ignore stats.</span>
                    </div>
                      
                      <div class="setting-row">
                        <h4>${d.Ld}</h4>
                        <div class="table-container">
                          <table class="styled-table">
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="bidList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                    <input type="button" class="awesome-button" id="clearBidItemsHistory" value="${d.Qa}">
                                  </div>
                                  
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                  </div>

                <div class="popup-box" id="auto_smelt_settings">
                    <div class="settings_tab_title" style="position: relative;">
                        Auto Smelt
                        <i class="fas fa-info-circle" id="autoSmeltInfo" style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 22px; color: black;"></i>

                    
                    </div>


                    <div class="rule-container">
                    <!-- Rule Row Template -->
                    <div class="rule-row-template" style="display: none;">
                        <!-- Top row (Condition, Prefix, Scroll, Level) -->
                        <div class="rule-top-row">
     
                            <label class="rule-checkbox-wrapper">
        
                                <input type="checkbox" class="rule-checkbox">
                                <span class="checkbox-icon"></span>
                                
                            </label>

                            &nbsp

                            <!-- Condition Combo Box -->
                            <select class="rule-condition-select">
                                <option value="nameContains">${d.sg}</option>
                                <option value="isUnderworldItem">${d.isUnderworldItem}</option>
                            </select>

                            <!-- Text input appears only for 'Name contains' -->
                            <input type="text" class="rule-prefix-input" placeholder="${d.Cb}" />
                            <input type="text" class="rule-suffix-input" placeholder="${d.Ob}" />

                            <!-- Scroll Combo Box 
                            <select class="rule-scroll-select">
                                <option value="noScroll">No scroll</option>
                                <option value="anyScroll">Has any scroll</option>
                            </select>
                            -->

                            <input type="number" class="rule-level" placeholder="lvl>">
                        </div>

                        <!-- Second row (Item Types, Colors, Hammer) -->
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection">
                                <span class="color-circle white" data-color="white"></span>
                                <span class="color-circle green" data-color="green"></span>
                                <span class="color-circle blue" data-color="blue"></span>
                                <span class="color-circle purple" data-color="purple"></span>
                                 <span class="color-circle orange" data-color="orange"></span>
                                <span class="color-circle red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

                            <button class="remove-rule-btn">X</button>
                        </div>
                    </div>

                    <!-- Add Rule Button -->
                    <button class="add-rule-btn">${d.ug}</button>
                    <hr style="border: 1px solid #c4ac70; margin: 10px 0;">
                </div>



                    <!-- Condition Selection  
                    <div class="setting-row">
                        <label for="smeltCondition">Condition:</label>
                        <select id="smeltCondition" class="styled-select" style="width:200px">
                            <option value="name_contains">Name contains</option>
                            <option value="name_word">Name contains word</option>
                            <option value="color">Item color is</option>
                            <option value="underworld_prefix_suffix">Item has underworld prefix/suffix</option>
                        </select>
                    </div>
                    
                    <div class="setting-row" id="filterNameRow">
                        <label for="filterNameInput">Filter Profile Name:</label>
                        <input type="text" id="filterNameInput" class="styled-input3" placeholder="Enter profile name" />
                    </div>

                    <div class="setting-row" id="itemNameRow" style="display: none;">
                        <label for="itemNameInput">Item Name:</label>
                        <input type="text" id="itemNameInput" class="styled-input" placeholder="Enter item name" />
                    </div>
                    
                    <div class="setting-row" id="colorRow" style="display: none;">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                

                    <div class="setting-row">
                        <h4>Added Filters</h4>
                        <div id="filtersList" class="filter-list"></div>
                    </div>


                    <div class="setting-row">
                        <h4>Saved Items</h4>
                        <div id="savedItemsList" class="filter-list"></div>
                    </div>

                    

                    <div class="setting-row">
                        <label>${d.qa}</label>
                        <div class="equipment-selection-smelt">
                            <label><input type="checkbox" class="equipment-option-smelt" value="2"> ${d.ja}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="4"> ${d.ga}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="8"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="256"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="512"> ${d.ha}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="48"> ${d.ea}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1024"> ${d.V}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="9999"> ${d.P}</label>
                        </div>
                    </div>
                  

                    <div class="setting-row" id="colorRowOriginal">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                    

                    <div class="setting-row">
                        <label for="smeltUnderworld">Smelt only Underworld/Hell items?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="smeltUnderworld">
                        <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="smeltLootbox">${d.Bj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="smeltLootbox">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltIgnorePS">${d.Aj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltIgnorePS">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->

                    <div class="setting-row">
                      <label for="smeltAnything">${d.vh}</label>
                      
                      <label class="toggle-switch" data-tooltip="${d.Cj}">
                        <input type="checkbox" id="smeltAnything">
                        <span class="switch"></span>
                      </label>
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection2">
                                <span class="color-circle2 white" data-color="white"></span>
                                <span class="color-circle2 green" data-color="green"></span>
                                <span class="color-circle2 blue" data-color="blue"></span>
                                <span class="color-circle2 purple" data-color="purple"></span>
                                 <span class="color-circle2 orange" data-color="orange"></span>
                                <span class="color-circle2 red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection2">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

        
                        </div>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Dj}">
                      <label for="smelteverything3">${d.Lj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smelteverything3">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="RepairBeforeSmelt">${d.uj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="RepairBeforeSmelt">
                        <span class="switch"></span>
                      </label>
                        <div class="setting-row">
                        <label for="repairBeforeSmeltMaxQuality">${d.Gc}</label>
                            <select id="repairBeforeSmeltMaxQuality" class="input">
                                    <option value="3">
                                    ${d.G}
                                    </option>
                                    <option value="2">
                                    ${d.D}
                                    </option>
                                    <option value="1">
                                    ${d.B}
                                    </option>
                                    <option value="0">
                                    ${d.C}
                                    </option>
                                    <option value="-1">
                                    ${d.Da}
                                    </option>
                            </select>
                        </div>
                        <div class="setting-row">
                        <label for="PartialOrFull">${d.Ag}</label>
                            <select id="PartialOrFull" class="input">
                                    <option value="0">
                                    ${d.Bg}
                                    </option>
                                    <option value="1">
                                    ${d.Le}
                                    </option>
                            </select>
                        </div>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltusehammers">Use Hammers?</label>
                      <span class="span-new">[Bot will look for bronze then silver.]</span>   
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltusehammers">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->
                    
                    <div class="setting-row">
                        <label for="smeltTab">${d.wh}</label>
                        <select id="smeltTab" class="input">
                        <option value="6">
                            8
                        </option>
                            <option value="5">
                                7
                            </option>
                            <option value="4">
                                6
                            </option>
                            <option value="3">
                                5
                            </option>
                            <option value="2">
                                4
                            </option>
                            <option value="1">
                                3
                            </option>
                            <option value="0">
                                2
                            </option>
                        </select>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="smeltLevel">Min Level</label>
                        <div class="switch-field3">
                            <input type="number" id="smeltLevel" min="1" max="100" value="${localStorage.getItem("smeltLevel")||1}">
                        </div>
                    </div>
                    
                    
                    
                    <span class="span-new">${d.Mj}</span>
-->
                    <div class="settings_tab_title">${d.uh}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                <thead>
                                    <tr>
                                    <th>${d.Cb}</th>
                                    <th>${d.Ob}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td>
                                        <ul class="styled-list" id="IgnoredprefixList"></ul>
                                    </td>
                                    <td>
                                        <ul class="styled-list" id="IgnoredsuffixList"></ul>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredPrefixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddPrefixButton" value="${d.Ha}">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredSuffixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddSuffixButton" value="${d.Ia}">
                                        </div>
                                    </td>
                                    </tr>
                                </tbody>
                                </table>          
                        </div>
                    </div>
                    
                    <!-- Smelted Items List -->
                  
                    <div class="settings_tab_title">${d.Kj}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                    <tbody>
                                    <tr>
                                        <td>
                                        <ul class="styled-list" id="smeltedList"></ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <div class="list-options">
                                            <input type="button" class="awesome-button" id="clearSmeltedItemsHistory" value="${d.Qa}">
                                            
                                        </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>    
                        </div>
                    </div>
                </div>

                
                <div class="popup-box" id="auto_repair_settings">
                <div class="settings_tab_title">${d.Fb}</div>
                <div class="setting-row">

                    <div class="inventory gladiator-inventory">
                        <h3>Gladiator</h3>
                        <!-- Inventory Rows for Gladiator -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weapon">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmet">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armor">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shield">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="gloves">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoes">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklace">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>

                        </div>
                    </div>

                    <div class="inventory mercenary-inventory">
                        <h3>Mercenary</h3>
                        <!-- Inventory Rows for Mercenary -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weaponM">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmetM">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armorM">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shieldM">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="glovesM">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoesM">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1M">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2M">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklaceM">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>
                        </div>
                    </div>

                    <div class="instructions" style="clear: both;">
                            <span class="span-new">${d.Vb}</span><br>
                            <span class="span-new">${d.Vg}</span>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="repairGladiator">${d.Ca} Gladiator?</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="repairGladiator">
                            <span class="switch"></span>
                        </label>
                    </div>
                  
                    <div class="setting-row">
                        <label for="repairMercenary">${d.Ca} Mercenary?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="repairMercenary">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="repairPercentage">${d.pg}</label>
                        <select id="repairPercentage" class="input">
                        <option value="3">%10</option>
                        <option value="2">%20</option>
                        <option value="1">%30</option>
                        <option value="0">%40</option>
                        <option value="-1">%50</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="repairMaxQuality">${d.Gc}</label>
                        <select id="repairMaxQuality" class="input">
                                <option value="3">
                                ${d.G}
                                </option>
                                <option value="2">
                                ${d.D}
                                </option>
                                <option value="1">
                                ${d.B}
                                </option>
                                <option value="0">
                                ${d.C}
                                </option>
                                <option value="-1">
                                ${d.Da}
                                </option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="currentWorkbenchItem">${d.Sd}</label>
                        <span id="currentWorkbenchItem"></span> <!-- Item name will be displayed here -->
                    </div>

                    <div class="setting-row">
                        <div id="clear_repair" style="display:flex;" class="awesome-button">${d.gk}</div> <!-- Button to clear -->
                    </div>

                    <div class="setting-row" id="ignoreMaterialsSection" style="margin-top: 10px; border-top: 1px solid #b3a77a; padding-top: 10px; background: linear-gradient(to right, #e8e1c8, #dacfa1); border-radius: 8px;">
                        <h3 style="color: #5a5a5a; font-family: 'Arial', sans-serif; text-align: center; text-transform: uppercase; letter-spacing: 2px;">${d.Ue}</h3>
                        
                        <!-- Scrollable list of materials -->
                        <div id="ignoreMaterialsList" style="border-radius: 4px; padding: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); height: 300px; max-height: 300px; overflow-y: auto; display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                            <!-- Base Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Base Materials</h4>
                                <label><input type="checkbox" value="1"> ${d.Ec}</label><br>
                                <label><input type="checkbox" value="2"> ${d.uc}</label><br>
                                <label><input type="checkbox" value="3"> ${d.yc}</label><br>
                                <label><input type="checkbox" value="4"> ${d.Ac}</label><br>
                            </div>

                            <!-- Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Materials</h4>
                                <label><input type="checkbox" value="13"> ${d.Fc}</label><br>
                                <label><input type="checkbox" value="14 Wool"> ${d.vc}</label><br>
                                <label><input type="checkbox" value="15"> ${d.xc}</label><br>
                                <label><input type="checkbox" value="16"> ${d.wc}</label><br>
                                <label><input type="checkbox" value="17"> ${d.Bc}</label><br>
                                <label><input type="checkbox" value="18"> ${d.zc}</label><br>
                                <label><input type="checkbox" value="19"> ${d.Dc}</label><br>
                                <label><input type="checkbox" value="20"> ${d.Cc}</label><br>
                            </div>

                            <!-- Monster Parts category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Monster Parts</h4>
                                <label><input type="checkbox" value="5"> ${d.Nc}</label><br>
                                <label><input type="checkbox" value="6"> ${d.Hc}</label><br>
                                <label><input type="checkbox" value="7"> ${d.Qc}</label><br>
                                <label><input type="checkbox" value="8"> ${d.Kc}</label><br>
                                <label><input type="checkbox" value="9"> ${d.Mc}</label><br>
                                <label><input type="checkbox" value="10> ${d.Lc}</label><br>
                                <label><input type="checkbox" value="11"> ${d.Ic}</label><br>
                                <label><input type="checkbox" value="12"> ${d.Pc}</label><br>
                                <label><input type="checkbox" value="55"> ${d.Jc}</label><br>
                                <label><input type="checkbox" value="58"> ${d.Oc}</label><br>
                                <label><input type="checkbox" value="62"> ${d.Rc}</label><br>
                                <label><input type="checkbox" value="64"> ${d.Sc}</label><br>
                            </div>

                            <!-- Gemstones category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Gemstones</h4>
                                <label><input type="checkbox" value="21"> ${d.pc}</label><br>
                                <label><input type="checkbox" value="22"> ${d.jc}</label><br>
                                <label><input type="checkbox" value="23"> ${d.ic}</label><br>
                                <label><input type="checkbox" value="24"> ${d.kc}</label><br>
                                <label><input type="checkbox" value="25"> ${d.qc}</label><br>
                                <label><input type="checkbox" value="26"> ${d.nc}</label><br>
                                <label><input type="checkbox" value="27"> ${d.mc}</label><br>
                                <label><input type="checkbox" value="28"> ${d.lc}</label><br>
                                <label><input type="checkbox" value="59"> ${d.oc}</label><br>
                                <label><input type="checkbox" value="63"> ${d.rc}</label><br>
                            </div>

                            <!-- Flasks category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Flasks</h4>
                                <label><input type="checkbox" value="37"> ${d.cc}</label><br>
                                <label><input type="checkbox" value="38"> ${d.fc}</label><br>
                                <label><input type="checkbox" value="39"> ${d.Zb}</label><br>
                                <label><input type="checkbox" value="40"> ${d.Yb}</label><br>
                                <label><input type="checkbox" value="41"> ${d.ec}</label><br>
                                <label><input type="checkbox" value="42"> ${d.bc}</label><br>
                                <label><input type="checkbox" value="43"> ${d.$b}</label><br>
                                <label><input type="checkbox" value="44"> ${d.ac}</label><br>
                                <label><input type="checkbox" value="53"> ${d.hc}</label><br>
                                <label><input type="checkbox" value="61"> ${d.dc}</label><br>
                            </div>

                            <!-- Runes category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Runes</h4>
                                <label><input type="checkbox" value="29"> ${d.od}</label><br>
                                <label><input type="checkbox" value="30"> ${d.hd}</label><br>
                                <label><input type="checkbox" value="31"> ${d.fd}</label><br>
                                <label><input type="checkbox" value="32"> ${d.nd}</label><br>
                                <label><input type="checkbox" value="33"> ${d.md}</label><br>
                                <label><input type="checkbox" value="34"> ${d.kd}</label><br>
                                <label><input type="checkbox" value="35"> ${d.gd}</label><br>
                                <label><input type="checkbox" value="36"> ${d.ld}</label><br>
                                <label><input type="checkbox" value="60"> ${d.jd}</label><br>
                            </div>

                            <!-- Ores category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Ores</h4>
                                <label><input type="checkbox" value="45"> ${d.Wc}</label><br>
                                <label><input type="checkbox" value="46"> ${d.Vc}</label><br>
                                <label><input type="checkbox" value="47"> ${d.$c}</label><br>
                                <label><input type="checkbox" value="48"> ${d.cd}</label><br>
                                <label><input type="checkbox" value="49"> ${d.dd}</label><br>
                                <label><input type="checkbox" value="50"> ${d.Yc}</label><br>
                                <label><input type="checkbox" value="51"> ${d.bd}</label><br>
                                <label><input type="checkbox" value="52"> ${d.ad}</label><br>
                                <label><input type="checkbox" value="54"> ${d.Uc}</label><br>
                                <label><input type="checkbox" value="56"> ${d.Xc}</label><br>
                                <label><input type="checkbox" value="57"> ${d.Zc}</label><br>
                            </div>
                        </div>

                    </div>

                </div>


                <div class="popup-box" id="guild_settings">

                    <!-- Guld stuff comes here -->

                    <div class="settings_tab_title">${d.xh}</div>

                        <span class="span-new">${d.Ki}:</span>
                        <span class="span-new">${d.df}</span>
                  
                        <div class="setting-row">
                            <label for="doKasa">${d.v}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="doKasa">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="AuctionItemLevel2">${d.qg}</label>
                            <div class="switch-field2">
                            <input type="number" id="minimumGoldAmount" placeholder="Amount" value="${localStorage.getItem("minimumGoldAmount")||0}">         
                            </div>
                        </div>

                        <div class="setting-row">
                            <label for="filterGM">${d.Je}</label>
                            <select id="filterGM">
                            <option value="" disabled>${d.fa}</option>
                            <option value="pd">${d.rg}</option>
                            <option value="p">${d.Pd}</option>
        
                            </select>
                        </div>

                        <div class="setting-row">
                            <label for="guildPackHour">${d.Kb}</label>
                            <select id="guildPackHour">
                            <option value="" disabled>${d.Kb}</option>
                            <option value="1">2 hr</option>
                            <option value="2">8 hr</option>
                            <option value="3">24 hr</option>
                            </select>
                        </div>

                        <div class="setting-row">
                        <label for="KasaHoldGold">${d.aa}</label>
                            <div class="switch-field3">
                            <input type="number" id="KasaHoldGold" placeholder="Amount" value="${localStorage.getItem("KasaHoldGold")||0}">       
                                </div>
                        </div>

                        <div class="setting-row">
                            <label for="itemsToResetGuild">${d.fa}</label>
                            <div id="itemsToResetGuild" class="items-reset-list">
                                <div class="item-reset"><input type="checkbox" id="GUILD_WEAPONS" value="GUILD_WEAPONS"><label for="GUILD_WEAPONS">${d.U}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHIELD" value="GUILD_SHIELD"><label for="GUILD_SHIELD">${d.M}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_CHEST" value="GUILD_CHEST"><label for="GUILD_CHEST">${d.I}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_HELMET" value="GUILD_HELMET"><label for="GUILD_HELMET">${d.L}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_GLOVES" value="GUILD_GLOVES"><label for="GUILD_GLOVES">${d.K}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHOES" value="GUILD_SHOES"><label for="GUILD_SHOES">${d.J}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RINGS" value="GUILD_RINGS"><label for="GUILD_RINGS">${d.T}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_AMULETS" value="GUILD_AMULETS"><label for="GUILD_AMULETS">${d.R}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FOOD" value="GUILD_FOOD"><label for="GUILD_FOOD">${d.oa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_USABLES" value="GUILD_USABLES"><label for="GUILD_USABLES">${d.Fa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_UPGRADES" value="GUILD_UPGRADES"><label for="GUILD_UPGRADES">${d.va}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RECIPES" value="GUILD_RECIPES"><label for="GUILD_RECIPES">${d.sa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_MERCENARY" value="GUILD_MERCENARY"><label for="GUILD_MERCENARY">${d.ra}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SCROLLS" value="GUILD_SCROLLS"><label for="GUILD_SCROLLS">${d.ta}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_REINFORCEMENTS" value="GUILD_REINFORCEMENTS"><label for="GUILD_REINFORCEMENTS">${d.Ga}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_TOOLS" value="GUILD_TOOLS"><label for="GUILD_TOOLS">${d.ua}</label></div>
                            </div>
                        </div>

                    <div class="settings_tab_title">${d.Pi}</div>

                            
                            <div class="setting-row">
                                <label for="guildBattleEnable">${d.v}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleEnable">
                                    <span class="switch"></span>
                                </label>          
                            </div>

                            <div class="setting-row">
                             <label for="guildBattleRandom">${d.Oi}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleRandom">
                                    <span class="switch"></span>
                                </label>
                            </div>

                            <div class="setting-row">
                                ${d.Qi}
                                <div class="input-container">
                                <input type="text" id="keywordGuildInput" placeholder="${d.X}">
                                <button class="awesome-button" id="addGuildKeywordBtn">${d.H}</button>
                                </div>
                                <div id="keywordGuildList"></div>
                            </div>

                    <div class="settings_tab_title">${d.eb}</div>

                        <div class="setting-row">
                            <label for="GuildEnable">${d.v}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="GuildEnable">
                                <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        
                            <label for="GuildDonateAmount">${d.Te}</label>
                            <div class="switch-field3">
                                <input type="number" id="GuildDonateAmount" min="0" value="${localStorage.getItem("GuildDonateAmount")||0}">      
                            </div> 

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateMore">${d.Wd}</label>
                                <div class="switch-field3">
                                    <input type="number" id="GuildDonateMore" min="0" value="${localStorage.getItem("GuildDonateMore")||0}">                         
                                </div>

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateLess">${d.ef}</label>
                            <div class="switch-field3">
                            <input type="number" id="GuildDonateLess" min="0" value="${localStorage.getItem("GuildDonateLess")||0}">       
                            </div>                  
                        </div>

                        <span class="span-new">${d.Vd}</span>
                        
                    </div>

                <div class="popup-box" id="other_settings2">

                    <div class="settings_tab_title">${d.Wg}</div>


                    <div class="setting-row">
                    <span class="span-new">${d.Xg}</span>
                    <div class="instructionsReset">
                    
                    <span class="span-new">${d.Gb}</span>
                    </div>
                 
                    </div>
                    
                    <div class="setting-row">
                      <label for="resetExpiredItems">${d.v}</label>
                      <label class="toggle-switch">
                          <input type="checkbox" id="resetExpiredItems">
                          <span class="switch"></span>
                      </label>
                    </div>
                    <div class="setting-row">
                    <label for="resetColors">Select Colors</label>
                            <div class="rule-color-resetColors">
                                <span class="color-circle3 white" data-color="-1"></span>
                                <span class="color-circle3 green" data-color="0"></span>
                                <span class="color-circle3 blue" data-color="1"></span>
                                <span class="color-circle3 purple" data-color="2"></span>
                                <span class="color-circle3 orange" data-color="3"></span>
                                <span class="color-circle3 red" data-color="4"></span>
                            </div>
                    </div>


                    <div class="setting-row">
 
                        <label for="resetDays">${d.Yg}</label>
                        <select id="resetDays" style="margin-left: 5px;">
                            <option value="1">1 day</option>
                            <option value="2">2 days</option>
                            <option value="3">3 days</option>
                            <option value="4">4 days</option>
                        </select>
                    </div>
                    
                    <div class="setting-row">
                        <label for="itemsToReset">${d.Ek}</label>
                        <button id="selectAllItems" title="Select All">
                            <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                                <polyline points="20 6 9 17 4 12"></polyline> <!-- This SVG represents a check mark -->
                            </svg>
                        </button>
                        <div id="itemsToReset" class="items-reset-list">
                        
                            <div class="item-reset"><input type="checkbox" id="WEAPONS" value="WEAPONS"><label for="WEAPONS">${d.U}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHIELD" value="SHIELD"><label for="SHIELD">${d.M}</label></div>
                            <div class="item-reset"><input type="checkbox" id="CHEST" value="CHEST"><label for="CHEST">${d.I}</label></div>
                            <div class="item-reset"><input type="checkbox" id="HELMET" value="HELMET"><label for="HELMET">${d.L}</label></div>
                            <div class="item-reset"><input type="checkbox" id="GLOVES" value="GLOVES"><label for="GLOVES">${d.K}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHOES" value="SHOES"><label for="SHOES">${d.J}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RINGS" value="RINGS"><label for="RINGS">${d.T}</label></div>
                            <div class="item-reset"><input type="checkbox" id="AMULETS" value="AMULETS"><label for="AMULETS">${d.R}</label></div>
                            <div class="item-reset"><input type="checkbox" id="FOOD" value="FOOD"><label for="FOOD">${d.oa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="USABLES" value="USABLES"><label for="USABLES">${d.Fa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="UPGRADES" value="UPGRADES"><label for="UPGRADES">${d.va}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RECIPES" value="RECIPES"><label for="RECIPES">${d.sa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="MERCENARY" value="MERCENARY"><label for="MERCENARY">${d.ra}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SCROLLS" value="SCROLLS"><label for="SCROLLS">${d.ta}</label></div>
                            <div class="item-reset"><input type="checkbox" id="REINFORCEMENTS" value="REINFORCEMENTS"><label for="REINFORCEMENTS">${d.Ga}</label></div>
                            <div class="item-reset"><input type="checkbox" id="TOOLS" value="TOOLS"><label for="TOOLS">${d.ua}</label></div>
                            
                        </div>
                    </div>
                    
                    <hr style="border: none; border-top: 1px solid black; margin: 10px 0px;">

                    <div class="setting-row">
                        <label for="pauseDuration">${d.Eg} </label>
                        <select id="pauseDuration">
                        <option value="0">No pause</option>
                        <option value="1">Stable Boy</option>
                        <option value="2">Farmer</option>
                        <option value="3">Butcher</option>
                        <option value="4">Fisherman</option>
                        <option value="5">Baker</option>
                        </select>
                    </div>
                     
              </div>

                <div class="popup-box" id="Timers">
                <div class="settings_tab_title">${d.Pb}</div>
                <span class="span-new">${d.Timers}</span>

                <div class="setting-row">
                    <div class="timer-list" style="display: grid; grid-template-columns: repeat(2, 5fr); gap: 10px;">

                    <div class="timer-item">
                        <label for="smelting-timer" style="font-weight: bold;">${d.Uh}</label>
                        <p class="description">${d.Sh}</p>
                        <input type="number" id="smelting-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Smelting||10}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-nogold" style="font-weight: bold;">${d.Th}</label>
                        <p class="description">${d.Ph}</p>
                        <input type="number" id="smelting-timer-nogold" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-noitem" style="font-weight: bold;">${d.Qh}</label>
                        <p class="description">${d.Rh}</p>
                        <input type="number" id="smelting-timer-noitem" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoItem||15}">
                    </div>

                    <div class="timer-item">
                        <label for="repair-timer" style="font-weight: bold;">${d.Ca}</label>
                        <p class="description">${d.Kh}</p>
                        <input type="number" id="repair-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Repair||10}">
                    </div>

                    <div class="timer-item">
                        <label for="guild-market-timer" style="font-weight: bold;">${d.Ih}</label>
                        <p class="description">${d.Jh}</p>
                        <input type="number" id="guild-market-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildMarket||2}">
                    </div>

                    <div class="timer-item">
                        <label for="auction-hold-timer" style="font-weight: bold;">${d.Eh}</label>
                        <p class="description">${d.Fh}</p>
                        <input type="number" id="auction-hold-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionHoldGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="arena-timer" style="font-weight: bold;">Arena:</label>
                        <p class="description">${d.Bh}</p>
                        <input type="number" id="arena-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Arena||10}">
                    </div>

                    <div class="timer-item">
                        <label for="circus-turma-timer" style="font-weight: bold;">Circus Turma:</label>
                        <p class="description">${d.Gh}</p>
                        <input type="number" id="circus-turma-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).CircusTurma||10}">
                    </div>

                    <div class="timer-item">
                        <label for="training-timer" style="font-weight: bold;">${d.Xh}</label>
                        <p class="description">${d.Yh}</p>
                        <input type="number" id="training-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Training||2}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-expired-timer" style="font-weight: bold;">${d.Lh}</label>
                        <p class="description">${d.Mh}</p>
                        <input type="number" id="reset-expired-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).ResetExpired||10}">
                    </div>

                    <div class="timer-item">
                        <label for="store-forge-timer" style="font-weight: bold;">${d.Vh}</label>
                        <p class="description">${d.Wh}</p>
                        <input type="number" id="store-forge-timer" class="timer-input" style="width: 60px;" min="5" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).StoreForge||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-auction-timer" style="font-weight: bold;">${d.Ch}</label>
                        <p class="description">${d.Dh}</p>
                        <input type="number" id="reset-auction-timer" class="timer-input" style="width: 60px;" min="1" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionCheck||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-search-timer" style="font-weight: bold;">${d.Nh}</label>
                        <p class="description">${d.Oh}</p>
                        <input type="number" id="reset-search-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SearchTimer||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guilddonate-timer" style="font-weight: bold;">${d.eb}</label>
                        <p class="description">${d.Hh}</p>
                        <input type="number" id="reset-guilddonate-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildDonate||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guildattack-timer" style="font-weight: bold;">Guild Attack</label>
                        <p class="description">Sets timer for guild attack</p>
                        <input type="number" id="reset-guildattack-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).guildBattleEnable||120}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-buff-timer" style="font-weight: bold;">Buffs</label>
                        <p class="description">Buff timer</p>
                        <input type="number" id="reset-buff-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Buffs||60}">
                    </div>

                    </div>
                </div>
                </div>


                  <div class="popup-box" id="other_settings">

                <div class="settings_tab_title">${d.rd}</div>

                <div class="setting-row">
                ${d.sd}
                    <select id="delaySelect">
                    <option value="0">0 seconds</option>
                    <option value="1">1 second</option>
                    <option value="5">1 to 5 seconds</option>
                    <option value="10">5 to 10 seconds</option>
                    <option value="15">10 to 15 seconds</option>
                    <option value="30">15 to 30 seconds</option>
                    <option value="60">30 to 60 seconds</option>
                    <option value="120">1 to 2 minutes</option>
                    </select>
                </div>
                <div class="setting-row">
                    <label for="timeConditions">Bot Auto Start/Stop Schedule:</label>
                    <div id="timeConditions"></div>
                    <br></br>
                    <button id="addCondition" class="awesome-button btn">Add Condition</button>
                </div>
                  
                <div class="settings_tab_title">${d.Xj}</div>

                <div class="setting-row">
                  <label for="storeResource">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="storeResource">
                    <span class="switch"></span>
                    </label>
                </div>

                <div class="settings_tab_title">${d.de}</div>

                <div class="setting-row">
                  <label for="HighlightUnderworldItems">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="HighlightUnderworldItems">
                    <span class="switch"></span>
                    </label>
                </div>
                    
                <div class="settings_tab_title">${d.Zh}</div>
                <div class="setting-row">

                      <div class="setting-row">
                        <label for="trainEnable">${d.v}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainEnable">
                          <span class="switch"></span>
                          </label>
                      </div>

                      <div class="setting-row">
                        <label for="trainPickGold">${d.Yj}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainPickGold">
                          <span class="switch"></span>
                          </label>
                      </div>

                          ${d.ai}
                      <div class="stat-container">


                        <div class="stat stat-header">
                            <div>Stats</div>
                            <div>Points</div>
                            <div>Priority</div>
                        </div>

                        <div class="stat">
                          <input type="checkbox" id="Strength" class="stat-checkbox" data-skill="1" data-stat-name="Strength">
                          <label for="Strength">${d.Strength}</label>
                          <input type="number" class="stat-count" id="StrengthCount" min="0" value="${localStorage.getItem("StrengthCount")||0}">
                          <div class="priority-btn" id="StrengthPriority" data-stat="Strength" data-priority="${localStorage.getItem("StrengthPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="StrengthContinue" class="stat-checkbox" data-stat="Strength" data-skill="1">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Dexterity" class="stat-checkbox" data-skill="2" data-stat-name="Dexterity">
                          <label for="Dexterity">${d.Dexterity}</label>
                          <input type="number" class="stat-count" id="DexterityCount" min="0" value="${localStorage.getItem("DexterityCount")||0}">
                          <div class="priority-btn" id="DexterityPriority" data-stat="Dexterity" data-priority="${localStorage.getItem("DexterityPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="DexterityContinue" class="stat-checkbox" data-stat="Dexterity" >
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Agility" class="stat-checkbox" data-skill="3" data-stat-name="Agility">
                          <label for="Agility">${d.Agility}</label>
                          <input type="number" class="stat-count" id="AgilityCount" min="0" value="${localStorage.getItem("AgilityCount")||0}">
                          <div class="priority-btn" id="AgilityPriority" data-stat="Agility" data-priority="${localStorage.getItem("AgilityPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="AgilityContinue" class="stat-checkbox" data-stat="Agility">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Constitution" class="stat-checkbox" data-skill="4" data-stat-name="Constitution">
                          <label for="Constitution">${d.Constitution}</label>
                          <input type="number" class="stat-count" id="ConstitutionCount" min="0" value="${localStorage.getItem("ConstitutionCount")||0}">
                          <div class="priority-btn" id="ConstitutionPriority" data-stat="Constitution" data-priority="${localStorage.getItem("ConstitutionPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="ConstitutionContinue" class="stat-checkbox" data-stat="Constitution">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Charisma" class="stat-checkbox" data-skill="5" data-stat-name="Charisma">
                          <label for="Charisma">${d.Charisma}</label>
                          <input type="number" class="stat-count" id="CharismaCount" min="0" value="${localStorage.getItem("CharismaCount")||0}">
                          <div class="priority-btn" id="CharismaPriority" data-stat="Charisma" data-priority="${localStorage.getItem("CharismaPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="CharismaContinue" class="stat-checkbox" data-stat="Charisma">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Intelligence" class="stat-checkbox" data-skill="6" data-stat-name="Intelligence">
                          <label for="Intelligence">${d.Intelligence}</label>
                          <input type="number" class="stat-count" id="IntelligenceCount" min="0" value="${localStorage.getItem("IntelligenceCount")||0}">
                          <div class="priority-btn" id="IntelligencePriority" data-stat="Intelligence" data-priority="${localStorage.getItem("IntelligencePriority")||1}">Set Priority</div>
                          <input type="checkbox" id="IntelligenceContinue" class="stat-checkbox" data-stat="Intelligence">
                        </div>                                                                                                                   

                        <div class="setting-row">
                            
                            <label for="TrainingHoldGold">${d.aa}</label>

                            <div class="switch-field3">
                            <input type="number" id="TrainingHoldGold" min="0" value="${localStorage.getItem("TrainingHoldGold")||0}">                         
                            </div>  
                  
                        </div>

                                  <span class="span-new">${d.$h}</span>        

                      </div>  
                    </div>
        
                </div>

            <div class="popup-box" id="Extra">
            <div class="settings_tab_title">${d.hb}</div>

              <div class="setting-row">
                
                    <span style="color:red"class="span-new">1 Day Trial Key : </span>
                    <span id="kydt"style="color:red"></span>
                    <br>
                    <span style="color:red"class="span-new">${d.De} : </span>
                    <span id="kydtexp"style="color:red"></span>
                    
                    <ul>
                    <p>
                    <b>1.1.2 Update</b>
                    <div class="scrollable-list">
                        <ul>
                        <li>New feature : Seperate heal options for both underworld & without underworld.</li>
                        <li>Fixed a problem where bot wouldnt do partial repair.</li>
                        <li>Fixed an issue where bot wouldn't sell golds in packages.</li>
                        <li>Fixed a problem heal would use more foods than needed.</li>
                        <li>More translations.</li>
                        </ul>
                    </div>

                </div>

                <div class="settings_tab_title">Stats</div>
                    <div class="setting-row">
                        <div id="stats">
                            <p>${d.Vj} <span id="items-repaired">0</span></p>
                            <p>${d.qd} <span id="items-reset">0</span></p>
                            <p>${d.Uj} <span id="gold-cycled">0</span></p>
                            <p>${d.Oj} <span id="arena-attacks">0</span></p>
                            <p>${d.Qj} <span id="circus-attacks">0</span></p>
                            <p>${d.Sj} <span id="dungeons-attacked">0</span></p>
                            <p>${d.Tj} <span id="expeditions-attacked">0</span></p>
                            <p>${d.qd} <span id="items-smelted">0</span></p>
                            <p>${d.Wj} <span id="underworld-attacks">0</span></p>
                            <p>${d.Pj} <span id="arena-money">0</span></p>
                            <p>${d.Rj} <span id="circus-money">0</span></p>
                        </div>
                        <button class="awesome-button" id="reset-stats-button">${d.Bi}</button>
                    </div>
           

            <div class="settings_tab_title">${d.We}</div>
            
            <div class="setting-row">
              <button class="awesome-button" id="exportBtn">${d.Ee}</button>
              <input type="file" id="importBtn" style="display: none;">
              <button class="awesome-button" id="importFileBtn">${d.Xe}</button>
              <p id="importStatus"></p>
              <p>
            </div>

            <div class="settings_tab_title">${d.Gd}</div>

            <div class="setting-row">
            <span class="span-new">${d.Hd}</span>
              <br></br>
              <label for="autologinenable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="autologinenable">
                <span class="switch"></span>
              </label>
            </div>

            <div class="settings_tab_title">${d.Cg}</div>
                <div class="setting-row">
                <label for="pauseBotEnable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="pauseBotEnable">
                <span class="switch"></span>
                </label>
            </div>
            
            <div class="setting-row">
                <label for="pauseBot">${d.Dg}</label>
                <div class="switch-field3"> 
                <input type="number" id="pauseBot" placeholder="Minutes" value="${Math.round((localStorage.getItem("pauseBot.timeOut")-Date.now())/6E4)||0}">
                </div>
                </label>
            </div>

            <div class="settings_tab_title">UI Settings</div>

                <div class="setting-row">
                    <label for="disableBG">${d.yj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableBG">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="disableLogMenu">${d.Ud}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableLogMenu">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="MoveButtons">${d.zj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="MoveButtons">
                        <span class="switch"></span>
                    </label>
                </div>
                
            
    
            <div class="settings_tab_title">${d.hg}</div>
                <div class="setting-row">
                    <span class="span-new">${d.ig}</span>
                    <textarea id="messageInput" rows="4" cols="50" placeholder="${d.jg}" style="width: 350px; height: 50px;"></textarea>
                    <button class="awesome-button" id="messageButton">${d.lg}</button>
                    <button class="awesome-button"id="showPlayersButton">${d.mg}</button>
                    <button class="awesome-button" id="selectAllButton">${d.kg}</button>
                    <button class="awesome-button" id="unselectAllButton">${d.ng}</button>
                    <div id="messageStatus"></div>
                    <div id="playerList" style="display: none;"></div>
                    <div id="loadingContainer"></div>
                    <br>
                    ${d.Td}
                </div>        
            </div>

                  <div class="popup-box" id="Market">
                  <div class="settings_tab_title">Market Buy</div>
        
                    <span class="span-new">${d.Rf}</span>

                    <div class="setting-row">
                      <label for="enableMarketSearch">${d.ee}
                        <label class="toggle-switch">
                        <input type="checkbox" id="enableMarketSearch">
                        <span class="switch"></span>
                      </label>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label>${d.Sf}</label>
                    <span style="font-weight: normal">${d.Tf}</span>
                    <input type="text" id="MarketSearchInterval" placeholder="Market Search Interval - Minutes" value="${localStorage.getItem("MarketSearchInterval")||""}">

                    </div>



                    <div class="setting-row">
                    <div class="setting-row">
                        <label for="marketOnlyFood">${d.xg}
                        <label class="toggle-switch">
                        <input type="checkbox" id="marketOnlyFood">
                        <span class="switch"></span>
                        </label>
                        </label>
                    </div>
                      <span class="span-new">${d.yg}</span>
                      
                      <label for="MaxTotalGold">${d.Ab} : </label><input type="number" id="MarketMaxFoodPrice" placeholder="${d.Ab}" value="${localStorage.getItem("MarketMaxFoodPrice")||""}">
                    
                      <label for="MaxPerFood">${d.zb} : </label><input type="number" id="MarketMaxPerFoodPrice" placeholder="${d.zb}" value="${localStorage.getItem("MarketMaxPerFoodPrice")||""}">

                      <label for="MinItemLevel">${d.da} : </label><input type="number" id="MarketMinItemLevel" placeholder="${d.da}" value="${localStorage.getItem("MarketMinItemLevel")||""}">
                    

                    </div>

                    <div class="setting-row">
                    <label>${d.$e}</label>
                      <input type="text" id="itemToBuy" placeholder="${d.Ye}">
                    </div>

                    <div class="setting-row">
                      <input type="number" id="maxPrice" placeholder="${d.N}">
                    </div>

                    <div class="setting-row">
                    
                      <label>${d.af}</label>
                      <select id="marketItemType">
                        <option value="WEAPON">${d.U}</option>
                        <option value="SHIELD">${d.M}</option>
                        <option value="CHEST">${d.I}</option>
                        <option value="HELMET">${d.L}</option>
                        <option value="GLOVES">${d.K}</option>
                        <option value="SHOES">${d.J}</option>
                        <option value="RINGS">${d.T}</option>
                        <option value="AMULETS">${d.R}</option>
                        <option value="USABLES">${d.oa}</option></option>
                        <option value="BOOSTS">${d.fj}</option></option>
                        <option value="UPGRADES">${d.va}</option></option>
                        <option value="RECIPES">${d.sa}</option></option>
                        <option value="MERCENARY">${d.ra}</option></option>
                        <option value="FORGINGGOODS">${d.ed}</option></option>
                        <option value="btools">${d.ua}</option></option>
                        <option value="SCROLLS">${d.ta}</option></option>
                      </select>

                      <label>${d.Ze}</label>
                      <select id="rarity">
                        <option value="White">${d.wa}</option>
                        <option value="Green">${d.C}</option>
                        <option value="Blue">${d.B}</option>
                        <option value="Purple">${d.D}</option>
                        <option value="Orange">${d.G}</option>
                        <option value="Red">${d.S}</option>
                      </select>

                      <label>${d.Od}</label>
                      <select id="itemsoulbound">
                        <option value="BuySoulbound">${d.wi}</option>
                        <option value="DontBuySoulbound">${d.vg}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <button class="awesome-button" id="addItemBtn">${d.H}</button>
                    </div>

                    <div class="setting-row">
                      <label for="itemList">${d.cf}</label>
                      <select id="itemList" size="10"></select>
                      <button class="awesome-button" id="removeItemBtn">${d.Tg}</button>
                    </div>

                    <div class="setting-row">
                      <label for="usePacks">${d.bf}
                      <label class="toggle-switch">
                        <input type="checkbox" id="usePacks">
                        <span class="switch"></span>
                        </label>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="MarketboughtItems">${d.Md}</label>
                      <select id="MarketboughtItems" size="5"></select>
                      <button class="awesome-button" id="MarketremoveItemBtn">${d.Rd}</button>
                    </div>

                    <div class="setting-row">
                    <label for="MarketHoldGold">${d.aa}</label>
                    <input type="number" id="MarketHoldGold" min="0" value="${localStorage.getItem("MarketHoldGold")||0}">
                    </div>
                  
                    </div>   
                  </div>
                </div>
              </div>
            </div>

              `;document.getElementById("header_game").insertBefore(t,document.getElementById("header_game").children[0]);t=document.createElement("div");w=document.getElementById("wrapper_game").clientHeight;t.setAttribute("id","overlayBack");t.setAttribute("style",`height: ${w}px; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 198;`);t.addEventListener("click",cc);document.getElementsByTagName("body")[0].appendChild(t);(function(){var v=localStorage.getItem("lastActiveTab");v?(v=
document.querySelector(`.popup-tab[data-target="${v}"]`))&&Oc(v):(v=document.querySelector(".popup-tab"))&&Oc(v)})();t=localStorage.getItem("we");null!==t&&(t=(new Date(t)).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),document.getElementById("kydtexp").textContent=t,t=localStorage.getItem("showTrial"),null!==t&&(document.getElementById("kydt").textContent=t));bi();(function(){document.querySelectorAll(".setting-row").forEach(function(v){v.addEventListener("mouseenter",
function(){var D=this.getAttribute("data-tooltip");if(D&&""!==D.trim()){const F=document.createElement("div");F.className="custom-tooltip";F.innerHTML=D;document.body.appendChild(F);D=this.getBoundingClientRect();F.style.left=D.left+D.width/2-F.offsetWidth/2+"px";F.style.top=D.top-F.offsetHeight+"px";this.$l=F}});v.addEventListener("mouseleave",function(){this.$l&&(document.body.removeChild(this.$l),this.$l=null)})})})();document.querySelectorAll(".popup-tab").forEach(v=>{v.addEventListener("click",
()=>{Oc(v);localStorage.setItem("lastActiveTab",v.dataset.target)})});const y=document.querySelectorAll(".popup-tab"),A=document.querySelectorAll(".popup-box"),B=document.querySelector(`#${document.querySelector(".popup-tab.active").dataset.target}`);B.classList.add("active");A.forEach(v=>{v!==B&&(v.style.display="none")});y.forEach(v=>{v.addEventListener("click",()=>{y.forEach(D=>D.classList.remove("active"));v.classList.add("active");A.forEach(D=>{D.style.display="none"});document.querySelector(`#${v.dataset.target}`).style.display=
"block"})});$("#languageGB").click(function(){b("EN")});$("#languagePL").click(function(){b("PL")});$("#languageES").click(function(){b("ES")});$("#languageTR").click(function(){b("TR")});$("#languageFR").click(function(){b("FR")});$("#languageHG").click(function(){b("HG")});$("#languageBR").click(function(){b("BR")});$("#do_expedition_true").click(function(){c(!0)});$("#do_expedition_false").click(function(){c(!1)});$("#set_monster_id_0").click(function(){e("0")});$("#set_monster_id_1").click(function(){e("1")});
$("#set_monster_id_2").click(function(){e("2")});$("#set_monster_id_3").click(function(){e("3")});$("#do_dungeon_true").click(function(){g(!0)});$("#do_dungeon_false").click(function(){g(!1)});(t=localStorage.getItem("dungeonDifficulty"))&&h(t);$("#set_dungeon_difficulty_normal").click(function(){k("normal")});$("#set_dungeon_difficulty_advanced").click(function(){k("advanced")});$("#do_arena_true").click(function(){l(!0)});$("#do_arena_false").click(function(){l(!1)});$("#do_circus_true").click(function(){n(!0)});
$("#do_circus_false").click(function(){n(!1)});$("#do_quests_true").click(function(){m(!0)});$("#do_quests_false").click(function(){m(!1)});$("#do_combat_quests").click(function(){r("combat")});$("#do_arena_quests").click(function(){r("arena")});$("#do_circus_quests").click(function(){r("circus")});$("#do_expedition_quests").click(function(){r("expedition")});$("#do_dungeon_quests").click(function(){r("dungeon")});$("#do_items_quests").click(function(){r("items")});$("#do_event_expedition_true").click(function(){u(!0)});
$("#do_event_expedition_false").click(function(){u(!1)});$(document).ready(function(){function v(z){var H=z.split(". "),L="<ol>";H.forEach(function(O,V){""!==O.trim()&&(V!==H.length-1||O.endsWith(".")||(O+="."),L+="<li>"+O+"</li>")});return L+="</ol>"}function D(z){const H={"guild-market-timer":"GuildMarket","smelting-timer":"Smelting","smelting-timer-nogold":"SmeltingNoGold","smelting-timer-noitem":"SmeltingNoItem","repair-timer":"Repair","auction-hold-timer":"AuctionHoldGold","arena-timer":"Arena",
"circus-turma-timer":"CircusTurma","training-timer":"Training","reset-expired-timer":"ResetExpired","store-forge-timer":"StoreForge","reset-auction-timer":"AuctionCheck","reset-search-timer":"SearchTimer","reset-guilddonate-timer":"GuildDonate","reset-guildattack-timer":"guildBattleEnable","reset-buff-timer":"BuffTimer"};return H[z]?H[z]:z.replace(/-([a-z])/g,function(L){return L[1].toUpperCase()}).replace("-timer","")}function F(){var z="Strength Dexterity Agility Constitution Charisma Intelligence".split(" ");
const H=[];for(const L of z){z=document.getElementById(`${L}Count`);document.getElementById(`${L}Priority`);z=z?z.value:0;let O=gb[L];null===O&&(O="None");H.push({stat:L,count:z,priority:O,Hm:document.getElementById(`${L}`).checked})}localStorage.setItem("statSettings",JSON.stringify(H))}function I(z,H){JSON.parse(localStorage.getItem(H)||"[]").forEach(L=>K(L,z,H))}function K(z,H,L){const O=document.createElement("div");O.className="keyword-item";var V=document.createElement("span");V.textContent=
z;O.appendChild(V);V=document.createElement("span");V.className="remove-keyword";V.textContent="X";V.addEventListener("click",function(){O.remove();let Y=JSON.parse(localStorage.getItem(L)||"[]");const ca=Y.indexOf(z);-1<ca&&(Y.splice(ca,1),localStorage.setItem(L,JSON.stringify(Y)))});O.appendChild(V);H.appendChild(O)}function M(z,H){const L=JSON.parse(localStorage.getItem(H)||"[]");L.push(z);localStorage.setItem(H,JSON.stringify(L))}function Q(z,H,L){const O=document.createElement("li");O.textContent=
z;O.style.padding="10px";O.style.border="1px solid #ccc";O.style.borderColor="#cea429";O.style.borderRadius="5px";O.style.marginBottom="5px";O.style.display="flex";O.style.justifyContent="space-between";const V=document.createElement("button");V.textContent="X";V.style.textAlign="center";V.addEventListener("click",()=>{O.remove();const Y=(JSON.parse(localStorage.getItem(L))||[]).filter(ca=>!(ca[0]===z[0]&&ca[1]===z[1]));localStorage.setItem(L,JSON.stringify(Y))});O.appendChild(V);document.getElementById(H).appendChild(O)}
function Z(){hb=hb.map(z=>{z.km=!1;z.gm=null;return z})}function ba(){document.getElementById("startSearchButton").innerText="Start Search";gc=!1}function ia(){const z=document.getElementById("clothCount");var H=parseInt(z.value,10);isNaN(H)&&(H=0);--H;0>=H&&(H=0);return z.value=H}function la(){const z=document.getElementById("itemsList");z.innerHTML="";hb.forEach((H,L)=>{const O=document.createElement("div");O.style.display="flex";O.style.flexDirection="column";O.style.border="1px solid #d2b97f";
O.style.padding="10px";O.style.marginBottom="10px";O.style.borderRadius="5px";O.style.backgroundColor="#faf2dd";var V=document.createElement("div");V.style.display="flex";V.style.justifyContent="space-between";V.style.alignItems="center";const Y=document.createElement("span");Y.innerHTML=`<strong>${H.name}</strong> (${H.qualityName}) - Level: [${H.Tm}]`;Y.style.color="#5d432c";const ca=document.createElement("button");ca.innerText="Remove";ca.style.backgroundColor="#af552e";ca.style.color="white";
ca.style.border="none";ca.style.padding="5px 10px";ca.style.cursor="pointer";ca.style.borderRadius="3px";ca.onclick=()=>{hb.splice(L,1);la();wa()};V.appendChild(Y);V.appendChild(ca);O.appendChild(V);H.Ml&&H.Yl&&(V=document.createElement("div"),V.style.marginTop="5px",V.style.fontStyle="italic",V.style.color="#7d5b3e",V.innerText=`Stat: ${H.Ml.toUpperCase()} - Value: ${H.Yl}`,O.appendChild(V));z.appendChild(O)})}function wa(){localStorage.setItem("itemsToSearch",JSON.stringify(hb))}function Ha(z,H){const L=
document.getElementById("foundItemsContainer");L.style.display="flex";L.style.flexWrap="wrap";L.style.justifyContent="center";L.style.alignItems="center";L.style.bp="10px";const O=document.createElement("div");O.className="notification-item";O.style.border="1px solid #d2b97f";O.style.borderRadius="4px";O.style.padding="10px";O.style.margin="5px";O.style.textAlign="center";O.style.backgroundColor="#faf2dd";O.style.boxShadow="0 2px 4px rgba(0, 0, 0, 0.1)";O.style.boxSizing="border-box";O.style.flex=
"0 1 calc(20% - 10px)";O.style.display="flex";O.style.flexDirection="column";O.style.alignItems="center";O.style.transition="all 0.3s ease-in-out";const V=document.createElement("span"),Y=document.createElement("span");switch(Number(z.gm.getAttribute("data-quality"))){case 0:Y.style.color="green";break;case 1:Y.style.color="blue";break;case 2:Y.style.color="purple";break;case 3:Y.style.color="orange";break;case 4:Y.style.color="red";break;default:Y.style.color="#333"}Y.innerText=z.name;Y.style.fontWeight=
"bold";Y.style.fontSize="12px";Y.style.marginBottom="5px";V.appendChild(Y);const ca=document.createElement("div");ca.style.marginTop="5px";ca.style.padding="10px";ca.style.borderRadius="5px";ca.style.display="flex";ca.style.justifyContent="center";ca.style.alignItems="center";ca.style.transition="transform 0.3s ease-in-out";ca.onmouseover=()=>{ca.style.transform="scale(1.1)"};ca.onmouseout=()=>{ca.style.transform="scale(1)"};z=z.gm.cloneNode(!0);z.style.position="static";z.style.transform="none";
z.style.margin="0";ca.appendChild(z);z=document.createElement("a");z.href=H;z.style.textDecoration="none";z.style.cursor="pointer";z.onmouseover=()=>{Y.style.textDecoration="underline"};z.onmouseout=()=>{Y.style.textDecoration="none"};z.appendChild(V);z.appendChild(ca);O.appendChild(z);L.appendChild(O);hc.style.display="block"}async function na(){var z=!1;if(!gc)return!1;const H=await Ff();var L=hb.filter(ca=>!ca.km);for(let ca of L)for(const Qc of H){L=Qc.querySelectorAll("#shop .ui-draggable");
for(const Ra of L){var O=JSON.parse(Ra.getAttribute("data-tooltip").replace(/&quot;/g,'"')),V=parseInt(Db(Ra).split("-")[0],10);L=15==V?parseInt(Ra.getAttribute("data-tooltip").split(",")[5].match(/\d+/)[0],10):0;let di=15==V?parseInt(Ra.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,ei=15==V?parseInt(Ra.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,fi=15==V?parseInt(Ra.getAttribute("data-tooltip").split(",")[11].match(/\d+/)[0],10):0,gi=15==V?parseInt(Ra.getAttribute("data-tooltip").split(",")[13].match(/\d+/)[0],
10):0;V=15==V?parseInt(Ra.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],10):0;var Y=Ra.getAttribute("data-quality");O=O[0][0][0];const hi=Ra.getAttribute("data-level");if(Number(hi)>=Number(ca.Tm)&&O.toLowerCase().includes(ca.name.toLowerCase())&&(Y>=ca.quality||!Y&&"0"==ca.quality)){if(ca.Ml&&ca.Yl&&"none"!==ca.Ml&&(Y=!1,(L={str:L,dex:di,agi:ei,cot:fi,chr:gi,"int":V}[ca.Ml])&&L>=ca.Yl&&(Y=!0),!Y))continue;ca.gm=Ra.cloneNode(!0);Ha(ca,Qc.sm||Qc.querySelector("a.shopLink").href);z=ca.km=
!0}}}L=hb.filter(ca=>!ca.km);if(0===L.length||z)return ba(),!0;z=ia();Wa();if(0>=z)return ba(),!1;await va();return na()}async function va(){var z=new URL(window.location.href);const H=z.origin;z=z.searchParams.get("sh")||"";await fetch(`${H}/game/index.php?mod=inventory&sub=2&subsub=0&sh=${z}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({bestechen:"New goods"})})}function Wa(){var z=parseInt(document.getElementById("clothCount").getAttribute("data-total"),
10);const H=parseInt(document.getElementById("clothCount").value,10);z=(z-H)/z*100;document.getElementById("progressBarInner").style.width=`${isNaN(z)?100:z}%`}function Rc(){const z=[...Sc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelectionSmelt",JSON.stringify(z))}function Ya(){const z=[...Tc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelection",JSON.stringify(z))}function ib(){localStorage.setItem("timeConditions",JSON.stringify(Hb))}function ic(z=
{}){const H=document.createElement("div");H.classList.add("condition-row");H.innerHTML=`
                    <input type="time" class="awesome-button start-time" value="${z.start||""}" required> to
                    <input type="time" class="awesome-button end-time" value="${z.end||""}" required>
                    <br>
                    <select class="bot-action">
                        <option value="start" ${"start"===z.action?"selected":""}>Start Bot</option>
                        <option value="stop" ${"stop"===z.action?"selected":""}>Stop Bot</option>
                    </select>
                    <button class="awesome-button remove-condition">Remove</button>
                `;ib();H.querySelector(".remove-condition").addEventListener("click",()=>{Gf.removeChild(H);Hb=Hb.filter(L=>L!==z);ib()});H.querySelector(".start-time").addEventListener("change",L=>{z.start=L.target.value;ib()});H.querySelector(".end-time").addEventListener("change",L=>{z.end=L.target.value;ib()});H.querySelector(".bot-action").addEventListener("change",L=>{z.action=L.target.value;ib()});Gf.appendChild(H)}function Hf(){document.getElementById("mercenarySearchOptions").style.display=
jc.checked?"block":"none"}function ii(z){document.querySelectorAll('#itemsToReset input[type="checkbox"]').forEach(H=>{H.checked=z});Sa()}function Uc(){localStorage.setItem("marketItems",JSON.stringify(jb));Vc.innerHTML="";If.innerHTML="";for(var z of Ib){var H=document.createElement("option");H.textContent=z;If.appendChild(H)}for(z=0;z<jb.length;z++)H=document.createElement("option"),H.value=z,H.text=jb[z].Qm+" (Rarity: "+jb[z].Wl+", Max price: "+jb[z].maxPrice+" "+jb[z].Soulbound+")",Vc.appendChild(H)}
function Jf(z,H,L){H[z.id]&&z.classList.add("active");z.addEventListener("click",function(O){O.preventDefault();this.classList.contains("active")?(this.classList.remove("active"),H[this.id]=!1):(this.classList.add("active"),H[this.id]=!0);localStorage.setItem(L,JSON.stringify(H))})}function Kf(z,H,L,O){L.forEach(V=>{V in H||(H[V]=!1)});localStorage.setItem(O,JSON.stringify(H))}function Lf(){const z=kc.checked;ji.style.display=z?"block":"none";ki.style.display=z?"block":"none"}const li=document.getElementById("doExpedition"),
mi=document.getElementById("doDungeon"),ni=document.getElementById("doArena"),oi=document.getElementById("doCircus"),pi=document.getElementById("doQuests"),qi=document.getElementById("doEventExpedition"),ri=document.getElementById("activateAutoBid"),si=document.getElementById("doKasa"),lc=document.querySelector("#healPercentage"),Wc=document.querySelector("#HealClothToggle"),Mf=document.querySelector("#hellEnterHP"),Nf=document.querySelector("#HellHealHP"),Xc=document.querySelector("#HealRubyToggle"),
Yc=document.querySelector("#storeResource"),Zc=document.querySelector("#HighlightUnderworldItems");lc.value=localStorage.getItem("healPercentage")||25;Wc.checked="true"===localStorage.getItem("HealClothToggle")||!1;Xc.checked="true"===localStorage.getItem("HealRubyToggle")||!1;Yc.checked="true"===localStorage.getItem("storeResource")||!1;Zc.checked="true"===localStorage.getItem("HighlightUnderworldItems")||!1;const Of=document.getElementById("minimumGoldAmount");Of.addEventListener("change",()=>{localStorage.setItem("minimumGoldAmount",
Of.value)});const Pf="true"===localStorage.getItem("useGodPowers");document.getElementById("useGodPowers").checked=Pf;document.getElementById("godPowersSection").style.display=Pf?"block":"none";const ti=JSON.parse(localStorage.getItem("GodPowersHell"))||[];document.querySelectorAll(".god-power-checkbox").forEach(z=>{z.checked=ti.includes(z.value)});const ui="true"===localStorage.getItem("useWeaponBuff");document.getElementById("weaponBuff").checked=ui;const vi=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||
[];document.querySelectorAll(".armor-checkbox").forEach(z=>{z.checked=vi.includes(z.value)});document.getElementById("useGodPowers").addEventListener("change",function(){const z=this.checked;localStorage.setItem("useGodPowers",z);document.getElementById("godPowersSection").style.display=z?"block":"none"});document.querySelectorAll(".god-power-checkbox").forEach(z=>{z.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".god-power-checkbox:checked")).map(L=>L.value);localStorage.setItem("GodPowersHell",
JSON.stringify(H))})});document.getElementById("weaponBuff").addEventListener("change",function(){localStorage.setItem("useWeaponBuff",this.checked)});document.querySelectorAll(".armor-checkbox").forEach(z=>{z.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".armor-checkbox:checked")).map(L=>L.value);localStorage.setItem("ArmorBuffsHell",JSON.stringify(H))})});const Qf=document.getElementById("autoSmeltInfo"),xb=document.getElementById("popupSmelt");Qf.addEventListener("mouseenter",
function(){xb.style.display="block";const z=document.querySelector(".popup-menu").getBoundingClientRect();xb.style.position="fixed";xb.style.width="350px";xb.style.left=`${z.right+10}px`;xb.style.top=`${z.top}px`});Qf.addEventListener("mouseleave",function(){xb.style.display="none"});var $c=document.getElementById("tabA"),ad=document.getElementById("tabB"),Rf=document.getElementById("contentA"),Sf=document.getElementById("contentB"),bd=document.getElementById("tabACircus"),cd=document.getElementById("tabBCircus"),
Tf=document.getElementById("contentACircus"),Uf=document.getElementById("contentBCircus");$c.addEventListener("click",function(){Rf.style.display="block";Sf.style.display="none";$c.classList.add("active");ad.classList.remove("active")});ad.addEventListener("click",function(){Sf.style.display="block";Rf.style.display="none";ad.classList.add("active");$c.classList.remove("active")});bd.addEventListener("click",function(){Tf.style.display="block";Uf.style.display="none";bd.classList.add("active");cd.classList.remove("active")});
cd.addEventListener("click",function(){Uf.style.display="block";Tf.style.display="none";cd.classList.add("active");bd.classList.remove("active")});const wi=v(d.Vb),xi=v(d.Gb);document.querySelector(".instructions .span-new").innerHTML=wi;document.querySelector(".instructionsReset .span-new").innerHTML=xi;const dd=document.getElementById("announcement"),ed="1.1.2 esta ativa, reinicie o navegador. Melhorando o reparo de itens para a proxima versão!  1.1.2 is live. Improving repair for the next version!";ed&&""!==ed?(dd.style.display="block",dd.innerHTML=ed):dd.style.display="none";const yi=[{id:"Health",
buffs:["Gingko","Taigaroot","Hawthorn"]},{id:"Strength",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Dexterity",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Agility",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Constitution",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Charisma",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Intelligence",buffs:["Flask","Ampulla","Flacon","Bottle"]}];(function(){const z=JSON.parse(localStorage.getItem("buffSelections"))||{};yi.forEach(H=>{z[H.id]=
z[H.id]||[];H.buffs.forEach((L,O)=>{const V=document.getElementById(`${H.id}Buff${O+1}`);V.checked=z[H.id].includes(L);V.addEventListener("change",()=>{V.checked?z[H.id].push(L):z[H.id]=z[H.id].filter(Y=>Y!==L);localStorage.setItem("buffSelections",JSON.stringify(z))})})})})();let fd=document.getElementById("BuffsEnable");fd.checked="true"===localStorage.getItem("BuffsEnable");fd.addEventListener("change",()=>{localStorage.setItem("BuffsEnable",fd.checked)});let gd=document.getElementById("BuffUnderworldOnly");
gd.checked="true"===localStorage.getItem("BuffUnderworldOnly");gd.addEventListener("change",()=>{localStorage.setItem("BuffUnderworldOnly",gd.checked)});document.querySelectorAll(".timer-input").forEach(z=>{z.addEventListener("change",function(){var H=parseInt(this.min,10);let L=parseInt(this.value,10);L<H&&(this.value=L=H);H=JSON.parse(localStorage.getItem("Timers"))||{};const O=D(this.id);H[O]=L;localStorage.setItem("Timers",JSON.stringify(H))})});const gb={Strength:null,Dexterity:null,Agility:null,
Constitution:null,Charisma:null,Intelligence:null};(function(){var z=JSON.parse(localStorage.getItem("statSettings"))||[];for(const {stat:H,count:L,priority:O,Hm:V}of z)document.getElementById(`${H}Count`)&&(document.getElementById(`${H}Count`).value=L),document.getElementById(`${H}Priority`)&&(z=O||"None",document.getElementById(`${H}Priority`).dataset.priority=z,document.getElementById(`${H}Priority`).textContent=`Priority: ${z}`),document.getElementById(`${H}`)&&(document.getElementById(`${H}`).checked=
V||!1);z=JSON.parse(localStorage.getItem("statSettings"))||[];for(const {stat:H,priority:L}of z)gb[H]="None"===L?null:L})();const Vf=document.querySelectorAll(".priority-btn");Vf.forEach(z=>{z.addEventListener("click",function(H){const L=H.target.getAttribute("data-stat");let O=(gb[L]||0)+1;6<O&&(O=1);for(const [V,Y]of Object.entries(gb))if(Y===O){gb[V]=null;const ca=document.getElementById(`${V}Priority`);ca.innerText="Set Priority";ca.setAttribute("data-priority","None")}gb[L]=O;H.target.innerText=
`Priority: ${O}`;H.target.setAttribute("data-priority",O);Vf.forEach(V=>{const Y=V.getAttribute("data-stat");V.innerText=null!==gb[Y]?`Priority: ${gb[Y]}`:"Set Priority"});F()})});Array.from(document.getElementsByClassName("stat-count")).forEach(z=>{z.addEventListener("change",()=>{F()})});document.getElementById("clear_next_event_expedition_time").addEventListener("click",function(){localStorage.setItem("eventPoints_",16);alert("Done!")});let Za=localStorage.getItem("workbenchItem");Za=Za?JSON.parse(Za):
{};Za.selectedItem&&Za.selectedItem.item?document.getElementById("currentWorkbenchItem").textContent=Za.selectedItem.item.name:document.getElementById("currentWorkbenchItem").textContent="No item";document.getElementById("clear_repair").addEventListener("click",function(){Za.selectedItem&&(Za.selectedItem={},Object.assign(Za.selectedItem,{selectedItem:!1}),localStorage.removeItem("workbenchItem"),localStorage.removeItem("activeItems"),localStorage.removeItem("activeItemsGladiator"),localStorage.removeItem("activeItemsMercenary"),
document.getElementById("currentWorkbenchItem").textContent="No item")});document.getElementById("ClearAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackList",JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearOtherAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackServerList",JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));
window.location.reload()});document.getElementById("ClearAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackList",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearOtherCircusAttackList").addEventListener("click",
function(){localStorage.setItem("autoAttackCircusServerList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackCircusList",JSON.stringify([]));window.location.reload()});const Wf=document.getElementById("keywordAcceptInput"),zi=document.getElementById("addKeywordAcceptBtn"),Xf=document.getElementById("keywordAcceptList"),
mc=document.getElementById("underworldKeywordSection"),Yf=document.getElementById("underworldKeywordInput"),Ai=document.getElementById("addUnderworldKeywordBtn"),Zf=document.getElementById("underworldKeywordList");let hd=document.getElementById("skipTimeQuests");hd.checked="true"===localStorage.getItem("skipTimeQuests");hd.addEventListener("change",()=>{localStorage.setItem("skipTimeQuests",hd.checked)});let jd=document.getElementById("skipTimeCircusQuests");jd.checked="true"===localStorage.getItem("skipTimeCircusQuests");
jd.addEventListener("change",()=>{localStorage.setItem("skipTimeCircusQuests",jd.checked)});let kd=document.getElementById("skipTimeOtherQuests");kd.checked="true"===localStorage.getItem("skipTimeOtherQuests");kd.addEventListener("change",()=>{localStorage.setItem("skipTimeOtherQuests",kd.checked)});"Mercury Apollo Diana Minerva Vulcan Mars".split(" ").forEach(z=>{let H=document.getElementById(`questType${z}`);H.checked="true"===localStorage.getItem(`questType${z}`);H.addEventListener("change",()=>
{localStorage.setItem(`questType${z}`,H.checked)})});let Jb=document.getElementById("UnderworldQuests");Jb.checked="true"===localStorage.getItem("UnderworldQuests");Jb.addEventListener("change",()=>{localStorage.setItem("UnderworldQuests",Jb.checked);Jb.checked||"true"===localStorage.getItem("UnderworldQuests")?mc.style.display="block":mc.style.display="none"});Jb.checked||"true"===localStorage.getItem("UnderworldQuests")?mc.style.display="block":mc.style.display="none";let ld=document.getElementById("acceptnotfilter");
ld.checked="true"===localStorage.getItem("acceptnotfilter");ld.addEventListener("change",()=>{localStorage.setItem("acceptnotfilter",ld.checked)});const md=document.getElementById("keywordInput"),Bi=document.getElementById("addKeywordBtn"),$f=document.getElementById("keywordList"),Ci=document.getElementById("keywordGuildInput"),Di=document.getElementById("addGuildKeywordBtn"),ag=document.getElementById("keywordGuildList");I(ag,"guildKeywords");Di.addEventListener("click",function(){const z=Ci.value.trim();
""!==z&&(K(z,ag,"guildKeywords"),M(z,"guildKeywords"),md.value="")});I($f,"questKeywords");I(Zf,"underworldQuestKeywords");Bi.addEventListener("click",function(){const z=md.value.trim();""!==z&&(K(z,$f,"questKeywords"),M(z,"questKeywords"),md.value="")});I(Xf,"acceptQuestKeywords");zi.addEventListener("click",function(){const z=Wf.value.trim();""!==z&&(K(z,Xf,"acceptQuestKeywords"),M(z,"acceptQuestKeywords"),Wf.value="")});Ai.addEventListener("click",function(){const z=Yf.value.trim();""!==z&&(K(z,
Zf,"underworldQuestKeywords"),M(z,"underworldQuestKeywords"),Yf.value="")});let nd=document.getElementById("renewEvent");nd.checked="true"===localStorage.getItem("renewEvent");nd.addEventListener("change",()=>{localStorage.setItem("renewEvent",nd.checked)});let od=document.getElementById("throwDice");od.checked="true"===localStorage.getItem("throwDice");od.addEventListener("change",()=>{localStorage.setItem("throwDice",od.checked)});let pd=document.getElementById("useCostume");pd.checked="true"===
localStorage.getItem("useCostume");pd.addEventListener("change",()=>{localStorage.setItem("useCostume",pd.checked)});let Kb=document.getElementById("wearUnderworld"),bg=document.getElementById("costumeUnderworldWrapper");Kb.checked="true"===localStorage.getItem("wearUnderworld");bg.style.display=Kb.checked?"block":"none";Kb.addEventListener("change",()=>{localStorage.setItem("wearUnderworld",Kb.checked);bg.style.display=Kb.checked?"block":"none"});document.getElementById("costumeUnderworld").addEventListener("change",
function(){localStorage.setItem("costumeUnderworld",this.value)});const Ei=document.getElementById("costumeUnderworld"),cg=localStorage.getItem("costumeUnderworld");null!==cg&&(Ei.value=cg);const Fi=document.getElementById("costumeBasic"),dg=localStorage.getItem("costumeBasic");document.getElementById("costumeBasic").addEventListener("change",function(){localStorage.setItem("costumeBasic",this.value)});null!==dg&&(Fi.value=dg);document.getElementById("costumeDungeon").addEventListener("change",function(){localStorage.setItem("costumeDungeon",
this.value)});const Gi=document.getElementById("costumeDungeon"),eg=localStorage.getItem("costumeDungeon");null!==eg&&(Gi.value=eg);const Hi=document.getElementById("search_input"),Ii=document.getElementById("search_reset"),Ji=document.getElementById("search_button");let nc=JSON.parse(localStorage.getItem("searchTerms")||"[]");nc.forEach(z=>{Q(z,"search_list","searchTerms")});Ji.addEventListener("click",function(){const z=Hi.value.trim();""===z||nc.includes(z)||(nc.push(z),localStorage.setItem("searchTerms",
JSON.stringify(nc)),Q(z,"search_list","searchTerms"))});const qd=document.querySelector(".equipment-search-selection");qd.addEventListener("change",()=>{const z=Array.from(qd.querySelectorAll(".equipment-search-option:checked")).map(H=>H.value);localStorage.setItem("SearchTypes",JSON.stringify(z))});JSON.parse(localStorage.getItem("SearchTypes")||"[]").forEach(z=>{if(z=qd.querySelector(`.equipment-search-option[value="${z}"]`))z.checked=!0});let hb=JSON.parse(localStorage.getItem("itemsToSearch"))||
[];document.getElementById("addItemButton").addEventListener("click",function(){const z=document.getElementById("newItem").value,H=document.getElementById("itemQuality").value,L=document.getElementById("newItemLevel").value,O=document.getElementById("shopitemstat").value,V=document.getElementById("statValue").value;hb.push({name:z,quality:H,Tm:L,qualityName:Ki[H],Ml:"none"!==O?O:null,Yl:"none"!==O?V:null});la();wa()});document.getElementById("startSearchButton").addEventListener("click",async function(){gc=
!0;hc.style.display="none";document.getElementById("clothCount").setAttribute("data-total",document.getElementById("clothCount").value);document.getElementById("startSearchButton").innerText="Searching...";await na()});document.getElementById("stopSearchButton").addEventListener("click",ba);document.getElementById("shopitemstat").addEventListener("change",function(){document.getElementById("statValueRow").style.display="none"===this.value?"none":"block"});const hc=document.getElementById("skipSearchButton");
hc.addEventListener("click",async function(){const z=document.getElementById("foundItemsContainer");for(;z.firstChild;)z.removeChild(z.firstChild);Z();gc=!0;hc.style.display="none";ia();Wa();await va();await na()});let gc=!0;const Ki={0:"Green",1:"Blue",2:"Purple",3:"Orange",4:"Red"};la();Zh();const Sc=document.querySelectorAll(".equipment-option-smelt");Sc.forEach(z=>{z.addEventListener("change",Rc)});(JSON.parse(localStorage.getItem("equipmentSelectionSmelt"))||[]).forEach(z=>{const H=[...Sc].find(L=>
L.value===z);H&&(H.checked=!0)});const Tc=document.querySelectorAll(".equipment-option");Tc.forEach(z=>{z.addEventListener("change",Ya)});(JSON.parse(localStorage.getItem("equipmentSelection"))||[]).forEach(z=>{const H=[...Tc].find(L=>L.value===z);H&&(H.checked=!0)});Ii.addEventListener("click",function(){localStorage.setItem("AuctionSearch.timeOut",0);localStorage.setItem("ShopSearch.timeOut",0);location.reload()});let rd=document.getElementById("trainPickGold");rd.checked="true"===localStorage.getItem("trainPickGold");
rd.addEventListener("change",()=>{localStorage.setItem("trainPickGold",rd.checked)});let sd=document.getElementById("trainEnable");sd.checked="true"===localStorage.getItem("trainEnable");sd.addEventListener("change",()=>{localStorage.setItem("trainEnable",sd.checked)});let td=document.getElementById("EnableArenaHell");td.checked="true"===localStorage.getItem("EnableArenaHell");td.addEventListener("change",()=>{localStorage.setItem("EnableArenaHell",td.checked)});let ud=document.getElementById("dungeonAB");
ud.checked="true"===localStorage.getItem("dungeonAB");ud.addEventListener("change",()=>{localStorage.setItem("dungeonAB",ud.checked)});let vd=document.getElementById("dungeonFocusQuest");vd.checked="true"===localStorage.getItem("dungeonFocusQuest");vd.addEventListener("change",()=>{localStorage.setItem("dungeonFocusQuest",vd.checked)});(function(){const z=document.getElementById("autologinenable"),H="true"===localStorage.getItem("AutoLogin");z.checked=H;Yb(H);z.addEventListener("change",function(){const L=
this.checked;localStorage.setItem("AutoLogin",L);Yb(L)})})();const Gf=document.getElementById("timeConditions"),Li=document.getElementById("addCondition");let Hb=JSON.parse(localStorage.getItem("timeConditions"))||[];Hb.forEach(ic);Li.addEventListener("click",()=>{const z={start:"",end:"",action:"stop"};Hb.push(z);ic(z);ib()});let wd=document.getElementById("enableArenaSimulator");wd.checked="true"===localStorage.getItem("enableArenaSimulator");wd.addEventListener("change",()=>{localStorage.setItem("enableArenaSimulator",
wd.checked)});let xd=document.getElementById("enableCircusSimulator");xd.checked="true"===localStorage.getItem("enableCircusSimulator");xd.addEventListener("change",()=>{localStorage.setItem("enableCircusSimulator",xd.checked)});let yd=document.getElementById("enableCircusWithoutHeal");yd.checked="true"===localStorage.getItem("enableCircusWithoutHeal");yd.addEventListener("change",()=>{localStorage.setItem("enableCircusWithoutHeal",yd.checked)});let zd=document.getElementById("arenaAttackGM");zd.checked=
"true"===localStorage.getItem("arenaAttackGM");zd.addEventListener("change",()=>{localStorage.setItem("arenaAttackGM",zd.checked)});let Ad=document.getElementById("onlyArena");Ad.checked="true"===localStorage.getItem("onlyArena");Ad.addEventListener("change",()=>{localStorage.setItem("onlyArena",Ad.checked)});let Bd=document.getElementById("onlyCircus");Bd.checked="true"===localStorage.getItem("onlyCircus");Bd.addEventListener("change",()=>{localStorage.setItem("onlyCircus",Bd.checked)});let Cd=document.getElementById("attackRandomly");
Cd.checked="true"===localStorage.getItem("attackRandomly");Cd.addEventListener("change",()=>{localStorage.setItem("attackRandomly",Cd.checked)});let Dd=document.getElementById("attackRandomlyCircus");Dd.checked="true"===localStorage.getItem("attackRandomlyCircus");Dd.addEventListener("change",()=>{localStorage.setItem("attackRandomlyCircus",Dd.checked)});let Ed=document.getElementById("circusAttackGM");Ed.checked="true"===localStorage.getItem("circusAttackGM");Ed.addEventListener("change",()=>{localStorage.setItem("circusAttackGM",
Ed.checked)});let Fd=document.getElementById("auctionmercenaryenable");Fd.checked="true"===localStorage.getItem("auctionmercenaryenable");Fd.addEventListener("change",()=>{localStorage.setItem("auctionmercenaryenable",Fd.checked)});let Gd=document.getElementById("auctionTURBO");Gd.checked="true"===localStorage.getItem("auctionTURBO");Gd.addEventListener("change",()=>{localStorage.setItem("auctionTURBO",Gd.checked)});let Hd=document.getElementById("auctiongladiatorenable");Hd.checked="true"===localStorage.getItem("auctiongladiatorenable");
Hd.addEventListener("change",()=>{localStorage.setItem("auctiongladiatorenable",Hd.checked)});let Id=document.getElementById("bidFood");Id.checked="true"===localStorage.getItem("bidFood");Id.addEventListener("change",()=>{localStorage.setItem("bidFood",Id.checked)});let Jd=document.getElementById("ignorePS");Jd.checked="true"===localStorage.getItem("ignorePS");Jd.addEventListener("change",()=>{localStorage.setItem("ignorePS",Jd.checked)});let Kd=document.getElementById("auctionminlevel");Kd.value=
localStorage.getItem("auctionminlevel")||"";Kd.addEventListener("input",()=>{localStorage.setItem("auctionminlevel",Kd.value)});let Ld=document.getElementById("AuctionCover");Ld.checked="true"===localStorage.getItem("AuctionCover");Ld.addEventListener("change",()=>{localStorage.setItem("AuctionCover",Ld.checked)});let Md=document.getElementById("AuctionGoldCover");Md.checked="true"===localStorage.getItem("AuctionGoldCover");Md.addEventListener("change",()=>{localStorage.setItem("AuctionGoldCover",
Md.checked)});let Nd=document.getElementById("maximumBid");Nd.value=localStorage.getItem("maximumBid")||"";Nd.addEventListener("input",()=>{localStorage.setItem("maximumBid",Nd.value)});let Od=document.getElementById("activateAuction2");Od.checked="true"===localStorage.getItem("activateAuction2");Od.addEventListener("change",()=>{localStorage.setItem("activateAuction2",Od.checked)});let Pd=document.getElementById("AuctionItemLevel2");Pd.value=localStorage.getItem("AuctionItemLevel2")||"";Pd.addEventListener("input",
()=>{localStorage.setItem("AuctionItemLevel2",Pd.value)});let jc=document.getElementById("enableMercenarySearch"),Qd=document.getElementById("minDexterity"),Rd=document.getElementById("minAgility"),Sd=document.getElementById("minIntelligence");jc.checked="true"===localStorage.getItem("enableMercenarySearch");Qd.value=localStorage.getItem("minDexterity")||0;Rd.value=localStorage.getItem("minAgility")||0;Sd.value=localStorage.getItem("minIntelligence")||0;Hf();jc.addEventListener("change",()=>{localStorage.setItem("enableMercenarySearch",
jc.checked);Hf()});Qd.addEventListener("input",()=>{localStorage.setItem("minDexterity",Qd.value)});Rd.addEventListener("input",()=>{localStorage.setItem("minAgility",Rd.value)});Sd.addEventListener("input",()=>{localStorage.setItem("minIntelligence",Sd.value)});const Td=document.getElementById("SearchQuality"),fg=localStorage.getItem("SearchQuality");fg&&(Td.value=fg);Td.addEventListener("change",()=>{localStorage.setItem("SearchQuality",Td.value)});const Ud=document.getElementById("HealPickBag"),
gg=localStorage.getItem("HealPickBag");gg&&(Ud.value=gg);Ud.addEventListener("change",()=>{localStorage.setItem("HealPickBag",Ud.value)});const Vd=document.getElementById("FoodAmount"),hg=localStorage.getItem("FoodAmount");hg&&(Vd.value=hg);Vd.addEventListener("change",()=>{localStorage.setItem("FoodAmount",Vd.value)});const ig=document.getElementById("questrewardvalue");ig.addEventListener("change",()=>{localStorage.setItem("questrewardvalue",ig.value)});const Wd=document.getElementById("smeltTab"),
jg=localStorage.getItem("smeltTab");jg&&(Wd.value=jg);Wd.addEventListener("change",()=>{localStorage.setItem("smeltTab",Wd.value)});const Xd=document.getElementById("repairMaxQuality"),Yd=document.getElementById("repairBeforeSmeltMaxQuality"),Zd=document.getElementById("PartialOrFull");let oc=localStorage.getItem("repairMaxQuality"),pc=localStorage.getItem("repairBeforeSmeltMaxQuality"),qc=localStorage.getItem("PartialOrFull");oc||(oc="1",localStorage.setItem("repairMaxQuality",oc));pc||(pc="1",localStorage.setItem("RSMaxQuality",
pc));qc||(qc="0",localStorage.setItem("PartialOrFull",qc));Xd.value=oc;Yd.value=pc;Xd.addEventListener("change",()=>{localStorage.setItem("repairMaxQuality",Xd.value)});Yd.addEventListener("change",()=>{localStorage.setItem("repairBeforeSmeltMaxQuality",Yd.value)});Zd.addEventListener("change",()=>{localStorage.setItem("PartialOrFull",Zd.value)});Zd.value=qc;var rc=document.getElementById("repairPercentage");(function(){var z=localStorage.getItem("repairPercentage");if(null!==z)for(var H=0;H<rc.options.length;H++)if(rc.options[H].text.replace("%",
"")===z){rc.selectedIndex=H;break}})();rc.addEventListener("change",function(){var z=this.options[this.selectedIndex].text.replace("%","");localStorage.setItem("repairPercentage",z)});const $d=document.getElementById("bidStatus"),kg=localStorage.getItem("bidStatus");kg&&($d.value=kg);$d.addEventListener("change",()=>{localStorage.setItem("bidStatus",$d.value)});const ae=document.getElementById("auctionMinQuality"),lg=localStorage.getItem("auctionMinQuality");lg&&(ae.value=lg);ae.addEventListener("change",
()=>{localStorage.setItem("auctionMinQuality",ae.value)});const be=document.getElementById("storeInShopQuality"),mg=localStorage.getItem("storeInShopQuality");mg&&(be.value=mg);be.addEventListener("change",()=>{localStorage.setItem("storeInShopQuality",be.value)});const Sa=function(z,H){let L;return function(){const O=this,V=arguments;clearTimeout(L);L=setTimeout(()=>z.apply(O,V),H)}}(function(){const z=document.getElementById("resetExpiredItems").checked,H=document.getElementById("resetDays").value,
L=Array.from(document.querySelectorAll('#itemsToReset input[type="checkbox"]:checked')).map(Y=>Y.value),O=Array.from(document.querySelectorAll('#itemsToReset2 input[type="checkbox"]:checked')).map(Y=>Y.value),V=Array.from(document.querySelectorAll('#itemsToResetGuild input[type="checkbox"]:checked')).map(Y=>Y.value);localStorage.setItem("resetExpiredItems",z);localStorage.setItem("resetDays",H);localStorage.setItem("itemsToReset",JSON.stringify(L));localStorage.setItem("itemsToReset2",JSON.stringify(O));
localStorage.setItem("itemsToResetGuild",JSON.stringify(V))},250);document.getElementById("resetExpiredItems").addEventListener("change",Sa);document.getElementById("resetDays").addEventListener("change",Sa);document.getElementById("itemsToReset").addEventListener("change",Sa);document.getElementById("itemsToReset2").addEventListener("change",Sa);document.getElementById("itemsToResetGuild").addEventListener("change",Sa);document.getElementById("resetExpiredItems").addEventListener("touchend",Sa);
document.getElementById("resetDays").addEventListener("touchend",Sa);document.getElementById("itemsToReset").addEventListener("touchend",Sa);document.getElementById("itemsToReset2").addEventListener("touchend",Sa);document.getElementById("itemsToResetGuild").addEventListener("touchend",Sa);document.getElementById("selectAllItems").addEventListener("click",function(){let z="true"!==this.dataset.checked;this.innerHTML=(this.dataset.checked=z)?'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <polyline points="20 6 9 17 4 12"></polyline>\n                    </svg>':
'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line> \n                    </svg>';ii(z)});(function(){const z="true"===localStorage.getItem("resetExpiredItems"),H=localStorage.getItem("resetDays"),L=JSON.parse(localStorage.getItem("itemsToReset")||"[]"),O=JSON.parse(localStorage.getItem("itemsToReset2")||
"[]"),V=JSON.parse(localStorage.getItem("itemsToResetGuild")||"[]");document.getElementById("resetExpiredItems").checked=z;document.getElementById("resetDays").value=H;L.forEach(Y=>{if(Y=document.getElementById(Y))Y.checked=!0});O.forEach(Y=>{if(Y=document.getElementById(Y))Y.checked=!0});V.forEach(Y=>{if(Y=document.getElementById(Y))Y.checked=!0})})();const ce=document.getElementById("guildPackHour"),ng=localStorage.getItem("guildPackHour");ng&&(ce.value=ng);ce.addEventListener("change",()=>{localStorage.setItem("guildPackHour",
ce.value)});const de=document.getElementById("filterGM"),og=localStorage.getItem("filterGM");og&&(de.value=og);de.addEventListener("change",()=>{localStorage.setItem("filterGM",de.value)});const qb=document.getElementById("delaySelect"),pg=localStorage.getItem("DELAY");if(pg)for(let z=0;z<qb.options.length;z++)if(qb.options[z].text===pg){qb.value=qb.options[z].value;break}qb.addEventListener("change",()=>{localStorage.setItem("DELAY",qb.options[qb.selectedIndex].text)});const ee=document.getElementById("questSpeed"),
qg=localStorage.getItem("questSpeed");qg&&(ee.value=qg);ee.addEventListener("change",()=>{localStorage.setItem("questSpeed",ee.value)});let rg=document.getElementById("itemToBuy"),sg=document.getElementById("rarity"),tg=document.getElementById("marketItemType"),ug=document.getElementById("itemsoulbound"),vg=document.getElementById("maxPrice"),Mi=document.getElementById("addItemBtn"),Ni=document.getElementById("removeItemBtn"),Oi=document.getElementById("MarketremoveItemBtn"),Vc=document.getElementById("itemList"),
If=document.getElementById("MarketboughtItems"),Ib=localStorage.getItem("MarketboughtItems");Ib?Ib=JSON.parse(Ib):Ib=[];const wg=document.getElementById("MarketSearchInterval");wg.addEventListener("change",()=>{localStorage.setItem("MarketSearchInterval",wg.value)});document.getElementById("MarketSearchInterval").addEventListener("input",function(){3>parseInt(this.value,10)&&(this.value=3)});const xg=document.getElementById("MarketMaxPerFoodPrice");xg.addEventListener("change",()=>{localStorage.setItem("MarketMaxPerFoodPrice",
xg.value)});const yg=document.getElementById("MarketMaxFoodPrice");yg.addEventListener("change",()=>{localStorage.setItem("MarketMaxFoodPrice",yg.value)});const zg=document.getElementById("MarketMinItemLevel");zg.addEventListener("change",()=>{localStorage.setItem("MarketMinItemLevel",zg.value)});let fe=document.getElementById("marketOnlyFood");fe.checked="true"===localStorage.getItem("marketOnlyFood");fe.addEventListener("change",()=>{localStorage.setItem("marketOnlyFood",fe.checked)});let jb=JSON.parse(localStorage.getItem("marketItems"))||
[];Mi.onclick=function(){jb.push({Qm:rg.value||1,Wl:sg.value||4,maxPrice:vg.value||4,itemType:tg.value||4,Soulbound:ug.value||2});rg.value="";sg.value="White";vg.value="";tg.value="WEAPONS";ug.value="DontBuySoulbound";Uc()};Ni.onclick=function(){jb.splice(Vc.value,1);Uc()};Oi.onclick=function(){document.getElementById("MarketboughtItems").innerHTML="";localStorage.setItem("MarketboughtItems",JSON.stringify([]))};Uc();let ge=document.getElementById("enableMarketSearch");ge.checked="true"===localStorage.getItem("enableMarketSearch");
ge.addEventListener("change",()=>{localStorage.setItem("enableMarketSearch",ge.checked)});let he=document.getElementById("usePacks");he.checked="true"===localStorage.getItem("usePacks");he.addEventListener("change",()=>{localStorage.setItem("usePacks",he.checked)});const ie=document.getElementById("scoreRange"),Ag=localStorage.getItem("scoreRange");Ag&&(ie.value=Ag);ie.addEventListener("change",()=>{localStorage.setItem("scoreRange",ie.value)});const je=document.getElementById("scoreRangeCircus"),
Bg=localStorage.getItem("scoreRangeCircus");Bg&&(je.value=Bg);je.addEventListener("change",()=>{localStorage.setItem("scoreRangeCircus",je.value)});let ke=document.getElementById("scoreboardattackenable");ke.checked="true"===localStorage.getItem("scoreboardattackenable");ke.addEventListener("change",()=>{localStorage.setItem("scoreboardattackenable",ke.checked)});let le=document.getElementById("scoreboardcircusenable");le.checked="true"===localStorage.getItem("scoreboardcircusenable");le.addEventListener("change",
()=>{localStorage.setItem("scoreboardcircusenable",le.checked)});let me=document.getElementById("leagueattackenable");me.checked="true"===localStorage.getItem("leagueattackenable");me.addEventListener("change",()=>{localStorage.setItem("leagueattackenable",me.checked)});let Lb=document.getElementById("leaguerandom");Lb.checked="true"===localStorage.getItem("leaguerandom");Lb.addEventListener("change",()=>{localStorage.setItem("leaguerandom",Lb.checked);Lb.checked&&(Mb.checked=!1,localStorage.setItem("leaguelowtohigh",
!1))});let Mb=document.getElementById("leaguelowtohigh");Mb.checked="true"===localStorage.getItem("leaguelowtohigh");Mb.addEventListener("change",()=>{localStorage.setItem("leaguelowtohigh",Mb.checked);Mb.checked&&(Lb.checked=!1,localStorage.setItem("leaguerandom",!1))});let ne=document.getElementById("leaguecircusattackenable");ne.checked="true"===localStorage.getItem("leaguecircusattackenable");ne.addEventListener("change",()=>{localStorage.setItem("leaguecircusattackenable",ne.checked)});let Nb=
document.getElementById("leaguecircusrandom");Nb.checked="true"===localStorage.getItem("leaguecircusrandom");Nb.addEventListener("change",()=>{localStorage.setItem("leaguecircusrandom",Nb.checked);Nb.checked&&(Ob.checked=!1,localStorage.setItem("leaguecircuslowtohigh",!1))});let Ob=document.getElementById("leaguecircuslowtohigh");Ob.checked="true"===localStorage.getItem("leaguecircuslowtohigh");Ob.addEventListener("change",()=>{localStorage.setItem("leaguecircuslowtohigh",Ob.checked);Ob.checked&&
(Nb.checked=!1,localStorage.setItem("leaguecircusrandom",!1))});let oe=document.getElementById("autoAddArena");oe.checked="true"===localStorage.getItem("autoAddArena");oe.addEventListener("change",()=>{localStorage.setItem("autoAddArena",oe.checked)});let pe=document.getElementById("autoAvoidArena");pe.checked="true"===localStorage.getItem("autoAvoidArena");pe.addEventListener("change",()=>{localStorage.setItem("autoAvoidArena",pe.checked)});const Cg=document.getElementById("autoAddArenaAmount");
Cg.addEventListener("change",()=>{localStorage.setItem("autoAddArenaAmount",Cg.value)});const Dg=document.getElementById("ArenaSimulatorAmount");Dg.addEventListener("change",()=>{localStorage.setItem("ArenaSimulatorAmount",Dg.value)});const Eg=document.getElementById("CircusSimulatorAmount");Eg.addEventListener("change",()=>{localStorage.setItem("CircusSimulatorAmount",Eg.value)});let qe=document.getElementById("autoAddCircus");qe.checked="true"===localStorage.getItem("autoAddCircus");qe.addEventListener("change",
()=>{localStorage.setItem("autoAddCircus",qe.checked)});let re=document.getElementById("autoAvoidCircus");re.checked="true"===localStorage.getItem("autoAvoidCircus");re.addEventListener("change",()=>{localStorage.setItem("autoAvoidCircus",re.checked)});const Fg=document.getElementById("autoAddCircusAmount");Fg.addEventListener("change",()=>{localStorage.setItem("autoAddCircusAmount",Fg.value)});let se=document.getElementById("UnderWorldUseRuby");se.checked="true"===localStorage.getItem("UnderWorldUseRuby");
se.addEventListener("change",()=>{localStorage.setItem("UnderWorldUseRuby",se.checked)});let te=document.getElementById("useSacrifice");te.checked="true"===localStorage.getItem("useSacrifice");te.addEventListener("change",()=>{localStorage.setItem("useSacrifice",te.checked)});let ue=document.getElementById("usePray");ue.checked="true"===localStorage.getItem("usePray");ue.addEventListener("change",()=>{localStorage.setItem("usePray",ue.checked)});let ve=document.getElementById("UnderworldUseMobi");
ve.checked="true"===localStorage.getItem("UnderworldUseMobi");ve.addEventListener("change",()=>{localStorage.setItem("UnderworldUseMobi",ve.checked)});let we=document.getElementById("exitUnderworld");we.checked="true"===localStorage.getItem("exitUnderworld");we.addEventListener("change",()=>{localStorage.setItem("exitUnderworld",we.checked)});let xe=document.getElementById("autoEnterHell");xe.checked="true"===localStorage.getItem("autoEnterHell");xe.addEventListener("change",()=>{localStorage.setItem("autoEnterHell",
xe.checked)});let ye=document.getElementById("dontEnterUnderworld");ye.checked="true"===localStorage.getItem("dontEnterUnderworld");ye.addEventListener("change",()=>{localStorage.setItem("dontEnterUnderworld",ye.checked)});let ze=document.getElementById("disableLogMenu");ze.checked="true"===localStorage.getItem("disableLogMenu");ze.addEventListener("change",()=>{localStorage.setItem("disableLogMenu",ze.checked)});let Ae=document.getElementById("disableBG");Ae.checked="true"===localStorage.getItem("disableBG");
Ae.addEventListener("change",()=>{localStorage.setItem("disableBG",Ae.checked)});let Be=document.getElementById("MoveButtons");Be.checked="true"===localStorage.getItem("MoveButtons");Be.addEventListener("change",()=>{localStorage.setItem("MoveButtons",Be.checked)});let Ce=document.getElementById("pauseBotEnable");Ce.checked="true"===localStorage.getItem("pauseBotEnable");Ce.addEventListener("change",()=>{localStorage.setItem("pauseBotEnable",Ce.checked)});const Gg=document.getElementById("pauseBot");
Gg.addEventListener("change",()=>{X("pauseBot",Gg.value)});let De=document.getElementById("storeGoldinAuction");De.checked="true"===localStorage.getItem("storeGoldinAuction");De.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuction",De.checked)});const Hg=document.getElementById("storeGoldinAuctionmaxGold");Hg.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuctionmaxGold",Hg.value)});const Ig=document.getElementById("storeGoldinAuctionholdGold");Ig.addEventListener("change",
()=>{localStorage.setItem("storeGoldinAuctionholdGold",Ig.value)});const Jg=document.getElementById("TrainingHoldGold");Jg.addEventListener("change",()=>{localStorage.setItem("TrainingHoldGold",Jg.value)});const Kg=document.getElementById("MarketHoldGold");Kg.addEventListener("change",()=>{localStorage.setItem("MarketHoldGold",Kg.value)});const Lg=document.getElementById("KasaHoldGold");Lg.addEventListener("change",()=>{localStorage.setItem("KasaHoldGold",Lg.value)});let Ee=document.getElementById("guildBattleEnable");
Ee.checked="true"===localStorage.getItem("guildBattleEnable");Ee.addEventListener("change",()=>{localStorage.setItem("guildBattleEnable",Ee.checked)});let Fe=document.getElementById("guildBattleRandom");Fe.checked="true"===localStorage.getItem("guildBattleRandom");Fe.addEventListener("change",()=>{localStorage.setItem("guildBattleRandom",Fe.checked)});let Ge=document.getElementById("GuildEnable");Ge.checked="true"===localStorage.getItem("GuildEnable");Ge.addEventListener("change",()=>{localStorage.setItem("GuildEnable",
Ge.checked)});const Mg=document.getElementById("GuildDonateAmount");Mg.addEventListener("change",()=>{localStorage.setItem("GuildDonateAmount",Mg.value)});const Ng=document.getElementById("GuildDonateMore");Ng.addEventListener("change",()=>{localStorage.setItem("GuildDonateMore",Ng.value)});const Og=document.getElementById("GuildDonateLess");Og.addEventListener("change",()=>{localStorage.setItem("GuildDonateLess",Og.value)});document.getElementById("hellDifficulty").addEventListener("change",function(){localStorage.setItem("hellDifficulty",
this.value)});const Pi=document.getElementById("hellDifficulty"),Pg=localStorage.getItem("hellDifficulty");null!==Pg&&(Pi.value=Pg);let He=document.getElementById("useVillaMedici");He.checked="true"===localStorage.getItem("useVillaMedici");He.addEventListener("change",()=>{localStorage.setItem("useVillaMedici",He.checked)});let Ie=document.getElementById("useHealingPotion");Ie.checked="true"===localStorage.getItem("useHealingPotion");Ie.addEventListener("change",()=>{localStorage.setItem("useHealingPotion",
Ie.checked)});const Je=document.getElementById("repairMercenary");Je.checked="true"===localStorage.getItem("repairMercenary");Je.addEventListener("change",()=>{localStorage.setItem("repairMercenary",Je.checked)});const Ke=document.getElementById("repairGladiator");Ke.checked="true"===localStorage.getItem("repairGladiator");Ke.addEventListener("change",()=>{localStorage.setItem("repairGladiator",Ke.checked)});let Le=document.getElementById("activateRepair");Le.checked="true"===localStorage.getItem("activateRepair");
Le.addEventListener("change",()=>{localStorage.setItem("activateRepair",Le.checked)});const Qi=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(z=>{z.checked=Qi.includes(z.value)});document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(z=>{z.addEventListener("change",()=>{const H=[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(L=>{L.checked&&H.push(L.value)});
localStorage.setItem("ignoredMaterials",JSON.stringify(H))})});const Qg=document.querySelectorAll(".gladiator-inventory .inventory-item"),Rg=document.querySelectorAll(".mercenary-inventory .inventory-item"),Sg=JSON.parse(localStorage.getItem("activeItemsGladiator"))||{},Tg=JSON.parse(localStorage.getItem("activeItemsMercenary"))||{};Qg.forEach(z=>{Jf(z,Sg,"activeItemsGladiator")});Rg.forEach(z=>{Jf(z,Tg,"activeItemsMercenary")});Kf(Qg,Sg,"helmet necklace weapon armor shield gloves shoes rings1 rings2".split(" "),
"activeItemsGladiator");Kf(Rg,Tg,"helmetM necklaceM weaponM armorM shieldM glovesM shoesM rings1M rings2M".split(" "),"activeItemsMercenary");const Ug=document.getElementById("expeditionLocation");Ug.addEventListener("change",()=>{localStorage.setItem("expeditionLocation",Ug.value)});const Vg=document.getElementById("dungeonLocation");Vg.addEventListener("change",()=>{localStorage.setItem("dungeonLocation",Vg.value)});const sc=document.getElementById("autoCollectBonuses");sc.checked="true"===localStorage.getItem("autoCollectBonuses");
document.getElementById("enemySelection").style.display=sc.checked?"none":"block";sc.addEventListener("change",()=>{localStorage.setItem("autoCollectBonuses",sc.checked)});const Me=document.getElementById("skipBossToggle");Me.checked="true"===localStorage.getItem("skipBoss");Me.addEventListener("change",()=>{localStorage.setItem("skipBoss",Me.checked)});const Ne=document.getElementById("resetIfLoseToggle");Ne.checked="true"===localStorage.getItem("resetIfLose");Ne.addEventListener("change",()=>{localStorage.setItem("resetIfLose",
Ne.checked)});const Oe=document.getElementById("activateSmelt");Oe.checked="true"===localStorage.getItem("EnableSmelt");Oe.addEventListener("change",()=>{localStorage.setItem("EnableSmelt",Oe.checked)});const Pe=document.getElementById("EnableHellLimit"),Wg=document.getElementById("hellLimit").closest(".setting-row"),Xg="true"===localStorage.getItem("EnableHellLimit"),Yg=localStorage.getItem("hellLimit")||5;Pe.checked=Xg;document.getElementById("hellLimit").value=Yg;Wg.style.display=Xg?"block":"none";
Pe.addEventListener("change",function(){const z=Pe.checked;localStorage.setItem("EnableHellLimit",z);Wg.style.display=z?"block":"none"});document.getElementById("hellLimit").addEventListener("input",function(){const z=document.getElementById("hellLimit").value;1<=z&&200>=z?localStorage.setItem("hellLimit",z):document.getElementById("hellLimit").value=Yg});const kc=document.getElementById("farmEnable"),ji=document.getElementById("farmLocation").closest(".setting-row"),ki=document.getElementById("farmEnemy").closest(".setting-row"),
Ri="true"===localStorage.getItem("farmEnable"),Zg=localStorage.getItem("farmLocation"),$g=localStorage.getItem("farmEnemy");kc.checked=Ri;Zg&&(document.getElementById("farmLocation").value=Zg);$g&&(document.getElementById("farmEnemy").value=$g);Lf();kc.addEventListener("change",function(){localStorage.setItem("farmEnable",kc.checked);Lf()});document.getElementById("farmLocation").addEventListener("change",function(){localStorage.setItem("farmLocation",this.value)});document.getElementById("farmEnemy").addEventListener("change",
function(){localStorage.setItem("farmEnemy",this.value)});const Qe=document.getElementById("doHeal");Qe.checked="true"===localStorage.getItem("HealEnabled");Qe.addEventListener("change",()=>{localStorage.setItem("HealEnabled",Qe.checked)});const Re=document.getElementById("healShopToggle");Re.checked="true"===localStorage.getItem("HealShop");Re.addEventListener("change",()=>{localStorage.setItem("HealShop",Re.checked)});const Se=document.getElementById("healfrompackage");Se.checked="true"===localStorage.getItem("HealPackage");
Se.addEventListener("change",()=>{localStorage.setItem("HealPackage",Se.checked)});const Te=document.getElementById("healcervisia");Te.checked="true"===localStorage.getItem("HealCervisia");Te.addEventListener("change",()=>{localStorage.setItem("HealCervisia",Te.checked)});const Ue=document.getElementById("HealEggs");Ue.checked="true"===localStorage.getItem("HealEggs");Ue.addEventListener("change",()=>{localStorage.setItem("HealEggs",Ue.checked)});const Ve=document.getElementById("OilEnable");Ve.checked=
"true"===localStorage.getItem("OilEnable");Ve.addEventListener("change",()=>{localStorage.setItem("OilEnable",Ve.checked)});document.getElementById("enemySelect").addEventListener("change",function(){localStorage.setItem("selectedEnemy",this.value)});const Si=document.getElementById("enemySelect"),ah=localStorage.getItem("selectedEnemy");null!==ah&&(Si.value=ah);document.getElementById("autoCollectBonuses").addEventListener("change",function(){document.getElementById("enemySelection").style.display=
this.checked?"none":"block"});li.addEventListener("change",function(){this.checked?(c(!0),Ba=!0):(c(!1),Ba=!1);localStorage.setItem("doExpedition",Ba);q()});mi.addEventListener("change",function(){this.checked?(g(!0),Fa=!0):(g(!1),Fa=!1);localStorage.setItem("doDungeon",Fa);q()});ni.addEventListener("change",function(){this.checked?(l(!0),Ga=!0):(l(!1),Ga=!1);localStorage.setItem("doArena",Ga);q()});document.getElementById("addAutoAttack").addEventListener("click",()=>{const z=document.getElementById("autoAttackInput").value.trim();
z&&bc(z,"autoAttackList","autoAttackList")});document.getElementById("addAvoidAttack").addEventListener("click",()=>{const z=document.getElementById("avoidAttackInput").value.trim();z&&bc(z,"avoidAttackList","avoidAttackList")});document.getElementById("addAutoCircusAttack").addEventListener("click",()=>{const z=document.getElementById("autoAttackCircusInput").value.trim();z&&bc(z,"autoAttackCircusList","autoAttackCircusList")});document.getElementById("addAvoidCircusAttack").addEventListener("click",
()=>{const z=document.getElementById("avoidAttackCircusInput").value.trim();z&&bc(z,"avoidAttackCircusList","avoidAttackCircusList")});ci();oi.addEventListener("change",function(){this.checked?(n(!0),Ca=!0):(n(!1),Ca=!1);localStorage.setItem("doCircus",Ca);q()});pi.addEventListener("change",function(){this.checked?(m(!0),La=!0):(m(!1),La=!1);localStorage.setItem("doQuests",La);q()});si.addEventListener("change",function(){this.checked?(fb=!0,localStorage.setItem("doKasa",!0),fb=!0):(fb=!1,localStorage.setItem("doKasa",
!1),fb=!1);localStorage.setItem("doKasa",fb);q()});ri.addEventListener("change",function(){this.checked?(Xa=!0,localStorage.setItem("AutoAuction",!0),Xa=!0):(Xa=!1,localStorage.setItem("AutoAuction",!1),Xa=!1);localStorage.setItem("AutoAuction",Xa);q()});qi.addEventListener("change",function(){this.checked?(u(!0),Da=!0):(u(!1),Da=!1);localStorage.setItem("doEventExpedition",Da);q()});lc.addEventListener("input",()=>{let z=parseInt(lc.value,10);1>z?z=1:99<z&&(z=99);lc.value=z;localStorage.setItem("healPercentage",
z)});Mf.addEventListener("input",()=>{localStorage.setItem("hellEnterHP",Mf.value)});Nf.addEventListener("input",()=>{localStorage.setItem("HellHealHP",Nf.value)});Wc.addEventListener("change",()=>{localStorage.setItem("HealClothToggle",Wc.checked)});Xc.addEventListener("change",()=>{localStorage.setItem("HealRubyToggle",Xc.checked)});Yc.addEventListener("change",()=>{localStorage.setItem("storeResource",Yc.checked)});Zc.addEventListener("change",()=>{localStorage.setItem("HighlightUnderworldItems",
Zc.checked)});const We=document.querySelectorAll(".stat-checkbox"),Ti=localStorage.getItem("selectedStat");for(const z of We)z.checked=z.id===Ti;for(const z of We)z.addEventListener("change",()=>{if(z.checked){for(const H of We)H!==z&&(H.checked=!1);localStorage.setItem("selectedStat",z.id);localStorage.setItem("statID",z.getAttribute("data-skill"))}else localStorage.removeItem("selectedStat")})});$("#set_event_monster_id_0").click(function(){x("0")});$("#set_event_monster_id_1").click(function(){x("1")});
$("#set_event_monster_id_2").click(function(){x("2")});$("#set_event_monster_id_3").click(function(){x("3")});q()}async function Ui(){if("true"===localStorage.getItem("storeResource")){var b=new URL(window.location.href),c=b.origin;b=b.searchParams.get("sh")||"";const e=Date.now();c=`${c}/game/ajax.php?mod=forge&submod=storageIn`;const g=new FormData;g.append("inventory","1");g.append("packages","1");g.append("sell","1");g.append("a",e);g.append("sh",b);b=JSON.parse(localStorage.getItem("Timers"));
X("storeForgeResources",b.StoreForge||60);try{(await fetch(c,{method:"POST",body:g})).ok?C(`${d.rf}`):window.location.reload()}catch(k){window.location.reload()}}}async function Vi(){var b=new URL(window.location.href),c=b.origin,e=b.searchParams.get("sh")||"";let g=JSON.parse(localStorage.getItem("statSettings"))||[];b=JSON.parse(localStorage.getItem("Timers"));const k=g.every(q=>1>parseInt(q.count,10));g.every(q=>"None"===q.priority);localStorage.getItem("selectedStat");const h={Strength:1,Dexterity:2,
Agility:3,Constitution:4,Charisma:5,Intelligence:6};g.sort((q,t)=>"None"===q.priority?1:"None"===t.priority?-1:parseInt(q.priority,10)-parseInt(t.priority,10));for(const {stat:q,count:t,priority:w}of g){if(1>t||"None"===w)continue;var l="true"===localStorage.getItem("trainPickGold");const y=h[q];var n=await (await fetch(`${c}/game/index.php?mod=training&sh=${e}`)).text();n=(new DOMParser).parseFromString(n,"text/html").querySelectorAll("#training_box .training_button");var m=void 0;0==n.length&&(X("Training",
b.Training||2),location.reload());for(var r of n)if(n=r.getAttribute("href").match(/skillToTrain=(\d+)/)[1],Number(n)===y&&(n=r.closest(".training_link").querySelector(".training_costs"))){m=parseInt(n.textContent.trim().replace(".",""),10);break}n=parseInt(localStorage.getItem("TrainingHoldGold"),10)||0;if(aa.gold>=m+n){fetch(`${c}/game/index.php?mod=training&submod=train&skillToTrain=${y}&sh=${e}`);for(var u of g)if(u.stat===q){--u.count;0>u.count&&(u.count=0);break}localStorage.setItem("statSettings",
JSON.stringify(g));C(`Trained ${q} for ${m} gold`);X("Training",b.Training||2);location.reload();return}if(l){l=await jQuery.get(G({mod:"packages",f:14,fq:-1,qry:"",page:1,sh:U("sh")}));let A=!1;jQuery(l).find(".packageItem").each(function(B,v){if(jQuery(v).find(".ui-draggable").attr("data-basis"))return A=!0,!1});if(A)try{await ec(1,1,async(B,v)=>{const D=selectedBuff.find('input[name="packages[]"]').val(),F=selectedBuff.find(".ui-draggable").attr("data-position-x"),I=selectedBuff.find(".ui-draggable").attr("data-position-y");
await jQuery.post(R({mod:"inventory",submod:"move",from:"-"+D,fromX:F,fromY:I,to:v,toX:B.x+1,toY:B.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:U("sh")}));C(`${d.Zj}`);window.location.reload()})}catch(B){C(`${d.Fp}`)}}}if(k){if(m=new URL(window.location.href),c=m.origin,m=m.searchParams.get("sh")||"",r=localStorage.getItem("selectedStat"),u=localStorage.getItem("statID"),r){e=await (await fetch(`${c}/game/index.php?mod=training&sh=${m}`)).text();e=(new DOMParser).parseFromString(e,"text/html").querySelectorAll("#training_box .training_button");
let q;for(var x of e)if(x.getAttribute("href").match(/skillToTrain=(\d+)/)[1]===u&&(e=x.closest(".training_link").querySelector(".training_costs"))){q=parseInt(e.textContent.trim().replace(".",""),10);break}x=parseInt(localStorage.getItem("TrainingHoldGold"),10)||0;aa.gold>=q+x&&(await fetch(`${c}/game/index.php?mod=training&submod=train&skillToTrain=${u}&sh=${m}`),C(`Trained ${r} for ${q} gold`),X("Training",b.Training||2),location.reload())}}else X("Training",b.Training||2),location.reload()}function Wi(){const b=
JSON.parse(localStorage.getItem("statSettings"));for(let c=0;c<b.length;c++)if("0"!==b[c].count||b[c].Hm)return!0;return!1}function Xi(){var b=new URL(window.location.href),c=localStorage.getItem("scoreboardattackenable"),e=localStorage.getItem("scoreboardcircusenable");if(document.querySelector(".reportWin")){var g=document.querySelector(".report_reward");g&&(g=g.querySelector('img[src*="71e68d38f81ee6f96a618f33c672e0.gif"]'))&&(g=g.previousSibling)&&g.nodeType===Node.TEXT_NODE&&(g=g.textContent.trim().match(/(\d+(?:\.\d+)?)/))&&
(g=parseFloat(g[1]),b.href.includes("&t=2")?N("arenaMoney",g):b.href.includes("&t=3")&&N("circusMoney",g))}if(b.href.includes("submod=showCombatReport")&&b.href.includes("&t=1"))(c=document.getElementById("reportHeader"))&&(c.classList.contains("reportWin")||"true"!==sessionStorage.getItem("autoGoActive")?localStorage.setItem("loose","false"):localStorage.setItem("loose","true"));else if(b.href.includes("submod=showCombatReport")){let l=document.querySelector("p > a + img");var k=document.querySelector("#defenderAvatar11 .playername_achievement");
null===k&&(k=document.querySelector("#defenderAvatar11 .playername.ellipsis "));(g=document.getElementById("reportHeader"))&&!g.classList.contains("reportWin")&&(localStorage.setItem("nextQuestTime.timeOut",0),localStorage.setItem("nextQuestTime",0));g=0;if(k&&(k=k.innerText.trim(),!k.includes("#"))){try{var h=l.previousSibling.nodeValue.trim();h=h.split(" ").pop();h=h.replace(".","");h=h.replace(",",".");g=parseFloat(h)}catch(n){}b.href.includes("&t=2")?(e=document.getElementById("reportHeader").classList.contains("reportWin"),
b=JSON.parse(localStorage.getItem("tempOpponentDetails")),h=xf.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidArena")||e||kb("avoidAttackList",k),"true"===localStorage.getItem("autoAddArena")&&Number(g)>=Number(localStorage.getItem("autoAddArenaAmount"))&&b&&b.serverId&&(h===b.serverId?(kb("autoAttackList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===c&&k!=b.playerName?kb("autoAttackList",k):h!==b.serverId&&kb("autoAttackServerList",b))):b.href.includes("&t=3")&&
(c=document.getElementById("reportHeader").classList.contains("reportWin"),b=JSON.parse(localStorage.getItem("tempOpponentDetails")),h=xf.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidCircus")||c||kb("avoidAttackCircusList",k),"true"===localStorage.getItem("autoAddCircus")&&g>=Number(localStorage.getItem("autoAddCircusAmount"))&&b&&b.serverId&&(h===b.serverId?(kb("autoAttackCircusList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===e&&k!=b.playerName?kb("autoAttackCircusList",
k):h!==b.serverId&&kb("autoAttackCircusServerList",b)))}}}function kb(b,c){let e=JSON.parse(localStorage.getItem(b))||[];if("object"===typeof c&&null!==c){let g=c.playerName;e.some(k=>k.playerName===g&&k.serverId===c.serverId)||e.push(c)}else"string"===typeof c&&(e.includes(c)||e.push(c));localStorage.setItem(b,JSON.stringify(e))}async function bh(b){var c=new URL(window.location.href),e=c.origin,g=c.searchParams;c=localStorage.getItem("AuctionItemLevel2")||"";const k=g.get("itemType")||"",h=localStorage.getItem("SearchQuality")||
"";g=g.get("sh")||"";e=new URL(`${e}/game/index.php?mod=auction&qry=&itemLevel=${c}&itemType=${k}&itemQuality=${h}&sh=${g}`);e.searchParams.set("mod","auction");e.searchParams.set("itemLevel",c);e.searchParams.set("itemType",k);e.searchParams.set("itemQuality",h);e.searchParams.set("sh",g);b&&e.searchParams.set("ttype",b);b=await (await fetch(e.href)).text();return(new DOMParser).parseFromString(b,"text/html")}async function Ff(){var b=new URL(window.location.href);const c=b.origin,e=b.searchParams.get("sh")||
"";b=Array.from({length:5},(k,h)=>[new URL(`${c}/game/index.php?mod=inventory&sub=${h+1}&subsub=0&sh=${e}`),new URL(`${c}/game/index.php?mod=inventory&sub=${h+1}&subsub=1&sh=${e}`)]).flat();const g=async k=>{var h=await (await fetch(k.href)).text();h=(new DOMParser).parseFromString(h,"text/html");h.sm=k.href;return h};return await Promise.all(b.map(k=>g(k)))}function Xe(b){return JSON.parse(b.replace(/&quot;/g,'"'))[0][0][0]}async function Yi(b){b=(new TextEncoder).encode(b.toString());b=await crypto.subtle.digest("SHA-256",
b);return Array.from(new Uint8Array(b)).map(c=>c.toString(16).padStart(2,"0")).join("")}function eb(){(function(b){const c=setInterval(()=>{const e=document.getElementById("mainmenu");e&&(clearInterval(c),b(e))},500)})(b=>{if(!document.querySelector(".customButtonm")){var c=document.createElement("button");c.className="customButtonm";c.innerHTML='\n            <style>\n            .customButtonm {\n                vertical-align: middle;\n                width: 179px;\n                height: 50px;\n                background-image: linear-gradient(135deg, #f29b20 0%, #b18026 100%);\n                border: 2px solid #000;\n                color: white;\n                text-align: center;\n                text-decoration: none;\n                border-radius: 5px;\n                display: inline-block;\n                font-size: 16px;\n                margin: 4px auto;\n                cursor: pointer;\n                box-shadow: 5px 2px 5px rgba(0, 0, 0, 0.3), inset 0 1px 1px rgba(255, 255, 255, 0.4), inset 0 -1px 1px rgba(0, 0, 0, 0.3);\n                padding: 18px 34px;\n                transition-duration: 0.4s;\n            }\n        \n            .customButtonm span {\n                top: 50%;\n                position: relative;\n                transform: translateY(-50%);\n                display: block;\n                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);\n            }\n            </style>\n\n            <span class="span-new">License expired or Server Error. Check Discord</span>\n\n        ';
b.insertBefore(c,b.children[0]);Bf(45E3)}});return!1}async function Zi(b,c,e){function g(k){const h=[];for(let l=0;l<k.length;l+=2)h.push(parseInt(k.substr(l,2),16));return new Uint8Array(h)}try{if(!e)return!1;const [k,h]=e.split(":"),l=g(k),n=g(h);if(b!==ua)return!1;const m=await window.crypto.subtle.importKey(String.fromCharCode(114,97,119),g("46d9ef519c1474cf8699ba24ab2a726a"),{name:String.fromCharCode(65,69,83)+"-CBC"},!1,[String.fromCharCode(100,101,99,114,121,112,116)]),r=await window.crypto.subtle.decrypt({name:String.fromCharCode(65,
69,83)+"-CBC",iv:l},m,n),u=(new TextDecoder).decode(new Uint8Array(r)),x=new Date(u);x.setHours(0,0,0,0);if(!0!==c)return!1;const q=new Date,t=new Date(q.setMonth(q.getMonth()+13));return x>t||u<q?!1:!0}catch{throw eb(),Error("supportDev");}}function tc(b){return 36E5*Number(b.split(":")[0])+6E4*Number(b.split(":")[1])+1E3*Number(b.split(":")[2])}function $i(){function b(g,k){rb?alert("A repair process is already running."):(e.Zm=k,jQuery(".gladbot-worbench-button").addClass("disabled"),e.u(),e.Ym=
[],e.queue=0,jQuery(document.body).addClass("workbench-cursor"),jQuery(document.body).on("contextmenu",function(h){h.preventDefault();jQuery(document.body).removeClass("workbench-cursor");jQuery(document.body).off("contextmenu")}),jQuery("#inv .ui-draggable, #char .ui-draggable").mouseup(h=>{h=h.target;var l=h.className.match(/item-i-(\d+)-\d+/)[1],n=document.querySelector(".charmercsel.active").getAttribute("onclick").toString().match(/doll=(\d+)/),m=e.freeSlots.shift()["forge_slots.slot"];n=n[1];
m={item:{type:l,name:Sb(h),quality:nb(h),slot:m,container:h.getAttribute("data-container-number"),doll:n},spot:{bag:h.getAttribute("data-container-number"),x:h.getAttribute("data-position-x"),y:h.getAttribute("data-position-y")}};localStorage.setItem("workbench_itemList1",JSON.stringify(m));if(jQuery(h).parents("#char").length)rb?alert("A repair process is already running."):(e.cn(h),e.rm(h,0,n),rb=!0);else if(jQuery(h).parents("#inv").length){if(l=document.querySelector("#inventory_nav .awesome-tabs.current"))l=
l.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",l);e.tm={bag:h.getAttribute("data-container-number"),x:h.getAttribute("data-position-x"),y:h.getAttribute("data-position-y")};rb?alert("A repair process is already running."):(e.cn(h),h=h.getAttribute("data-item-id"),e.$i(h),rb=!0)}else e.queue++,e.io(h),e.xm(l)}))}function c(g,k,h){k=jQuery("<button>").html(k).addClass(h);jQuery(g).append(k);return k}const e={Zm:"full",async start(){let {itemList1:g,itemList2:k,repairArena:h,
repairTurma:l}=sa,n=sa.selectedItem;n?this.u(()=>{switch(n.status){case "toWorkbench":e.$i(n.iid);break;case "toFillGoods":e.Xb(n.slot);break;case "toPackage":e.bj(n.slot);break;case "toBag":e.aj();break;case "toInv":e.Jl()}}):h&&0<g.length?"mod=overview&doll=1"!=lf?Cf("mod=overview&doll=1"):this.u(()=>{0<e.spaces&&this.Vl(sa.itemList1)}):l&&0<k.length&&("mod=overview&doll=2"!=lf?Cf("mod=overview&doll=2"):this.u(()=>{0<e.spaces&&this.Vl(sa.itemList2)}))},u(g=!1){jQuery.post(R({}),{mod:"forge",submod:"getWorkbenchPreview",
mode:"workbench",a:(new Date).getTime(),sh:U("sh")},k=>{e.slots=JSON.parse(k).slots;e.spaces=0;e.freeSlots=[];for(let h of e.slots)"closed"==h["forge_slots.state"]&&(e.spaces++,e.freeSlots.push(h));g&&g()})},Vl(g){let k=g.shift();ec(k.Rm,k.Sm,(h,l)=>{jQuery.post(R({mod:"inventory",submod:"move",from:k.container,fromX:1,fromY:1,to:l,toX:h.x+1,toY:h.y+1,amount:1,doll:k.doll}),{a:(new Date).getTime(),sh:U("sh")},n=>{let m={item:k,iid:JSON.parse(n).to.data.itemId,status:"toWorkbench",spot:h,bag:l};localStorage.setItem("workbench_selectedItem",
JSON.stringify(m));this.$i(JSON.parse(n).to.data.itemId)})})},async rm(g,k=0,h){var l=[512,513,514,515];if(!(k>=l.length)){l=l[k];var n=document.getElementById("inv");if(n=jf(n))try{const r=await jQuery.post(R({mod:"inventory",submod:"move",from:g.getAttribute("data-container-number"),fromX:1,fromY:1,to:l,toX:n.x+1,toY:n.y+1,amount:1,doll:h}),{a:(new Date).getTime(),sh:U("sh")}),u=JSON.parse(r);if(u.error)this.rm(g,k+1,h);else{var m={item:g,iid:u.to.data.itemId,status:"toWorkbench",spot:n,bag:l};
localStorage.setItem("workbench_selectedItem",JSON.stringify(m));localStorage.setItem("workbench_itemBag",JSON.stringify(m.bag));this.$i(u.to.data.itemId)}}catch(r){}else this.rm(g,k+1)}},async $i(g){aj();C(`${d.qb}`);let k=5;for(let h of e.slots)"closed"==h["forge_slots.state"]&&(k=h["forge_slots.slot"]);jQuery.post(R({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:k,iid:g,amount:1,a:(new Date).getTime(),sh:U("sh")},h=>{e.needed=JSON.parse(h).slots[k].formula.needed;zh().gold>
JSON.parse(h).slots[k].formula.rent[2]&&jQuery.post(R({}),{mod:"forge",submod:"rent",mode:"workbench",slot:k,rent:2,item:g,a:(new Date).getTime(),sh:U("sh")},()=>{"full"==e.Zm?(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:k,status:"toFillGoods"})),e.Xb(k)):(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:k,status:"toFillPartial"})),e.Ni(k))})})},Xb(g,k=-1,h=!0){C(`${d.Df}`,k);jQuery.post(R({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:g,
quality:k,a:(new Date).getTime(),sh:U("sh")},()=>{k<Number(localStorage.getItem("repairMaxQuality"))?e.Xb(g,++k,h):jQuery.post(R({}),{mod:"forge",submod:"start",mode:"workbench",slot:g,a:(new Date).getTime(),sh:U("sh")},()=>{h?(localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"})),e.u(()=>{e.bj(g)})):(e.queue--,0==e.queue&&window.location.reload())})})},bj(g){let k=1E3*e.slots[g].formula.duration||1E4;C(`${d.Qf}`,k);this.u(()=>{setTimeout(()=>{jQuery.post(R({}),{mod:"forge",
submod:"lootbox",mode:"workbench",slot:g,a:(new Date).getTime(),sh:U("sh")},h=>{if("document.location.href=document.location.href;"==h)return window.location.reload();localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));e.aj()})},k)})},async aj(g=1){var k=JSON.parse(localStorage.getItem("workbench_itemList1"));let h=localStorage.getItem("workbench_itemBag"),{item:l,spot:n}=k;k=!1;var m=new URL(window.location.href),r=m.origin;m=m.searchParams.get("sh")||"";r=new URL(`${r}/game/index.php?mod=packages&qry=&f=${l.type}&page=${g}&sh=${m}`);
r.searchParams.set("mod","packages");r.searchParams.set("f",l.type);r.searchParams.set("page",g);r.searchParams.set("sh",m);r=await (await fetch(r.href)).text();r=(new DOMParser).parseFromString(r,"text/html");var u=r.querySelector(".ui-draggable");m=Db(u).split("-")[0];nb(u);u=Sb(u);l.name==u&&l.type==m&&(k=!0,jQuery.post(R({mod:"inventory",submod:"move",from:r.querySelector("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:h,toX:n.x,toY:n.y,amount:1}),{a:(new Date).getTime(),
sh:U("sh")},()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));e.Jl()}));k||this.aj(++g)},Jl(){JSON.parse(localStorage.getItem("workbench_selectedItem"));let g=JSON.parse(localStorage.getItem("workbench_itemList1"));const k=localStorage.getItem("workbench_itemBag");let {item:h,spot:l}=g;jQuery.post(R({mod:"inventory",submod:"move",from:k,fromX:l.x,fromY:l.y,to:h.container,toX:1,toY:1,amount:1,doll:h.doll}),{a:(new Date).getTime(),sh:U("sh")},()=>{localStorage.setItem("workbench_selectedItem",
JSON.stringify({status:"toInv"}));C(`${d.Gf}`);rb=!1;window.location.reload()})},Vm(g){g=jQuery(g);g=jQuery("<div>").addClass("gbot-overlay").width(g.width()).height(g.height()).offset(g.offset()).append(jQuery('<div class="gbot-spinner"></div>'));jQuery(document.body).append(g)},am(g,k,h){k=jQuery("<button>").html(k).addClass(h);jQuery(g).append(k);return k},Ap(){let g=0;for(let k of e.slots)"finished-succeeded"==k["forge_slots.state"]&&(g++,jQuery.post(R({}),{mod:"forge",submod:"lootbox",mode:"workbench",
slot:k["forge_slots.slot"],a:(new Date).getTime(),sh:U("sh")},h=>{g--;if("document.location.href=document.location.href;"==h||0==g)return window.location.reload()}))},io(g){Ub(g)&&(e.Vm(g),e.Ym.push(g))},cn(g){Ub(g)&&e.Vm(g)},xm(g,k,h){let l=e.freeSlots.shift()["forge_slots.slot"],n=e.Ym.shift(),m=null!==k?k:n.getAttribute("data-item-id"),r=null!==h?h:{bag:n.getAttribute("data-container-number"),x:n.getAttribute("data-position-x"),y:n.getAttribute("data-position-y")};jQuery.post(R({}),{mod:"forge",
submod:"getWorkbenchPreview",mode:"workbench",slot:l,iid:m,amount:1,a:(new Date).getTime(),sh:U("sh")},u=>{let x=JSON.parse(u).slots[l].formula.needed;zh().gold>JSON.parse(u).slots[l].formula.rent[2]&&jQuery.post(R({}),{mod:"forge",submod:"rent",mode:"workbench",slot:l,rent:2,item:m,a:(new Date).getTime(),sh:U("sh")},()=>{"full"==g?e.Xb(l,r,!0):"partial"==g&&e.Ni(l,r,x)})})},Ni(g,k,h){let l=[];h=e.needed;for(let n in h)0<h[n].amount&&l.push(n-18E3);e.kl(l,(n,m)=>{e.ll(k,n,m,r=>{jQuery.post(R({}),
{mod:"forge",submod:"toWarehouse",mode:"workbench",slot:g,iid:r,amount:1,a:(new Date).getTime(),sh:U("sh")},()=>{jQuery.post(R({}),{mod:"forge",submod:"start",mode:"workbench",slot:g,a:(new Date).getTime(),sh:U("sh")},()=>{e.queue--;localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"}));e.u(()=>{e.bj(g)});0==e.queue&&window.location.reload()})})})})},kl(g,k=!1,h=0,l=-1){if(h==g.length)if(1>l)h=0,l++;else return;jQuery.post(R({mod:"forge",submod:"storageOut"}),{type:g[h],
quality:l,amount:1,a:(new Date).getTime(),sh:U("sh")}).done(()=>k&&k(g[h],l)).fail(()=>e.kl(g,k,++h,l))},ll(g,k,h,l=!1,n=1){let m=!1;jQuery.get(G({mod:"packages",f:18,fq:h,qry:"",page:1,sh:U("sh")}),r=>{jQuery(r).find(".packageItem").each((u,x)=>{var q=jQuery(x).find(".ui-draggable");u=q.context.querySelector("input").getAttribute("value");x=Db(q[0]).split("-")[1];q=nb(q[0]);k==x&&h==q&&(m=!0,jQuery.post(R({mod:"inventory",submod:"move",from:"-"+u,fromX:1,fromY:1,to:e.tm.bag,toX:e.tm.x,toY:e.tm.y,
amount:1}),{a:(new Date).getTime(),sh:U("sh")},t=>{l&&l(JSON.parse(t).to.data.itemId)}))});m||e.ll(g,k,h,l,++n)})}};jQuery("#inv").after('\n              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n    \n                <fieldset id="gladbot-workbench" style="\n                  padding: 10px;\n                  margin: 10px 20px;\n                  text-align: center;\n                  display: flex;\n                  flex-direction: row;\n                  flex-wrap: wrap;\n                  align-items: center;\n                  justify-content: space-around;\n                  border: 2px solid darkred;\n                  border-radius: 8px;\n                  width: 235px;">\n                  <legend style="\n                    padding: 0 10px;\n                    color: darkred;\n                    font-weight: bold;">GLDbot Workbench Area</legend>\n                    <span class="span-new">Make sure last workbench slot is available, and make sure there\'s 3x3 space available. Repair only works for the equipments on the character. If you dont see the inventory, install Crazy-Addon.</span>\n                </fieldset>');
c("#gladbot-workbench",'<i class="fa fa-wrench"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for full repair. You can only repair one item at a time.").mouseup(g=>{b(g,"full")});c("#gladbot-workbench",'<i class="fa fa-hammer"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for partial repair. You can only repair one item at a time.").mouseup(g=>{b(g,"partial")});c("#gladbot-workbench",'<i class="fa fa-undo"></i>',
"gladbot-button gladbot-worbench-button-reset gladbot-stylish-button").attr("title","If an item is stuck and not repairing, click this button to reset.").mouseup(()=>{rb=!1})}function uc(b){const c=document.createElement("div");c.className="notification-popup";c.innerText=b;c.style.position="fixed";c.style.bottom="20px";c.style.right="20px";c.style.padding="10px 20px";c.style.backgroundColor="rgba(0, 0, 0, 0.8)";c.style.color="white";c.style.borderRadius="5px";c.style.fontSize="14px";c.style.zIndex=
"9999";document.body.appendChild(c);setTimeout(()=>{c.remove()},3E3)}function ch(b,c,e,g,k,h){const l=document.createElement("span");l.className=c;l.innerHTML=b;l.title=h;l.style.cursor=e;l.style.fontSize=g;l.style.top="70px";l.style.position="absolute";l.style.right=k;return l}function dh(b,c){try{var e=JSON.parse(b.replace(/&quot;/g,'"'))}catch(l){return{}}b=e[0]?e[0][0]:null;e=b[0];e="string"!==typeof e?"":e.split(" ")[0];const g=Wb(b[0]),k=c.getAttribute("data-quality"),h=c.getAttribute("data-content-type");
c=c.getAttribute("data-level");return{itemName:b,Om:e,Pm:g,itemColor:{"-1":"white",0:"green",1:"blue",2:"purple",3:"orange",4:"red"}[k]||"white",itemType:h,itemLevel:c}}function bj(b,c,e,g){let k=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],h=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];k.includes(b)||(k.push(b),localStorage.setItem("auctionPrefixes",JSON.stringify(k)));h.includes(c)||(h.push(c),localStorage.setItem("auctionSuffixes",JSON.stringify(h)));uc(`Item "${e[0]}" added to the auction list!`);
g.innerHTML="\u2705";setTimeout(()=>{g.innerHTML="\ud83d\udd28"},1E3)}function cj(b,c,e,g,k,h,l){c={condition:"nameContains",prefix:c,suffix:e,colors:[g],itemTypes:[k],hammerState:"none",level:h||1,enabled:!0};e=JSON.parse(localStorage.getItem("smeltingSettings"))||[];e.push(c);localStorage.setItem("smeltingSettings",JSON.stringify(e));uc(`Item "${b[0]}" added to the smelting list!`);l.innerHTML="\u2705";setTimeout(()=>{l.innerHTML="\ud83d\udd25"},1E3)}async function aj(){const b=G({mod:"packages",
submod:"sort",page:"1",sh:U("sh")});return await jQuery.post(b,{packageSorting:"in_desc"})}async function dj(){var b=localStorage.getItem("PackageSort")||"in_desc",c=await ha.Sl();let e=[];var g=Math.min(10,c);if("del_asc"===b||"in_asc"===b)for(c=1;c<=g;c++)e.push(c);else for(b=c;b>c-g;b--)e.push(b);g=[];for(const k of e)try{const h=await jQuery.get(G({mod:"packages",f:"0",fq:"-1",qry:"",page:k.toString(),sh:U("sh")}));g.push(h)}catch(h){C(`Error fetching pages ${k}: ${h.message}`)}return g.flat()}
async function ej(b,c){if("mod=guildMarket"!=lf)Cf("mod=guildMarket");else{C(`${d.hf}`);var e={TOOLS:["2097152","1048576","8388608","4194304"],WEAPONS:["2"],SHIELD:["4"],CHEST:["8"],HELMET:["1"],GLOVES:["256"],SHOES:["512"],RINGS:["48"],AMULETS:["1024"],USABLES:["4096"],FOOD:["64"],UPGRADES:["4096"],RECIPES:["8192"],MERCENARY:["16384"],SCROLLS:["64"],REINFORCEMENTS:["4096"]},g=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]},k=(await dj()).map(x=>jQuery(x).find(".packageItem").toArray()).flat();
b=24*b;var h=!1;for(const x of k){k=x.querySelector("span[data-ticker-type]");if(!k)continue;k=k.getAttribute("data-ticker-time-left");if(!k)continue;k=k/1E3/60/60;var l=x.querySelector("div[data-content-type]");const q=l?l.getAttribute("data-content-type"):null;l=(l=x.querySelector(".ui-draggable"))?l.getAttribute("data-basis"):null;if(("64"!==q||!l||c.includes("SCROLLS")&&l.startsWith("20")||c.includes("FOOD")&&l.startsWith("7")||c.includes("REINFORCEMENTS")&&l.startsWith("11"))&&k<=b&&c.some(t=>
e[t].includes(q))){l=x.querySelector("div[data-container-number]");var n=x.querySelector("div[data-amount]");k=n?n.getAttribute("data-amount"):null;n=n?n.getAttribute("data-quality"):null;if(!(null!==n&&0<g.colors.length)||g.colors.includes(n)){l=l?l.getAttribute("data-container-number"):null;n=x.querySelector("div[data-measurement-x]").getAttribute("data-measurement-x");var m=x.querySelector("div[data-measurement-y]").getAttribute("data-measurement-y");h=x.querySelector("div[data-tooltip]").getAttribute("data-tooltip");
var r=Xe(h);h=!0;await fj(x,l,r,k,n,m);k=U("sh");k=`${window.location.origin}/game/index.php?mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=p&p=1&&sh=${k}`;l=await (await fetch(k)).text();l=(new DOMParser).parseFromString(l,"text/html").querySelectorAll("#market_table tr");if((n=document.querySelector('input[type="submit"][name="anbieten"][value="Offer"]'))&&n.disabled)k=JSON.parse(localStorage.getItem("Timers")),X("resetExpired",k.ResetExpired||10),C(`${d.sf}`);else for(n=1;n<l.length;n++){var u=
l[n];m=u.querySelectorAll("td")[2];r=u.querySelector('input[name="cancel"]');u=(u=u.querySelector("div[data-item-id]"))?u.getAttribute("data-item-id"):null;r&&Number(m.textContent.replace(/\./g,""))===Number(eh)&&(await fetch(k,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({buyid:u,qry:"",seller:"",f:0,fl:0,fq:-1,s:"",p:1,cancel:"Cancel"})}),C(`${d.jf}`),N("itemReset",0))}}}}if(!h||h)c=JSON.parse(localStorage.getItem("Timers")),X("resetExpired",
c.ResetExpired||10),window.location.reload()}}async function fj(b,c,e,g,k,h){let {spot:l,bag:n}=await ec(k,h);try{const m=await jQuery.post(R({mod:"inventory",submod:"move",from:c,fromX:1,fromY:1,to:n,toX:l.x+1,toY:l.y+1,amount:g}),{a:(new Date).getTime(),sh:U("sh")});if(m){const r=Math.floor(41*Math.random())+10;eh=r;const u=JSON.parse(m).to.data.itemId;await gj(c,r,u)}}catch(m){C(`${d.kf}`),b=JSON.parse(localStorage.getItem("Timers")),X("resetExpired",b.ResetExpired||10),window.location.reload()}}
async function gj(b,c,e){await jQuery.post(G({mod:"guildMarket",sh:U("sh")}),{sellid:e,preis:c,dauer:1,sell_mode:0,anbieten:"Offer"})}async function hj(){if(!1!==JSON.parse(localStorage.getItem("underworld")||"{}").isUnderworld||"true"!==localStorage.getItem("BuffUnderworldOnly")){"mod=overview&doll=1"!=lf&&Cf("mod=overview&doll=1");var b={"11-23":{type:"Health",item:"Gingko"},"11-22":{type:"Health",item:"Taigaroot"},"11-21":{type:"Health",item:"Hawthorn"},"11-1":{type:"Strength",item:"Flask"},"11-2":{type:"Strength",
item:"Ampulla"},"11-3":{type:"Strength",item:"Flacon"},"11-4":{type:"Strength",item:"Bottle"},"11-13":{type:"Constitution",item:"Flask"},"11-14":{type:"Constitution",item:"Ampulla"},"11-15":{type:"Constitution",item:"Flacon"},"11-16":{type:"Constitution",item:"Bottle"},"11-9":{type:"Agility",item:"Flask"},"11-10":{type:"Agility",item:"Ampulla"},"11-11":{type:"Agility",item:"Flacon"},"11-12":{type:"Agility",item:"Bottle"},"11-17":{type:"Charisma",item:"Flask"},"11-18":{type:"Charisma",item:"Ampulla"},
"11-19":{type:"Charisma",item:"Flacon"},"11-20":{type:"Charisma",item:"Bottle"},"11-24":{type:"Intelligence",item:"Flask"},"11-25":{type:"Intelligence",item:"Ampulla"},"11-26":{type:"Intelligence",item:"Flacon"},"11-27":{type:"Intelligence",item:"Bottle"},"11-5":{type:"Dexterity",item:"Flask"},"11-6":{type:"Dexterity",item:"Ampulla"},"11-7":{type:"Dexterity",item:"Flacon"},"11-8":{type:"Dexterity",item:"Bottle"}},c=JSON.parse(localStorage.getItem("buffs"))||{},e=JSON.parse(localStorage.getItem("Timers")),
g=JSON.parse(localStorage.getItem("buffSelections"))||{};for(const h in g){var k=g[h];let l=null;if(0<k.length)for(let n of k)if(Object.entries(b).find(([,m])=>m.type===h&&m.item===n)&&!Object.keys(c).find(m=>m.includes(h)&&m.includes(n)&&0<c[m].timeLeft))try{let m=!1,r=null;for(k=1;3>=k;k++){const u=await jQuery.get(G({mod:"packages",f:11,fq:-1,qry:"",page:k,sh:U("sh")}));jQuery(u).find(".packageItem").each(function(x,q){x=jQuery(q).find(".ui-draggable").attr("data-basis");if((x=b[x])&&x.type===
h&&x.item===n){const t=x.item;l=t;if(Object.keys(c).some(w=>w.includes(h)&&w.includes(t)))return!0;m=!0;r=jQuery(q);return!1}});if(m)break}if(m&&r)try{await ec(1,1,async(u,x)=>{const q=r.find('input[name="packages[]"]').val(),t=r.find(".ui-draggable").attr("data-position-x"),w=r.find(".ui-draggable").attr("data-position-y");await new Promise(y=>setTimeout(y,250));await jQuery.post(R({mod:"inventory",submod:"move",from:"-"+q,fromX:t,fromY:w,to:x,toX:u.x+1,toY:u.y+1,amount:1,doll:1,a:(new Date).getTime(),
sh:U("sh")}));C(`${h} buff (${n}) has been moved to the inventory.`);await new Promise(y=>setTimeout(y,250));await jQuery.post(R({mod:"inventory",submod:"move",from:x,fromX:u.x+1,fromY:u.y+1,to:8,toX:1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:U("sh")}));c[`${h} - ${l}`]={timeLeft:r.find(".ticker").attr("data-ticker-time-left")/6E4};localStorage.setItem("buffs",JSON.stringify(c))})}catch(u){X("BuffCheck",e.BuffTimer||60),C(`Error moving or using ${h} buff (${n}):`,u)}else X("BuffCheck",e.BuffTimer||
60),C(`No ${h} buff found for ${n}.`)}catch(m){X("BuffCheck",e.BuffTimer||60),C("Error fetching buffs from packages:",m)}}}}function ij(){const b=Date.now(),c=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),e=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),k=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}");Object.entries(e).forEach(([h,l])=>{3E5<b-l&&(c[h]=!0,delete e[h])});Object.entries(k).forEach(([h,
l])=>{3E5<b-l&&(g[h]=!0,delete k[h])});localStorage.setItem("activeItemsGladiator",JSON.stringify(c));localStorage.setItem("disabledTimeGladiator",JSON.stringify(e));localStorage.setItem("activeItemsMercenary",JSON.stringify(g));localStorage.setItem("disabledTimeMercenary",JSON.stringify(k))}function Ye(){const b=localStorage.getItem("healPercentage")||25;var c=(new Date).getTime();let e=!1;const z4 = localStorage.getItem("we");we = new Date(z4);if(fa<new Date||we<new Date)throw eb(),Error("SupportDevs");const g=[];if(!0===Ba&&da==ua){var k=tc(document.getElementById("cooldown_bar_text_expedition").innerText);
g.push({name:"expedition",time:k,index:0})}!0===Fa&&da==ua&&(k=tc(document.getElementById("cooldown_bar_text_dungeon").innerText),g.push({name:"dungeon",time:k,index:1}));!0===Ga&&(k=tc(document.getElementById("cooldown_bar_text_arena").innerText),g.push({name:"arena",time:k,index:2}));!0===Ca&&(k=tc(document.getElementById("cooldown_bar_text_ct").innerText),g.push({name:"circusTurma",time:k,index:3}));!0===Da&&(c=localStorage.getItem("eventPoints.timeOut")-c,g.push({name:"eventExpedition",time:c,
index:4}));"true"===sessionStorage.getItem("autoGoActive")&&!1===Ca&&!1===Ga&&!1===Ba&&!1===Fa&&"true"===localStorage.getItem("activateAuction2")&&Bf(2E4);const h=function(q){let t=0;for(;t<q.length&&!q[t];)t++;if(t===q.length)return null;let w=q[t].time;for(let y=t+1;y<q.length;y++)q[y]&&q[y].time<w&&(w=q[y].time,t=y);return q[t]}(g);function l(q){if(1E3>q)return"0:00:00";q=Math.round(q/1E3);let t=q%60;10>t&&(t="0"+t);q=(q-t)/60;let w=q%60;10>w&&(w="0"+w);return(q-w)/60+":"+w+":"+t}let n=document.getElementById("nextActionWindow");
const m=(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld;n||(n=document.createElement("div"),n.setAttribute("id","nextActionWindow"),n.setAttribute("style","\n                display: block;\n                align-items: center;\n                justify-content: center;\n                position: absolute;\n                top: -3px;\n                left: 50%;\n                transform: translateX(-50%);\n                height: 50px;\n                width: 190px;\n                color: black;\n                background: rgba(196, 172, 112, 0.9);\n                box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1); /* Softer shadow for a more subtle effect */\n                border-radius: 10px;\n                font-size: 16px;\n                font-family: 'Open Sans', sans-serif;\n                letter-spacing: 0.5px;\n                border: 1px solid black;\n                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); /* Smoother transition effect */\n                z-index: 1999;\n                \n                  "),
h&&h.time&&!String(h.time).includes("NaN")?n.innerHTML=`
                              <span class="span-new" style="color: black;">${d.Tc}: </span>
                              <span class="span-new">${d[h.name]}</span></br>
                              <span class="span-new" style="color: black;">${d.tc}: </span>
                              <span class="span-new">${l(h.time)}</span>`:n.innerHTML='\n                              <span class="span-new">Please select an action. [Exp|Dungeon|Arena|Circus]</span></br>',document.getElementById("header_game").insertBefore(n,document.getElementById("header_game").children[0]));function r(q){if(!0===m){if(!0===(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld)switch(q){case "expedition":return"cooldown_bar_expedition";case "circusTurma":if(Ca)return"cooldown_bar_ct";
default:return null}}else switch(q){case "expedition":if(Ba)return"cooldown_bar_expedition";break;case "dungeon":if(Fa)return"cooldown_bar_dungeon";break;case "arena":if(Ga)return"cooldown_bar_arena";break;case "circusTurma":if(Ca)return"cooldown_bar_ct";break;case "eventExpedition":if(Da)return null;break;default:return null}}function u(q){if("eventExpedition"!==q){if("circusTurma"===q&&(q="ct"),(q=document.getElementById("cooldown_bar_"+q))&&"none"!==q.style.display)return!q.querySelector(".cooldown_bar_text").classList.contains("ticker")}else if(Da)return Array.from(document.getElementsByClassName("cooldown_bar_link")).some(t=>
(t=t.closest(".cooldown_bar"))&&"none"!==t.style.display?!t.querySelector(".cooldown_bar_text").classList.contains("ticker"):!1);return!1}function x(q){try{if("eventExpedition"===q&&W("eventPoints")&&1==Da&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(b):1))try{const t=document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0];return t?(t.click(),e=!0):!1}catch(t){return C("Error performing eventExpedition action: "+t),!1}else{const t=r(q);if(t){const w=document.getElementById(t);
if(w){const y=w.querySelector(".cooldown_bar_link");if(m&&u(q)&&!Ba)return!1;if(y&&u(q))return y.click(),!0}}}}catch(t){return window.location.reload(),!1}}if("true"===sessionStorage.getItem("autoGoActive")){const q=["expedition","dungeon","arena","circusTurma","eventExpedition"];let t=0;function w(){let B=Date.now();if(400>B-t)requestAnimationFrame(w);else{for(const v of q)if(u(v)&&(e=x(v))){t=B;return}e||requestAnimationFrame(w)}}w();setInterval(()=>{if(h){h.time-=1E3;if(h&&(y!==h.name||A!==h.time)){var B=
!h||isNaN(h.time)||String(h.time).includes("NaN")?`<span class="span-new">${d.fa}</span></br>`:`
                            <span class="span-new" style="color: black;">${d.Tc}: </span>
                            <span class="span-new">${d[h.name]}</span></br>
                            <span class="span-new" style="color: black;">${d.tc}: </span>
                            <span class="span-new">${l(h.time)}</span>`;n.innerHTML=B;y=h.name;A=h.time;pa&&!0===La&&J()&&"mod=quests"!=lf&&Cf("mod=quests")}(0>=h.time||u(h.name))&&x(h.name)}},1E3);let y=null,A=-1}}(function(){if("true"===localStorage.getItem("disableBG")){var b=document.getElementById("wrapper_game");b&&(b.style.backgroundImage="none",b.style.backgroundColor="black")}let c=setTimeout(()=>{chrome.runtime.sendMessage({sp:!0})},1E4);window.onload=function(){clearTimeout(c);chrome.runtime.sendMessage({tp:!0})};
let e=!1;document.addEventListener("touchstart",function(g){function k(l){setTimeout(function(){var n=new MouseEvent("click",{bubbles:!0,cancelable:!0,view:window});l.dispatchEvent(n)},150)}var h=g.target;try{if("AuctionaddPrefixButton"==h.id||"AuctionaddSuffixButton"==h.id||"Strength"==h.htmlFor||"Dexterity"==h.htmlFor||"Agility"==h.htmlFor||"Constitution"==h.htmlFor||"Charisma"==h.htmlFor||"Intelligence"==h.htmlFor||"costumes_button_left"===h.offsetParent.id||"costumes_button_right"===h.offsetParent.id||
"buy_rubies_link"===h.offsetParent.id||"footer_inner"===h.offsetParent.id||"footer_logos"===h.offsetParent.id||"content"===h.id||"sidebar"===h.id||"char"===h.id||"a.menuitem.advanced_menu_link"==h.className||"a.menuitem.advanced_menu_link active"==h.className||"a.menuitem.advanced_menu_link active"==h.className||"menuitem"==h.className||"menuitem "==h.className||"menuitem advanced_menu_link"==h.className||"menuitem active advanced_menu_link_active"==h.className||"set_dungeon_difficulty_normal"!=h.id&&
"set_dungeon_difficulty_advanced"!=h.id&&"set_event_monster_id_0"!=h.id&&"set_event_monster_id_1"!=h.id&&"set_event_monster_id_2"!=h.id&&"set_event_monster_id_3"!=h.id&&"do_combat_quests"!=h.id&&"do_arena_quests"!=h.id&&"do_circus_quests"!=h.id&&"do_expedition_quests"!=h.id&&"do_dungeon_quests"!=h.id&&"do_items_quests"!=h.id&&"ConstitutionPriority"!=h.id&&"CharismaPriority"!=h.id&&"IntelligencePriority"!=h.id&&"StrengthPriority"!=h.id&&"DexterityPriority"!=h.id&&"AgilityPriority"!=h.id&&"shoes-image"!=
h.className&&"ring1-image"!=h.className&&"ring2-image"!=h.className&&"helmet-image"!=h.className&&"necklace-image"!=h.className&&"sword-image"!=h.className&&"chest-image"!=h.className&&"shield-image"!=h.className&&"gloves-image"!=h.className&&("div"==h.localName&&"overlayBack"!==h.id||"div"==h.localName&&"licotok"!==h.id))return}catch{}e||"checkbox"===h.type&&"switch"===h.className||(e=!0,k(h),"submit"!==h.type&&"checkbox"!==h.type&&"switch"!==h.className||g.preventDefault());e=!1},{passive:!1});
try{chrome&&chrome.runtime&&chrome.runtime.sendMessage&&"true"===sessionStorage.getItem("autoGoActive")&&(chrome.runtime.sendMessage({Wm:!0,cm:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"}),chrome.runtime.sendMessage({keepAlive:!0},()=>{}));let g=localStorage.getItem("activeItemsMercenary"),k=localStorage.getItem("activeItemsGladiator");null!==g&&g!==JSON.stringify([])||localStorage.setItem("activeItemsMercenary",JSON.stringify({}));null!==k&&k!==JSON.stringify([])||localStorage.setItem("activeItemsGladiator",
JSON.stringify({}));chrome.runtime.onMessage.addListener(h=>{h.Wm&&h.cm&&"true"===sessionStorage.getItem("autoGoActive")&&(h=new Audio(h.cm),h.loop=!0,h.volume=0,h.play().catch(()=>{}))})}catch{console.log("Could not play the audio")}(b=JSON.parse(localStorage.getItem("timeConditions"))||[],1>b.length)?setTimeout(function(){window.location.reload()},36E4):setTimeout(function(){window.location.reload()},18E4)})();const jj={start(){function b(){try{sessionStorage.setItem("gbAutoLoginInProgress","true"),
chrome.runtime.sendMessage({queryButtonClickedState:!0},k=>{if(!k.state){if(window.location.href.includes("/accounts")&&(k=document.querySelector("#serverlist-header #backbutton")))return k.click(),setTimeout(b,500);if(document.querySelector("#joinGame .button-default")&&document.getElementById("joinGame")&&(k=document.querySelectorAll("#joinGame button"))&&"false"!==localStorage.getItem("autologin")){chrome.runtime.sendMessage({sn:!0});let h=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0});
k[1]?.dispatchEvent(h);chrome.runtime.sendMessage({sn:!0})}}})}catch{}}function c(){var k=document.cookie.split("; ").find(h=>h.startsWith("glautologin="));k=k?k.split("=")[1]:null;window.location.href.includes("forum.gladiatus")||"true"!=k||sessionStorage.getItem("gbAutoLoginInProgress")||setTimeout(b,3E3)}window.location.href.includes("game/index.php")||c();var e=document.querySelectorAll('h1, h2, .error-code, h1[jstcache="0"], #main-frame-error');let g=!1;for(const k of e){e=k.textContent||"";
if(e.includes("503")||e.includes("500")){g=!0;break}if("main-frame-error"===k.id||k.hasAttribute("jstcache")){g=!0;break}}g&&setTimeout(()=>{location.reload()},3E3)}};window.location.href.includes("index.php?mod=overview&submod=achievements")||window.location.href.includes("index.php?mod=overview&submod=stats")||jj.start();const fh=localStorage.getItem("underworld"),yb=fh?JSON.parse(fh):null,gh=document.querySelector('input[name="cancelTravel"]');try{document.querySelector("#header_LoginBonus")&&
!gh&&yb&&!window.location.href.includes("/index.php?mod=hermit")&&!1===yb.isUnderworld&&document.querySelector("#linkLoginBonus").click()}catch{}let hh=document.getElementById("wrapper_game");if(hh&&"underworld"===hh.className){const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else{const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!1;localStorage.setItem("underworld",JSON.stringify(b))}try{if((window.location.href.includes("/index.php?mod=hermit&submod=travel")||
gh||window.location.href.includes("/index.php?mod=hermit&submod=enterUnderworld"))&&"true"===sessionStorage.getItem("autoGoActive")&&"true"===localStorage.getItem("autoEnterHell")){const b=document.querySelector('span[data-ticker-type="countdown"]');if(b){const c=parseInt(b.getAttribute("data-ticker-time-left"),10);await new Promise(e=>setTimeout(e,c+5E4||33E4))}else await new Promise(c=>setTimeout(c,45E3))}}catch(b){C(`Error in underworld wait: ${b.message}`)}(function(){var b=document.querySelector('span[data-ticker-type="countdown"]');
if(window.location.href.includes("/index.php?mod=reports")&&!b||window.location.href.includes("/index.php?mod=guildMarket")&&!b||window.location.href.includes("/index.php?mod=quests")&&!b)null!==document.getElementById("blackoutDialogLoginBonus")&&yb&&!1===yb.isUnderworld&&setTimeout(function(){document.getElementById("blackoutDialogLoginBonus").getElementsByTagName("input")[0].click()},500),b=document.getElementById("blackoutDialognotification"),null!==b&&"none"!==window.getComputedStyle(b).display&&
setTimeout(function(){const c=document.getElementById("breakDiv");c&&c.click()},500)})();let Ze=!0;const $a=new URL(window.location.href);let ih=document.createElement("style");ih.innerHTML="\n    #logMenu {\n      resize: vertical;\n      overflow: auto;\n      max-height: 500px;\n    }\n  ";document.head.appendChild(ih);let pf=null,qf=0;null===localStorage.getItem("HealClothToggle")&&localStorage.setItem("HealClothToggle","false");window.location.href.includes("mod=auction")&&E();const ja=JSON.parse(localStorage.getItem("userStats"))||
{nm:0,om:0,lm:0,bm:0,fm:0,hm:0,im:0,pm:0,zm:0,Pl:0,Ql:0};let db;localStorage.getItem("playerId")&&ka((localStorage.getItem("playerId")|0)%100|0);(function(){var b="true"===localStorage.getItem("MoveButtons"),c=document.createElement("button");c.className="menuitem breathing-light";c.innerHTML="GLDbot License";c.setAttribute("id","lico");c.addEventListener("click",Fc);b?((b=document.getElementById("lico"))&&b.remove(),c.style.position="fixed",c.style.left="13px",c.style.bottom="60px",c.style.zIndex=
"1000",document.body.appendChild(c)):(b=document.getElementById("mainmenu"))&&b.children[0]&&b.insertBefore(c,b.children[0]);c=document.createElement("style");c.innerHTML="\n        @keyframes breathing-light {\n            0%, 100% {\n                box-shadow: 0 0 11px 5px rgba(255, 255, 0, 0.7);\n            }\n            50% {\n                box-shadow: 0 0 11px 10px rgba(255, 255, 0, 0.5);\n            }\n        }\n    \n        .breathing-light {\n            animation: breathing-light 2s ease-in-out infinite;\n        }";
document.head.appendChild(c)})();if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll")){var $e=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),sb=$e.textContent.trim();if(2<sb.length){var af=document.getElementById("char");function b(e,g,k,h){if(null!==document.getElementById("container_start")){var l=window.location.href.split("p=")[1].split("&")[0],n=window.location.href.match(/s(\d+)-\w\w/),
m=window.location.href.match(/s\d+-(\w\w)/);g={playerName:g,aType:h,opponentId:l,serverId:n?n[1]:null,country:m?m[1]:null};k=2===h?"arenacrosslist":"circuscrosslist";var r=2===h?"removeArenaList":"removeCircusList";n=JSON.parse(wb(k)||"[]");var u=JSON.parse(wb(r)||"[]");m=n.findIndex(q=>q.opponentId===l);var x=u.findIndex(q=>q.opponentId===l);-1!==m?(n.splice(m,1),-1===x&&(u.push(g),ob(r,JSON.stringify(u),7)),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+(2===h?"Arena":"Circus"))):
(n.push(g),-1!==x&&(u.splice(x,1),ob(r,JSON.stringify(u),7)),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+(2===h?"Arena":"Circus")));ob(k,JSON.stringify(n),7)}else n=JSON.parse(localStorage.getItem(k))||[],m=n.indexOf(g),-1!==m?(n.splice(m,1),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(n.push(g),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus"))),
localStorage.setItem(k,JSON.stringify(n))}function c(e,g,k,h,l){var n=document.createElement("a");n.className="gladbot-button gladbot-"+e;n.textContent=g;n.setAttribute("data-tooltip",k);af.appendChild(n);(JSON.parse(localStorage.getItem(h))||[]).includes(sb)&&(n.classList.add("added"),n.setAttribute("data-tooltip","Remove from "+("autoAttackList"===h?"Arena":"Circus")));n.addEventListener("click",function(){b(n,sb,h,l)})}c("arena","A","GladB: Add to Arena List","autoAttackList",2);c("circus","C",
"GladB: Add to Circus List","autoAttackCircusList",3)}}const kj=localStorage.getItem("Username"),ua=localStorage.getItem("pid");idkps=localStorage.getItem("idkps");let lj=localStorage.getItem("tkz_lcr");const mj=localStorage.getItem("tkn"),Zb=await ea(lj,mj,ua,kj);"true"===localStorage.getItem("AutoLogin")?Yb(!0):Yb(!1);if(window.location.href.includes("/index.php?mod=overview")){const b=[3,4,5,2,9,10,6,7,11],c=[1,2,4,8,48,256,512,1024];Jh();(function(){const g={dbfa266e60c28ce109de4d9c216a2a:"Health - Gingko Leaves","25925f7ce7c04483a3b4527846c04b":"Health - Taigaroot",
"79e62e1e04445d354bcc955bb8baeb":"Health - Hawthorn",b306d3f65b14cb91c0f0c9de871e0a:"Strength - Flask",ee80ae69b48ebbeb81e52c20113709:"Constitution - Flask","887d1152e2f7cba339a0a4675b3b5e":"Agility - Flask","93820f465cb02d5d8828ee9a14f5fe":"Charisma - Flask","2bf8795edae428b4646f8d6fd6dc4c":"Intelligence - Flask","43ac2597d30a099dd7033273ac29c1":"Dexterity - Flask","5368deb7929c8853843b420fb439ac":"Constitution - Bottle","967321edb226ea075ac63acc701eea":"Dexterity - Bottle","1c344cf484e5a87731eaf906ffd993":"Strength - Bottle",
"8971734256abbbe0fea2bb40721953":"Intelligence - Bottle",d2df53b4e64ad33dc301b6bf125fd2:"Agility - Bottle","37fc8feb4ead7f2e59c026af4228b3":"Charisma - Bottle",ce03a66b17f81394722a3fc2335a1d:"Constitution - Flacon","352a093dc497a9ec659f217dc7d374":"Dexterity - Flacon",b5e7e6f2cd2ea3d86143894e5f9ade:"Charisma - Flacon","2e8f9fc0f9b101f7ba49152cbe9779":"Strength - Flacon","3b52078b78637bd54fed2e4cfb951b":"Agility - Flacon",a2ef931eff7cce75e07baa9ae2ac97:"Intelligence - Flacon","48331278d1b0391f74ba54b4cac6d4":"Intelligence - Ampulla",
"453199ebfb25d62f83af27b0187088":"Agility - Ampulla","00ef972a002dc3040447e5cc0eb77d":"Dexterity - Ampulla",ce6fe5171b946cd26d5b21e87efb5d:"Strength - Ampulla",ddd6bc43a13d444409087b99b9f142:"Charisma - Ampulla",bd48bef94e6d066a8bfef716dd959a:"Constitution - Ampulla"},k=document.querySelectorAll("#buffbar_old .buff_inner");let h=JSON.parse(localStorage.getItem("buffs"))||{},l=new Set;k.forEach(n=>{var m=n.querySelector("img");m=(m=m?m.getAttribute("src"):null)?m.split("/").pop().split(".")[0]:null;
if(m=g[m])if(n=(n=n.parentElement.querySelector(".ticker"))?n.getAttribute("data-ticker-time-left"):null)h[m]={timeLeft:Math.round(Number(n)/6E4)},l.add(m)});Object.keys(h).forEach(n=>{l.has(n)||delete h[n]});localStorage.setItem("buffs",JSON.stringify(h))})();const e=document.getElementById("char");if(e){const g=document.createElement("button"),k=document.createElement("span");g.textContent="\u21d3";g.className="put-down awesome-button";g.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 170px; font-size: 12px; cursor: pointer;";
g.classList.add("tooltip");g.appendChild(k);g.onclick=async function(){let n=Array.from(document.querySelectorAll("#char .ui-droppable")).filter(m=>b.includes(parseInt(m.dataset.containerNumber,10)||"0"));for(let m=0;m<n.length;m++)await new Promise(r=>setTimeout(r,100)),Aa(n[m],"inv");await new Promise(m=>setTimeout(m,500))};e.appendChild(g);const h=document.createElement("button"),l=document.createElement("span");h.textContent="\u21d1";h.className="put-up awesome-button";h.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 192px; font-size: 12px; cursor: pointer;";
h.classList.add("tooltip");h.appendChild(l);h.onclick=async function(){let n=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(m=>c.includes(parseInt(m.dataset.contentType,10)));for(let m=0;m<n.length;m++)await new Promise(r=>setTimeout(r,100)),Aa(n[m],"char");await new Promise(m=>setTimeout(m,500))};e.appendChild(h)}if(document.getElementById("inv")){async function g(n,m,r,u,x,q){await jQuery.post(R({mod:"inventory",submod:"move",from:q,fromX:m+1,fromY:r+1,to:q,toX:u+1,toY:x+1,amount:n.dataset.amount||
1,doll:1,a:(new Date).getTime(),sh:U("sh")}))}const k=document.createElement("button");k.id="sort-button";k.textContent="Sort Inventory";k.className="sort-button awesome-button";k.style="padding: 5px; margin: 5px; cursor: pointer;";const h=document.createElement("span");h.id="loading-indicator";h.style="margin-left: 10px; display: none;";const l=document.querySelector(".contentItem");l&&(l.insertAdjacentElement("afterend",k),k.insertAdjacentElement("afterend",h));k.addEventListener("click",async function(){function n(y,
A,B){for(let v=0;5>v;v++)for(let D=0;8>D;D++)if(!x[v][D]){let F=!0;for(let I=v;I<v+A&&F;I++)for(let K=D;K<D+y;K++)if(5<=I||8<=K||x[I][K])F=!1;if(F){if(B){y=[{x:D-1,y:v},{x:D+y,y:v},{x:D,y:v-1},{x:D,y:v+A}];for(const I of y)if(0<=I.x&&8>I.x&&0<=I.y&&5>I.y&&u.find(K=>{const M=parseInt(K.style.top,10)/32;return parseInt(K.style.left,10)/32===I.x&&M===I.y&&K.dataset.basis.split("-")[0]===B}))break}return{x:D,y:v}}}return null}var m=document.getElementById("inv");document.getElementById("sort-button");
var r=document.getElementById("loading-indicator");r.textContent="Sorting...";r.style.display="inline-block";const u=Array.from(m.getElementsByClassName("ui-draggable"));u.sort((y,A)=>{const B=parseInt(y.dataset.basis.split("-")[0],10)||0,v=parseInt(A.dataset.basis.split("-")[0],10)||0;return B!==v?B-v:(parseInt(y.dataset.measurementX,10)*parseInt(y.dataset.measurementY,10)||1)-(parseInt(A.dataset.measurementX,10)*parseInt(A.dataset.measurementY,10)||1)});const x=Array.from({length:5},()=>Array(8).fill(!1));
u.forEach(y=>{const A=parseInt(y.style.left,10)/32,B=parseInt(y.style.top,10)/32,v=parseInt(y.dataset.measurementX,10);y=parseInt(y.dataset.measurementY,10);for(let D=B;D<B+y;D++)for(let F=A;F<A+v;F++)x[D][F]=!0});for(m=0;m<u.length;m++){var q=u[m];r=parseInt(q.dataset.measurementX,10);const y=parseInt(q.dataset.measurementY,10);var t=q.dataset.basis.split("-")[0];const A=parseInt(q.style.left,10)/32,B=parseInt(q.style.top,10)/32;var w=n(r,y,t);if(w&&(t=w.x,w=w.y,A!==t||B!==w)){await g(q,A,B,t,w,
q.dataset.containerNumber);for(q=w;q<w+y;q++)for(let v=t;v<t+r;v++)x[q][v]=!0;for(t=B;t<B+y;t++)for(q=A;q<A+r;q++)x[t][q]=!1}}window.location.reload()})}}let Ic=localStorage.getItem("playerId");Xb();let rb=!1,pa="true"===sessionStorage.getItem("autoGoActive")?!0:!1,aa;await async function(){try{aa={level:parseInt(document.getElementById("header_values_level").innerText,10),o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,""))}}catch(b){C("Error getting player data: "+
b.message,"error")}}();const ab=document.createElement("div");ab.style.position="fixed";ab.style.right="10px";ab.style.top="50px";ab.style.zIndex="99999";document.body.appendChild(ab);const ma=document.createElement("div");ma.id="logMenu";ma.style.width="190px";ma.style.height="210px";ma.style.overflowY="hidden";ma.style.backgroundColor="rgba(221, 213, 180, 0.8)";ma.style.border="1px solid #c4ac70";ma.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";ma.style.borderRadius="10px";ma.style.fontFamily=
"Arial, sans-serif";ma.style.color="#333";ab.appendChild(ma);const bb=document.createElement("h2");bb.textContent="Log Menu";bb.style.backgroundColor="rgba(196, 172, 112, 0.8)";bb.style.color="#333";bb.style.margin="0";bb.style.padding="10px 20px";bb.style.borderTopLeftRadius="10px";bb.style.borderTopRightRadius="10px";ma.appendChild(bb);const zb=document.createElement("div");zb.id="logEntriesContainer";zb.style.color="#bfae54";zb.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";zb.style.overflowY="scroll";zb.style.height="calc(100% - 60px)";zb.style.padding="10px 20px";ma.appendChild(zb);
const Na=document.createElement("div");Na.style.display="flex";Na.style.justifyContent="space-between";Na.style.marginTop="10px";Na.style.top="calc(300px + 10px)";Na.style.width="155px";Na.style.padding="0 10px";Na.style.zIndex="99999";Na.style.left="0";ab.appendChild(Na);const Ia=document.createElement("button");Ia.id="clearLogsButton";Ia.textContent="Clear Logs";Jc(Ia,"rgba(221, 213, 180, 0.8)");Na.appendChild(Ia);Ia.addEventListener("click",function(){const b=document.querySelector("#logMenu");
if(b){for(;b.firstChild;)b.removeChild(b.firstChild);localStorage.removeItem("savedLogs")}});const Pb=document.createElement("button");Pb.id="resetBOT";Pb.textContent="Reset Bot";Jc(Pb,"rgba(221, 213, 180, 0.8)");Na.appendChild(Pb);Pb.addEventListener("click",function(){S()});const Oa=document.createElement("button");Oa.textContent="Sort Logs";Jc(Oa,"rgba(221, 213, 180, 0.8)");Na.appendChild(Oa);Oa.addEventListener("click",function(){let b=localStorage.getItem("savedLogs");if(b){b=JSON.parse(b);b.sort((e,
g)=>{e=e.split(" ")[0];g=g.split(" ")[0];return Ze?e.localeCompare(g):g.localeCompare(e)});Ze=!Ze;for(var c=document.querySelector("#logMenu");c.firstChild;)c.removeChild(c.firstChild);for(let e of b){const g=document.createElement("p");g.style.margin="0";g.style.padding="0";g.style.fontSize="12px";g.textContent=e;c.appendChild(g)}localStorage.setItem("savedLogs",JSON.stringify(b))}});ma.style.transition="height 0.1s ease";const jh=localStorage.getItem("logMenuVisible"),kh="true"===localStorage.getItem("disableLogMenu");
null===jh?localStorage.setItem("logMenuVisible","true"):1==kh?(ma.style.display="none;",ma.style.height="0px",ma.style.width="0px",ma.style.border="0px",Ia.style.display="none",Ia.style.height="0px",Ia.style.width="0px",Ia.style.border="0px",Oa.style.display="none",Oa.style.height="0px",Oa.style.width="0px",Oa.style.border="0px"):"true"===jh?localStorage.getItem("logMenuHeight"):ma.style.height="38px";window.location.href.includes("/hub")&&(ma.style.display="none;",ma.style.height="0px",ma.style.width=
"0px",ma.style.border="0px",Ia.style.display="none",Ia.style.height="0px",Ia.style.width="0px",Ia.style.border="0px",Oa.style.display="none",Oa.style.height="0px",Oa.style.width="0px",Oa.style.border="0px");bb.addEventListener("click",function(){if("38px"!==ma.style.height)ma.style.height="38px",localStorage.setItem("logMenuVisible","false");else{const b=localStorage.getItem("logMenuHeight")||"210px";ma.style.height=b;localStorage.setItem("logMenuVisible","true")}});ma.addEventListener("resize",sf);
"38px"!==ma.style.height&&sf();if(await Hc()){const b="true"===localStorage.getItem("MoveButtons");let c=document.getElementById("mainmenu"),e=document.createElement("button");e.id="autoGoButton";e.className="customButton";e.innerHTML=`<span style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;">${pa?"&#9724;":"&#9658;"}</span>`;e.addEventListener("click",pa?wf:pt);let g=document.createElement("button");g.className="customButton2";g.innerHTML='<span style="position: relative; top: -12px;">&#9881;</span>';
g.addEventListener("click",dc);b?(g.style.position="fixed",g.style.bottom="10px",g.style.left="10px",g.style.zIndex="1000",e.style.position="fixed",e.style.bottom="10px",e.style.left="105px",e.style.zIndex="1000",document.body.appendChild(g),document.body.appendChild(e)):c&&(c.insertBefore(g,c.children[0]),c.insertBefore(e,c.children[1]))}else return eb(),!1;(function(){try{if("mod=arena&submod=serverArena&aType=2"==lf||"mod=arena&submod=serverArena&aType=3"==lf){let l=JSON.parse(localStorage.getItem("autoAttackList"))||
[],n=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],m=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[],r=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[],u=[...l,...n,...m,...r].map(x=>x.playerName);Array.from(document.querySelectorAll("#own2 tr")).forEach(x=>{(x=x.querySelector("a"))&&u.includes(x.innerText)&&(x.style.color="orange",x.style.fontWeight="bold",x.style.textShadow="1px 1px 2px #000000")})}var b=JSON.parse(wb("arenacrosslist")||"[]"),c=JSON.parse(wb("circuscrosslist")||
"[]"),e=JSON.parse(wb("removeArenaList")||"[]"),g=JSON.parse(wb("removeCircusList")||"[]"),k=JSON.parse(localStorage.getItem("autoAttackServerList")||"[]"),h=JSON.parse(localStorage.getItem("autoAttackCircusServerList")||"[]");0<b.length&&(b.forEach(l=>{k.some(n=>n.opponentId===l.opponentId)||k.push(l)}),localStorage.setItem("autoAttackServerList",JSON.stringify(k)),ob("arenacrosslist",JSON.stringify([]),7));0<c.length&&(c.forEach(l=>{h.some(n=>n.opponentId===l.opponentId)||h.push(l)}),localStorage.setItem("autoAttackCircusServerList",
JSON.stringify(h)),ob("circuscrosslist",JSON.stringify([]),7));if(0<e.length||0<g.length)k=k.filter(l=>!e.some(n=>n.opponentId===l.opponentId)),h=h.filter(l=>!g.some(n=>n.opponentId===l.opponentId)),localStorage.setItem("autoAttackServerList",JSON.stringify(k)),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(h)),ob("removeArenaList",JSON.stringify([]),7),ob("removeCircusList",JSON.stringify([]),7)}catch{C("Something is wrong with HandlePlayers")}})();"mod=overview"==lf&&Kh();if("mod=location"!==
lf&&"mod=arena"!==lf&&0==localStorage.getItem("eventPoints_")){const b=document.getElementById("ServerQuestTime");if(b){const c=b.querySelector("span");c&&localStorage.setItem("eventPoints_",c.textContent)}}let La=!0;localStorage.getItem("doQuests")&&(La="true"===localStorage.getItem("doQuests")?!0:!1);let Ma={combat:!0,arena:!0,circus:!0,expedition:!0,dungeon:!0,items:!0};localStorage.getItem("questTypes")&&(Ma=JSON.parse(localStorage.getItem("questTypes")));let Qb=0;localStorage.getItem("nextQuestTime")&&
(Qb=Number(localStorage.getItem("nextQuestTime")));let Ba=!0;localStorage.getItem("doExpedition")&&(Ba="true"===localStorage.getItem("doExpedition")?!0:!1);let Pc=0;localStorage.getItem("monsterId")&&(Pc=Number(localStorage.getItem("monsterId")));let Fa=!0;localStorage.getItem("doDungeon")&&(Fa="true"===localStorage.getItem("doDungeon")?!0:!1);10>aa.level&&(Fa=!1);let Gb="advanced"===localStorage.getItem("dungeonDifficulty")?"advanced":"normal",Ga=!0;localStorage.getItem("doArena")&&(Ga="true"===
localStorage.getItem("doArena")?!0:!1);2>aa.level&&(Ga=!1);let Df="min";localStorage.getItem("arenaOpponentLevel")&&(Df=localStorage.getItem("arenaOpponentLevel"));let Ca=!0;localStorage.getItem("doCircus")&&(Ca="true"===localStorage.getItem("doCircus")?!0:!1);10>aa.level&&(Ca=!1);let Ef="min";localStorage.getItem("circusOpponentLevel")&&(Ef=localStorage.getItem("circusOpponentLevel"));let Da=!0;localStorage.getItem("doEventExpedition")&&(Da="true"===localStorage.getItem("doEventExpedition")?!0:!1);
try{document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0]||(Da=!1)}catch{}let fc=0;localStorage.getItem("eventMonsterId")&&(fc=Number(localStorage.getItem("eventMonsterId")));let Xa=!1;localStorage.getItem("AutoAuction")&&(Xa="true"===localStorage.getItem("AutoAuction")?!0:!1);localStorage.getItem("DoOther")&&localStorage.getItem("DoOther");let fb=!1;localStorage.getItem("doKasa")&&(fb="true"===localStorage.getItem("doKasa")?!0:!1);let d;switch(localStorage.getItem("settings.language")){case "EN":d=
{...Ch};break;case "PL":d={...Dh};break;case "ES":d={...Eh};break;case "TR":d={...Fh};break;case "FR":d={...Gh};break;case "HG":d={...Hh};break;case "BR":d={...Ih};break;default:d={...Ch}}const z1 = localStorage.getItem("we");we = new Date(z1);if(fa<new Date||we<new Date)throw sessionStorage.setItem("autoGoActive","false"),eb(),Error("LE");if("true"===localStorage.getItem("activateAuction2")){function b(m){m.style.position="flex";m.style.width="150px";m.style.marginLeft="8px";m.style.marginTop="10px";m.style.height="16px";m.style.backgroundColor="rgba(221, 213, 180, 0.8)";
m.style.border="1px solid #c4ac70";m.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";m.style.padding="10px";m.style.borderRadius="10px";m.style.fontFamily="Arial, sans-serif";m.style.color="#333";m.style.textAlign="center";m.style.zIndex="1000"}const c=document.createElement("div");c.id="auctionMPopup";b(c,"calc(55px + 200px + 100px + 10px + 10px + -5px)");c.addEventListener("click",async()=>{Cf("mod=auction&ttype=3")});const e=document.createElement("div");e.id="auctionPopup";b(e,"calc(100px + 200px + 100px + 10px)");
e.addEventListener("click",async()=>{Cf("mod=auction")});function g(m,r){return`${r}: ${[d.Qb,d.sb,d.Bb,d.Nb,d.Rb][m]||"Unknown"}`}const k=document.createElement("h3"),h=document.createElement("h3");ab.appendChild(e);ab.appendChild(c);const l=localStorage.getItem("auctionStatus"),n=localStorage.getItem("auctionMStatus");null!==l?(k.textContent=g(parseInt(l,10),"Gladiator"),e.appendChild(k),e.style.display="block"):e.style.display="none";null!==n?(h.textContent=g(parseInt(n,10),"Mercenary"),c.appendChild(h),
c.style.display="block"):c.style.display="none";kh&&(e.style.display="none",e.style.height="0px",c.style.display="none",c.style.height="0px")}let vc=localStorage.getItem("savedLogs");vc&&(vc=JSON.parse(vc),vc.forEach(b=>{const c=document.createElement("p");c.style.margin="0";c.style.padding="0";c.style.fontSize="12px";c.textContent=b;zb.appendChild(c)}));const za={async start(){return new Promise(()=>{za.Vk=zh().gold;za.form=document.querySelectorAll("#auction_table form");za.O=[];const b=localStorage.getItem("auctiongladiatorenable"),
c=localStorage.getItem("auctionmercenaryenable"),e=localStorage.getItem("bidFood"),g=localStorage.getItem("bidStatus"),k=localStorage.getItem("auctionStatus"),h=localStorage.getItem("auctionMStatus"),l=localStorage.getItem("auctionminlevel")||0;let n="true"===localStorage.getItem("enableMercenarySearch");const m=JSON.parse(localStorage.getItem("Timers")),r=async(x,q)=>{try{C(`${d.ff}`);const t=await (await fetch(x)).text(),w=(new DOMParser).parseFromString(t,"text/html");await za.vn(w);0<za.O.length?
(C(`${d.gf}`),"auction"===q?za.dm(2,za.O.length):za.dm(3,za.O.length)):("auction"===q?X("auction",m.AuctionCheck||10):X("auctionM",m.AuctionCheck||10),window.location.reload());1!=localStorage.getItem("AuctionTurbo")&&X("AuctionEmpty",1)}catch(t){window.location.reload()}},u=async()=>{var x=JSON.parse(localStorage.getItem("auctionPrefixes"))||[];let q=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],t;var w=(new URL(window.location.href)).origin;try{1===x.length?t=Wb(x[0]):1===q.length&&(t=
Wb(q[0]))}catch(y){t=""}if(n&&Number(k)>=Number(g)&&W("auction")||"true"==e&&Number(k)>=Number(g)&&W("auction"))lf!=`mod=auction&itemType=0&itemLevel=${l}`&&(w=`${w}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,r(w,"auction"));else if((1==x.length||1==q.length)&&"true"==b&&Number(k)>=Number(g)&&"false"==e&&W("auction"))x=`mod=auction&qry=${encodeURIComponent(t)}&itemType=0&itemLevel=${l}`,lf!==x&&(w=`${w}/game/index.php?${x}&sh=${U("sh")}`,r(w,"auction"));else if(n&&Number(k)>=
Number(g)&&"true"==e&&W("auction"))lf!=`mod=auction&itemType=0&itemLevel=${l}`&&(w=`${w}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,r(w,"auction"));else if((1==x.length||1==q.length)&&"true"==c&&Number(h)>=Number(g)&&"false"==e&&W("auctionM"))lf!=`mod=auction&qry=${encodeURIComponent(t)}&itemType=0&ttype=3&itemLevel=${l}`&&(w=`${w}/game/index.php?mod=auction&qry=${t}&itemType=0&ttype=3&itemLevel=${l}&sh=${U("sh")}`,r(w,"auctionM"));else if(("true"===b||"true"===e)&&!n&&Number(k)>=
Number(g)&&W("auction"))if("true"===e&&1>x.length&&1>q.length)lf!=`mod=auction&itemType=7&itemLevel=${l}`&&(w=`${w}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${U("sh")}`,r(w,"auction"));else{if(("true"===b||"true"===e)&&!n&&Number(k)>=Number(g)&&W("auction"))if("true"===e&&"false"===b&&(0<x.length||0<q.length))lf!=`mod=auction&itemType=7&itemLevel=${l}`&&(w=`${w}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${U("sh")}`,r(w,"auction"));else if("true"===e&&(0<x.length||0<q.length))lf!=
`mod=auction&itemType=0&itemLevel=${l}`&&(w=`${w}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,r(w,"auction"));else if(lf!=`mod=auction&itemType=0&itemLevel=${l}`&&0<x.length||lf!=`mod=auction&itemType=0&itemLevel=${l}`&&0<q.length)w=`${w}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,r(w,"auction")}else if("true"==c&&Number(h)>=Number(g)&&(0<x.length||0<q.length)&&W("auctionM")){if(lf!=`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&0<x.length||lf!=`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&
0<q.length)w=`${w}/game/index.php?mod=auction&itemType=0&ttype=3&itemLevel=${l}&sh=${U("sh")}`,r(w,"auctionM")}else n?lf!=`mod=auction&itemType=15&itemLevel=${l}`&&(w=`${w}/game/index.php?mod=auction&itemType=15&itemLevel=${l}&sh=${U("sh")}`,r(w,"auction")):setTimeout(u,3E3)};u()})},un(b){const c="true"===localStorage.getItem("AuctionCover");b=b.querySelector("span");if(!b||!b.getAttribute("style"))return!0;b=b.getAttribute("style");return c&&b.includes("green")?!1:!c&&b.includes("green")?!0:b.includes("blue")?
!1:!0},async vn(b){this.form=b.querySelectorAll("#auction_table form");for(let e of this.form){var c=e.querySelector(".auction_bid_div");b=e.querySelector(".ui-draggable");let g=c.querySelector("input").value;c=this.un(c);let k=Sb(b),h=ub(b),l=JSON.parse(localStorage.getItem("equipmentSelection")||"[]"),n=localStorage.getItem("maximumBid"),m=localStorage.getItem("auctiongladiatorenable"),r=localStorage.getItem("auctionmercenaryenable"),u=nb(b),x=localStorage.getItem("auctionMinQuality")||0,q=localStorage.getItem("bidFood"),
t=parseInt(Db(b).split("-")[0],10),w=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,y=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,A=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],10):0,B=!1,v="true"===localStorage.getItem("enableMercenarySearch"),D=parseInt(localStorage.getItem("minDexterity"),10)||0,F=parseInt(localStorage.getItem("minAgility"),10)||0,I=parseInt(localStorage.getItem("minIntelligence"),
10)||0,K=!1,M=!1,Q,Z,ba;ba=localStorage.getItem("ignorePS")||"false";Q=JSON.parse(localStorage.getItem("auctionPrefixes")||"[]");Z=JSON.parse(localStorage.getItem("auctionSuffixes")||"[]");Q.some(ia=>k.toLowerCase().includes(ia.toLowerCase())?K=!0:!1);Z.some(ia=>{let la=k.toLowerCase();ia=ia.toLowerCase();return la.endsWith(" "+ia)||la===ia?M=!0:!1});if("true"===ba){if(K||M)B=!0}else if(K&&M||K&&0===Z.length||M&&0===Q.length)B=!0;"string"===typeof h&&(h=[h]);null==x&&(x=5);B=B&&0===l.length||B&&l.includes("9999")||
B&&l.some(ia=>h.includes(ia))?!0:!1;"true"===q&&7==t&&g<aa.gold&&(B=!0);1E3>aa.gold&&(X("AuctionEmpty",1),X("AuctionMEmpty",1));c&&v&&15==t&&Number(g)<Number(n)&&(0==D||w>=D)&&(0==F||y>=F)&&(0==I||A>=I)&&(B=!0);Number(u)<x&&(B=!1);"false"===m&&"false"===r&&(B=!1);(c&&Number(g)<Number(n)&&B||c&&B&&"true"===q&&7==t&&Number(g)<Number(n))&&this.O.push([{itemLevel:Cb(b),itemName:k,basis:Db(b),quality:nb(b),price:g},g,e.getAttribute("action"),{auctionid:e.querySelector("input[name=auctionid]").value,qry:e.querySelector("input[name=qry]").value,
itemType:e.querySelector("input[name=itemType]").value,itemLevel:e.querySelector("input[name=itemLevel]").value,itemQuality:e.querySelector("input[name=itemQuality]").value,buyouthd:e.querySelector("input[name=buyouthd]").value,bid_amount:g,bid:e.querySelector("input[name=bid]").value}])}},dm(b,c,e=0){localStorage.getItem("auctionStatus");localStorage.getItem("auctionMStatus");const g=JSON.parse(localStorage.getItem("Timers"));let k=za.O.pop();try{if(Number(k[1])<za.Vk){za.Vk-=k[1];jQuery.ajax({type:"POST",
url:k[2],data:k[3]});let h=JSON.parse(localStorage.getItem("bidList"))||[];h.push(k[0].itemName);localStorage.setItem("bidList",JSON.stringify(h));0<za.O.length?setTimeout(()=>{za.dm(b,--c,++e)},350):(X("AuctionEmpty",1),X("AuctionMEmpty",1),window.location.reload())}else 2==b?(X("AuctionEmpty",1),X("auction",g.AuctionCheck||10)):(X("AuctionMEmpty",1),X("auctionM",g.AuctionCheck||10)),window.location.reload()}catch(h){window.location.reload()}}},ha={bag:null,m:null,up:null,Cp:localStorage.getItem("smeltIgnorePS"),
async start(){const b="true"===localStorage.getItem("RepairBeforeSmelt");var c="513";c=(c=localStorage.getItem("smeltTab"))?(513+parseInt(c,10)).toString():"513";c=document.querySelector(`[data-bag-number="${c}"]`);if("mod=forge&submod=smeltery"!=lf)Cf("mod=forge&submod=smeltery");else if(c.classList.contains("current")&&nf()){this.slots=await this.u();const e=this.slots.filter(h=>"closed"===h["forge_slots.state"]);this.vm(this.slots);await this.em(this.slots);const g=JSON.parse(localStorage.getItem("Timers")),
k="true"===localStorage.getItem("smelteverything3");c="true"===localStorage.getItem("smeltAnything")?this.Rn():"true"===localStorage.getItem("smelteverything3")?this.Sn():this.Qn();if(0<c.length){for(let {id:h,slot:l,hammerState:n}of c)try{if(b){const m=await nj.lo(h);if(m&&0!=m)try{await ha.Xl(l,m,n,h)}catch{await ha.Xl(l,h,n,h)}else await ha.Xl(l,h,n,h)}else await ha.Xl(l,h,n,h)}catch(m){}window.location.reload()}else 1>c.length&&1==k?(X("smelt",g.SmeltingNoItem||10),window.location.reload()):0<
e.length?await this.pickItems():0<e.length&&"true"===localStorage.getItem("smelteverything3")?ha.move():(X("smelt",g.SmeltingNoItem||10),window.location.reload())}else c.click(),nf(()=>this.start())},jo(b,c){b=JSON.parse(localStorage.getItem("smeltedItems"))||[];b.push(c);localStorage.setItem("smeltedItems",JSON.stringify(b))},Qn(){const b=this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];
for(let g of c){if(c=this.Tl(g)){let k=b.shift();void 0!==k&&e.push({id:g.getAttribute("data-item-id"),slot:k,hammerState:c.hammerState||"none",matchingRule:c})}if(0===b.length)break}return e},Rn(){const b=this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let g of c){if(c=this.Tl(g)){let k=b.shift();void 0!==k&&e.push({id:g.getAttribute("data-item-id"),slot:k,hammerState:c.hammerState||
"none",matchingRule:c})}if(0===b.length)break}return e},Sn(){const b=[2,4,8,1,256,512,48,1024],c=this.slots.filter(e=>"closed"===e["forge_slots.state"]).map(e=>e["forge_slots.slot"]);return Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(e=>{if(!Ub(e))return!1;e=e.getAttribute("data-content-type");return b.includes(Number(e))}).map(e=>({id:e.getAttribute("data-item-id"),slot:c.shift()})).filter(({slot:e})=>void 0!==e)},async Xl(b,c,e,g){try{var k=await jQuery.post(R({}),{mod:"forge",
submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:U("sh")});let n;try{var h=JSON.parse(k);if(h.slots[b]&&h.slots[b].formula&&h.slots[b].formula.rent[2])n=h.slots[b].formula.rent[2];else{for(k=0;k<h.slots.length;k++)if(h.slots[k].formula&&h.slots[k].formula.rent[2]){n=h.slots[k].formula.rent[2];break}n||=3E3}}catch(r){n=3E3}const m=Sb(document.querySelector(`[data-item-id='${g}']`));try{if(e&&"none"!==e){const r={bronze:"19-10",silver:"19-11",gold:"19-12"}[e];
if(r){var l=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));const u=l.findIndex(q=>q.classList.contains("current")),x=l.slice(u).concat(l.slice(0,u));g=!1;h=null;for(l=0;l<x.length;l++){let q=x[l];if("false"===q.getAttribute("data-available"))continue;q.click();await new Promise(w=>setTimeout(w,250));const t=document.querySelector(`.item-i-${r}`);if(t){g=!0;h=t;break}}if(g&&h){const q=h.getAttribute("data-container-number"),t=h.getAttribute("data-position-x"),w=h.getAttribute("data-position-y");
await jQuery.post(R({mod:"inventory",submod:"move",from:q,fromX:t,fromY:w,to:773,toX:b+1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:U("sh")}));C(`Hammer (${e}) moved to inventory.`)}else C(`Hammer (${e}) not found in any inventory bag.`),C("Proceeding to smelt without a hammer.")}else C("Proceeding to smelt without a hammer.")}}catch(r){}if(n<zh().gold)await jQuery.post(R({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:U("sh")})),this.jo(c,m),N("itemSmelted",
0),C(`${d.If}`+m),await new Promise(r=>setTimeout(r,250));else{const r=JSON.parse(localStorage.getItem("Timers"));X("smelt",r.Smelting||10);window.location.reload()}}catch(n){location.reload()}},async oo(b,c){var e=await jQuery.post(R({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:U("sh")});e=JSON.parse(e).slots[b].formula.rent[2];e<zh().gold?jQuery.post(R({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),
sh:U("sh")})).done(function(){var g=JSON.parse(localStorage.getItem("smeltery_itemList1"));({item:g}=g);C(`${d.Jf}`+g.name);window.location.reload()}).fail(function(){C("Problem with smelting, maybe there is not enough space.");window.location.reload()}):(C(`${d.Kf}`+e),b=JSON.parse(localStorage.getItem("Timers")),X("smelt",b.SmeltingNoGold||5),window.location.reload())},init:function(){jQuery("#inv").after('\n                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n\n                        <fieldset id="gladbot-workbench" style="\n                        padding: 10px;\n                        margin: 10px 20px;\n                        text-align: center;\n                        display: flex;\n                        flex-direction: row;\n                        flex-wrap: wrap;\n                        align-items: center;\n                        justify-content: space-around;\n                        border: 2px solid darkred;\n                        border-radius: 8px;\n                        width: 235px;">\n                        <legend style="\n                            padding: 0 10px;\n                            color: darkred;\n                            font-weight: bold;">GLDbot Smeltery Area</legend>\n                        </fieldset>');
ha.am("#gladbot-workbench",'<i class="fa fa-fire"></i>',"gladbot-button gladbot-smelter-button-smelt gladbot-stylish-button").mouseup(b=>{ha.Dm(b)});ha.am("#gladbot-workbench","RESET","gladbot-button gladbot-smelter-button-reset gladbot-stylish-button").mouseup(()=>{localStorage.setItem("activateSmeltMode",!1)});jQuery("#gladbot-workbench").append('<p style="font-size: 0.8em; color: darkred;">Right click to reset smelt mode.</p>')},Dm:async function(){jQuery(document.body).addClass("fire-smelt-cursor");
jQuery(document.body).on("contextmenu",function(b){b.preventDefault();jQuery(document.body).removeClass("fire-smelt-cursor");jQuery(document.body).off("contextmenu");localStorage.setItem("activateSmeltMode",!1)});this.slots=await this.u();localStorage.setItem("activateSmeltMode",!0);jQuery("#inv .ui-draggable, #char .ui-draggable").off("mouseup.smelt").on("mouseup.smelt",async b=>{var c=b.target,e=c.className.match(/item-i-(\d+)-\d+/)[1];(b=this.slots.filter(g=>"closed"===g["forge_slots.state"])[0])?
(e={item:{type:e,name:Sb(c),quality:nb(c),slot:b,container:c.getAttribute("data-container-number")},spot:{bag:c.getAttribute("data-container-number"),x:c.getAttribute("data-position-x"),y:c.getAttribute("data-position-y")}},localStorage.setItem("smeltery_itemList1",JSON.stringify(e)),jQuery(c).parents("#char").length?setTimeout(()=>{},1E3):(this.slots=await this.u(),await this.em(this.slots),this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>g["forge_slots.slot"]),c=c.getAttribute("data-item-id"),
e&&await ha.oo(b["forge_slots.slot"],c))):console.log("No free slot available")})},async u(){try{const b=await jQuery.post(R({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",a:(new Date).getTime(),sh:U("sh")});return JSON.parse(b).slots}catch(b){console.log(b)}},async vm(b){if("undefined"!==typeof b){let e=[];for(var c=0;c<b.length;c++)if("undefined"!==typeof b[c]["forge_slots.uend"]){let g=1E3*b[c]["forge_slots.uend"];"finished-succeeded"===b[c]["forge_slots.state"]&&(g=0);e.push([g,
b[c].item.name])}localStorage.setItem("smelt.timer",JSON.stringify(e))}},async em(b){const c="true"===localStorage.getItem("smeltLootbox");Array.isArray(b)&&(b=b.filter(e=>"finished-succeeded"===e.state).map(e=>e["forge_slots.slot"]),0<b.length&&!c?(await Promise.all(b.map(e=>ha.co(e))),await this.u()):0<b.length&&c&&(await Promise.all(b.map(e=>ha.eo(e))),await this.u()))},async eo(b){return jQuery.post("ajax.php",{mod:"forge",submod:"lootbox",mode:"smelting",slot:b,a:(new Date).getTime(),sh:U("sh")})},
async co(b){return jQuery.post("ajax.php",{mod:"forge",submod:"storeSmelted",mode:"smelting",slot:b,a:(new Date).getTime(),sh:U("sh")})},Gm(){var b=localStorage.getItem("smelt.timer");if(!b)return!0;b=JSON.parse(b).sort((c,e)=>c[0]-e[0]);return 6>b.length||b[0][0]+6E4<(new Date).getTime()},async pickItems(){C(`${d.Lf}`);ha.bag=document.getElementById("inv");ha.m=[];var b=JSON.parse(localStorage.getItem("smeltingSettings"))||[],c=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{},e=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||
"[]")),g=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]")),k=!1;for(var h of b){if(!h.isEnabled)continue;if("isUnderworldItem"!==h.condition&&2>h.prefix.length&&2>h.suffix.length)continue;let t=[];var l="";"nameContains"===h.condition&&2<h.prefix.length&&""!==h.prefix.trim()?l=h.prefix.trim():!h.prefix&&"nameContains"===h.condition&&2<h.suffix.length&&""!==h.suffix.trim()&&(l=h.suffix.trim());const w={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};h.colors&&0<
h.colors.length?h.colors.forEach(y=>{y=w[y];void 0!==y&&t.push(y)}):t=Object.values(w);var n=0,m=[];if(2<l.length){for(var r=1;2>=r;r++)m.push(this.Lm(r,t[0],l));l=await Promise.all(m);l=[].concat(...l);if(5<=n)break;for(let y of l){if(5<=n)break;l=y.item;m=Sb(y.item);ha.m.some(A=>A.id===y.id)||e.has(m)||g.has(m)||!this.Tl(l,h,b,c)||(ha.m.push({item:l,id:y.id,hammerState:h.hammerState||"none",matchingRule:h}),n++,k=!0)}if(5<=n)break}else if("isUnderworldItem"===h.condition){C("Looking for underworld items...This might take a while...");
for(var u of t){if(5<=n)break;l=await this.Sl(u);m=Math.min(l,10);for(r=new Set;r.size<m;)r.add(Math.floor(Math.random()*l)+1);for(var x of r){l=await this.Lm(x,u);for(var q of l)if(l=q.item,m=this.Tl(l,h))if(ha.m.push({item:l,id:q.id,hammerState:m.hammerState||"none",matchingRule:m}),n++,k=!0,5<=n)break;if(5<=n)break}}}}if(!k&&"true"===localStorage.getItem("smeltAnything")){b=c.itemTypes||[];e=c.hammerState||"none";const t={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};c=(c.colors||
[]).map(w=>t[w]);0===c.length&&(c=Object.values(t));g=0;h=await this.Sl(c[0]);for(n=1;n<=h&&!(5<=g);n++){u=await this.On(n,c[0]);for(let w of u){if(5<=g)break;u=w.item;x=Sb(u);const y=parseInt(nb(u),10);q=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]");l=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");if(!q.includes(x)&&!l.includes(x)){if(Ea.colors&&0<Ea.colors.length){const A={white:-1,green:0,blue:1,purple:2,orange:3,red:4};x=Object.keys(A).find(B=>A[B]===y);if(!Ea.colors.includes(x))continue}b.includes(u.getAttribute("data-content-type"))&&
(ha.m.push({item:u,id:w.id,hammerState:e}),g++,k=!0)}}if(5<=g)break}}k&&0<ha.m.length?await ha.move(ha.m):(C("No items found for smelting."),k=JSON.parse(localStorage.getItem("Timers")),X("smelt",k.SmeltingNoItem||15),window.location.reload())},async cp(b,c){b=await jQuery.get(G({mod:"packages",f:"0",fq:c,qry:"",page:b,sh:U("sh")}));const e=[];jQuery(b).find(".packageItem").each((g,k)=>{g=k.querySelector("input").value;(k=jQuery(k).find(".ui-draggable")[0])&&e.push({id:g,item:k})});return e},Nn(b){return b.getAttribute("data-hammer-state")||
"none"},async Lm(b,c=null,e=""){b={mod:"packages",f:"0",page:b,sh:U("sh")};null!==c&&(b.fq=c);e&&""!==e.trim()&&(b.qry=e.trim());c=await jQuery.get(G(b));const g=[];jQuery(c).find(".packageItem").each((k,h)=>{k=h.querySelector("input").value;(h=jQuery(h).find(".ui-draggable")[0])&&g.push({id:k,item:h})});return g},async On(b,c=null,e=""){b={mod:"packages",f:"0",fq:null!==c?c:-1,page:b,sh:U("sh")};e&&""!==e.trim()&&(b.qry=e.trim());e=await jQuery.get(G(b));e=jQuery(e).find(".packageItem");const g=
[],k=(JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{}).itemTypes||[],h=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]"),l=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");e.each((n,m)=>{const r=m.querySelector("input").value;if(n=jQuery(m).find(".ui-draggable")[0]){m=Sb(n);var u=n.getAttribute("data-content-type");g.some(x=>x.id===r)||h.includes(m)||l.includes(m)||k.includes(u)&&g.push({item:n,id:r})}});return g},async Sl(b=null,c="",e="0"){b={mod:"packages",
f:e,fq:b||-1,qry:"",page:1,sh:U("sh")};c&&""!==c.trim()&&(b.qry=c.trim());c=await jQuery.get(G(b));b=jQuery(c).find(".paging_right_full");c=1;0<b.length&&(b=b.last().attr("href"))&&(b=b.match(/page=(\d+)(?!.*page=)/))&&b[1]&&(c=parseInt(b[1],10));return c},Tl(b){const c="true"===localStorage.getItem("smeltAnything"),e=JSON.parse(localStorage.getItem("smeltingSettings"))||[],g=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||[];if(!c&&!c&&0===e.length)return!1;const k=Sb(b),h=parseInt(b.getAttribute("data-level"),
10),l=ub(b),n=parseInt(nb(b),10);var m=this.Nn(b),r=b.getAttribute("data-basis");m=b.getAttribute("data-hash");b.getAttribute("data-level");r=Eb(r,m);m=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]");const u=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");if(m.includes(k)||u.includes(k))return!1;for(let x of e)if(m=x.hammerState||"none",x.isEnabled&&this.Cn(b,x,{itemName:k,itemLevel:h,itemType:l,itemQuality:n,itemHammerState:m,isUnderworldItem:r}))return x;if(c){if(g.itemTypes&&
0<g.itemTypes.length&&!g.itemTypes.map(x=>parseInt(x,10)).includes(parseInt(l,10)))return!1;if(g.colors&&0<g.colors.length){const x={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(x).find(q=>x[q]===n);if(!g.colors.includes(b))return!1}return g}return null},Cn(b,c,e){b=e.itemName;const g=e.itemLevel,k=e.itemType,h=e.itemQuality;e=e.isUnderworldItem;if("nameContains"===c.condition){e=!0;if(0===c.prefix.length&&0===c.suffix.length)return!1;c.prefix&&0<c.prefix.length&&b&&0<b.length&&
!b.toLowerCase().includes(c.prefix.toLowerCase())&&(e=!1);c.suffix&&0<c.suffix.length&&b&&0<b.length&&!b.toLowerCase().includes(c.suffix.toLowerCase())&&(e=!1);c.prefix&&0<c.prefix.length&&c.suffix&&0<c.suffix.length&&(!(b&&0<b.length)||b.toLowerCase().includes(c.prefix.toLowerCase())&&b.toLowerCase().includes(c.suffix.toLowerCase())||(e=!1));if(!e)return!1}else if("isUnderworldItem"===c.condition&&!e)return!1;if(!(g<(c.level?parseInt(c.level,10):0))&&c.itemTypes&&0<c.itemTypes.length){if(!c.itemTypes.includes("9999")&&
!c.itemTypes.map(l=>parseInt(l)).includes(parseInt(k,10)))return!1}else return!1;if(c.colors&&0<c.colors.length){const l={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(l).find(n=>l[n]===h);if(!c.colors.includes(b))return!1}else return!1;return c},am:function(b,c,e){c=jQuery("<button>").html(c).addClass(e);jQuery(b).append(c);return c},async move(){var b="513";b=(b=localStorage.getItem("smeltTab"))?(513+parseInt(b,10)).toString():"513";this.slots.filter(g=>"closed"===g["forge_slots.state"]).map(g=>
g["forge_slots.slot"]).shift();try{let g=ha.m.pop();var c=Cc(ha.bag);let k=Dc(5,8,c),h=parseInt(g.item.getAttribute("data-measurement-x")),l=parseInt(g.item.getAttribute("data-measurement-y")),n=Ec(l,h,k);c=b;if(n){await jQuery.post(R({mod:"inventory",submod:"move",from:"-"+g.id,fromX:"1",fromY:"1",to:c,toX:n.x+1,toY:n.y+1,amount:"1"}),{a:(new Date).getTime(),sh:U("sh")});var e=jQuery(g.item).css({left:32*n.x,top:32*n.y});ha.bag.appendChild(e[0]);0<ha.m.length||g?(localStorage.setItem("smeltCheck.timeOut",
0),await new Promise(m=>setTimeout(m,500)),await this.move()):window.location.reload()}else 0<ha.m.length?(localStorage.setItem("smeltCheck.timeOut",0),await new Promise(m=>setTimeout(m,500)),await this.move()):window.location.reload()}catch(g){window.location.reload()}}};window.location.href.includes("index.php?mod=mysterybox")&&(Mh(),Nh());window.location.href.includes("/index.php?mod=forge&submod=smeltery")&&(ha.init(),ha.slots=await ha.u(),await ha.vm(ha.slots),"true"==localStorage.getItem("activateSmeltMode")&&
ha.Dm());try{window.location.href.includes("/index.php?mod=location&submod=serverQuest")&&(window.location.href.includes("submod=serverQuestHighscore&loc=hadrians_wall")||localStorage.setItem("eventPoints_",parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10)))}catch{localStorage.setItem("doEventExpedition",!1);Cf("mod=overview");return}try{if(window.location.href.includes("/index.php?mod=work")){let b=document.querySelector('span[data-ticker-type="countdown"]');
if(b){let c=b.innerText.split(":"),e=6E4*(60*parseInt(c[0],10)+parseInt(c[1],10));await new Promise(g=>setTimeout(g,e))}}}catch{Cf("mod=overview");return}const oj={async start(){const b=await Promise.all([new Promise(c=>{jQuery.get(G({mod:"overview",doll:"1",sh:U("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");c(!e)})}),new Promise(c=>{jQuery.get(G({mod:"overview",doll:"2",sh:U("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");
c(!e)})})]);b[0]&&X("CheckDolls",1);b[1]&&X("CheckDolls",1)}},bf={async check(b=!1){return new Promise(async c=>{await new Promise(e=>{jQuery.get(G({mod:"overview",doll:"1",sh:U("sh")}),g=>{localStorage.setItem("arenaCostumeEquiped",jQuery(g).find(".avatar")[0].classList.contains("avatar_costume_part"));e()})});b&&await b();c()})},async start(){if("mod=costumes"!=lf)Cf("mod=costumes");else{let e=localStorage.getItem("costumeUnderworld"),g=localStorage.getItem("costumeUnderworld");const k="true"===
localStorage.getItem("wearUnderworld");var b=!1;let h=document.querySelectorAll(".costumes_box"),l=!1,n;const m=localStorage.getItem("costumeUnderworld");b=["9","10","11"];const r=JSON.parse(localStorage.getItem("underworld"));for(var c of b)try{const u=h[Number(c)-1].querySelector(".costumes_button_single").getAttribute("onclick");if(u&&!u.includes("dropCostume")){l=!0;break}}catch(u){}0<h.length&&null!==m&&(c=Number(m)-1,0<=c&&c<h.length&&(c=h[c].querySelector(".costumes_button_single")||h[c].querySelector(".costumes_button_active_single"))&&
(n=c.getAttribute("onclick")));["9","10","11"].includes(e)&&n&&n.includes("dropCostume")?(b=!0,r.Zi=!0,localStorage.setItem("underworld",JSON.stringify(r)),X("CheckDolls",15)):(b=!1,r.Zi=!1,localStorage.setItem("underworld",JSON.stringify(r)));b?(X("CheckDolls",30),window.location.reload()):await this.check(async()=>{let u=[];if(k){let x=0;const q=["9","10","11"];for(let t of q)try{const w=h[Number(t)-1].querySelector(".costumes_button_single")?.getAttribute("onclick");if(w&&!w.includes("dropCostume")){l=
!0;const y=Number(m)-1;0<=y&&y<h.length&&(l=h[y].querySelector(".costumes_button_single")||h[y].querySelector(".costumes_button_active_single")?!0:!1);if(l&&"9"===g&&2>=Number(zh().Ea)){u.push({doll:1,setId:Number(g)+2});break}if(l&&"10"===g&&2>=Number(zh().Dn)){u.push({doll:1,setId:Number(g)+2});break}if(l&&"11"===g){u.push({doll:1,setId:Number(g)+2});break}}}catch(w){x++}x===q.length&&C(`${d.mf}`)}try{if(!l){const x=h[Number(localStorage.getItem("costumeBasic")-1)].querySelector("#costumes_button_left input"),
q=x.getAttribute("onclick");x.classList.contains("disabled")||q.includes("dropCostume")||u.push({doll:1,setId:localStorage.getItem("costumeBasic")});if(8>=Number(localStorage.getItem("costumeDungeon"))){const t=h[Number(localStorage.getItem("costumeDungeon")-1)].querySelector("#costumes_button_right input"),w=t.getAttribute("onclick");t.classList.contains("disabled")||w.includes("dropCostume")||u.push({doll:2,setId:localStorage.getItem("costumeDungeon")})}}if(0<u.length){let {doll:x,setId:q}={...u.pop()};
(await fetch(G({mod:"costumes",submod:"changeCostume",doll:x,setId:q,sh:U("sh")}))).ok&&0<u.length&&9>Number(q)&&await bf.Jm(u);X("CheckDolls",30)}else X("CheckDolls",15);window.location.reload()}catch{X("CheckDolls",15),window.location.reload(),C("Problem occurred while wearing a costume.")}})}},async Jm(b,c=!1){let {doll:e,setId:g}={...b.pop()};await new Promise(k=>{jQuery.get(G({mod:"costumes",submod:"changeCostume",doll:e,setId:g,sh:U("sh")}),()=>{0<b.length?bf.Jm(b,c):(X("CheckDolls",15),k())})})}};const z2 = localStorage.getItem("we");we = new Date(z2);
fa<new Date&&we<new Date&&da!=ua&&eb();if(pa&&"true"===localStorage.getItem("guildBattleEnable")&&W("guildBattleEnable"))try{const b="true"===localStorage.getItem("guildBattleRandom"),c=JSON.parse(localStorage.getItem("guildKeywords"))||[],e=await jQuery.get(G({mod:"guild_warcamp",sh:U("sh")})),g=(new DOMParser).parseFromString(e,"text/html"),k=g.querySelectorAll('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]'),h=g.querySelectorAll("table.section-like tr:not(:first-child)");let l=null;0<h.length&&0<c.length?
h.forEach(n=>{const m=n.querySelector('td a[href*="mod=guild"]');n=n.querySelector('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]');if(m&&n){const r=m.textContent.trim().toLowerCase();c.some(u=>r.includes(u.toLowerCase()))&&(l=n.getAttribute("href"))}}):b&&(l=k[Math.floor(Math.random()*k.length)].getAttribute("href"));if(l){const n=new URLSearchParams(l),m=n.get("gid"),r=n.get("sh");try{await jQuery.post(G({mod:"guild_warcamp",submod:"guild_combat",gid:m,sh:r}),{combat:"Attack!"});C(`Guild attack initiated against guild ID: ${m}`);
const u=JSON.parse(localStorage.getItem("Timers"))||{};X("guildBattleEnable",u.guildBattleEnable||120)}catch(u){C("Error initiating guild attack")}}else C("No matching guilds found for the provided guild names.")}catch(b){C("Error loading guild warcamp page")}if(pa&&"true"===localStorage.getItem("GuildEnable")&&W("GuildDonate")){const b=parseInt(localStorage.getItem("GuildDonateMore")||0,10),c=parseInt(localStorage.getItem("GuildDonateLess")||0,10),e=parseInt(localStorage.getItem("GuildDonateAmount")||
0,10);if(aa.gold>=b&&aa.gold<=c){await jQuery.post(G({mod:"guildBankingHouse",submod:"donate",sh:U("sh")}),{donation:e,doDonation:"Donate"});C(`${d.qf} ${e}.`);const g=JSON.parse(localStorage.getItem("Timers"));X("GuildDonate",g.GuildDonate||5)}}"true"===localStorage.getItem("throwDice")&&W("throwDice")&&"true"==sessionStorage.getItem("autoGoActive")&&(jQuery.post(window.location.protocol+"//"+window.location.host+"/game/ajax/craps.php",{type:"1",a:(new Date).getTime(),sh:U("sh")}),C(`${d.pf}`),X("throwDice",
10));if(W("sortSettings")&&"true"==sessionStorage.getItem("autoGoActive")){const b=await jQuery.get(G({mod:"settings",submod:"gameSettings",sh:U("sh")})),c=(new DOMParser).parseFromString(b,"text/html").querySelector('select[name="packageSorting"]');let e="in_desc";if(c){const g=c.querySelector("option[selected]");e=g?g.value:"in_desc"}X("sortSettings",30);localStorage.setItem("PackageSort",e)}if(window.location.href.includes("index.php?mod=location&loc=")){let b=0,c=!1;const e=()=>{fetch(window.location.href).then(m=>
m.text()).then(m=>{m=(new DOMParser).parseFromString(m,"text/html");if(m=Array.from(m.querySelectorAll("img[data-tooltip]")).find(r=>{const u=r.getAttribute("data-tooltip").toLowerCase();return["owned","sahip","propri","posiad","posees"].some(x=>u.includes(x))}))m=(m=m.getAttribute("data-tooltip").match(/(Owned|Sahip[^:]*|Propri[^:]*|Posiad[^:]*|Posees[^:]*): (\d+)/i))?parseInt(m[2],10):100,document.getElementById("hourglassesLeft").textContent=m,localStorage.setItem("hourglassesLeft",m)}).catch(()=>
{C("No hourglass left")})},g=(m,r,u,x,q,t)=>{function w(F){return new Promise((I,K)=>{fetch(`${A}/game/index.php?mod=premium&submod=inventory&sh=${B}`).then(M=>M.text()).then(M=>{if(M=(new DOMParser).parseFromString(M,"text/html").querySelector(`div.premiumfeature_picture > img[src*="${F}"] + .premiumfeature_tokencount`))return M.textContent.trim();throw Error("Token value not found!");}).then(M=>fetch(`${A}/game/index.php?mod=premium&submod=inventoryActivate&feature=${"5fd403b4efa8ea7bc3ca5a852bfce9"===
F?18:5}&token=${M}&sh=${B}`)).then(()=>{I()}).catch(M=>{K(M)})})}if(!c||b>=t)h();else{var y=new URL(window.location.href),A=y.origin,B=y.searchParams.get("sh")||"",v=document.getElementById("useLifePotion").checked;x=document.getElementById("useMobilizationExp2").checked;var D=parseInt(document.getElementById("healPercentage2").value,10);y=new URLSearchParams({mod:"location",submod:"attack",location:m,stage:r,premium:u?1:0,a:Date.now(),sh:B});fetch(`${A}/game/ajax.php?${y.toString()}`).then(F=>F.text()).then(()=>
{(v||x)&&fetch(window.location.href).then(F=>F.text()).then(async F=>{F=(new DOMParser).parseFromString(F,"text/html");if(v){const I=parseInt(F.getElementById("header_values_hp_percent").textContent,10);if(Number(I)<Number(D))return await w("5fd403b4efa8ea7bc3ca5a852bfce9")}if(x&&(F=F.getElementById("expeditionpoints_value_point").innerText,0===Number(parseInt(F.replace("%",""),10))))return await w("c9ce614bbc67a9e85aa0ee87cf2bb7")}).then(async()=>{b++;b>=Number(t)?(h(),window.location.reload()):
(document.getElementById("attacksPerformed").textContent=b,localStorage.setItem("attackCount",b),await e(),setTimeout(async()=>{await g(m,r,u,x,q,t)},1E3*q))}).catch(()=>{})})}},k=async()=>{c=!0;document.getElementById("startExpedition").style.display="none";document.getElementById("stopExpedition").style.display="block";const m=(new URLSearchParams(window.location.search)).get("loc"),r=document.getElementById("monsterSelection").value,u=document.getElementById("useHourglass").checked,x=document.getElementById("attackInterval").value,
q=document.getElementById("numberOfAttacks").value;await g(m,r,u,useMobilizationExp2,x,q)},h=()=>{c=!1;document.getElementById("startExpedition").style.display="block";document.getElementById("stopExpedition").style.display="none"},l=()=>{var m=document.createElement("div");m.innerHTML=`
    <div class="expedition-settings">
      <h2 class="section-header">${d.Be}</h2>
      <div class="expedition-settings-content">
        <div>
            <label>${d.ye}: </label>
            <select id="monsterSelection">
            <option value="1">${d.qe}</option>
            <option value="2">${d.re}</option>
            <option value="3">${d.se}</option>
            <option value="4">${d.te}</option>
            </select>
            <br>
            <label>${d.me}: </label>
            <input type="checkbox" id="useHourglass">
            <br>
            <label>${d.pe}: </label>
            <input type="checkbox" id="useMobilizationExp2">
            <br>
            <label>${d.oe}: </label>
            <input type="checkbox" id="useLifePotion">
            <br>
            <label>${d.le}: </label>
            <input type="number" id="healPercentage2" value="25" min="1" max="99">
            <br>
            <label>${d.we}: </label>
            <input type="number" id="numberOfAttacks" value="${document.getElementById("expeditionpoints_value_point").textContent||"0"}" min="1" max="36">
            <br>
            <label>${d.ne}: </label>
            <input type="number" id="attackInterval" value="5" min="1" max="60">
            <br>
            <button id="startExpedition" class="expedition-button">${d.ze}</button>
            <button id="resetAttacks" class="expedition-button reset-button">${d.xe}</button>
            <button id="stopExpedition" class="expedition-button" style="display: none;">${d.Ae}</button>
            <div id="attackLog"></div>
        </div>
      </div>
    </div>
  `;var r=document.querySelector(".section-header");r.parentNode.insertBefore(m,r);m.querySelector(".section-header").addEventListener("click",()=>{const u=document.querySelector(".expedition-settings-content"),x="none"===u.style.display;u.style.display=x?"block":"none";localStorage.setItem("expeditionSettingsHidden",x?"false":"true")});m=m.querySelector(".expedition-settings-content");r="true"===localStorage.getItem("expeditionSettingsHidden");m.style.display=r?"none":"block";document.getElementById("resetAttacks").addEventListener("click",
()=>{b=0;localStorage.removeItem("attackCount");document.getElementById("attacksPerformed").textContent=b});document.getElementById("startExpedition").addEventListener("click",k);document.getElementById("stopExpedition").addEventListener("click",h);b=parseInt(localStorage.getItem("attackCount")||"0");document.getElementById("attackLog").innerHTML=`
            ${d.je}: <span id="attacksPerformed">${b}</span><br>
            ${d.ke}: <span id="hourglassesLeft">${localStorage.getItem("hourglassesLeft")||"0"}</span><br>
            <span class="span-new">${d.ue}</span><br>
            <span class="span-new">${d.ve}</span>

            `};if(window.location.href.includes("index.php?mod=location&loc=")&&!window.location.href.includes("location&loc=nile_bank")&&!window.location.href.includes("index.php?mod=location&loc=false")&&!window.location.href.includes("location&loc=desert")){const m=document.querySelector("#wrapper_game.underworld");(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld||m||l()}const n=document.createElement("style");n.innerHTML="\n  .expedition-settings {\n    border: 2px solid #4CAF50;\n    padding: 10px;\n    margin: 10px 0;\n    background-color: #d3c195;\n    border-radius: 5px;\n  }\n  .expedition-button {\n    border: none;\n    padding: 10px 20px;\n    text-align: center;\n    text-decoration: none;\n    display: inline-block;\n    font-size: 16px;\n    margin: 10px;\n    background-color: #a09270;\n    cursor: pointer;\n    border-radius: 5px;\n  }\n\n  .reset-button {\n    background-color: #f44336; /* Red color */\n  }\n\n  .expedition-button:disabled {\n    background-color: #ccc;\n    cursor: not-allowed;\n  }\n";
document.head.appendChild(n)}if(window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&submod=showDungeons")||window.location.href.includes("index.php?mod=reports&submod=showArena")||window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")){let b=document.createElement("div");b.id="ReportSearchUI";b.innerHTML='\n        <div class="setting-row">\n            <h5>GLDbot - Search in Reports</h5>\n            <span>Searches for reports containing the specified keyword and gold amount. Limit 15 pages.</span>\n            <br>\n            <div class="input-container">\n                <input type="text" id="searchReports" placeholder="Enter keyword">\n                <input type="number" id="goldFilter" placeholder="Minimum gold">\n                <button class="awesome-button" id="searchReportsButton">Search</button>\n            </div>\n        </div>\n    ';
const c=document.querySelector("#content");c.insertBefore(b,c.firstChild);document.getElementById("searchReportsButton").addEventListener("click",async()=>{const h=document.getElementById("searchReports").value,l=parseInt(document.getElementById("goldFilter").value,10)||0,n=document.getElementById("searchReportsButton");n.disabled=!0;try{await e(h,l)}finally{n.disabled=!1}});async function e(h,l){let n=1;var m=await jQuery.get(window.location.href);m=jQuery(m).find(".paging_right_full");0<m.length&&
(m=m.last().attr("href"))&&(m=m.match(/page=(\d+)(?!.*page=)/))&&m[1]&&(n=parseInt(m[1],10));m=[];for(let u=1;u<=n&&15>=u;u++){var r=await g(u);r=k(r,h,l);0<r.length&&(m=m.concat(r))}if(0<m.length){const u=document.querySelector(".table-container tbody");u.innerHTML="";m.forEach(x=>{u.appendChild(x)})}}async function g(h){let l="";window.location.href.includes("index.php?mod=reports&submod=showArena")?l="showArena":window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")?l="showCircusTurma":
window.location.href.includes("index.php?mod=reports&submod=showDungeons")?l="showDungeons":window.location.href.includes("index.php?mod=reports&showExpeditions")&&(l="showExpeditions");h=G({mod:"reports",submod:l,page:h,sh:U("sh")});return await jQuery.get(h)}function k(h,l,n){let m=[];jQuery(h).find(".table-container tr").each((r,u)=>{var x=jQuery(u);r=window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&showDungeons")?x.find("td").eq(1).text().trim():
x.find("td").eq(1).find("a").first().text().trim();x=x.find("td").eq(2).text().trim().replace(/[.,]/g,"");x=parseInt(x,10)||0;r.toLowerCase().includes(l.toLowerCase())&&x>=n&&m.push(u)});return m}}if(window.location.href.includes("/index.php?mod=overview&doll=2")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(c=>Sb(c));localStorage.setItem("mercenaryEquipmentIDs",JSON.stringify(b))}else if(window.location.href.includes("/index.php?mod=overview")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(c=>
Sb(c));localStorage.setItem("playerEquipmentIDs",JSON.stringify(b))}if(window.location.href.includes("/index.php?mod=inventory&sub")&&document.querySelector('td[valign="top"]')){let b=!0;async function c(){var r=document.getElementById("sortCriteria");let u=Array.from(r.selectedOptions).map(w=>w.value),x=document.getElementById("shop");r=Array.from(x.querySelectorAll(".ui-draggable")).map(w=>{let y=Sb(w),A=parseInt(w.getAttribute("data-level"),10)||0,B=w.getAttribute("data-basis")||"",v=parseInt(B.split("-")[1],
10)||0,D=parseInt(w.getAttribute("data-quality"),10)||0,F=parseInt(w.getAttribute("data-content-type"),10)||0,I=parseInt(w.getAttribute("data-measurement-x"),10)||1,K=parseInt(w.getAttribute("data-measurement-y"),10)||1;return{element:w,name:y,level:A,Wb:B,type:F,Im:v,quality:D,measurementX:I,measurementY:K,qp:parseInt(w.getAttribute("data-position-x"),10),rp:parseInt(w.getAttribute("data-position-y"),10)}});r.sort((w,y)=>{for(let A of u){let B;switch(A){case "name":B=w.name.localeCompare(y.name);
break;case "level":B=w.level-y.level;break;case "data-basis":B=w.Im-y.Im;break;case "quality":B=w.quality-y.quality;break;case "type":B=w.type-y.type;break;default:B=0}if(0!==B)return B}return 0});let q=0,t=0;for(let w of r)w.element.setAttribute("data-position-x",q+1),w.element.setAttribute("data-position-y",t+1),w.element.style.left=`${32*q}px`,w.element.style.top=`${32*t}px`,q+=w.measurementX,6<=q&&(q=0,t+=1);x.innerHTML="";r.forEach(w=>{x.appendChild(w.element)})}(function(){let r=`
                <section class="merchant-settings" style="display: block;">
                    <div class="sorting-options">
                        <label for="sortCriteria">Sort Items By:</label>
                        <select id="sortCriteria">
                            <option value="name">Name</option>
                            <option value="level">Level</option>
                            <option value="data-basis">Base</option>
                            <option value="type">Type</option>
                            <option value="quality">Quality</option>
                        </select>
                        <button class="awesome-button" type="button" id="sortItemsButton">Sort Items</button>
                        
                    </div>
                    <p>
                    <div class="actions">
                        <button class="awesome-button" type="button">${d.wj}</button>
                        <button class="awesome-button" type="button">${d.xj}</button>
                        <button class="awesome-button" type="button">Buy All</button>
                        <button class="awesome-button" type="button">Buy 10</button>
                    </div>
                    <ul class="compact-list">
                        <li><input type="checkbox" id="chkWeapons"><label for="chkWeapons">${d.ja}</label></li>
                        <li><input type="checkbox" id="chkShields"><label for="chkShields">${d.ga}</label></li>
                        <li><input type="checkbox" id="chkChestArmour"><label for="chkChestArmour">${d.W}</label></li>
                        <li><input type="checkbox" id="chkHelmets"><label for="chkHelmets">${d.Z}</label></li>
                        <li><input type="checkbox" id="chkGloves"><label for="chkGloves">${d.Y}</label></li>
                        <li><input type="checkbox" id="chkShoes"><label for="chkShoes">${d.ha}</label></li>
                        <li><input type="checkbox" id="chkRings"><label for="chkRings">${d.ea}</label></li>
                        <li><input type="checkbox" id="chkAmulets"><label for="chkAmulets">${d.V}</label></li>
                        <li><input type="checkbox" id="chkUsable"><label for="chkUsable">${d.ni}</label></li>
                        <li><input type="checkbox" id="chkUpgrades"><label for="chkUpgrades">${d.mi}</label></li>
                        <li><input type="checkbox" id="chkRecipes"><label for="chkRecipes">${d.Qg}</label></li>
                        <li><input type="checkbox" id="chkMercenary"><label for="chkMercenary">${d.gg}</label></li>
                        <li><input type="checkbox" id="chkScroll"><label for="chkScroll">Scroll</label></li>
                        <li><input type="checkbox" id="chkReinforcements"><label for="chkReinforcements">${d.Sg}</label></li>
                    </ul>
                </section>
                `;document.getElementById("inv").insertAdjacentHTML("afterend",r)})();async function e(){if(b){var r=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(u=>{u=u.getAttribute("data-content-type");if(document.getElementById("chkWeapons").checked&&"2"==u||document.getElementById("chkShields").checked&&"4"==u||document.getElementById("chkChestArmour").checked&&"8"==u||document.getElementById("chkHelmets").checked&&"1"==u||document.getElementById("chkGloves").checked&&"256"==
u||document.getElementById("chkShoes").checked&&"512"==u||document.getElementById("chkRings").checked&&"48"==u||document.getElementById("chkAmulets").checked&&"1024"==u||document.getElementById("chkUsable").checked&&"4096"==u||document.getElementById("chkUpgrades").checked&&"4096"==u||document.getElementById("chkRecipes").checked&&"8192"==u||document.getElementById("chkMercenary").checked&&"16384"==u||document.getElementById("chkScroll").checked&&"64"==u||document.getElementById("chkReinforcements").checked&&
"4096"==u)return!0;if(b)return!1});for(let u=0;u<r.length&&b;u++)await new Promise(x=>setTimeout(x,200)),Aa(r[u],"shop")}}async function g(){if(b){var r=document.querySelectorAll("#inv .ui-draggable");for(let u=0;u<r.length;u++)await new Promise(x=>setTimeout(x,200)),Aa(r[u],"shop")}}async function k(){if(b){var r=document.querySelectorAll("#shop .ui-draggable");for(let u=0;u<r.length;u++)await new Promise(x=>setTimeout(x,200)),Aa(r[u],"inv")}}async function h(){if(b){var r=document.querySelectorAll("#shop .ui-draggable");
for(let u=0;10>u;u++)await new Promise(x=>setTimeout(x,200)),Aa(r[u],"inv")}}let l=document.querySelector(".actions .awesome-button:nth-child(2)"),n=document.querySelector(".actions .awesome-button:nth-child(3)"),m=document.querySelector(".actions .awesome-button:nth-child(4");document.querySelector(".actions .awesome-button:nth-child(1)").addEventListener("click",async()=>{b=!0;await new Promise(r=>setTimeout(r,500));g()});l.addEventListener("click",async()=>{b=!0;await new Promise(r=>setTimeout(r,
500));e()});n.addEventListener("click",async()=>{await new Promise(r=>setTimeout(r,500));k()});m.addEventListener("click",async()=>{await new Promise(r=>setTimeout(r,500));h()});document.getElementById("sortItemsButton").addEventListener("click",async()=>{await new Promise(r=>setTimeout(r,500));await c()})}if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll"))if($e=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),
sb=$e.textContent.trim(),2<sb.length){af=document.getElementById("char");function b(c,e,g,k){var h=document.createElement("a");h.className="gladbot-button gladbot-"+c;h.textContent=e;h.setAttribute("data-tooltip",g);af.appendChild(h);(JSON.parse(localStorage.getItem(k))||[]).includes(sb)&&(h.classList.add("added"),h.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));h.addEventListener("click",function(){var l=sb,n=JSON.parse(localStorage.getItem(k))||[],m=n.indexOf(l);
-1!==m?(n.splice(m,1),h.classList.remove("added"),h.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(n.push(l),h.classList.add("added"),h.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));localStorage.setItem(k,JSON.stringify(n))})}b("arena","A","GladB: Add to Arena List","autoAttackList");b("circus","C","GladB: Add to Circus List","autoAttackCircusList")}let Mc=JSON.parse(localStorage.getItem("smeltingSettings"))||[],Ea=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||
{itemTypes:[],colors:[],hammerState:"none",enabled:!1},ac=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]};"true"==localStorage.getItem("pauseBotEnable")&&W("pauseBot")&&(sessionStorage.setItem("autoGoActive","false"),localStorage.setItem("pauseBotEnable","false"),alert("Bot has been paused!"),window.location.reload());1==pa&&W("storeForgeResources")&&Ui();!0===pa&&W("Training")&&"true"==localStorage.getItem("trainEnable")&&Wi()&&Vi();"true"===sessionStorage.getItem("autoGoActive")&&$a.href.includes("submod=showCombatReport")&&
Xi();if("true"===localStorage.getItem("HighlightUnderworldItems")){function b(e){e.querySelectorAll("div[data-basis]").forEach(g=>{const k=g.getAttribute("data-basis"),h=g.getAttribute("data-hash");g.getAttribute("data-level");null!=k&&Eb(k,h)&&(g.style.boxShadow="0 0 0.1px 2px red")})}b(document);const c=new MutationObserver(e=>{e.forEach(g=>{g.addedNodes&&g.addedNodes.forEach(k=>{1===k.nodeType&&b(k)})});c.disconnect()});c.observe(document.body,{childList:!0,subtree:!0});document.querySelectorAll(".awesome-tabs").forEach(e=>
{e.addEventListener("click",()=>{setTimeout(()=>{b(document)},500)})})}if("true"==localStorage.getItem("AutoAuction")){const b=JSON.parse(localStorage.getItem("searchTerms")||"[]"),c=JSON.parse(localStorage.getItem("SearchTypes")||"[]"),e=JSON.parse(localStorage.getItem("Timers")),g=new DOMParser;function k(m,r,u){let x=[],q=[];Array.from(m).forEach(t=>{const w=t.getAttribute("data-tooltip");var y=t.getAttribute("data-content-type");const A=t.getAttribute("data-quality"),B=r.some(v=>{const D=Xe(w);
return D?D.toLowerCase().split(/\s+/).includes(v.toLowerCase()):!1});y=u.includes("9999")||u.includes(y);"2"==A||"3"==A?q.push(t):B&&y&&x.push(t)});return{dn:x,gn:q}}if(W("ShopSearch")){const m=await Ff();let r=[],u=[];for(const t of m){const w=k(t.querySelectorAll("#shop .ui-draggable"),b,c);w.dn.forEach(y=>{y.setAttribute("data-original-url",t.sm)});w.gn.forEach(y=>{y.setAttribute("data-original-url",t.sm)});r=r.concat(w.dn);u=u.concat(w.gn)}const x=r.map(t=>t.outerHTML);localStorage.setItem("MatchingShopItems",
JSON.stringify(x));const q=u.map(t=>t.outerHTML);localStorage.setItem("UniqueShopResults",JSON.stringify(q));X("ShopSearch",e.SearchTimer||5)}if(W("AuctionSearch")){const m=await bh(),r=await bh(3),u=t=>Array.from(t.querySelectorAll('#auction_table [class^="item-i-"]')).filter(w=>{const y=w.getAttribute("data-tooltip");var A=w.getAttribute("data-content-type");w=b.some(B=>{const v=Xe(y);return v?v.toLowerCase().split(/\s+/).includes(B.toLowerCase()):!1});A=c.includes("9999")||c.includes(A);return w&&
A}),x=u(m);localStorage.setItem("MatchingAuctionItems",JSON.stringify(x.map(t=>t.outerHTML)));const q=u(r);localStorage.setItem("MatchingMercAuctionItems",JSON.stringify(q.map(t=>t.outerHTML)));X("AuctionSearch",e.SearchTimer||5)}function h(m,r,u){const x=document.createElement("div");x.setAttribute("id",u);x.classList.add("search_results_panel");var q=document.createElement("div");q.classList.add("panel-header");q.innerHTML=`<h2>${m}</h2>`;x.appendChild(q);x.style.cssText="\n                position: fixed;\n                left: 0;\n                top: 0;\n                width: 300px;\n                height: 400px; /* Set a default height */\n                overflow-y: auto; /* Allow both vertical and horizontal scrolling if needed */\n                overflow-x: hidden;\n                z-index: 500;\n                box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n                font-family: 'Arial', sans-serif;\n                background: rgba(221, 213, 180, 0.95);\n                background-size: cover;\n                border-radius: 8px;\n            ";
m=x.querySelector(".panel-header");m.style.cssText=`
                background-color: ${"auction_items_panel"===u?"#bead79":"#8b6a45"};
                padding: 10px;
                cursor: move; /* Set cursor to move only on the header */
                user-select: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            `;m.querySelector("h2").style.cssText="\n                margin: 0;\n                font-size: 16px;\n                color: #fff;\n            ";m=localStorage.getItem(`${u}_top`);q=localStorage.getItem(`${u}_left`);let t=localStorage.getItem(`${u}_width`),w=localStorage.getItem(`${u}_height`);m&&q?(x.style.top=m+"px",x.style.left=q+"px"):"auction_items_panel"===u?(x.style.top="50px",x.style.left="20px"):"shop_items_panel"===u&&(x.style.top="50px",x.style.left="350px");t&&(x.style.width=
t+"px");w&&(x.style.height=w+"px");n(x,u);r=l(r);x.appendChild(r);document.body.appendChild(x);x.style.maxHeight=`${window.innerHeight-100}px`}function l(m){const r=document.createElement("div");r.classList.add("items-container");m.forEach(({key:u,label:x})=>{const q=document.createElement("div");q.classList.add("section-header");q.textContent=x;r.appendChild(q);const t=document.createElement("div");t.classList.add("grid-container");t.style.display="grid";t.style.gridTemplateColumns="repeat(auto-fill, minmax(50px, 1fr))";
t.style.fp="5px";t.style.padding="10px";x=localStorage.getItem(u);(JSON.parse(x)||[]).forEach(w=>{const y=g.parseFromString(w,"text/html").body.firstChild.cloneNode(!0);y.style.left="";y.style.top="";y.style.position="relative";w=y.getAttribute("data-tooltip");var A=JSON.parse(w.replace(/&quot;/g,'"'));w=A[0][0][1].split(";")[0];const B=encodeURIComponent(A[0][0][0].split(" ")[0]);A=new URL(window.location.href);const v=A.origin,D=A.searchParams.get("sh")||"";A=document.createElement("div");A.classList.add("auction_item_div");
A.appendChild(y);A.style.border="2px solid "+w;A.style.borderRadius="4px";A.style.padding="2px";A.style.boxSizing="border-box";A.style.cursor="pointer";A.style.transform="scale(0.8)";A.addEventListener("click",()=>{var F=y.getAttribute("data-hash");localStorage.setItem("highlightedItemHash",F);if(["UniqueShopResults","MatchingShopItems"].includes(u)){if(F=y.getAttribute("data-original-url"))location.href=F}else F=`${v}/game/index.php?mod=auction&qry=${B}&itemLevel=1&itemType=0&itemQuality=-1&sh=${D}`,
"MatchingMercAuctionItems"===u&&(F+="&ttype=3"),location.href=F});t.appendChild(A)});r.appendChild(q);r.appendChild(t)});return r}function n(m,r){const u=m.querySelector(".panel-header");$(m).draggable({handle:u,Ro:"window",stop:function(x,q){localStorage.setItem(`${r}_top`,q.position.top);localStorage.setItem(`${r}_left`,q.position.left)}});$(m).resizable({gp:"n, e, s, w, ne, se, sw, nw",stop:function(x,q){localStorage.setItem(`${r}_width`,q.size.width);localStorage.setItem(`${r}_height`,q.size.height)}})}
(function(){document.querySelectorAll(".search_results_panel").forEach(m=>m.remove());h(`${d.Na}`,[{key:"MatchingAuctionItems",label:`${d.Na}`},{key:"MatchingMercAuctionItems",label:`${d.fg}`}],"auction_items_panel");h(`${d.Mb}`,[{key:"MatchingShopItems",label:`${d.Mb}`},{key:"UniqueShopResults",label:`${d.li}`}],"shop_items_panel")})()}if(document.hidden)try{chrome.runtime.sendMessage({Wm:!0,cm:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"})}catch(b){}3;const pj=btoa("autoGoActive"),
qj=btoa("false");await async function(){"0832c8d97d643585cc279054bdfa0905af9be2db498cb77a8b5c17f8fbbe943c"!==await Yi(ea)&&sessionStorage.setItem(atob(pj),atob(qj))}();setInterval(()=>{const b=JSON.parse(localStorage.getItem("timeConditions"))||[];if(b&&0<b.length&&Hc()){const c=new Date,e=`${String(c.getHours()).padStart(2,"0")}:${String(c.getMinutes()).padStart(2,"0")}`;b.forEach(g=>{g.start&&g.end&&(g.start>g.end?e>=g.start||e<=g.end:e>=g.start&&e<=g.end)&&("stop"===g.action?sessionStorage.setItem("autoGoActive",
"false"):"start"===g.action&&"false"===sessionStorage.getItem("autoGoActive")&&(sessionStorage.setItem("autoGoActive","true"),Ye()))})}},15E3);const Rb=(new Date).getTime();if(!ua!==Ic){"true"===localStorage.getItem("activateAuction2")&&kf();var cf={Em(b){let c=localStorage.getItem("MarketboughtItems");c?c=JSON.parse(c):c=[];c.push(b);localStorage.setItem("MarketboughtItems",JSON.stringify(c))},Ip(){var b=localStorage.getItem("boughtItems");b?b=JSON.parse(b):b=[];let c=document.getElementById("boughtItems");
for(;c.firstChild;)c.removeChild(c.firstChild);for(let e of b)b=document.createElement("option"),b.textContent=e,c.appendChild(b)},async wn(){var b=new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=parseInt(localStorage.getItem("MarketHoldGold"))||0;let g=localStorage.getItem("marketItems");g=g?JSON.parse(g):[];const k={Io:"1",Eo:"2",wo:"3",zo:"4",yo:"5",Fo:"8",Co:"6",uo:"9",Ho:"7",vo:"11",Go:"12",Bo:"13",Ao:"15",xo:"18",Po:"19",Do:"20"},h={pn:"-1",kn:"0",hn:"1",mn:"2",
ln:"3",nn:"4"};C(`${d.lf}`);const l={};if("true"===localStorage.getItem("marketOnlyFood"))c=await this.Km(c,e,"-1"),await this.Xm([],7,1,c,b);else{for(var n of g){const m=`${k[n.itemType]||"0"}-${h[n.Wl]||"0"}`;l[m]||(l[m]=[]);l[m].push(n)}n=g.map(m=>h[m.Wl]||"0");n=Math.min(...n);c=await this.Km(c,e,n);for(const [m,r]of Object.entries(l)){const [u,x]=m.split("-");await this.Xm(r,u,x,c,b)}}},async Km(b,c,e){const g="true"===localStorage.getItem("marketOnlyFood");let k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=0&fq=${e}`;
g&&(k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=7&fq=${e}`);c=await fetch(k).then(A=>A.text());b=new DOMParser;e=b.parseFromString(c,"text/html").querySelector(".standalone");c=1;e&&(c=parseInt(e.textContent.split("/")[1],10));e=[];const h=localStorage.getItem("MarketMaxFoodPrice")||1E5,l=localStorage.getItem("MarketMaxPerFoodPrice")||1E3,n=localStorage.getItem("MarketMinItemLevel")||1;let m=0;for(let A=1;A<=c;A++){var r=`${k}&p=${A}`;await new Promise(B=>setTimeout(B,250));r=await (await fetch(r)).text();
await new Promise(B=>setTimeout(B,250));r=b.parseFromString(r,"text/html").querySelectorAll("#market_item_table tr");for(let B of r){var u=B.querySelectorAll("td");if(u&&0<u.length&&(r=u[0].querySelector("div"))){var x=ub(r),q=nb(r),t=Sb(r),w=Cb(r);let v=r.getAttribute("data-item-id"),D=r.getAttribute("data-soulbound-to");u=parseInt(u[2].innerText.replace(/\./g,""),10);var y=parseInt(r.getAttribute("data-amount"),10)||1;y=u/y;if(g&&"64"===x&&u<=l&&(!D||null===D)&&Number(w)>=Number(n)){if(m+u>h)break;
m+=u;e.push({itemRarity:q,itemName:t,itemDataId:v,itemSoulbound:D,itemPrice:u,pricePerItem:y,page:A})}else g||(x=nb(r),q=Sb(r),t=r.getAttribute("data-item-id"),w=r.getAttribute("data-soulbound-to"),r=parseInt(r.getAttribute("data-amount"),10)||1,e.push({itemRarity:x,itemName:q,itemDataId:t,itemSoulbound:w,itemPrice:u,pricePerItem:u/r,page:A}))}}if(g&&m>=h)break}return e},async Xm(b,c,e,g,k){for(const h of g){const l=h.itemName;g=h.itemDataId;const n=h.itemSoulbound,m=h.itemPrice,r=h.pricePerItem,
u=h.page,x={pn:"-1",kn:"0",hn:"1",mn:"2",ln:"3",nn:"4"},q=localStorage.getItem("usePacks")||"false";"true"===localStorage.getItem("marketOnlyFood")?aa.gold>=m+k&&(!n||null===n)&&await jQuery.get(G({}),{mod:"market",buyid:g,sh:U("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:u,buy:"Buy"}).then(t=>{t=(new DOMParser).parseFromString(t,"text/html").getElementById("sstat_gold_val").innerText;t=parseInt(t.replace(/\./g,""),10);if(document.getElementById("sstat_gold_val").innerText=t)aa.gold=t;cf.Em(l);C(`Bought ${l} for ${m} gold`)}):
b.some(t=>{const w=x[t.Wl]||"0";return l.trim().toLowerCase().includes(t.Qm.trim().toLowerCase())&&e==w&&aa.gold>=m+k&&(!n||null===n||"BuySoulbound"===t.Soulbound&&n||"DontBuySoulbound"===t.Soulbound&&!n)&&(Number(t.maxPrice)>=m||"true"==q&&Number(t.maxPrice)>=r&&aa.gold>=m)})&&await jQuery.get(G({}),{mod:"market",buyid:g,sh:U("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:u,buy:"Buy"}).then(t=>{t=(new DOMParser).parseFromString(t,"text/html").getElementById("sstat_gold_val").innerText;t=parseInt(t.replace(/\./g,
""),10);if(document.getElementById("sstat_gold_val").innerText=t)aa.gold=t;cf.Em(l);C(`Bought ${l} for ${m} gold`)})}C(`${d.ob} in Market`)}};(window.location.href.includes("/index.php?mod=forge&submod=workbench")||window.location.href.includes("/index.php?mod=forge&doll=1&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=2&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=3&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=4&submod=workbench")||
window.location.href.includes("index.php?mod=forge&doll=5&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=6&submod=workbench"))&&$i();var rj={async start(){try{const b=sa.repairArena,c=sa.repairTurma;let e=this.F(),g=this.Mn(e),k=this.Um("itemList1"),h=this.Um("itemList2");const l=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];g?(await this.u(),await this.ho(g,l)):b&&0<k.length?await this.Mm("mod=overview&doll=1",sa.itemList1):c&&0<h.length&&await this.Mm("mod=overview&doll=2",
sa.itemList2)}catch(b){this.handleError()}},F(){let b=localStorage.getItem("workbenchItem");return b?JSON.parse(b):{selectedItem:{}}},Mn(b){try{return b.selectedItem&&0<Object.keys(b.selectedItem).length?b.selectedItem:!1}catch(c){return null}},Um(b){return(b=localStorage.getItem(b))?this.no(b):[]},no(b){try{let c=JSON.parse(b);return Array.isArray(c)&&c.every(e=>void 0===e)?[]:c}catch(c){return[]}},async Mm(b,c){lf!==b?Cf(b):(await this.u(),0<this.F().spaces?await this.Vl(c):this.an("workbench"))},
an(b){"space"===b?C("Not enough inventory space for repair. Retrying in 10 minutes."):"workbench"===b?C("Not enough empty slots in workbench. Retrying in 10 minutes."):"material"===b?C(`${d.nf}`):C("Repair: Retrying in 10 minutes.");b=JSON.parse(localStorage.getItem("Timers"));X("repair",b.Repair||10);window.location.reload()},async ho(b,c,e){switch(b.status){case "toWorkbench":await this.$i(b.iid);break;case "toFillGoods":0<c.length&&e.workbenchneededitems?await this.Ni(b.slot,-1,e.workbenchneededitems):
await this.Xb(b.slot);break;case "toPackage":await this.bj(b.slot);break;case "toBag":await this.aj();break;case "toInv":await this.Jl();break;case "workbenchToBag":await this.qm(b.slot)}},handleError(){localStorage.removeItem("workbenchItem");const b=JSON.parse(localStorage.getItem("Timers"));X("repair",b.Repair||10);window.location.reload()},async u(){try{const b=await jQuery.post(R({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:U("sh")});let c=this.F();
c.slots=JSON.parse(b).slots;c.spaces=c.slots.filter(e=>"closed"===e["forge_slots.state"]).length;c.freeSlots=c.slots.filter(e=>"closed"===e["forge_slots.state"]);localStorage.setItem("workbenchItem",JSON.stringify(c))}catch(b){}},async Vl(b){try{let c=b.shift();C(`${d.Ff}${c.name}`);C(`${d.rb}`);let {spot:e,bag:g}=await ec(c.Rm,c.Sm);const k=await jQuery.post(R({}),{mod:"inventory",submod:"move",from:c.container,fromX:1,fromY:1,to:g,toX:e.x+1,toY:e.y+1,amount:1,doll:c.doll,a:(new Date).getTime(),
sh:U("sh")});let h=this.F();h.selectedItem||(h.selectedItem={});Object.assign(h.selectedItem,{item:c,iid:JSON.parse(k).to.data.itemId,status:"toWorkbench",spot:e,bag:g});localStorage.setItem("workbenchItem",JSON.stringify(h));await this.$i(JSON.parse(k).to.data.itemId)}catch{C("Error repairing the item."),localStorage.setItem("workbenchItem",JSON.stringify({})),window.location.reload()}},async $i(b){try{C(`${d.qb}`);let c=this.F(),e=0;for(let k of c.slots||[])if("closed"===k["forge_slots.state"]){e=
k["forge_slots.slot"];break}const g=await jQuery.post(R({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:e,iid:b,amount:1,a:(new Date).getTime(),sh:U("sh")});c.slots=JSON.parse(g).slots;c.spaces=0;c.freeSlots=[];for(let k of c.slots)"closed"===k["forge_slots.state"]&&(c.spaces++,c.freeSlots.push(k));e=c.freeSlots.shift()["forge_slots.slot"];c.workbenchneededitems=JSON.parse(g).slots[e].formula.needed;localStorage.setItem("workbenchItem",JSON.stringify(c));Object.assign(c.selectedItem,
{slot:e,status:"toFillGoods"});await this.ko(e,b)}catch(c){C("Error moving the item to the workbench."+c)}},async ko(b,c){await jQuery.post(R({}),{mod:"forge",submod:"rent",mode:"workbench",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:U("sh")});c=this.F();Object.assign(c.selectedItem,{slot:b,status:"toFillGoods"});localStorage.setItem("workbenchItem",JSON.stringify(c));0<(JSON.parse(localStorage.getItem("ignoredMaterials"))||[]).length?await this.Ni(b,-1,c.workbenchneededitems):await this.Xb(b)},
async Ni(b,c,e){c=[];const g=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let k in e){const h=parseInt(k,10);0<e[k].amount&&!g.some(l=>parseInt(l,10)+18E3===h)&&c.push({type:h,amount:e[k].amount})}await this.kl(c,-1,b);await jQuery.post(R({mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")}));e=this.F();e.selectedItem.status="toPackage";localStorage.setItem("workbenchItem",JSON.stringify(e));await this.bj(b)},async kl(b,c=-1,e){for(let g=0;g<b.length;g++){let k=
c;const h=b[g].amount;for(b[g].type=b[g].type-18E3;k<=Number(localStorage.getItem("repairMaxQuality"));)try{await jQuery.post(R({mod:"forge",submod:"storageOut",type:b[g].type,quality:k,amount:h,a:(new Date).getTime(),sh:U("sh")}));await this.ll(b[g].type,k,e,h);break}catch(l){if(k++,k>Number(localStorage.getItem("repairMaxQuality")))break}}},async ll(b,c,e,g){let k=1,h=!1,l=this.F(),{bag:n,spot:m}=l.selectedItem||{};for(;!h&&5>=k;)try{const r=await jQuery.get(G({mod:"packages",f:18,fq:c,qry:"",page:k,
sh:U("sh")})),u=jQuery(r).find(".packageItem");0===u.length?k++:(u.each(async(x,q)=>{try{let t=jQuery(q).find(".ui-draggable"),w=Db(t[0]).split("-")[1],y=nb(t[0]),A=t.context.querySelector("input").getAttribute("value");if(Number(w)==Number(b)&&Number(y)==Number(c)){h=!0;try{const B=await jQuery.post(R({mod:"inventory",submod:"move",from:"-"+A,fromX:1,fromY:1,to:n,toX:m.x+1,toY:m.y+1,amount:g}),{a:(new Date).getTime(),sh:U("sh")}),v=JSON.parse(B).to.data.itemId;try{await jQuery.post(R({mod:"forge",
submod:"toWarehouse",mode:"workbench",slot:e,iid:v,amount:g,a:(new Date).getTime(),sh:U("sh")}))}catch(D){C(`Error moving material to workbench: ${D}`)}}catch(B){C(`Error moving material from package to bag: ${B}`)}return!1}}catch(t){C(`Error processing package item: ${t}`)}}),h||k++)}catch(r){C(`Error fetching materials from the package on page ${k}: ${r}`),k++}h||C(`Material of type ${b} and quality ${c} not found in packages.`)},async Xb(b,c=-1){let e=this.F();await jQuery.post(R({}),{mod:"forge",
submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:U("sh")});c<Number(localStorage.getItem("repairMaxQuality"))?await this.Xb(b,++c):(await jQuery.post(R({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")}),e.selectedItem.status="toPackage",localStorage.setItem("workbenchItem",JSON.stringify(e)),await this.bj(b))},async bj(b){C(`${d.Ef}`);let c=this.F();c.selectedItem.status="workbenchToBag";localStorage.setItem("workbenchItem",
JSON.stringify(c));let e;try{(e=1100*c.slots[b].formula.duration)||(e=12E3)}catch(g){e=12E3}await new Promise(g=>setTimeout(g,e));await this.qm(b)},async qm(b){let c=this.F();(await jQuery.post(R({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")})).includes("document.location.href=document.location.href")?(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.aj()):(Object.assign(c.selectedItem,{status:"workbenchToBag"}),
localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.qm(b))},async aj(b=1){C(`${d.rb}`);let c=this.F(),{item:e,bag:g,spot:k}=c.selectedItem,h=!1;try{const q=await jQuery.get(G({}),{mod:"packages",f:-1,fq:e.quality,qry:e.name,page:b,sh:U("sh")});let t=jQuery(q).find(".packageItem").toArray();0===t.length&&C(`No package items found on page: ${b}`);for(let w of t){let y=w.querySelector(".ui-draggable");Db(y).split("-");var l=nb(y),n=Sb(y);w.getAttribute("data-soulbound-to");var m=y.getAttribute("data-measurement-x"),
r=y.getAttribute("data-measurement-y"),u=w.querySelector("[data-container-number]").getAttribute("data-container-number"),x=w.querySelector('input[name="packages[]"]').value;if(n===e.name&&e.container===x||n===e.name&&u.includes(e.container)||n===e.name&&e.quality===l)h=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.bo(w,g,k,u,m,r)}3<b?this.handleError():h||await this.aj(++b,!0)}catch(q){C(`Error repairing the item. ${q}`),this.mo(),window.location.reload()}},
async bo(b,c,e,g,k,h){await ec(k,h,async(l,n)=>{await jQuery.post(R({}),{mod:"inventory",submod:"move",from:g,fromX:1,fromY:1,to:n,toX:l.x+1,toY:l.y+1,amount:1,a:(new Date).getTime(),sh:U("sh")});await this.Jl(g,l,n)})},async Jl(b,c,e){C("Trying to move repaired item to the equpiment.");b=this.F();let {item:g}=b.selectedItem;c=await jQuery.post(R({}),{mod:"inventory",submod:"move",from:e,fromX:c.x+1,fromY:c.y+1,to:g.container,toX:1,toY:1,amount:1,doll:g.doll,a:(new Date).getTime(),sh:U("sh")});c.includes(`"data":{"containerNumber":${g.container}`)?
(Object.assign(b.selectedItem,{status:"toInv"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),this.Kn(c,g)):(Object.assign(b.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),window.location.reload())},Kn(b,c){var e=this.F();delete e.selectedItem;localStorage.setItem("workbenchItem",JSON.stringify(e));let g,k;e=localStorage.getItem("repairPercentage")||10;try{g=JSON.parse(b).to.data.tooltip.pop().pop()[0].match(/\d+/g),k=Number(g[0])/Number(g[1])*100}catch(h){location.reload()}"x";
k<parseInt(e,10)?this.qo(c.container,2===c.doll):(C(`${d.Hf}`),N("itemRepaired",0));window.location.reload()},qo(b,c=!1){const e=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),k=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),h=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}"),l={2:"helmet",11:"necklace",3:"weapon",5:"armor",4:"shield",9:"gloves",10:"shoes",6:"rings1",7:"rings2"},n={2:"helmetM",
11:"necklaceM",3:"weaponM",5:"armorM",4:"shieldM",9:"glovesM",10:"shoesM",6:"rings1M",7:"rings2M"};b=c?n[b]:l[b];c?g[b]&&(g[b]=!1,h[b]=Date.now(),localStorage.setItem("activeItemsMercenary",JSON.stringify(g)),localStorage.setItem("disabledTimeMercenary",JSON.stringify(h))):e[b]&&(e[b]=!1,k[b]=Date.now(),localStorage.setItem("activeItemsGladiator",JSON.stringify(e)),localStorage.setItem("disabledTimeGladiator",JSON.stringify(k)))},mo(){this.an()}},nj={Ll:[],async lo(b){try{let e;const g=parseInt(localStorage.getItem("smeltTab"),
10)||1;C("Repairing before smelting, please wait...");1===g?e=514:2===g?e=515:3===g?e=516:4===g?e=517:5===g?e=518:6===g&&(e=519);const k=await this.Jn(b);if(k){var c=await this.$n(b);if(null===c)console.error("Failed to move item to workbench.");else return await this.xm(c),await this.so(c),await this.yn(c,e,k)}else console.error(`Item with ID ${b} not found in inventory.`)}catch(e){}},async Jn(b){let c=null;document.querySelectorAll("#inv .ui-draggable").forEach(e=>{if(e.getAttribute("data-item-id")===
b){const g=parseInt(e.getAttribute("data-position-x"),10)+1,k=parseInt(e.getAttribute("data-position-y"),10)+1,h=nb(e);e=Sb(e).toLowerCase();c={container:"inv",x:g,y:k,quality:h,name:e};return!1}});return c},async $n(b){const c=await this.Ln();if(null===c)return C("No available workbench slots. Continuing without repair."),!1;const e=await jQuery.post(R({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:c,iid:b,amount:1,a:(new Date).getTime(),sh:U("sh")});if("0"===(localStorage.getItem("PartialOrFull")||
"0"))try{this.Ll=JSON.parse(e).slots[c].formula.needed}catch{C("Error getting needed items for repair.")}await jQuery.post(R({}),{mod:"forge",submod:"rent",mode:"workbench",slot:c,rent:2,item:b,a:(new Date).getTime(),sh:U("sh")});return c},async Ln(){var b=await jQuery.post(R({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:U("sh")});b=JSON.parse(b).slots;let c=null;for(let e of b)if("closed"===e["forge_slots.state"]){c=e["forge_slots.slot"];break}return c},
async xm(b){"0"===(localStorage.getItem("PartialOrFull")||"0")&&0<Object.keys(this.Ll).length?await this.Ni(b):await this.In(b);await jQuery.post(R({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")})},async In(b){const c=localStorage.getItem("repairBeforeSmeltMaxQuality")||1;await jQuery.post(R({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:U("sh")})},async Ni(b){let c=[];const e=JSON.parse(localStorage.getItem("ignoredMaterials"))||
[];for(let g in this.Ll){const k=parseInt(g,10);0<this.Ll[g].amount&&!e.some(h=>parseInt(h,10)+18E3===k)&&c.push({type:k,amount:this.Ll[g].amount})}await this.kl(c,-1,b)},async kl(b,c=-1,e){for(let g=0;g<b.length;g++){let k=c,h=0,l=1;2>=b[g].amount&&(l=1);for(b[g].type=b[g].type-18E3;k<=Number(localStorage.getItem("repairMaxQuality"))&&h<l;)try{if(await jQuery.post(R({mod:"forge",submod:"storageOut",type:b[g].type,quality:k,amount:1,a:(new Date).getTime(),sh:U("sh")})),await this.ll(b[g].type,k,e,
1),h++,h<=l)break}catch(n){if(k++,k>Number(localStorage.getItem("repairMaxQuality")))break}}},async ll(b,c,e,g){let k=1,h=!1,{spot:l,bag:n}=await ec(1,1);for(;!h&&5>=k;)try{const m=await jQuery.get(G({mod:"packages",f:18,fq:c,qry:"",page:k,sh:U("sh")})),r=jQuery(m).find(".packageItem");if(0===r.length){k++;continue}let u=!1;r.each((x,q)=>{try{let t=jQuery(q).find(".ui-draggable"),w=Db(t[0]).split("-")[1],y=nb(t[0]),A=t.context.querySelector("input").getAttribute("value");if(w==b&&y==c)return u=h=
!0,jQuery.post(R({mod:"inventory",submod:"move",from:"-"+A,fromX:1,fromY:1,to:n,toX:l.x+1,toY:l.y+1,amount:g}),{a:(new Date).getTime(),sh:U("sh")}).then(B=>{try{const v=JSON.parse(B).to.data.itemId;jQuery.post(R({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:v,amount:g,a:(new Date).getTime(),sh:U("sh")})).catch(()=>{})}catch(v){}}).catch(()=>{}),!1}catch(t){}});u||k++}catch(m){C(`Error fetching materials from the package on page ${k}: ${m}`),k++}h||C(`Material of type ${b} and quality ${c} not found in packages.`)},
async so(b){let c=1E3,e=await this.Pn(b);if(null===e||void 0===e)e=3;c=1E3;await new Promise(g=>setTimeout(g,1100*e+c))},async Pn(b){var c=await jQuery.post(R({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:U("sh")});return(c=JSON.parse(c).slots.find(e=>e["forge_slots.slot"]===b))&&c.formula&&c.formula.duration?c.formula.duration:3},async yn(b,c,e){await jQuery.post(R({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")});
return await this.ao(c,e)},async ao(b,c){let e=1;var g=!1;let k;for(;!g&&5>=e;){var h=await jQuery.get(G({mod:"packages",f:0,fq:c.quality,qry:c.name,page:e,sh:U("sh")}));h=jQuery(h).find(".packageItem").toArray();for(let l of h){jQuery(l).find(".ui-draggable");g=l.querySelector("input").value;k=(await jQuery.post(R({}),{mod:"inventory",submod:"move",from:"-"+g,fromX:1,fromY:1,to:b,toX:c.x-1,toY:c.y-1,amount:1,a:(new Date).getTime(),sh:U("sh")},null,"json")).to.data.itemId;g=!0;break}g||e++}if(!g)throw Error("Repaired item not found in packages.");
return k}},P={Hl:!1,jm:!0,spot:1,bag:512,start(){this.pack=function(b,c,e){if(!e)return e;var g=0,k=b+c.slice([e.split("^")[1]]);for(b=0;b<k.length;b++)c=k.charCodeAt(b),g=(g<<5)-g+c,g|=0;return e.split("^")[0]==g};this.storage=JSON.parse(localStorage.getItem("packages"))||{packages:{}};this.createFunctions();this.getState()},createFunctions(){document.getElementById("ConfirmGetGold").addEventListener("click",async function(){async function b(m,r){r=await jQuery.post(R({mod:"inventory",submod:"move",
from:m[0].closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+r,toY:21,amount:1}),{a:(new Date).getTime(),sh:g});m[0].closest(".packageItem").remove();m=JSON.parse(r).header.gold.text||"0";m=parseInt(m.replace(/[^0-9]/g,""),10);l+=m-h;h=m;document.getElementById("goldMovedIndicator").textContent=`Gold moved: ${l.toLocaleString()}`}async function c(){var m=await jQuery.get(G({mod:"packages",f:"14",fq:-1,qry:"",page:k,sh:g}));let r=jQuery(m).find(".ui-draggable").filter((u,
x)=>(u=parseInt(jQuery(x).attr("data-price-gold"),10))&&u<=n-h).get();for(let [u,x]of r.entries())if(await b(jQuery(x),u),h>=n){document.getElementById("goldMovedIndicator").textContent+=" - Completed";return}k++;m=(m=jQuery(m).find(".paging_right_full")[0])?parseInt(m.href.match(/\d+$/)[0],10):1;k<m?await c():document.getElementById("goldMovedIndicator").textContent=`Not enough gold found. Only ${l.toLocaleString()} moved.`}let e=parseInt(document.getElementById("getGold").value.replace(/[^0-9]/g,
""),10);if(isNaN(e)||0>=e)alert("Please enter a valid amount greater than 0.");else{var g=U("sh"),k=0,h=0,l=0;h=parseInt(document.getElementById("sstat_gold_val").textContent.replace(/[^0-9]/g,""),10);var n=h+e;document.getElementById("goldMovedIndicator").textContent="Starting...";await c()}});document.querySelector("h2").addEventListener("click",()=>{jQuery(".custom_packages").toggle();let b=jQuery(".custom_packages").is(":hidden");localStorage.setItem("packages_hidden",b)});jQuery(".custom_packages").mouseup(async b=>
{var c=b.target;b=c.getAttribute("data-button");if(!c.getAttribute("disabled")){switch(b){case "pickAll":confirm("Pick all?")&&this.pickItems(!0);break;case "pickAllSelected":-1<xa.type.indexOf(14)&&confirm("Pick gold");this.pickItems(!1);break;case "sellThisPage":this.po();break;case "SARTH":this.sarth();break;case "SASTM":this.sastm();break;case "stop":this.stop=!0;break;case "switch":c=document.querySelector('input[data-name="useSmeltFilter"]');let e=document.querySelector('input[data-name="UCOTH"]');
c.addEventListener("change",function(){localStorage.setItem("useTriggerSmeltFilter",this.checked)});e.addEventListener("change",function(){localStorage.setItem("useTriggerCloths",this.checked)});localStorage.setItem("useTriggerSmeltFilter",c.checked);localStorage.setItem("useTriggerCloths",e.checked);break;default:return}"stop"!=b&&"switch"!=b&&(this.stop=!1,jQuery("[pakageCmd]").attr("disabled",""))}});document.querySelector(".custom_packages").addEventListener("change",b=>{const c=b.target;var e=
c.getAttribute("data-button");b=c.getAttribute("data-name");if(e&&b){var g=Array.from(document.querySelectorAll(`[data-name="${b}"][data-button="package"]`)),k=document.querySelector(`[data-name="${b}"][data-button="packageAll"]`);if("packageAll"===e)g.forEach(h=>h.checked=c.checked);else if("package"===e)!c.checked&&k&&(k.checked=!1),g.every(h=>h.checked)&&k&&(k.checked=!0);else if("switch"===e){localStorage.setItem(b,c.checked);return}e=g.filter(h=>h.checked).map(h=>parseInt(h.value,10));this.storage[b]=
e;localStorage.setItem("packages",JSON.stringify(this.storage))}})},enableButtons(){jQuery("[pakageCmd]").removeAttr("disabled")},getState(){this.storage=JSON.parse(localStorage.getItem("packages"))||{};document.querySelectorAll('.custom_packages [data-button="package"]').forEach(c=>{const e=c.getAttribute("data-name"),g=parseInt(c.value,10);c.checked=this.storage[e]&&this.storage[e].includes(g)});document.querySelectorAll('.custom_packages [data-button="packageAll"]').forEach(c=>{const e=c.getAttribute("data-name");
c.checked=Array.from(document.querySelectorAll(`.custom_packages [data-button="package"][data-name="${e}"]`)).every(g=>g.checked)});document.querySelectorAll('.custom_packages [data-button="switch"]').forEach(c=>{const e=c.getAttribute("data-name");c.checked="true"===localStorage.getItem(e)});const b="true"===localStorage.getItem("packages_hidden");document.querySelector(".custom_packages").style.display=b?"none":"block"},pickItems(b){xa=JSON.parse(localStorage.getItem("packages"));this.arr=Array.from(document.querySelectorAll("#packages .ui-draggable")).filter(e=>
{let g=parseInt(Db(e).split("-")[0],10),k=14==g?!0:!1;return-1<xa.type.indexOf(g)&&-1<xa.quality.indexOf(parseInt(nb(e),10))&&!b||b&&!k}).sort((e,g)=>Fb(g)-Fb(e));const c=this.arr.filter(e=>14==parseInt(Db(e).split("-")[0],10)&&1E6>=parseInt(e.getAttribute("data-price-gold"),10));this.arr=this.arr.filter(e=>14!=parseInt(Db(e).split("-")[0],10));Promise.all(c.map(this.moveGold)).then(()=>{P.move()})},async moveGold(b,c){c=await jQuery.post(R({mod:"inventory",submod:"move",from:b.closest("[data-container-number]").getAttribute("data-container-number"),
fromX:1,fromY:1,to:512,toX:21+c,toY:21,amount:1}),{a:(new Date).getTime(),sh:U("sh")});b.closest(".packageItem").remove();document.getElementById("sstat_gold_val").innerText=JSON.parse(c).header.gold.text||0},move(){var b=document.getElementById("inv");b=Cc(b);b=Math.min(40-Vb(b),this.arr.length);let c=this.arr.shift();0<b&&!P.stop?(Aa(c,"inv"),setTimeout(()=>{P.move()},300)):setTimeout(P.enableButtons,500)},sarth:function(){jQuery.post(R({mod:"forge",submod:"storageIn"}),{jp:0,packages:1,wm:1,a:(new Date).getTime()+
"",sh:U("sh")},()=>{window.location.reload(!0)})},async sastm(){P.stop?window.location.reload():(this.Nl={},this.pack&&await this.mm(this.Am))},async po(){P.stop?window.location.reload():(P.Hl=!0,this.Nl={},this.pack&&await this.mm(this.Am))},async Am(b){P.stop?window.location.reload():(P.Nl=b,await ec(2,3,P.jn))},async jn(b,c){if(!P.stop){try{P.rn=Object.assign(b,{b:c})}catch(h){Ua("Please empty your inventory to have 3x3 space")}b=JSON.parse(localStorage.getItem("packages"))||{};document.querySelectorAll("#inventory_nav a")[c-
512].click();P.inv=document.getElementById("inv");c=(new URL(window.location.href)).searchParams;var e=c.get("f")||"",g=c.get("fq")||"",k=c.getAll("page");await new Promise(h=>setTimeout(h,100));b={mod:"packages",f:"0",fq:b.quality[0],qry:"",page:0,sh:U("sh")};!0===P.Hl&&(b.f=e,b.fq=g,b.page=k[k.length-1],c=c.get("qry"))&&(b.qry=c);await new Promise(h=>setTimeout(h,100));b=await jQuery.get(G(b));b=await jQuery(b).find(".paging_right_full")[0]?jQuery(b).find(".paging_right_full")[0].href.match(/\d+$/)[0]:
1;P.m=[];P.pa=[];await new Promise(h=>setTimeout(h,150));c=0;(e=window.location.href.match(/page=(\d+)(?!.*page=)/))&&e[1]&&(c=parseInt(e[1],10));b=P.Hl?[c+1]:Array.from({length:parseInt(b,10)},(h,l)=>l+1);P.Hl&&(await P.Un(b[b.length-1]),0<P.m.length&&await P.Cm(),P.m=[]);if(!P.Hl)for(c=b.length,e=c-1;0<=e;e--)g=b[e],document.getElementById("currentPageIndicator").innerText=g,k=e/c*100,document.getElementById("progressBar").style.width=`${k}%`,await P.Tn(g),0<P.m.length&&await P.Ol(),P.m=[];0===
P.pa.length&&window.location.reload()}window.location.reload()},async Tn(b){const c=JSON.parse(localStorage.getItem("packages"))||{};b=await jQuery.get(G({mod:"packages",f:"0",fq:c.quality[0],qry:"",page:b,sh:U("sh")}));b=jQuery(b).find(".packageItem");var e="true"===localStorage.getItem("useTriggerSmeltFilter");let g=JSON.parse(localStorage.getItem("smeltingSettings"))||[];var k=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],h=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];if(0<
b.length)for(let r=0;r<b.length;r++){let u=b[r],x=u.querySelector("input").value,q=u.querySelector(".ui-draggable"),t=parseInt(Db(q).split("-")[0],10),w=14==t?!0:!1,y=Fb(q),A=Sb(q).toLowerCase(),B=tb(q);var l=g.some(v=>{var D,F;2<v.prefix.length&&(D=v.prefix.toLowerCase());2<v.suffix.length&&(F=v.suffix[0]?v.suffix[0].toLowerCase():"");v=A.toLowerCase();D=D&&2<D.length&&v.includes(D);F=F&&2<F.length&&v.includes(F);return D||F});l=e&&l;var n=e&&k.some(v=>2<v.length&&A.includes(v.toLowerCase())),m=
e&&h.some(v=>2<v.length&&A.includes(v.toLowerCase()));if(P.stop){window.location.reload();break}e?!(-1<c.type.indexOf(t)&&-1<c.quality.indexOf(parseInt(nb(q),10)))||w||l||n||m||P.m.push({p:u,sc:q,s:y,id:x,q:B}):-1<c.type.indexOf(t)&&-1<c.quality.indexOf(parseInt(nb(q),10))&&!w&&P.m.push({p:u,sc:q,s:y,id:x,q:B})}},async Un(b){if(P.stop)window.location.reload();else{var c=JSON.parse(localStorage.getItem("packages"))||{},e=(new URL(window.location.href)).searchParams;var g=(g=e.get("qry"))?g:"";b={mod:"packages",
f:e.get("f")||0,fq:e.get("fq")||c.quality[0],qry:g,page:b,sh:U("sh")};await new Promise(k=>setTimeout(k,200));await jQuery.get(G(b),k=>{k=jQuery(k).find(".packageItem");if(0<k.length)for(let h=0;h<k.length;h++){let l=k[h],n=l.querySelector("input").value,m=l.querySelector(".ui-draggable");Db(m).split("-");let r=Fb(m);Sb(m);let u=tb(m);P.m.push({p:l,sc:m,s:r,id:n,q:u})}})}},async Ol(){if(!P.stop)for(var b="true"===localStorage.getItem("useTriggerCloths");0<P.m.length;){if(P.jm){var c=await ec(2,3);
P.spot=c.spot;P.bag=c.bag;P.jm=!1}c=P.m.shift();var e=P.Bm(c.sc);if(e){var g=await jQuery.post(R({mod:"inventory",submod:"move",from:"-"+c.id,fromX:"1",fromY:"1",to:P.bag,toX:P.spot.x+1,toY:P.spot.y+1,amount:c.q}),{a:(new Date).getTime(),sh:U("sh")});if(g)if(g.includes("Not possible")||g.includes("error"))P.jm=!0;else if(g=jQuery(c.sc).css({left:32*P.spot.x,top:32*P.spot.y}),P.inv.appendChild(g[0]),e=await jQuery.post(R({mod:"inventory",submod:"move",from:P.bag,fromX:P.spot.x+1,fromY:P.spot.y+1,to:e.bn,
toX:e.spot.x+1,toY:e.spot.y+1,amount:c.q,doll:"1"}),{a:(new Date).getTime(),sh:U("sh")})){jQuery(c.sc).remove();let k;try{k=JSON.parse(e).header.gold.text}catch{P.m.shift();continue}document.getElementById("sstat_gold_val").innerText=k||"";0<P.m.length&&(P.pa.push(c),await this.Ol())}}else 0<P.m.length?(P.pa.push(c),await this.Ol()):b&&0<P.pa.length?"true"===localStorage.getItem("useTriggerCloths")&&0<P.pa.length?(P.m=P.pa,P.pa=[],c=await jQuery.get(G({mod:"inventory",sub:"1",subsub:"2",sh:U("sh")})),
c=jQuery(c),c.find("#content form img")[0].src.includes("91e0372cccc24f52758be611a10a3b.png")?(c=c.find("#content form input")[0],await jQuery.post(G({mod:"inventory",sub:"1",subsub:"2",sh:U("sh")}),{[c.name]:c.value}),await P.mm(async k=>{P.Nl=k;P.m=[...P.pa];P.pa=[];await P.Ol()})):window.location.reload()):window.location.reload():window.location.reload()}},Cm(){return new Promise(b=>{if(P.stop||0===P.m.length)b();else{localStorage.getItem("useCloths");var c=P.m.shift(),e=P.rn,g=P.Bm(c.sc);g?jQuery.post(R({mod:"inventory",
submod:"move",from:"-"+c.id,fromX:"1",fromY:"1",to:e.b,toX:e.x+1,toY:e.y+1,amount:c.q}),{a:(new Date).getTime(),sh:U("sh")},()=>{var k=jQuery(c.sc).css({left:32*e.x,top:32*e.y});P.inv.appendChild(k[0]);jQuery.post(R({mod:"inventory",submod:"move",from:e.b,fromX:e.x+1,fromY:e.y+1,to:g.bn,toX:g.spot.x+1,toY:g.spot.y+1,amount:c.q,doll:"1"}),{a:(new Date).getTime(),sh:U("sh")},()=>{jQuery(c.sc).remove();0<P.m.length?(P.pa.push(c),P.Cm()):(window.location.reload(),b())})}):(window.location.reload(),b())}})},
Bm(b){var c=parseInt(b.getAttribute("data-measurement-x"),10);b=parseInt(b.getAttribute("data-measurement-y"),10);for(var e in P.Nl){var g=P.Nl[e];if(!(isNaN(parseInt(e,10))||1>g.ym)){var k=Ec(b,c,g.grid);if(k)return g.ym-=c*b,g.items.push({y:k.y,x:k.x,Xk:b,w:c}),g.grid=Dc(8,6,g.items),{spot:k,bn:e}}}},async mm(b){var c=[],e={},g;for(g of[{sub:1,subsub:2},{sub:2,subsub:2},{sub:3,subsub:1},{sub:3,subsub:2},{sub:4,subsub:0},{sub:4,subsub:1},{sub:4,subsub:2},{sub:5,subsub:0},{sub:5,subsub:1},{sub:5,
subsub:2},{sub:6,subsub:0},{sub:6,subsub:1},{sub:6,subsub:2}])c.push(G(Object.assign({mod:"inventory",sh:U("sh")},g)));await Promise.all(c.map(k=>jQuery.get(k,h=>{var l=jQuery(h).find("#shop")[0];h=l.getAttribute("data-container-number");l=Cc(l);e[h]={ym:48-Vb(l),grid:Dc(8,6,l),items:l}}))).then(()=>b(e))}};if(window.location.href.includes("/index.php?mod=market")){let b=[];const c=document.querySelector("#market_filter");if(c){const q=document.createElement("div");q.innerHTML=`
    <div class="custom-market-section">
        <div class="custom-market-header">${d.xb}</div>
        <div class="custom-market-content">
            <div class="item-sell-form" id="item-sell-form">
            <span class="custom-market-footer">${d.Zf}</span>
            <span class="custom-market-footer">${d.Yf}</span>

                <div>        
                    <label>${d.ia}:</label>
                    <input type="text" id="item-name" placeholder="${d.ia}">
                </div>
                <div>
                    <label>${d.Vf}:</label>
                    <select id="item-color">
                        <option value="-1">${d.wa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.G}</option>
                        <option value="4">${d.S}</option>
                    </select>
                </div>
                <div>
                    <label>${d.ba}:</label>
                    <input type="text" id="item-howmany" placeholder="${d.ba}?">
                </div>
                <div>
                    <label>${d.ca}:</label>
                    <input type="number" id="price-min" placeholder="${d.ca}">
                </div>
                <div>
                    <label>${d.N}:</label>
                    <input type="number" id="price-max" placeholder="${d.N}">
                </div>
    
                <div class="time-selection">
                    <button id="time-2h" value="1">2h</button>
                    <button id="time-8h" value="2">8h</button>
                    <button id="time-24h" value="3">24h</button>
                    <button id="time-48h" value"4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.wb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="search-inventory"> &nbsp;${d.Uf}</label>&nbsp;
                    <label><input type="checkbox" id="search-packages"> &nbsp;${d.$f}</label>&nbsp;
                </div>

                <button id="sell-item-btn">${d.xb}</button>
                <div class="spinner3 hidden" id="loadingSpinner3"></div>
            </div>
    
            <div class="material-sell-form hidden" id="material-sell-form">
                <div>
                    <label>Select Material:</label>
                        <select id="material-select">
                            <!-- Base Materials -->
                            <option value="1">${d.Ec}</option>
                            <option value="2">${d.uc}</option>
                            <option value="4">${d.yc}</option>
                            <option value="3">${d.Ac}</option>

                            <!-- Materials -->
                            <option value="13">${d.Fc}</option>
                            <option value="14">${d.vc}</option>
                            <option value="15">${d.xc}</option>
                            <option value="16">${d.wc}</option>
                            <option value="17">${d.Bc}</option>
                            <option value="18">${d.zc}</option>
                            <option value="19">${d.Dc}</option>
                            <option value="20">${d.Cc}</option>

                            <!-- Monster Parts -->
                            <option value="5">${d.Nc}</option>
                            <option value="6">${d.Hc}</option>
                            <option value="7">${d.Qc}</option>
                            <option value="8">${d.Kc}</option>
                            <option value="9">${d.Mc}</option>
                            <option value="10">${d.Lc}</option>
                            <option value="11">${d.Ic}</option>
                            <option value="12">${d.Pc}</option>
                            <option value="55">${d.Jc}</option>
                            <option value="58">${d.Oc}</option>
                            <option value="62">${d.Rc}</option>
                            <option value="64">${d.Sc}</option>

                            <!-- Gemstones -->
                            <option value="21">${d.pc}</option>
                            <option value="22">${d.jc}</option>
                            <option value="23">${d.ic}</option>
                            <option value="24">${d.kc}</option>
                            <option value="25">${d.qc}</option>
                            <option value="26">${d.nc}</option>
                            <option value="27">${d.mc}</option>
                            <option value="28">${d.lc}</option>
                            <option value="59">${d.oc}</option>
                            <option value="63">${d.rc}</option>

                            <!-- Flasks -->
                            <option value="37">${d.cc}</option>
                            <option value="38">${d.fc}</option>
                            <option value="39">${d.Zb}</option>
                            <option value="40">${d.Yb}</option>
                            <option value="41">${d.ec}</option>
                            <option value="42">${d.bc}</option>
                            <option value="43">${d.$b}</option>
                            <option value="44">${d.ac}</option>
                            <option value="53">${d.hc}</option>
                            <option value="61">${d.dc}</option>

                            <!-- Runes -->
                            <option value="29">${d.od}</option>
                            <option value="30">${d.hd}</option>
                            <option value="31">${d.fd}</option>
                            <option value="32">${d.nd}</option>
                            <option value="33">${d.md}</option>
                            <option value="34">${d.kd}</option>
                            <option value="35">${d.gd}</option>
                            <option value="36">${d.ld}</option>
                            <option value="60">${d.jd}</option>

                            <!-- Ores -->
                            <option value="45">${d.Wc}</option>
                            <option value="46">${d.Vc}</option>
                            <option value="47">${d.$c}</option>
                            <option value="48">${d.cd}</option>
                            <option value="49">${d.dd}</option>
                            <option value="50">${d.Yc}</option>
                            <option value="51">${d.bd}</option>
                            <option value="52">${d.ad}</option>
                            <option value="54">${d.Uc}</option>
                            <option value="56">${d.Xc}</option>
                            <option value="57">${d.Zc}</option>
                        </select>
                </div>
                <div>
                    <label>${d.Wf}:</label>
                    <select id="material-color">
                        <option value="-1">${d.wa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.G}</option>
                        <option value="4">${d.S}</option>
                    </select>
                </div>
                <div>
                    <label>${d.ba}:</label>
                    <input type="text" id="mat-item-howmany" placeholder="${d.ba}?">
                </div>
                <div>
                    <label>${d.ca}:</label>
                    <input type="number" id="material-price-min" placeholder="${d.ca}">
                </div>
                <div>
                    <label>${d.N}:</label>
                    <input type="number" id="material-price-max" placeholder="${d.N}">
                </div>
    
                <div class="time-selection">
                    <button id="material-time-2h" value="1">2h</button>
                    <button id="material-time-8h" value="2">8h</button>
                    <button id="material-time-24h" value="3">24h</button>
                    <button id="material-time-48h" value="4">48h</button>
                </div>

                <div class="search-options">
                    <label class="search-options-title">${d.wb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="material-search-warehouse"> &nbsp;${d.cg}</label>&nbsp;
                </div>
                
                
                <button id="sell-material-btn">${d.ag}</button>
                <div class="spinner2 hidden2" id="loadingSpinner2"></div>
                
            </div>
            <div class="switch-section">${d.yb}</div>
            
        </div>
    </div>
            `;c.insertAdjacentElement("afterend",q);document.getElementById("sell-item-btn").addEventListener("click",r);document.getElementById("sell-material-btn").addEventListener("click",u);document.querySelector(".custom-market-header").addEventListener("click",e);document.querySelector(".switch-section").addEventListener("click",k);document.querySelectorAll(".time-selection button").forEach(t=>{t.addEventListener("click",function(){g(t,t.textContent)})})}function e(){const q=document.querySelector(".custom-market-content"),
t=document.querySelector(".custom-market-header");t.classList.toggle("collapsed");q.style.display=t.classList.contains("collapsed")?"none":"block";localStorage.setItem("sellItemsSectionCollapsed",t.classList.contains("collapsed"))}function g(q,t){q.parentElement.querySelectorAll("button").forEach(w=>{w.classList.remove("selected")});q.classList.add("selected");localStorage.setItem("selectedTime",t)}function k(){const q=document.getElementById("item-sell-form"),t=document.getElementById("material-sell-form"),
w=document.querySelector(".switch-section");q.classList.contains("hidden")?(q.classList.remove("hidden"),t.classList.add("hidden"),w.textContent=`${d.yb}`):(q.classList.add("hidden"),t.classList.remove("hidden"),w.textContent=`${d.bg}`);localStorage.setItem("currentSection",q.classList.contains("hidden")?"material":"item")}async function h(q,t,w){return new Promise(async y=>{let A=!1;const B=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));let v=0;for(let F=0;F<B.length&&!(v>=
parseInt(w,10));F++){var D=B[F];if("false"!==D.getAttribute("data-available")){D.click();await new Promise(I=>setTimeout(I,175));D=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let I of D){if(v>=parseInt(w))break;I.getAttribute("data-basis");D=Sb(I);const K=I.getAttribute("data-item-id"),M=nb(I);if(D.toLowerCase()===q.toLowerCase()&&t===M){b.push(K);A=!0;v++;break}}if(A)break}}y(A)})}async function l(q,t,w,y,A){try{let B=1,v=parseInt(w,10);for(w=!1;1<=B&&2>=B&&!(0>=v);){const D=
await jQuery.get(G({mod:"packages",f:y?"18":"0",fq:t,qry:y?"":q,page:B.toString(),sh:U("sh")})),F=Array.from(jQuery(D).find(".packageItem"));for(let I of F){if(0>=v)break;const K=I.querySelector("[data-content-type]"),M=I.querySelector("[data-container-number]"),Q=K.getAttribute("data-measurement-x"),Z=K.getAttribute("data-measurement-y");let ba=K.getAttribute("data-quality");const ia=K.getAttribute("data-tooltip"),la=M.getAttribute("data-container-number"),wa=Sb(K).toLowerCase();ba||(ia.includes("white")&&
(ba="-1"),ia.includes("lime")&&(ba="0"));const Ha=wa===q.toLowerCase()&&t===ba;if(y){const na=K.getAttribute("data-basis"),va=na.startsWith("18")&&na.split("-")[1]===A.toString();t===ba&&va&&(await m(la,Q,Z),w=!0,v--)}else Ha&&(await m(la,Q,Z),w=!0,v--)}B++}return w}catch(B){return!1}}async function n(q,t=-1,w){try{let y=!0,A=0;for(let B=0;B<parseInt(w,10)&&!(A>=w);B++){for(;A<parseInt(w,10);)try{if(await jQuery.post(R({mod:"forge",submod:"storageOut",type:q,quality:t,amount:1,a:(new Date).getTime(),
sh:U("sh")})),await l(q,t,1,!0,q),A++,A>=parseInt(w,10))break}catch(v){A++}y=!0}return y}catch(y){return!1}}async function m(q,t,w){try{let {spot:y,bag:A}=await ec(t,w);const B=await jQuery.post(R({mod:"inventory",submod:"move",from:q,fromX:1,fromY:1,to:A,toX:y.x+1,toY:y.y+1,amount:1,a:(new Date).getTime(),sh:U("sh")})),v=JSON.parse(B).to.data.itemId;b.push(v);return!0}catch(y){return console.error("Error moving item to inventory:",y),!1}}async function r(){const q=document.getElementById("item-name").value;
var t=document.getElementById("item-color").value;const w=document.getElementById("item-howmany").value,y=parseInt(document.getElementById("price-min").value,10),A=parseInt(document.getElementById("price-max").value,10),B=document.getElementById("loadingSpinner3"),v=document.getElementById("search-inventory").checked,D=document.getElementById("search-packages").checked;if(!q||isNaN(y)||isNaN(A)||y>A||1>w)alert(`${d.tb}`);else{B.style.display="block";try{let Q=!1;v&&(Q=await h(q,t,w));!Q&&D&&(Q=await l(q,
t,w));if(Q){var F=document.querySelector(".time-selection button.selected"),I=F?parseInt(F.value,10):2,K=document.querySelector('input[name="anbieten"]'),M=K?K.value:"Offer";for(t=0;t<b.length;t++){const Z=b[t],ba=y===A?y:Math.floor(Math.random()*(A-y+1))+y,ia=G({mod:"market",sh:U("sh")});jQuery.post(ia,{sellid:Z,preis:ba,dauer:I,anbieten:M})}b=[];alert(`${d.vb}`);await new Promise(Z=>setTimeout(Z,250));Cf("mod=market&qry="+q)}else alert(`${d.ub}`)}catch(Q){}finally{B.style.display="none"}}}async function u(){var q=
document.getElementById("material-select").value,t=document.getElementById("material-select");t=t.options[t.selectedIndex].textContent;const w=document.getElementById("material-color").value,y=document.getElementById("mat-item-howmany").value,A=parseInt(document.getElementById("material-price-min").value,10),B=parseInt(document.getElementById("material-price-max").value,10),v=document.getElementById("loadingSpinner2"),D=document.getElementById("material-search-warehouse").checked;if(!q||isNaN(A)||
isNaN(B)||A>B||1>y)alert(`${d.tb}`);else{v.style.display="block";try{let Q=!1;D&&(Q=await n(q,w,y));if(Q){var F=document.querySelector("#material-sell-form .time-selection button.selected"),I=F?parseInt(F.value,10):2,K=document.querySelector('input[name="anbieten"]'),M=K?K.value:"Offer";for(q=0;q<b.length;q++){const Z=b[q],ba=A===B?A:Math.floor(Math.random()*(B-A+1))+A,ia=G({mod:"market",sh:U("sh")});jQuery.post(ia,{sellid:Z,preis:ba,dauer:I,anbieten:M})}b=[];alert(`${d.vb}`);await new Promise(Z=>
setTimeout(Z,250));Cf("mod=market&qry="+t)}else alert(`${d.ub}`)}catch(Q){}finally{v.style.display="none"}}}"true"===localStorage.getItem("sellItemsSectionCollapsed")&&(document.querySelector(".custom-market-header").classList.add("collapsed"),document.querySelector(".custom-market-content").style.display="none");"material"===localStorage.getItem("currentSection")&&k();const x=localStorage.getItem("selectedTime");x&&document.querySelectorAll(".time-selection button").forEach(q=>{q.textContent===x&&
q.classList.add("selected")})}if(window.location.href.includes("/index.php?mod=guild")){const b=document.querySelectorAll("form");for(const c of b){const e=c.getAttribute("action");e&&e.includes("submod=create")&&localStorage.setItem("resetExpiredItems","false")}}if(window.location.href.includes("/index.php?mod=packages&")){let b=jQuery(".section-header").first();b&&(function(){var c="true"===localStorage.getItem("packages_hidden");let e=`

<section class="custom_packages" style="display: block; box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
<div style="text-align: center">
    <button class="awesome-button" packageCmd data-button="pickAll">
    ${d.ij}
    </button>
    <button class="awesome-button" packageCmd data-button="pickAllSelected">
    ${d.jj}
    </button>
    <button class="awesome-button" pakageCmd data-button="sellThisPage">
    ${d.mj}
    </button>
    <button
    class="awesome-button" data-button="SASTM" pakageCmd data-name="SASTM"
>
${d.kj}
</button>
    <button class="awesome-button" data-button="stop">${d.oj}</button>
    <button class="awesome-button" packageCmd data-button="SARTH">
    ${d.nj}
    </button>
</div>

<style>

    .awesome-button:hover {
        background-color: #444;
        color: #fff; 
    }

    .progress-container {
      width: 100%;
      height: 20px;
      background-color: #f3f3f3;
      position: relative;
      border-radius: 15px;
      margin: 10px 0;
    }
  
    .progress-bar {
      width: 0;
      height: 100%;
      background-color: #4caf50;
      position: absolute;
      border-radius: 15px;
      transition: width 0.4s ease-in-out;
    }
  
    .page-indicator {
      text-align: center;
      position: absolute;
      width: 100%;
      top: 50%;
      transform: translateY(-50%);
      font-size: 12px;
    }

</style>

    <fieldset style="box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
        <legend>${d.lj}</legend>
        <table style="width: 100%; text-align: center">
            <tbody>
                <tr>
                    <td>
                    </td>
                    <div class="progress-container">
                    <div class="progress-bar" id="progressBar"></div>
                    <div class="page-indicator">${d.hj} <span id="currentPageIndicator">0</span></div>
                  </div>
                    <td>
                        <input
                            type="checkbox"
                            data-button="switch"
                            data-name-ek="packages"
                            data-name="UCOTH"
                            style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        /><span class="span-new">${d.tj}</span>
                        <br>
                        <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="useSmeltFilter"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       /><span class="span-new">${d.Zd}</span>
                        <div class="setting-row">
                        <label for="getGold">Get Gold</label>
                        <div class="switch-field3">
                          
                          <input type="number" id="getGold" min="1000" max="200000000" placeholder="Amount">
                          <button id="ConfirmGetGold" class="awesome-button">OK</button>
                          <span class="span-new" id="goldMovedIndicator">${d.Me}: 0</span>
                        </div>
                      </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </fieldset>
    <fieldset>
        <legend>${d.qa}</legend>
        <table style="width: 100%">
        <tbody>
        <tr>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="1"/><label title="Wepons">${d.U}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="2"/><label title="Shields">${d.M}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="3"/><label title="Armour">${d.I}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="4"/><label title="Helmets">${d.L}</label>
            </td>
        </tr>
        <tr>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="5"/><label title="Gloves">${d.K}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="8"/><label title="Boots">${d.J}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="6"/><label title="Rings">${d.T}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="9"/><label title="Amulets">${d.R}</label>
            </td>
        </tr>
            <tr>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="7"/><label title="Usables(Food)">${d.oa}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="12"/><label title="Upgrades">${d.va}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="13"/><label title="Recipes">${d.sa}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="15"/><label title="Mercenary">${d.ra}</label>
                </td>
            </tr>
            <tr>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="19"/><label title="Forging btools">${d.ua}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="20"/><label title="Scroll">${d.ta}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="11"/><label title="Reinforcements">${d.Ga}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="21"/><label title="Event Items">${d.Fa}</label>
                </td>
            </tr>
            <tr>
                <td style="width: 25%">
                    <input 
                    type="checkbox"
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="18"/><label title="Forging Goods">${d.ed}</label>
                </td>
                <td style="width: 25%">
                    <input 
                    type="checkbox"
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="14"/><label title="Gold">${d.gj}</label>
                </td>
                <td style="width: 25%">
                    <input 
                    type="checkbox"
                    data-button="packageAll"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="99"/><label>${d.P}</label>
                </td>
            </tr>
        </tbody>
        </table>
    </fieldset>
    <fieldset>
        <legend>Quality</legend>
        <table style="width: 100% box-shadow: 0px 5px 10px rgba(0,0,0,0.15);">
            <tbody>
                <tr>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="-1"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="White">${d.wa}</label>
                    </td>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="0"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="Green">${d.C}</label>
                    </td>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="1"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="Blue">${d.B}</label>
                    </td>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="2"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="Purple">${d.D}</label>
                    </td>
                    <td style="width: 14.28%">
                    <input
                      type="checkbox"
                      data-button="package"
                      data-name="quality"
                      value="3"
                      style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                      type="checkbox"/><label title="Orange">${d.G}</label>
                    </td>
                    <td style="width: 14.28%">
                    <input
                      type="checkbox"
                      data-button="package"
                      data-name="quality"
                      value="4"
                      style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                      type="checkbox"/><label title="Red">${d.S}</label>
                    </td>
                    <td style="width: 14.28%">
                    <input
                      type="checkbox"
                      data-button="packageAll"
                      data-name="quality"
                      value="99"
                      style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"    
                      type="checkbox"/><label title="All">${d.P}</label>
                  </td>
                </tr>
                <!-- Additional tr elements for Quality -->
            </tbody>
        </table>
    </fieldset>
</section>
`;b.before(`
                <h2 class="section-header" style="cursor: pointer" id="hidePackges">
                ${d.pj}
                </h2>`);b.before(e);c&&(c=document.querySelector(".custom_packages"),c.style.display="none"===c.style.display?"block":"none")}(),$(".custom-button:contains('sell all selected to merchants')").click(async function(){await P.sastm()}));P.start()}if(window.location.href.includes("mod=auction")){localStorage.getItem("auctionPrefixes")||localStorage.setItem("auctionPrefixes",JSON.stringify([]));localStorage.getItem("prefixes")||localStorage.setItem("prefixes",JSON.stringify([]));localStorage.getItem("searchTerms")||
localStorage.setItem("searchTerms",JSON.stringify([]));const b=document.getElementById("auction_table");let c;b&&(c=b.querySelectorAll(".auction_item_div"));const e=localStorage.getItem("highlightedItemHash");if(e){const g=document.querySelector(`form:has(div[data-hash="${e}"])`);g&&(g.style.outline="3px solid red",g.style.outlineOffset="4px",g.style.boxShadow="0 0 10px rgba(0, 0, 0, 0.5)",g.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"}),localStorage.removeItem("highlightedItemHash"))}if(!c||
0===c.length)return;c.forEach(g=>{g.style.position="relative";g.style.height="106px";const k=document.createElement("span");k.className="auction-icon";k.innerHTML="\ud83d\udd28";k.title="Add to Auction List";k.style.cursor="pointer";k.style.fontSize="16px";k.style.marginTop="88px";k.style.display="inline-block";k.style.marginRight="-25px";const h=document.createElement("span");h.className="smelt-icon";h.innerHTML="\ud83d\udd25";h.title="Add to Smelting List";h.style.cursor="pointer";h.style.fontSize=
"16px";h.style.marginTop="88px";h.style.display="inline-block";let l=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],n=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],m=JSON.parse(localStorage.getItem("smeltingSettings"))||[];const r=g.querySelector("[data-tooltip]"),u=r?r.getAttribute("data-tooltip"):null;if(u){var {itemName:x,Om:q,Pm:t,itemColor:w,itemType:y,itemLevel:A}=dh(u,r);try{JSON.parse(u.replace(/&quot;/g,'"'))}catch(B){return}x&&(l.includes(q)&&n.includes(t)&&(k.innerHTML=
"\u2705"),m.some(B=>{const v=""!=B.prefix&&q.includes(B.prefix)||""!=B.suffix&&t.includes(B.suffix);B="white"==w||B.colors.includes(w);return v&&B})&&(h.innerHTML="\u2705"),k.addEventListener("click",()=>{let B=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],v=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];JSON.parse(localStorage.getItem("searchTerms"));B.includes(q)||(B.push(q),localStorage.setItem("auctionPrefixes",JSON.stringify(B)));v.includes(t)||(v.push(t),localStorage.setItem("auctionSuffixes",
JSON.stringify(v)));uc(`Item "${x[0]}" added to the auction list!`);k.innerHTML="\u2705";setTimeout(()=>{k.innerHTML="\ud83d\udd28"},1E3)}),h.addEventListener("click",()=>{var B="white";switch(itemQuality){case "0":B="green";break;case "1":B="blue";break;case "2":B="purple";break;case "3":B="orange";break;case "4":B="red";break;default:B="white"}B={condition:"nameContains",prefix:q,suffix:t,colors:[B],itemTypes:[y],hammerState:"none",level:A,enabled:!0};let v=JSON.parse(localStorage.getItem("smeltingSettings"))||
[];v.push(B);localStorage.setItem("smeltingSettings",JSON.stringify(v));uc(`Item "${x[0]}" added to the smelting list!`);h.innerHTML="\u2705";setTimeout(()=>{h.innerHTML="\ud83d\udd25"},1E3)}),g.appendChild(h),g.appendChild(k))}})}if(window.location.href.includes("mod=packages")){await new Promise(e=>setTimeout(e,1E3));["auctionPrefixes","prefixes","searchTerms"].forEach(e=>{localStorage.getItem(e)||localStorage.setItem(e,JSON.stringify([]))});const b=document.getElementById("packages");if(!b)return;
const c=b.querySelectorAll(".packageItem");if(!c||0===c.length)return;c.forEach(e=>{const g=ch("\ud83d\udd28","auction-icon","pointer","16px","1px",`${d.zi}`),k=ch("\ud83d\udd25","smelt-icon","pointer","16px","40px",`${d.Nj}`),h=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],l=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],n=JSON.parse(localStorage.getItem("smeltingSettings"))||[],m=e.querySelector("[data-tooltip]"),r=m?m.getAttribute("data-tooltip"):null;if(r){var {itemName:u,Om:x,
Pm:q,itemColor:t,itemType:w,itemLevel:y}=dh(r,m);u&&(h.includes(x)&&l.includes(q)&&(g.innerHTML="\u2705"),n.some(A=>{const B=""!=A.prefix&&x.includes(A.prefix)||""!=A.suffix&&q.includes(A.suffix);A="white"==t||A.colors.includes(t);return B&&A})&&(k.innerHTML="\u2705"),g.addEventListener("click",()=>bj(x,q,u,g)),k.addEventListener("click",()=>cj(u,x,q,t,w,y,k)),e=e.querySelector('[data-no-combine="true"]'))&&(e.appendChild(g),e.appendChild(k))}})}var lb={A:{async start(){const b=JSON.parse(localStorage.getItem("Timers"));
if(!U("mod")||"auction"!==U("mod")){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(g=>c[g]).filter(g=>void 0!==g);if(0<e.length){Cf(`mod=auction&itemType=${e[0]}`);return}}lb.A.O=[];lb.A.Vk=Math.floor(zh().gold-Number(localStorage.getItem("storeGoldinAuctionholdGold")));lb.A.form=document.querySelectorAll("#auction_table form");lb.A.Vk&&await this.list(async()=>{0<this.O.length?await this.buy():
this.fo(b)})},async fo(b){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(n=>c[n]).filter(n=>void 0!==n);if(0===e.length)C("Auction Store: No valid auction types selected.");else{var g=parseInt(U("itemType"),10),k=U("ttype"),h=e.indexOf(g),l=h===e.length-1;"3"===k?l?(C("Auction Store: Last type reached, reloading and setting timeout for next cycle."),X("enableHideGold",b.AuctionHoldGold||5),
window.location.reload()):Cf(`mod=auction&itemType=${e[h+1]}`):-1!==h&&(C("Auction Store: Toggling to mercenary mode for current type:",g),Cf(`mod=auction&itemType=${g}&ttype=3`))}},async list(b=!1){C(`${d.Af}`);var c=this.Vk;const e="true"===localStorage.getItem("AuctionGoldCover");let g=[];const k=localStorage.getItem("storeInShopQuality")||-1;for(let n=0;n<this.form.length;n++){let m=this.form[n];var h=m.querySelector(".ui-draggable"),l=m.querySelector(".auction_bid_div");l=(l=l?l.querySelector('input[type="text"], input[type="number"]'):
null)?Number(l.value):0;h=h?Tb(h):0;l<=h&&l<=c&&g.push({na:m,price:parseInt(l,10),value:h})}g.sort((n,m)=>m.price-n.price);for(let n of g)if(c=n.na.querySelector(".ui-draggable").getAttribute("data-quality"),!(Number(c)<Number(k))){if(c=(c=(c=n.na.querySelector(".auction_bid_div"))?c.querySelector("div > a"):null)?c.querySelector("span"):null){c=c.getAttribute("style");if(e&&c&&c.includes("green"))continue;if(!e&&c&&c.includes("green"))return!0;if(c&&c.includes("blue"))continue}lb.A.O.push([n.na.getAttribute("action"),
{auctionid:n.na.querySelector('input[name="auctionid"]').value,qry:n.na.querySelector('input[name="qry"]').value,itemType:n.na.querySelector('input[name="itemType"]').value,itemLevel:n.na.querySelector('input[name="itemLevel"]').value,itemQuality:n.na.querySelector('input[name="itemQuality"]').value,buyouthd:n.na.querySelector('input[name="buyouthd"]').value,bid_amount:n.price,bid:n.na.querySelector('input[name="bid"]').value}])}b&&await b()},async buy(){let b=lb.A.O.pop();await jQuery.ajax({type:"POST",
url:b[0],data:b[1]});0<lb.A.O.length?(await new Promise(c=>setTimeout(c,100)),await this.buy()):window.location.reload()}}},lh=localStorage.getItem("OillastRan"),mh=Date.now(),Ta={Kl:"minerva diana vulcanus mars apollo merkur".split(" "),zn:[20,60,150,0],Fm:[],async start(){"mod=gods"!=lf?Cf("mod=gods"):Ta.um(0)},xn(){let b=(new Date).getTime(),c=ya.en?ya.en:[1];if(5>c.length)return!0;for(let e=0;e<c.length;e++){if(c[e]&&c[e]<b||!c[e]&&(0==ya[Ta.Kl[e]]&&!ya.Nm||1==ya[Ta.Kl[e]]||2==ya[Ta.Kl[e]]))return!0;
!c[e]&&ya.Nm&&Pa.isUnderworld()}return!1},async Hn(){var b=$a.origin;const c=$a.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);return(new DOMParser).parseFromString(await b.text(),"text/html")},async um(b,c){if(c){var e=JSON.parse(localStorage.getItem("gods")),g=this.Kl[b],k=c.getElementById(g);k&&(c=parseInt(k.querySelector(".god_points").innerText.match(/\d+/)[0],10),k=k.querySelector(".god_cooldown span")?parseInt(k.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),
10):0,e=e[g],g=this.zn[e],c>=g&&0==k&&0<g&&0<=e&&(Ta.Fm.push(!1),jQuery.get(G({mod:"gods",submod:"activateBlessing",god:b+1,rank:e+1,sh:U("sh")}),()=>{Ta.Fm.push(!1);5>b&&Ta.um(++b)})))}},async Qo(){var b=$a.origin,c=$a.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);c=new DOMParser;await new Promise(e=>setTimeout(e,800));b=c.parseFromString(await b.text(),"text/html");c=JSON.parse(localStorage.getItem("gods"));for(let e in c)if((c=b.getElementById(e))&&0===(c.querySelector(".god_cooldown span")?
parseInt(c.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0))return!0;return!1}},eh,sj={async start(){const b=localStorage.getItem("healPercentage")||25;var c=JSON.parse(localStorage.getItem("underworld")).isUnderworld;const e=localStorage.getItem("HealEnabled"),g=localStorage.getItem("HellHealHP")||15,k=localStorage.getItem("useVillaMedici"),h=localStorage.getItem("useHealingPotion"),l="true"===localStorage.getItem("usePray");if("true"==e&&aa.o<=Number(b)||"true"==
e&&aa.o<=parseInt(g)||"true"==k&&da==ua&&aa.o<=b&&1==c||e&&"true"==h&&aa.o<=b&&1==c||e&&!c&&3>=Number(zh().Ea)&&localStorage.getItem("autoEnterHell")&&aa.o<=localStorage.getItem("hellEnterHP")){c=document.createElement("div");c.setAttribute("id","lowHealth");c.setAttribute("style","\n                display: block;\n                position: absolute;\n                top: 140px;\n                left: 50%;\n                transform: translateX(-30%);\n                width: 115px;\n                color: rgba(234, 20, 20, 0.9);\n                background-color: rgba(0, 0, 0, 0.8);\n                font-size: 20px;\n                border-radius: 5px;\n                border-left: 10px solid rgba(234, 20, 20, 0.9);\n                border-right: 10px solid rgba(234, 20, 20, 0.9);\n                will-change: transform, opacity;\n                z-index: 999;\n            ");
c.innerHTML='<span class="span-new">Low Health!</span>';document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);async function n(){if("inventoryPage"!==document.body.id)Cf("mod=inventory&sub=3&subsub=1");else{await new Promise(Q=>setTimeout(Q,500));const B=Array.from(document.querySelectorAll("#shop .ui-draggable")),v=aa.gold,D=$a.searchParams.get("doll")||"";let F=!1,I=0;localStorage.getItem("HealPickBag");let K=!1;for(const Q of B){if(I>=Number(localStorage.getItem("FoodAmount")))break;
var y=parseInt(Q.getAttribute("data-price-gold"),10),A=Q.getAttribute("data-basis");A=A&&"7"===A.split("-")[0];if(v>=y&&A){F=!0;localStorage.removeItem("healingStateX");y=Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));let Z;(A=localStorage.getItem("HealPickBag"))&&(Z=511+Number(A)||512);if(Z&&(A=document.querySelector(`#inventory_nav a.awesome-tabs[data-bag-number="${Z}"]`)))if(A.click(),await new Promise(ba=>setTimeout(ba,370)),A=document.getElementById("inv"),
hf(A,Q)){Aa(Q,"inv");I++;await new Promise(ba=>setTimeout(ba,370));if(I>=Number(localStorage.getItem("FoodAmount"))&&(await new Promise(ba=>setTimeout(ba,370)),"1"!==D)){Cf("mod=overview&doll=1");return}continue}else K=!0;if(K)for(const ba of y){if(I>=Number(localStorage.getItem("FoodAmount")))break;ba.click();await new Promise(ia=>setTimeout(ia,500));y=document.getElementById("inv");if(hf(y,Q)&&(Aa(Q,"inv"),I++,await new Promise(ia=>setTimeout(ia,370)),I>=Number(localStorage.getItem("FoodAmount"))&&
(await new Promise(ia=>setTimeout(ia,370)),"1"!==D))){Cf("mod=overview&doll=1");return}}}}F||(!F&&0==B.length&&"true"===localStorage.getItem("HealClothToggle")||0==B.length&&!F&&"true"===localStorage.getItem("HealClothToggle")&&"true"===localStorage.getItem("HealRubyToggle")?await M():(C(`${d.tf}`),localStorage.removeItem("healingStateX"),await new Promise(Q=>setTimeout(Q,3E4)),window.location.reload()));async function M(){if("true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")){if(document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')){var Q=
jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),Z=Q.attr("action");Q=Q.find('input[name="bestechen"]')[0];var ba=U("sh");await jQuery.post(`${Z}?mod=inventory&sub=3&subsub=1&sh=${ba}`,{bestechen:Q.value})?C(`${d.mb}`):C(`${d.nb}`)}else 0<zh().$m&&"true"===localStorage.getItem("HealRubyToggle")&&!document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')?(Q=jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),Z=Q.attr("action"),Q=Q.find('input[name="bestechen"]')[0],
ba=U("sh"),await jQuery.post(`${Z}?mod=inventory&sub=3&subsub=1&sh=${ba}`,{bestechen:Q.value})?C(`${d.mb}`):C(`${d.nb}`)):(C(`${d.wf}`),localStorage.setItem("HealClothToggle","false"),localStorage.setItem("HealRubyToggle","false"));window.location.reload()}else localStorage.removeItem("healingStateX"),setTimeout(()=>{window.location.reload()},6E4)}return!1}}async function m(){if("guild"==U("mod"))localStorage.setItem("useVillaMedici","false"),Cf("mod=overview");else if("guild_medic"!=U("mod"))Cf("mod=guild_medic");
else{var y=Array.from(document.querySelectorAll("#content a")).filter(({href:A})=>A.includes("mod=guild_medic"));0<y.length?window.location.href=y[0].href:(y=Math.min(...Array.from(document.querySelectorAll("span[data-ticker-time-left]")).map(A=>parseInt(A.getAttribute("data-ticker-time-left"),10))),isFinite(y)&&X("VillaMedici",Math.ceil(y/6E4)),l?(C(`${d.za}`),Cf("mod=underworld&submod=prayStart")):window.location.reload())}}async function r(){let y=!1;if("mod=premium&submod=inventory"!=lf)Cf("mod=premium&submod=inventory");
else{await new Promise(A=>setTimeout(A,500));for(let A=0,B=document.querySelectorAll(".contentboard_paper_repeat");A<B.length;A++)if(B[A].querySelector("img").src&&B[A].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")||B[A].querySelector("img").src&&B[A].querySelector("img").src.includes("token/18")||B[A].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")){y=!0;B[A].querySelector("input").click();Bf(1E3);return}y||(localStorage.setItem("useHealingPotion","false"),
l?(C(`${d.za}`),Cf("mod=underworld&submod=prayStart")):Bf(1E3))}}async function u(){try{let F=document.getElementById("inv"),I=0,K;var y=localStorage.getItem("HealPickBag"),A=localStorage.getItem("PackageSort");K=y?511+Number(y)||512:512;var B=Array.from(document.querySelectorAll(`#inventory_nav a.awesome-tabs[data-bag-number="${K}"]`));0<B.length&&B[0].click();B=1;let M=0,Q=!1;y=[];const Z=Number(localStorage.getItem("FoodAmount"))||1;let ba=!1;if(A&&"del_asc"===A||A&&"in_asc"===A)B=await ha.Sl(-1,
"",7),ba=!0;for(;!Q&&5>M;){var v=await jQuery.get(G({mod:"packages",f:"7",fq:"-1",qry:"",page:B.toString(),sh:U("sh")})),D=jQuery(v).find(".packageItem");if(0===D.length)C(`${d.xf} (Page ${B})`),M++,ba?B--:B++;else{y=[];for(A=0;A<D.length;A++){const la=D[A],wa=la.querySelector("[data-content-type]"),Ha=parseInt(wa.getAttribute("data-soulbound-to"),10),na=parseInt(wa.getAttribute("data-basis").split("-")[1],10);(![30,35].includes(na)&&isNaN(Ha)||![30,35].includes(na)&&Ha===Number(idkps))&&y.push(la)}0<
y.length?Q=!0:(C(`${d.ob} (Page ${B})`),M++,ba?B--:B++)}}if(!Q)return localStorage.setItem("healingStateX","true"),C(`${d.pb}`),!1;v=[5,8];const ia=Cc(F);for(D=0;I<Z&&D<y.length;){const la=y[D],wa=la.querySelector("[data-content-type]"),Ha=la.querySelector("input").getAttribute("value"),na=parseInt(wa.getAttribute("data-measurement-x"),10),va=parseInt(wa.getAttribute("data-measurement-y"),10),Wa=parseInt(wa.getAttribute("data-amount"),10),Rc=Dc(v[0],v[1],ia),Ya=Ec(va,na,Rc);if(Ya){ia.push({x:Ya.x,
y:Ya.y,Xk:va,w:na});await jQuery.post(R({mod:"inventory",submod:"move",from:"-"+Ha,fromX:1,fromY:1,to:K,toX:Ya.x+1,toY:Ya.y+1,amount:Wa}),{a:(new Date).getTime(),sh:U("sh")});I++;const ib=jQuery(wa).css({left:32*Ya.x,top:32*Ya.y});F.appendChild(ib[0]);C(`${d.uf}`);await new Promise(ic=>setTimeout(ic,500))}else return C(`${d.vf}`),!1;D++}if(0<I)return I>=Z?C(`${d.yf}`):C(`${d.zf}`),!0;C(`${d.pb}`);return!1}catch(F){return C(`Error in pickFood(): ${F}`),!1}}async function x(){var y=document.querySelector("#header_values_hp_bar");
const A=parseInt(y.getAttribute("data-value"),10);y=parseInt(y.getAttribute("data-max-value"),10);return{An:A,Xn:y}}async function q(){var y=JSON.parse(localStorage.getItem("underworld")).isUnderworld,A="true"===localStorage.getItem("useSacrifice");const B="true"===localStorage.getItem("HealShop"),v=localStorage.getItem("HellHealHP")||15,D="true"===localStorage.getItem("healingStateX"),F="true"===localStorage.getItem("HealPackage"),I=document.getElementById("sstat_ruby_val");let K=0;I&&(K=I.textContent.trim().replace(/\./g,
""),K=parseInt(K,10));if(D&&B)await n()?await q():(localStorage.removeItem("healingStateX"),await w());else if(!0===y||"true"===h&&!0===y||!0===A&&!0===y)"true"===localStorage.getItem("useVillaMedici")&&W("VillaMedici")?m():"true"===localStorage.getItem("useHealingPotion")?await r():A&&5<=Number(K)?(C("Sacrificing for heal."),Cf("mod=underworld&submod=offering")):l&&"mod=underworld&submod=pray"!=lf&&("true"===localStorage.getItem("HealEnabled")?aa.o<=Number(v):1)?(C(`${d.za}`),Cf("mod=underworld&submod=prayStart")):
l&&"mod=underworld&submod=pray"==lf&&("true"===localStorage.getItem("HealEnabled")?aa.o<=Number(v):1)?(await new Promise(M=>setTimeout(M,6E4)),C(`${d.Mf}`),window.location.reload()):(C(`${d.Nf}`),Bf(6E4));else if(0==y)if("1"!==((new URL(window.location.href)).searchParams.get("doll")||""))"mod=overview&doll=1"!=lf&&Cf("mod=overview&doll=1");else if(A=await w(),!A&&aa.o<=Number(b)||!A&&!y&&3>=Number(zh().Ea)&&localStorage.getItem("autoEnterHell")&&aa.o<=localStorage.getItem("hellEnterHP"))F?(y=await u(),
!y&&B?(localStorage.setItem("healingStateX","true"),n()):(y||(C(`${d.lb}`),await new Promise(M=>setTimeout(M,3E4))),window.location.reload())):B?(localStorage.setItem("healingStateX","true"),n()):(C(`${d.lb}`),await new Promise(M=>setTimeout(M,3E4)),window.location.reload())}async function t(y,A,B){let v=null,D=0,F=Infinity;const I=localStorage.getItem("idkps")||0,K="true"===localStorage.getItem("HealCervisia"),M="true"===localStorage.getItem("HealEggs");let Q=!1;K&&(Q=await rf());y.forEach(Z=>
{var ba=Z.getAttribute("data-basis");const ia=parseInt(Z.getAttribute("data-soulbound-to"),10);var la=(la=Z.getAttribute("data-tooltip").match(/Heals ([\d,\.]+) of life/))?parseInt(la[1].replace(/\./g,""),10):0;const wa=B-(A+la);if(!ia||ia===parseInt(I,10)){if(ba.startsWith("7-")){ba=parseInt(ba.split("-")[1],10);if(!M&&23<=ba&&34>=ba||!K&&35===ba)return;if(K&&35===ba&&Q)Q=!0;else if(35===ba&&K&&!Q)return}0<=wa&&wa<F?(v=Z,F=wa):0>wa&&la>D&&(D=la,v=Z)}});return v}async function w(){return new Promise(async y=>
{let A=!1;const {An:B,Xn:v}=await x();var D=new URL(window.location.href);const F=D.origin;D=D.searchParams.get("sh");if("mod=overview&doll=1"!=lf)Cf("mod=overview&doll=1");else{const ba="true"===localStorage.getItem("HealPackage"),ia="true"===localStorage.getItem("HealShop"),la="true"===localStorage.getItem("HealCervisia"),wa="true"===localStorage.getItem("HealEggs");let Ha=!1;la&&(Ha=await rf());var I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs")),K=I.findIndex(na=>na.classList.contains("current"));
I=I.slice(K).concat(I.slice(0,K));for(K=0;K<I.length;K++){var M=I[K];if("false"!==M.getAttribute("data-available")&&(await new Promise(na=>setTimeout(na,175)),M.click(),M.classList.contains("current"))){M=document.querySelectorAll("#inv .ui-draggable");M=Array.from(M).filter(na=>{const va=na.getAttribute("data-basis");na=parseInt(na.getAttribute("data-soulbound-to"),10);const Wa=parseInt(va.split("-")[1],10);if(!na||na===parseInt(idkps,10)){if(va.startsWith("7-")){if(!wa&&23<=Wa&&34>=Wa||!la&&35===Wa)return;
if(Ha&&la&&35===Wa)Ha=!0;else if(35===Wa&&la&&!Ha)return}return va&&"7"===va.split("-")[0]}});var Q=void 0,Z=!1;if(Pa.cooldown()&&"true"==localStorage.getItem("autoEnterHell")){Q=await (await fetch(`${F}/game/index.php?mod=hermit&sh=${D}`)).text();Q=(new DOMParser).parseFromString(Q,"text/html");Q=Array.from(Q.querySelectorAll('div[style="margin:20px"]'));for(let na of Q)if(na.querySelector('a[href^="index.php?mod=hermit&submod=underworld&sh="]')){Z=!0;break}}if(Z){Z=0;Q=localStorage.getItem("idkps");
for(const na of M)if(M=parseInt(na.getAttribute("data-soulbound-to"),10),(!M||M===parseInt(Q,10))&&"true"===localStorage.getItem("autoEnterHell"))if(na){if(await new Promise(va=>setTimeout(va,250)),await Aa(na,"avatar"),await new Promise(va=>setTimeout(va,450)),C(`${d.kb}`),Z++,2<=Z){window.location.reload();return}}else{M=!1;ba&&(M=await u());if(!M&&ia)return localStorage.setItem("healingStateX","true"),n(),!0;window.location.reload()}}else for(const na of M){A=!0;if(Z=await t(M,B,v)){await new Promise(va=>
setTimeout(va,250));await Aa(Z,"avatar");await new Promise(va=>setTimeout(va,450));C(`${d.kb}`);window.location.reload();return}Z=!1;ba&&(Z=await u());if(!Z&&ia){localStorage.setItem("healingStateX","true");n();return}window.location.reload()}}}y(A)}})}await q()}}},Pa={isUnderworld(){if("underworld"==document.getElementById("wrapper_game").className){var b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else b=JSON.parse(localStorage.getItem("underworld")||
"{}"),b.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(b));return(b=document.querySelector("#submenu2 a"))&&b.href.match(/mod=.*&sh/)&&"mod=underworld&submod=leave"===b.href.match(/mod=.*&sh/)[0].slice(0,-3)?!0:!1},Zi(){let b=JSON.parse(localStorage.getItem("underworld"))||{};if(void 0===b.Zi||!b.Zi)return!0;if(b.Zi)return!1},cooldown(){var b=(new Date).getTime();let c=JSON.parse(localStorage.getItem("underworld"))||{};c.cooldown=b;localStorage.setItem("underworld",JSON.stringify(c));
let e=document.getElementById("submenu2");e&&e.innerHTML.includes("index.php?mod=underworld")?c.isUnderworld=!0:c.isUnderworld=!1;if(ra.cooldown&&ra.cooldown>b)return!1;if(b=document.querySelectorAll(".buff-clickable"))for(let g of b)if(g.getAttribute("data-link")=="index.php?mod=location&sh="+U("sh"))return!1;return!0},async start(){function b(){var v=`expedition_info${parseInt(localStorage.getItem("farmEnemy"),10)||1}`,D=document.getElementById(v);if(!D)return!1;v=D.querySelector(".expedition_picture img");
D=D.querySelector(".expedition_picture .avatar_costume_animation");if(!v&&!D)return!1;if(v){var F=v.getAttribute("src");if(!F)return!1;F=!F.includes("904194973d21066c96cb414d04d676")}D&&(F=D.style.backgroundImage.match(/url\("(.+?)"\)/),v=null,F&&F[1]&&(v=F[1]),F=!v.includes("904194973d21066c96cb414d04d676"));return F}async function c(){if(Pa.isUnderworld||!t){0<(JSON.parse(localStorage.getItem("GodPowersHell"))||[]).length&&await e();var v="true"===localStorage.getItem("useWeaponBuff"),D=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||
[],F=[];v&&F.push({type:"weapon",Wb:"12-1",Il:[3]});if(0<D.length){const I={Helmet:2,Armor:5,Shield:4,Boots:10,Gloves:9};v=D.map(K=>I[K]).filter(K=>K);0<v.length&&F.push({type:"armor",Wb:"12-3",Il:v})}0<F.length&&await g(F);localStorage.setItem("usedGodPowers","true")}}async function e(){if("true"===localStorage.getItem("useGodPowersHell")){var v=JSON.parse(localStorage.getItem("GodPowersHell"))||[],D="Minerva Diana Vulcan Mars Apollo Mercury".split(" ");for(let F of v)if(v=D.indexOf(F),-1<v)try{await jQuery.get(G({mod:"gods",
submod:"activateBlessing",god:v+1,rank:1,sh:U("sh")})),C(`${F} power activated`)}catch(I){console.error(`Failed to activate ${F} power:`,I)}}}async function g(v){var D=v.map(I=>I.Wb);const F={};D=await k(D);Object.assign(F,D);for(let I of v.slice())if(D=F[I.Wb])await n(D,I.Il),v=v.filter(K=>K.Wb!==I.Wb),C(`${I.type.charAt(0).toUpperCase()+I.type.slice(1)} buff equipped on slots ${I.Il.join(", ")}`);0<v.length&&await h(v)}async function k(v){return new Promise(async D=>{const F={};var I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));
for(let K of I)if("false"!==K.getAttribute("data-available")){K.click();await new Promise(M=>setTimeout(M,200));I=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let M of I)if(I=M.getAttribute("data-basis"),v.includes(I)&&!F[I]){const Q=parseInt(M.getAttribute("data-position-x"),10),Z=parseInt(M.getAttribute("data-position-y"),10),ba=parseInt(M.getAttribute("data-container-number"),10);F[I]={fromX:Q,fromY:Z,from:ba};if(Object.keys(F).length===v.length){D(F);return}}}D(F)})}async function h(v){try{let D=
1;for(;1<=D&&7>=D&&0<v.length;){const F=await jQuery.get(G({mod:"packages",f:"12",page:D.toString(),sh:U("sh")})),I=Array.from(jQuery(F).find(".packageItem"));for(let K of I){const M=K.querySelector("[data-content-type]"),Q=K.querySelector("[data-container-number]");M.getAttribute("data-measurement-x");M.getAttribute("data-measurement-y");const Z=M.getAttribute("data-basis");Q.getAttribute("data-container-number");const ba=Q.getAttribute("data-container-number"),ia=v.find(la=>la.Wb===Z);if(ia&&await l(ba,
ia.Il)&&(C(`${ia.type.charAt(0).toUpperCase()+ia.type.slice(1)} buff equipped on slots ${ia.Il.join(", ")}`),v=v.filter(la=>la.Wb!==Z),0===v.length))return}D++}if(0<v.length)for(let F of v)C(`Could not find ${F.type} buff to equip.`)}catch(D){}}async function l(v,D){return new Promise((F,I)=>{ec(1,1,async(K,M)=>{try{await jQuery.post(R({}),{mod:"inventory",submod:"move",from:v,fromX:1,fromY:1,to:M,toX:K.x+1,toY:K.y+1,amount:1,a:(new Date).getTime(),sh:U("sh")});const Q={fromX:K.x+1,fromY:K.y+1,from:M};
await n(Q,D);F(Q)}catch(Q){console.error("Error moving item to inventory and equipping:",Q),I(Q)}})})}async function n(v,D){for(let F of D)await m(v.from,v.fromX,v.fromY,F,1,1,!0),await new Promise(I=>setTimeout(I,200))}async function m(v,D,F,I,K,M,Q=!1){v={mod:"inventory",submod:"move",from:v,fromX:D,fromY:F,to:I,toX:K,toY:M,amount:1,a:(new Date).getTime(),sh:U("sh")};Q&&(v.doll=1);await jQuery.post(R({}),v)}this.location=Array.from(document.querySelectorAll("#submenu2 a")).pop().href;var r="true"===
localStorage.getItem("farmEnable"),u=localStorage.getItem("farmLocation")||1;const x=localStorage.getItem("farmEnemy")||1;var q="true"===localStorage.getItem("useGodPowersHell");const t="true"===localStorage.getItem("usedGodPowers");var w=localStorage.getItem("hellLimit")||0;const y="true"===localStorage.getItem("EnableHellLimit");if(q&&!t){if("mod=overview&doll=1"!=lf){Cf("mod=overview&doll=1");return}await c()}let A;r&&(A=b());q=localStorage.getItem("HellHealHP")||15;aa.o>=Number(q)&&await jQuery.get(G({mod:"underworld",
submod:"prayEnd",sh:U("sh")}));if("true"==localStorage.getItem("exitUnderworld")&&0==Number(zh().Ea))w=JSON.parse(localStorage.getItem("underworld")),w.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(w)),await jQuery.get(G({mod:"underworld",submod:"exit",sh:U("sh")})),C(`${d.Of}`),location.reload();else{if(0==Number(zh().Ea)&&"true"==localStorage.getItem("UnderworldUseMobi")){if("mod=premium&submod=inventory"!==lf){Cf("mod=premium&submod=inventory");return}q=document.querySelectorAll(".contentboard_paper_repeat");
for(var B=0;B<q.length;){q[B].querySelector("img").src&&(q[B].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7")||q[B].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7"))?q[B].querySelector("input").click():localStorage.setItem("UnderworldUseMobi","false");Bf(500);return}}B=document.querySelector("#submenu2");q=B.querySelector(`#location_inactive_${u}`);B=B.querySelector(`a[href*="loc=${u}"]`);q=q&&q.classList.contains("inactive");if(!r||q&&!B||lf===`mod=location&loc=${u}`)if(r&&
lf==`mod=location&loc=${u}`&&A&&(!y||y&&0<w))r=parseInt(x,10),u=document.getElementsByClassName("expedition_button"),y&&(w--,localStorage.setItem("hellLimit",w)),u[r-1].click(),Bf(5E3);else if(window.location.href!=this.location)window.location.href=this.location;else{await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:U("sh")}));let v=0;Array.from(document.querySelectorAll(".expedition_box")).forEach(D=>{D.querySelector(".expedition_picture img")&&D.querySelector("img").src.includes("904194973d21066c96cb414d04d676")&&
v++});document.querySelector("#content .icon_expeditionpoints")&&0<Number(zh().Ea)||"true"==localStorage.getItem("UnderWorldUseRuby")&&"0"==zh().Ea?(N("underworldAttacks",0),document.querySelectorAll(".expedition_button")[Math.floor(3-v)].click()):(C(`${d.Pf}`),await new Promise(D=>setTimeout(D,6E4)),Bf())}else Cf(`mod=location&loc=${u}`)}},async Fn(){let b=0;const c=["normal","medium","hard"][parseInt(localStorage.getItem("hellDifficulty"),10)||0],e=G({mod:"hermit",submod:"enterUnderworld",sh:U("sh")}),
g={};g[`difficulty_${c}`]=c.charAt(0).toUpperCase()+c.slice(1);try{await jQuery.post(e,g),localStorage.setItem("usedGodPowers","false"),await new Promise(k=>{const h=++b;var l=!document.hidden;let n=1;var m=jQuery("#server-time");0<m.length&&(m=m.next().html())&&(m=m.match(/x(\d+)$/)||["0","1"],m=parseInt(m[1],10),0<m&&(n=5/m));l=l?400:400*n;if("undefined"!==typeof Worker){const r=URL.createObjectURL(new Blob(["\n                            const timers = {};\n                            self.onmessage = function(event) {\n                                const { type, id, delay } = event.data;\n                                if (type === 'setTimeout') {\n                                    timers[id] = setTimeout(() => {\n                                        self.postMessage({ type: 'timeout', id });\n                                        delete timers[id];\n                                    }, delay);\n                                }\n                                if (type === 'clearTimeout') {\n                                    if (timers[id]) {\n                                        clearTimeout(timers[id]);\n                                        delete timers[id];\n                                    }\n                                }\n                            };\n                        "],
{type:"application/javascript"})),u=new Worker(r),x=q=>{"timeout"===q.data.type&&q.data.id===h&&(k(),u.removeEventListener("message",x),u.terminate(),URL.revokeObjectURL(r))};u.addEventListener("message",x);u.postMessage({type:"setTimeout",id:h,delay:l})}else setTimeout(()=>{k()},l)}),window.location.reload()}catch(k){}}};null===localStorage.getItem("DELAY")&&localStorage.setItem("DELAY","0 seconds");var wc=localStorage.getItem("DELAY");if(wc.includes("to")){const b=wc.split(" "),c=parseInt(b[0],
10);var xc=Math.floor(Math.random()*(parseInt(b[2],10)-c+1))+c}else xc=parseInt(wc.split(" ")[0],10);wc.includes("minute")&&(xc*=60);var nh=1E3*xc,tj=localStorage.getItem("costumeUnderworld"),uj=["9","10","11"],yc="true"===localStorage.getItem("activateAuction2"),oh="true"===localStorage.getItem("auctionTURBO"),zc="true"===localStorage.getItem("bidFood"),ph=9<aa.level,qh="true"===localStorage.getItem("enableCircusWithoutHeal"),rh="true"===localStorage.getItem("auctiongladiatorenable"),th="true"===
localStorage.getItem("auctionmercenaryenable"),Ac="true"===localStorage.getItem("enableMercenarySearch"),df="true"===localStorage.getItem("EnableArenaHell"),vj="true"===localStorage.getItem("dontEnterUnderworld"),Bc=0<JSON.parse(localStorage.getItem("auctionPrefixes")).length||0<JSON.parse(localStorage.getItem("auctionSuffixes")).length,Ab=localStorage.getItem("auctionStatus")>=localStorage.getItem("bidStatus"),uh=localStorage.getItem("auctionMStatus")>=localStorage.getItem("bidStatus"),mb=JSON.parse(localStorage.getItem("underworld")),
Bb=W("auction"),vh=W("auctionM"),wh=localStorage.getItem("MarketlastRan"),wj=localStorage.getItem("MarketSearchInterval")||5,xj=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),yj=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),xh=JSON.parse(localStorage.getItem("itemsToReset")||"[]");pa&&"true"===localStorage.getItem("activateRepair")&&ij();if(pa&&(0<Object.keys(xj).length||0<Object.keys(yj).length)&&"true"===localStorage.getItem("activateRepair")&&W("repair")&&!window.location.href.includes("/index.php?mod=hermit&submod=underworld")&&
da==ua&&1E4<zh().gold&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)){const b="true"===localStorage.getItem("repairGladiator"),c="true"===localStorage.getItem("repairMercenary");let e=[],g=[];const k=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),h=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}");async function l(q,t,w){const y=localStorage.getItem("repairPercentage"),A=null!==y?parseInt(y,10)/100:.1;q=await (await fetch(`${q}/game/index.php?mod=overview&doll=${t}&sh=${w}`)).text();
q=(new DOMParser).parseFromString(q,"text/html").getElementById("char").querySelectorAll("div[data-tooltip]");w=(w=localStorage.getItem("workbenchItem"))?JSON.parse(w):{};w.selectedItem=w.selectedItem||{};let B=[];q.forEach(v=>{if(v.classList.contains("ui-draggable")){let D=Sb(v),F=v.getAttribute("data-container-number"),I=v.getAttribute("data-measurement-x"),K=v.getAttribute("data-measurement-y"),M=JSON.parse(v.getAttribute("data-tooltip")).pop().pop()[0].match(/\d+/g);null!=M&&M[0]/M[1]<A&&B.push({type:Db(v).split("-")[0],
quality:nb(v),name:D,doll:t,container:F,Rm:I,Sm:K})}});return B}const n=$a.origin,m=$a.searchParams.get("sh")||"";let r=localStorage.getItem("workbenchItem");r=r?JSON.parse(r):{};b&&(e=await l(n,1,m),localStorage.setItem("itemList1",JSON.stringify(e)),sa.itemList1=e);c&&(g=await l(n,2,m),localStorage.setItem("itemList2",JSON.stringify(g)),sa.itemList2=g);const u=JSON.parse(localStorage.getItem("Timers"));r.selectedItem||(b&&c?0===e.length&&0===g.length&&X("repair",u.Repair||10):b?0===e.length&&X("repair",
u.Repair||10):c?0===g.length&&X("repair",u.Repair||10):X("repair",u.Repair||10));function x(q,t,w){return Array.isArray(q)&&0!==q.length?q.filter(y=>{const A=Object.keys(t).find(B=>t[B]===y.container);return A?!1!==w[A]:!0}):q}e=x(e,{helmet:"2",necklace:"11",weapon:"3",armor:"5",shield:"4",gloves:"9",shoes:"10",rings1:"6",rings2:"7"},k);g=x(g,{helmetM:"2",necklaceM:"11",weaponM:"3",armorM:"5",shieldM:"4",glovesM:"9",shoesM:"10",rings1M:"6",rings2M:"7"},h);localStorage.setItem("itemList1",JSON.stringify(e));
localStorage.setItem("itemList2",JSON.stringify(g));sa.itemList1=e;sa.itemList2=g;if(r.selectedItem&&!0===r.selectedItem.enable){let q=e.findIndex(t=>t.name===r.selectedItem.item.name);-1!==q&&e.splice(q,1);q=g.findIndex(t=>t.name===r.selectedItem.item.name);-1!==q&&g.splice(q,1);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(g))}if(b&&0<e.length||c&&0<g.length||r.selectedItem&&0<Object.keys(r.selectedItem).length)await rj.start();else{const q=
JSON.parse(localStorage.getItem("Timers"));X("repair",q.Repair||10);window.location.reload()}}else if(0==await Zi(ua,Zb,qa))eb();else if((yc||zc||Ac)&&oh&&yc&&pa&&ph&&(rh&&Bc&&Ab&&Bb&&W("AuctionEmpty")||zc&&Ab&&Bb&&W("AuctionEmpty")||Ac&&Ab&&Bb&&W("AuctionMEmpty")||th&&Bc&&uh&&vh&&W("AuctionMEmpty")))await za.start();else if(pa&&3>=Number(zh().Ea)&&!0===Ba&&"true"===localStorage.getItem("autoEnterHell")&&100<=aa.level&&8E3<=aa.gold&&aa.o>Number(localStorage.getItem("hellEnterHP"))&&Pa.cooldown()&&
(vj?Pa.Zi():1))await Pa.Fn();else if(1==pa&&"true"===localStorage.getItem("OilEnable")&&Ta.xn()&&(!lh||36E5<=mh-lh)){C(`${d.Bf}`);localStorage.setItem("OillastRan",mh.toString());const b=await Ta.Hn();for(let c=0;c<Ta.Kl.length;c++)await Ta.um(c,b);C(`${d.Cf}`);Ye()}else if(pa&&(aa.o<=Number(localStorage.getItem("healPercentage"))&&"true"===localStorage.getItem("HealEnabled")&&!Pa.isUnderworld()||3>=Number(zh().Ea)&&!Pa.isUnderworld()&&Pa.cooldown()&&"true"===localStorage.getItem("autoEnterHell")&&
aa.o<=Number(localStorage.getItem("hellEnterHP"))||Pa.isUnderworld()&&"true"===localStorage.getItem("autoEnterHell")&&aa.o<=Number(localStorage.getItem("HellHealHP"))))await sj.start();else if(pa&&Ba&&"true"===localStorage.getItem("autoEnterHell")&&Pa.isUnderworld()&&zh().Gn)await Pa.start();else if(pa&&"true"==localStorage.getItem("useCostume")&&(!window.location.href.includes("/index.php?mod=hermit")&&W("CheckDolls")&&uj.some(b=>tj.includes(b))||!window.location.href.includes("/index.php?mod=hermit")&&
W("CheckDolls")))await bf.start();else if(pa&&(!0===La&&J()&&da==ua||!0===La&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&Qb<Rb&&da==ua)){localStorage.setItem("nextQuestTime.timeOut",0);localStorage.setItem("nextQuestTime",0);function b(k){const h={Diana:"026bb622a42b4d00abc74c67f28d63",Apollo:"bb75bf0df76de3ec421bbfb0eac3c5",Vulcan:"6fbd05e43d699e65fc40cc92a17c51",Minerva:"72919cc6b457bf475fb81cc7de8863",Mercury:"5e272e2aade20b4a266e48663421ce",
Mars:"5fd915f85b3e5e71b64632af0c6543"};k=k.querySelectorAll(".quest_slot_reward img");for(const l of k){k=l.getAttribute("src");for(const [n,m]of Object.entries(h))if(k.includes(m)&&"true"===localStorage.getItem(`questType${n}`))return!0}}function c(k){var h=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]").map(n=>n.toLowerCase());const l=parseInt(localStorage.getItem("questrewardvalue"),10);if(k=$(k).find(".quest_slot_reward_item")[0]){const n=k.outerHTML.toLowerCase();if(h.some(m=>n.includes(m))&&
(h=n.match(/(\d+\.\d+)/))&&parseFloat(h[0].replace(".",""))>=l)return!0}return!1}async function e(){var k=$a.origin,h=$("#content .contentboard_slot a.quest_slot_button_accept"),l="true"===localStorage.getItem("skipTimeQuests");const n="true"===localStorage.getItem("skipTimeCircusQuests"),m="true"===localStorage.getItem("skipTimeOtherQuests"),r="true"===localStorage.getItem("acceptnotfilter"),u="true"===localStorage.getItem("UnderworldQuests"),x=JSON.parse(localStorage.getItem("questKeywords")||"[]"),
q=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]"),t=JSON.parse(localStorage.getItem("underworldQuestKeywords")||"[]"),w=JSON.parse(localStorage.getItem("underworld")||"{}");var y=$("#content .contentboard_slot_inactive").toArray();if(h.length){function A(B){return B.includes("8aada67d4c5601e009b9d2a88f478c")?"combat":B.includes("00f1a594723515a77dcd6d66c918fb")?"arena":B.includes("586768e942030301c484347698bc5e")?"circus":B.includes("4e41ab43222200aa024ee177efef8f")?"expedition":B.includes("dc366909fdfe69897d583583f6e446")?
"dungeon":B.includes("5a358e0a030d8551a5a65d284c8730")?"items":null}h=!1;for(const B of y){let v=B.getElementsByClassName("quest_slot_title")[0].innerText;y=A(B.getElementsByClassName("quest_slot_icon")[0].style.backgroundImage);if(!(l&&0<B.getElementsByClassName("quest_slot_time").length&&"arena"==y||n&&0<B.getElementsByClassName("quest_slot_time").length&&"circus"==y||m&&0<B.getElementsByClassName("quest_slot_time").length&&"circus"!==y&&"arena"!==y)){if(1==w.isUnderworld&&u&&!h&&0<t.length&&Ma[y]&&
u){const D=$(B).find(".quest_slot_reward_item img[data-tooltip]")[0];if(D){y=D.getAttribute("data-tooltip");const F=JSON.parse(y.replace(/&quot;/g,'"'))[0][0][0].toLowerCase();if(t.some(I=>F.includes(I.toLowerCase()))){l=B.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();h=!0;break}else continue}}if(!x.some(D=>v.includes(D))){if(Ma[y]&&b(B)){l=B.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();
h=!0;break}if(Ma[y]&&c(B)&&!r){l=B.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();h=!0;break}if(Ma[y]&&q.some(D=>v.includes(D))){l=B.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();h=!0;break}!h&&Ma[y]&&r||h||!Ma[y]||r||0!==q.length||(h=B.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),await jQuery.get(h).done(),h=!0)}}}if(h)return;k=`${k}/game/index.php?mod=quests&submod=resetQuests&sh=${U("sh")}`;
await jQuery.get(k).done();window.location.reload()}g()}async function g(){var k=$("#quest_header_cooldown");let h;switch(localStorage.getItem("questSpeed")){case "0":h=15E4;break;case "1":h=2E5;break;case "2":h=25E4;break;case "3":h=3E5;break;case "4":h=4E5;break;default:h=3E5}k.length?(k=Number($("#quest_header_cooldown b span").attr("data-ticker-time-left")),Qb=Rb+k):Qb=Rb+h;localStorage.setItem("nextQuestTime",Qb);window.location.reload()}await async function(){if("mod=quests"!=lf)Cf("mod=quests");
else{let k=[];const h=[],l=[];document.querySelectorAll("a.quest_slot_button_finish").forEach(r=>{r.href&&k.push(r.href)});document.querySelectorAll(".quest_slot_button_restart").forEach(r=>{r.href&&h.push(r.href)});document.querySelectorAll(".quest_slot_button_accept").forEach(r=>{r.href&&l.push(r.href)});async function n(r){try{r<k.length&&(await jQuery.get(k[r]),await n(r+1))}catch(u){}}async function m(r){try{r<h.length&&(await jQuery.get(h[r]),await m(r+1))}catch(u){console.error("Error in completeQuestsForLink:",
u)}}await async function(){0<k.length&&await n(0);0<h.length&&await m(0);0<l.length&&await e();await g()}()}}()}else if(pa&&Hc()&&!0===Ba&&0==mb.isUnderworld&&da==ua&&0==yb.isUnderworld&&fa>=new Date&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&!0===document.getElementById("cooldown_bar_fill_expedition").classList.contains("cooldown_bar_fill_ready"))await async function(){function b(){const h=document.getElementById("errorText");"false"===
localStorage.getItem("HealEnabled")?(Ua("Your expedition/dungeon settings are incorrect!"),localStorage.setItem("HealEnabled","true"),Bf(5E3)):h&&""!==h.innerText.trim()&&location.reload()}var c=localStorage.getItem("expeditionLocation");if(lf!=`mod=location&loc=${c}`)Cf(`mod=location&loc=${c}`);else if("true"===localStorage.getItem("nana_lcn")&&Zb){var e="true"===localStorage.getItem("autoCollectBonuses"),g=localStorage.getItem("selectedEnemy")||0;c=document.getElementsByClassName("expedition_button");
var k=document.querySelectorAll(".expedition_button.disabled");try{if(N("expeditionAttacks",0),e)for(await new Promise(h=>setTimeout(h,800)),e=0;e<c.length;e++){if(4>c[e].closest(".expedition_box").querySelectorAll(".expedition_bonus.active").length||3===e){c[e].click();break}if(4<=k.length){window.location.reload();break}else setTimeout(b,800)}else c[parseInt(g,10)].click(),4<=k.length?window.location.reload():setTimeout(b,800)}catch{C("There's a problem with the expedition, refreshing the page."),
window.location.reload()}}}();else if(pa&&!0===Fa&&!mb.isUnderworld&&da==ua&&9<aa.level&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&zh().En&&"none"!==document.getElementById("cooldown_bar_dungeon").style.display&&!0===document.getElementById("cooldown_bar_fill_dungeon").classList.contains("cooldown_bar_fill_ready"))await async function(){if("true"===localStorage.getItem("nana_lcn")&&Zb){var b=localStorage.getItem("dungeonLocation")||"1",c=
"true"===localStorage.getItem("skipBoss"),e="true"===localStorage.getItem("resetIfLose"),g="true"===localStorage.getItem("loose"),k="true"===localStorage.getItem("dungeonFocusQuest"),h="chefe Chefe \u0161\u00e9f chef chef juht boss Boss jefe jefe jefe patron capo vad\u012bt\u0101js vadovas f\u0151n\u00f6k patron Patron \u0428\u0435\u0444 baas sjef szef chefe \u0219ef \u0161\u00e9f \u0161ef pomo chef patron \u0645\u062f\u064a\u0631 \u03b1\u03c6\u03b5\u03bd\u03c4\u03b9\u03ba\u03cc \u0448\u0435\u0444 \u0431\u043e\u0441\u0441 \u8001\u677f".split(" ");
if(lf!=`mod=dungeon&loc=${b}`)Cf(`mod=dungeon&loc=${b}`);else{b=!document.getElementById("content").getElementsByTagName("area")[0];const m=document.getElementById("content").getElementsByClassName("button1");if(2<=m.length){c=m[0].getAttribute("name");e=m[1].getAttribute("name");try{if(b){const r=(new URLSearchParams(window.location.search)).get("loc");"normal"===Gb&&"dif1"===c?(jQuery.post(G({mod:"dungeon",loc:r,sh:U("sh")}),{dif1:Gb}),m[0].click(),window.location.reload()):"dif2"===e?(jQuery.post(G({mod:"dungeon",
loc:r,sh:U("sh")}),{dif2:Gb}),m[1].click(),window.location.reload()):(Ua("Incorrect dungeon/expedition settings"),setTimeout(()=>{Bf()},1E4))}}catch(r){location.reload()}}else if(b)window.location.reload();else try{const r=document.querySelector("#content .map_label"),u=r&&r.textContent.toLowerCase(),x=Array.from(document.querySelectorAll("#content .map_label")).find(q=>h.some(t=>t===q.textContent));N("dungeonAttacks",0);if(e&&g)localStorage.setItem("loose","false"),document.querySelectorAll("#content .button1")[0].click();
else if(c&&u&&x)document.querySelectorAll("#content .button1")[0].click();else if(u&&x&&"true"===localStorage.getItem("dungeonAB"))x.click();else if(k){var l=0,n=null;document.querySelectorAll('[onclick*="startFight"]').forEach(function(q){var t=q.getAttribute("onclick").match(/startFight\('(\d+)',/);t&&t[1]&&(t=parseInt(t[1],10),t>l&&(l=t,n=q))});n?n.click():window.location.reload()}else document.querySelector("#content area").click()}catch{window.location.reload()}}}}();else if(pa&&(!0===Ga||mb.isUnderworld&&
df)&&(!mb.isUnderworld||mb.isUnderworld&&df)&&da==ua&&ua===Ic&&fa>=new Date&&(mb.isUnderworld||"true"!==localStorage.getItem("HealEnabled")||aa.o>Number(localStorage.getItem("healPercentage"))||mb.isUnderworld&&aa.o>Number(localStorage.getItem("HellHealHP")))&&!0===document.getElementById("cooldown_bar_fill_arena").classList.contains("cooldown_bar_fill_ready")){async function b(){var k=new URL(window.location.href),h=k.origin;k=k.searchParams.get("sh")||"";var l=localStorage.getItem("scoreRange"),
n=[];h=await (await fetch(`${h}/game/index.php?mod=highscore&sh=${k}&a=${l}`)).text();h=(new DOMParser).parseFromString(h,"text/html");h=Array.from(h.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(m=>(m=m.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===m.style.color||"blue"===m.style.color):null===m);n=[...n,...h];if(0===n.length)return console.log("No players available to attack"),!1;h=JSON.parse(localStorage.getItem("avoidAttackList"))||
[];l=function(m){for(var r=m.length,u,x;0!==r;)x=Math.floor(Math.random()*r),--r,u=m[r],m[r]=m[x],m[x]=u;return m}(n);n=0;for(let m of l)if(l=m.textContent.toLowerCase(),!h.map(r=>r.toLowerCase()).includes(l)){l=await c(m.textContent,k);if(l.includes("index.php?mod=reports")){k=(new URLSearchParams(l)).get("reportId");C(`${d.xa}`+m.textContent);Cf(`mod=reports&submod=showCombatReport&t=2&reportId=${k}`);await new Promise(r=>setTimeout(r,500));return}n++;if(3<=n)break}return!1}async function c(k,h){try{const l=
(new URL(window.location.href)).origin;return await (await fetch(`${l}/game/ajax/doArenaFight.php?dname=${k}&a=${(new Date).getTime()}&sh=${h}`,{method:"POST"})).text()}catch{Bf(1E3)}}async function e(k){var h=k.opponentId;const l=k.serverId;k=k.country;var n=(new URL(window.location.href)).origin;n=new URL(`${n}/game/ajax.php`);h={mod:"arena",submod:"doCombat",aType:2,opponentId:h,serverId:l,country:k.toString(),a:(new Date).getTime(),sh:U("sh")};n.search=(new URLSearchParams(h)).toString();return await (await fetch(n,
{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function g(){function k(q){const t=null!==q.querySelector("span[style*='color:green;']");return Array.from(q.querySelectorAll("a, span")).find(w=>"green"===w.style.color||"bold"===w.style.fontWeight)||t}var h=new URL(window.location.href);const l=h.origin;var n=await (await fetch(`${l}/game/index.php?mod=arena&sh=${U("sh")}`)).text();n=(new DOMParser).parseFromString(n,"text/html");
var m=Array.from(n.querySelectorAll('table[width="80%"] tbody tr')).filter(q=>q.querySelector(".attack"));if(m.length&&1!==m.length){var r=null;n=JSON.parse(localStorage.getItem("avoidAttackList"))||[];if("true"===localStorage.getItem("leaguerandom")){m=m.sort(()=>Math.random()-.5);for(var u of m){var x=u.querySelector("a");x=x?x.innerText:null;if(!k(u)&&!n.includes(x)){r=u;break}}}else if("true"===localStorage.getItem("leaguelowtohigh")){m=m.sort((q,t)=>parseInt(q.querySelector("th")?q.querySelector("th").textContent:
"0",10)-parseInt(t.querySelector("th")?t.querySelector("th").textContent:"0",10));u=null;r=-1;for(x of m)m=(m=x.querySelector("a"))?m.innerText:null,k(x)||n.includes(m)||(m=parseInt(x?.querySelector("th")?.textContent,10),m>r&&(r=m,u=x));r=u}if(null===r)localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","false"),localStorage.setItem("leagueattackenable","false"),Bf(500);else if(r)if(n=r.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],x=(new Date).getTime(),
h=h.searchParams.get("sh")||"",await new Promise(q=>setTimeout(q,250)),h=await (await fetch(`${l}/game/ajax/doArenaFight.php?did=${n}&a=${x}&sh=${h}`)).text(),(n=h.match(/document\.location\.href\s*=\s*'([^']+)'/))&&n[1])window.location=`${l}/game/${n[1]}`;else{h.includes("5")&&("true"===localStorage.getItem("leaguelowtohigh")?(localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","true")):"true"===localStorage.getItem("leaguerandom")&&(localStorage.setItem("leaguerandom",
"false"),localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leagueattackenable","false")),location.reload());if(h.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leagueattackenable","false"),location.reload()}mb.isUnderworld&&df&&await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:U("sh")}));await async function(){function k(y){const A=Date.now(),B=q.findIndex(v=>v.playerName===y);-1<B?q[B].timeout=A:q.push({playerName:y,timeout:A});localStorage.setItem("playerTimeouts",
JSON.stringify(q))}function h(y,A){const B=Date.now();if(Array.isArray(q)){const v=q.find(D=>D.playerName===y);return!v||B-v.timeout>A}return!q[y]||B-q[y]>A}function l(y){for(var A=y.length-1;0<A;A--){const B=Math.floor(Math.random()*(A+1));[y[A],y[B]]=[y[B],y[A]]}2<y.length&&(A=y.splice(0,2),y.push(...A));return y}async function n(y,A,B){try{const v=A.match(/\d+/)[0],D=A.match(/\w+/g)[2],F=(new URLSearchParams(A)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:B,aType:y,
opponentId:F,serverId:v,country:D}));const I=await jQuery.get(R({mod:"arena",submod:"confirmDoCombat",aType:y,opponentId:F,serverId:v,country:D,a:(new Date).getTime(),sh:U("sh")})),K=(new URLSearchParams(I)).get("reportId");K||window.location.reload();Cf(`mod=reports&submod=showCombatReport&t=${y}&reportId=${K}`)}catch(v){document.getElementById("content").querySelector("form > input").click(),Bf(1E3)}}"true"===localStorage.getItem("leagueattackenable")&&await g();"true"===localStorage.getItem("scoreboardattackenable")&&
await b();var m=(new URL(window.location.href)).searchParams.get("sh")||"",r=JSON.parse(localStorage.getItem("autoAttackList"))||[];let u=JSON.parse(localStorage.getItem("autoAttackServerList"))||[];const x=JSON.parse(localStorage.getItem("avoidAttackList"))||[];let q=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const t="true"===localStorage.getItem("onlyArena");if(W("arena")&&0<r.length||W("arena")&&0<u.length||t)try{l(r);localStorage.setItem("autoAttackList",JSON.stringify(r));l(u);localStorage.setItem("autoAttackServerList",
JSON.stringify(u));let y=0,A=2,B=0,v=0;for(t&&(A=10);y<A&&(B<r.length||v<u.length);){let D,F,I;(I=B<r.length&&v<u.length?.5>Math.random():v<u.length)?(F=u[v],D=F.playerName,v++):(D=r[B],B++);if(!x.includes(D)&&(h(D,6E4*(10+Math.floor(36*Math.random())))||t)){let K;K=I?await e(F):await c(D,m);N("arenaAttacks",0);if(K.includes("index.php?mod=reports")&&!K.includes("errorRow")){k(D);C(`${d.xa}`+D);window.location.reload();break}}y++}if(y===A){const D=JSON.parse(localStorage.getItem("Timers"));X("arena",
D.Arena||5)}}catch(y){window.location.reload()}if("mod=arena&submod=serverArena&aType=2"!=lf)Cf("mod=arena&submod=serverArena&aType=2");else try{let y=[...r,...u].map(v=>v.playerName);var w=Array.from(document.querySelectorAll("#own2 tr")).slice(1);const A="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),B="true"===localStorage.getItem("attackRandomly");m=null;r=Infinity;localStorage.getItem("Username");localStorage.getItem("enableArenaSimulator");localStorage.getItem("ArenaSimulatorAmount");
for(let v of w){const D=v.querySelector("a");w=2;B&&(w=Math.floor(5*Math.random())+2);const F=v.querySelector(`td:nth-child(${w})`);if(D&&F){const I=D.innerText,K=parseInt(F.textContent.trim(),10),M=x.includes(I),Q=null!==D.querySelector("span[style*='color:green;']"),Z="green"===D.style.color;if(!(M||!A&&Q&&Z)){if(y.includes(I)){C(`${d.xa}`+I);m=D;break}!m&&K<r&&(r=K,m=D)}}}if(m)await n(2,m.href,m.outerText),N("arenaAttacks",0);else{const v=document.querySelector('form[name="filterForm"] input[type="submit"]');
v&&v.click()}}catch{window.location.reload()}}()}else if(pa&&!0===Ca&&9<aa.level&&da==ua&&!0===document.getElementById("cooldown_bar_fill_ct").classList.contains("cooldown_bar_fill_ready")){async function b(){var h=new URL(window.location.href),l=h.origin;h=h.searchParams.get("sh")||"";var n=localStorage.getItem("scoreRangeCircus"),m=[];l=await (await fetch(`${l}/game/index.php?mod=highscore&sh=${h}&a=${n}`)).text();l=(new DOMParser).parseFromString(l,"text/html");l=Array.from(l.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(r=>
(r=r.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===r.style.color||"blue"===r.style.color):null===r);m=[...m,...l];if(0===m.length)return console.log("No players available to attack"),!1;l=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];n=function(r){for(var u=r.length,x,q;0!==u;)q=Math.floor(Math.random()*u),--u,x=r[u],r[u]=r[q],r[q]=x;return r}(m);m=0;for(let r of n)if(n=r.textContent.toLowerCase(),!l.map(u=>u.toLowerCase()).includes(n)){n=await c(r.textContent,
h);if(n.includes("index.php?mod=reports")){h=(new URLSearchParams(n)).get("reportId");C(`${d.ya}`+r.textContent);Cf(`mod=reports&submod=showCombatReport&t=3&reportId=${h}`);await new Promise(u=>setTimeout(u,500));return}m++;if(3<=m)break}return!1}async function c(h,l){try{const n=(new URL(window.location.href)).origin;return await (await fetch(`${n}/game/ajax/doGroupFight.php?dname=${h}&a=${Date.now()}&sh=${l}`,{method:"POST"})).text()}catch{Bf(1E3)}}async function e(h){var l=h.opponentId;const n=
h.serverId;h=h.country;var m=(new URL(window.location.href)).origin;m=new URL(`${m}/game/ajax.php`);l={mod:"arena",submod:"doCombat",aType:3,opponentId:l,serverId:n,country:h.toString(),a:(new Date).getTime(),sh:U("sh")};m.search=(new URLSearchParams(l)).toString();return await (await fetch(m,{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function g(){function h(t){const w=null!==t.querySelector("span[style*='color:green;']");
return Array.from(t.querySelectorAll("a, span")).find(y=>"green"===y.style.color||"bold"===y.style.fontWeight)||w}var l=new URL(window.location.href);const n=l.origin;var m=await (await fetch(`${n}/game/index.php?mod=arena&submod=grouparena&sh=&sh=${U("sh")}`)).text();m=(new DOMParser).parseFromString(m,"text/html");var r=Array.from(m.querySelectorAll('table[width="80%"] tbody tr')).filter(t=>t.querySelector(".attack"));if(r.length&&1!==r.length){var u=null;m=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||
[];if("true"===localStorage.getItem("leaguecircusrandom")){r=r.sort(()=>Math.random()-.5);for(var x of r){var q=x.querySelector("a");q=q?q.innerText:null;if(!h(x)&&!m.includes(q)){u=x;break}}}else if("true"===localStorage.getItem("leaguecircuslowtohigh")){r=r.sort((t,w)=>parseInt(t.querySelector("th")?t.querySelector("th").textContent:"0",10)-parseInt(w.querySelector("th")?w.querySelector("th").textContent:"0",10));x=null;u=-1;for(q of r)r=(r=q.querySelector("a"))?r.innerText:null,h(q)||m.includes(r)||
(r=parseInt(q?.querySelector("th")?.textContent,10),r>u&&(u=r,x=q));u=x}if(null===u)localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircusattackenable","false"),Bf(500);else if(u)if(m=u.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],q=(new Date).getTime(),l=l.searchParams.get("sh")||"",await new Promise(t=>setTimeout(t,250)),l=await (await fetch(`${n}/game/ajax/doGroupFight.php?did=${m}&a=${q}&sh=${l}`)).text(),
(m=l.match(/document\.location\.href\s*=\s*'([^']+)'/))&&m[1])window.location=`${n}/game/${m[1]}`;else{l.includes("5")&&("true"===localStorage.getItem("leaguecircuslowtohigh")?(localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","true")):"true"===localStorage.getItem("leaguecircusrandom")&&(localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusattackenable","false")),location.reload());
if(l.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leaguecircusattackenable","false"),location.reload()}async function k(){function h(A){const B=Date.now(),v=t.findIndex(D=>D.playerName===A);-1<v?t[v].timeout=B:t.push({playerName:A,timeout:B});localStorage.setItem("playerTimeouts",JSON.stringify(t))}function l(A,B){const v=Date.now();if(Array.isArray(t)){const D=t.find(F=>F.playerName===A);return!D||v-D.timeout>B}return!t[A]||v-t[A]>B}function n(A){for(var B=A.length-
1;0<B;B--){const v=Math.floor(Math.random()*(B+1));[A[B],A[v]]=[A[v],A[B]]}2<A.length&&(B=A.splice(0,2),A.push(...B));return A}async function m(A,B,v){try{const D=B.match(/\d+/)[0],F=B.match(/\w+/g)[2],I=(new URLSearchParams(B)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:v,aType:A,opponentId:I,serverId:D,country:F}));const K=await jQuery.get(R({mod:"arena",submod:"confirmDoCombat",aType:A,opponentId:I,serverId:D,country:F,a:(new Date).getTime(),sh:U("sh")})),M=
(new URLSearchParams(K)).get("reportId");M||window.location.reload();Cf(`mod=reports&submod=showCombatReport&t=${A}&reportId=${M}`)}catch(D){document.getElementById("content").querySelector("form > input").click(),Bf(1E3)}}"true"===localStorage.getItem("leaguecircusattackenable")&&await g();"true"===localStorage.getItem("scoreboardcircusenable")&&await b();var r=(new URL(window.location.href)).searchParams.get("sh")||"",u=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[];let x=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||
[];const q=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];let t=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const w="true"===localStorage.getItem("onlyCircus");localStorage.getItem("CircusSimulatorAmount");if(W("circus")&&0<u.length||W("circus")&&0<x.length||w)try{n(u);localStorage.setItem("autoAttackCircusList",JSON.stringify(u));n(x);localStorage.setItem("autoAttackCircusServerList",JSON.stringify(x));let A=0,B=2,v=0,D=0;for(w&&(B=10);A<B&&(v<u.length||D<x.length);){let F,
I,K;(K=v<u.length&&D<x.length?.5>Math.random():D<x.length)?(I=x[D],F=I.playerName,D++):(F=u[v],v++);if(!q.includes(F)&&(l(F,6E4*(10+Math.floor(36*Math.random())))||w)){let M;M=K?await e(I):await c(F,r);N("circusAttacks",0);if(M.includes("index.php?mod=reports")&&!M.includes("errorRow")){h(F);C(`${d.ya}`+F);window.location.reload();break}}A++}if(A===B){const F=JSON.parse(localStorage.getItem("Timers"));X("circus",F.CircusTurma||5)}}catch(A){window.location.reload()}if("mod=arena&submod=serverArena&aType=3"!=
lf)Cf("mod=arena&submod=serverArena&aType=3");else try{if(document.querySelector(".messages .message.fail"))localStorage.setItem("doCircus",!1),window.location.reload();else{let A=[...u,...x].map(D=>D.playerName);var y=Array.from(document.querySelectorAll("#own3 tr")).slice(1);const B="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),v="true"===localStorage.getItem("attackRandomly");r=null;u=Infinity;localStorage.getItem("Username");localStorage.getItem("enableCircusSimulator");
for(let D of y){const F=D.querySelector("a");y=2;v&&(y=Math.floor(5*Math.random())+2);const I=D.querySelector(`td:nth-child(${y})`);if(F&&I){const K=F.innerText,M=parseInt(I.textContent.trim(),10),Q=q.includes(K),Z=null!==F.querySelector("span[style*='color:green;']"),ba="green"===F.style.color;if(!(Q||!B&&Z&&ba)){if(A.includes(K)){C(`${d.ya}`+K);r=F;break}!r&&M<u&&(u=M,r=F)}}}if(r)await m(3,r.href,r.outerText),N("circusAttacks",0);else{const D=document.querySelector('form[name="filterForm"] input[type="submit"]');
D&&D.click()}}}catch{window.location.reload()}}1==yb.isUnderworld?(await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:U("sh")})),await k()):qh?await k():!qh&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&await k()}else if(pa&&!0===Da&&W("eventPoints")&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1))await async function(){var b=jQuery("#submenu2 a").filter(".glow")?jQuery("#submenu2 a").filter(".glow")[0].href.match(/mod=.*&sh/)[0].slice(0,
-3):null;if(lf!=b)Cf(b);else{b=document.querySelector("#content .ticker");let c=parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10),e=fc;localStorage.setItem("eventPoints_",c);if(b){b=document.querySelector('[data-ticker-type="countdown"]').textContent.trim().split(" ").pop();let [g,k,h]=b.split(":").map(Number);(b=(new Date).getTime()+1E3*(3600*g+60*k+h)+1)?localStorage.setItem("eventPoints.timeOut",b):X("eventPoints",5);setTimeout(Cf,1E3,"mod=overview")}else!b&&
0<c?(3==e&&1==c&&(e=2),setTimeout(yh,1E3,document.querySelectorAll(".expedition_button")[e])):!c&&"true"===localStorage.getItem("renewEvent")&&0<zh().$m?((new URL(window.location.href)).searchParams.get("loc"),setTimeout(yh,1E3,document.querySelectorAll(".expedition_button")[e])):0==c&&"false"===localStorage.getItem("renewEvent")?(X("eventPoints",5),location.reload()):0==c&&setTimeout(Cf,5E3,"mod=overview")}}();else if((yc||zc||Ac)&&!oh&&yc&&pa&&ph&&(rh&&Bc&&Ab&&Bb&&W("AuctionEmpty")||zc&&Ab&&Bb&&
W("AuctionEmpty")||Ac&&Ab&&Bb&&W("AuctionMEmpty")||th&&Bc&&uh&&vh&&W("AuctionMEmpty")))await za.start();else if(pa&&5<aa.level&&"true"==localStorage.getItem("storeGoldinAuction")&&Number(zh().gold)>Math.floor(Number(localStorage.getItem("storeGoldinAuctionmaxGold")))&&W("enableHideGold"))await lb.A.start();else if(pa&&"true"===localStorage.getItem("resetExpiredItems")&&0<xh.length&&5E3<=aa.gold&&W("resetExpired"))await ej(localStorage.getItem("resetDays"),xh);else if(pa&&("true"===localStorage.getItem("HealEnabled")?
aa.o>Number(localStorage.getItem("healPercentage")):1)&&Ah()&&"true"===localStorage.getItem("doKasa")&&W("gold")&&zh().gold>Math.floor(localStorage.getItem("KasaHoldGold")))await Lh();else if(pa&&"true"===localStorage.getItem("EnableSmelt")&&ha.Gm()&&1E3<aa.gold&&W("smelt"))W("smeltCheck")&&(ha.slots=await ha.u(),await ha.em(ha.slots),await ha.vm(ha.slots),"true"===localStorage.getItem("EnableSmelt")&&1E3<aa.gold&ha.Gm()&&W("smelt")&&await ha.start());else if(pa){if("true"==localStorage.getItem("useCostume")&&
W("CheckDolls"))await oj.start();else if("true"===localStorage.getItem("HealEnabled")&&"true"==localStorage.getItem("BuffsEnable")&&W("BuffCheck"))await hj();else if(!wh||Rb-wh>=6E4*wj)localStorage.setItem("MarketlastRan",Rb.toString()),"true"==localStorage.getItem("enableMarketSearch")&&da==ua&&"true"==sessionStorage.getItem("autoGoActive")&&await cf.wn();0<nh&&(C(`Waiting for ${xc} seconds...`),await new Promise(b=>setTimeout(b,nh)));Ye()}const z3 = localStorage.getItem("we");we = new Date(z3);fa<new Date&&we<new Date&&da!=ua&&eb()}})();const Ch={qj:"After expedition points are consumed, travel to Germania to consume Dungeon points",gk:"Use this if the bot gets stuck in the repair!",uk:"When HP is below, use heal",Bg:"Partial Repair",Le:"Full Repair",Ag:"Partial or Full Repair",ce:"Enable Limit",Wi:"Limit",Xi:"If you want to limit the number of times you want to attack to the enemy, enable this option and set the limit. Bot will continue to attack rest of the enemies after it finishes attacking to the selected monster.",Yd:"Do not enter underworld with underworld costume?",
Xd:"If you dont want to enter underworld while you have underworld costume on, enable this option",ji:"Underworld",bi:"Underworld Buffs",di:"Use god powers after entering the underworld?",ei:"Select gods to use powers from:",fi:"Use Weapon Buff on the weapon?",gi:"Use Armor Buff on the following equipment:",rk:"Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.",Fk:"Select Colors",Ra:"Vulcanus Forge",Va:"Feronia`s Earthen Shield",Wa:"Neptune`s Fluid Might",Xa:"Aelous` Aerial Freedom",
Ya:"Pluto`s Deadly Mist",Za:"Juno`s Breath of Life",$a:"Wrath Mountain`s Scale Armour",ab:"Eagle Eyes",bb:"Saturn`s Winter Garment",Sa:"Bubona` Bull Armour",Ta:"Mercerius` Robber`s Garments",Ua:"Ra` Light Robe",$f:"Packages",Uf:"Inventory",ca:"Min Price",ba:"How Many",xb:"Sell Items",wb:"Search in",Wf:"Material Color",Vf:"Item Color",cg:"Warehouse",yb:"Switch to Materials",bg:"Switch to Items",ag:"Sell Materials",tb:"Please enter a valid item name and price range and how many.",ub:"No suitable items found in the selected search locations.",
vb:"All items listed successfully!",zk:"All materials listed successfully!",Yf:"If you want to sell items for fixed price, you can enter the same value for both min and max price.",Zf:"This feature is still experimental, use with caution. If you dont put fixed price, it will list items randomly between min and max price you enter.",uj:"Repair Before Smelt",Ej:"Select the item types you want to smelt.",Fj:"Select the colors you want to smelt.",Gj:"Select the level of the items you want to smelt.",
Hj:"Select the hammer you want to use",Ij:"Note that Green and Red circle next to the first box are for enabling/disabling the rule.",Jj:"If you want to use smelt randomly any colors or types, you can enable `Smelt randomly if no conditions met? (Last enabled option in the tutorial video)",mk:"Sets the max gold that the bot will spend per cycle.",Ma:"Bot will start bidding on any food items, if enabled. You do not require to enable gladiator/mercenary toggles",wd:"Bot will not bid on allies` bids.",
xd:"Ignore Prefix/Suffix Combination when looking for an item in the auction.",ye:"Select Monster",me:"Use Hourglass/Ruby?",tk:"Use Ruby?",pe:"Use Mobilization?",oe:"Use Life Potion?",le:"Heal Percentage (%)",we:"Number of Attacks",ne:"Attack Interval (in seconds)",je:"Attacks Performed",ke:"Hourglass Left",ue:"Note: It uses lifepotions to heal, not food.",ve:"Note: If attacks stop prematurely, try 'Reset Attacks'.",ze:"Start",xe:"Reset",Ae:"Stop",Be:"Expedition Settings (Click to minimize)",qe:"Monster 1",
re:"Monster 2",se:"Monster 3",te:"Monster 4",Ck:"Repair Before Smelt",Ci:"This option will use cervisia when your premium expires.",ej:"This option will enables and picks oils from god rewards. It can use number 1 and number 3 oils on the character but number 2 will only be picked to packages.",Ai:"This option will use buffs at the time you set. It will find buffs in packages and apply it to the character.",Yi:"This option will enter you to the underworld when your expedition points are below 3. Dont forget to enable Auto Login from Extras tab, otherwise you might get logged out upon entering underworld[Game Bug]",
Sb:"Bot normally picks random 3 to 6 tries to attack arena list. If you enable this option, it will go through your list until it can attack someone. This might take some time.",rj:"This option is only for premium licenses. It simulates the attack before attacking a user for %75 win rate.",zd:"You do not need to enable main auction toggle to enable this option.",$j:"This option will refresh the page every second when auction is in -Very Short- state to bid constantly to win the auction.",Cj:"If none of the smelt conditions are met, it will smelt randomly. Make sure to select item type and color.",
Dj:"This option will only smelt items from inventory. It will ignore items in packages.",Na:"Auction Items",fg:"Mercenary Items",Mb:"Shop Items",li:"Unique Items",yj:"Set background to black [Increases performance]",zj:"Move GLDbot buttons to bottom left?",Di:"Attack Circus Without Heal",Yj:"Pick gold from packages if needed?",Zj:"Gold has been picked from packages for training",Cl:"No gold has been found in packages for training",gl:'GLDBot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.',
Vj:"Items Repaired",Oj:"Arena Attacks",Qj:"Circus Attacks",qd:"Items Reset",Tj:"Expedition Attacks",Sj:"Dungeon Attacks",Wj:"Underworld Attacks",Pj:"Money Earned from Arena",Rj:"Money Earned from Circus",Al:"Items Smelted",Uj:"Gold Cycled",Pi:"Guild Battle",Ri:"Guild Settings",Wk:"Will attack guilds randomly.",Oi:"Attack Random Guilds?",Qi:"Guild Name",Bi:"Reset Stats",Ec:"Wood",uc:"Copper",yc:"Iron",Ac:"Leather",Fc:"Wool",vc:"Cotton Wool",xc:"Hemp",wc:"Gauze Strip",Bc:"Linen Strip",zc:"Jute Patch",
Dc:"Velvet",Cc:"Silk Thread",Nc:"Fur",Hc:"Bone Splinter",Qc:"Scale",Kc:"Claw",Mc:"Fang",Lc:"Dragon Scale",Ic:"Bull`s Horn",Pc:"Poison Gland",Jc:"Cerberus` Pelt",Oc:"Hydra Scale",Rc:"Sphinx Feather",Sc:"Typhon Leather",pc:"Lapis Lazuli",jc:"Amethyst",ic:"Amber",kc:"Aquamarine",qc:"Sapphire",nc:"Garnet",mc:"Emerald",lc:"Diamond",oc:"Jasper",rc:"Sugilite",cc:"Scorpion Poison",fc:"Tincture of Stamina",Zb:"Antidote",Yb:"Adrenaline",ec:"Tincture of Enlightenment",bc:"Potion of Perception",$b:"Essence of Reaction",
ac:"Phial of Charisma",hc:"Waters of Oblivion",dc:"Soul Essence",od:"Water Seal",hd:"Protection Rune",fd:"Earth Mark",nd:"Totem of Healing",md:"Talisman of Power",kd:"Stone of Fortune",gd:"Flintstone",ld:"Storm Rune",jd:"Shadow Rune",Wc:"Crystal",Vc:"Bronze",$c:"Obsidian",cd:"Silver",dd:"Sulphur",Yc:"Gold Ore",bd:"Quartz",ad:"Platinum",Uc:"Almandin",Xc:"Cuprit",Zc:"Hellstone",xi:"Attack Randomly in Provinciarum?",yi:'Also disable "Sort players in arena by level" setting in crazy-addon.',Ng:"Only accept quests based on god type.",
Oa:"Auto Buff",Nd:"Use it in hell only?",ug:"New Rule",sg:"Name Contains",isUnderworldItem:"Is Underworld Item",Ue:"Ignore Materials",fk:"Use Pray?",ii:"When in underworld only accept underworld related quests?",hi:"If enabled, you need to enter underworld item names. If the bot finds these items in the underworld, it will accept the quest.",Jk:"Underworld Quest Item",Tk:"Enter Material Name",qk:"The bot loves dice! They help find clothes in chests. But if there are no dice, the bot opens chests anyway, hoping for some cool clothes (but it might not find any!).",
Bj:"Send smelted materials to package?",be:"Enable Arena",Fg:"Prioritize arena list?",Gg:"Prioritize circus list?",Ud:"Disable Log Menu",ah:"Reward Min. Gold Value",Og:"Focus Quest, if enabled, will follow the shortest path to finish the dungeon.",zh:"Throw Dice Automatically?",Ah:"Use throw dice cautiously, it will keep using the first dice until you disable the option.",gh:"Search Progress",Vg:"Cooldown for repair by default is 10 minutes.",pg:"Minimum Condition",Sd:"Current item on workbench [Clear if bot pauses unexpectedly]",
rf:"Forge Resources stored to horreum successfully.",lf:"Checking marketplace for items...",qb:"Item moved to workbench.",Gf:"Item successfully repaired and equipped.",Hf:"Item successfully repaired.",xk:"Repair failed. Page will be refreshed.",Df:"Picking up materials...",Qf:"Waiting for repair...",Ff:"Repair has started for .",rb:"Repair: Moving the item from inventory to bag",Ef:"Repair: Moving the item from workbench to package.",nf:"Could not find enough materials. Disabling the repair slot for 5 minutes ",
Af:"Looking for items to buy to hide gold in Auction...",hf:"Checking for expired items in packages...",jf:"Item successfully reset.",kf:"No Empty Space or Gold to Reset.",sf:"Make sure you have sell rights in guild market!",tf:"Not enough gold/or no item to buy. Waiting for 30sec to refresh.",mb:"Store has been refreshed.",nb:"Error while healing.",wf:"No Ruby or Cloth, disabling the options.",xf:"No healing item found in packages.",ob:"No suitable items found",yf:"Foods have been picked. Ending the process.",
zf:"At least one food has been picked. Ending process.",pb:"No suitable space found in bag to pick food.",uf:"Getting food from packages.",vf:"No suitable space found in bag to pick food.",lb:"No more heal items. Waiting for 30 seconds.",kb:"HP Recovered.",za:"Nothing to do so I am going to pray!",Mf:"Im going to refresh in 60 seconds to check for my health and villa medici.",Nf:"Waiting for Villa Medici, refreshing in 60 seconds.",Of:"Left underworld.",Pf:"Im going to refresh in 60 seconds to check for my health.",
Bf:"Checking for god oils...",Cf:"God oils have been picked.",xa:"Successfully attacked player in ARENA: ",ya:"Successfully attacked player in CIRCUS: ",ff:"Checking auction! Please wait...",gf:"Bidding to items. Please wait...",If:"Auto Smelted Item: ",Jf:"Smelting Item: ",Kf:"Not enough gold to smelt. Required Gold: ",Lf:"SMELT: Looking for items to smelt...",yk:"Looking for items to smelt...",mf:"Checking costume availability...",qf:"Donated : ",pf:"Throwing dice...",He:"Underworld Farm [Manual, Beta]",
Ie:"Be aware: Turn on this feature after unlocking the creature you want to attack, it will not automatically attack to unlock the monster.",Ge:"Farm Location",Fe:"Farm Enemy",Gd:"Auto Login",Hd:"You need to allow pop-ups from the lobby screen for GameForge. See documentation on how to do it.",Cg:"Pause Bot",Dg:"Pause Bot in (Minutes)",De:"Expiration Date",xg:"Only buy food?",yg:"If you enable this, it will ignore your selections and buy food automatically without entering anything.",Ab:"Max total gold to spend",
zb:"Max gold per food to spend",wg:"Bot will check oils every 60 minutes",Sh:"Sets a timer to check smelting times.",Ph:"Sets a timer to check smelting after you dont have gold.",Rh:"Sets a timer to check smelting if you dont have available item.",Kh:"Sets a timer for repair to check your items.",Jh:"Sets a timer to check guild market hold gold.",Fh:"Sets a timer for auction hold gold option.",Bh:"Sets a timer to check the arena pvp list to attack.",Gh:"Sets a timer to check the circus pvp list to attack.",
Yh:"Sets a timer for training to train your stats.",Mh:"Sets a timer to reset expired items.",Wh:"Sets a timer to store forge materials to horreum.",Dh:"Sets a timer to check gladiatos & mercenary auction.",Oh:"Sets a timer to search for items in auction&shop.",Hh:"Sets the timer of sending donation to the guild.",Me:"Gold Moved",Zd:"Don't sell smelt & auction list items",hh:"Shop Automation",jh:"Item Search Settings",ih:"Use this tool to search for items in shops. Simply add the items to the list, specify the cloth amount, and start the search.",
kh:"Cloths to use:",lh:"How many cloths to use?",ia:"Enter Full Item Name",Lb:"Enter Item Level",nh:"Item Quality",mh:"Item Name Here",oh:"Start Searching",ph:"Skip and Continue",qh:"Stop Searching",Je:"Buy cheapest or expensive?",rg:"Most Expensive",Pd:"Cheapest",fa:"Select an option",de:"Highlight Underworld Items",Ke:"Focus on the quest?",El:"Use ruby if there isnt cloth?",Pa:"Add cross-server players: Find profile, use A & C buttons. Play nice: Avoid targeting same players to dodge reports/bans.",
tl:"Smelt Green?",Ig:"Do not accept random quests if entered any filters?",Gc:"Max Material Quality to use",Li:"Enable Mercenary Search",bl:"Click \u2018Sell All Selected\u2019 to sell all items. Make sure to have 2x3 empty space in your first (1) bag and select quality. To mass collect Gold, use `USE GOLD` panel below or filter gold and use the `Pick Selected or Pick All`",Nj:"\ud83d\udd25 : Adds item to smelting list.",zi:"\ud83d\udd28 : Adds item to auction list.",tj:"Refresh shop automatically with cloth when its full.",
hj:"Page:",oj:"Stop",mj:"Sell This Page",jj:"Pick Selected",ij:"Pick All",pj:"Auto Package Settings",nj:"Send Resources",kj:"Sell All Selected",qa:"Item Type",U:"Weapons",M:"Shields",I:"Armour",L:"Helmets",K:"Gloves",J:"Boots",T:"Rings",R:"Amulets",oa:"Usables (Foods)",va:"Upgrades",fj:"Boosts",sa:"Recipes",ra:"Mercenary",ua:"Forging Tools",ta:"Scrolls",Ga:"Reinforcements",Fa:"Event Items",ed:"Forging Goods",gj:"Gold",P:"All",jl:"Quality",wa:"White",C:"Green",B:"Blue",D:"Purple",G:"Orange",S:"Red",
lj:"Sell All Options",Aj:"Ignore Prefix/Suffix Combination?",Si:"How many food to buy/pick?",Gi:"Normal",Fi:"Middle",Ei:"Hard",Da:"Standard",ml:"Repair Stuck Fix",vk:"Underworld mode will automatically disable Dungeon/Arena/Circus, and enable all of them after underworld. Disable Enter Underworld if you want to disable Dungeon/Circus/Arena. If you entered underworld manually, you need to enable underworld Mode.",ai:"Set how many times you want to train the stats and their priorities. The bot wont train unless you set a priority. If there is no more stat left but priority is set, it will continue with checked stat.",
Qk:"Quest",rl:"Smelt",xl:"Smelt Settings",Kj:"Smelted Items",yl:"Add Prefix or Suffix, once it finds it in the packages it will smelt automatically. If you only want to look for all the items listed without checking their combination, enable Ignore combination option.",wl:"Smelting Item:",Vb:"Click on the item you want to repair and choose the highest quality materials to use. You need to have at least 10,000 gold for the repair to start. Ensure you have a 3x3 space available in your first inventory bag and make sure a food item or any small item is not in the first inventory space otherwise, it might get stuck!. The bot will start the repair once the item has the condition you have chosen. Repair now should be able to continue from where it was left off. Items that have a Hint tooltip might cause a problem.",
Kk:"Apply only to Mercenary",Nk:"Auction will only bid when market is close to the end.",Mk:"Smelting will prioritize starting from the first item to search. You can drag and drop to change priority. Smelt will start when you have over 7k gold. ",Vi:"Heal & Buffs",nl:"Not enough gold to smelt. Required Gold:",ql:"Skipping bid: Guild member has already bid for item ",pl:"Skipping bid: Already bid for item ",advanced:"Advanced",arena:"Arena",ma:"Auto Attack",Tb:"Avoid Attack",ka:"Add Player",la:"Add Player Name (Same Server)",
Yk:"Stop Bot if run out of food?",circusTurma:"Circus Turma",Hi:"Difficulty",dungeon:"Dungeon",Ii:"Dungeon Settings",eventExpedition:"Event Expedition",expedition:"Expedition",Mi:"Expedition Settings",vj:"Select Monster",$k:"Highest",Zk:"Put your heal stuff in first page of your inventory",tc:"In",xh:"Store Gold in Guild Market",yh:"Store Gold in Auction",eh:"Use Clothes to renew Shop?",Ek:"Select Items to Reset",Xg:"Reset Expired Items",Gb:"Note: By enabling this option, the bot will sell upcoming expired items from Packages to Guild Market then cancels to reset expiration time. Guild is required. Make sure you have empty 3x3 space in your bags. It checks last 7 pages per cycle. This might slow down the bot while it is checking for the pages to reset. If it doesnt work, set display expiry date as Date in game settings.",
Eg:"Pause bot randomly to work as [Testing Phase]:",aa:"Hold Gold: Bot will keep this gold in the bag:",dg:"Max Gold: Bot will spend when the gold is greater than",bh:"Bot will bid on random items.",rd:"Add Random Delay",sd:"You can add a delay to bot here.",Fb:"Repair",sl:"Smelt Blue?",vl:"Smelt Purple?",ul:"Smelt Orange?",Lj:"Smelt Everything Only From Inventory?",Mj:"`Smelt Tab` works only for `Smelt Everything Only From Inventory` option. Rest of the options will use selected smelt tab. This will ignore color and ignore list items. Tab 1 is reserved for repair.",
th:"Smelt",Ad:"Auto Search",tg:"Auto Auction",Bd:"Excess use of Auction might result in ban. If you enabled auction on Crazy-Addon please disable before using this. Note that, if you put only one item to PREFIX section, bot will try to filter by the items name for faster bidding. Although you need to disable bidding food for this.",dh:"Search in Gladiators Auction",fh:"Search in Mercenary Auction",Jd:"Bid Food?",eg:"Maximum Bid",Kd:"Bid if the status is less than",Ld:"Bidded Items",kk:"Auction Language",
lk:"Please set the language according to your ingame language, otherwise auction wont work.",vd:"You can add items to look for items in market and auction. It will also show purple items in the market once you add an item into the list.",ik:"Use auction with caution!",jk:"Auto bid makes too many requests to the server causing white page error and can cause a ban if you use it often!!",Ug:"Renew Event Points with Ruby?",fe:"Enable Auto Oil",nk:"Auto Get Holy Oils",Ak:"Quest Check Speed",La:"Attack Guild Members?",
Ja:'Auto add people to the "Attack" list when X GOLD is stolen:',Ka:'Automatically add people to the "Avoid Attack" list when you lose to them:',Jb:"Scoreboard Attacks",Qb:"Very Long",sb:"Long",Bb:"Middle",Nb:"Short",Rb:"Very Short",ge:"Enter Underworld if HP >",Pg:"Quest Check Speed",Hg:'Default is "3x". If bot causes problems with quests, change quest speed according to your server speed.',Ne:"Heal Pick Bag",he:'If you are renewing points manually, you need to click the button above "Refresh Event Expedition if stuck!',
sk:"You must enable at least one of the following: expedition, dungeon, arena, or circus to start the Event Expedition.",Rg:"Refresh Event Expedition if stuck!",cb:"Dont bid on Allies` Bids?",Gk:"Leave all settings disabled if you wish to smelt using packages that contain the items in the list. However, you still need to choose colors.",pk:"Character(Off) / Mercenary(On)",Dk:"Repair Both?",Hk:"Timers",Timers:"Enter the number of minutes for each timer below or leave it default. Be aware! If you enter very low numbers, bot might get stuck in loop!",
Mg:"Quest Filter Ignore",Lg:"Enter keywords to filter out quests you do not want to take",X:"Enter Keyword",H:"Add",Tg:"Remove",Rd:"Clear",Jg:"Quest Filter Accept",Kg:"Enter keywords to choose which quests to take. You can also use this to accept quests by their reward using keyword. Using this will ignore Quest Types",Ba:"Skip Time Quests?",Bk:"Quests",Dd:"Auto Costume",oi:"Use Costume?",Id:"Basic Battle",$d:"Dungeon Battle & Event",Qd:"Choose underworld costume",vi:"Wear Underworld costume when available?",
Ed:'To ensure the bot doesnt override your Underworld costume, make sure to select "Wear Underworld costume when available?" and "Choose Underworld costume." The bot will only switch to Dis Pater Normal and Medium costumes if your expedition or dungeon points are at 0.',Pe:"Underworld Heal Settings",ud:"Attack Boss When Available?",jb:"League attack will disable itself after 5 unsuccessful attack.",Se:"Holy Oils",og:"Item Name",da:"Min. Item Level",Aa:"Min. Item Quality",td:"Apply/Reset Timer",Ve:"Ignore Prefix/Suffix Combination",
wi:"Yes",vg:"No",Ha:"Add Prefix",Ia:"Add Suffix",Qa:"Clear History",uh:"Ignore List",Cb:"Prefix",Ob:"Suffix",Zg:"Reset Expiring Items",vh:"Smelt randomly if no conditions met?",wh:"Smelt Tab",hb:"Extras",yd:"Auction",Xf:"Market",Pb:"Timers",Uh:"Smelting",Th:"Smelting if not enough gold",Qh:"Smelt if no item",Ca:"Repair",Ih:"Guild Market Hold Gold",Eh:"Auction Hold Gold",Xh:"Training",Lh:"Reset Expired",Vh:"Store Forge",Ch:"Auction Check",Nh:"Search",v:"Enable",qg:"Minimum Gold",Kb:"Select Hour",eb:"Donate Gold to Guild",
Vd:"Donates every 5 minutes. You can change the interval from timers tab",Te:"How much to donate?",Wd:"Donate when you have more than >",ef:"Less than <",Wg:"Reset Expired and Other settings",Yg:"Reset in:",wk:"Hold Ctrl (Cmd on Mac) to select multiple items",We:"Import/Export Settings",Ee:"Export Settings",Xe:"Import Settings",hg:"Message All Players",ig:"[Requires Ultra Premium Key, message on Discord to get the key.]",jg:"Enter message to send",Td:"For custom scripts contact us on Discord",lg:"Send",
mg:"Show Players",kg:"SelectAll",ng:"UnselectAll",df:"Make sure your inventory has enough space. Cooldown is 2 minutes.",gb:"Enable Scoreboard Attack:",Hb:"Select Range to Attack",Ib:"Bot will randomly attack from the scoreboard list.",ib:"League Attack",fb:"Enable League Attack:",Db:"Randomly Attack",Eb:"Attack lowest to highest",hk:"Bot will avoid attacking guild members by default.",Ce:"Expedition Location:",Cd:"Auto Collect Bonuses:",rh:"Skip Boss",ae:"Dungeon Location:",$g:"Reset if lose?",Qe:"Underworld Settings",
Re:"Underworld: Runs from start to finish! Set your heal % in the Heal tab (activate it first). Underworld Mode uses Underworld Heal %, so expect more food consumption. Enable Auto-login in Extras if logout occurs.",Oe:"Underworld Difficulty:",Fd:"Auto Enter Underworld / Underworld Mode:",pi:"Use Mobilization if points = 0",ui:"Use rubies?",si:"Use Sacrifice to heal?",bk:"Use Cloth to enter underworld?",ie:"Exit underworld if no points?",ci:"The bot will try to use Villa Medici first and disable itself if there is no available Villa Medici; if thats the case, it will use a healing potion. Dont forget to enable Heal toggle.",
ki:"Auto enter Underworld will disable dungeon/arena/circus upon entering underworld.",Ik:"Underworld Heal Settings",ti:"Use Villa Medici?",ri:"Use Healing Potion?",Rf:"INFO: The bot will search for market items every selected minutes, which may pause attacking during the search.",ee:"Enable Market Search:",Sf:"Market Search Interval in Minutes:",Tf:"Suggested 10 minutes.",$e:"Item Settings:",Ye:"Item Name Includes",N:"Max Price",af:"Item Type",Ze:"Item Rarity",Od:"Buy Soulbound?",cf:"Items to Buy",
bf:"Buy packs if any of them match the maximum price entered?",Md:"Bought Items:",Ti:"Heal Percentage",dk:"Buy Food from Shop?",ek:"Use Heal from Package?",ak:"Use Cervisia? (packages included)",ck:"Use Eggs? (packages included)",cl:"Last Used",location:"Location",Strength:"Strength",Dexterity:"Dexterity",Agility:"Agility",Constitution:"Constitution",Charisma:"Charisma",Intelligence:"Intelligence",Zh:"Train Settings",$h:"Select the attributes you want to train. It will train once you have enough gold.",
Tc:"Next action",cj:"No",dj:"Normal",hl:"Opponent",il:"Opponent Level",sj:"Quests",random:"Random",ol:"Settings",zl:"Soon...",type:"Click on icons to activate quest types. Select first 3 if you want to focus on Circus & Arena",Gl:"Yes",A:"Search",pd:"Add item",Xj:"Store Forge Resources automatically",Bl:"Submit",al:"Interval : ",Rk:"Enable Auto Bid",Sk:"Cover Allies` Bids",Dl:"Tutorial",Ub:"More users will slow down the bot.",Lk:"Begin by adding an items full name to the list. Once added, the tool will display search results on the left. This also aids in auto-auction searches. With auto-bid enabled, the tool will periodically search based on your set interval. If the item is found and you have sufficient funds, it will bid automatically. Note: To search for unique items in shops, you must add at least one item to the search list..",
Uk:"The creature number can be selected from the buttons above. Number 1 represents the leftmost creature. Make sure you select the correct location otherwise bot might pause.",Ji:"Choose the difficulty of the dungeon from the options above. Ensure you select the correct location, as otherwise, the bot might pause.",Ui:"Heal Settings",Ki:"Store excess gold in Guild by buying guild market items. -> Min. Gold. Leave some empty space in first inventory.",dl:"Move All",el:"Move Selected",Ok:"Auto Heal",
Pk:"Auto Heal Percentage",Fl:"Ruby",zg:"General Settings",wj:"Sell All",xj:"Sell Selected",ja:"Weapons",ga:"Shields",W:"Chest Armour",Z:"Helmets",Y:"Gloves",ha:"Shoes",ea:"Rings",V:"Amulets",ni:"Usable",mi:"Upgrades",Qg:"Recipes",gg:"Mercenary Scroll",Sg:"Reinforcements"},Fh={qj:"Expedition Sonras\u0131 Eylem",gk:"Tamir takilirsa TIKLA",uk:"Kaca dustugunde iyilestirsin?",Bg:"K\u0131smi Onar\u0131m",Le:"Tam Onar\u0131m",Ag:"K\u0131smi veya Tam Onar\u0131m",ce:"Limiti Etkinle\u015ftir",Wi:"Limit",Xi:"D\u00fc\u015fmana sald\u0131rmak istedi\u011finiz kez say\u0131s\u0131n\u0131 s\u0131n\u0131rlamak istiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin ve limiti ayarlay\u0131n. Bot, se\u00e7ilen canavara sald\u0131rmay\u0131 bitirdikten sonra di\u011fer d\u00fc\u015fmanlara sald\u0131rmaya devam edecek.",
Yd:"Yeralt\u0131 kost\u00fcm\u00fc ile yeralt\u0131na girmeyin",Xd:"Yeralt\u0131 kost\u00fcm\u00fc varken yeralt\u0131na girmek istemiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin",ji:"Yeralt\u0131 D\u00fcnyas\u0131",bi:"Yeralt\u0131 D\u00fcnyas\u0131 G\u00fc\u00e7lendirmeleri",di:"Yeralt\u0131 d\u00fcnyas\u0131na girdikten sonra tanr\u0131 g\u00fc\u00e7lerini kullan?",ei:"G\u00fc\u00e7lerini kullanmak istedi\u011fin tanr\u0131lar\u0131 se\u00e7:",fi:"Silaha Silah G\u00fc\u00e7lendirmesi kullan?",
gi:"A\u015fa\u011f\u0131daki ekipmana Z\u0131rh G\u00fc\u00e7lendirmesi kullan:",rk:"Bekleme s\u00fcresi 30 dakikad\u0131r. \u00dczerinde kost\u00fcm yoksa, bot bekleme s\u00fcresini s\u0131f\u0131rlar.",Fk:"Renkleri Se\u00e7",Ra:"Vulcano`nun Demirci Atesi",Va:"Feronia`nin Toprak Kalkani",Wa:"Neptune`un sivi gucu",Xa:"Aelous`un havali ozgurlugu",Ya:"Pluto`nun olumcul nefesi",Za:"Juno`nun Hayat Solugu",$a:"Ofkeli Dag Ejderhasi Pul Zirhi",ab:"Kartal Bakisi",bb:"Saturn`un kisi giysisi",Sa:"Bubona`nin okuz zirhi",
Ta:"Mercerius`un Hirsiz Kaftani",Ua:"Ra`nin isikli esvabi",$f:"Paketler",Uf:"Envanter",ca:"Min. Fiyat",ba:"Ka\u00e7 Tane",xb:"E\u015fya Sat",wb:"\u015eurada Ara",Wf:"Malzeme Rengi",Vf:"E\u015fya Rengi",cg:"Depo",yb:"Malzemelere Ge\u00e7",bg:"E\u015fyalara Ge\u00e7",ag:"Malzeme Sat",tb:"L\u00fctfen ge\u00e7erli bir e\u015fya ad\u0131, fiyat aral\u0131\u011f\u0131 ve miktar girin.",ub:"Se\u00e7ilen arama konumlar\u0131nda uygun e\u015fya bulunamad\u0131.",vb:"T\u00fcm e\u015fyalar ba\u015far\u0131yla listelendi!",
zk:"T\u00fcm malzemeler ba\u015far\u0131yla listelendi!",Yf:"Sabit fiyata e\u015fya satmak istiyorsan\u0131z, min ve maks fiyat i\u00e7in ayn\u0131 de\u011feri girebilirsiniz.",Zf:"Bu \u00f6zellik hala deneyseldir, dikkatli kullan\u0131n. Sabit fiyat koymazsan\u0131z, girdi\u011finiz minimum ve maksimum fiyat aras\u0131nda rastgele \u00f6\u011feler listeleyecektir.",Ej:"Eritmek istedi\u011finiz e\u015fya t\u00fcrlerini se\u00e7in.",Fj:"Eritmek istedi\u011finiz renkleri se\u00e7in.",Gj:"Eritmek istedi\u011finiz e\u015fyalar\u0131n seviyesini se\u00e7in.",
Hj:"Kullanmak istedi\u011finiz \u00e7ekici se\u00e7in.",Ij:"\u0130lk kutunun yan\u0131ndaki Ye\u015fil ve K\u0131rm\u0131z\u0131 \u00e7emberin kural\u0131 etkinle\u015ftirme/devre d\u0131\u015f\u0131 b\u0131rakma i\u00e7in oldu\u011funa dikkat edin.",Jj:"E\u011fer rastgele herhangi bir renk veya t\u00fcr\u00fc ergitmek istiyorsan\u0131z, Ko\u015fullar sa\u011flanmazsa rastgele eritilsin mi? (E\u011fitim videosundaki son etkinle\u015ftirilen se\u00e7enek) se\u00e7ene\u011fini etkinle\u015ftirebilirsiniz.",
mk:"Bot`un her d\u00f6ng\u00fcde harcayaca\u011f\u0131 maksimum alt\u0131n\u0131 belirler.",Ma:"Etkinle\u015ftirilirse, bot herhangi bir yiyecek \u00f6\u011fesi i\u00e7in teklif vermeye ba\u015flar. Gladyat\u00f6r/asker ayar\u0131n\u0131 etkinle\u015ftirmeniz gerekmez.",wd:"Bot, m\u00fcttefiklerin tekliflerine teklif vermez.",xd:"A\u00e7\u0131k art\u0131rmada bir \u00f6\u011fe ararken \u00d6nek/Son ek kombinasyonunu g\u00f6rmezden gelir.",uj:"Eritmeden \u00f6nce tamir et?",ye:"Canavar Se\u00e7",me:"Kum Saati/Rub kullan?",
tk:"Rub kullan?",pe:"Mobilizasyon Kullan?",oe:"Ya\u015fam \u0130ksiri Kullan?",le:"\u0130yile\u015ftirme Y\u00fczdesi (%)",we:"Sald\u0131r\u0131 Say\u0131s\u0131",ne:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131 (saniye cinsinden)",je:"Yap\u0131lan Sald\u0131r\u0131lar",ke:"Kalan Kum Saati",ue:"Not: \u0130yile\u015ftirmek i\u00e7in yiyecek de\u011fil, ya\u015fam iksiri kullan\u0131r.",ve:"Not: Sald\u0131r\u0131lar erken durursa, 'Sald\u0131r\u0131lar\u0131 S\u0131f\u0131rla' deneyin.",ze:"Ba\u015flat",
xe:"S\u0131f\u0131rla",Ae:"Durdur",Be:"Ke\u015fif Ayarlar\u0131 (K\u00fc\u00e7\u00fcltmek i\u00e7in t\u0131klay\u0131n)",qe:"Canavar 1",re:"Canavar 2",se:"Canavar 3",te:"Canavar 4",Ck:"Eritmeden \u00f6nce tamir et?",Ci:"Bu se\u00e7enek, premium \u00fcyeli\u011finiz sona erdi\u011finde cervisia kullanacak.",ej:"Bu se\u00e7enek, tanr\u0131 \u00f6d\u00fcllerinden ya\u011flar\u0131 etkinle\u015ftirir ve se\u00e7er. Karakter \u00fczerinde 1 numara ve 3 numara ya\u011flar\u0131 kullanabilir ancak 2 numara sadece paketlere al\u0131n\u0131r.",
Ai:"Bu se\u00e7enek, belirledi\u011finiz zamanda buff kullan\u0131r. Paketlerdeki bufflar\u0131 bulur ve karaktere uygular.",Yi:"Bu se\u00e7enek sizi kesif seferleriniz 2 ve altina geldiginde yeralt\u0131 d\u00fcnyas\u0131na sokar. Ekstralar sekmesinden Otomatik Giri\u015fi etkinle\u015ftirmeyi unutmay\u0131n, yoksa yeralt\u0131na girerken \u00e7\u0131k\u0131\u015f yapabilirsiniz [Oyun Hatas\u0131]",Sb:"Bot normalde rastgele 3 ila 6 deneme ile arena listesine sald\u0131r\u0131r. Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, sald\u0131rabilece\u011fi birini bulana kadar listenizde ilerler. Bu biraz zaman alabilir.",
rj:"Bu se\u00e7enek sadece premium lisanslar i\u00e7indir. Kullan\u0131c\u0131ya sald\u0131rmadan \u00f6nce %75 kazanma oran\u0131 ile sald\u0131r\u0131y\u0131 sim\u00fcle eder.",zd:"Bu se\u00e7ene\u011fi etkinle\u015ftirmek i\u00e7in ana m\u00fczayede ge\u00e7i\u015fini etkinle\u015ftirmenize gerek yoktur.",$j:"Bu se\u00e7enek, m\u00fczayede -\u00c7ok K\u0131sa- durumundayken sayfay\u0131 her saniye yeniler ve s\u00fcrekli teklif vererek m\u00fczayede kazanmay\u0131 ama\u00e7lar.",Cj:"E\u011fer eritme ko\u015fullar\u0131ndan hi\u00e7biri kar\u015f\u0131lanmazsa rastgele eritir. L\u00fctfen e\u015fya tipini ve rengini se\u00e7in.",
Dj:"Bu se\u00e7enek sadece envanterdeki e\u015fyalar\u0131 eritir. Paketlerdeki e\u015fyalar\u0131 g\u00f6rmezden gelecektir.",yj:"Arkaplan\u0131 Siyah yap",zj:"Bot butonlarini sol alta koy?",Di:"Iyilestirme olmadan Sirke Sald\u0131r?",Yj:"Gerekirse paketlerden alt\u0131n al\u0131ns\u0131n?",Zj:"E\u011fitim i\u00e7in paketlerden alt\u0131n al\u0131nd\u0131",Cl:"E\u011fitim i\u00e7in paketlerde alt\u0131n bulunamad\u0131",gl:'GLDBot: Gizem kutusunu yenilemek ve de\u011ferli e\u015fyalar\u0131 (Vb. Kost\u00fcmler) a\u00e7madan \u00f6nce bulmak i\u00e7in zarlar\u0131 kullan. Sand\u0131klar\u0131 a\u00e7mak i\u00e7in "Ba\u015flat"a t\u0131kla.',
Na:"Muzayede Esyalari",fg:"Mersaneri Esyalari",Mb:"Dukkan Esyalari",li:"Degerli Dukkan Esyalari",Vj:"E\u015fyalar Tamir Edildi",Oj:"Arena Sald\u0131r\u0131lar\u0131",Qj:"Sirk Sald\u0131r\u0131lar\u0131",qd:"E\u015fyalar S\u0131f\u0131rland\u0131",Tj:"Sefer Sald\u0131r\u0131lar\u0131",Sj:"Zindan Sald\u0131r\u0131lar\u0131",Wj:"Yeralt\u0131 Sald\u0131r\u0131lar\u0131",Pj:"Arenadan Kazan\u0131lan Para",Rj:"Sirkten Kazan\u0131lan Para",Al:"E\u015fyalar Eritildi",Uj:"D\u00f6n\u00fc\u015ft\u00fcr\u00fclen Alt\u0131n",
Pi:"Lonca Sava\u015f\u0131",Ri:"Lonca Ayarlar\u0131",Wk:"Loncalara rastgele sald\u0131racak.",Qi:"Lonca Ismi",Oi:"Rastgele Sald\u0131r",Bi:"\u0130statistikleri S\u0131f\u0131rla",Ec:"Ah\u015fap",uc:"Bak\u0131r",yc:"Demir",Ac:"Deri",Fc:"Y\u00fcn \u0130plik",vc:"Y\u00fcn Yuma\u011f\u0131",xc:"Kenevir",wc:"Gaze \u015eeridi",Bc:"Keten Par\u00e7as\u0131",zc:"J\u00fct Dikimi",Dc:"Kadife \u015eerit",Cc:"\u0130pek \u0130plik",Nc:"Post Par\u00e7as\u0131",Hc:"Kemik Par\u00e7as\u0131",Qc:"Kepek",Kc:"Pen\u00e7e",
Mc:"K\u00f6pek Di\u015fi",Lc:"Ejderha Kepe\u011fi",Ic:"Bo\u011fa Boynuzu",Pc:"Zehir Bezesi",Jc:"Cerberus`un post par\u00e7as\u0131",Oc:"Hidra pulu",Rc:"Sfenks t\u00fcy\u00fc",Sc:"Tifon derisi",pc:"Lacivert Tasi",jc:"Ametist",ic:"Kehribar",kc:"Akuamarin",qc:"Safir",nc:"Grena Ta\u015f\u0131",mc:"Z\u00fcmr\u00fct",lc:"Elmas",oc:"Jaspis",rc:"Sugilith",cc:"Akrep Zehri",fc:"Dayan\u0131kl\u0131l\u0131k Tent\u00fcr\u00fc",Zb:"Antidot",Yb:"Adrenalin",ec:"Ayd\u0131nl\u0131k Tent\u00fcr\u00fc",bc:"Alg\u0131 Tent\u00fcr\u00fc",
$b:"Refleks Esans\u0131",ac:"Karizma Flakonu",hc:"Unutman\u0131n Suyu",dc:"Ruh esans\u0131",od:"Su M\u00fchr\u00fc",hd:"Koruyucu Runik",fd:"D\u00fcnya Grav\u00fcr\u00fc",nd:"\u015eifa Totemi",md:"G\u00fc\u00e7 T\u0131ls\u0131m\u0131",kd:"\u015eans Ta\u015f\u0131",gd:"Ate\u015f Ta\u015f\u0131",ld:"F\u0131rt\u0131na Runi\u011fi",jd:"G\u00f6lge runi\u011fi",Wc:"Kristal",Vc:"Bronz",$c:"Obsidyen",cd:"G\u00fcm\u00fc\u015f",dd:"K\u00fck\u00fcrt",Yc:"Alt\u0131n Madeni",bd:"Kuvars",ad:"Platin",Uc:"Almandin",
Xc:"Cuprit",Zc:"Cehennem ta\u015f\u0131",xi:"Provinciarum'da Rastgele Sald\u0131r?",yi:'Crazy-addon\'da "Arena oyuncular\u0131n\u0131 seviyeye g\u00f6re s\u0131rala" se\u00e7ene\u011fini de devre d\u0131\u015f\u0131 b\u0131rak\u0131n.',Ng:"Sadece tanr\u0131 t\u00fcr\u00fcne g\u00f6re g\u00f6rev kabul et.",Oa:"Oto Buff",Nd:"Sadece cehennemde kullan?",ug:"Yeni Kural",sg:"\u0130sim \u0130\u00e7erir",isUnderworldItem:"Yeralt\u0131 item mi?",Ue:"Malzemeleri Yoksay",fk:"Dua Kullan?",si:"\u015eifalanmak i\u00e7in Kurban Kullan?",
bk:"Yeralt\u0131na girmek i\u00e7in kuma\u015f kullan?",ii:"Yeralt\u0131nda sadece yeralt\u0131 ile ilgili g\u00f6revleri kabul et?",hi:"Etkinle\u015ftirilirse, yeralt\u0131 item adlar\u0131n\u0131 girmeniz gerekir. Bot, bu itemlari yeralt\u0131nda bulursa g\u00f6revi kabul eder.",Jk:"Yeralt\u0131 G\u00f6rev Itemi",Tk:"Malzeme Ad\u0131n\u0131 Girin",qk:"Bot zarlar\u0131 sever! Zarlar, sand\u0131klarda k\u0131yafet bulmaya yard\u0131mc\u0131 olur. Ancak zar yoksa, bot yine de sand\u0131klar\u0131 a\u00e7ar ve k\u0131yafetler bulmay\u0131 umar (ama bulamayabilir!).",
Bj:"Ertilen malzemeleri pakete g\u00f6nder?",be:"Arena'y\u0131 Etkinle\u015ftir",Fg:"Arena listesini \u00f6nceliklendir?",Gg:"Sirk listesini \u00f6nceliklendir?",Ud:"Log Men\u00fcs\u00fcn\u00fc Devre D\u0131\u015f\u0131 B\u0131rak",ah:"\u00d6d\u00fcl Min. Alt\u0131n De\u011feri",Og:"Odaklanm\u0131\u015f G\u00f6rev, etkinle\u015ftirilirse, zindan\u0131 bitirmek i\u00e7in en k\u0131sa yolu izler.",zh:"Zar\u0131 Otomatik At?",Ah:"Zar\u0131 dikkatli kullan\u0131n, ilk zar\u0131 se\u00e7ene\u011fi devre d\u0131\u015f\u0131 b\u0131rakana kadar kullanmaya devam eder.",
gh:"Arama \u0130lerlemesi",Vg:"Onar\u0131m\u0131n varsay\u0131lan bekleme s\u00fcresi 10 dakikad\u0131r.",pg:"Minimum Durum",Sd:"\u0130\u015f tezgah\u0131ndaki mevcut \u00f6\u011fe [Bot beklenmedik \u015fekilde durursa Temizle]",rf:"D\u00f6k\u00fcm Kaynaklar\u0131 ba\u015far\u0131yla horreuma depoland\u0131.",lf:"Pazar yerindeki \u00f6\u011feleri kontrol ediyor...",qb:"\u00d6\u011fe i\u015f tezgah\u0131na ta\u015f\u0131nd\u0131.",Gf:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131 ve donat\u0131ld\u0131.",
Hf:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131.",xk:"Onar\u0131m ba\u015far\u0131s\u0131z oldu. Sayfa yenilenecek.",Df:"Malzemeler toplan\u0131yor...",Qf:"Onar\u0131m bekleniyor...",Ff:"Onar\u0131m ba\u015flad\u0131.",rb:"Onar\u0131m: \u00d6\u011feyi envanterden \u00e7antaya ta\u015f\u0131ma",Ef:"Onar\u0131m: \u00d6\u011feyi i\u015f tezgah\u0131ndan pakete ta\u015f\u0131ma.",nf:"Yeterli malzeme bulunamad\u0131. Onar\u0131m slotunu 5 dakikaligina devre disi birakiyorum. ",Af:"Alt\u0131n\u0131 saklamak i\u00e7in a\u00e7\u0131k art\u0131rmadan sat\u0131n al\u0131nacak \u00f6\u011feler aran\u0131yor...",
hf:"Paketlerdeki s\u00fcresi dolmu\u015f \u00f6\u011feler kontrol ediliyor...",jf:"\u00d6\u011fe ba\u015far\u0131yla s\u0131f\u0131rland\u0131.",kf:"Bo\u015f Alan veya S\u0131f\u0131rlanacak Alt\u0131n Yok.",sf:"Klan pazar\u0131nda sat\u0131\u015f haklar\u0131n\u0131z oldu\u011fundan emin olun!",tf:"Yeterli alt\u0131n ve/veya sat\u0131n al\u0131nacak \u00f6\u011fe yok. Yenilemek i\u00e7in 30sn bekliyor.",mb:"Ma\u011faza yenilendi.",nb:"\u0130yile\u015ftirme s\u0131ras\u0131nda hata.",wf:"Ruby veya Kuma\u015f yok, se\u00e7enekleri devre d\u0131\u015f\u0131 b\u0131rak.",
xf:"Paketlerde helaing \u00f6\u011fesi bulunamad\u0131.",ob:"Uygun \u00f6\u011feler bulunamad\u0131",yf:"Yiyecekler topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",zf:"En az bir yiyecek topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",pb:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",uf:"Paketlerden yiyecek al\u0131n\u0131yor.",vf:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",lb:"Daha fazla iyile\u015ftirme \u00f6\u011fesi yok. 30 saniye bekliyor.",
kb:"HP Kurtar\u0131ld\u0131.",za:"Yapacak bir \u015fey yok, bu y\u00fczden dua edece\u011fim!",Mf:"Sa\u011fl\u0131\u011f\u0131m\u0131 ve villa medicimi kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Nf:"Villa Medici bekleniyor, 60 saniye i\u00e7inde yenileniyor.",Of:"Underworld terk edildi.",Pf:"Sa\u011fl\u0131\u011f\u0131m\u0131 kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Bf:"Tanr\u0131 ya\u011flar\u0131 kontrol ediliyor...",Cf:"Tanr\u0131 ya\u011flar\u0131 topland\u0131.",
xa:"ARENADA ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",ya:"CIRCUS'ta ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",ff:"A\u00e7\u0131k art\u0131rma kontrol ediliyor! L\u00fctfen bekleyin...",gf:"\u00d6\u011felere teklif veriliyor. L\u00fctfen bekleyin...",If:"Otomatik Eritilen Item: ",Jf:"Eritme \u00d6\u011fesi: ",Kf:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n: ",Lf:"ER\u0130T: Eritilecek \u00f6\u011feler aran\u0131yor...",yk:"Eritilecek \u00f6\u011feler aran\u0131yor...",
mf:"Kost\u00fcm mevcudiyeti kontrol ediliyor...",qf:"Ba\u011f\u0131\u015fland\u0131 : ",pf:"Zar at\u0131l\u0131yor...",He:"Yeralti Farmla [Manuel, BETA]",Ie:"Bu ozelligi saldirmak istediginiz yaratigi actiktan sonra acin, otomatik olarak yaratigi acana kadar saldirmayacaktir. Dikkat edin.",Ge:"Farm Lokasyonu",Fe:"Farm Dusmani",Gd:"Otomatik Giri\u015f",Hd:"GameForge lobisinden a\u00e7\u0131l\u0131r pencere izinlerini vermeniz gerekmektedir. Nas\u0131l yap\u0131laca\u011f\u0131na dair dok\u00fcmantasyona bak\u0131n.",
Cg:"Bot'u Durdur",Dg:"Bot'u ka\u00e7 dakika bitince durdurmak istersiniz? (Dakika)",De:"Son Kullanma Tarihi",xg:"Sadece yemek sat\u0131n al?",yg:"Bunu etkinle\u015ftirirseniz, se\u00e7imlerinizi g\u00f6rmezden gelir ve herhangi bir \u015fey girmeden otomatik olarak yemek sat\u0131n al\u0131r.",Ab:"Harcamak i\u00e7in maksimum toplam alt\u0131n",zb:"Harcamak i\u00e7in maksimum alt\u0131n miktar\u0131",wg:"Bot, ya\u011flar\u0131 her 60 dakikada bir kontrol edecek",Sh:"Eritme s\u00fcrelerini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Ph:"Alt\u0131n\u0131n\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Rh:"Kullan\u0131labilir e\u015fyan\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Kh:"E\u015fyalar\u0131n\u0131z\u0131 kontrol etmek i\u00e7in bir tamir zamanlay\u0131c\u0131 ayarlar.",Jh:"Ittifak pazar\u0131ndaki alt\u0131n\u0131 kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Fh:"M\u00fczayede tutma alt\u0131n\u0131 se\u00e7ene\u011fi i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Bh:"Arenadaki PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Gh:"Sirk PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Yh:"\u0130statistiklerinizi e\u011fitmek i\u00e7in bir e\u011fitim zamanlay\u0131c\u0131 ayarlar.",Mh:"S\u00fcresi dolmu\u015f e\u015fyalar\u0131 s\u0131f\u0131rlamak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Wh:"D\u00f6vme malzemelerini horreum'a koymak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Dh:"Gladyat\u00f6rler ve paral\u0131 askerler m\u00fczayede kontrol\u00fc i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Oh:"M\u00fczayede ve market i\u00e7in e\u015fya aramak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Hh:"Ittifaga ba\u011f\u0131\u015f g\u00f6nderme zamanlay\u0131c\u0131s\u0131n\u0131 ayarlar.",Me:"Alt\u0131n Ta\u015f\u0131nd\u0131",Zd:"Eritme ve Muzayede listesi e\u015fyalar\u0131n\u0131 satma",hh:"Market Otomasyonu",jh:"E\u015fya Arama Ayarlar\u0131",ih:"Bu ozellik, dukkanlarda e\u015fya aramak i\u00e7in kullanilir. Sadece e\u015fyalar\u0131 listeye ekleyin, kuma\u015f miktar\u0131n\u0131 belirtin ve aramay\u0131 ba\u015flat\u0131n. Ornegin mor samnit, mor samnit i bulana kadar arar.",
kh:"Kullan\u0131lacak Kuma\u015flar:",lh:"Ka\u00e7 kuma\u015f kullan\u0131lacak?",ia:"Full E\u015fya Ad\u0131n\u0131 Girin",Lb:"E\u015fya Seviyesini Girin",nh:"E\u015fya Kalitesi",mh:"E\u015fya Ad\u0131 Buraya",oh:"Aramaya Ba\u015fla",ph:"Atla ve Devam Et",qh:"Aramay\u0131 Durdur",Je:"En ucuz mu, en pahal\u0131 m\u0131 alay\u0131m?",rg:"En Pahal\u0131",Pd:"En Ucuz",fa:"Bir se\u00e7enek se\u00e7in",de:"Yeralt\u0131 D\u00fcnyas\u0131 Itemlarini Goster",Ke:"G\u00f6reve odaklan\u0131ls\u0131n m\u0131?",
El:"Elbise yoksa yakut kullan?",Pa:"Diger serverlarda sald\u0131rmak icin, oyuncunun sayfasini acin ve A & C butonlariyla ekleyin. Not: Rapor edilmemek i\u00e7in ayn\u0131 ki\u015filere sald\u0131rmaktan ka\u00e7\u0131n\u0131n. Rapor edilmek, banlanma \u015fans\u0131n\u0131z\u0131 art\u0131r\u0131r.",tl:"Yesil Eritilsin mi?",Ig:"Herhangi bir filtre girildiyse rastgele g\u00f6revleri kabul etme?",Gc:"Maksimum materyal kalitesi?",Li:"Mersaneri Ara?",bl:"T\u00fcm Se\u00e7ilenleri Sat\u2019\u0131 t\u0131klay\u0131n ve t\u00fcm e\u015fyalar\u0131 sat\u0131n. \u0130lk (1) \u00e7antan\u0131zda 2x3 bo\u015f alan oldu\u011fundan emin olun ve kalite secmeyi unutmayin. Alt\u0131n toplamak i\u00e7in, alt\u0131n\u0131 filtreleyin ve `Se\u00e7ilenleri Al veya T\u00fcm\u00fcn\u00fc Al`\u0131 kullan\u0131n",
Nj:"\ud83d\udd25 : E\u015fyay\u0131 eritme listesine ekler.",zi:"\ud83d\udd28 : E\u015fyay\u0131 a\u00e7\u0131k art\u0131rma listesine ekler.",tj:"D\u00fckkan dolu oldu\u011funda d\u00fckkan\u0131 kuma\u015fla yenileyin (Yeniden sat\u0131n alman\u0131z gerekecek)",hj:"Sayfa:",oj:"Durdur",mj:"Bu Sayfay\u0131 Sat",jj:"Se\u00e7ilenleri Al",ij:"T\u00fcm\u00fcn\u00fc Al",pj:"Paket Ayarlar\u0131",nj:"Kaynaklar\u0131 G\u00f6nder",kj:"T\u00fcm Se\u00e7ilenleri Sat",qa:"E\u015fya T\u00fcr\u00fc",U:"Silahlar",
M:"Kalkanlar",I:"Z\u0131rhlar",L:"Kasklar",K:"Eldivenler",J:"Ayakkabilar",T:"Y\u00fcz\u00fckler",R:"Nazarliklar",oa:"Malzemeler (Yiyecekler)",va:"G\u00fc\u00e7lendirmeler",fj:"Yukseltmeler",sa:"Receteler",ra:"Mersaneri Askerler",ua:"Demirhane Mallari",ta:"Persomenler",Ga:"Takviyeler",Fa:"Etkinlik E\u015fyalar\u0131",ed:"D\u00f6vme Malzemeleri",gj:"Alt\u0131n",P:"Hepsi",jl:"Kalite",wa:"Beyaz",C:"Ye\u015fil",B:"Mavi",D:"Mor",G:"Turuncu",S:"K\u0131rm\u0131z\u0131",lj:"T\u00fcm Sat\u0131\u015f Se\u00e7enekleri",
Aj:"\u00d6nek/Sonek Kombinasyonunu Yoksay?",Si:"Ka\u00e7 yiyecek sat\u0131n almak/al\u0131nmal\u0131?",Gi:"Normal",Fi:"Orta",Ei:"Zor",Da:"Standart",ml:"S\u0131k\u0131\u015fma Onar\u0131m\u0131",vk:"Dungeon/Circus/Arena\u2019y\u0131 devre d\u0131\u015f\u0131 b\u0131rakmak istiyorsan\u0131z Cehenneme Giri\u015fi Devre D\u0131\u015f\u0131 B\u0131rakin. Cehenneme manuel olarak girdiyseniz, Cehennem Modu\u2019nu etkinle\u015ftirmeniz gerekecektir.",ai:"Egitimleri ka\u00e7 kez e\u011fitmek istedi\u011finizi ve onlar\u0131n \u00f6nceliklerini belirleyin. Bot, bir \u00f6ncelik belirlemedik\u00e7e e\u011fitim yapmayacakt\u0131r. E\u011fer \u00f6ncelik belirlenmi\u015fse ancak ba\u015fka bir egitim kalmam\u0131\u015fsa, secilen egitim devam edecektir.",
Qk:"Gorev",rl:"Erit",xl:"Eritme Ayarlar\u0131",Kj:"Eritilen Nesneler",yl:"\u00d6nek veya Sonek Ekle, paketlerde bulunursa otomatik olarak eritilecektir.:",wl:"Eritilen Nesne:",Vb:"Onarmak istedi\u011finiz nesneyi t\u0131klay\u0131n. Onar\u0131ma ba\u015flamak i\u00e7in en az 10,000 alt\u0131n\u0131z\u0131n olmas\u0131 gerekmektedir. Yeni repair sistemi refresh atilsa bile kaldigi yerden devam edecektir. Sorun cikarsa clear a basip workbench itemini temizleyebilirsiniz. Ayr\u0131ca envanterinizde yer a\u00e7mayi unutmayin. Bot, kondisyon seciminize gore aktif olacaktir.",
Kk:"Sadece S\u00f6zle\u015fmeliye Uygula",Nk:"M\u00fczayede yaln\u0131zca piyasa sona yakla\u015ft\u0131\u011f\u0131nda teklif verecektir.",Mk:"Envanterde bos yer acmayi ve en az 7K alt\u0131n\u0131n\u0131z\u0131n oldu\u011fundan emin olun. Bot 1. koydugunuz prefixden baslayip sona dogru bakacaktir, bu siralamayi uzerine gelip tasiyarak degistirebilirsiniz. Bot, sectiginiz sekmeye gore itemlari tasiyacak ve eritecektir. Eritme i\u015flemi her ayarlanan zamana gore kontrol edilir. Bu ayari Zamanlayici sekmesinden degistirebilirsiniz. Eger kombinasyon olarak bakmak istemiyorsaniz, onek sonek kombinasyonunu yoksay`i aktiflestirin.",
Vi:"\u0130yile\u015ftirme/Buff",nl:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n:",ql:"Teklifi Atla: ittifak \u00fcyesi zaten nesne i\u00e7in teklif verdi ",pl:"Teklifi Atla: Zaten nesne i\u00e7in teklif verildi ",advanced:"Geli\u015fmi\u015f",arena:"Arena",ma:"Otomatik sald\u0131r\u0131 listesi",Tb:"Bu listedekilere sald\u0131rma",ka:"Oyuncu Ekle",la:"Oyuncu Ad\u0131 Gir (Ayni Server)",Yk:"Yiyecek t\u00fckenirse Botu Durdur?",circusTurma:"Sirkin Turma",Hi:"Zorluk",dungeon:"Zindan",
Ii:"Zindan Ayarlar\u0131",eventExpedition:"Etkinlik Seferi",expedition:"Sefer",Mi:"Sefer Ayarlar\u0131",vj:"Yarat\u0131k Se\u00e7",$k:"En Y\u00fcksek",Zk:"\u0130yile\u015ftirme e\u015fyalar\u0131n\u0131z\u0131 envanterinizin ilk sayfas\u0131na koyun",tc:"\u0130\u00e7inde",Qd:"Yeralti kostumu secin",vi:"Yeralti kostumu hazir oldugunda giy?",xh:"Alt\u0131n\u0131 Depola",yh:"Alt\u0131n\u0131 M\u00fczayedede Depola?",eh:"D\u00fckk\u00e2n\u0131 yenilemek i\u00e7in \u0130\u015f K\u0131yafetleri kullan\u0131ls\u0131n m\u0131?",
Ek:"S\u0131f\u0131rlanacak Nesneleri Se\u00e7in",Xg:"S\u00fcresi Dolan Nesneleri S\u0131f\u0131rla",Gb:"Not: Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, bot paketlerden gelecek s\u00fcresi dolan nesneleri ittifak marketine satar ve s\u00fcrelerini s\u0131f\u0131rlar. Ittifak gereklidir. \u00c7antalar\u0131n\u0131zda bo\u015f 3x3 alan\u0131n\u0131z oldu\u011fundan emin olun, ozellikle birinci canta. Her basladiginda son 7 sayfaya bakar. Eger calismazsa oyun ayarlarindan sure bitimini tarih olarak ayarlayin.",
Eg:"Bota Rastgele Ara Vermesini Sa\u011fla [Test A\u015famas\u0131]:",aa:"Alt\u0131n\u0131 Tut: Bot bu alt\u0131n\u0131 \u00e7antada saklayacak:",dg:"Maksimum Alt\u0131n",bh:"Gereksiz itemlar i\u00e7in teklif verilecek",rd:"Rastgele Gecikme Ekle",sd:"Bot i\u00e7in rastgele gecikme ekleyebilirsiniz.",Fb:"Onar\u0131m",sl:"Mavi Eritilsin mi?",vl:"Mor Eritilsin mi?",ul:"Turuncu Eritilsin mi?",Lj:"Sadece envantere koyulanlari mi eritsin?",Mj:"Bu renk se\u00e7imlerini yok sayacakt\u0131r",Ha:"\u00d6nek Ekle",
Ia:"Sonek Ekle",th:"Erit",Ad:"Otomatik Arama",tg:"Otomatik M\u00fczayede",Bd:"Bu ozelligi fazla kullanmak banlanmaniza sebep olabilir. Eger Crazy Addon`da muzayedeyi zamanlarini gosteren ozelligi aktif ettiyseniz bu ozelligi kullanmadan once onu iptal edin, yoksa yavaslama olacaktir.",dh:"Gladyat\u00f6rler M\u00fczayedesinde Ara",fh:"Mersaneriler M\u00fczayedesinde Ara",Jd:"Yiyecek \u0130\u00e7in Teklif Verilsin mi?",eg:"Maksimum Teklif",Kd:"Durum daha azsa teklif ver",Ld:"Teklif Edilen Nesneler",
kk:"M\u00fczayede Dili",lk:"L\u00fctfen dil ayarlarini oyunun diline gore tekrar ayarlay\u0131n.. Hepsi do\u011fru oldu\u011fundan emin olun, aksi takdirde teklif vermeyebilir.",vd:"Piyasada aranacak nesneleri ekleyebilirsiniz. Bir nesneyi listede ekledi\u011finizde, nesneyi arayacak ve sonu\u00e7lar\u0131 sol tarafta g\u00f6sterecektir. Otomatik m\u00fczayedeyi aramak i\u00e7in de arayacakt\u0131r. Otomatik teklifi etkinle\u015ftirirseniz, belirledi\u011finiz aral\u0131klarla nesneyi arayacak ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: Tekil nesneleri d\u00fckkanlarda aramak i\u00e7in, en az\u0131ndan bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
ik:"M\u00fczayedeyi dikkatli kullan\u0131n!",jk:"Otomatik teklif, sunucuya \u00e7ok fazla istek g\u00f6nderir ve s\u00fcrekli kullan\u0131rsan\u0131z yasa\u011fa neden olabilir!",Ug:"Etkinlik Puanlar\u0131n\u0131 Yakut ile Yenile?",fe:"Otomatik Ya\u011f Topla",nk:"Kutsal Ya\u011flar\u0131 Otomatik Al",Ak:"G\u00f6rev Kontrol H\u0131z\u0131",La:"Ittifak \u00dcyelerine Sald\u0131r\u0131ls\u0131n m\u0131?",Ja:"Oto Sald\u0131r\u0131 listesine cal\u0131nan Alt\u0131n X ALTINI a\u015ft\u0131\u011f\u0131nda > eklensin mi? ",
Ka:"Yenildi\u011finizde otomatik olarak eklensin mi?:",Jb:"Skor Tablosu Sald\u0131r\u0131lar\u0131",Qb:"\u00c7ok Uzun",sb:"Uzun",Bb:"Orta",Nb:"K\u0131sa",Rb:"\u00c7ok K\u0131sa",ge:"HP > ise Yeralt\u0131 D\u00fcnyas\u0131'na Gir",Pg:"G\u00f6rev Kontrol H\u0131z\u0131",Hg:'Varsay\u0131lan olarak "3x" ayarl\u0131d\u0131r. Bot g\u00f6revlerle sorun \u00e7\u0131kar\u0131yorsa, g\u00f6rev h\u0131z\u0131n\u0131 sunucu h\u0131z\u0131n\u0131za g\u00f6re ayarlay\u0131n.',Ne:"\u0130yile\u015ftirme \u00c7anta Se\u00e7imi",
he:'Puanlar\u0131 manuel olarak yeniliyorsan\u0131z, s\u0131k\u0131\u015f\u0131rsa "Yeniden Etkinlik Seferi Yenile" d\u00fc\u011fmesine t\u0131klaman\u0131z gerekmektedir!',sk:"Etkinlik Seferi'ni ba\u015flatmak i\u00e7in en az birini etkinle\u015ftirmeniz gerekmektedir: sefer, zindan, arena veya sirk.",Rg:"E\u011fer s\u0131k\u0131\u015f\u0131rsa Etkinlik Seferi'ni Yenile!",cb:"\u0130ttifak \u00fcyesi teklif verdiyse atlas\u0131n m\u0131?",Gk:"E\u011fer paketlerde bulunan \u00f6\u011feleri kullanarak eritmek istiyorsan\u0131z, t\u00fcm ayarlar\u0131 devre d\u0131\u015f\u0131 b\u0131rak\u0131n. Ancak hala renkleri se\u00e7ebilirsiniz.",
pk:"Karakter(Kapal\u0131) / S\u00f6zle\u015fmeli(A\u00e7\u0131k)",Dk:"Ana/Sirk her iki karakteri de tamir etsin mi?",Hk:"Zamanlar",Timers:"Her zamanlay\u0131c\u0131 i\u00e7in a\u015fa\u011f\u0131daki dakika cinsinden say\u0131lar\u0131 girin veya varsay\u0131lan b\u0131rak\u0131n. Dikkat edin! eger cok kisa sureler girerseniz baz\u0131 ozellikler botu donguye sokayabilir.",gb:"Skor Tablosu Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Hb:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131n\u0131 Se\u00e7",
Ib:"Bot, skor tablosu listesinden rastgele sald\u0131r\u0131 yapacakt\u0131r.",ib:"Lig Sald\u0131r\u0131s\u0131",fb:"Lig Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Db:"Rastgele Sald\u0131r",Eb:"En d\u00fc\u015f\u00fckten en y\u00fckse\u011fe sald\u0131r",hk:"Bot, varsay\u0131lan olarak ittifak \u00fcyelerine sald\u0131rmaktan ka\u00e7\u0131nacakt\u0131r.",Ce:"Sefer Yeri:",Cd:"Bonuslar\u0131 Otomatik Al:",rh:"Boss`a sald\u0131rma",ae:"Zindan Yeri:",$g:"Kaybederseniz S\u0131f\u0131rlans\u0131n m\u0131?",
Qe:"Cehennem Ayarlar\u0131",Re:"Bu mod birden sona kadar saldirarak cehennemi bitirir. \u0130yile\u015ftirme y\u00fczde ayarlar\u0131n\u0131z\u0131 iyile\u015ftirme sekmesinden yap\u0131land\u0131r\u0131n ve iyile\u015ftirme sekmesini etkinle\u015ftirdi\u011finizden emin olun. Cehennem modu aktif oldugunda bot cehennem iyilestirme oranina gore karakterinize yemek yedirecektir. Cehenneme giri\u015f sizi oturumdan \u00e7\u0131kar\u0131yorsa, extralar tabini ziyaret edin ve otomatik giri\u015f kutusunu i\u015faretleyin.",
Oe:"Cehennem Zorlu\u011fu",Fd:"Otomatik Cehennem Giri\u015fi / Cehennem Modu:",pi:"Puan = 0 ise Mobilizasyon Kullan?",ui:"Yakut Kullan?",ie:"Puan Yoksa Cehennemden \u00c7\u0131k\u0131ls\u0131n m\u0131?",ci:"Bot, \u00f6nce villa mediciyi kullanmaya \u00e7al\u0131\u015facakt\u0131r, e\u011fer yoksa iyile\u015ftirme iksiri kullanacakt\u0131r. \u0130yile\u015ftirme anahtar\u0131n\u0131 etkinle\u015ftirdi\u011finizden emin olmay\u0131 unutmay\u0131n.",ki:"Otomatik cehennem giri\u015fi, cehenneme girdi\u011finizde zindan/arena/sirk otomatik olarak devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",
Ik:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",ti:"Villa Medici Kullan?",ri:"\u0130yile\u015ftirme \u0130ksiri Kullan?",Rf:"Bu ozellik genel marketten esya almaya yarar. Satin alma suresi biraz surebilir.",ee:"Pazar Aramas\u0131n\u0131 Etkinle\u015ftir:",Sf:"Dakika cinsinden Pazar Arama Aral\u0131\u011f\u0131:",Tf:"\u00d6nerilen 10 dakika.",$e:"Nesne Ayarlar\u0131:",Ye:"Nesne Ad\u0131 \u0130\u00e7erir",N:"Maksimum Fiyat",af:"Nesne T\u00fcr\u00fc",Ze:"Nesne Nadirli\u011fi",Od:"Ruh Ba\u011fl\u0131 Al\u0131ns\u0131n m\u0131?",
cf:"Al\u0131nacak Nesneler",bf:"Herhangi biri maksimum fiyat\u0131 a\u015f\u0131yorsa \u00f6\u011feleri almay\u0131 deneyin.:",Md:"Sat\u0131n Al\u0131nan Nesneler:",Ti:"\u0130yile\u015ftirme Y\u00fczdesi",dk:"D\u00fckkandan Yiyecek Sat\u0131n Al\u0131ns\u0131n m\u0131?",ek:"Paketten \u0130yile\u015ftirme Kullan\u0131ls\u0131n m\u0131?",ak:"Cervisia Kullan\u0131ls\u0131n m\u0131?",ck:"Yumurta Kullan\u0131ls\u0131n m\u0131?",cl:"Son Kullan\u0131ld\u0131",location:"Konum",Strength:"G\u00fc\u00e7",Dexterity:"Beceri",
Agility:"\u00c7eviklik",Constitution:"Dayaniklilik",Charisma:"Karizma",Intelligence:"Zeka",Zh:"E\u011fitim Ayarlar\u0131",$h:"E\u011fitim yapmak istedi\u011finiz nitelikleri se\u00e7in. Yeterli alt\u0131n\u0131z oldu\u011funda e\u011fitim yapacakt\u0131r.",Tc:"Sonraki ad\u0131m",cj:"Hay\u0131r",dj:"Normal",hl:"Rakip",il:"Rakip Seviyesi",sj:"G\u00f6revler",random:"Rastgele",ol:"Ayarlar",zl:"Yak\u0131nda...",type:"G\u00f6rev t\u00fcrlerini etkinle\u015ftirmek i\u00e7in simgeleri t\u0131klay\u0131n.",
Gl:"Evet",A:"Arama",pd:"\u00d6\u011feleri ekle",Xj:"Demircilik Kaynaklar\u0131n\u0131 Otomatik Olarak Sakla",Bl:"G\u00f6nder",al:"Aral\u0131k : ",Rk:"Otomatik Teklif Etkinle\u015ftir",Sk:"Bir ittifak \u00fcyesi zaten teklif verdiyse teklif vermeyin",Dl:"\u00d6\u011fretici",Ub:"Arena'da en d\u00fc\u015f\u00fck veya en y\u00fcksek seviyeli rakiple y\u00fczle\u015fmek isteyip istemedi\u011finizi yukar\u0131daki d\u00fc\u011fmelerden se\u00e7in. Daha fazla kullan\u0131c\u0131, botun h\u0131z\u0131n\u0131 yava\u015flatabilir.",
Lk:"Ba\u015flamak i\u00e7in bir \u00f6\u011feyi listeyle ekleyin (\u00f6r. `Lucius`). Ekledikten sonra, arama sonu\u00e7lar\u0131n\u0131 sol tarafta g\u00f6r\u00fcnt\u00fclemek i\u00e7in arama sonu\u00e7lar\u0131n\u0131 g\u00f6sterir. Ayn\u0131 zamanda otomatik m\u00fczayede ama\u00e7lar\u0131 i\u00e7in de arar. Otomatik teklifi etkinle\u015ftirirseniz, belirli aral\u0131klarla \u00f6\u011feyi arar ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: D\u00fckkanlarda benzersiz \u00f6\u011feleri aramak i\u00e7in, en az bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
Uk:"Yarat\u0131k numaras\u0131n\u0131 yukar\u0131daki d\u00fc\u011fmelerden se\u00e7ebilirsiniz. Numara 1, en soldaki yarat\u0131\u011f\u0131 temsil eder. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",Ji:"Zindan\u0131n zorlu\u011funu yukar\u0131dakilerden se\u00e7in. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",Ui:"\u0130yile\u015ftirme Ayarlar\u0131",Ki:"Ittifak Piyasas\u0131ndan al\u0131\u015fveri\u015f yaparak fazla alt\u0131n\u0131 depola -> Min. Alt\u0131n. 1. Envanterde bos yer birakmaya calisin.",
dl:"T\u00fcm\u00fcn\u00fc Ta\u015f\u0131",el:"Se\u00e7ilenleri Ta\u015f\u0131",Ok:"Otomatik \u0130yile\u015ftirme",Pk:"Otomatik \u0130yile\u015ftirme Y\u00fczdesi",Fl:"Yakut",zg:"Genel Ayarlar",wj:"Hepsini Sat",xj:"Se\u00e7ilenleri Sat",ja:"Silahlar",ga:"Kalkanlar",W:"G\u00f6\u011f\u00fcs Z\u0131rhlar\u0131",Z:"Kasklar",Y:"Eldivenler",ha:"Ayakkab\u0131lar",ea:"Y\u00fcz\u00fckler",V:"Kolyeler",ni:"Kullan\u0131labilir",mi:"G\u00fc\u00e7lendirmeler",Qg:"Re\u00e7eteler",gg:"S\u00f6zle\u015fmeli Scrollar",
Sg:"Takviyeler",Mg:"G\u00f6rev Filtre \u0130gnore",Lg:"Almak istemedi\u011finiz g\u00f6revleri filtrelemek i\u00e7in anahtar kelimeleri girin",X:"Anahtar Kelime Girin",H:"Ekle",Tg:"Kald\u0131r",Rd:"Temizle",Jg:"G\u00f6rev Filtre Kabul",Kg:"Almak istedi\u011finiz g\u00f6revleri se\u00e7mek i\u00e7in anahtar kelimeleri girin. Odule gore secmek isterseniz odulun icinde gecen bir kelimeyi girin.",Ba:"Zamanl\u0131 G\u00f6revleri Atla?",Bk:"G\u00f6revler",Dd:"Oto Kost\u00fcm",oi:"Kost\u00fcm Kullan?",Id:"Ana Sava\u015f",
$d:"Dungeon Sava\u015f ve Etkinlik",Ed:"Bot yaln\u0131zca ke\u015fif/zindan puanlar\u0131n\u0131z 0 ise Dis Pater Normal ve Medium giyecektir.",Pe:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",ud:"Boss Mevcut Oldu\u011funda Sald\u0131r?",jb:"5 ba\u015far\u0131s\u0131z sald\u0131r\u0131dan sonra Lig sald\u0131r\u0131s\u0131n\u0131 devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",Se:"Kutsal Ya\u011flar",og:"\u00dcr\u00fcn Ad\u0131",da:"Min. Item Seviyesi",Aa:"Min. \u00dcr\u00fcn Kalitesi",td:"Zamanlay\u0131c\u0131y\u0131 Uygula/S\u0131f\u0131rla",
Ve:"\u00d6nek/Soneki Yok Say",wi:"Evet",vg:"Hay\u0131r",Qa:"Ge\u00e7mi\u015fi Temizle",uh:"Yok Sayma Listesi",Cb:"\u00d6nek",Ob:"Sonek",Zg:"S\u00fcresi Dolan \u00dcr\u00fcnleri S\u0131f\u0131rla",vh:"Kondisyonlar disinda rastgele erit",wh:"Eritme Sekmesi",hb:"Ekstralar",yd:"M\u00fczayede",Xf:"Pazar",Pb:"Zamanlar",Uh:"Eritme",Th:"Alt\u0131n Yoksa Eritme",Qh:"\u00dcr\u00fcn Yoksa Eritme",Ca:"Tamir",Ih:"Ittifak Pazar\u0131 Alt\u0131n Tutma",Eh:"M\u00fczayede Alt\u0131n Tutma",Xh:"E\u011fitim",Lh:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla",
Vh:"Hammadde Depola",Ch:"M\u00fczayede Kontrol",Nh:"Arama",v:"Etkinle\u015ftir",qg:"Min. Alt\u0131n",Kb:"Saat Se\u00e7in",eb:"Ittifaga Alt\u0131n Ba\u011f\u0131\u015fla",Vd:"Her 5 dakikada bir ba\u011f\u0131\u015f yapacakt\u0131r. Zamanlay\u0131c\u0131lar sekmesinden aral\u0131\u011f\u0131 de\u011fi\u015ftirebilirsiniz",Te:"Ne kadar ba\u011f\u0131\u015f yap\u0131lmal\u0131?",Wd:"Ne zaman ba\u011f\u0131\u015f yap\u0131lmal\u0131 >",ef:"Daha az <",Wg:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla ve Di\u011fer Ayarlar\u0131",
Yg:"S\u0131f\u0131rla in:",wk:"Birden fazla \u00f6\u011feyi se\u00e7mek i\u00e7in Ctrl (Mac'de Cmd) tu\u015funu bas\u0131l\u0131 tutun",We:"Ayarlar\u0131 Kaydet / Yukle",Ee:"Ayarlar\u0131 Indir",Xe:"Ayarlar\u0131 Yukle",hg:"T\u00fcm Oyunculara Mesaj G\u00f6nder",ig:"[Ultra Premium Anahtar\u0131 gerektirir, anahtar i\u00e7in Discord \u00fczerinden ileti\u015fime ge\u00e7in.]",jg:"G\u00f6nderilecek mesaj\u0131 girin",Td:"\u00d6zel scriptler i\u00e7in Discord \u00fczerinden bize ula\u015f\u0131n",lg:"G\u00f6nder",
mg:"Oyuncular\u0131 G\u00f6ster",kg:"T\u00fcm\u00fcn\u00fc Se\u00e7",ng:"T\u00fcm Se\u00e7imleri Kald\u0131r",df:"Envanterinizin yeterli alan\u0131 oldu\u011fundan emin olun. Geri say\u0131m 2 dakikad\u0131r."},Ih={qj:"A\u00e7\u00e3o p\u00f3s expedi\u00e7\u00e3o",gk:"Clique aqui se o reparo ficar travado",uk:"Quando HP estiver baixo, use cura",Bg:"Reparo Parcial",Le:"Reparo Completo",Ag:"Reparo Parcial ou Completo",ce:"Habilitar Limite",Wi:"Limite",Xi:"Se voc\u00ea deseja limitar o n\u00famero de vezes que quer atacar o inimigo, habilite esta op\u00e7\u00e3o e defina o limite. O bot continuar\u00e1 atacando o resto dos inimigos ap\u00f3s terminar de atacar o monstro selecionado.",
Yd:"N\u00e3o entre no submundo com a fantasia do submundo",Xd:"Se voc\u00ea n\u00e3o quiser entrar no submundo enquanto estiver usando a fantasia do submundo, ative esta op\u00e7\u00e3o",ji:"Submundo",bi:"Melhorias do Submundo",di:"Usar os poderes dos deuses ap\u00f3s entrar no submundo?",ei:"Selecione os deuses para usar seus poderes:",fi:"Usar Buff de Arma na arma?",gi:"Usar Buff de Armadura no seguinte equipamento:",rk:"O tempo de espera \u00e9 de 30 minutos. Se voc\u00ea n\u00e3o estiver com um traje, o bot redefinir\u00e1 o tempo de espera para 0.",
Fk:"Selecionar Cores",Ra:"Forja de Vulcano",Va:"Escudo Terrestre de Feronia",Wa:"Poder Fluido de Netuno",Xa:"Liberdade A\u00e9rea de Aelous",Ya:"N\u00e9voa Mortal de Plut\u00e3o",Za:"Sopro de Vida de Juno",$a:"Armadura de Escamas das Montanhas da Ira",ab:"Olhos de \u00c1guia",bb:"Vestimenta de Inverno de Saturno",Sa:"Armadura de Touro de Bubona",Ta:"Trajes de Ladr\u00e3o de Merc\u00fario",Ua:"T\u00fanica de Luz de R\u00e1",$f:"Pacotes",Uf:"Invent\u00e1rio",ca:"Pre\u00e7o M\u00edn.",ba:"Quantos",xb:"Vender Itens",
wb:"Procurar em",Wf:"Cor do Material",Vf:"Cor do Item",cg:"Armaz\u00e9m",yb:"Mudar para Materiais",bg:"Mudar para Itens",ag:"Vender Materiais",tb:"Por favor, insira um nome de item v\u00e1lido, faixa de pre\u00e7o e quantidade.",ub:"Nenhum item adequado encontrado nos locais de busca selecionados.",vb:"Todos os itens foram listados com sucesso!",zk:"Todos os materiais foram listados com sucesso!",Yf:"Se voc\u00ea quiser vender itens por um pre\u00e7o fixo, voc\u00ea pode inserir o mesmo valor para o pre\u00e7o m\u00ednimo e m\u00e1ximo.",
Zf:"Este recurso ainda \u00e9 experimental, use com cautela. Se voc\u00ea n\u00e3o colocar um pre\u00e7o fixo, os itens ser\u00e3o listados aleatoriamente entre o pre\u00e7o m\u00ednimo e m\u00e1ximo que voc\u00ea inserir.",mk:"Define o m\u00e1ximo de ouro que o bot gastar\u00e1 por ciclo.",Ma:"O bot come\u00e7ar\u00e1 a fazer lances em itens de comida, se habilitado. Voc\u00ea n\u00e3o precisa habilitar os interruptores de gladiador/mercen\u00e1rio.",wd:"O bot n\u00e3o far\u00e1 lances sobre os lances dos aliados.",
xd:"Ignorar combina\u00e7\u00e3o de Prefixo/Sufixo ao procurar por um item no leil\u00e3o.",Ej:"Selecione os tipos de item que voc\u00ea deseja fundir.",Fj:"Selecione as cores que voc\u00ea deseja fundir.",Gj:"Selecione o n\u00edvel dos itens que voc\u00ea deseja fundir.",Hj:"Selecione o martelo que voc\u00ea deseja usar.",Ij:"Note que o c\u00edrculo Verde e Vermelho ao lado da primeira caixa s\u00e3o para ativar/desativar a regra.",Jj:"Se voc\u00ea quiser fundir aleatoriamente quaisquer cores ou tipos, voc\u00ea pode ativar `Fundir aleatoriamente se nenhuma condi\u00e7\u00e3o for atendida? (\u00daltima op\u00e7\u00e3o habilitada no v\u00eddeo tutorial)",
uj:"Reparar antes de fundir?",ye:"Selecionar Monstro",me:"Usar Ampulheta/Rubi?",tk:"Usar Rubi?",pe:"Usar Mobiliza\u00e7\u00e3o?",oe:"Usar Po\u00e7\u00e3o de Vida?",le:"Percentual de Cura (%)",we:"N\u00famero de Ataques",ne:"Intervalo de Ataque (em segundos)",je:"Ataques Realizados",ke:"Ampulhetas Restantes",ue:"Nota: Usa po\u00e7\u00f5es de vida para curar, n\u00e3o comida.",ve:"Nota: Se os ataques pararem prematuramente, tente 'Resetar Ataques'.",ze:"Iniciar",xe:"Resetar",Ae:"Parar",Be:"Configura\u00e7\u00f5es de Expedi\u00e7\u00e3o (Clique para minimizar)",
qe:"Monstro 1",re:"Monstro 2",se:"Monstro 3",te:"Monstro 4",Ck:"Reparar antes de fundir?",Ci:"Esta op\u00e7\u00e3o usar\u00e1 cervisia quando seu premium expirar.",ej:"Esta op\u00e7\u00e3o ativa e seleciona \u00f3leos das recompensas divinas. Pode usar \u00f3leos n\u00famero 1 e 3 no personagem, mas o n\u00famero 2 s\u00f3 ser\u00e1 pego para pacotes.",Ai:"Esta op\u00e7\u00e3o usar\u00e1 buffs no hor\u00e1rio que voc\u00ea definir. Encontrar\u00e1 buffs nos pacotes e os aplicar\u00e1 ao personagem.",
Yi:"Esta op\u00e7\u00e3o te levar\u00e1 ao submundo. N\u00e3o esque\u00e7a de habilitar o Login Autom\u00e1tico na aba Extras, caso contr\u00e1rio, voc\u00ea pode ser desconectado ao entrar no submundo [Bug do Jogo]",Sb:"O bot normalmente escolhe de 3 a 6 tentativas aleat\u00f3rias para atacar na lista de arena. Se voc\u00ea habilitar esta op\u00e7\u00e3o, ele passar\u00e1 pela sua lista at\u00e9 que possa atacar algu\u00e9m. Isso pode levar algum tempo.",rj:"Esta op\u00e7\u00e3o \u00e9 apenas para licen\u00e7as premium. Simula o ataque antes de atacar um usu\u00e1rio para uma taxa de vit\u00f3ria de 75%.",
zd:"Voc\u00ea n\u00e3o precisa habilitar a togglede leil\u00e3o principal para habilitar esta op\u00e7\u00e3o.",$j:"Esta op\u00e7\u00e3o atualizar\u00e1 a p\u00e1gina a cada segundo quando o leil\u00e3o estiver no estado -Muito Curto- para dar lances constantemente e vencer o leil\u00e3o.",Cj:"Se nenhuma das condi\u00e7\u00f5es de fus\u00e3o for atendida, ele fundir\u00e1 aleatoriamente. Certifique-se de selecionar o tipo e a cor do item.",Dj:"Esta op\u00e7\u00e3o fundir\u00e1 apenas itens do invent\u00e1rio. Ignorar\u00e1 itens nos pacotes.",
Na:"Itens de Leil\u00e3o",fg:"Itens de Mercen\u00e1rio",Mb:"Itens da Loja",li:"Itens \u00danicos",yj:"Definir fundo para preto [Aumenta o desempenho]",zj:"Mover bot\u00f5es do GLDbot para o canto inferior esquerdo?",Di:"Atacar o Circo Sem Curar",Yj:"Pegar ouro dos pacotes se necess\u00e1rio?",Zj:"Ouro foi pego dos pacotes para treinamento",Cl:"Nenhum ouro foi encontrado nos pacotes para treinamento",Vj:"Itens Reparados",Oj:"Ataques na Arena",Qj:"Ataques no Circo",qd:"Itens Reiniciados",Tj:"Ataques em Expedi\u00e7\u00f5es",
Sj:"Ataques em Masmorras",Wj:"Ataques no Submundo",Pj:"Dinheiro Ganhado na Arena",Rj:"Dinheiro Ganhado no Circo",Al:"Itens Fundidos",Uj:"Ouro Reciclado",Pi:"Batalha de Guilda",Ri:"Configura\u00e7\u00f5es da Guilda",Wk:"Atacar\u00e1 guildas aleatoriamente.",Qi:"Nome da Guilda",Bi:"Redefinir Estat\u00edsticas",Oi:"Atacar Guildas Aleatoriamente",gl:'GLDbot: Use os dados para atualizar a caixa misteriosa e encontrar itens valiosos antes de abri-los (Etc. Trajes). Clique em "Iniciar" para abrir ba\u00fas.',
Ec:"Madeira",uc:"Cobre",yc:"Ferro",Ac:"Couro",Fc:"Fio de L\u00e3",vc:"Bolas de Algod\u00e3o",xc:"Hemp",wc:"Tiras de Gaze",Bc:"Fios de Linho",zc:"Remendo",Dc:"Veludo",Cc:"Fio de Seda",Nc:"Pelo",Hc:"Lasca de Osso",Qc:"Escama",Kc:"Garra",Mc:"Presas",Lc:"Escama de Drag\u00e3o",Ic:"Corno de Touro",Pc:"Gl\u00e2ndula Venenosa",Jc:"Casaco de Pele de Cerberus",Oc:"Escama de Hydra",Rc:"Pena de Esfinge",Sc:"Pele de Typhon",pc:"Lapis Lazuli",jc:"Ametista",ic:"Ambar",kc:"Agua-Marinha",qc:"Safira",nc:"Granada",
mc:"Esmeralda",lc:"Diamante",oc:"Jasper",rc:"Sugilite",cc:"Veneno de Escorpi\u00e3o",fc:"Tintura de Resist\u00eancia",Zb:"Antidoto",Yb:"Adrenalina",ec:"Tintura Esclarecedora",bc:"Po\u00e7\u00e3o de Perce\u00e7\u00e3o",$b:"Ess\u00eancia de Rea\u00e7\u00e3o",ac:"Frasco de Carisma",hc:"\u00c0guas de Oblivion",dc:"Ess\u00eancia de Alma",od:"Selo Aqu\u00e1tico",hd:"Runa Protetora",fd:"Marca da Terra",nd:"Totem de Cura",md:"Talism\u00e3 do Poder",kd:"Pedra da Fortuna",gd:"Pedernal",ld:"Runa da Tempestade",
jd:"Runa das Sombras",Wc:"Cristal",Vc:"Bronze",$c:"Obsidiana",cd:"Prata",dd:"Enxofre",Yc:"Mina de Ouro",bd:"Quartzo",ad:"Platina",Uc:"Almandin",Xc:"Cuprit",Zc:"Pedra do Inferno",xi:"Atacar Aleatoriamente em Provinciarum?",yi:'Tamb\u00e9m desative a configura\u00e7\u00e3o "Classificar jogadores na arena por n\u00edvel" no crazy-addon.',Ng:"Aceitar apenas miss\u00f5es com base no tipo de deus.",Oa:"Auto Buff",Nd:"Usar apenas no inferno?",ug:"Nova Regra",sg:"Nome Cont\u00e9m",isUnderworldItem:"\u00c9 Item do Submundo",
Ue:"Ignorar Materiais",fk:"Usar Ora\u00e7\u00e3o?",si:"Usar Sacrif\u00edcio?",bk:"Usar Roupas para Entrar no Submundo?",ii:"Miss\u00f5es do Submundo",hi:"Se habilitado, voc\u00ea precisa digitar nomes de itens do submundo. Se o bot encontrar esses itens no submundo, ele aceitar\u00e1 a miss\u00e3o.",Jk:"Item da Miss\u00e3o do Submundo",Tk:"Digite o nome do material",qk:"O bot adora dados! Eles ajudam a encontrar roupas nos ba\u00fas. Mas se n\u00e3o houver dados, o bot abre os ba\u00fas mesmo assim, na esperan\u00e7a de encontrar roupas legais (mas pode n\u00e3o encontrar nenhuma!)",
Bj:"Caixa de saque",be:"Ativar Arena?",Fg:"Priorizar lista de arena?",Gg:"Priorizar lista de circo?",Ud:"Desativar Menu de Log",ah:"Recompensa Min. Valor em Ouro",Og:"Miss\u00e3o Focada, se ativada, seguir\u00e1 o caminho mais curto para terminar a masmorra.",zh:"Jogar Dados Automaticamente?",Ah:"Use jogar dados com cautela, ele continuar\u00e1 usando o primeiro dado at\u00e9 voc\u00ea desativar a op\u00e7\u00e3o.",gh:"Progresso da Pesquisa",Vg:"O tempo de espera para reparo por padr\u00e3o \u00e9 de 10 minutos.",
pg:"Condi\u00e7\u00e3o M\u00ednima",Sd:"Item atual na bancada [Limpar se o bot pausar inesperadamente]",rf:"Recursos da Forja armazenados com sucesso no horreum.",lf:"Verificando itens no mercado...",qb:"Item movido para a bancada.",Gf:"Item reparado e equipado com sucesso.",Hf:"Item reparado com sucesso.",xk:"Reparo falhou. A p\u00e1gina ser\u00e1 atualizada.",Df:"Pegando materiais...",Qf:"Aguardando reparo...",Ff:"Reparo iniciado para .",rb:"Reparo: Movendo o item do invent\u00e1rio para a bolsa",
Ef:"Reparo: Movendo o item da bancada para o pacote.",nf:"N\u00e3o foi poss\u00edvel encontrar materiais suficientes. Desativando o slot de reparo ",Af:"Procurando itens para comprar para esconder ouro no Leil\u00e3o...",hf:"Verificando itens expirados nos pacotes...",jf:"Item redefinido com sucesso.",kf:"Sem Espa\u00e7o Vazio ou Ouro para Redefinir.",sf:"Certifique-se de que voc\u00ea tem direitos de venda no mercado da guilda!",tf:"Ouro insuficiente e/ou nenhum item para comprar. Aguardando 30s para atualizar.",
mb:"Loja foi atualizada.",nb:"Erro durante a cura.",wf:"Sem Rubi ou Pano, desativando as op\u00e7\u00f5es.",xf:"Nenhum item de cura encontrado nos pacotes.",ob:"Nenhum item adequado encontrado",yf:"Alimentos foram pegos. Finalizando o processo.",zf:"Pelo menos um alimento foi pego. Finalizando processo.",pb:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",uf:"Pegando comida dos pacotes.",vf:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",lb:"Sem mais itens de cura. Aguardando 30 segundos.",
kb:"HP Recuperado.",za:"Nada para fazer ent\u00e3o vou rezar!",Mf:"Vou atualizar em 60 segundos para verificar minha sa\u00fade e villa medici.",Nf:"Aguardando Villa Medici, atualizando em 60 segundos.",Of:"Saiu do submundo.",Pf:"Vou atualizar em 60 segundos para verificar minha sa\u00fade.",Bf:"Verificando \u00f3leos de deus...",Cf:"\u00d3leos de deus foram pegos.",xa:"Atacou com sucesso o jogador na ARENA: ",ya:"Atacou com sucesso o jogador no CIRCO: ",ff:"Verificando leil\u00e3o! Por favor, aguarde...",
gf:"Dando lances em itens. Por favor, aguarde...",If:"Item Derretido Automaticamente: ",Jf:"Derretendo Item: ",Kf:"Ouro insuficiente para derreter. Ouro Necess\u00e1rio: ",Lf:"DERRETER: Procurando itens para derreter...",yk:"Procurando itens para derreter...",mf:"Verificando disponibilidade de traje...",qf:"Doado : ",pf:"Jogando dados...",He:"Underworld Farm [Manual, Beta]",Ie:"Esteja ciente: ative este recurso ap\u00f3s desbloquear a criatura que deseja atacar, ela n\u00e3o atacar\u00e1 automaticamente para desbloquear o monstro.",
Ge:"Farm Location",Fe:"Farm Enemy",Gd:"Login Autom\u00e1tico",Hd:"Voc\u00ea precisa permitir pop-ups da tela do lobby do GameForge. Veja a documenta\u00e7\u00e3o sobre como fazer isso.",Cg:"Pausar Bot",Dg:"Pausar Bot em (Minutos)",De:"Data de Expira\u00e7\u00e3o",xg:"Comprar apenas comida?",yg:"Se voc\u00ea habilitar isso, o bot ignorar\u00e1 suas sele\u00e7\u00f5es e comprar\u00e1 comida automaticamente sem inserir nada.",Ab:"M\u00e1ximo de ouro total para gastar",zb:"M\u00e1ximo de ouro por comida para gastar",
wg:"O bot verificar\u00e1 \u00f3leos a cada 60 minutos",Sh:"Define um temporizador para verificar os tempos de fus\u00e3o.",Ph:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver ouro.",Rh:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver o item dispon\u00edvel.",Kh:"Define um temporizador para reparar e verificar seus itens.",Jh:"Define um temporizador para verificar o ouro mantido no mercado da guilda.",Fh:"Define um temporizador para a op\u00e7\u00e3o de reten\u00e7\u00e3o de ouro em leil\u00e3o.",
Bh:"Define um temporizador para verificar a lista de PvP na arena para atacar.",Gh:"Define um temporizador para verificar a lista de PvP no circo para atacar.",Yh:"Define um temporizador para treinar suas estat\u00edsticas.",Mh:"Define um temporizador para redefinir itens expirados.",Wh:"Define um temporizador para armazenar materiais de forja no horreum.",Dh:"Define um temporizador para verificar o leil\u00e3o de gladiadores e mercen\u00e1rios.",Oh:"Define um temporizador para buscar itens em leil\u00e3o e loja.",
Hh:"Define o temporizador para enviar doa\u00e7\u00f5es \u00e0 guilda.",Me:"Ouro Movido",Zd:"N\u00e3o venda itens da lista de fundi\u00e7\u00e3o e leil\u00e3oo",hh:"Automa\u00e7\u00e3o da Loja",jh:"Configura\u00e7\u00f5es de Busca de Item",ih:"Use esta ferramenta para buscar itens. Basta adicionar os itens \u00e0 lista, especificar a quantidade de pano e iniciar a busca.",kh:"Panos a Usar:",lh:"Quantos panos usar?",ia:"Full Digite o Nome do Item",Lb:"Digite o N\u00edvel do Item",nh:"Qualidade do Item",
mh:"Nome do Item Aqui",oh:"Iniciar Busca",ph:"Pular e Continuar",qh:"Parar Busca",Je:"Comprar o mais barato ou o mais caro?",rg:"Mais Caro",Pd:"Mais Barato",fa:"Selecionar uma op\u00e7\u00e3o",de:"Destacar itens do submundo",Ke:"Foco na miss\u00e3o?",El:"Usar Ruby se n\u00e3o houver pano?",Pa:"Evite atacar as mesmas pessoas para n\u00e3o ser reportado. Ser reportado aumenta as chances de ser banido.",tl:"Queimar verde?",Ig:"N\u00e3o aceitar miss\u00f5es aleat\u00f3rias se algum filtro for inserido?",
Gc:"Qualidade m\u00e1xima do material a ser usado",Li:"Ativar a busca mercen\u00e1ria",bl:"Clique em `Vender Todos Selecionados` para vender todos os itens. Certifique-se de ter um espa\u00e7o vazio de 2x3 em sua primeira (1) bolsa. Para coletar ouro em massa, filtre ouro e use `Selecionar Todos ou Selecionar`",Nj:"\ud83d\udd25 : Adiciona item \u00e0 lista de fundi\u00e7\u00e3o.",zi:"\ud83d\udd28 : Adiciona item \u00e0 lista de leil\u00e3o.",tj:"Atualize a loja com pano quando estiver cheia (Voc\u00ea precisa vender novamente depois)",
hj:"P\u00e1gina:",oj:"Parar",mj:"Vender Esta P\u00e1gina",jj:"Selecionar Selecionados",ij:"Selecionar Tudo",pj:"Configura\u00e7\u00f5es de Empacotamento Autom\u00e1tico",nj:"Enviar Recursos",kj:"Vender Todos Selecionados",qa:"Tipo de Item",U:"Armas",M:"Escudos",I:"Armaduras",L:"Capacetes",K:"Luvas",J:"Botas",T:"An\u00e9is",R:"Amuletos",oa:"Utiliz\u00e1veis (Alimentos)",va:"Melhorias",fj:"Potencializadores",sa:"Receitas",ra:"Mercen\u00e1rios",ua:"Ferramentas de Forja",ta:"Pergaminhos",Ga:"Refor\u00e7os",
Fa:"Itens de Evento",ed:"Materiais de Forja",gj:"Ouro",P:"Todos",jl:"Qualidade",wa:"Branco",C:"Verde",B:"Azul",D:"Roxo",G:"Laranja",S:"Vermelho",lj:"Op\u00e7\u00f5es de Venda",Aj:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo?",Si:"Quantos alimentos comprar/pegar?",Gi:"Normal",Fi:"Intermedi\u00e1rio",Ei:"Dif\u00edcil",Da:"Padr\u00e3o",ml:"Reparar Corre\u00e7\u00e3o de Travamento",vk:"Desative a entrada no Inferno se voc\u00ea quiser desabilitar a Dungeon/Circo/Arena. Se voc\u00ea entrar no Inferno manualmente, ser\u00e1 necess\u00e1rio ativar o Modo Inferno.",
Qd:"Escolher traje do submundo",vi:"Vestir traje do submundo quando dispon\u00edvel?",ai:"Define quantas vezes quer treinar as estat\u00edsticas e suas prioridades. O bot n\u00e3o treinar\u00e1 a menos que defina uma prioridade. Se n\u00e3o houver mais estat\u00edsticas ele continuar\u00e1 com as estat\u00edsticas Defenidas.",Qk:"Aventura",rl:"Derreter",xl:"Defini\u00e7\u00f5es de Derreter",Kj:"Itens Derretidos",yl:"Adicione um Prefixo ou Sufixo, uma vez encontrado nos pacotes Ser\u00e1 Derretido automaticamente.:",
wl:"Derreter Item:",Vb:"Clique no item que voc\u00ea deseja consertar. Isto utilizar\u00e1 apenas materiais Padr\u00e3o, Verde e Azul. Voc\u00ea precisa ter pelo menos 10.000 ouro para iniciar o reparo. Abra espa\u00e7o 3x3 em sua PRIMEIRA Bolsa do invent\u00e1rio. Caso contr\u00e1rio, ele poder\u00e1 ficar preso! O bot iniciar\u00e1 o reparo assim que o item tiver durabilidade de %0.",Kk:"Aplicar apenas no Mercenario.",Nk:"O leil\u00e3o s\u00f3 dar\u00e1  o lance quando o mercado estiver no Fim..",
Mk:"Certifique-se de que a SEGUNDA PAGINA DO INVENT\u00c1RIO est\u00e1 vazia e tem 10K de ouro. O bot encontrar\u00e1 e colocar\u00e1 o item na segunda pagina e na pr\u00f3xima vez, a p\u00e1gina, atualiza-se Derrentendo o item. A fundi\u00e7\u00e3o acontecer\u00e1 novamente a cada 5-10 minutos. ",Vi:"Cura & Buffs",nl:"Sem ouro suficiente para fundir. Ouro necess\u00e1rio!:",ql:"Skipping bid: Membro da galian\u00e7a j\u00e1 deu lance no item ",pl:"Skipping bid: J\u00e1 licitei o item ",advanced:"Avan\u00e7ado",
arena:"Arena",ma:"Ataque autom\u00e1tico",Tb:"Evitar Atacar",ka:"Adicionar Jogador",la:"Adicionar Nome do Jogador (Same Server)",Yk:"Parar o Bot se ficar sem comida?",circusTurma:"Circus Turma",Hi:"Dificuldade",dungeon:"Masmorra",Ii:"Configura\u00e7\u00e1o da Masmorra",eventExpedition:"Expedi\u00e7\u00e3o de evento",expedition:"Expedi\u00e7\u00f5es",Mi:"Configura\u00e7\u00e1o de Expedi\u00e7\u00f5es",vj:"Selecionar Monstro",$k:"Maior",Zk:"Coloque as curas na primeira p\u00e1gina do invent\u00e1rio",
tc:"No",xh:"Guardar Ouro",yh:"Guardar ouro no Leil\u00e3o?",Kb:"Selecionar Horas",eh:"Utilizar Roupas para Renovar Iventario?",Ek:"Selecione itens para serem redefinidos",Xg:"Redefinir itens expirados\t",Gb:"Nota: Ao ativar esta op\u00e7\u00e3o, o bot vender\u00e1 os  itens expirados nos Pacotes para o Mercado da Guilda e cancelar\u00e1 para redefinir o tempo de expira\u00e7\u00e3o. Guilda \u00e9 necess\u00e1ria. Certifique-se que tem espa\u00e7o 3x3 vazio no iventario. Nota: Tamb\u00e9m ir\u00e1 coletar as Moedas de Ouro se elas estiverem prestes a expirar!!!",
Eg:"Parar o Bot Aleatoriamente para trabalhar como [Fase de Teste]:",aa:"Ficar com o Ouro: Bot vai guardar esse ouro na bolsa:",dg:"maximo de Ouro: O bot gastar\u00e1 o ouro quando for Superior a",bh:"Ofertas ser\u00e3o aceitas por itens desnecess\u00e1rios",rd:"Adicionar atraso aleat\u00f3rio",sd:"Podes adicionar um atraso para o bot aqui.",Fb:"Reparar",sl:"Derreter apenas Azul?",vl:"Derreter apenas Roxo?",ul:"Derreter apenas Laranja?",Lj:"Derreter tudo no ivent\u00e1rio?",Mj:"Isto ir\u00e1 ignorar a cor e os itens da lista. A pagina 1 est\u00e1 reservada a repara\u00e7\u00e3o..",
th:"Derreter",Ad:"Pesquisa autom\u00e1tica",tg:"Leil\u00e3o Autom\u00e1tico",Bd:"O uso excessivo do Leil\u00e3o pode resultar em banimento. Esse recurso tamb\u00e9m pode desacelerar o bot, pois ele verifica os leil\u00f5es a cada atualiza\u00e7\u00e3o. As licita\u00e7\u00f5es s\u00e3o feitas a cada 5 minutos, a menos que o leil\u00e3o esteja no estado \u201cmuito curto\u201d. Observe que, se voc\u00ea colocar apenas um item na se\u00e7\u00e3o PREFIX, o bot tentar\u00e1 filtrar pelo nome dos itens para licitar mais rapidamente. Embora voc\u00ea precise desativar a licita\u00e7\u00e3o de alimentos para isso.",
dh:"Pesquisar no leil\u00e3o dos gladiadores",fh:"Pesquisar no leil\u00e3o dos mercen\u00e1rios",Jd:"Licitar Comida?",eg:"Lance m\u00e1ximo",Kd:"Licitar se o Tempo for inferior a",Ld:"Itens licitados",kk:"Linguagem do Leil\u00e3o",lk:"De acordo com a atualiza\u00e7\u00e3o 2.5.6, defina o idioma novamente.",vd:"Poder\u00e1 adicionar itens para procurar no mercado e no leil\u00e3o. Tamb\u00e9m mostrar\u00e1 itens roxos no mercado assim que voc\u00ea adicionar um item \u00e0 lista.",ik:"Utilize o leil\u00e3o com cuidado!",
jk:"O lance autom\u00e1tico faz muitas solicita\u00e7\u00f5es ao servidor, causando erro de p\u00e1gina em branco e pode causar banimento se for utilizado com frequ\u00eancia!!",Ug:"Renovar pontos de evento com Rubis?",fe:"Ativar \u00f3leo autom\u00e1tico",nk:"Obter os \u00f3leos sagrados automaticamente",Ak:"Velocidade de verifica\u00e7\u00e3o das miss\u00f5es",La:"Atacar membros da alian\u00e7a?",Ja:'Adicionar Jogador automaticamente \u00e0 lista de "Ataque" quando X OURO for roubado:',Ka:'Adicione Jogadores automaticamente \u00e0 lista "Evitar Ataque" quando perder:',
Jb:"Placar De Ataques",Qb:"Muito Longo",sb:"Longo",Bb:"M\u00e9dio",Nb:"Curto",Rb:"Bastante Curto",gb:"Aceitar Ataques ao Placar:",Hb:"Selecionar Posi\u00e7\u00e3o do ataque",Ib:"O bot ira atacar aleatoriamente jogadores no placar.",ib:"Ataque da Liga",fb:"Ativar ataque da liga:",Db:"Ataque aleat\u00f3rio",Eb:"Atacar do Menor para o maior",hk:"Bot N\u00e3o atacara menbros da alian\u00e7a.",Ce:"Local da Expedi\u00e7\u00e3o:",Cd:"Coletar Bonus automaticamente:",rh:"Ignorar Chefe",ae:"Local da Masmorra:",
$g:"Recome\u00e7ar se perder?",Qe:"Defeni\u00e7\u00f5es do Inferno",Re:" A Personagem entrar\u00e1 no submundo apenas quando o HP for> 90%. Por favor, defina as configura\u00e7\u00f5es de porcentagem de cura na Aba de cura e certifique-se de que a Aba de cura est\u00e1 ativada. Se ao entrar no submundo fizer logout, v\u00e1 para o lobby e ative a caixa de sele\u00e7\u00e3o de login autom\u00e1tico.",Oe:"Dificuldade Do inferno:",Fd:"Entrar automaticamente no inferno / Inferno Mode",pi:"Utilizar Mobiliza\u00e7\u00e3o se pontos = 0",
ui:"Usar Rubies?",ie:"Deixar Inferno se nao tiver pontos?",ci:"O bot tentar\u00e1 usar a Villa Medici primeiro, se voc\u00ea n\u00e3o tiver, ele usar\u00e1 a po\u00e7\u00e3o de cura. N\u00e3o se esque\u00e7a de ativar o bot\u00e3o de Cura!.",ki:"Entrar automaticamente no Inferno ira desabilitar masmorras/arena/Circus.",Ik:"Defeni\u00e7oes de cura no Inferno",ti:"Usar Villa Medici?",ri:"Usar Po\u00e7\u00e3o de Vida?",Rf:"INFO: O bot ir\u00e1 procurar itens no mercado a cada minuto selecionado, o que pode parar o ataque durante a busca.",
ee:"Ativar pesquisa de mercado:",Sf:"Intervalo de pesquisa no mercado:",Tf:"Sugest\u00e3o 10 minutos.",$e:"Defini\u00e7\u00f5es de itens:",Ye:"Nome do item inclui",N:"Pre\u00e7o Maximo",af:"Estilo do Item",Ze:"Raridade do Item",Od:"Comprar Soulbound?",cf:"Itens para comprar",bf:"Tentar comprar itens com pacotes se algum deles corresponde ao pre\u00e7o m\u00e1ximo Defenido.:",Md:"Itens Comprados:",Ti:"Percentagem de Cura",dk:"Comprar comida da Loja?",ek:"Usar cura dos pacotes?",ak:"Usar Cervisia?",
ck:"Usar Ovos?",cl:"Usado por \u00faltimo",location:"Localiza\u00e7\u00e3o",Strength:"For\u00e7a",Dexterity:"Destreza",Agility:"Agilidade",Constitution:"Constitui\u00e7\u00e3o",Charisma:"Carisma",Intelligence:"Inteligencia",Zh:"Defini\u00e7\u00f5es de Treino",$h:"Selecione os atributos que deseja treinar. ir\u00e1 treinar assim que houver ouro suficiente.",Tc:"Proxima A\u00e7\u00e3o",cj:"N\u00e3o",dj:"Normal",hl:"Oponente",il:"Nivel do Oponente",sj:"Miss\u00f5es",random:"aleat\u00f3rio",ol:"Defini\u00e7\u00f5es",
zl:"Brevemente...",type:"Clique nos \u00edcones para ativar os tipos de miss\u00f5es. Selecione os 3 primeiros se quiser se concentrar em Circus & Arena",Gl:"Sim",A:"Procura",pd:"Adicionar item [NOME COMPLETO]",Xj:"Guardar recursos da Forja automaticamente",Bl:"Enviar",al:"Intervalo : ",Rk:"Ativar lance autom\u00e1tico",Sk:"Não cobrir aliados",Dl:"Tutorial",Ub:"MMais jogadores ir\u00e3o por o bot mais lento.",Lk:"Comece adicionando o nome completo dos itens \u00e0 lista. Uma vez adicionado, a ferramenta exibir\u00e1 os resultados da pesquisa \u00e0 esquerda. Isso tamb\u00e9m auxilia nas pesquisas de leil\u00e3o autom\u00e1tico. Com o lance autom\u00e1tico ativado, a ferramenta far\u00e1 pesquisas peri\u00f3dicas com base no intervalo definido. Se o item for encontrado e voc\u00ea tiver fundos suficientes, ele far\u00e1 um lance automaticamente. Nota: Para pesquisar itens exclusivos em lojas, voc\u00ea deve adicionar pelo menos um item \u00e0 lista de pesquisa...",
Uk:"O n\u00famero da criatura pode ser escolhido nos bot\u00f5es acima. O n\u00famero 1 representa a criatura \u00e0 esquerda. Certifique-se de selecionar o local correto, caso contr\u00e1rio o bot poder\u00e1 fazer uma pausa.",Ji:"Escolha a dificuldade da masmorra nas op\u00e7\u00f5es acima. Certifique-se de selecionar o local correto, caso contr\u00e1rio, o bot poder\u00e1 fazer uma pausa.",Ui:"Defini\u00e7\u00f5es de cura",Ki:"Armazene o excesso de ouro na Guilda comprando itens do mercado da Guilda. -> Min. Gold",
dl:"Mover tudo",el:"Mover o Selecionado",Ok:"Curar autom\u00e1ticamente",Pk:"Percentagem da cura",Fl:"Rubi",zg:"Defini\u00e7\u00f5es Gerais",wj:"Vender tudo",xj:"Vender Selecionados",ja:"Armas",ga:"Escudos",W:"Armaduras",Z:"Capacetes",Y:"Luvas",ha:"Sapatos",ea:"Aneis",V:"Amuletos",ni:"Usaveis",mi:"Atualiza\u00e7\u00f5es",Qg:"Receitas",gg:"Mercen\u00e1rios",Sg:"Refor\u00e7os",ge:"Entrar no Submundo se HP >",Pg:"Velocidade de Verifica\u00e7\u00e3o de Miss\u00e3o",Hg:'O padr\u00e3o \u00e9 "3x". Se o bot causar problemas com miss\u00f5es, altere a velocidade da miss\u00e3o de acordo com a velocidade do seu servidor.',
Ne:"Saco de Cura",he:'Se voc\u00ea est\u00e1 renovando pontos manualmente, voc\u00ea precisa clicar no bot\u00e3o acima "Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!',sk:"Voc\u00ea deve ativar pelo menos uma das seguintes op\u00e7\u00f5es: expedi\u00e7\u00e3o, masmorra, arena ou circo para iniciar a Expedi\u00e7\u00e3o de Evento.",Rg:"Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!",cb:"Cobrir Aliados?",Gk:"Deixe todas as configura\u00e7\u00f5es desativadas se desejar fundir usando pacotes que cont\u00eam os itens da lista. No entanto, voc\u00ea ainda pode escolher cores.",
pk:"Personagem(Desligado) / Mercen\u00e1rio(Ligado)",Dk:"Reparar Ambos?",Hk:"Cron\u00f4metros",Timers:"Insira o n\u00famero de minutos para cada cron\u00f4metro abaixo ou deixe-o padr\u00e3o.",Mg:"Ignorar Filtro de Miss\u00e3o",Lg:"Digite palavras-chave para filtrar miss\u00f5es que voc\u00ea n\u00e3o deseja aceitar",X:"Inserir Palavra-chave",H:"Adicionar",Tg:"Remover",Rd:"Limpar",Jg:"Aceitar Filtro de Miss\u00e3o",Kg:"Digite palavras-chave para escolher quais miss\u00f5es aceitar. Usar isso ignorar\u00e1 os tipos de miss\u00e3o",
Ba:"Pular Miss\u00f5es de Tempo?",Bk:"Miss\u00f5es",Dd:"Auto Traje",oi:"Usar Traje?",Id:"Batalha B\u00e1sica",$d:"Batalha em Masmorra",Ed:"O bot s\u00f3 usar\u00e1 Dis Pater Normal e M\u00e9dio se seus pontos de expedi\u00e7\u00e3o/masmorra forem 0.",Pe:"Configura\u00e7\u00f5es de Cura no Inferno",ud:"Atacar Chefe Quando Dispon\u00edvel?",jb:"O ataque \u00e0 Liga ser\u00e1 desativado ap\u00f3s 5 ataques malsucedidos.",Se:"\u00d3leos Sagrados",og:"Nome do Item",da:"N\u00edvel M\u00edn. do Item",Aa:"Qualidade M\u00edn. do Item",
td:"Aplicar/Reiniciar Temporizador",Ve:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo",wi:"Sim",vg:"N\u00e3o",Ha:"Adicionar Prefixo",Ia:"Adicionar Sufixo",Qa:"Limpar Hist\u00f3rico",uh:"Lista de Ignora\u00e7\u00e3o de Fundi\u00e7\u00e3o",Cb:"Prefixo",Ob:"Sufixo",Zg:"Redefinir Itens Expirados",vh:"Fundir Aleatoriamente de Pacotes?",wh:"Guia de Fundi\u00e7\u00e3o",hb:"Extras",yd:"Leil\u00e3o",Xf:"Mercado",Pb:"Temporizadores",Uh:"Fundi\u00e7\u00e3o",Th:"Fundi\u00e7\u00e3o se n\u00e3o houver ouro suficiente",
Qh:"Fundir se n\u00e3o houver item",Ca:"Reparo",Ih:"Manter Ouro no Mercado da Guilda",Eh:"Manter Ouro no Leil\u00e3o",Xh:"Treinamento",Lh:"Redefinir Expirados",Vh:"Loja de Forja",Ch:"Verifica\u00e7\u00e3o de Leil\u00e3o",Nh:"Pesquisa",v:"Habilitar",qg:"Ouro M\u00ednimo",eb:"Doar Ouro para a Guilda",Vd:"Isso doar\u00e1 a cada 5 minutos. Voc\u00ea pode alterar o intervalo na guia de temporizadores",Te:"Quanto deseja doar?",Wd:"Doar quando tiver mais que >",ef:"Menos que <",Wg:"Redefinir Expirados e Outras Configura\u00e7\u00f5es",
Yg:"Redefinir em:",wk:"Mantenha Ctrl (Cmd no Mac) pressionado para selecionar v\u00e1rios itens",We:"Importar/Exportar Configura\u00e7\u00f5es",Ee:"Exportar Configura\u00e7\u00f5es",Xe:"Importar Configura\u00e7\u00f5es",hg:"Mensagem para Todos os Jogadores",ig:"[Requer Chave Ultra Premium, mensagem no Discord para obter a chave.]",jg:"Digite a mensagem a ser enviada",Td:"Para scripts personalizados, entre em contato conosco no Discord",lg:"Enviar",mg:"Mostrar Jogadores",kg:"Selecionar Todos",ng:"Desmarcar Todos",
df:"Certifique-se de que seu invent\u00e1rio tenha espa\u00e7o suficiente. O tempo de recarga \u00e9 de 2 minutos."},Dh={qj:"After expedition points are consumed, travel to Germania to consume Dungeon points",gk:"Kliknij tutaj, je\u015bli naprawa si\u0119 zacina",uk:"Gdy HP spadnie poni\u017cej, u\u017cyj leczenia",Bg:"Cz\u0119\u015bciowa Naprawa",Le:"Pe\u0142na Naprawa",Ag:"Cz\u0119\u015bciowa lub Pe\u0142na Naprawa",ce:"W\u0142\u0105cz Limit",Wi:"Limit",Xi:"Je\u015bli chcesz ograniczy\u0107 liczb\u0119 atak\u00f3w na przeciwnika, w\u0142\u0105cz t\u0119 opcj\u0119 i ustaw limit. Bot b\u0119dzie kontynuowa\u0142 atakowanie reszty przeciwnik\u00f3w po zako\u0144czeniu atak\u00f3w na wybranego potwora.",
Yd:"Nie wchod\u017a do podziemia w kostiumie podziemia",Xd:"Je\u015bli nie chcesz wchodzi\u0107 do podziemia, maj\u0105c na sobie kostium podziemia, w\u0142\u0105cz t\u0119 opcj\u0119",ji:"Podziemia",bi:"Wzmocnienia Podziemi",di:"U\u017cy\u0107 mocy bog\u00f3w po wej\u015bciu do podziemi?",ei:"Wybierz bog\u00f3w, kt\u00f3rych moce chcesz wykorzysta\u0107:",fi:"U\u017cy\u0107 Wzmocnienia Broni na broni?",gi:"U\u017cy\u0107 Wzmocnienia Zbroi na nast\u0119puj\u0105cym ekwipunku?",rk:"Czas odnowienia wynosi 30 minut. Je\u015bli nie masz kostiumu, bot zresetuje czas odnowienia do 0.",
Fk:"Wybierz Kolory",Ra:"Kowad\u0142o Wulkana",Va:"Ziemna Tarcza Feronii",Wa:"P\u0142ynna Moc Neptuna",Xa:"Powietrzna Wolno\u015b\u0107 Aelousa",Ya:"Zab\u00f3jcza Mg\u0142a Plutona",Za:"Oddech \u017bycia Junony",$a:"Pancerz \u0141usek G\u00f3r Gniewu",ab:"Orle Oczy",bb:"Zimowy Str\u00f3j Saturna",Sa:"Bycza Zbroja Bubony",Ta:"Szaty Z\u0142odzieja Merceriusa",Ua:"Szata \u015awiat\u0142a Ra",$f:"Paczki",Uf:"Inwentarz",ca:"Min. Cena",ba:"Ile",xb:"Sprzedaj Przedmioty",wb:"Szukaj w",Wf:"Kolor Materia\u0142u",
Vf:"Kolor Przedmiotu",cg:"Magazyn",yb:"Prze\u0142\u0105cz na Materia\u0142y",bg:"Prze\u0142\u0105cz na Przedmioty",ag:"Sprzedaj Materia\u0142y",tb:"Prosz\u0119 wprowadzi\u0107 poprawn\u0105 nazw\u0119 przedmiotu, zakres cen oraz ilo\u015b\u0107.",ub:"Nie znaleziono odpowiednich przedmiot\u00f3w w wybranych miejscach wyszukiwania.",vb:"Wszystkie przedmioty zosta\u0142y pomy\u015blnie wystawione!",zk:"Wszystkie materia\u0142y zosta\u0142y pomy\u015blnie wystawione!",Yf:"Je\u015bli chcesz sprzeda\u0107 przedmioty za sta\u0142\u0105 cen\u0119, mo\u017cesz wpisa\u0107 t\u0119 sam\u0105 warto\u015b\u0107 dla minimalnej i maksymalnej ceny.",
Zf:"Ta funkcja jest nadal eksperymentalna, u\u017cywaj ostro\u017cnie. Je\u015bli nie ustawisz sta\u0142ej ceny, przedmioty b\u0119d\u0105 wy\u015bwietlane losowo mi\u0119dzy minimaln\u0105 a maksymaln\u0105 cen\u0105, kt\u00f3r\u0105 wpiszesz.",mk:"Ustawia maksymaln\u0105 ilo\u015b\u0107 z\u0142ota, kt\u00f3r\u0105 bot wyda w jednym cyklu.",Ma:"Bot zacznie licytowa\u0107 wszelkie przedmioty \u017cywno\u015bciowe, je\u015bli opcja jest w\u0142\u0105czona. Nie musisz w\u0142\u0105cza\u0107 prze\u0142\u0105cznik\u00f3w gladiatora/najemnika.",
wd:"Bot nie b\u0119dzie licytowa\u0142 ofert sojusznik\u00f3w.",xd:"Ignoruj kombinacj\u0119 Prefixu/Sufiksu podczas szukania przedmiotu na aukcji.",Ej:"Wybierz typy przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Fj:"Wybierz kolory, kt\u00f3re chcesz przetopi\u0107.",Gj:"Wybierz poziom przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Hj:"Wybierz m\u0142ot, kt\u00f3rego chcesz u\u017cy\u0107.",Ij:"Zwr\u00f3\u0107 uwag\u0119, \u017ce zielone i czerwone k\u00f3\u0142ko obok pierwszego pola s\u0142u\u017cy do w\u0142\u0105czania/wy\u0142\u0105czania regu\u0142y.",
Jj:"Je\u015bli chcesz przetapia\u0107 losowo jakiekolwiek kolory lub typy, mo\u017cesz w\u0142\u0105czy\u0107 `Czy przetapia\u0107 losowo, je\u015bli \u017cadne warunki nie s\u0105 spe\u0142nione? (Ostatnia w\u0142\u0105czona opcja w filmie instrukta\u017cowym)",uj:"Napraw przed przetopieniem",ye:"Wybierz Potwora",me:"U\u017cy\u0107 Klepsydry/Rubinu?",tk:"U\u017cy\u0107 Rubinu?",pe:"U\u017cy\u0107 Mobilizacji?",oe:"U\u017cy\u0107 Mikstury \u017bycia?",le:"Procent Leczenia (%)",we:"Liczba Atak\u00f3w",
ne:"Interwa\u0142 Ataku (w sekundach)",je:"Wykonane Ataki",ke:"Pozosta\u0142e Klepsydry",ue:"Uwaga: U\u017cywa mikstur \u017cycia do leczenia, nie jedzenia.",ve:"Uwaga: Je\u015bli ataki zatrzymaj\u0105 si\u0119 przedwcze\u015bnie, spr\u00f3buj 'Zresetuj Ataki'.",ze:"Rozpocznij",xe:"Resetuj",Ae:"Zatrzymaj",Be:"Ustawienia Ekspedycji (Kliknij, aby zminimalizowa\u0107)",qe:"Potw\u00f3r 1",re:"Potw\u00f3r 2",se:"Potw\u00f3r 3",te:"Potw\u00f3r 4",Ck:"Napraw przed przetopieniem",Ci:"Ta opcja u\u017cyje cervisia, gdy twoja subskrypcja premium wyga\u015bnie.",
ej:"Ta opcja w\u0142\u0105cza i wybiera oleje z nagr\u00f3d boskich. Mo\u017ce u\u017cywa\u0107 olej\u00f3w numer 1 i 3 na postaci, ale numer 2 b\u0119dzie tylko zbierany do paczek.",Ai:"Ta opcja u\u017cyje buff\u00f3w o ustawionym przez ciebie czasie. Znajdzie buffy w paczkach i zastosuje je na postaci.",Yi:"Ta opcja wprowadzi ci\u0119 do podziemia. Nie zapomnij w\u0142\u0105czy\u0107 Automatycznego Logowania z zak\u0142adki Dodatki, inaczej mo\u017cesz zosta\u0107 wylogowany przy wej\u015bciu do podziemia [B\u0142\u0105d Gry]",
Sb:"Bot zazwyczaj wybiera losowo od 3 do 6 pr\u00f3b ataku na list\u0119 areny. Je\u015bli w\u0142\u0105czysz t\u0119 opcj\u0119, przejdzie przez twoj\u0105 list\u0119, dop\u00f3ki nie b\u0119dzie m\u00f3g\u0142 kogo\u015b zaatakowa\u0107. To mo\u017ce zaj\u0105\u0107 troch\u0119 czasu.",rj:"Ta opcja jest tylko dla licencji premium. Symuluje atak przed zaatakowaniem u\u017cytkownika dla 75% szansy na wygran\u0105.",zd:"Nie musisz w\u0142\u0105cza\u0107 g\u0142\u00f3wnego prze\u0142\u0105cznika aukcji, aby w\u0142\u0105czy\u0107 t\u0119 opcj\u0119.",
$j:"Ta opcja od\u015bwie\u017cy stron\u0119 co sekund\u0119, gdy aukcja jest w stanie -Bardzo Kr\u00f3tki-, aby nieustannie licytowa\u0107 i wygra\u0107 aukcj\u0119.",Cj:"Je\u015bli \u017caden z warunk\u00f3w wytopu nie zostanie spe\u0142niony, b\u0119dzie wybiera\u0107 losowo. Upewnij si\u0119, \u017ce wybra\u0142e\u015b typ i kolor przedmiotu.",Dj:"Ta opcja b\u0119dzie tylko wytopi\u0107 przedmioty z inwentarza. Zignoruje przedmioty w paczkach.",Na:"Przedmioty na Aukcji",fg:"Przedmioty Najemnika",
Mb:"Przedmioty w Sklepie",li:"Unikalne Przedmioty",yj:"Ustaw t\u0142o na czarne [Zwi\u0119ksza wydajno\u015b\u0107]",zj:"Przenie\u015b przyciski GLDBot do lewego dolnego rogu?",Di:"Atakuj Cyrk Bez Leczenia",Yj:"Czy pobra\u0107 z\u0142oto z paczek, je\u015bli to konieczne?",Zj:"Z\u0142oto zosta\u0142o pobrane z paczek do treningu",Cl:"Nie znaleziono z\u0142ota w paczkach do treningu",Vj:"Naprawione Przedmioty",Oj:"Ataki na Arenie",Qj:"Ataki w Cyrku",qd:"Zresetowane Przedmioty",Tj:"Ataki na Wyprawach",
Sj:"Ataki w Lochach",Wj:"Ataki w Podziemiach",Pj:"Pieni\u0105dze Zarobione na Arenie",Rj:"Pieni\u0105dze Zarobione w Cyrku",Al:"Przedmioty Przetopione",Uj:"Przetopione Z\u0142oto",Pi:"Bitwa Gildii",Ri:"Ustawienia Gildii",Wk:"B\u0119dzie atakowa\u0107 gildie losowo.",Qi:"Nazwa Gildii",Bi:"Zresetuj Statystyki",Oi:"Atakuj losowo?",gl:"GLDBot: U\u017cyj kostek, aby od\u015bwie\u017cy\u0107 tajemnicze pude\u0142ko i znale\u017a\u0107 cenne przedmioty przed ich otwarciem (itp. Kostiumy). Kliknij \u201eStart\u201d otw\u00f3rz skrzynie.",
Ec:"Drewno",uc:"Mied\u017a",yc:"\u017belazo",Ac:"Sk\u00f3ra",Fc:"We\u0142niana nitka",vc:"Bawe\u0142na",xc:"Konopie",wc:"Kawa\u0142ek tkaniny",Bc:"Kawa\u0142ek w\u0142\u00f3kna lnianego",zc:"\u0141ata z juty",Dc:"Pasek aksamitu",Cc:"Jedwabna nitka",Nc:"Futro",Hc:"Od\u0142amek ko\u015bci",Qc:"\u0141uska",Kc:"Pazur",Mc:"Kie\u0142",Lc:"Smocza \u0142uska",Ic:"R\u00f3g byka",Pc:"Gruczo\u0142 jadowy",Jc:"Kawa\u0142ek futra Cerbera",Oc:"\u0141uska Hydry",Rc:"Pi\u00f3ro Sfinksa",Sc:"Sk\u00f3ra Tyfona",pc:"Lazuryt",
jc:"Ametyst",ic:"Bursztyn",kc:"Akwamaryn",qc:"Szafir",nc:"Granat",mc:"Szmaragd",lc:"Diament",oc:"Jaspis",rc:"Sugilit",cc:"Jad skorpiona",fc:"Eliksir wytrwa\u0142o\u015bci",Zb:"Antidotum",Yb:"Adrenalina",ec:"Eliksir o\u015bwiecenia",bc:"Nap\u00f3j postrzegania",$b:"Esencja refleksu",ac:"Fiolka Charyzmy",hc:"Woda zapomnienia",dc:"Esencja duszy",od:"Wodna piecz\u0119\u0107",hd:"Runa ochrony",fd:"Ziemny grawerunek",nd:"\u015awi\u0119ty totem",md:"Talizman mocy",kd:"Kamie\u0144 szcz\u0119\u015bcia",gd:"Krzemie\u0144",
ld:"Runa wichury",jd:"Runa cienia",Wc:"Kryszta\u0142",Vc:"Br\u0105z",$c:"Obsydian",cd:"Srebro",dd:"Siarka",Yc:"Ruda z\u0142ota",bd:"Kwarc",ad:"Platina",Uc:"Almandyn",Xc:"Kupryt",Zc:"Piekielny kamie\u0144",xi:"Atakuj losowo?",yi:'Wy\u0142\u0105cz r\u00f3wnie\u017c ustawienie "Sortuj graczy na arenie wed\u0142ug poziomu" w crazy-addon.',Ng:"Akceptuj tylko misje na podstawie typu boga.",Oa:"Automatyczny Buff",Nd:"U\u017cywaj tylko w piekle?",ug:"Nowa Zasada",sg:"Nazwa Zawiera",isUnderworldItem:"Czy to przedmiot z Podziemi",
Ue:"Ignoruj Materia\u0142y",fk:"U\u017cyj modlitwy",si:"U\u017cyj ofiary",bk:"U\u017cyj tkaniny, aby wej\u015b\u0107 do podziemia",ii:"Czy w podziemiach akceptowa\u0107 tylko zadania zwi\u0105zane z podziemiami?",hi:"Je\u015bli w\u0142\u0105czone, musisz wprowadzi\u0107 nazwy przedmiot\u00f3w z podziemi. Je\u015bli bot znajdzie te przedmioty w podziemiach, zaakceptuje zadanie.",Jk:"Przedmiot zadania z podziemi",Tk:"Wprowad\u017a nazw\u0119 materia\u0142u",qk:"Bot uwielbia ko\u015bci! Pomagaj\u0105 znale\u017a\u0107 ubrania w skrzyniach. Ale je\u015bli nie ma ko\u015bci, bot i tak otwiera skrzynie, licz\u0105c na fajne ciuchy (ale mo\u017ce ich nie znale\u017a\u0107!)",
Bj:"Czy chcesz przetopi\u0107 skrzynki?",be:"W\u0142\u0105cz automatyczne ataki na arenie?",Fg:"Priorytetowa lista aren?",Gg:"Priorytetowa lista cyrk\u00f3w?",Ud:"Wy\u0142\u0105cz menu dziennika",ah:"Minimalna warto\u015b\u0107 nagrody z\u0142ota",Og:"Je\u015bli w\u0142\u0105czone, Fokus na zadaniach b\u0119dzie pod\u0105\u017ca\u0142 najkr\u00f3tsz\u0105 drog\u0105 do uko\u0144czenia lochu.",zh:"Automatyczne rzucanie kostk\u0105?",Ah:"U\u017cywaj rzucania kostk\u0105 ostro\u017cnie, b\u0119dzie ono nadal u\u017cywa\u0107 pierwszej kostki, dop\u00f3ki nie wy\u0142\u0105czysz opcji.",
gh:"Post\u0119p w wyszukiwaniu",Vg:"Czas odnowienia naprawy domy\u015blnie wynosi 10 minut.",pg:"Minimalny stan",Sd:"Obecny przedmiot na warsztacie [Wyczy\u015b\u0107, je\u015bli bot nagle zostanie zatrzymany]",rf:"Pomy\u015blnie przechowywano zasoby do horreum.",lf:"Sprawdzanie rynku na przedmioty...",qb:"Przedmiot przeniesiony na warsztat.",Gf:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony i za\u0142o\u017cony.",Hf:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony.",xk:"Naprawa nie powiod\u0142a si\u0119. Strona zostanie od\u015bwie\u017cona.",
Df:"Podnoszenie materia\u0142\u00f3w...",Qf:"Oczekiwanie na napraw\u0119...",Ff:"Naprawa rozpocz\u0119\u0142a si\u0119 dla .",rb:"Naprawa: Przenoszenie przedmiotu z inwentarza do torby",Ef:"Naprawa: Przenoszenie przedmiotu z warsztatu do paczki.",nf:"Nie uda\u0142o si\u0119 znale\u017a\u0107 wystarczaj\u0105cej ilo\u015bci materia\u0142\u00f3w. Wy\u0142\u0105czanie slotu naprawy ",Af:"Szukanie przedmiot\u00f3w do kupienia w celu ukrycia z\u0142ota na Aukcji...",hf:"Sprawdzanie wygas\u0142ych przedmiot\u00f3w w paczkach...",
jf:"Przedmiot zosta\u0142 pomy\u015blnie zresetowany.",kf:"Brak pustej przestrzeni lub z\u0142ota do zresetowania.",sf:"Upewnij si\u0119, \u017ce masz prawa do sprzeda\u017cy na rynku gildii!",tf:"Brak wystarczaj\u0105cej ilo\u015bci z\u0142ota/lub brak przedmiotu do kupienia. Oczekiwanie 30 sekund na od\u015bwie\u017cenie.",mb:"Sklep zosta\u0142 od\u015bwie\u017cony.",nb:"B\u0142\u0105d podczas leczenia.",wf:"Brak Rubina lub Materia\u0142u, wy\u0142\u0105czanie opcji.",xf:"Brak przedmiotu do leczenia w paczkach.",
ob:"Nie znaleziono odpowiednich przedmiot\u00f3w",yf:"\u017bywno\u015b\u0107 zosta\u0142a wybrana. Zako\u0144czenie procesu.",zf:"Wybrano przynajmniej jedzenie. Proces zako\u0144czony.",pb:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",uf:"Pobieranie jedzenia z paczek.",vf:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",lb:"Brak wi\u0119cej przedmiot\u00f3w do leczenia. Oczekiwanie 30 sekund.",kb:"Odzyskano punkty \u017cycia.",za:"Nie ma nic do roboty, wi\u0119c id\u0119 si\u0119 pomodli\u0107!",
Mf:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie i Vill\u0119 Medici.",Nf:"Oczekiwanie na Vill\u0119 Medici, od\u015bwie\u017canie za 60 sekund.",Of:"Opuszczono za\u015bwiaty.",Pf:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie.",Bf:"Sprawdzanie olejk\u00f3w bo\u017cych...",Cf:"Olejki bo\u017ce zosta\u0142y podniesione.",xa:"Pomy\u015blnie zaatakowano gracza na ARENIE: ",ya:"Pomy\u015blnie zaatakowano gracza w CIRKUSIE: ",ff:"Sprawdzanie aukcji! Prosz\u0119 czeka\u0107...",
gf:"Licytacja przedmiot\u00f3w. Prosz\u0119 czeka\u0107...",If:"Automatycznie przetopiony przedmiot: ",Jf:"Przetapiany przedmiot: ",Kf:"Nie ma wystarczaj\u0105cej ilo\u015bci z\u0142ota do przetopienia. Wymagane z\u0142oto: ",Lf:"PRZETAP: Szukanie przedmiot\u00f3w do przetopienia...",yk:"Szukanie przedmiot\u00f3w do przetopienia...",mf:"Sprawdzanie dost\u0119pno\u015bci kostium\u00f3w...",qf:"Wys\u0142ano datek: ",pf:"Rzucanie kostk\u0105...",He:"Underworld Farm [Manual, Beta]",Ge:"Farm Location",
Ie:"Uwaga: w\u0142\u0105cz t\u0119 funkcj\u0119 po odblokowaniu stworzenia, kt\u00f3re chcesz zaatakowa\u0107, nie b\u0119dzie ono automatycznie atakowa\u0107, aby odblokowa\u0107 potwora.",Fe:"Farm Enemy",Gd:"Automatyczne Logowanie",Hd:"Musisz zezwoli\u0107 na wyskakuj\u0105ce okienka z ekranu lobby GameForge. Zobacz dokumentacj\u0119, jak to zrobi\u0107.",Cg:"Wstrzymaj Bota",Dg:"Wstrzymaj Bota na (Minuty)",De:"Data Wyga\u015bni\u0119cia",xg:"Tylko kupowa\u0107 jedzenie?",yg:"Je\u015bli to w\u0142\u0105czysz, zignoruje twoje wybory i b\u0119dzie automatycznie kupowa\u0107 jedzenie, nie wprowadzaj\u0105c niczego.",
Ab:"Maksymalna \u0142\u0105czna ilo\u015b\u0107 z\u0142ota do wydania",zb:"Maksymalna ilo\u015b\u0107 z\u0142ota na jedzenie do wydania",wg:"Bot b\u0119dzie sprawdza\u0107 oleje co 60 minut",Sh:"Ustawia timer do sprawdzania czas\u00f3w topienia.",Ph:"Ustawia timer do sprawdzania topienia, gdy nie masz z\u0142ota.",Rh:"Ustawia timer do sprawdzania topienia, gdy nie masz dost\u0119pnego przedmiotu.",Kh:"Ustawia timer do naprawy i sprawdzania twoich przedmiot\u00f3w.",Jh:"Ustawia timer do sprawdzania ilo\u015bci z\u0142ota w gildijnym rynku.",
Fh:"Ustawia timer dla opcji zatrzymania z\u0142ota na aukcji.",Bh:"Ustawia timer do sprawdzania listy PvP na arenie do ataku.",Gh:"Ustawia timer do sprawdzania listy PvP w cyrku do ataku.",Yh:"Ustawia timer treningowy do trenowania statystyk.",Mh:"Ustawia timer do resetowania wygas\u0142ych przedmiot\u00f3w.",Wh:"Ustawia timer do przechowywania materia\u0142\u00f3w do kucia w horreum.",Dh:"Ustawia timer do sprawdzania aukcji gladiator\u00f3w i najemnik\u00f3w.",Oh:"Ustawia timer do wyszukiwania przedmiot\u00f3w na aukcji i w sklepie.",
Hh:"Ustawia timer do wysy\u0142ania darowizn do gildii.",Me:"Z\u0142oto Przeniesione",Zd:"Nie sprzedawaj przedmiot\u00f3w z listy hutniczej i aukcyjnej",hh:"Automatyzacja Sklepu",jh:"Ustawienia Wyszukiwania Przedmiotu",ih:"U\u017cyj tego narz\u0119dzia do wyszukiwania przedmiot\u00f3w. Po prostu dodaj przedmioty do listy, okre\u015bl ilo\u015b\u0107 tkaniny i rozpocznij wyszukiwanie.",kh:"Ilo\u015b\u0107 Tkaniny do U\u017cycia:",lh:"Ile tkaniny u\u017cy\u0107?",ia:"Full Wprowad\u017a Nazw\u0119 Przedmiotu",
Lb:"Wprowad\u017a Poziom Przedmiotu",nh:"Jako\u015b\u0107 Przedmiotu",mh:"Wprowad\u017a Nazw\u0119 Przedmiotu Tutaj",oh:"Rozpocznij Wyszukiwanie",ph:"Pomi\u0144 i Kontynuuj",qh:"Zatrzymaj Wyszukiwanie",Je:"Kupi\u0107 najta\u0144sze czy najdro\u017csze?",rg:"Najdro\u017csze",Pd:"Najta\u0144sze",fa:"Wybierz Opcj\u0119",de:"Pod\u015bwietl przedmioty z Podziemia",Ke:"Skoncentruj si\u0119 na zadaniu?",El:"U\u017cyj rubinu, je\u015bli nie ma tkaniny?",Pa:"Unikaj atakowania tych samych os\u00f3b, aby unikn\u0105\u0107 zg\u0142osze\u0144. Zg\u0142oszenia zwi\u0119kszaj\u0105 szans\u0119 na zablokowanie konta.",
tl:"Roztopi\u0107 zielone?",Ig:"Nie akceptuj losowych zada\u0144, je\u015bli wprowadzono jakiekolwiek filtry?",Gc:"Maksymalna jako\u015b\u0107 materia\u0142u do u\u017cycia",Li:"W\u0142\u0105czy\u0107 wyszukiwanie najemnik\u00f3w",bl:"Kliknij \u201eSprzedaj Wszystkie Wybrane\u201d, aby sprzeda\u0107 wszystkie przedmioty. Upewnij si\u0119, \u017ce masz 2x3 puste miejsce w swojej pierwszej (1) torbie. Aby zbiera\u0107 z\u0142oto masowo, u\u017cyj filtra na z\u0142oto i opcji \u201eWybierz Wybrane lub Wybierz Wszystkie\u201d.",
Nj:"\ud83d\udd25 : Dodaje przedmiot do listy przetapiania.",zi:"\ud83d\udd28 : Dodaje przedmiot do listy aukcyjnej.",tj:"Od\u015bwie\u017c sklep tkanin\u0105, gdy jest pe\u0142ny (musisz ponownie sprzeda\u0107 po tym)",hj:"Strona:",oj:"Zatrzymaj",mj:"Sprzedaj T\u0119 Stron\u0119",jj:"Wybierz Wybrane",ij:"Wybierz Wszystko",pj:"Ustawienia Automatycznego Pakowania",nj:"Wy\u015blij Zasoby",kj:"Sprzedaj Wszystkie Wybrane",qa:"Rodzaj Przedmiotu",U:"Bronie",M:"Tarcze",I:"Zbroje",L:"He\u0142my",K:"R\u0119kawice",
J:"Buty",T:"Pier\u015bcienie",R:"Amulety",oa:"U\u017cytkowe (\u017bywno\u015b\u0107)",va:"Ulepszenia",fj:"Wzmacniacze",sa:"Receptury",ra:"Najemnicy",ua:"Narz\u0119dzia Kowalskie",ta:"Zwoje",Ga:"Wzmocnienia",Fa:"Przedmioty Eventowe",ed:"Materia\u0142y Kowalskie",gj:"Z\u0142oto",P:"Wszystko",jl:"Jako\u015b\u0107",wa:"Bia\u0142y",C:"Zielony",B:"Niebieski",D:"Fioletowy",G:"Pomara\u0144czowy",S:"Czerwony",lj:"Opcje Sprzeda\u017cy",Aj:"Ignorowa\u0107 Kombinacje Przedrostk\u00f3w/Sufiks\u00f3w?",Si:"Ile jedzenia kupi\u0107/wybiera\u0107?",
Gi:"Normalny",Fi:"\u015aredni",Ei:"Trudny",Da:"Standardowy",ml:"Naprawa Utkni\u0119\u0107",vk:"Wy\u0142\u0105cz Wej\u015bcie do Piek\u0142a, je\u015bli chcesz wy\u0142\u0105czy\u0107 Lochy/Cyrk/Aren\u0119. Je\u015bli wszed\u0142e\u015b do Piek\u0142a r\u0119cznie, musisz w\u0142\u0105czy\u0107 Tryb Piek\u0142a.",ai:"Okre\u015bl, ile razy chcesz przeprowadzi\u0107 szkolenia dla statystyk oraz ich priorytety. Bot nie b\u0119dzie przeprowadza\u0142 szkole\u0144, dop\u00f3ki nie zostanie ustalony priorytet. Je\u015bli priorytet zosta\u0142 ustawiony, ale nie ma ju\u017c wi\u0119cej statystyk do szkolenia, bot kontynuowa\u0107 b\u0119dzie z priorytetowym szkoleniem.",
Qk:"Quest",Qd:"Wybierz kostium z Za\u015bwiat\u00f3w",vi:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",rl:"Przetapianie",xl:"Ustawienia Topienia",Kj:"Topione Przedmioty",yl:"Dodaj Prefiks lub Sufiks, gdy bot znajdzie go w paczkach, automatycznie przeprowadzi przetapianie.:",wl:"Topiony Przedmiot:",Vb:"Kliknij na przedmiot, kt\u00f3ry chcesz naprawi\u0107. Ten system naprawi twoje dwie postacie, g\u0142\u00f3wn\u0105 oraz pierwsz\u0105 posta\u0107 cyrku. Musisz mie\u0107 co najmniej 10000 z\u0142ota, aby naprawa mog\u0142a si\u0119 rozpocz\u0105\u0107. Je\u015bli utkn\u0105\u0142 na jednym przedmiocie, oznacza to, \u017ce nie masz materia\u0142u do naprawy. Spr\u00f3buj r\u00f3wnie\u017c zrobi\u0107 troch\u0119 miejsca w swoim inwentarzu. Bot rozpocznie napraw\u0119, gdy trwa\u0142o\u015b\u0107 przedmiotu wynosi 0%.",
Kk:"Zastosuj tylko do Najemnik\u00f3w",Nk:"Licytacja b\u0119dzie licytowa\u0107 tylko wtedy, gdy rynek zbli\u017cy si\u0119 do ko\u0144ca.",Mk:"Upewnij si\u0119, \u017ce DRUGA KARTA INWENTARZA jest pusta i masz 10 000 z\u0142ota. Bot znajdzie i umie\u015bci przedmiot na drugiej karcie, a nast\u0119pnie, gdy strona zostanie od\u015bwie\u017cona, przeprowadzi przetapianie przedmiotu. przetapianie b\u0119dzie ponownie sprawdzane co 5-10 minut.",Vi:"Leczenie & Buffs",nl:"Za ma\u0142o z\u0142ota na przetapianie. Wymagane Z\u0142oto:",
ql:"Pomijanie licytacji: Cz\u0142onek gildii ju\u017c licytowa\u0142 przedmiot ",pl:"Pomijanie licytacji: Ju\u017c licytowa\u0142e\u015b przedmiot ",advanced:"Zaawansowane",arena:"Arena",ma:"Auto Atak",Tb:"Unikaj Ataku",ka:"Dodaj Gracza",la:"Wpisz Nazw\u0119 Gracza (Same Server)",Yk:"Zatrzymaj Bota, je\u015bli brakuje jedzenia?",circusTurma:"Cyrk Turma",Hi:"Trudno\u015b\u0107",dungeon:"Loch",Ii:"Ustawienia Lochu",eventExpedition:"Ekspedycja Wydarzenia",expedition:"Wyprawa",Mi:"Ustawienia Wyprawy",
vj:"Wybierz Potwora",$k:"Najwy\u017cszy",Zk:"Umie\u015b\u0107 swoje przedmioty uzdrawiaj\u0105ce na pierwszej stronie swojego inwentarza",tc:"W",xh:"Przechowuj Z\u0142oto",yh:"Przechowuj Z\u0142oto w Licytacji?",Kb:"Wybierz Godzin\u0119",eh:"U\u017cyj Roboczych Ubran, aby odnowi\u0107 Sklep?",Ek:"Wybierz Przedmioty do Zresetowania",Xg:"Zresetuj Wygas\u0142e Przedmioty",Gb:"Uwaga: W\u0142\u0105czaj\u0105c t\u0119 opcj\u0119, bot b\u0119dzie sprzedawa\u0142 nadchodz\u0105ce wygas\u0142e przedmioty z Paczek na Rynek Gildii, a nast\u0119pnie anuluje, aby zresetowa\u0107 czas wyga\u015bni\u0119cia. Wymagana jest gildia. Upewnij si\u0119, \u017ce masz puste miejsce 3x3 w swoich torbach.",
Eg:"Losowe Zatrzymywanie Bota [Faza Testowa]:",aa:"Zachowaj Z\u0142oto: Bot b\u0119dzie trzyma\u0142 to z\u0142oto w torbie:",dg:"Max Gold: Bot b\u0119dzie wydawa\u0142, gdy z\u0142oto b\u0119dzie wi\u0119ksze ni\u017c",bh:"Bot b\u0119dzie sk\u0142ada\u0142 oferty na losowe przedmioty.",rd:"Dodaj Losowe Op\u00f3\u017anienie",sd:"Mo\u017cesz tutaj doda\u0107 op\u00f3\u017anienie do bota.",Fb:"Naprawa",sl:"Top Tylko Niebieskie?",vl:"Top Tylko Fioletowe?",ul:"Top Tylko Pomara\u0144czowe?",Lj:"Top Wszystko na 2. karcie?",
Mj:"To zignoruje wyb\u00f3r kolor\u00f3w",Qa:"Wyczy\u015b\u0107 Histori\u0119",th:"Przetapianie",Ad:"Search",tg:"Auto Licytacja",Bd:"Nadmierne korzystanie z aukcji mo\u017ce skutkowa\u0107 banem. Zaleca si\u0119 wy\u0142\u0105czenie innych funkcji okre\u015blania stawek, aby unikn\u0105\u0107 potencjalnych konflikt\u00f3w. Ta funkcja spowolni bota.",dh:"Szukaj w Licytacji Gladiator\u00f3w",fh:"Szukaj w Licytacji Najemnik\u00f3w",Jd:"Licytuj Po\u017cywienie?",eg:"Maksymalna Licytacja",Kd:"Licytuj, je\u015bli status jest mniejszy ni\u017c",
Ld:"Wystawione Przedmioty",kk:"J\u0119zyk Licytacji",lk:"Zgodnie z aktualizacj\u0105 2.9.4, prosz\u0119 ponownie ustawi\u0107 j\u0119zyk lub ZRESETOWA\u0106 BOTA. Upewnij si\u0119, \u017ce wszystko jest poprawne, w przeciwnym razie bot nie b\u0119dzie licytowa\u0107.",vd:"Mo\u017cesz doda\u0107 przedmioty do wyszukiwania na rynku i w licytacji. Poka\u017ce tak\u017ce fioletowe przedmioty na rynku, gdy dodasz przedmiot do listy. Je\u015bli chcesz w\u0142\u0105czy\u0107 auto licytacj\u0119, u\u017cyj opcji poni\u017cej",
ik:"U\u017cywaj licytacji z rozwag\u0105!",jk:"Automatyczna licytacja generuje zbyt wiele \u017c\u0105da\u0144 do serwera i mo\u017ce spowodowa\u0107 ban, je\u015bli u\u017cywasz jej ca\u0142y czas!",Ug:"Odnowi\u0107 Punkty Wydarzenia Rubinem?",fe:"W\u0142\u0105cz Auto Olej",nk:"Auto Pobieraj \u015awi\u0119te Oleje",Ak:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",La:"Atakowa\u0107 Cz\u0142onk\u00f3w Gildii?",Ja:'Automatycznie dodawaj osoby do listy "Atak", gdy wi\u0119cej ni\u017c X z\u0142ota zostanie skradzione.:',
Ka:'Automatycznie dodawaj osoby do listy "Unikaj Atak", gdy przegrasz z nimi.:',Jb:"Ataki na Tablicy Wynik\u00f3w",Qb:"Bardzo D\u0142ugo",sb:"D\u0142ugo",Bb:"\u015arednio",Nb:"Kr\u00f3tko",Rb:"Bardzo Kr\u00f3tko",ge:"Wejd\u017a do Podziemia je\u015bli HP >",Pg:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Hg:'Domy\u015blnie to "3x". Je\u015bli bot sprawia problemy z zadaniami, zmie\u0144 szybko\u015b\u0107 zada\u0144 zgodnie ze szybko\u015bci\u0105 serwera.',Ne:"Wyb\u00f3r Worka z Lecznicami",he:'Je\u015bli r\u0119cznie odnawiasz punkty, musisz klikn\u0105\u0107 przycisk powy\u017cej: "Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!"',
sk:"Musisz w\u0142\u0105czy\u0107 co najmniej jedn\u0105 z opcji: ekspedycja, loch, arena lub cyrk, aby rozpocz\u0105\u0107 Ekspedycj\u0119 Eventow\u0105.",Rg:"Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!",cb:"Nie przebijaj gildii?",Gk:"Pozostaw wszystkie ustawienia wy\u0142\u0105czone, je\u015bli chcesz przetapia\u0107 za pomoc\u0105 paczek zawieraj\u0105cych przedmioty z listy. Jednak nadal mo\u017cesz wybiera\u0107 kolory.",pk:"Posta\u0107(Wy\u0142\u0105czona) / Najemnik(W\u0142\u0105czony)",
Dk:"Naprawi\u0107 Obie?",Hk:"Timery",Timers:"Wprowad\u017a liczb\u0119 minut dla ka\u017cdego timera poni\u017cej lub pozostaw domy\u015blnie.",Mg:"Ignoruj Filtr Zada\u0144",Lg:"Wprowad\u017a s\u0142owa kluczowe, aby odfiltrowa\u0107 zadania, kt\u00f3rych nie chcesz przyj\u0105\u0107. You can also use this to accept quests by their reward using keywords.",X:"Wprowad\u017a S\u0142owo Kluczowe",H:"Dodaj",Tg:"Usu\u0144",Rd:"Wyczy\u015b\u0107",Jg:"Akceptuj Filtr Zada\u0144",Kg:"Wprowad\u017a s\u0142owa kluczowe, aby wybra\u0107 zadania do przyj\u0119cia. U\u017cycie tego spowoduje ignorowanie rodzaj\u00f3w zada\u0144",
Ba:"Pomi\u0144 Zadania Czasowe?",Bk:"Zadania",Dd:"Automatyczny Kostium",oi:"U\u017cywa\u0107 Kostiumu?",Id:"Podstawowa Bitwa",$d:"Bitwa w Lochach",Ed:"Bot b\u0119dzie nosi\u0142 Dis Pater Normal i Medium tylko wtedy, gdy Twoje punkty ekspedycji/podziemi wynosz\u0105 0.",Pe:"Ustawienia Piekielnego Leczenia",ud:"Atakuj Bossa, Gdy Dost\u0119pny?",jb:"Atak na Lig\u0119 zostanie wy\u0142\u0105czony po 5 nieudanych atakach.",Se:"\u015awi\u0119te Oleje",og:"Nazwa Przedmiotu",da:"Minimalny Poziom Przedmiotu",
Aa:"Minimalna Jako\u015b\u0107 Przedmiotu",td:"Zastosuj/Resetuj Licznik",Ve:"Ignoruj Prefiks/Sufiks",wi:"Tak",vg:"Nie",Ha:"Dodaj Prefiks",Ia:"Dodaj Sufiks",uh:"Lista Ignorowanych Przedmiot\u00f3w do Topienia",Cb:"Prefiks",Ob:"Sufiks",Zg:"Resetuj Wygas\u0142e Przedmioty",vh:"Losowe Topienie z Paczek?",wh:"Karta Topienia",hb:"Dodatki",yd:"Aukcja",Xf:"Rynek",Pb:"Zegary",Uh:"Topienie",Th:"Topienie, je\u015bli brakuje z\u0142ota",Qh:"Topienie, je\u015bli brakuje przedmiotu",Ca:"Naprawa",Ih:"Przechowuj Z\u0142oto na Rynku Gildii",
Eh:"Przechowuj Z\u0142oto na Aukcji",Xh:"Trening",Lh:"Resetuj Wygas\u0142e",Vh:"Przechowuj W Ku\u017ani",Ch:"Sprawd\u017a Aukcj\u0119",Nh:"Szukaj",v:"W\u0142\u0105cz",qg:"Minimalne Z\u0142oto",eb:"Wp\u0142acaj Z\u0142oto do Gildii",Vd:"B\u0119dzie wp\u0142aca\u0107 co 5 minut. Mo\u017cesz zmieni\u0107 interwa\u0142 w zak\u0142adce zegar\u00f3w",Te:"Ile chcesz wp\u0142aci\u0107?",Wd:"Wp\u0142aca\u0107, gdy masz wi\u0119cej ni\u017c >",ef:"Mniej ni\u017c <",Wg:"Resetuj Wygas\u0142e i Inne Ustawienia",
Yg:"Reset za:",wk:"Naci\u015bnij Ctrl (Cmd na Macu), aby zaznaczy\u0107 wiele przedmiot\u00f3w",We:"Importuj/Eksportuj Ustawienia",Ee:"Eksportuj Ustawienia",Xe:"Importuj Ustawienia",hg:"Wiadomo\u015b\u0107 do Wszystkich Graczy",ig:"[Wymaga Klucza Ultra Premium, wiadomo\u015b\u0107 na Discordzie, aby go otrzyma\u0107.]",jg:"Wprowad\u017a wiadomo\u015b\u0107 do wys\u0142ania",Td:"Aby uzyska\u0107 niestandardowe skrypty, skontaktuj si\u0119 z nami na Discordzie",lg:"Wy\u015blij",mg:"Poka\u017c Graczy",
kg:"Zaznacz Wszystkie",ng:"Odznacz Wszystkie",df:"Upewnij si\u0119, \u017ce tw\u00f3j inwentarz ma wystarczaj\u0105co du\u017co miejsca. Czas odnowienia wynosi 2 minuty.",gb:"W\u0142\u0105cz Atak na Tablicy Wynik\u00f3w:",Hb:"Wybierz Zakres Ataku",Ib:"Bot losowo atakuje z listy tablicy wynik\u00f3w.",ib:"Atak Ligi",fb:"W\u0142\u0105cz Atak Ligi:",Db:"Losowo Atakuj",Eb:"Atakuj od najs\u0142abszego do najsilniejszego",hk:"Domy\u015blnie bot unika atakowania cz\u0142onk\u00f3w gildii.",Ce:"Lokalizacja Wyprawy:",
Cd:"Auto Zbieraj Bonusy:",rh:"Pomi\u0144 Bossa",ae:"Lokalizacja Lochu:",$g:"Zresetowa\u0107, je\u015bli przegrasz?",Qe:"Ustawienia Piek\u0142a",Re:"Skonfiguruj ustawienia procentu leczenia w zak\u0142adce leczenia i upewnij si\u0119, \u017ce zak\u0142adka leczenia jest aktywowana. Je\u015bli wej\u015bcie do podziemi wyrzuca ci\u0119 z gry, przejd\u017a do lobby i zaznacz pole wyboru automatycznego logowania.",Oe:"Trudno\u015b\u0107 Piek\u0142a",Fd:"Auto Wej\u015bcie do Piek\u0142a: / Piek\u0142a Mode",
pi:"U\u017cyj Mobilizacji, je\u015bli punkty = 0",ui:"U\u017cyj rubin\u00f3w?",ie:"Wyj\u015b\u0107 z podziemi, je\u015bli nie ma punkt\u00f3w?",ci:"Bot b\u0119dzie pr\u00f3bowa\u0142 u\u017cy\u0107 willi medici najpierw, je\u015bli jej nie masz, u\u017cyje mikstury uzdrawiania. Nie zapomnij w\u0142\u0105czy\u0107 prze\u0142\u0105cznika uzdrawiania.",ki:"Automatyczne wej\u015bcie do piek\u0142a wy\u0142\u0105czy loch/aren\u0119/cyrk po wej\u015bciu do piek\u0142a.",Ik:"Ustawienia Leczenia Piek\u0142a",
ti:"U\u017cyj Willi Medici?",ri:"U\u017cyj Mikstury Uzdrawiania?",Rf:"INFORMACJA: Bot b\u0119dzie wyszukiwa\u0142 przedmioty na rynku co wybran\u0105 liczb\u0119 minut, co mo\u017ce spowodowa\u0107 zatrzymanie atakowania podczas wyszukiwania.",ee:"W\u0142\u0105cz Wyszukiwanie na Rynku:",Sf:"Interwa\u0142 Wyszukiwania na Rynku w Minutach:",Tf:"Sugerowane 10 minut.",$e:"Ustawienia Przedmiotu:",Ye:"Nazwa Przedmiotu Zawiera",N:"Maksymalna Cena",af:"Rodzaj Przedmiotu",Ze:"Rzadko\u015b\u0107 Przedmiotu",
Od:"Kup Przedmiot Uwi\u0105zany?",cf:"Przedmioty do Kupienia",bf:"Pr\u00f3buj kupowa\u0107 przedmioty z paczek, je\u015bli kt\u00f3rykolwiek z nich pasuje do maksymalnej ceny wprowadzonej.:",Md:"Zakupione Przedmioty:",Ti:"Procent Leczenia",dk:"Kupuj Jedzenie ze Sklepu?",ek:"U\u017cyj Leczenia z Paczki?",ak:"U\u017cyj Cervisia?",ck:"U\u017cyj Jajka?",cl:"Ostatnio U\u017cyty",location:"Lokalizacja",Strength:"Si\u0142a",Dexterity:"W\u0142adanie broni\u0105",Agility:"Zr\u0119czno\u015b\u0107",Constitution:"Budowa fizyczna",
Charisma:"Charyzma",Intelligence:"Inteligencja",Zh:"Ustawienia Treningu",$h:"Wybierz atrybuty, kt\u00f3re chcesz trenowa\u0107. Bot przeprowadzi trening, gdy b\u0119dziesz mia\u0142 wystarczaj\u0105co du\u017co z\u0142ota.",Tc:"Nast\u0119pna akcja",cj:"Nie",dj:"Normalnie",hl:"Przeciwnik",il:"Poziom Przeciwnika",sj:"Zadania",random:"Losowo",ol:"Ustawienia",zl:"Wkr\u00f3tce...",type:"Kliknij na ikony, aby aktywowa\u0107 rodzaje zada\u0144.",Gl:"Tak",A:"Licytacja/Szukaj",pd:"Dodaj przedmioty",Xj:"Automatycznie Przechowuj Zasoby W\u0142asne",
Bl:"Zatwierd\u017a",al:"Interwa\u0142 : ",Rk:"W\u0142\u0105cz Automatyczn\u0105 Licytacj\u0119",Sk:"Nie licytuj, je\u015bli cz\u0142onek gildii ju\u017c licytowa\u0142",Dl:"Samouczek",Ub:"Wybierz przyciski powy\u017cej, aby wybra\u0107, czy chcesz stawi\u0107 czo\u0142a najni\u017cszemu przeciwnikowi na arenie, czy przeciwnikowi najwy\u017cszego poziomu. Wi\u0119cej u\u017cytkownik\u00f3w spowolni dzia\u0142anie bota.",Lk:'Aby rozpocz\u0105\u0107, dodaj przedmiot do listy (np. "Lucius"). Po dodaniu narz\u0119dzie b\u0119dzie szuka\u0107 przedmiotu i wy\u015bwietla\u0107 wyniki wyszukiwania po lewej stronie ekranu. B\u0119dzie r\u00f3wnie\u017c szuka\u0107 przedmiotu w celu automatycznej licytacji. Je\u015bli w\u0142\u0105czysz automatyczn\u0105 licytacj\u0119, narz\u0119dzie b\u0119dzie regularnie szuka\u0107 przedmiotu w okre\u015blonych odst\u0119pach czasu, zgodnie z liczb\u0105 wpisan\u0105 w polu interwa\u0142u. Je\u015bli narz\u0119dzie znajdzie przedmiot i b\u0119dziesz mie\u0107 wystarczaj\u0105co du\u017co pieni\u0119dzy, automatycznie z\u0142o\u017cy za ciebie licytacj\u0119. *Uwaga* aby szuka\u0107 unikalnych przedmiot\u00f3w w sklepach, musisz doda\u0107 przynajmniej 1 losowy przedmiot do listy wyszukiwania.',
Uk:"Numer potwora mo\u017cna wybra\u0107 z przycisk\u00f3w powy\u017cej. Numer 1 reprezentuje potwora najbardziej na lewo. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",Ji:"Wybierz trudno\u015b\u0107 lochu z powy\u017cszych opcji. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",Ui:"Ustawienia Leczenia",Ki:"Przechowuj nadmiar z\u0142ota w Gildii, kupuj\u0105c przedmioty z rynku gildii. -> Min. Z\u0142oto",
dl:"Przenie\u015b Wszystko",el:"Przenie\u015b Wybrane",Ok:"Auto Uzdrawianie",Pk:"Procent Auto Uzdrawiania",Fl:"Ruby",zg:"Og\u00f3lne Ustawienia",wj:"Sprzedaj Wszystko",xj:"Sprzedaj Wybrane",ja:"Bronie",ga:"Tarcze",W:"Zbroje Piersiowe",Z:"He\u0142my",Y:"R\u0119kawice",ha:"Buty",ea:"Pier\u015bcienie",V:"Amulety",ni:"U\u017cywalne",mi:"Ulepszenia",Qg:"Receptury",gg:"Zwoje Najemnik\u00f3w",Sg:"Wzmocnienia"},Eh={qj:"After expedition points are consumed, travel to Germania to consume Dungeon points",gk:"Haz clic aqu\u00ed si la reparaci\u00f3n se atasca",
uk:"Cuando los HP est\u00e9n bajos, usa curar",Bg:"Reparaci\u00f3n Parcial",Le:"Reparaci\u00f3n Completa",Ag:"Reparaci\u00f3n Parcial o Completa",ce:"Habilitar L\u00edmite",Wi:"L\u00edmite",Xi:"Si deseas limitar el n\u00famero de veces que quieres atacar al enemigo, habilita esta opci\u00f3n y establece el l\u00edmite. El bot continuar\u00e1 atacando al resto de los enemigos despu\u00e9s de terminar de atacar al monstruo seleccionado.",Yd:"No entres al inframundo con el traje del inframundo",Xd:"Si no quieres entrar al inframundo mientras llevas el traje del inframundo puesto, activa esta opci\u00f3n",
ji:"Inframundo",bi:"Mejoras del Inframundo",di:"\u00bfUsar los poderes de los dioses despu\u00e9s de entrar al inframundo?",ei:"Selecciona a los dioses para usar sus poderes:",fi:"\u00bfUsar Buff de Arma en el arma?",gi:"\u00bfUsar Buff de Armadura en el siguiente equipo?",rk:"El tiempo de enfriamiento es de 30 minutos. Si no llevas un disfraz, el bot restablecer\u00e1 el tiempo de enfriamiento a 0.",Fk:"Seleccionar Colores",Ra:"Forja de Vulcano",Va:"Escudo Terrestre de Feronia",Wa:"Poder Fluido de Neptuno",
Xa:"Libertad A\u00e9rea de Aelous",Ya:"Niebla Mortal de Plut\u00f3n",Za:"Aliento de Vida de Juno",$a:"Armadura de Escamas de las Monta\u00f1as de la Ira",ab:"Ojos de \u00c1guila",bb:"Vestidura Invernal de Saturno",Sa:"Armadura de Toro de Bubona",Ta:"Vestiduras de Ladr\u00f3n de Mercurio",Ua:"T\u00fanica de Luz de Ra",$f:"Paquetes",Uf:"Inventario",ca:"Precio M\u00edn.",ba:"Cantidad",xb:"Vender Art\u00edculos",wb:"Buscar en",Wf:"Color del Material",Vf:"Color del Art\u00edculo",cg:"Almac\u00e9n",yb:"Cambiar a Materiales",
bg:"Cambiar a Art\u00edculos",ag:"Vender Materiales",tb:"Por favor, introduce un nombre de art\u00edculo v\u00e1lido, rango de precio y cantidad.",ub:"No se han encontrado art\u00edculos adecuados en las ubicaciones de b\u00fasqueda seleccionadas.",vb:"\u00a1Todos los art\u00edculos fueron listados con \u00e9xito!",zk:"\u00a1Todos los materiales fueron listados con \u00e9xito!",Yf:"Si quieres vender art\u00edculos a un precio fijo, puedes ingresar el mismo valor para el precio m\u00ednimo y m\u00e1ximo.",
Zf:"Esta caracter\u00edstica todav\u00eda es experimental, \u00fasala con precauci\u00f3n. Si no pones un precio fijo, los art\u00edculos se listar\u00e1n aleatoriamente entre el precio m\u00ednimo y m\u00e1ximo que ingreses.",mk:"Establece el m\u00e1ximo de oro que el bot gastar\u00e1 por ciclo.",Ma:"El bot comenzar\u00e1 a pujar por cualquier art\u00edculo de comida, si est\u00e1 habilitado. No necesitas habilitar los interruptores de gladiador/mercenario.",wd:"El bot no pujar\u00e1 sobre las ofertas de los aliados.",
xd:"Ignorar la combinaci\u00f3n de Prefijo/Sufijo al buscar un art\u00edculo en la subasta.",Ej:"Selecciona los tipos de art\u00edculos que quieres fundir.",Fj:"Selecciona los colores que quieres fundir.",Gj:"Selecciona el nivel de los art\u00edculos que quieres fundir.",Hj:"Selecciona el martillo que quieres usar.",Ij:"Nota que el c\u00edrculo verde y rojo junto a la primera caja son para habilitar/deshabilitar la regla.",Jj:"Si quieres fundir aleatoriamente cualquier color o tipo, puedes habilitar `\u00bfFundir aleatoriamente si no se cumplen condiciones? (\u00daltima opci\u00f3n habilitada en el video tutorial)",
uj:"Reparar antes de fundir?",ye:"Seleccionar Monstruo",me:"\u00bfUsar Reloj de Arena/Rub\u00ed?",tk:"\u00bfUsar Rub\u00ed?",pe:"\u00bfUsar Movilizaci\u00f3n?",oe:"\u00bfUsar Poci\u00f3n de Vida?",le:"Porcentaje de Curaci\u00f3n (%)",we:"N\u00famero de Ataques",ne:"Intervalo de Ataque (en segundos)",je:"Ataques Realizados",ke:"Reloj de Arena Restante",ue:"Nota: Usa pociones de vida para curar, no comida.",ve:"Nota: Si los ataques se detienen prematuramente, intenta 'Reiniciar Ataques'.",ze:"Comenzar",
xe:"Reiniciar",Ae:"Detener",Be:"Configuraci\u00f3n de Expedici\u00f3n (Clic para minimizar)",qe:"Monstruo 1",re:"Monstruo 2",se:"Monstruo 3",te:"Monstruo 4",Ck:"Reparar antes de fundir?",Ci:"Esta opci\u00f3n usar\u00e1 cervisia cuando tu premium expire.",ej:"Esta opci\u00f3n activa y selecciona aceites de las recompensas de los dioses. Puede usar los aceites n\u00famero 1 y n\u00famero 3 en el personaje, pero el n\u00famero 2 solo ser\u00e1 recogido para los paquetes.",Ai:"Esta opci\u00f3n usar\u00e1 buffs en el momento que establezcas. Encontrar\u00e1 buffs en los paquetes y los aplicar\u00e1 al personaje.",
Yi:"Esta opci\u00f3n te llevar\u00e1 al inframundo. No olvides activar el Inicio de Sesi\u00f3n Autom\u00e1tico desde la pesta\u00f1a de Extras, de lo contrario podr\u00edas desconectarte al entrar al inframundo [Error del Juego]",Sb:"Normalmente, el bot elige de 3 a 6 intentos aleatorios para atacar en la lista de arena. Si activas esta opci\u00f3n, recorrer\u00e1 tu lista hasta que pueda atacar a alguien. Esto puede llevar algo de tiempo.",rj:"Esta opci\u00f3n es solo para licencias premium. Simula el ataque antes de atacar a un usuario para un ratio de victoria del 75%.",
zd:"No necesitas activar el interruptor principal de subastas para habilitar esta opci\u00f3n.",$j:"Esta opci\u00f3n refrescar\u00e1 la p\u00e1gina cada segundo cuando la subasta est\u00e9 en estado -Muy Corto- para ofertar constantemente y ganar la subasta.",Cj:"Si ninguna de las condiciones de fundici\u00f3n se cumple, fundir\u00e1 aleatoriamente. Aseg\u00farate de seleccionar tipo de objeto y color.",Dj:"Esta opci\u00f3n solo fundir\u00e1 art\u00edculos del inventario. Ignorar\u00e1 los art\u00edculos en los paquetes.",
Na:"Art\u00edculos de Subasta",fg:"Art\u00edculos de Mercenario",Mb:"Art\u00edculos de la Tienda",li:"Art\u00edculos \u00danicos",yj:"Establecer fondo en negro [Aumenta el rendimiento]",zj:"Mover los botones de GLDBot a la parte inferior izquierda?",Di:"Atacar al circo sin sanar",Yj:"\u00bfRecoger oro de los paquetes si es necesario?",Zj:"Se ha recogido oro de los paquetes para entrenamiento",Cl:"No se ha encontrado oro en los paquetes para entrenamiento",Vj:"Objetos Reparados",Oj:"Ataques en la Arena",
Qj:"Ataques en el Circo",qd:"Objetos Reiniciados",Tj:"Ataques en Expediciones",Sj:"Ataques en Mazmorras",Wj:"Ataques en el Inframundo",Pj:"Dinero Ganado en la Arena",Rj:"Dinero Ganado en el Circo",Al:"Objetos Fundidos",Uj:"Oro Reciclado",Pi:"Batalla de Gremio",Ri:"Configuraci\u00f3n del Gremio",Wk:"Atacar\u00e1 gremios al azar.",Qi:"Nombre del Gremio",Oi:"Atacar Guilds Aleatoriamente",Bi:"Restablecer Estad\u00edsticas",gl:'GLDBot: usa los dados para actualizar la caja misteriosa y encontrar objetos valiosos antes de abrirla (por ejemplo, disfraces). Haz clic en "Iniciar" para abrir los cofres.',
Ec:"Madera",uc:"Cobre",yc:"Hierro",Ac:"Cuero",Fc:"Hilo de lana",vc:"Bolas de algod\u00f3n",xc:"C\u00e1\u00f1amo",wc:"Tiras de gasa",Bc:"Lino",zc:"Yute",Dc:"Tiras de terciopelo",Cc:"Hilo de seda",Nc:"Pelaje",Hc:"Astilla \u00f3sea",Qc:"Escama",Kc:"Garra",Mc:"Colmillo",Lc:"Escama de drag\u00f3n",Ic:"Cuerno de toro",Pc:"Gl\u00e1ndula venenosa",Jc:"Pelaje de Cerbero",Oc:"Escama de Hidra",Rc:"Pluma de Esfinge",Sc:"Piel de Tif\u00f3n",pc:"Lapisl\u00e1zuli",jc:"Amatista",ic:"\u00c1mbar",kc:"Aguamarina",qc:"Safiro",
nc:"Granate",mc:"Esmeralda",lc:"Diamante",oc:"Jaspe",rc:"Sugilita",cc:"Veneno de escorpi\u00f3n",fc:"Tintura de la resistencia",Zb:"Ant\u00eddoto",Yb:"Adrenalina",ec:"Tintura de la inspiraci\u00f3n",bc:"Poci\u00f3n de percepci\u00f3n",$b:"Esencia de reflejos",ac:"Frasco de carisma",hc:"Agua del olvido",dc:"Esencia de alma",od:"Sello acu\u00e1tico",hd:"Runa protectora",fd:"Grabado terrestre",nd:"T\u00f3tem curativo",md:"Talism\u00e1n de poder",kd:"Piedra de la fortuna",gd:"Pedernal",ld:"Runa de la tormenta",
jd:"Runa de las sombras",Wc:"Cristal",Vc:"Bronce",$c:"Obsidiana",cd:"Plata",dd:"Azufre",Yc:"Mena de oro",bd:"Cuarzo",ad:"Platino",Uc:"Almandino",Xc:"Cuprita",Zc:"Piedra infernal",xi:"\u00bfAtacar aleatoriamente?",yi:'Tambi\u00e9n desactiva la configuraci\u00f3n "Ordenar jugadores en la arena por nivel" en crazy-addon.',Ng:"Aceptar solo misiones basadas en el tipo de dios.",Oa:"Auto Buff",Nd:"\u00bfUsar solo en el infierno?",ug:"Nueva Regla",sg:"Nombre Contiene",isUnderworldItem:"\u00bfEs un objeto del inframundo?",
Ue:"Ignorar Materiales",fk:"\u00bfUsar Oraci\u00f3n?",si:"Usar Sacrificio",bk:"Usar Tela para entrar en el Inframundo",ii:"\u00bfCuando est\u00e9s en el inframundo, solo aceptar misiones relacionadas con el inframundo?",hi:"Si est\u00e1 habilitado, necesitas ingresar los nombres de los objetos del inframundo. Si el bot encuentra estos objetos en el inframundo, aceptar\u00e1 la misi\u00f3n.",Jk:"Objeto de Misi\u00f3n del Inframundo",Tk:"Introduzca el nombre del material",qk:"\u00a1El robot adora los dados! Le ayudan a encontrar ropa en los cofres. Pero si no hay dados, el robot abre los cofres de todos modos, con la esperanza de encontrar ropa genial (\u00a1pero puede que no encuentre nada!)",
Bj:"\u00bfFusionar Cajas de Bot\u00edn?",be:"Habilitar Arena",Fg:"\u00bfPriorizar lista de arenas?",Gg:"\u00bfPriorizar lista de circos?",Ud:"Desactivar men\u00fa de registro",ah:"Valor m\u00ednimo de recompensa en oro",Og:"Si est\u00e1 habilitado, el Enfoque en misiones seguir\u00e1 el camino m\u00e1s corto para terminar el calabozo.",zh:"\u00bfLanzar dados autom\u00e1ticamente?",Ah:"Usa el lanzamiento de dados con cautela, seguir\u00e1 usando el primer dado hasta que desactives la opci\u00f3n.",
gh:"Progreso de b\u00fasqueda",Vg:"El tiempo de enfriamiento para la reparaci\u00f3n por defecto es de 10 minutos.",pg:"Condici\u00f3n m\u00ednima",Sd:"Art\u00edculo actual en el banco de trabajo [Borrar si el bot se detiene inesperadamente]",rf:"Recursos de forja almacenados en el horreum con \u00e9xito.",lf:"Comprobando el mercado para art\u00edculos...",qb:"Art\u00edculo movido al banco de trabajo.",Gf:"Art\u00edculo reparado y equipado con \u00e9xito.",Hf:"Art\u00edculo reparado con \u00e9xito.",
xk:"La reparaci\u00f3n fall\u00f3. La p\u00e1gina se actualizar\u00e1.",Df:"Recogiendo materiales...",Qf:"Esperando reparaci\u00f3n...",Ff:"La reparaci\u00f3n ha comenzado para .",rb:"Reparaci\u00f3n: Moviendo el art\u00edculo del inventario a la bolsa",Ef:"Reparaci\u00f3n: Moviendo el art\u00edculo del banco de trabajo al paquete.",nf:"No se pudieron encontrar suficientes materiales. Desactivando la ranura de reparaci\u00f3n ",Af:"Buscando art\u00edculos para comprar y ocultar oro en la subasta...",
hf:"Comprobando los art\u00edculos caducados en los paquetes...",jf:"Art\u00edculo reseteado con \u00e9xito.",kf:"Sin espacio vac\u00edo o oro para resetear.",sf:"\u00a1Aseg\u00farate de tener derechos de venta en el mercado de la guild!",tf:"No hay suficiente oro o ning\u00fan art\u00edculo para comprar. Esperando 30 segundos para actualizar.",mb:"La tienda ha sido actualizada.",nb:"Error durante la curaci\u00f3n.",wf:"Sin Rub\u00ed o Tela, desactivando las opciones.",xf:"No se encontr\u00f3 ning\u00fan art\u00edculo de curaci\u00f3n en los paquetes.",
ob:"No se encontraron art\u00edculos adecuados",yf:"Se han recogido alimentos. Finalizando el proceso.",zf:"Se ha recogido al menos un alimento. Finalizando el proceso.",pb:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",uf:"Obteniendo alimentos de los paquetes.",vf:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",lb:"No hay m\u00e1s art\u00edculos de curaci\u00f3n. Esperando 30 segundos.",kb:"Puntos de vida recuperados.",za:"\u00a1No hay nada que hacer, as\u00ed que voy a rezar!",
Mf:"Voy a actualizar en 60 segundos para revisar mi salud y Villa Medici.",Nf:"Esperando Villa Medici, actualizando en 60 segundos.",Of:"Sal\u00ed del inframundo.",Pf:"Voy a actualizar en 60 segundos para revisar mi salud.",Bf:"Comprobando aceites divinos...",Cf:"Los aceites divinos han sido recogidos.",xa:"Atacado con \u00e9xito al jugador en la ARENA: ",ya:"Atacado con \u00e9xito al jugador en el CIRCO: ",ff:"\u00a1Comprobando subasta! Por favor, espere...",gf:"Pujando por art\u00edculos. Por favor, espere...",
If:"Art\u00edculo fundido autom\u00e1ticamente: ",Jf:"Fundiendo art\u00edculo: ",Kf:"No hay suficiente oro para fundir. Oro requerido: ",Lf:"FUNDIR: Buscando art\u00edculos para fundir...",yk:"Buscando art\u00edculos para fundir...",mf:"Comprobando disponibilidad de disfraces...",qf:"Donado : ",pf:"Lanzando dados...",He:"Underworld Farm [Manual, Beta]",Ge:"Farm Location",Ie:"Tenga en cuenta: active esta funci\u00f3n despu\u00e9s de desbloquear la criatura que desea atacar, no atacar\u00e1 autom\u00e1ticamente para desbloquear el monstruo.",
Fe:"Farm Enemy",Gd:"Inicio Autom\u00e1tico",Hd:"Necesitas permitir las ventanas emergentes desde la pantalla del lobby de GameForge. Consulta la documentaci\u00f3n sobre c\u00f3mo hacerlo.",Cg:"Pausar Bot",Dg:"Pausar Bot en (Minutos)",De:"Fecha de Expiraci\u00f3n",xg:"\u00bfComprar solo comida?",yg:"Si activas esto, el bot ignorar\u00e1 tus selecciones y comprar\u00e1 comida autom\u00e1ticamente sin ingresar nada.",Ab:"M\u00e1ximo de oro total para gastar",zb:"M\u00e1ximo de oro por comida para gastar",
wg:"El bot verificar\u00e1 los aceites cada 60 minutos",Sh:"Establece un temporizador para verificar los tiempos de fundici\u00f3n.",Ph:"Establece un temporizador para verificar la fundici\u00f3n cuando no tengas oro.",Rh:"Establece un temporizador para verificar la fundici\u00f3n si no tienes el art\u00edculo disponible.",Kh:"Establece un temporizador para reparar y verificar tus objetos.",Jh:"Establece un temporizador para verificar el oro en el mercado de la hermandad.",Fh:"Establece un temporizador para la opci\u00f3n de retenci\u00f3n de oro en la subasta.",
Bh:"Establece un temporizador para verificar la lista de PVP en la arena para atacar.",Gh:"Establece un temporizador para verificar la lista de PVP en el circo para atacar.",Yh:"Establece un temporizador para entrenar tus estad\u00edsticas.",Mh:"Establece un temporizador para reiniciar los objetos caducados.",Wh:"Establece un temporizador para almacenar los materiales de forja en el horreo.",Dh:"Establece un temporizador para verificar la subasta de gladiadores y mercenarios.",Oh:"Establece un temporizador para buscar objetos en la subasta y la tienda.",
Hh:"Establece el temporizador para enviar donaciones a la hermandad.",Me:"Oro Movido",Zd:"No vender art\u00edculos de la lista de fundici\u00f3n y subasta.",hh:"Automatizaci\u00f3n de la Tienda",jh:"Configuraci\u00f3n de B\u00fasqueda de Objetos",ih:"Utiliza esta herramienta para buscar objetos. Simplemente agrega los objetos a la lista, especifica la cantidad de tela y comienza la b\u00fasqueda.",kh:"Telas a Usar:",lh:"\u00bfCu\u00e1ntas telas usar?",ia:"Full Ingresa el Nombre del Objeto",Lb:"Ingresa el Nivel del Objeto",
nh:"Calidad del Objeto",mh:"Nombre del Objeto Aqu\u00ed",oh:"Comenzar B\u00fasqueda",ph:"Saltar y Continuar",qh:"Detener B\u00fasqueda",Je:"\u00bfComprar lo m\u00e1s barato o lo m\u00e1s caro?",rg:"M\u00e1s Caros",Pd:"M\u00e1s Baratos",fa:"Selecciona una Opci\u00f3n",de:"Pod\u015bwietl przedmioty z Podziemia",Ke:"\u00bfCentrarse en la b\u00fasqueda",El:"\u00bfUsar Ruby si no hay tela",Pa:"Evita atacar a las mismas personas para no ser reportado. Ser reportado aumenta las posibilidades de ser baneado.",
tl:"\u00bfDerretir verde?",Ig:"\u00bfNo aceptar misiones aleatorias si se han introducido filtros?",Gc:"Calidad m\u00e1xima del material a utilizar",Li:"Habilitar la b\u00fasqueda de mercenarios",bl:"Haz clic en `Vender Todo Seleccionado` para vender todos los elementos. Aseg\u00farate de tener espacio vac\u00edo de 2x3 en tu primera (1) bolsa. Para recoger oro en masa, filtra el oro y usa `Seleccionar Seleccionados o Seleccionar Todo`.",Nj:"\ud83d\udd25 : A\u00f1ade elemento a la lista de fundici\u00f3n.",
zi:"\ud83d\udd28 : A\u00f1ade elemento a la lista de subastas.",tj:"Actualiza la tienda con tela cuando est\u00e9 llena (Deber\u00e1s vender de nuevo despu\u00e9s)",hj:"P\u00e1gina:",oj:"Detener",mj:"Vender Esta P\u00e1gina",jj:"Seleccionar Seleccionados",ij:"Seleccionar Todo",pj:"Configuraci\u00f3n de Empaquetado Autom\u00e1tico",nj:"Enviar Recursos",kj:"Vender Todo Seleccionado",qa:"Tipo de Objeto",U:"Armas",M:"Escudos",I:"Armaduras",L:"Cascos",K:"Guantes",J:"Botas",T:"Anillos",R:"Amuletos",oa:"Utilizables (Comida)",
va:"Mejoras",fj:"Potenciadores",sa:"Recetas",ra:"Mercenarios",ua:"Herramientas de Forja",ta:"Pergaminos",Ga:"Refuerzos",Fa:"Objetos de Evento",ed:"Materiales de Forja",gj:"Oro",P:"Todo",jl:"Calidad",wa:"Blanco",C:"Verde",B:"Azul",D:"Morado",G:"Naranja",S:"Rojo",lj:"Opciones de Venta",Aj:"\u00bfIgnorar Combinaci\u00f3n de Prefijo/Sufijo?",Si:"\u00bfCu\u00e1nta comida comprar/recoger?",Gi:"Normal",Fi:"Intermedio",Ei:"Dif\u00edcil",Da:"Est\u00e1ndar",ml:"Reparar Correcci\u00f3n de Atascos",vk:"Desactiva la entrada al Infierno si deseas desactivar la Mazmorra/Circo/Arena. Si entraste al Infierno manualmente, deber\u00e1s activar el Modo Infierno.",
Qd:"Wybierz kostium z Za\u015bwiat\u00f3w",vi:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",ai:"Indica cu\u00e1ntas veces deseas entrenar las estad\u00edsticas y establece sus prioridades. El bot no entrenar\u00e1 a menos que se establezca una prioridad. Si hay una prioridad configurada pero no quedan m\u00e1s estad\u00edsticas por entrenar, el bot continuar\u00e1 con la estad\u00edstica seleccionada.",Qk:"Quest",rl:"Fundir",xl:"Configuraci\u00f3n de Fundici\u00f3n",Kj:"Objetos Fundidos",
yl:"Agrega Prefijos o Sufijos, una vez que los encuentre en los paquetes, se fundir\u00e1n autom\u00e1ticamente:",wl:"Objeto en Fundici\u00f3n:",Vb:"Haz clic en el objeto que deseas reparar. Este sistema reparar\u00e1 a tus dos personajes, el principal y el primer personaje de circo. Debes tener al menos 10000 de oro para que comience la reparaci\u00f3n. Si se queda atascado en un objeto, significa que no tienes material para arreglarlo. Tambi\u00e9n trata de hacer espacio en tu inventario. El bot iniciar\u00e1 la reparaci\u00f3n una vez que el objeto tenga un %0 de durabilidad.",
Kk:"Aplicar solo a Mercenarios",Nk:"La subasta solo pujar\u00e1 cuando el mercado est\u00e9 cerca del final.",Mk:"Aseg\u00farate de que la SEGUNDA PESTA\u00d1A DEL INVENTARIO est\u00e9 vac\u00eda y tenga 10K de oro. El bot encontrar\u00e1 y colocar\u00e1 el objeto en la segunda pesta\u00f1a y luego, la pr\u00f3xima vez que se actualice la p\u00e1gina, fundir\u00e1 el objeto. La fundici\u00f3n se revisar\u00e1 cada 5-10 minutos.",Vi:"Curar & Buffs",nl:"No hay suficiente oro para fundir. Oro requerido:",
ql:"Saltando puja: El miembro del gremio ya ha pujado por el objeto ",pl:"Saltando puja: Ya has pujado por el objeto ",advanced:"Avanzado",arena:"Arena",ma:"Auto Ataque",Tb:"Evitar Ataque",ka:"Agregar Jugador",la:"Agregar Nombre de Jugador (Same Server)",Yk:"\u00bfDetener el bot si se queda sin comida?",circusTurma:"Circo Turma",Hi:"Dificultad",dungeon:"Mazmorra",Ii:"Configuraci\u00f3n de Mazmorra",eventExpedition:"Expedici\u00f3n de Evento",expedition:"Expedici\u00f3n",Mi:"Configuraci\u00f3n de Expedici\u00f3n",
vj:"Seleccionar Monstruo",$k:"M\u00e1s Alto",Zk:"Coloca tus objetos de curaci\u00f3n en la primera p\u00e1gina de tu inventario",tc:"En",xh:"Almacenar Oro",yh:"\u00bfAlmacenar Oro en Subasta?",eh:"\u00bfUsar Ropa de Trabajo para renovar la Tienda?",Ek:"Seleccionar Objetos para Reiniciar",Xg:"Reiniciar Objetos Expirados",Gb:"Nota: Al habilitar esta opci\u00f3n, el bot vender\u00e1 los objetos pr\u00f3ximos a expirar de los Paquetes al Mercado del Gremio y luego los cancelar\u00e1 para reiniciar el tiempo de vencimiento. Se requiere el Gremio. Aseg\u00farate de tener un espacio vac\u00edo de 3x3 en tus bolsas.",
Eg:"Pausar el bot aleatoriamente para funcionar como [Fase de Pruebas]:",aa:"Mantener Oro: El bot mantendr\u00e1 este oro en la bolsa:",dg:"Oro M\u00e1ximo: El bot gastar\u00e1 cuando el oro sea mayor que",bh:"El bot pujar\u00e1 por art\u00edculos aleatorios",rd:"Agregar Retraso Aleatorio",sd:"Puedes agregar un retraso al bot aqu\u00ed.",Fb:"Reparar",sl:"\u00bfFundir solo Azules?",vl:"\u00bfFundir solo P\u00farpuras?",ul:"\u00bfFundir solo Naranjas?",Lj:"\u00bfFundir Todo en la 2da pesta\u00f1a?",
Mj:"Esto ignorar\u00e1 las selecciones de colores",Qa:"Limpiar Historial",th:"Fundir",Ad:"Search",tg:"Subasta Autom\u00e1tica",Bd:"El uso excesivo de la Subasta podr\u00eda resultar en una prohibici\u00f3n. Se recomienda desactivar otras funciones de oferta para evitar posibles conflictos. Esta caracter\u00edstica ralentizar\u00e1 el bot.",dh:"Buscar en la Subasta de Gladiadores",fh:"Buscar en la Subasta de Mercenarios",Jd:"\u00bfPujar por Comida?",eg:"Puja M\u00e1xima",Kd:"Pujar si el estado es menor que",
Ld:"Objetos Pujados",kk:"Idioma de Subasta",lk:"Seg\u00fan la actualizaci\u00f3n 2.9.4, establece el idioma nuevamente o REINICIA EL BOT. Aseg\u00farate de que todos sean correctos, de lo contrario, no pujar\u00e1.",vd:"Puedes agregar objetos para buscar en el mercado y en la subasta. Tambi\u00e9n mostrar\u00e1 objetos p\u00farpuras en el mercado una vez que agregues un objeto a la lista. Si deseas habilitar la puja autom\u00e1tica, usa las opciones a continuaci\u00f3n",ik:"\u00a1Usa la subasta con precauci\u00f3n!",
jk:"La puja autom\u00e1tica realiza demasiadas solicitudes al servidor y puede causar una prohibici\u00f3n si se usa todo el tiempo.",Ug:"\u00bfRenovar Puntos de Evento con Rub\u00edes?",fe:"\u00bfHabilitar Aceite Autom\u00e1tico?",nk:"\u00bfObtener Aceites Sagrados Autom\u00e1ticamente?",Ak:"Velocidad de Verificaci\u00f3n de Misiones",La:"\u00bfAtacar a Miembros del Gremio?",Ja:'Agregar autom\u00e1ticamente a las personas a la lista de "Ataque" cuando se roban m\u00e1s de X ORO.:',Ka:'Agregar autom\u00e1ticamente a las personas a la lista de "Evitar Ataque" cuando pierdas contra ellas.:',
Jb:"Ataques en el Marcador",Qb:"Muy Largo",sb:"Largo",Bb:"Medio",Nb:"Corto",Rb:"Muy Corto",ge:"Entrar al Inframundo si HP >",Pg:"Velocidad de Verificaci\u00f3n de Misiones",Hg:'El valor predeterminado es "3x". Si el bot causa problemas con las misiones, cambia la velocidad de las misiones seg\u00fan la velocidad de tu servidor.',Ne:"Selecci\u00f3n de Bolsa de Curaci\u00f3n",he:'Si est\u00e1s renovando puntos manualmente, debes hacer clic en el bot\u00f3n de arriba "Actualizar expedici\u00f3n de evento si est\u00e1 atascada".',
sk:"Debes habilitar al menos una de las siguientes opciones: expedici\u00f3n, mazmorra, arena o circo para comenzar la Expedici\u00f3n de Evento.",Rg:"\u00a1Actualiza la Expedici\u00f3n de Evento si est\u00e1 atascada!",cb:"\u00bfCubrir a los Aliados?",Gk:"Deja todas las configuraciones desactivadas si deseas fundir usando paquetes que contienen los elementos de la lista. Sin embargo, a\u00fan puedes elegir colores.",pk:"Personaje(Desactivado) / Mercenario(Activado)",Dk:"\u00bfReparar Ambos?",Hk:"Temporizadores",
Timers:"Ingresa el n\u00famero de minutos para cada temporizador a continuaci\u00f3n o d\u00e9jalo en su valor predeterminado.",Mg:"Ignorar Filtro de Misiones",Lg:"Ingresa palabras clave para filtrar las misiones que no deseas tomar. You can also use this to accept quests by their reward using keywords.",X:"Ingresar Palabra Clave",H:"Agregar",Tg:"Eliminar",Rd:"Limpiar",Jg:"Aceptar Filtro de Misiones",Kg:"Ingresa palabras clave para seleccionar qu\u00e9 misiones tomar. Usar esto ignorar\u00e1 los tipos de misiones",
Ba:"\u00bfSaltar Misiones Temporales?",Bk:"Misiones",Dd:"Auto Traje",oi:"\u00bfUsar Traje?",Id:"Batalla B\u00e1sica",$d:"Batalla en Mazmorra",Ed:"Bot solo usar\u00e1 Dis Pater Normal y Medium si tus puntos de expedici\u00f3n/mazmorra son 0.",Pe:"Configuraci\u00f3n de Sanaci\u00f3n Infernal",ud:"\u00bfAtacar al Jefe cuando est\u00e9 disponible?",jb:"La opci\u00f3n de ataque a la Liga se desactivar\u00e1 despu\u00e9s de 5 intentos fallidos.",Se:"Aceites Sagrados",og:"Nombre del Objeto",da:"Nivel M\u00ednimo del Objeto",
Aa:"Calidad M\u00ednima del Objeto",td:"Aplicar/Restablecer Temporizador",Ve:"Ignorar Combinaci\u00f3n de Prefijo/Sufijo",wi:"S\u00ed",vg:"No",Ha:"Agregar Prefijo",Ia:"Agregar Sufijo",uh:"Lista de Objetos a Ignorar al Fundir",Cb:"Prefijo",Ob:"Sufijo",Zg:"Restablecer Objetos Expirados",vh:"\u00bfFundir al Azar desde los Paquetes?",wh:"Pesta\u00f1a de Fundici\u00f3n",hb:"Extras",yd:"Subasta",Xf:"Mercado",Pb:"Temporizadores",Uh:"Fundici\u00f3n",Th:"Fundici\u00f3n si no hay suficiente oro",Qh:"Fundir si no hay objeto",
Ca:"Reparaci\u00f3n",Ih:"Mantener Oro en el Mercado de Gremio",Eh:"Mantener Oro en la Subasta",Xh:"Entrenamiento",Lh:"Restablecer Expirados",Vh:"Almacenar en la Forja",Ch:"Comprobar Subasta",Nh:"Buscar",v:"Habilitar",qg:"Oro M\u00ednimo",Kb:"Seleccionar Hora",eb:"Donar Oro al Gremio",Vd:"Donar\u00e1 cada 5 minutos. Puedes cambiar el intervalo desde la pesta\u00f1a de temporizadores",Te:"\u00bfCu\u00e1nto deseas donar?",Wd:"Donar cuando tengas m\u00e1s de >",ef:"Menos de <",Wg:"Restablecer Objetos Expirados y Otras Configuraciones",
Yg:"Restablecer en:",wk:"Mant\u00e9n presionada la tecla Ctrl (Cmd en Mac) para seleccionar varios objetos",We:"Importar/Exportar Configuraciones",Ee:"Exportar Configuraciones",Xe:"Importar Configuraciones",hg:"Mensaje a Todos los Jugadores",ig:"[Requiere Clave Ultra Premium, mensaje en Discord para obtenerla.]",jg:"Ingresar mensaje para enviar",Td:"Para scripts personalizados, cont\u00e1ctanos en Discord",lg:"Enviar",mg:"Mostrar Jugadores",kg:"Seleccionar Todos",ng:"Deseleccionar Todos",df:"Aseg\u00farate de que tu inventario tenga suficiente espacio. El tiempo de reutilizaci\u00f3n es de 2 minutos.",
gb:"Habilitar Ataque en el Marcador:",Hb:"Seleccionar Rango para Atacar",Ib:"El bot atacar\u00e1 aleatoriamente desde la lista del marcador.",ib:"Ataque de Liga",fb:"Habilitar Ataque de Liga:",Db:"Ataque Aleatorio",Eb:"Atacar desde el m\u00e1s bajo al m\u00e1s alto",hk:"El bot evitar\u00e1 atacar a los miembros del gremio por defecto.",Ce:"Ubicaci\u00f3n de Expedici\u00f3n:",Cd:"\u00bfRecoger Bonos Autom\u00e1ticamente?",rh:"\u00bfSaltar al Jefe?",ae:"Ubicaci\u00f3n de Mazmorra:",$g:"\u00bfReiniciar si pierdes?",
Qe:"Configuraci\u00f3n de Inframundo",Re:"Configura tus ajustes de porcentaje de curaci\u00f3n desde la pesta\u00f1a de curaci\u00f3n y aseg\u00farate de que est\u00e9 activada. Si ingresar al inframundo te desconecta, ve al lobby y activa la casilla de inicio de sesi\u00f3n autom\u00e1tico.",Oe:"Dificultad del Inframundo",Fd:"Entrar Autom\u00e1ticamente al Inframundo: / Inframundo Mode",pi:"\u00bfUsar Movilizaci\u00f3n si los puntos = 0",ui:"\u00bfUsar Rub\u00edes?",ie:"\u00bfSalir del inframundo si no hay puntos?",
ci:"El bot intentar\u00e1 usar villa medici primero, si no la tienes, usar\u00e1 poci\u00f3n de curaci\u00f3n. No olvides activar el interruptor de Curar.",ki:"El ingreso autom\u00e1tico al inframundo deshabilitar\u00e1 la mazmorra/arena/circo al ingresar al inframundo.",Ik:"Ajustes de Curaci\u00f3n del Inframundo",ti:"\u00bfUsar Villa Medici?",ri:"\u00bfUsar Poci\u00f3n de Curaci\u00f3n?",Rf:"INFO: El bot buscar\u00e1 objetos en el mercado cada ciertos minutos, lo que puede detener los ataques durante la b\u00fasqueda.",
ee:"Habilitar B\u00fasqueda en el Mercado:",Sf:"Intervalo de B\u00fasqueda en el Mercado en Minutos:",Tf:"Se sugieren 10 minutos.",$e:"Ajustes de Objetos:",Ye:"Nombre del Objeto Incluye",N:"Precio M\u00e1ximo",af:"Tipo de Objeto",Ze:"Rareza del Objeto",Od:"\u00bfComprar con V\u00ednculo Espiritual?",cf:"Objetos para Comprar",bf:"Intentar comprar objetos con paquetes si alguno coincide con el precio m\u00e1ximo ingresado:",Md:"Objetos Comprados:",Ti:"Porcentaje de Curaci\u00f3n",dk:"\u00bfComprar Comida en la Tienda?",
ek:"\u00bfUsar Curaci\u00f3n de Paquete?",ak:"\u00bfUsar Cervisia?",ck:"\u00bfUsar Huevos?",cl:"\u00daltima Vez Usado",location:"Ubicaci\u00f3n",Strength:"Fuerza",Dexterity:"Destreza",Agility:"Agilidad",Constitution:"Constituci\u00f3n",Charisma:"Carisma",Intelligence:"Inteligencia",Zh:"Ajustes de Entrenamiento",$h:"Selecciona los atributos que deseas entrenar. Se entrenar\u00e1 una vez que tengas suficiente oro.",Tc:"Siguiente acci\u00f3n",cj:"No",dj:"Normal",hl:"Oponente",il:"Nivel del Oponente",
sj:"Misiones",random:"Aleatorio",ol:"Ajustes",zl:"Pronto...",type:"Haz clic en los \u00edconos para activar los tipos de misiones.",Gl:"S\u00ed",A:"Subasta/B\u00fasqueda",pd:"Agregar objetos",Xj:"Almacenar Recursos Forjados autom\u00e1ticamente",Bl:"Enviar",al:"Intervalo : ",Rk:"Habilitar Puja Autom\u00e1tica",Sk:"No pujar si el miembro del gremio ya ha pujado",Dl:"Tutorial",Ub:"Selecciona entre los botones de arriba si deseas enfrentar al oponente de nivel m\u00e1s bajo en la arena o al oponente de nivel m\u00e1s alto. M\u00e1s usuarios ralentizar\u00e1n el bot.",
Lk:"Para empezar, agrega un objeto a la lista (p. ej., `Lucius`). Una vez agregado, la herramienta buscar\u00e1 el objeto y mostrar\u00e1 los resultados de la b\u00fasqueda en el lado izquierdo de la pantalla. Tambi\u00e9n se buscar\u00e1 para fines de subasta autom\u00e1tica. Si habilitas la puja autom\u00e1tica, la herramienta buscar\u00e1 el objeto a intervalos regulares seg\u00fan el n\u00famero que ingreses en el cuadro de intervalo. Si la herramienta encuentra el objeto y tienes suficiente dinero, pujar\u00e1 autom\u00e1ticamente por ti. *Nota* para buscar objetos \u00fanicos en las tiendas, debes agregar al menos 1 objeto aleatorio en la lista de b\u00fasqueda.",
Uk:"El n\u00famero de criatura se puede seleccionar desde los botones de arriba. El n\u00famero 1 representa la criatura m\u00e1s a la izquierda. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",Ji:"Selecciona la dificultad de la mazmorra de arriba. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",Ui:"Ajustes de Curaci\u00f3n",Ki:"Almacena el oro excedente en el Gremio comprando objetos del mercado del gremio. -> M\u00edn. Oro",
dl:"Mover Todo",el:"Mover Seleccionados",Ok:"Curaci\u00f3n Autom\u00e1tica",Pk:"Porcentaje de Curaci\u00f3n Autom\u00e1tica",Fl:"Ruby",zg:"Ajustes Generales",wj:"Vender Todo",xj:"Vender Seleccionados",ja:"Armas",ga:"Escudos",W:"Armadura de Pecho",Z:"Cascos",Y:"Guantes",ha:"Zapatos",ea:"Anillos",V:"Amuletos",ni:"Usables",mi:"Mejoras",Qg:"Recetas",gg:"Pergamino de Mercenario",Sg:"Refuerzos"},Gh={qj:"After expedition points are consumed, travel to Germania to consume Dungeon points",gk:"Cliquez ici si la r\u00e9paration se bloque",
uk:"Quand les PV sont en dessous, utilisez soin",Bg:"R\u00e9paration Partielle",Le:"R\u00e9paration Compl\u00e8te",Ag:"R\u00e9paration Partielle ou Compl\u00e8te",ce:"Activer la Limite",Wi:"Limite",Xi:"Si vous voulez limiter le nombre de fois que vous souhaitez attaquer l'ennemi, activez cette option et d\u00e9finissez la limite. Le bot continuera \u00e0 attaquer le reste des ennemis apr\u00e8s avoir fini d'attaquer le monstre s\u00e9lectionn\u00e9.",ji:"Monde Souterrain",bi:"Am\u00e9liorations du Monde Souterrain",
di:"Utiliser les pouvoirs des dieux apr\u00e8s \u00eatre entr\u00e9 dans le monde souterrain?",ei:"S\u00e9lectionnez les dieux pour utiliser leurs pouvoirs:",fi:"Utiliser un Buff d'Arme sur l'arme?",gi:"Utiliser un Buff d'Armure sur l'\u00e9quipement suivant:",rk:"Le temps de recharge est de 30 minutes. Si vous n'avez pas de costume, le bot r\u00e9initialisera le temps de recharge \u00e0 0.",Fk:"S\u00e9lectionner les Couleurs",Ra:"Forge de Vulcain",Va:"Bouclier de Terre de Feronia",Wa:"Puissance Fluide de Neptune",
Xa:"Libert\u00e9 A\u00e9rienne d'Aelous",Ya:"Brouillard Mortel de Pluton",Za:"Souffle de Vie de Junon",$a:"Armure d'\u00c9cailles des Montagnes de Col\u00e8re",ab:"Yeux d'Aigle",bb:"V\u00eatement d'Hiver de Saturne",Sa:"Armure de Taureau de Bubona",Ta:"V\u00eatements de Voleur de Mercure",Ua:"Robe de Lumi\u00e8re de R\u00e2",Yd:"N`entrez pas dans le monde souterrain avec le costume des enfers",Xd:"Si vous ne voulez pas entrer dans le monde souterrain en portant le costume des enfers, activez cette option",
$f:"Paquets",Uf:"Inventaire",ca:"Prix Min.",ba:"Combien",xb:"Vendre des Articles",wb:"Rechercher dans",Wf:"Couleur du Mat\u00e9riau",Vf:"Couleur de l`Article",cg:"Entrep\u00f4t",yb:"Basculer vers Mat\u00e9riaux",bg:"Basculer vers Articles",ag:"Vendre des Mat\u00e9riaux",tb:"Veuillez entrer un nom d`article valide, une fourchette de prix et une quantit\u00e9.",ub:"Aucun article correspondant trouv\u00e9 dans les emplacements de recherche s\u00e9lectionn\u00e9s.",vb:"Tous les articles ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",
zk:"Tous les mat\u00e9riaux ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",Yf:"Si vous souhaitez vendre des articles \u00e0 un prix fixe, vous pouvez entrer la m\u00eame valeur pour le prix minimum et maximum.",Zf:"Cette fonctionnalit\u00e9 est encore exp\u00e9rimentale, utilisez-la avec prudence. Si vous ne fixez pas un prix, les articles seront list\u00e9s al\u00e9atoirement entre le prix minimum et maximum que vous entrez.",mk:"D\u00e9finit le maximum d`or que le bot d\u00e9pensera par cycle.",
Ma:"Le bot commencera \u00e0 faire des offres sur tout article de nourriture, si activ\u00e9. Vous n`avez pas besoin d`activer les bascules gladiateur/mercenaire.",wd:"Le bot ne fera pas d`offres sur les ench\u00e8res des alli\u00e9s.",xd:"Ignorer la combinaison Pr\u00e9fixe/Suffixe lors de la recherche d`un objet \u00e0 la vente aux ench\u00e8res.",Ej:"S\u00e9lectionnez les types d\u2019objets que vous souhaitez fondre.",Fj:"S\u00e9lectionnez les couleurs que vous souhaitez fondre.",Gj:"S\u00e9lectionnez le niveau des objets que vous souhaitez fondre.",
Hj:"S\u00e9lectionnez le marteau que vous voulez utiliser.",Ij:"Notez que le cercle vert et rouge \u00e0 c\u00f4t\u00e9 de la premi\u00e8re case sert \u00e0 activer/d\u00e9sactiver la r\u00e8gle.",Jj:"Si vous voulez fondre al\u00e9atoirement n\u2019importe quelle couleur ou type, vous pouvez activer `Fondre al\u00e9atoirement si aucune condition n\u2019est remplie? (Derni\u00e8re option activ\u00e9e dans la vid\u00e9o du tutoriel)",uj:"R\u00e9parer avant de fondre",ye:"S\u00e9lectionner Monstre",
me:"Utiliser Sablier/Rubis?",tk:"Utiliser Rubis?",pe:"Utiliser Mobilisation?",oe:"Utiliser Potion de Vie?",le:"Pourcentage de Soin (%)",we:"Nombre d'Attaques",ne:"Intervalle d'Attaque (en secondes)",je:"Attaques Effectu\u00e9es",ke:"Sabliers Restants",ue:"Note : Utilise des potions de vie pour gu\u00e9rir, pas de nourriture.",ve:"Note : Si les attaques s'arr\u00eatent pr\u00e9matur\u00e9ment, essayez 'R\u00e9initialiser les Attaques'.",ze:"D\u00e9marrer",xe:"R\u00e9initialiser",Ae:"Arr\u00eater",
Be:"Param\u00e8tres d'Exp\u00e9dition (Cliquez pour minimiser)",qe:"Monstre 1",re:"Monstre 2",se:"Monstre 3",te:"Monstre 4",Ck:"R\u00e9parer avant de fondre",Ci:"Cette option utilisera cervisia lorsque votre premium expirera.",ej:"Cette option permet d'activer et de choisir les huiles parmi les r\u00e9compenses des dieux. Elle peut utiliser les huiles num\u00e9ro 1 et 3 sur le personnage, mais la num\u00e9ro 2 ne sera prise que pour les paquets.",Ai:"Cette option utilisera des buffs au moment que vous avez fix\u00e9. Elle trouvera les buffs dans les paquets et les appliquera au personnage.",
Yi:"Cette option vous m\u00e8nera aux enfers. N'oubliez pas d'activer la Connexion Automatique depuis l'onglet Extras, sinon vous pourriez \u00eatre d\u00e9connect\u00e9 en entrant aux enfers [Bug du Jeu]",Sb:"Le bot choisit normalement entre 3 et 6 essais al\u00e9atoires pour attaquer la liste d'ar\u00e8ne. Si vous activez cette option, il parcourra votre liste jusqu'\u00e0 ce qu'il puisse attaquer quelqu'un. Cela peut prendre du temps.",rj:"Cette option est uniquement pour les licences premium. Elle simule l'attaque avant d'attaquer un utilisateur pour un taux de victoire de 75%.",
zd:"Vous n'avez pas besoin d'activer l'interrupteur principal de l'ench\u00e8re pour activer cette option.",$j:"Cette option rafra\u00eechira la page chaque seconde quand l'ench\u00e8re est en \u00e9tat -Tr\u00e8s Court- pour ench\u00e9rir constamment et gagner l'ench\u00e8re.",Cj:"Si aucune des conditions de fusion n'est remplie, il fusionnera al\u00e9atoirement. Assurez-vous de s\u00e9lectionner le type et la couleur de l'objet.",Dj:"Cette option ne fusionnera que les objets de l'inventaire. Elle ignorera les objets dans les paquets.",
Na:"Articles aux Ench\u00e8res",fg:"Articles de Mercenaire",Mb:"Articles de Boutique",li:"Articles Uniques",yj:"D\u00e9finir le fond en noir [Augmente les performances]",zj:"D\u00e9placer les boutons GLDBot en bas \u00e0 gauche?",Di:"Attaquer le cirque sans soigner",Yj:"Prendre l'or des paquets si n\u00e9cessaire?",Zj:"L'or a \u00e9t\u00e9 pris des paquets pour l'entra\u00eenement",Cl:"Aucun or n'a \u00e9t\u00e9 trouv\u00e9 dans les paquets pour l'entra\u00eenement",Vj:"Objets R\u00e9par\u00e9s",
Oj:"Attaques en Ar\u00e8ne",Qj:"Attaques au Cirque",qd:"Objets R\u00e9initialis\u00e9s",Tj:"Attaques en Exp\u00e9dition",Sj:"Attaques en Donjon",Wj:"Attaques dans l'Underworld",Pj:"Argent Gagn\u00e9 en Ar\u00e8ne",Rj:"Argent Gagn\u00e9 au Cirque",Al:"Objets Fondus",Uj:"Or Recycl\u00e9",Pi:"Bataille de Guilde",Ri:"Param\u00e8tres de Guilde",Qi:"Guild Name",Wk:"Attaquera les guildes au hasard.",Bi:"R\u00e9initialiser les Statistiques",xh:"Stockage de l'Or",Oi:"Attaquer une Guilde Al\u00e9atoire",gl:"GLDBot\u00a0: utilisez les d\u00e9s pour rafra\u00eechir la bo\u00eete myst\u00e8re et trouver des objets de valeur avant de les ouvrir (etc. Costumes). Cliquez sur \u00ab\u00a0D\u00e9marrer\u00a0\u00bb pour ouvrir les coffres.\u00a0",
Ec:"Bois",uc:"Cuivre",yc:"Fer",Ac:"Cuir",Fc:"Fil de laine",vc:"Boule de coton",xc:"Chanvre",wc:"Bande de gaze",Bc:"Toile de lin",zc:"Jute",Dc:"Bande de velours",Cc:"Fil de soie",Nc:"Fourrure",Hc:"\u00c9clat osseux",Qc:"\u00c9caille",Kc:"Griffe",Mc:"Canine",Lc:"\u00c9caille de dragon",Ic:"Corne de taureau",Pc:"Glande \u00e0 venin",Jc:"Touffe de poils de Cerb\u00e8re",Oc:"\u00c9caille d`Hydre",Rc:"Plume du Sphinx",Sc:"Cuir de Typhon",pc:"Lapis-lazuli",jc:"Am\u00e9thyste",ic:"Ambre jaune",kc:"Aigue-marine",
qc:"Safir",nc:"Grenat",mc:"\u00c9meraude",lc:"Diamant",oc:"Jaspe",rc:"Sugilith",cc:"Venin de scorpion",fc:"Teinture d`endurance",Zb:"Antidote",Yb:"Adr\u00e9naline",ec:"Teinture de r\u00e9v\u00e9lation",bc:"Potion de perception",$b:"Essence de reflet",ac:"Flacon du rayonnement",hc:"Eau de l`oubli",dc:"Essence d`\u00e2me",od:"Sceau aquatique",hd:"Rune protectrice",fd:"Gravure terrestre",nd:"Totem gu\u00e9risseur",md:"Talism\u00e1n de puissance",kd:"Pierre de fortune",gd:"Pierre du feu",ld:"Rune temp\u00e9tueuse",
jd:"Rune t\u00e9n\u00e9breuse",Wc:"Cristal",Vc:"Bronze",$c:"Obsidienne",cd:"Argent",dd:"Soufre",Yc:"Minerai d`or",bd:"Quartz",ad:"Platine",Uc:"Almandin",Xc:"Cuprit",Zc:"Pierre infernale",xi:"Attaquer al\u00e9atoirement?",yi:'D\u00e9sactivez \u00e9galement le param\u00e8tre "Trier les joueurs dans l\'ar\u00e8ne par niveau" dans crazy-addon.',Ng:"Accepter uniquement les qu\u00eates bas\u00e9es sur le type de dieu.",Oa:"Buff Automatique",Nd:"Utiliser uniquement en enfer?",ug:"Nouvelle R\u00e8gle",sg:"Le Nom Contient",
isUnderworldItem:"Est-ce un objet du monde souterrain?",Ue:"Ignorer les Mat\u00e9riaux",fk:"Utiliser la pri\u00e8re",si:"Utiliser le sacrifice",bk:"Utiliser des v\u00eatements pour entrer dans le monde souterrain",ii:"Lorsque vous \u00eates dans le monde souterrain, n`acceptez que les qu\u00eates li\u00e9es au monde souterrain ?",hi:"Si activ\u00e9, vous devez entrer les noms des objets du monde souterrain. Si le bot trouve ces objets dans le monde souterrain, il acceptera la qu\u00eate.",Jk:"Objet de Qu\u00eate du Monde Souterrain",
Tk:"Entrez le nom du mat\u00e9riau",qk:"Le robot adore les d\u00e9s ! Ils l'aident \u00e0 trouver des v\u00eatements dans les coffres. Mais s'il n'y a pas de d\u00e9s, le robot ouvre quand m\u00eame les coffres, en esp\u00e9rant trouver des v\u00eatements cool (mais il pourrait ne rien trouver !)",Bj:"Fondre les coffres",be:"Activer l'ar\u00e8ne",Fg:"Prioriser la liste des ar\u00e8nes ?",Gg:"Prioriser la liste des cirques ?",Ud:"D\u00e9sactiver le menu de journalisation",ah:"Valeur minimale de r\u00e9compense en or",
bh:"Le robot ench\u00e9rira sur des articles al\u00e9atoires.",Og:"Si activ\u00e9, le Focus sur les qu\u00eates suivra le chemin le plus court pour terminer le donjon.",zh:"Lancer les d\u00e9s automatiquement ?",Ah:"Utilisez le lancer de d\u00e9s avec prudence, il continuera \u00e0 utiliser le premier d\u00e9 jusqu'\u00e0 ce que vous d\u00e9sactiviez l'option.",gh:"Progression de la recherche",Vg:"Le temps de recharge pour la r\u00e9paration par d\u00e9faut est de 10 minutes.",pg:"Condition minimale",
Sd:"Article actuel sur l'\u00e9tabli [Effacer si le bot se met en pause de mani\u00e8re inattendue]",rf:"Ressources de forge stock\u00e9es avec succ\u00e8s dans l'horreum.",lf:"V\u00e9rification du march\u00e9 pour les articles...",qb:"Article d\u00e9plac\u00e9 sur l'\u00e9tabli.",Gf:"Article r\u00e9par\u00e9 et \u00e9quip\u00e9 avec succ\u00e8s.",Hf:"Article r\u00e9par\u00e9 avec succ\u00e8s.",xk:"La r\u00e9paration a \u00e9chou\u00e9. La page sera rafra\u00eechie.",Df:"Ramassage des mat\u00e9riaux...",
Qf:"En attente de r\u00e9paration...",Ff:"La r\u00e9paration a commenc\u00e9 pour .",rb:"R\u00e9paration : D\u00e9placement de l'article de l'inventaire vers le sac",Ef:"R\u00e9paration : D\u00e9placement de l'article de l'\u00e9tabli vers le paquet.",nf:"Impossible de trouver suffisamment de mat\u00e9riaux. D\u00e9sactivation de l'emplacement de r\u00e9paration ",Af:"Recherche d'articles \u00e0 acheter pour cacher de l'or aux ench\u00e8res...",hf:"V\u00e9rification des articles expir\u00e9s dans les paquets...",
jf:"R\u00e9initialisation de l'article r\u00e9ussie.",kf:"Aucun espace vide ou or pour r\u00e9initialiser.",sf:"Assurez-vous d'avoir les droits de vente sur le march\u00e9 de guilde !",tf:"Pas assez d'or ou aucun article \u00e0 acheter. Attente de 30 secondes pour rafra\u00eechir.",mb:"Le magasin a \u00e9t\u00e9 rafra\u00eechi.",nb:"Erreur lors de la gu\u00e9rison.",wf:"Pas de Rubis ou de Tissu, d\u00e9sactivation des options.",xf:"Aucun article de gu\u00e9rison trouv\u00e9 dans les paquets.",ob:"Aucun article appropri\u00e9 trouv\u00e9",
yf:"Les aliments ont \u00e9t\u00e9 ramass\u00e9s. Fin du processus.",zf:"Au moins un aliment a \u00e9t\u00e9 ramass\u00e9. Fin du processus.",pb:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",uf:"Obtention de la nourriture des paquets.",vf:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",lb:"Plus d'articles de gu\u00e9rison. Attente de 30 secondes.",kb:"Points de vie r\u00e9cup\u00e9r\u00e9s.",za:"Rien \u00e0 faire alors je vais prier !",
Mf:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9 et Villa Medici.",Nf:"En attente de Villa Medici, actualisation dans 60 secondes.",Of:"Quitt\u00e9 les Enfers.",Pf:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9.",Bf:"V\u00e9rification des huiles divines...",Cf:"Les huiles divines ont \u00e9t\u00e9 ramass\u00e9es.",xa:"Attaque r\u00e9ussie du joueur dans l'AR\u00c8NE : ",ya:"Attaque r\u00e9ussie du joueur dans le CIRQUE : ",ff:"V\u00e9rification des ench\u00e8res ! Veuillez patienter...",
gf:"Mise aux ench\u00e8res d'articles. Veuillez patienter...",If:"Article fondu automatiquement : ",Jf:"Fusion de l'article : ",Kf:"Pas assez d'or pour fondre. Or requis : ",Lf:"FONDRE : Recherche d'articles \u00e0 fondre...",yk:"Recherche d'articles \u00e0 fondre...",mf:"V\u00e9rification de la disponibilit\u00e9 des costumes...",qf:"Donn\u00e9 : ",pf:"Lancer des d\u00e9s...",He:"Underworld Farm [Manual, Beta]",Ge:"Farm Location",Ie:"Attention\u00a0: activez cette fonctionnalit\u00e9 apr\u00e8s avoir d\u00e9verrouill\u00e9 la cr\u00e9ature que vous souhaitez attaquer, elle n'attaquera pas automatiquement pour d\u00e9bloquer le monstre.",
Fe:"Farm Enemy",Gd:"Connexion Automatique",Hd:"Vous devez autoriser les pop-ups depuis l'\u00e9cran du lobby de GameForge. Consultez la documentation pour savoir comment faire.",Cg:"Mettre le Bot en Pause",Dg:"Mettre le Bot en pause (Minutes)",De:"Date d'Expiration",xg:"Acheter uniquement de la nourriture ?",yg:"Si vous activez cette option, le bot ignorera vos s\u00e9lections et ach\u00e8tera automatiquement de la nourriture sans rien saisir.",Ab:"Montant total maximal d'or \u00e0 d\u00e9penser",
zb:"Montant maximal d'or par aliment \u00e0 d\u00e9penser",wg:"Le bot v\u00e9rifiera les huiles toutes les 60 minutes",Sh:"D\u00e9finit une minuterie pour v\u00e9rifier les temps de fusion.",Ph:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion lorsque vous n'avez pas d'or.",Rh:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion si vous n'avez pas l'objet disponible.",Kh:"D\u00e9finit une minuterie pour r\u00e9parer et v\u00e9rifier vos objets.",Jh:"D\u00e9finit une minuterie pour v\u00e9rifier l'or retenu sur le march\u00e9 de la guilde.",
Fh:"D\u00e9finit une minuterie pour l'option de retenue d'or aux ench\u00e8res.",Bh:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans l'ar\u00e8ne pour attaquer.",Gh:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans le cirque pour attaquer.",Yh:"D\u00e9finit une minuterie pour entra\u00eener vos statistiques.",Mh:"D\u00e9finit une minuterie pour r\u00e9initialiser les objets expir\u00e9s.",Wh:"D\u00e9finit une minuterie pour stocker les mat\u00e9riaux de forge dans l'horreum.",
Dh:"D\u00e9finit une minuterie pour v\u00e9rifier les ench\u00e8res des gladiateurs et des mercenaires.",Oh:"D\u00e9finit une minuterie pour rechercher des objets aux ench\u00e8res et en boutique.",Hh:"D\u00e9finit la minuterie d'envoi de dons \u00e0 la guilde.",Me:"Or D\u00e9plac\u00e9",Zd:"Ne vendez pas d'articles de la fonderie et de la liste des ench\u00e8res",hh:"Automatisation de la Boutique",jh:"Param\u00e8tres de Recherche d'Objets",ih:"Utilisez cet outil pour rechercher des objets. Ajoutez simplement les objets \u00e0 la liste, sp\u00e9cifiez la quantit\u00e9 de tissu et lancez la recherche.",
kh:"Tissus \u00e0 Utiliser :",lh:"Combien de tissus utiliser ?",ia:"Full Entrez le Nom de l'Objet",Lb:"Entrez le Niveau de l'Objet",nh:"Qualit\u00e9 de l'Objet",mh:"Nom de l'Objet Ici",oh:"Commencer la Recherche",ph:"Sauter et Continuer",qh:"Arr\u00eater la Recherche",Je:"Acheter le moins cher ou le plus cher?",rg:"Le Plus Cher",Pd:"Le Moins Cher",fa:"S\u00e9lectionnez une Option",de:"Mettre en surbrillance les objets du monde souterrain",Ke:"Concentrez-vous sur la qu\u00eate\u00a0?",El:"Utiliser Ruby s'il n'y a pas de tissu ?",
Pa:"\u00c9vitez d'attaquer les m\u00eames personnes pour ne pas \u00eatre signal\u00e9. \u00catre signal\u00e9 augmente les chances d'\u00eatre banni.",tl:"Fondre Green ?",Ig:"Ne pas accepter les qu\u00eates al\u00e9atoires si des filtres sont entr\u00e9s ?",Gc:"Qualit\u00e9 maximale des mat\u00e9riaux \u00e0 utiliser",Li:"Activer la recherche de mercenaires",bl:"Cliquez sur `Vendre Tout S\u00e9lectionn\u00e9` pour vendre tous les objets. Assurez-vous d`avoir de l`espace vide de 2x3 dans votre premi\u00e8re (1) sac. Pour collecter de l`or en masse, filtrez l`or et utilisez `S\u00e9lectionner S\u00e9lectionn\u00e9s ou Tout S\u00e9lectionner`.",
Nj:"\ud83d\udd25 : Ajoute l`objet \u00e0 la liste de fusion.",zi:"\ud83d\udd28 : Ajoute l`objet \u00e0 la liste des ench\u00e8res.",tj:"Actualisez la boutique avec du tissu lorsqu`elle est pleine (Vous devrez vendre \u00e0 nouveau apr\u00e8s)",hj:"Page:",oj:"Arr\u00eater",mj:"Vendre Cette Page",jj:"S\u00e9lectionner S\u00e9lectionn\u00e9s",ij:"Tout S\u00e9lectionner",pj:"Param\u00e8tres d`Emballage Automatique",nj:"Envoyer les Ressources",kj:"Vendre Tout S\u00e9lectionn\u00e9",qa:"Type d`Objet",U:"Armes",
M:"Boucliers",I:"Armures",L:"Casques",K:"Gants",J:"Bottes",T:"Anneaux",R:"Amulettes",oa:"Utilisables (Nourriture)",va:"Am\u00e9liorations",fj:"Boosts",sa:"Recettes",ra:"Mercenaires",ua:"Outils de Forge",ta:"Parchemins",Ga:"Renforcements",Fa:"Objets d`\u00c9v\u00e9nement",ed:"Mat\u00e9riaux de Forge",gj:"Or",P:"Tout",jl:"Qualit\u00e9",wa:"Blanc",C:"Vert",B:"Bleu",D:"Violet",G:"Orange",S:"Rouge",lj:"Options de Vente",Aj:"Ignorer la Combinaison Pr\u00e9fixe/Suffixe ?",Si:"Combien de nourriture acheter/cueillir ?",
Gi:"Normal",Fi:"Interm\u00e9diaire",Ei:"Difficile",Da:"Standard",ml:"R\u00e9paration Correction d`Enlisement",vk:"D\u00e9sactivez l`Entr\u00e9e en Enfer si vous souhaitez d\u00e9sactiver le Donjon/Cirque/Arenas. Si vous \u00eates entr\u00e9 en Enfer manuellement, vous devrez activer le Mode Enfer.",Qd:"Choisir le costume des Enfers",vi:"Porter le costume des Enfers quand il est disponible ?",ai:"Tutoriel dentra\u00eenement : Indiquez combien de fois vous souhaitez entra\u00eener les statistiques et d\u00e9finissez leurs priorit\u00e9s. Le bot nentra\u00eenera pas sans quune priorit\u00e9 soit d\u00e9finie. Si une priorit\u00e9 est configur\u00e9e mais quil ne reste plus de statistiques \u00e0 entra\u00eener, le bot continuera avec la statistique s\u00e9lectionn\u00e9e.",
Qk:"Quest",yh:"Conserver l'Or aux Ench\u00e8res ?",Eg:"Mettre en Pause le Bot Al\u00e9atoirement pour travailler comme [Phase de Test] :",Xg:"R\u00e9initialiser les Objets Expir\u00e9s",Gb:"Remarque : En activant cette option, le bot vendra les objets expir\u00e9s \u00e0 venir des paquets sur le march\u00e9 de la guilde, puis annulera pour r\u00e9initialiser le temps d'expiration. La guilde est requise. Assurez-vous d'avoir un espace vide de 3x3 dans vos sacs.",aa:"Conserver l'Or : Le bot conservera cet or dans le sac :",
dg:"Or Maximum : Le bot d\u00e9pensera lorsque l'or sera sup\u00e9rieur \u00e0",rl:"Fonderie",xl:"Fonderie Param\u00e8tres",Kj:"Fonderie Liste",yl:"Ajouter un pr\u00e9fixe ou un suffixe, une fois qu`il l`aura trouv\u00e9 dans les paquets, il le fondera automatiquement:",wl:"Fusion d'item:",Vb:"Cliquez sur l`\u00e9l\u00e9ment que vous souhaitez r\u00e9parer. Essayez de faire de la place dans votre inventaire",Kk:"S`applique-t-il uniquement aux mercenaires ?",Nk:"L'ench\u00e8re ach\u00e8te que lorsque le march\u00e9 est proche de la fin.",
Mk:"Assurez-vous que le SECOND ONGLET D'INVENTAIRE est vide. Le bot trouvera et mettra l'objet dans le deuxi\u00e8me onglet puis la prochaine fois que la page est actualis\u00e9e, il fondra l'objet.",Vi:"Gu\u00e9risseur & Buffs",nl:"Pas assez d'or pour fondre. Or requis:",ql:"Ench\u00e8re ignor\u00e9e: un membre de la guilde a d\u00e9j\u00e0 mis\u00e9 pour l'objet ",pl:"Ench\u00e8re ignor\u00e9e: Vous avez d\u00e9j\u00e0 mis\u00e9 pour cet objet ",advanced:"Avanc\u00e9e",arena:"Ar\u00e8ne",ma:"Attaque automatique",
Tb:"Eviter l'attaque",ka:"Ajouter un joueur",la:"Entrez le nom du joueur (Same Server)",Yk:"Arr\u00eater le bot en cas de manque de nourriture?",circusTurma:"Circus Turma",Hi:"Difficult\u00e9",dungeon:"Donjon",Ii:"Param\u00e8tres du donjon",eventExpedition:"Event Exp\u00e9dition",expedition:"Expedition",Mi:"Param\u00e8tres d'expedition",vj:"S\u00e9lectionner un monstre",$k:"Plus haut",Zk:"Mettez vos objets de soin dans la premi\u00e8re page de votre inventaire",tc:"Dans",eh:"Utiliser les v\u00eatements de travail pour renouveler la boutique?",
Ti:"Pourcentage de gu\u00e9rison",dk:"Acheter de la nourriture dans la boutique?",ek:"Utiliser la gu\u00e9rison \u00e0 partir du paquet?",ak:"Utiliser Cervisia?",ck:"Utiliser des oeufs?",cl:"Dernier utilis\u00e9",location:"Emplacement",Strength:"Force",Dexterity:"Adresse",Agility:"Agilit\u00e9",Constitution:"Constitution",Charisma:"Charisme",Intelligence:"Intelligence",Zh:"Param\u00e8tres d'entrainement",$h:"S\u00e9lectionnez les states que vous souhaitez entra\u00eener. L'entra\u00eenement commencera une fois que vous aurez assez d'or.",
Tc:"Action suivante",cj:"Non",dj:"Normal",hl:"Adversaire",il:"Niveau de l'adversaire",sj:"Qu\u00eates",random:"Al\u00e9atoire",ol:"Param\u00e8tres",zl:"Bient\u00f4t...",type:"Cliquez sur les ic\u00f4nes pour activer les types de qu\u00eate.",Gl:"Oui",A:"Ench\u00e8re",pd:"Ajouter des objets",Xj:"Stocker automatiquement les ressources de la forge",Bl:"Soumettre",al:"Intervalle : ",Rk:"Activer l'ench\u00e8re automatique",Sk:"Ne pas ench\u00e9rir si un membre de la guilde a d\u00e9j\u00e0 ench\u00e9ri",
Dl:"Tutoriel",Ub:"S\u00e9lectionnez \u00e0 partir des boutons ci-dessus pour choisir si vous souhaitez affronter l'adversaire le plus faible de l'ar\u00e8ne ou l'adversaire de niveau le plus \u00e9lev\u00e9.",Lk:"Pour commencer, ajoutez un article \u00e0 la liste (par exemple, `Lucius`). Une fois ajout\u00e9, l'outil recherchera l'article et affichera les r\u00e9sultats de la recherche sur le c\u00f4t\u00e9 gauche de l'\u00e9cran. Il sera \u00e9galement recherch\u00e9 \u00e0 des fins d'ench\u00e8re automatique. Si vous activez l'ench\u00e8re automatique, l'outil recherchera l'article \u00e0 des intervalles r\u00e9guliers en fonction du nombre que vous mettez dans la case d'intervalle. Si l'outil trouve l'article et que vous avez assez d'argent, il ench\u00e9rira automatiquement pour vous. *Note* pour rechercher des articles uniques dans les boutiques, vous devez ajouter au moins 1 article al\u00e9atoire \u00e0 la liste de recherche.",
Uk:"Le num\u00e9ro de la cr\u00e9ature peut \u00eatre s\u00e9lectionn\u00e9 \u00e0 partir des boutons ci-dessus. Le num\u00e9ro 1 repr\u00e9sente la cr\u00e9ature la plus \u00e0 gauche. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",Ji:"S\u00e9lectionnez la difficult\u00e9 du donjon depuis le dessus. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",Ui:"Param\u00e8tres de gu\u00e9rison",Ki:"Stocker l'or exc\u00e9dentaire dans la guilde en achetant des objets du march\u00e9 de la guilde. -> Or Min.",
dl:"D\u00e9placer tout",el:"D\u00e9placer les s\u00e9lectionn\u00e9s",Ok:"Auto gu\u00e9rison",Pk:"Pourcentage de gu\u00e9rison automatique",Fl:"Ruby",zg:"Param\u00e8tres g\u00e9n\u00e9raux",wj:"Tout vendre",xj:"Vendre s\u00e9lectionn\u00e9s",ja:"Armes",ga:"Boucliers",W:"Armure de poitrine",Z:"Casques",Y:"Gants",ha:"Chaussures",ea:"Anneaux",V:"Amulettes",ni:"Utilisable",mi:"Am\u00e9liorations",Qg:"Nourriture",gg:"Parchemin de mercenaire",Sg:"Renforts",rd:"Ajouter un D\u00e9lai Al\u00e9atoire",sd:"Vous pouvez ajouter un d\u00e9lai al\u00e9atoire au bot ici.",
Fb:"R\u00e9parer",sl:"Fonder uniquement les Bleus?",vl:"Fonder uniquement les Violets?",ul:"Fonder uniquement les Oranges?",Lj:"Tout Fondre dans le 2e Onglet?",Mj:"Cela ignorera les s\u00e9lections de couleur",Qa:"Effacer l'Historique",th:"Fondre",Ad:"Search",tg:"Ench\u00e8re Automatique",Bd:"Une utilisation excessive des ench\u00e8res peut entra\u00eener un bannissement. Il est recommand\u00e9 de d\u00e9sactiver les autres fonctionnalit\u00e9s d ench\u00e8res pour \u00e9viter les conflits potentiels. Cette fonctionnalit\u00e9 ralentira le bot..",
dh:"Rechercher dans l'Ench\u00e8re des Gladiateurs",fh:"Rechercher dans l'Ench\u00e8re des Mercenaires",Jd:"Miser de la Nourriture?",eg:"Mise Maximale",Kd:"Miser si le statut est inf\u00e9rieur \u00e0",Ld:"Objets Mis\u00e9s",kk:"Langue de l'Ench\u00e8re",lk:"\u00c0 partir de la mise \u00e0 jour 2.9.4, veuillez r\u00e9initialiser la langue ou R\u00c9INITIALISER LE BOT. Assurez-vous que toutes les informations sont correctes, sinon les ench\u00e8res ne fonctionneront pas.",vd:"Vous pouvez ajouter des objets pour les rechercher dans le march\u00e9 et les ench\u00e8res. Il montrera \u00e9galement les objets violets dans le march\u00e9 une fois que vous aurez ajout\u00e9 un objet \u00e0 la liste. Si vous souhaitez activer les ench\u00e8res automatiques, utilisez les options ci-dessous.",
ik:"Utilisez les ench\u00e8res avec prudence!",jk:"Les ench\u00e8res automatiques font trop de requ\u00eates au serveur et peuvent entra\u00eener un bannissement si elles sont utilis\u00e9es en permanence!",Ug:"Renouveler les Points d'\u00c9v\u00e9nement avec des Rubis?",fe:"Activer l'Huile Automatique",nk:"R\u00e9cup\u00e9rer Automatiquement les Huiles Sacr\u00e9es",Ak:"Vitesse de V\u00e9rification des Qu\u00eates",La:"Attaquer les Membres du Gremio ?",Ja:'Ajouter automatiquement les personnes \u00e0 la liste "Attaque" lorsque plus de X OR est vol\u00e9.:',
Ka:'Ajouter automatiquement les personnes \u00e0 la liste "\u00c9viter l\'Attaque" lorsque vous perdez contre elles.:',Jb:"Attaques au Tableau des Scores",Qb:"Tr\u00e8s Long",sb:"Long",Bb:"Moyen",Nb:"Court",Rb:"Tr\u00e8s Court",ge:"Entrer dans le Monde Souterrain si HP >",Pg:"Vitesse de V\u00e9rification des Qu\u00eates",Hg:'Par d\u00e9faut, c\'est "3x". Si le bot pose des probl\u00e8mes avec les qu\u00eates, changez la vitesse des qu\u00eates en fonction de la vitesse de votre serveur.',Ne:"S\u00e9lection du Sac de Soins",
he:"Si vous renouvelez manuellement les points, vous devez cliquer sur le bouton ci-dessus \"Actualiser l'exp\u00e9dition d'\u00e9v\u00e9nement si bloqu\u00e9e !",sk:"Vous devez activer au moins l'une des options suivantes : exp\u00e9dition, donjon, ar\u00e8ne ou cirque pour commencer l'exp\u00e9dition d'\u00e9v\u00e9nement.",Rg:"Actualisez l'exp\u00e9dition d'\u00e9v\u00e9nement en cas de blocage !",cb:"Prot\u00e9ger les Alli\u00e9s ?",Gk:"Laissez tous les param\u00e8tres d\u00e9sactiv\u00e9s si vous souhaitez fondre en utilisant les paquets contenant les objets de la liste. Cependant, vous pouvez toujours choisir les couleurs.",
pk:"Personnage(D\u00e9sactiv\u00e9) / Mercenaire(Activ\u00e9)",Dk:"R\u00e9parer les Deux ?",Hk:"Minuteries",Timers:"Entrez le nombre de minutes pour chaque minuteur ci-dessous ou laissez-le par d\u00e9faut.",gb:"Activer l'Attaque au Tableau des Scores:",Hb:"S\u00e9lectionner la Fourchette pour Attaquer",Ib:"Le bot attaquera al\u00e9atoirement depuis la liste du tableau des scores.",ib:"Attaque de Ligue",fb:"Activer l'Attaque de Ligue:",Db:"Attaquer Al\u00e9atoirement",Eb:"Attaquer du plus bas au plus haut",
hk:"Le bot \u00e9vitera par d\u00e9faut d'attaquer les membres du gremio.",Ce:"Lieu d'Exp\u00e9dition:",Cd:"Collecter Automatiquement les Bonus:",rh:"Passer le Boss",ae:"Lieu de Donjon:",$g:"R\u00e9initialiser en cas de perte?",Qe:"Param\u00e8tres de l'Enfer",Re:"Configurez vos param\u00e8tres de pourcentage de gu\u00e9rison depuis l'onglet Gu\u00e9rison, et assurez-vous que l'interrupteur Gu\u00e9rison est activ\u00e9. Si l'entr\u00e9e dans le monde souterrain vous d\u00e9connecte, allez au lobby et activez la case \u00e0 cocher Connexion Automatique.",
Oe:"Difficult\u00e9 de l'Enfer",Fd:"Entrer Automatiquement dans l'Enfer: / Enfer Mode",pi:"Utiliser Mobilisation si les points = 0",ui:"Utiliser les Rubis?",ie:"Sortir du monde souterrain s'il n'y a plus de points?",ci:"Le bot essaiera d'abord d'utiliser Villa Medici, si vous ne l'avez pas, il utilisera la potion de gu\u00e9rison. N'oubliez pas d'activer l'interrupteur de Gu\u00e9rison.",ki:"L'entr\u00e9e automatique dans le monde souterrain d\u00e9sactivera le donjon/l'ar\u00e8ne/le cirque lors de l'entr\u00e9e dans le monde souterrain.",
Ik:"Param\u00e8tres de Gu\u00e9rison du Monde Souterrain",ti:"Utiliser Villa Medici?",ri:"Utiliser la Potion de Gu\u00e9rison?",Rf:"INFO: Le bot recherchera les objets sur le march\u00e9 toutes les minutes s\u00e9lectionn\u00e9es, ce qui peut interrompre les attaques pendant la recherche.",ee:"Activer la Recherche sur le March\u00e9:",Sf:"Intervalle de Recherche sur le March\u00e9 en Minutes:",Tf:"Sugg\u00e9r\u00e9: 10 minutes.",$e:"Param\u00e8tres de l'Objet:",Ye:"Le Nom de l'Objet Inclut",N:"Prix Max",
af:"Type d'Objet",Ze:"Raret\u00e9 de l'Objet",Od:"Acheter avec Lien d'\u00c2me?",cf:"Objets \u00e0 Acheter",bf:"Tentative d'achat d'objets avec des packs si l'un d'eux correspond au prix maximum indiqu\u00e9.:",Md:"Objets Achet\u00e9s:",Mg:"Ignorer le Filtre de Qu\u00eates",Lg:"Saisissez des mots-cl\u00e9s pour filtrer les qu\u00eates que vous ne souhaitez pas accepter. You can also use this to accept quests by their reward using keywords.",X:"Saisir un Mot-cl\u00e9",H:"Ajouter",Tg:"Supprimer",Rd:"Effacer",
Jg:"Accepter le Filtre de Qu\u00eates",Kg:"Saisissez des mots-cl\u00e9s pour choisir les qu\u00eates \u00e0 accepter. Cela ignorera les types de qu\u00eates",Ba:"Ignorer les Qu\u00eates Temporelles ?",Bk:"Qu\u00eates",Dd:"Costume Automatique",oi:"Utiliser le Costume ?",Id:"Combat de Base",$d:"Combat en Donjon",Ed:"Le bot ne portera Dis Pater Normal et Medium que si vos points d'exp\u00e9dition/donjon sont de 0.",Pe:"Param\u00e8tres de Gu\u00e9rison en Enfer",ud:"Attaquer le Boss quand disponible ?",
jb:"L'attaque en Ligue se d\u00e9sactivera apr\u00e8s 5 attaques infructueuses.",Se:"Huiles Sacr\u00e9es",og:"Nom de l'Objet",da:"Niveau Minimum de l'Objet",Aa:"Qualit\u00e9 Minimum de l'Objet",td:"Appliquer/R\u00e9initialiser la Minuterie",Ve:"Ignorer la Combinaison de Pr\u00e9fixe/Suffixe",wi:"Oui",vg:"Non",Ha:"Ajouter un Pr\u00e9fixe",Ia:"Ajouter un Suffixe",uh:"Liste des Objets \u00e0 Ignorer pour la Fusion",Cb:"Pr\u00e9fixe",Ob:"Suffixe",Zg:"R\u00e9initialiser les Objets Expir\u00e9s",vh:"Fusionner au Hasard depuis les Paquets ?",
wh:"Onglet Fusion",hb:"Extras",yd:"Ench\u00e8res",Xf:"March\u00e9",Pb:"Minuteries",Uh:"Fusion",Th:"Fusionner s'il n'y a pas assez d'or",Qh:"Fusionner s'il n'y a pas d'objet",Ca:"R\u00e9paration",Ih:"Garder de l'Or sur le March\u00e9 de Guilde",Eh:"Garder de l'Or aux Ench\u00e8res",Xh:"Entra\u00eenement",Lh:"R\u00e9initialiser les Expir\u00e9s",Vh:"Stockage \u00e0 la Forge",Ch:"V\u00e9rification des Ench\u00e8res",Nh:"Recherche",v:"Activer",qg:"Or Minimum",Kb:"S\u00e9lectionner une Heure",eb:"Donner de l'Or \u00e0 la Guilde",
Vd:"Il donnera toutes les 5 minutes. Vous pouvez changer l'intervalle depuis l'onglet des minuteries",Te:"Combien souhaitez-vous donner ?",Wd:"Donner lorsque vous avez plus de >",ef:"Moins de <",Wg:"R\u00e9initialiser les Objets Expir\u00e9s et les Autres Param\u00e8tres",Yg:"R\u00e9initialiser dans :",wk:"Maintenez Ctrl (Cmd sur Mac) enfonc\u00e9 pour s\u00e9lectionner plusieurs objets",We:"Import/Export des Param\u00e8tres",Ee:"Exporter les Param\u00e8tres",Xe:"Importer les Param\u00e8tres",hg:"Message \u00e0 Tous les Joueurs",
ig:"[N\u00e9cessite une Cl\u00e9 Ultra Premium, message sur Discord pour l'obtenir.]",jg:"Saisir le message \u00e0 envoyer",Td:"Pour des scripts personnalis\u00e9s, contactez-nous sur Discord",lg:"Envoyer",mg:"Afficher les Joueurs",kg:"Tout S\u00e9lectionner",ng:"Tout D\u00e9s\u00e9lectionner",df:"Assurez-vous que votre inventaire ait suffisamment d'espace. Le temps de recharge est de 2 minutes."},Hh={qj:"After expedition points are consumed, travel to Germania to consume Dungeon points",gk:"Kattintson ide, ha a jav\u00edt\u00e1s beragad",
Bg:"R\u00e9szleges Jav\u00edt\u00e1s",Le:"Teljes Jav\u00edt\u00e1s",Ag:"R\u00e9szleges vagy Teljes Jav\u00edt\u00e1s",ce:"Korl\u00e1t Enged\u00e9lyez\u00e9se",Wi:"Korl\u00e1toz\u00e1s",Xi:"Ha korl\u00e1tozni szeretn\u00e9d a t\u00e1mad\u00e1sok sz\u00e1m\u00e1t az ellens\u00e9gre, enged\u00e9lyezd ezt az opci\u00f3t \u00e9s \u00e1ll\u00edtsd be a korl\u00e1tot. A bot folytatja a t\u00e1mad\u00e1st a t\u00f6bbi ellens\u00e9ggel, miut\u00e1n befejezte a kiv\u00e1lasztott sz\u00f6rny elleni t\u00e1mad\u00e1sokat.",
Yd:"Ne l\u00e9pj be az alvil\u00e1gba alvil\u00e1gi jelmezben",Xd:"Ha nem akarsz alvil\u00e1gi jelmezben az alvil\u00e1gba l\u00e9pni, enged\u00e9lyezd ezt az opci\u00f3t",ji:"Alvil\u00e1g",bi:"Alvil\u00e1gi Buffok",di:"Haszn\u00e1ld az istenek erej\u00e9t az alvil\u00e1gba l\u00e9p\u00e9s ut\u00e1n?",ei:"V\u00e1laszd ki az isteneket, akikt\u0151l er\u0151t szeretn\u00e9l nyerni:",fi:"Haszn\u00e1lj fegyver er\u0151s\u00edt\u00e9st a fegyveren?",gi:"Haszn\u00e1lj p\u00e1nc\u00e9l er\u0151s\u00edt\u00e9st a k\u00f6vetkez\u0151 felszerel\u00e9sen:",
rk:"A leh\u0171l\u00e9si id\u0151 30 perc. Ha nincs rajtad jelmez, a bot null\u00e1zza a leh\u0171l\u00e9si id\u0151t.",Fk:"Sz\u00ednek kiv\u00e1laszt\u00e1sa",Ra:"Vulcanus Kov\u00e1csm\u0171helye",Va:"Feronia F\u00f6ldi Pajzsa",Wa:"Neptunusz Foly\u00e9kony Ereje",Xa:"Aelous L\u00e9gies Szabads\u00e1ga",Ya:"Pl\u00fat\u00f3 Hal\u00e1los K\u00f6de",Za:"Juno \u00c9let Lehelete",$a:"Harag Hegyeinek Pikkelyes P\u00e1nc\u00e9lja",ab:"Sas Szemei",bb:"Saturnusz T\u00e9li \u00d6lt\u00f6z\u00e9ke",Sa:"Bubona Bikap\u00e1nc\u00e9lja",
Ta:"Mercerius Rabl\u00f3ruh\u00e1i",Ua:"Ra F\u00e9nyk\u00f6nt\u00f6se",$f:"Csomagok",Uf:"K\u00e9szlet",ca:"Min. \u00c1r",ba:"H\u00e1ny darab",xb:"T\u00e1rgyak Elad\u00e1sa",wb:"Keres\u00e9s ebben",Wf:"Anyag Sz\u00edne",Vf:"T\u00e1rgy Sz\u00edne",cg:"Rakt\u00e1r",yb:"V\u00e1lt\u00e1s Anyagokra",bg:"V\u00e1lt\u00e1s T\u00e1rgyakra",ag:"Anyagok Elad\u00e1sa",tb:"K\u00e9rj\u00fck, adjon meg \u00e9rv\u00e9nyes t\u00e1rgyn\u00e9v, \u00e1rfekv\u00e9s \u00e9s mennyis\u00e9get.",ub:"Nincsenek megfelel\u0151 t\u00e1rgyak a kiv\u00e1lasztott keres\u00e9si helyeken.",
vb:"Minden t\u00e1rgy sikeresen list\u00e1zva!",zk:"Minden anyag sikeresen list\u00e1zva!",Yf:"Ha fix \u00e1ron szeretne t\u00e1rgyakat eladni, ugyanazt az \u00e9rt\u00e9ket adja meg a min \u00e9s max \u00e1rra.",Zf:"Ez a funkci\u00f3 m\u00e9g k\u00eds\u00e9rleti, \u00f3vatosan haszn\u00e1lja. Ha nem ad meg fix \u00e1rat, az elemek v\u00e9letlenszer\u0171en ker\u00fclnek list\u00e1z\u00e1sra a megadott minimum \u00e9s maximum \u00e1r k\u00f6z\u00f6tt.",mk:"Be\u00e1ll\u00edtja a maxim\u00e1lis aranyat, amit a bot egy ciklusban elk\u00f6lt.",
Ma:"A bot licit\u00e1lni kezd minden \u00e9tel t\u00e1rgyra, ha enged\u00e9lyezve van. Nem kell enged\u00e9lyezned a gladi\u00e1tor/zsoldos kapcsol\u00f3kat.",wd:"A bot nem licit\u00e1l az sz\u00f6vets\u00e9gesei licitjeire.",xd:"Figyelmen k\u00edv\u00fcl hagyja az El\u0151tag/Ut\u00f3tag kombin\u00e1ci\u00f3t t\u00e1rgy keres\u00e9sekor az aukci\u00f3n.",Ej:"V\u00e1laszd ki azokat a t\u00e1rgyt\u00edpusokat, amelyeket be akarsz olvasztani.",Fj:"V\u00e1laszd ki azokat a sz\u00edneket, amelyeket be akarsz olvasztani.",
Gj:"V\u00e1laszd ki az t\u00e1rgyak szintj\u00e9t, amelyeket be akarsz olvasztani.",Hj:"V\u00e1laszd ki a kalap\u00e1csot, amit haszn\u00e1lni szeretn\u00e9l.",Ij:"Figyelj arra, hogy az els\u0151 mez\u0151 melletti z\u00f6ld \u00e9s piros k\u00f6r a szab\u00e1ly enged\u00e9lyez\u00e9s\u00e9hez/letilt\u00e1s\u00e1hoz van.",Jj:"Ha v\u00e9letlenszer\u0171en szeretn\u00e9l beolvasztani b\u00e1rmilyen sz\u00ednt vagy t\u00edpust, enged\u00e9lyezheted a `V\u00e9letlenszer\u0171en beolvasztani, ha nincsenek felt\u00e9telek teljes\u00edtve? (A tutorial vide\u00f3ban utolj\u00e1ra enged\u00e9lyezett opci\u00f3)",
uj:"R\u00e9parer avant la Fusion",ye:"Sz\u00f6rny Kiv\u00e1laszt\u00e1sa",me:"Homok\u00f3ra/Rubin Haszn\u00e1lata?",tk:"Rubin Haszn\u00e1lata?",pe:"Mozg\u00f3s\u00edt\u00e1s Haszn\u00e1lata?",oe:"\u00c9letital Haszn\u00e1lata?",le:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9ka (%)",we:"T\u00e1mad\u00e1sok Sz\u00e1ma",ne:"T\u00e1mad\u00e1si Id\u0151k\u00f6z (m\u00e1sodpercben)",je:"V\u00e9grehajtott T\u00e1mad\u00e1sok",ke:"H\u00e1tral\u00e9v\u0151 Homok\u00f3ra",ue:"Megjegyz\u00e9s: \u00c9leter\u0151-p\u00f3ci\u00f3kat haszn\u00e1l gy\u00f3gy\u00edt\u00e1sra, nem \u00e9telt.",
ve:"Megjegyz\u00e9s: Ha a t\u00e1mad\u00e1sok id\u0151 el\u0151tt meg\u00e1llnak, pr\u00f3b\u00e1lja meg az 'T\u00e1mad\u00e1sok Vissza\u00e1ll\u00edt\u00e1sa' opci\u00f3t.",ze:"Ind\u00edt\u00e1s",xe:"Vissza\u00e1ll\u00edt\u00e1s",Ae:"Le\u00e1ll\u00edt\u00e1s",Be:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sai (Kattintson minimaliz\u00e1l\u00e1shoz)",qe:"Sz\u00f6rny 1",re:"Sz\u00f6rny 2",se:"Sz\u00f6rny 3",te:"Sz\u00f6rny 4",Ck:"R\u00e9parer avant la Fusion",Ci:"Ez az opci\u00f3 haszn\u00e1lja a cervisia-t, amikor lej\u00e1r a pr\u00e9mium tags\u00e1god.",
ej:"Ez az opci\u00f3 aktiv\u00e1lja \u00e9s v\u00e1laszt olajokat az istenek jutalmai k\u00f6z\u00fcl. Haszn\u00e1lhatja az 1. \u00e9s 3. sz\u00e1m\u00fa olajokat a karakteren, de a 2. sz\u00e1m\u00fa csak csomagokba ker\u00fcl.",Ai:"Ez az opci\u00f3 a be\u00e1ll\u00edtott id\u0151ben haszn\u00e1lja a buffokat. Megkeresi a csomagokban l\u00e9v\u0151 buffokat \u00e9s alkalmazza \u0151ket a karakteren.",Yi:"Ez az opci\u00f3 bevisz az alvil\u00e1gba. Ne felejtsd el enged\u00e9lyezni az Auto Bejelentkez\u00e9st az Extra f\u00fcl\u00f6n, k\u00fcl\u00f6nben kijelentkezhetsz az alvil\u00e1gba l\u00e9p\u00e9skor [J\u00e1t\u00e9k Hiba]",
Sb:"A bot norm\u00e1lis esetben v\u00e9letlenszer\u0171en v\u00e1laszt 3-6 pr\u00f3b\u00e1t az ar\u00e9nalista megt\u00e1mad\u00e1s\u00e1ra. Ha enged\u00e9lyezed ezt az opci\u00f3t, v\u00e9gigmegy a list\u00e1don, am\u00edg meg nem t\u00e1madhat valakit. Ez eltarthat egy kis id\u0151t.",rj:"Ez az opci\u00f3 csak pr\u00e9mium licencek sz\u00e1m\u00e1ra van. Szimul\u00e1l egy t\u00e1mad\u00e1st egy felhaszn\u00e1l\u00f3 ellen 75%-os gy\u0151zelmi r\u00e1t\u00e1val, miel\u0151tt megt\u00e1madn\u00e1.",
zd:"Nem kell enged\u00e9lyezned a f\u0151 aukci\u00f3 kapcsol\u00f3t, hogy ezt az opci\u00f3t haszn\u00e1lhasd.",$j:"Ez az opci\u00f3 m\u00e1sodpercenk\u00e9nt friss\u00edti az oldalt, amikor az aukci\u00f3 -Nagyon R\u00f6vid- \u00e1llapotban van, hogy folyamatosan licit\u00e1ljon \u00e9s megnyerje az aukci\u00f3t.",Cj:"Ha egyik olvaszt\u00e1si felt\u00e9tel sem teljes\u00fcl, akkor v\u00e9letlenszer\u0171en olvaszt. Gy\u0151z\u0151dj meg r\u00f3la, hogy v\u00e1lasztott\u00e1l t\u00e1rgyt\u00edpust \u00e9s sz\u00ednt.",
Dj:"Ez az opci\u00f3 csak a lelt\u00e1rban l\u00e9v\u0151 t\u00e1rgyakat olvasztja. A csomagokban l\u00e9v\u0151 t\u00e1rgyakat figyelmen k\u00edv\u00fcl hagyja.",Na:"Aukci\u00f3s T\u00e1rgyak",fg:"Zsoldos T\u00e1rgyak",Mb:"Bolt T\u00e1rgyak",li:"Egyedi T\u00e1rgyak",yj:"H\u00e1tt\u00e9r be\u00e1ll\u00edt\u00e1sa feket\u00e9re [N\u00f6veli a teljes\u00edtm\u00e9nyt]",zj:"GLDBot gombok \u00e1thelyez\u00e9se a bal als\u00f3 sarokba?",Di:"Cirkusz T\u00e1mad\u00e1s Gy\u00f3gy\u00edt\u00e1s N\u00e9lk\u00fcl",
Yj:"Sz\u00fcks\u00e9g eset\u00e9n vegy\u00fcnk ki aranyat a csomagokb\u00f3l?",Zj:"Az edz\u00e9shez aranyat vettek a csomagokb\u00f3l",Cl:"Nem tal\u00e1ltak aranyat a csomagokban az edz\u00e9shez",Vj:"Jav\u00edtott T\u00e1rgyak",Oj:"Ar\u00e9na T\u00e1mad\u00e1sok",Qj:"Cirkusz T\u00e1mad\u00e1sok",qd:"T\u00e1rgyak Vissza\u00e1ll\u00edtva",Tj:"Exped\u00edci\u00f3s T\u00e1mad\u00e1sok",Sj:"Kazamata T\u00e1mad\u00e1sok",Wj:"Alvil\u00e1gi T\u00e1mad\u00e1sok",Pj:"Ar\u00e9n\u00e1ban Szerzett P\u00e9nz",
Rj:"Cirkuszban Szerzett P\u00e9nz",Al:"Olvasztott T\u00e1rgyak",Uj:"\u00dajrahasznos\u00edtott Arany",Pi:"C\u00e9h Csata",Ri:"C\u00e9h Be\u00e1ll\u00edt\u00e1sok",Qi:"C\u00e9h N\u00e9v",Oi:"V\u00e9letlenszer\u0171 C\u00e9h T\u00e1mad\u00e1s",Wk:"V\u00e9letlenszer\u0171en t\u00e1madja a c\u00e9heket.",Bi:"Statisztik\u00e1k Vissza\u00e1ll\u00edt\u00e1sa",gl:'GLDBot: A kock\u00e1k seg\u00edts\u00e9g\u00e9vel friss\u00edtse a rejt\u00e9lydobozt, \u00e9s tal\u00e1ljon \u00e9rt\u00e9kes t\u00e1rgyakat, miel\u0151tt kinyitn\u00e1 azokat (stb. jelmezek). Kattintson a "Start" gombra, nyissa meg a l\u00e1d\u00e1kat.',
Ec:"Wood",uc:"Copper",yc:"Iron",Ac:"Leather",Fc:"Wool",vc:"Cotton Wool",xc:"Hemp",wc:"Gauze Strip",Bc:"Linen Strip",zc:"Jute Patch",Dc:"Velvet",Cc:"Silk Thread",Nc:"Fur",Hc:"Bone Splinter",Qc:"Scale",Kc:"Claw",Mc:"Fang",Lc:"Dragon Scale",Ic:"Bull`s Horn",Pc:"Poison Gland",Jc:"Cerberus` Pelt",Oc:"Hydra Scale",Rc:"Sphinx Feather",Sc:"Typhon Leather",pc:"Lapis Lazuli",jc:"Amethyst",ic:"Amber",kc:"Aquamarine",qc:"Sapphire",nc:"Garnet",mc:"Emerald",lc:"Diamond",oc:"Jasper",rc:"Sugilite",cc:"Scorpion Poison",
fc:"Tincture of Stamina",Zb:"Antidote",Yb:"Adrenaline",ec:"Tincture of Enlightenment",bc:"Potion of Perception",$b:"Essence of Reaction",ac:"Phial of Charisma",hc:"Waters of Oblivion",dc:"Soul Essence",od:"Water Seal",hd:"Protection Rune",fd:"Earth Mark",nd:"Totem of Healing",md:"Talisman of Power",kd:"Stone of Fortune",gd:"Flintstone",ld:"Storm Rune",jd:"Shadow Rune",Wc:"Crystal",Vc:"Bronze",$c:"Obsidian",cd:"Silver",dd:"Sulphur",Yc:"Gold Ore",bd:"Quartz",ad:"Platinum",Uc:"Almandin",Xc:"Cuprit",
Zc:"Hellstone",xi:"T\u00e1mad\u00e1s v\u00e9letlenszer\u0171en?",yi:'Kapcsold ki a "J\u00e1t\u00e9kosok rendez\u00e9se az ar\u00e9n\u00e1ban szint szerint" be\u00e1ll\u00edt\u00e1st a crazy-addonban is.',Ng:"Csak az isten t\u00edpus\u00e1n alapul\u00f3 k\u00fcldet\u00e9seket fogadja el.",Oa:"Automatikus Buff",Nd:"Csak a pokolban haszn\u00e1lja?",ug:"\u00daj Szab\u00e1ly",sg:"N\u00e9v Tartalmazza",isUnderworldItem:"Ez egy alvil\u00e1gi t\u00e1rgy?",Ue:"Anyagok Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
fk:"Utiliser la Pri\u00e8re ?",si:"Utiliser le Sacrifice ?",bk:"Utiliser le tissu pour entrer dans le monde souterrain ?",ii:"A m\u00e9lyvil\u00e1gban csak a m\u00e9lyvil\u00e1ggal kapcsolatos k\u00fcldet\u00e9seket fogadja el?",hi:"Ha enged\u00e9lyezve van, meg kell adnia a m\u00e9lyvil\u00e1gi t\u00e1rgyak nev\u00e9t. Ha a bot megtal\u00e1lja ezeket a t\u00e1rgyakat a m\u00e9lyvil\u00e1gban, elfogadja a k\u00fcldet\u00e9st.",Jk:"M\u00e9lyvil\u00e1gi K\u00fcldet\u00e9s T\u00e1rgy",Tk:"Entrez le Nom du Mat\u00e9riel",
qk:"A robot im\u00e1dja a kock\u00e1kat! Seg\u00edtenek ruh\u00e1t tal\u00e1lni a l\u00e1d\u00e1kban. De ha nincs kocka, a robot akkor is kinyitja a l\u00e1d\u00e1kat, rem\u00e9lve, hogy tal\u00e1l valami men\u0151 ruh\u00e1t (de lehet, hogy semmit sem tal\u00e1l!)",Bj:"Fusionner les Bo\u00eetes de Butin ?",be:"Enable Arena",Fg:"Prioriz\u00e1lja az ar\u00e9na list\u00e1t?",Gg:"Prioriz\u00e1lja a cirkusz list\u00e1t?",Ud:"Napl\u00f3 men\u00fc letilt\u00e1sa",ah:"Jutalom Min. Arany \u00c9rt\u00e9k",
Og:"Ha enged\u00e9lyezve van, a K\u00fcldet\u00e9s F\u00f3kusz a legr\u00f6videbb utat k\u00f6veti a dungeon befejez\u00e9s\u00e9hez.",zh:"Dobja a kock\u00e1t automatikusan?",Ah:"Vigy\u00e1zva haszn\u00e1lja a dob\u00f3 kock\u00e1t, folyamatosan az els\u0151 kock\u00e1t fogja haszn\u00e1lni, am\u00edg ki nem kapcsolja az opci\u00f3t.",gh:"Keres\u00e9s folyamatban",Vg:"A jav\u00edt\u00e1s alap\u00e9rtelmezett leh\u0171l\u00e9se 10 perc.",pg:"Minim\u00e1lis \u00c1llapot",Sd:"Aktu\u00e1lis t\u00e9tel a munkapadon [T\u00f6r\u00f6lje, ha a bot v\u00e1ratlanul sz\u00fcnetelt]",
rf:"Kov\u00e1csolt er\u0151forr\u00e1sok sikeresen elmentve a horreumhoz.",lf:"Piac ellen\u0151rz\u00e9se t\u00e1rgyak sz\u00e1m\u00e1ra...",qb:"T\u00e9tel \u00e1thelyezve a munkapadra.",Gf:"T\u00e9tel sikeresen jav\u00edtva \u00e9s felszerelve.",Hf:"T\u00e9tel sikeresen jav\u00edtva.",xk:"A jav\u00edt\u00e1s sikertelen. Az oldal friss\u00edt\u00e9sre ker\u00fcl.",Df:"Anyagok felv\u00e9tele...",Qf:"V\u00e1rakoz\u00e1s a jav\u00edt\u00e1sra...",Ff:"Jav\u00edt\u00e1s elindult: .",rb:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa az invent\u00e1riumb\u00f3l a t\u00e1sk\u00e1ba",
Ef:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa a munkapadra a csomagol\u00f3ba.",nf:"Nem tal\u00e1lhat\u00f3 elegend\u0151 anyag. A jav\u00edt\u00e1si hely le lesz tiltva ",Af:"T\u00e1rgyak keres\u00e9se arany elrejt\u00e9s\u00e9re az aukci\u00f3ban...",hf:"Lej\u00e1rt t\u00e1rgyak ellen\u0151rz\u00e9se a csomagokban...",jf:"T\u00e9tel sikeresen vissza\u00e1ll\u00edtva.",kf:"Nincs \u00fcres hely vagy arany a vissza\u00e1ll\u00edt\u00e1shoz.",sf:"Gy\u0151z\u0151dj\u00f6n meg arr\u00f3l, hogy van elad\u00e1si joga a c\u00e9hes piacon!",
tf:"Nincs el\u00e9g arany/vagy nincs meg a v\u00e1s\u00e1rl\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s a friss\u00edt\u00e9shez.",mb:"A bolt friss\u00edtve lett.",nb:"Hiba t\u00f6rt\u00e9nt a gy\u00f3gyul\u00e1s k\u00f6zben.",wf:"Nincs Ruby vagy Cloth, letilt\u00e1sa az opci\u00f3knak.",xf:"Nincs gy\u00f3gy\u00edt\u00f3 t\u00e1rgy a csomagokban.",ob:"Nem tal\u00e1lhat\u00f3 megfelel\u0151 t\u00e1rgy",yf:"Az \u00e9lelmiszereket felvett\u00e9k. A folyamat v\u00e9get \u00e9rt.",zf:"Legal\u00e1bb egy \u00e9tel felv\u00e9telre ker\u00fclt. A folyamat v\u00e9get \u00e9rt.",
pb:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",uf:"\u00c9telek felv\u00e9tele a csomagokb\u00f3l.",vf:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",lb:"Nincs t\u00f6bb gy\u00f3gy\u00edt\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s.",kb:"\u00c9P helyre\u00e1ll\u00edtva.",za:"Nincs teend\u0151, ez\u00e9rt im\u00e1dkozom!",Mf:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem \u00e9s a Villa Medici ellen\u0151rz\u00e9s\u00e9re.",
Nf:"V\u00e1rakoz\u00e1s a Villa Medici-re, friss\u00edt\u00e9s 60 m\u00e1sodperc m\u00falva.",Of:"Elhagytam az alvil\u00e1got.",Pf:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem ellen\u0151rz\u00e9s\u00e9re.",Bf:"Isteni olajok ellen\u0151rz\u00e9se...",Cf:"Isteni olajok felv\u00e9ve.",xa:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen AZ AR\u00c9N\u00c1BAN: ",ya:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen A CIRKUSZBAN: ",ff:"Aukci\u00f3 ellen\u0151rz\u00e9se! K\u00e9rem v\u00e1rjon...",
gf:"T\u00e1rgyak licit\u00e1l\u00e1sa. K\u00e9rem v\u00e1rjon...",If:"Automatikus olvasztott t\u00e9tel: ",Jf:"Olvaszt\u00e1s alatt \u00e1ll\u00f3 t\u00e9tel: ",Kf:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges arany: ",Lf:"OLVASZT\u00c1S: T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",yk:"T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",mf:"Koszt\u00fcm\u00f6k el\u00e9rhet\u0151s\u00e9g\u00e9nek ellen\u0151rz\u00e9se...",qf:"Adom\u00e1nyozva: ",pf:"Kocka dob\u00e1sa...",
He:"Underworld Farm [Manual, Beta]",Ge:"Farm Location",Ie:"Figyelem: Kapcsolja be ezt a funkci\u00f3t a t\u00e1madni k\u00edv\u00e1nt l\u00e9ny felold\u00e1sa ut\u00e1n, nem fog automatikusan t\u00e1madni, hogy feloldja a sz\u00f6rnyet.",Fe:"Farm Enemy",Gd:"Automatikus Bejelentkez\u00e9s",Hd:"Enged\u00e9lyezned kell a felugr\u00f3 ablakokat a GameForge el\u0151csarnok k\u00e9perny\u0151j\u00e9r\u0151l. N\u00e9zd meg a dokument\u00e1ci\u00f3t, hogy hogyan tedd meg.",Cg:"Bot Sz\u00fcneteltet\u00e9se",
Dg:"Bot sz\u00fcneteltet\u00e9se ennyi id\u0151re: (Perc)",De:"Lej\u00e1rati D\u00e1tum",xg:"Csak \u00e9telt v\u00e1s\u00e1rolj?",yg:"Ha ezt enged\u00e9lyezed, a bot figyelmen k\u00edv\u00fcl hagyja a kiv\u00e1laszt\u00e1saidat, \u00e9s automatikusan v\u00e1s\u00e1rol \u00e9telt an\u00e9lk\u00fcl, hogy b\u00e1rmit be\u00edrn\u00e1l.",Ab:"Maxim\u00e1lis \u00f6sszes arany kiad\u00e1s",zb:"Maxim\u00e1lis arany \u00e9telenk\u00e9nti kiad\u00e1s",wg:"A bot 60 percenk\u00e9nt ellen\u0151rzi az olajokat",
Sh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a olvaszt\u00e1si id\u0151k ellen\u0151rz\u00e9s\u00e9hez.",Ph:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs aranyad.",Rh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs el\u00e9rhet\u0151 t\u00e1rgyad.",Kh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a t\u00e1rgyak jav\u00edt\u00e1s\u00e1hoz \u00e9s ellen\u0151rz\u00e9s\u00e9hez.",
Jh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a guild piac\u00e1nak arany\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Fh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az aukci\u00f3 arany tart\u00e1si lehet\u0151s\u00e9g\u00e9hez.",Bh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az ar\u00e9na PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",Gh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a cirkusz PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",
Yh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a statisztik\u00e1k tr\u00e9ningez\u00e9s\u00e9hez.",Mh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a lej\u00e1rt t\u00e1rgyak vissza\u00e1ll\u00edt\u00e1s\u00e1hoz.",Wh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a kov\u00e1csol\u00f3 anyagok t\u00e1rol\u00e1s\u00e1hoz a horreum-ban.",Dh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a gladi\u00e1torok \u00e9s zsoldosok aukci\u00f3j\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Oh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t t\u00e1rgyak keres\u00e9s\u00e9hez az aukci\u00f3ban \u00e9s a boltban.",
Hh:"Be\u00e1ll\u00edtja a guild adom\u00e1ny k\u00fcld\u00e9s\u00e9nek id\u0151z\u00edt\u0151j\u00e9t.",Me:"Arany Mozgatva",Zd:"Ne adjon el az \u00f6sszeoml\u00e1si \u00e9s aukci\u00f3s list\u00e1n szerepl\u0151 t\u00e9teleket",hh:"Bolt Automatiz\u00e1l\u00e1s",jh:"T\u00e1rgy Keres\u00e9s Be\u00e1ll\u00edt\u00e1sok",ih:"Haszn\u00e1lja ezt az eszk\u00f6zt t\u00e1rgyak keres\u00e9s\u00e9hez. Egyszer\u0171en adjon hozz\u00e1 t\u00e1rgyakat a list\u00e1hoz, hat\u00e1rozza meg a ruha mennyis\u00e9g\u00e9t, majd ind\u00edtsa el a keres\u00e9st.",
kh:"Haszn\u00e1lni k\u00edv\u00e1nt Ruha:",lh:"H\u00e1ny ruh\u00e1t haszn\u00e1ljon?",ia:"Full Adja meg a T\u00e1rgy Nev\u00e9t",Lb:"Adja meg a T\u00e1rgy Szintj\u00e9t",nh:"T\u00e1rgy Min\u0151s\u00e9ge",mh:"T\u00e1rgy Neve Itt",oh:"Keres\u00e9s Ind\u00edt\u00e1sa",ph:"\u00c1tugr\u00e1s \u00e9s Folytat\u00e1s",qh:"Keres\u00e9s Le\u00e1ll\u00edt\u00e1sa",Je:"Guild Piac Rendez\u00e9se",rg:"Legdr\u00e1g\u00e1bb",Pd:"Legolcs\u00f3bb",fa:"V\u00e1lasszon egy lehet\u0151s\u00e9get",de:"Mettre en surbrillance les objets du monde souterrain",
Ke:"F\u00f3kuszban a k\u00fcldet\u00e9sre?",Lp:"Haszn\u00e1ljon rubint, ha nincs ruha?",Pa:"Ker\u00fclje azonos szem\u00e9lyek megt\u00e1mad\u00e1s\u00e1t, hogy elker\u00fclje a jelent\u00e9st\u00e9tel\u00e9t. A jelent\u00e9s megn\u00f6veli a kitilt\u00e1s es\u00e9ly\u00e9t.",tl:"Olvad a z\u00f6ld?",Ig:"Ne fogadja el a v\u00e9letlenszer\u0171 k\u00fcldet\u00e9seket, ha b\u00e1rmilyen sz\u0171r\u0151t megadott?",Gc:"Maxim\u00e1lis haszn\u00e1lhat\u00f3 anyagmin\u0151s\u00e9g",Li:"Enged\u00e9lyezze a zsoldos keres\u00e9st",
bl:'Kattints a "Minden Kiv\u00e1lasztott Elad\u00e1sa" gombra az \u00f6sszes t\u00e9tel elad\u00e1s\u00e1hoz. Gy\u0151z\u0151dj meg r\u00f3la, hogy az els\u0151 (1) t\u00e1sk\u00e1dban van el\u00e9g 2x3 \u00fcres hely. Az arany t\u00f6meges gy\u0171jt\u00e9s\u00e9hez sz\u0171rd ki az aranyat, \u00e9s haszn\u00e1ld a "Kiv\u00e1lasztott vagy Mindet Kiv\u00e1laszt" lehet\u0151s\u00e9get.',Nj:"\ud83d\udd25 : Hozz\u00e1adja az elemet a koh\u00e1szati list\u00e1hoz.",zi:"\ud83d\udd28 : Hozz\u00e1adja az elemet az \u00e1rver\u00e9si list\u00e1hoz.",
tj:"Friss\u00edtsd a boltot anyaggal, amikor tele van (ut\u00e1na \u00fajra el kell adnod)",hj:"Oldal:",oj:"Meg\u00e1ll\u00edt",mj:"Elad\u00e1s Ezen az Oldalon",jj:"Kiv\u00e1lasztott Kiv\u00e1laszt\u00e1sa",ij:"Mindent Kiv\u00e1laszt",pj:"Automatikus Csomagol\u00e1si Be\u00e1ll\u00edt\u00e1sok",nj:"Er\u0151forr\u00e1sok K\u00fcld\u00e9se",kj:"Minden Kiv\u00e1lasztott Elad\u00e1sa",qa:"T\u00e9tel T\u00edpusa",U:"Fegyverek",M:"Pajzsok",I:"P\u00e1nc\u00e9lok",L:"Sisakok",K:"Keszty\u0171k",J:"Csizm\u00e1k",
T:"Gy\u0171r\u0171k",R:"Amulettek",oa:"Haszn\u00e1lati T\u00e1rgyak (\u00c9telek)",va:"Fejleszt\u00e9sek",fj:"Er\u0151s\u00edt\u00e9sek",sa:"Receptek",ra:"Zsoldosok",ua:"Kov\u00e1csol\u00f3 Eszk\u00f6z\u00f6k",ta:"Pergamenek",Ga:"Er\u0151s\u00edt\u00e9sek",Fa:"Esem\u00e9ny T\u00e1rgyak",ed:"Kov\u00e1csol\u00e1shoz Val\u00f3 T\u00e1rgyak",gj:"Arany",P:"Minden",jl:"Min\u0151s\u00e9g",wa:"Feh\u00e9r",C:"Z\u00f6ld",B:"K\u00e9k",D:"Lila",G:"Narancss\u00e1rga",S:"Piros",lj:"Az \u00d6sszes Elad\u00e1si Be\u00e1ll\u00edt\u00e1s",
Aj:"Elhanyagolja a El\u0151tag / Ut\u00f3tag Kombin\u00e1ci\u00f3t?",Si:"H\u00e1ny \u00e9telt vegy\u00e9l/fogj fel?",Gi:"Norm\u00e1l",Fi:"K\u00f6zepes",Ei:"Neh\u00e9z",Da:"Alap",ml:"Ragadt Megjav\u00edt\u00e1s",vk:"Kapcsold ki a Pokol Bel\u00e9p\u00e9s\u00e9t, ha letiltan\u00e1d a Dungeon/Circus/Arena-t. Ha k\u00e9zzel l\u00e9pt\u00e9l be a Pokolba, akkor enged\u00e9lyezned kell a Pokol M\u00f3dot.",Qd:"V\u00e1lassz alvil\u00e1gi jelmezt",vi:"Viselj alvil\u00e1gi jelmezt, ha el\u00e9rhet\u0151?",
ai:"K\u00e9pz\u00e9si \u00fatmutat\u00f3: Hat\u00e1rozza meg, h\u00e1nyszor szeretn\u00e9 edzeni a statisztik\u00e1kat, \u00e9s \u00e1ll\u00edtsa be priorit\u00e1saikat. A bot nem fog edzeni, hacsak nincs be\u00e1ll\u00edtva egy priorit\u00e1s. Ha van be\u00e1ll\u00edtott priorit\u00e1s, de nincs t\u00f6bb k\u00e9pzend\u0151 statisztika, a bot a kiv\u00e1lasztott statisztik\u00e1val folytatja.",Qk:"Quest",rl:"Olvaszt\u00e1s",xl:"Olvaszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Kj:"Olvasztott T\u00e1rgyak",
yl:"Adj hozz\u00e1 el\u0151tagot vagy ut\u00f3tagot, amint megtal\u00e1lja a csomagokban, aut\u00f3matikusan olvasztani fogja.:",wl:"Olvasztand\u00f3 T\u00e1rgy:",Vb:"Kattints a t\u00e1rgyra, amelyet meg akarsz jav\u00edtani. Ez a rendszer megjav\u00edtja a k\u00e9t f\u0151 karaktered t\u00e1rgyait ( AR\u00c9NA/CT). Legal\u00e1bb 10000 aranyra van sz\u00fcks\u00e9g a jav\u00edt\u00e1s elind\u00edt\u00e1s\u00e1hoz. Ha egy t\u00e1rgy beragad, az azt jelenti, hogy nincs anyagod a jav\u00edt\u00e1shoz. Pr\u00f3b\u00e1lj szabad helyet k\u00e9sz\u00edteni a t\u00e1sk\u00e1dban. A bot akkor kezdi meg a jav\u00edt\u00e1st, amikor a t\u00e9tel tart\u00f3ss\u00e1ga %0.",
Kk:"Csak Zsoldosra alkalmaz",Nk:"Aukci\u00f3 csak akkor licit\u00e1l, ha a lej\u00e1rati id\u0151 k\u00f6zel van a v\u00e9g\u00e9hez.",Mk:"Gy\u0151z\u0151dj meg arr\u00f3l, hogy a 2. lelt\u00e1r f\u00fcl \u00fcres \u00e9s rendelkezik 10K arannyal. A bot megtal\u00e1lja \u00e9s a m\u00e1sodik f\u00fclre helyezi a t\u00e1rgyat, majd legk\u00f6zelebb az oldal friss\u00edt\u00e9se ut\u00e1n olvasztja a t\u00e1rgyat. Az olvaszt\u00e1st minden 5-10 percen bel\u00fcl \u00fajraellen\u0151rzi.",Vi:"Gy\u00f3gy\u00edt\u00e1s & Buffs",
nl:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges Arany:",ql:"Licit kihagy\u00e1sa: Egyes\u00fclet tag m\u00e1r licit\u00e1lt a t\u00e1rgyra ",pl:"Licit kihagy\u00e1sa: M\u00e1r licit\u00e1lt a t\u00e1rgyra ",advanced:"Halad\u00f3",arena:"Ar\u00e9na",ma:"Aut\u00f3matikus T\u00e1mad\u00e1s",Tb:"T\u00e1mad\u00e1s Elker\u00fcl\u00e9se",ka:"J\u00e1t\u00e9kos Hozz\u00e1ad\u00e1sa",la:"Add hozz\u00e1 a j\u00e1t\u00e9kos nev\u00e9t (Same Server)",Yk:"Meg\u00e1ll\u00edtja a bot, ha elfogyott az \u00e9tel?",
circusTurma:"Circus Turma",Hi:"Neh\u00e9zs\u00e9g",dungeon:"Kazamata",Ii:"Kazamata Be\u00e1ll\u00edt\u00e1sok",eventExpedition:"Esem\u00e9ny Exped\u00edci\u00f3",expedition:"Exped\u00edci\u00f3",Mi:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sok",vj:"V\u00e1lassz Sz\u00f6rnyet",$k:"Legmagasabb",Zk:"Tedd be a gy\u00f3gy\u00edt\u00f3 t\u00e1rgyaid az els\u0151 oldalra a lelt\u00e1rodon bel\u00fcl",tc:"Bent",xh:"Arany T\u00e1rol\u00e1sa",yh:"Arany T\u00e1rol\u00e1sa az Aukci\u00f3ban?",eh:"Haszn\u00e1ld a Munk\u00e1sruh\u00e1t a Bolt Felt\u00f6lt\u00e9s\u00e9hez?",
Ek:"V\u00e1lassz T\u00e9teleket a Vissza\u00e1ll\u00edt\u00e1shoz",Xg:"Lej\u00e1rt T\u00e9telek Vissza\u00e1ll\u00edt\u00e1sa",Gb:"Megjegyz\u00e9s: Az opci\u00f3 enged\u00e9lyez\u00e9s\u00e9vel a bot eladja a k\u00f6zelg\u0151 lej\u00e1rat\u00fa t\u00e1rgyakat a Csomagokb\u00f3l az Egyes\u00fcleti Piacon majd megszak\u00edtja a lej\u00e1rati id\u0151 vissza\u00e1ll\u00edt\u00e1s\u00e1t. Egyes\u00fclet sz\u00fcks\u00e9ges. Gy\u0151z\u0151dj meg r\u00f3la, hogy a t\u00e1sk\u00e1dban van \u00fcres 3x3-as hely.",
Eg:"Bot v\u00e9letlenszer\u0171 sz\u00fcneteltet\u00e9se m\u0171k\u00f6d\u00e9si [Teszt F\u00e1zis]:",aa:"Arany T\u00e1rol\u00e1sa: A bot megtartja ezt az aranyat a karakteren:",dg:"Max Arany: A bot elk\u00f6lti, ha az arany nagyobb, mint",bh:"A bot v\u00e9letlenszer\u0171 t\u00e1rgyakra fog licit\u00e1lni.",rd:"V\u00e9letlenszer\u0171 k\u00e9sleltet\u00e9s hozz\u00e1ad\u00e1sa",sd:"Itt adhatsz hozz\u00e1 k\u00e9sleltet\u00e9st a bothoz.",Fb:"Jav\u00edt\u00e1s",sl:"Csak K\u00e9k t\u00e1rgy Olvaszt\u00e1s?",
vl:"Csak Lila t\u00e1rgy Olvaszt\u00e1s?",ul:"Csak Narancss\u00e1rga t\u00e1rgy Olvaszt\u00e1s?",Lj:"Mindent Olvassz be a 2. f\u00fclben?",Mj:"Ez figyelmen k\u00edv\u00fcl hagyja a sz\u00ednv\u00e1laszt\u00e1sokat",Qa:"El\u0151zm\u00e9nyek T\u00f6rl\u00e9se",th:"Olvaszt\u00e1s",Ad:"Search",tg:"Aut\u00f3matikus Aukci\u00f3",Bd:"Az aukci\u00f3 t\u00falzott haszn\u00e1lata kitilt\u00e1st vonhat maga ut\u00e1n. Az esetleges \u00fctk\u00f6z\u00e9sek elker\u00fcl\u00e9se \u00e9rdek\u00e9ben aj\u00e1nlatos letiltani az egy\u00e9b aj\u00e1nlatt\u00e9teli funkci\u00f3kat. Ez a funkci\u00f3 lelass\u00edtja a botot.",
dh:"Keres\u00e9s a Gladi\u00e1torok Aukci\u00f3j\u00e1ban",fh:"Keres\u00e9s a Zsoldosok Aukci\u00f3j\u00e1ban",Jd:"Licit\u00e1l\u00e1s \u00c9telekre?",eg:"Maxim\u00e1lis Licit",Kd:"Licit\u00e1l\u00e1s, ha az \u00e1llapot kevesebb, mint",Ld:"Licit\u00e1lt T\u00e1rgyak",kk:"Aukci\u00f3 Nyelve",lk:"2.9.4-es friss\u00edt\u00e9ssel kapcsolatban k\u00e9rlek \u00e1ll\u00edtsd be \u00fajra a nyelvet, vagy ALAP\u00c9RTELMEZET BE\u00c1LL\u00cdT\u00c1SOK. Gy\u0151z\u0151dj meg r\u00f3la, hogy minden helyesen van be\u00e1ll\u00edtva, k\u00fcl\u00f6nben a licit\u00e1l\u00e1s nem m\u0171k\u00f6dik.",
vd:"Hozz\u00e1adhatsz t\u00e9teleket a piac keres\u00e9s\u00e9hez \u00e9s az aukci\u00f3hoz. Amikor egy t\u00e9telt hozz\u00e1ad a list\u00e1hoz, a piac lila t\u00e9teleket is megjelen\u00edti. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, az al\u00e1bbi opci\u00f3kat haszn\u00e1lhatod",ik:"\u00d3vatosan haszn\u00e1ld az aukci\u00f3t!",jk:"Az aut\u00f3matikus licit\u00e1l\u00e1s t\u00fal sok k\u00e9r\u00e9st k\u00fcldhet a szerverre, \u00e9s kitilthatj\u00e1k, ha folyamatosan haszn\u00e1lod!",
Ug:"\u00dajra Aktiv\u00e1lja az Esem\u00e9nypontokat Rubinokkal?",fe:"Aut\u00f3matikus Olaj Enged\u00e9lyez\u00e9se",nk:"Aut\u00f3matikus Szent Olajok Beszerz\u00e9se",Ak:"K\u00fcldet\u00e9s ellen\u0151rz\u00e9si Sebess\u00e9g",La:"T\u00e1madj Egyes\u00fcleti Tagokat?",Ja:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "T\u00e1mad\u00e1s" list\u00e1hoz, amikor t\u00f6bb, mint X ARANYAT rabolsz.:',Ka:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "Elker\u00fclend\u0151 T\u00e1mad\u00e1s" list\u00e1hoz, ha vesz\u00edtesz ellen\u00fck.:',
Jb:"T\u00e1mad\u00e1sok Statisztik\u00e1i",Qb:"Nagyon Hossz\u00fa",sb:"Hossz\u00fa",Bb:"K\u00f6zepes",Nb:"R\u00f6vid",Rb:"Nagyon R\u00f6vid",ge:"Bel\u00e9p\u00e9s az Alvil\u00e1gba, ha az \u00c9P >",Pg:"K\u00fcldet\u00e9s Ellen\u0151rz\u00e9si Sebess\u00e9g",Hg:'Az alap\u00e9rtelmezett "3x". Ha a bot probl\u00e9m\u00e1kat okoz a k\u00fcldet\u00e9sekkel, \u00e1ll\u00edtsd \u00e1t a k\u00fcldet\u00e9s sebess\u00e9g\u00e9t a szerver sebess\u00e9g\u00e9nek megfelel\u0151en.',Ne:"Gy\u00f3gy\u00edt\u00f3 Kiv\u00e1laszt\u00f3 T\u00e1ska",
he:'Ha manu\u00e1lisan friss\u00edted a pontokat, akkor kattints a fent l\u00e9v\u0151 gombra: "Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!"',sk:"Legal\u00e1bb az egyiket enged\u00e9lyezned kell a k\u00f6vetkez\u0151k k\u00f6z\u00fcl: exped\u00edci\u00f3, dungeont, ar\u00e9n\u00e1t vagy cirkuszt, hogy elind\u00edtsd az Esem\u00e9ny Exped\u00edci\u00f3t.",Rg:"Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!",cb:"Fedezze a T\u00e1rsakat?",Gk:"Hagyd minden be\u00e1ll\u00edt\u00e1st letiltva, ha a csomagokban szerepl\u0151 elemekkel szeretn\u00e9l olvasztani. Azonban m\u00e9g mindig v\u00e1laszthatsz sz\u00edneket.",
pk:"Karakter(Ki) / Zsoldos(Be)",Dk:"Mindkett\u0151t Jav\u00edtani?",Hk:"Id\u0151z\u00edt\u0151k",Timers:"\u00cdrd be az egyes id\u0151z\u00edt\u0151kh\u00f6z a percek sz\u00e1m\u00e1t lent vagy hagyd az alap\u00e9rtelmezetten.",gb:"T\u00e1mad\u00e1s Statisztik\u00e1i Enged\u00e9lyez\u00e9se:",Hb:"V\u00e1lassz tartom\u00e1nyt a t\u00e1mad\u00e1shoz",Ib:"A bot v\u00e9letlenszer\u0171en t\u00e1mad a t\u00e1bl\u00e1zatban szerepl\u0151 j\u00e1t\u00e9kosok k\u00f6z\u00fcl.",ib:"Ligat\u00e1mad\u00e1sok",
fb:"Ligat\u00e1mad\u00e1s Enged\u00e9lyez\u00e9se:",Db:"V\u00e9letlenszer\u0171 T\u00e1mad\u00e1s",Eb:"T\u00e1mad\u00e1s alacsonyt\u00f3l a magas szint\u0171 j\u00e1t\u00e9kosokig",hk:"A bot alap\u00e9rtelmezetten elker\u00fcli az Egyes\u00fcleti tagok t\u00e1mad\u00e1s\u00e1t.",Ce:"Exped\u00edci\u00f3 Helysz\u00edne:",Cd:"Aut\u00f3matikus B\u00f3nuszok Begy\u0171jt\u00e9se:",rh:"Boss Kihagy\u00e1sa",ae:"Kazamata Helysz\u00edne:",$g:"Kazamata \u00fajrakezd\u00e9se veres\u00e9g eset\u00e9n?",Qe:"Alvil\u00e1g Be\u00e1ll\u00edt\u00e1sok",
Re:"K\u00e9rlek konfigur\u00e1ld a gy\u00f3gy\u00edt\u00e1s sz\u00e1zal\u00e9kos be\u00e1ll\u00edt\u00e1sait a gy\u00f3gy\u00edt\u00e1s f\u00fcl\u00f6n, \u00e9s gy\u0151z\u0151dj meg r\u00f3la, hogy a gy\u00f3gy\u00edt\u00e1s f\u00fcl be van kapcsolva. Ha az alvil\u00e1g bel\u00e9p\u00e9se kijelentkeztet, l\u00e9pj a lobbyba, \u00e9s kapcsold be az aut\u00f3mata bejelentkez\u00e9s jel\u00f6l\u0151n\u00e9gyzetet.",Oe:"Alvil\u00e1g Neh\u00e9zs\u00e9g",Fd:"Aut\u00f3matikus Alvil\u00e1g Bel\u00e9p\u00e9s: / Alvil\u00e1g Mode",
pi:"Mobiliz\u00e1ci\u00f3 haszn\u00e1lata, ha pontok = 0",ui:"Rubinok haszn\u00e1lata?",ie:"Kil\u00e9p\u00e9s az alvil\u00e1gb\u00f3l, ha nincsenek pontok?",ci:"A bot megpr\u00f3b\u00e1lja el\u0151sz\u00f6r a Villa Medici-t haszn\u00e1lni, ha nincs, akkor gy\u00f3gy\u00edt\u00f3 italt haszn\u00e1l. Ne felejtsd el bekapcsolni a Gy\u00f3gy\u00edt\u00e1s kapcsol\u00f3t.",ki:"Az aut\u00f3matikus alvil\u00e1g bel\u00e9p\u00e9s letiltja a kazamata/ar\u00e9na/circus be\u00e1ll\u00edt\u00e1sokat az alvil\u00e1g bel\u00e9p\u00e9sekor.",
Ik:"Alvil\u00e1g Gy\u00f3gy\u00edt\u00e1si Be\u00e1ll\u00edt\u00e1sok",ti:"Villa Medici Haszn\u00e1lata?",ri:"Gy\u00f3gy\u00edt\u00f3 Ital Haszn\u00e1lata?",Rf:"INF\u00d3: A bot minden kiv\u00e1lasztott percben keresni fog piaci t\u00e9teleket, ami meg\u00e1ll\u00edthatja a t\u00e1mad\u00e1st a keres\u00e9s alatt.",ee:"Piaci Keres\u00e9s Enged\u00e9lyez\u00e9se:",Sf:"Piaci Keres\u00e9s Id\u0151k\u00f6z Percekben:",Tf:"Javasolt 10 perc.",$e:"T\u00e9tel Be\u00e1ll\u00edt\u00e1sok:",Ye:"T\u00e9tel N\u00e9v Tartalmazza",
N:"Max \u00c1r",af:"T\u00e9tel T\u00edpus",Ze:"T\u00e9tel Ritkas\u00e1g",Od:"L\u00e9lekhez k\u00f6t\u00f6ttet v\u00e1s\u00e1roljon?",cf:"V\u00e1s\u00e1roland\u00f3 T\u00e9telek",bf:"Megpr\u00f3b\u00e1lja megvenni a t\u00e1sk\u00e1ban l\u00e9v\u0151 legnagyobb \u00e1ron tal\u00e1lhat\u00f3 t\u00e9telt, ha b\u00e1rmelyik megegyezik a maxim\u00e1lis \u00e1r be\u00e1ll\u00edt\u00e1ssal.:",Md:"Megv\u00e1s\u00e1rolt T\u00e9telek:",Ti:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",dk:"\u00c9tel V\u00e1s\u00e1rl\u00e1sa a Boltb\u00f3l?",
ek:"Gy\u00f3gy\u00edt\u00f3 eszk\u00f6z haszn\u00e1lata a Csomagb\u00f3l?",ak:"Cervisia haszn\u00e1lata?",ck:"Toj\u00e1sok haszn\u00e1lata?",cl:"Utols\u00f3 Haszn\u00e1lat",location:"Helysz\u00edn",Strength:"Er\u0151",Dexterity:"\u00dcgyess\u00e9g",Agility:"F\u00fcrges\u00e9g",Constitution:"Alkat",Charisma:"Karizma",Intelligence:"Intelligencia",Zh:"Gyakorl\u00e1s Be\u00e1ll\u00edt\u00e1sok",$h:"V\u00e1laszd ki az attrib\u00fatumokat, amiket szeretn\u00e9l edzeni. Akkor fogja elkezdeni az edz\u00e9st, ha van el\u00e9g aranyad.",
Tc:"K\u00f6vetkez\u0151 l\u00e9p\u00e9s",cj:"Nem",dj:"Norm\u00e1l",hl:"Ellens\u00e9g",il:"Ellens\u00e9g Szintje",sj:"K\u00e9rd\u00e9sek",random:"V\u00e9letlenszer\u0171",ol:"Be\u00e1ll\u00edt\u00e1sok",zl:"Hamarosan...",type:"Kattints az ikonokra a k\u00e9rd\u00e9s t\u00edpus\u00e1nak kiv\u00e1laszt\u00e1s\u00e1hoz.",Gl:"Igen",A:"Aukci\u00f3/Keres\u00e9s",pd:"T\u00e9telek Hozz\u00e1ad\u00e1sa",Xj:"Fejleszt\u0151t\u00e1rgyak Aut\u00f3matikus T\u00e1rol\u00e1sa",Bl:"Elk\u00fcld\u00e9s",al:"Id\u0151k\u00f6z : ",
Rk:"Aut\u00f3matikus Licit Enged\u00e9lyez\u00e9se",Sk:"Ne licit\u00e1ljon, ha az Egyes\u00fcleti tag m\u00e1r licit\u00e1lt",Dl:"\u00datmutat\u00f3",Ub:"V\u00e1lassz a fenti gombok k\u00f6z\u00fcl, hogy akarod-e az ar\u00e9n\u00e1ban a legkisebb vagy a legmagasabb szint\u0171 ellenfelet. T\u00f6bb felhaszn\u00e1l\u00f3 lass\u00edthatja a bot m\u0171k\u00f6d\u00e9s\u00e9t.",Lk:"Kezdetnek adj hozz\u00e1 egy t\u00e9telt a list\u00e1hoz (pl. `Lucius`). Miut\u00e1n hozz\u00e1adtad, a bot keresni fogja a t\u00e1rgyakat \u00e9s megjelen\u00edti a keres\u00e9si eredm\u00e9nyeket a k\u00e9perny\u0151 bal oldal\u00e1n. Az aut\u00f3matikus aukci\u00f3 c\u00e9lj\u00e1b\u00f3l is keressen r\u00e1 a t\u00e1rgyra. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, a bot rendszeres id\u0151k\u00f6z\u00f6nk\u00e9nt keresni fogja a t\u00e9teleket a megadott id\u0151szak alapj\u00e1n. Ha a bot megtal\u00e1lja a t\u00e1rgyat \u00e9s van el\u00e9g p\u00e9nzed, aut\u00f3matikusan licit\u00e1l majd helyetted. *Megjegyz\u00e9s*: egyedi t\u00e1rgyak keres\u00e9s\u00e9hez a boltban legal\u00e1bb 1 v\u00e9letlenszer\u0171 t\u00e1rgyat hozz\u00e1 kell adnod a keres\u00e9si list\u00e1hoz.",
Uk:"A sz\u00f6rny sz\u00e1m\u00e1t a fenti gombok k\u00f6z\u00fcl v\u00e1laszthatod ki. A 1 a legbaloldali sz\u00f6rnyet k\u00e9pviseli. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",Ji:"V\u00e1lassz nehezs\u00e9get a kazamat\u00e1hoz a fentiek k\u00f6z\u00fcl. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",Ui:"Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sok",
Ki:"Felesleges arany t\u00e1rol\u00e1sa az egyes\u00fcletben az egyes\u00fcleti piacon t\u00e1rgyak v\u00e1s\u00e1rl\u00e1s\u00e1val. -> Min. Arany",dl:"Mindent Mozgat",el:"Kijel\u00f6ltek Mozgat\u00e1sa",Ok:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s",Pk:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",Fl:"Rubin",zg:"\u00c1ltal\u00e1nos Be\u00e1ll\u00edt\u00e1sok",wj:"Mindent Elad",xj:"Kijel\u00f6ltek Elad\u00e1sa",ja:"Fegyverek",ga:"Pajzsok",W:"Mellv\u00e9rtek",Z:"Sisakok",Y:"Keszty\u0171k",
ha:"Cip\u0151k",ea:"Gy\u0171r\u0171k",V:"Amulettek",ni:"\u00c9telek",mi:"Fejleszt\u00e9sek",Qg:"Receptek",gg:"Tekercsek",Sg:"Er\u0151s\u00edt\u00e9sek",Mg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",Lg:"\u00cdrja be a sz\u0171rend\u0151 kulcsszavakat, hogy kisz\u0171rje azokat a k\u00fcldet\u00e9seket, amelyeket nem szeretne v\u00e1llalni. You can also use this to accept quests by their reward using keywords.",X:"Adjon meg kulcssz\u00f3t",H:"Hozz\u00e1ad\u00e1s",Tg:"Elt\u00e1vol\u00edt\u00e1s",
Rd:"T\u00f6rl\u00e9s",Jg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Elfogad\u00e1sa",Kg:"\u00cdrja be a kulcsszavakat, hogy kiv\u00e1lassza, melyik k\u00fcldet\u00e9seket szeretn\u00e9 v\u00e1llalni. Ez figyelmen k\u00edv\u00fcl hagyja a k\u00fcldet\u00e9st\u00edpusokat",Ba:"Id\u0151 Sz\u0171r\u00e9s\u0171 K\u00fcldet\u00e9sek Kihagy\u00e1sa?",Bk:"K\u00fcldet\u00e9sek",Dd:"Automatikus Kost\u00fcm",oi:"Kost\u00fcm Haszn\u00e1lata?",Id:"Alap Harc",$d:"Dungeoni Harc",Ed:"A Bot csak akkor viseli a Dis Pater Normal \u00e9s Medium form\u00e1tumot, ha az exped\u00edci\u00f3/kazamata pontja 0.",
Pe:"Pokoli Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sai",ud:"T\u00e1mad\u00e1s a F\u0151ellens\u00e9g el\u00e9rhet\u0151v\u00e9 v\u00e1l\u00e1sakor?",jb:"Az Ligat\u00e1mad\u00e1s \u00f6nmag\u00e1t letiltja 5 sikertelen t\u00e1mad\u00e1s ut\u00e1n.",Se:"Szent Olajok",og:"T\u00e1rgy Neve",da:"Minim\u00e1lis T\u00e1rgyszint",Aa:"Minim\u00e1lis T\u00e1rgymin\u0151s\u00e9g",td:"Alkalmaz/T\u00f6r\u00f6l Minut\u00e9ri\u00e1t",Ve:"El\u0151tag/Ut\u00f3tag Kombin\u00e1ci\u00f3 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
wi:"Igen",vg:"Nem",Ha:"El\u0151tag Hozz\u00e1ad\u00e1sa",Ia:"Ut\u00f3tag Hozz\u00e1ad\u00e1sa",uh:"Olvasd el a List\u00e1t",Cb:"El\u0151tag",Ob:"Ut\u00f3tag",Zg:"Lej\u00e1r\u00f3 T\u00e1rgyak Vissza\u00e1ll\u00edt\u00e1sa",vh:"V\u00e9letlenszer\u0171 Olvasd el a Csomagokat?",wh:"Olvasd el a Lapon",hb:"Extr\u00e1k",yd:"\u00c1rver\u00e9s",Xf:"Piac",Pb:"Id\u0151z\u00edt\u0151k",Uh:"Olvasd el a Minut\u00e9ri\u00e1t",Th:"Olvasd el, ha nincs el\u00e9g arany",Qh:"Olvasd el, ha nincs t\u00e1rgy",Ca:"Jav\u00edt\u00e1s",
Ih:"Gilda Piac Aranytartalma",Eh:"\u00c1rver\u00e9s Aranytartalma",Xh:"Edz\u00e9s",Lh:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa",Vh:"\u00dczletek a Kov\u00e1cshoz",Ch:"\u00c1rver\u00e9s Ellen\u0151rz\u00e9se",Nh:"Keres\u00e9s",v:"Enged\u00e9lyez\u00e9s",qg:"Minim\u00e1lis Arany",Kb:"\u00d3ra Kiv\u00e1laszt\u00e1sa",eb:"Arany Adom\u00e1nyoz\u00e1sa a Gildinek",Vd:"Minden 5 percenk\u00e9nt adom\u00e1nyoz. Az id\u0151z\u00edt\u0151k lapr\u00f3l m\u00f3dos\u00edthatja az id\u0151k\u00f6zt",Te:"Mennyit szeretne adom\u00e1nyozni?",
Wd:"Adom\u00e1nyozni, amikor t\u00f6bb van, mint >",ef:"Kevesebb, mint <",Wg:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa \u00e9s Egy\u00e9b Be\u00e1ll\u00edt\u00e1sok",Yg:"Vissza\u00e1ll\u00edt\u00e1s ideje:",wk:"Tartsa lenyomva a Ctrl (Cmd a Mac-en) billenty\u0171t a t\u00f6bb t\u00e1rgy kiv\u00e1laszt\u00e1s\u00e1hoz",We:"Be-/Kiv\u00e1laszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Ee:"Be\u00e1ll\u00edt\u00e1sok Export\u00e1l\u00e1sa",Xe:"Be\u00e1ll\u00edt\u00e1sok Import\u00e1l\u00e1sa",hg:"\u00dczenet Minden J\u00e1t\u00e9kosnak",
ig:"[Ultra Pr\u00e9mium Kulcs sz\u00fcks\u00e9ges, \u00fczenet a Discordon az kulcs megszerz\u00e9s\u00e9hez.]",jg:"Adja meg az elk\u00fcldend\u0151 \u00fczenetet",Td:"Egyedi szkriptek\u00e9rt vegye fel a kapcsolatot vel\u00fcnk a Discordon",lg:"K\u00fcld\u00e9s",mg:"J\u00e1t\u00e9kosok Megjelen\u00edt\u00e9se",kg:"Mindet Kiv\u00e1laszt",ng:"\u00d6sszes Kiv\u00e1laszt\u00e1s Visszavon\u00e1sa",df:"Gy\u0151z\u0151dj\u00f6n meg r\u00f3la, hogy van el\u00e9g hely a t\u00e1sk\u00e1j\u00e1ban. A leh\u0171l\u00e9si id\u0151 2 perc."};if("true"!==localStorage.getItem("isInitialized")){const E={Timers:JSON.stringify({Smelting:10,SmeltingNoGold:5,SmeltingNoItem:15,Repair:10,GuildMarket:2,AuctionHoldGold:15,Arena:10,CircusTurma:10,Training:2,ResetExpired:30,SearchTimer:5,StoreForge:30,AuctionCheck:10,GuildDonate:15,guildBattleEnable:120,BuffTimer:5}),packagesPurchased:"[]",questKeywords:"[]",activeItems:'{"gloves":false,"shoes":false,"rings1":false,"rings2":false,"shield":false,"armor":false,"weapon":false,"helmet":false,"necklace":false}',
auctionPrefixes:"[]",auctionSuffixes:"[]",prefixes:"[]",suffixes:"[]",underworldQuestKeywords:"[]",UnderworldQuests:"false",statSettings:JSON.stringify([{stat:"Strength",count:"0",priority:null,continueTraining:!1},{stat:"Dexterity",count:"0",priority:null,continueTraining:!1},{stat:"Agility",count:"0",priority:null,continueTraining:!1},{stat:"Constitution",count:"0",priority:null,continueTraining:!1},{stat:"Charisma",count:"0",priority:null,continueTraining:!1},{stat:"Intelligence",count:"0",priority:null,
continueTraining:!1}]),farmEnable:"false",farmEnemy:"1",farmLocation:"0",HealPickBag:"1",AutoBidInterval:"5",AuctionItemLevel2:"0",HealShop:"false",noItemsLastCheck:"false",dungeonFocusQuest:"false",smeltBlue:"false",smeltGreen:"false",HealClothToggle:"false",questrewardvalue:"2000",smeltOrange:"false",smeltRed:"false",auctionTURBO:"false",smeltusehammers:"false",BuffsEnable:"false",repairPercentage:"10",HealRubyToggle:"false",dungeonLocation:"0",costumeBasic:"1",costumeDungeon:"2",smeltAnything:"false",
skipTimeQuests:"false",skipTimeCircusQuests:"false",costumeUnderworld:"9",wearUnderworld:"false",hellDifficulty:"1",repairMaxQuality:"1",FoodAmount:"3",smeltIgnorePS:"false",EnableSmelt:"false",filterGM:"p","AuctionEmpty.timeOut":"0","BuffCheck.timeOut":"0","CheckDolls.timeOut":"0","AuctionMEmpty.timeOut":"0",expeditionLocation:"0",auctionMinQuality:"0",doQuests:"false",unique_shop_results_height:"124",unique_shop_results_width:"184",unique_shop_results_top:"452",unique_shop_results_left:"368",search_results_top:"112",
search_results_width:"179",search_results_height:"284",search_results_left:"410",itemBought:"false",itemMovedToInventory:"false",AucTab:"true",patmp:"false",arenaPlayer:"true",repairInitiated:"true",doKasa:"false",packages:JSON.stringify({quality:[],type:[1,2,3,4,5,8,6,9,7,12,13,15,19,20,11,21,18,14,99]}),delaySelect:"0",autoAttackList:"[]",avoidAttackList:"[]",autoAttackCircusList:"[]",avoidAttackCircusList:"[]",autoAttackServerList:"[]",removeCircusList:"[]",removeArenaList:"[]",arenacrosslist:"[]",
circuscrosslist:"[]",autoAttackCircusServerList:"[]",doArena:"false",doCircus:"false","gladBotChecks.timeOut":"0","repair.timeOut":"0","storeForgeResources.timeOut":"0",HealCervisia:"false",dungeonAB:"false",bidStatus:"4",doDungeon:"false",doExpedition:"false",arenaAttackGM:"false",circusAttackGM:"false",AutoAuction:"false",auctionminlevel:"0",storeGoldinAuctionmaxGold:"0",storeGoldinAuction:"false",autoAddArenaAmount:"0",autoAddCircusAmount:"0",eventPoints_:"16",storeGoldinAuctionholdGold:"0",TrainingHoldGold:"0",
smeltLevel:"1",MarketHoldGold:"0",KasaHoldGold:"0",HealPackage:"false",smeltPurple:"false",guildPackHour:"3",smeltEverything3:"false",questSpeed:"2","enableHideGold.timeOut":"0",bidFood:"false",auctionmercenaryenable:"false",auctiongladiatorenable:"false",maximumBid:"100000",activateAuction2:"false",scoreboardattackenable:"false",scoreRange:"5",auctionlanguagesettings:JSON.stringify(["Very long","Long","Middle","Short","Very short"]),scoreboardcircusenable:"false",healPercentage:"25",hellEnterHP:"75",
questTypes:JSON.stringify({combat:!0,arena:!0,circus:!0,expedition:!1,dungeon:!1,items:!1}),scoreRangeCircus:"5",underworld:JSON.stringify({cooldown:"",wins:0,isUnderworld:!1,Zi:!1}),enableMarketSearch:"false",smeltTab:"1",UnderWorldUseRuby:"false",renewEvent:"false","arena.timeOut":"0","circus.timeOut":"0",AuctionCover:"false",AuctionGoldCover:"false",UnderworldUseMobi:"false",MarketSearchInterval:"5",useVillaMedici:"false",autoEnterHell:"false",useHealingPotion:"false",repairMercenary:"false",repairALL:"false",
AutoBidButton:"false",healstopbot:"false",HealEnabled:"false",minimumGoldAmount:"100000",doEventExpedition:"false",GuildMemberBid:"false",autoCollectBonuses:"false",exitUnderworld:"false",workbench_selectedItem:JSON.stringify({})};Object.keys(E).forEach(J=>{null===localStorage.getItem(J)&&localStorage.setItem(J,E[J])});["license_playerId","eventPoints","playerTimeouts"].forEach(J=>{null!==localStorage.getItem(J)&&localStorage.removeItem(J)});localStorage.setItem("isInitialized","true")};
