var ba="",ea="",we="",showTrial="",pa="",ra={},sa={enable:!1,ep:10,sp:1,repairArena:!0,repairTurma:!0,itemList1:[],itemList2:[]},ya={type:[],quality:[],Qp:!1,useCloths:!1},Aa={enable:!1,Sm:!1,nn:[1],ho:3,Jn:3,co:3,fo:3,zn:3,xo:3};function G(F){let L=`${window.location.origin}/game/index.php?`;Object.entries(F).forEach((C,Q)=>{L+=(0==Q?"":"&")+C[0]+"="+C[1]});return L}function S(F){let L=`${window.location.origin}/game/ajax.php?`;Object.entries(F).forEach((C,Q)=>{L+=(0==Q?"":"&")+C[0]+"="+C[1]});return L}
async function Ca(F,L){L=await Ia(F,L);if(!L)return!1;L.slot&&await Ka(L.slot,F.dataset.itemId||F.parentNode.dataset.containerNumber);Sa(F,L.x,L.y);return!0}
async function Sa(F,L,C){var Q=jQuery(F).offset();Q={x:Q.left,y:Q.top};db(F,"mousedown",{clientX:Q.x-window.scrollX,clientY:Q.y-window.scrollY});db(document,"mousemove",{clientX:L-window.scrollX,clientY:C-window.scrollY});db(document,"mouseup",{clientX:L-window.scrollX,clientY:C-window.scrollY});setTimeout(()=>{window.scroll(scroll.x,scroll.y)},0)}function pb(F){F=F.getAttribute("data-quality");return null!=F?F:"0"}function vb(F){return wb(F).split("-")[0]}
function xb(F){return parseInt(F.getAttribute("data-amount"),10)}function Db(F){return F.getAttribute("data-content-type")}function Eb(F){return F.getAttribute("data-level")}function wb(F){return F.getAttribute("data-basis")}
function Vb(F,L){var C=[248,284,275,269,283,282,272,194,259,261,241,166,266,246,258,277,247,270,202,243,242,279,254,274,256,245,250,268,244,281,257,263,278,276,289,262,280,286,267,271,252,255,288,260,264,265];F=parseInt(F.split("-")[0],10);if(![1,2,3,4,5,6,8,9,20].includes(F))return!1;L=L.split("-");F=parseInt(L[6],36);return-1<[173,156,158,182,175,168,180,178,177,162,179,174,172,155,171,183,167,159,166,176,164,157,181,169,161,163,165].indexOf(parseInt(L[5],36))||-1<C.indexOf(F)}
function Wb(F){return parseInt(F.getAttribute("data-measurement-x"),10)*parseInt(F.getAttribute("data-measurement-y"),10)}function Xb(F){F=F.getAttribute("data-tooltip");F=F.substring(4,F.indexOf(",")).replace('"',"");return unescape(JSON.parse('"'+F+'"'))}function Yb(F){F=F.getAttribute("data-tooltip");return parseInt(F.replace(/\./g,"").match(/(\d+) (<img|<div class=\\"icon_gold\\")/i)[1],10)}
function Zb(F){F=parseInt(F.getAttribute("data-basis").split("-")[0],10);return-1<[1,2,3,4,5,6,8,9].indexOf(F)}function $b(F){for(var L=0,C=0;C<F.length;C++){var Q=F[C];L+=Q.cl*Q.w}return L}function ac(F){if("string"!==typeof F)return"";F=F.split(" ");return F[F.length-1]}
async function ic(F,L,C){return new Promise(Q=>{async function R(ua){ua===da.length&&R(ua+1);await jQuery.post(da[ua],va=>{va=jQuery("<div>").append(va)[0];va=Fc(va);va=Gc(ka[0],ka[1],va);(va=Hc(L,F,va))?(Q({spot:va,bag:ua+512}),C&&"function"===typeof C&&C(va,ua+512)):R(ua+1)})}let da=[];for(var ma of[512,513,514,515])da.push(S({mod:"inventory",submod:"loadBag",shopType:0,bag:ma,sh:U("sh")}));let ka=[5,8];R(0)})}var Ic=[],gf={};
function Ka(F,L){if("inv"==F.target||"shop"==F.target){var C=hf(F.target),Q=[];for(let R=0;R<F.w;R++)for(let da=0;da<F.cl;da++)Q.push(C+"<"+(F.x+R)+","+(F.y+da)+">");Q.forEach(R=>{Ic.includes(R)||Ic.push(R)});L&&(jf(L),gf[L]=Q)}}function jf(F){F&&gf.hasOwnProperty(F)&&(gf[F].forEach(L=>{L=Ic.indexOf(L);-1<L&&Ic.splice(L,1)}),delete gf[F])}
function hf(F){let L=document.getElementById(F);return L?"inv"==F?L.parentNode.getElementsByClassName("awesome-tabs current")[0].dataset.Ro:"inv"==F?L.dataset.containerNumber:F:F}
function kf(F,L){var C=F.querySelectorAll('.ui-draggable:not([style*="display: none"])');F=Array(5).fill(null).map(()=>Array(8).fill(!1));const Q=parseInt(L.getAttribute("data-measurement-x"),10);L=parseInt(L.getAttribute("data-measurement-y"),10);for(var R of C){C=parseInt(R.getAttribute("data-position-x"),10)-1;var da=parseInt(R.getAttribute("data-position-y"),10)-1,ma=parseInt(R.getAttribute("data-measurement-x"),10),ka=parseInt(R.getAttribute("data-measurement-y"),10);for(let ua=0;ua<ma;ua++)for(let va=
0;va<ka;va++)0<=C+ua&&8>C+ua&&0<=da+va&&5>da+va&&(F[da+va][C+ua]=!0)}for(R=0;5>R;R++)for(C=0;8>C;C++){da=!0;for(ma=0;ma<Q;ma++){for(ka=0;ka<L;ka++)if(8<=C+ma||5<=R+ka||F[R+ka][C+ma]){da=!1;break}if(!da)break}if(da)return{x:C,y:R}}return null}
function lf(F){var L=F.querySelectorAll('.ui-draggable:not([style*="display: none"])');F=Array(5).fill(null).map(()=>Array(8).fill(!1));for(var C of L){L=parseInt(C.getAttribute("data-position-x"),10)-1;const Q=parseInt(C.getAttribute("data-position-y"),10)-1,R=parseInt(C.getAttribute("data-measurement-x"),10),da=parseInt(C.getAttribute("data-measurement-y"),10);for(let ma=0;ma<R;ma++)for(let ka=0;ka<da;ka++)0<=L+ma&&8>L+ma&&0<=Q+ka&&5>Q+ka&&(F[Q+ka][L+ma]=!0)}for(C=0;5>C;C++)for(L=0;8>L;L++)if(!F[C][L])return{x:L,
y:C};return null}
async function Ia(F,L){if("shop"==L){var C=document.getElementById("shop");var Q=[Math.round(C.clientHeight/32),6]}else if("inv-guild"==L)Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));else if("inv"==L)C=document.getElementById("inv"),Q=[5,8];else{if("market"==L){C=document.getElementById("market_sell");var R=jQuery(C).offset();return{x:Math.ceil(R.left+32+8),y:Math.ceil(R.top+32+8),parent:C}}if("avatar"==L)return C=document.getElementById("avatar"),R=
jQuery(C).offset(),{x:Math.ceil(R.left+84),y:Math.ceil(R.top+97),parent:C};if("char"==L)for(var da=document.getElementById("char").children,ma=Number(F.dataset.contentType||"0"),ka=0;ka<da.length;ka++){var ua=da[ka];if(Number(ua.getAttribute("data-content-type-accept")||"0")==ma&&0==da[ka].children.length)return R=jQuery(ua).offset(),{x:R.left+5,y:R.top+5}}else return!1}da=Fc(C);ma=parseInt(F.dataset.measurementX,10);ka=parseInt(F.dataset.measurementY,10);try{var va;if(va="shop"!=L)a:{let Ya=F.dataset.amount?
parseInt(F.dataset.amount,10):1;for(ua=0;ua<da.length;ua++)if(da[ua].hash==F.dataset.hash&&100>=da[ua].amount+Ya){va={y:da[ua].y,x:da[ua].x};break a}va=!1}var eb=va||Hc(ka,ma,Gc(Q[0],Q[1],da));if(!eb)return!1;R=jQuery(C).offset();R={x:R.left,y:R.top};return eb={x:Math.ceil(R.x+32*eb.x+8),y:Math.ceil(R.y+32*eb.y+8),parent:C,slot:{target:L,x:eb.x,y:eb.y,cl:ka,w:ma}}}catch{return!1}}
function Fc(F){if(!F)return[];var L=[];F=F.getElementsByClassName("ui-draggable");for(var C=0;C<F.length;C++)L.push({y:parseInt(F[C].style.top,10)/32,x:parseInt(F[C].style.left,10)/32,cl:parseInt(F[C].dataset.measurementY,10),w:parseInt(F[C].dataset.measurementX,10)});return L}function Gc(F,L,C){var Q,R,da=[];for(Q=0;Q<F;Q++)for(da.push([]),R=0;R<L;R++)da[Q].push(!1);for(F=C.length-1;0<=F;F--)for(Q=0;Q<C[F].cl;Q++)for(R=0;R<C[F].w;R++)da[C[F].y+Q][C[F].x+R]=!0;return da}
function Hc(F,L,C){var Q,R,da,ma,ka=!1;for(Q=0;Q<=C[0].length-L;Q++){for(R=0;R<=C.length-F;R++){if(ka=!0,1==F)0==C[R][Q]?ka=!0:0==C[R][Q+1]?Q++:ka=!1;else for(da=0;da<L;da++){for(ma=0;ma<F;ma++)if(1==C[R+ma][Q+da]){ka=!1;break}if(!ka)break}if(ka){for(da=0;da<L;da++)for(ma=0;ma<F;ma++)C[R+ma][Q+da]=!0;ka={y:R,x:Q};break}}if(ka)break;1==F&&Q++}return ka}
function db(F,L,C){var Q="mousemove"!==L,R=window;var da=C.clientX;C=C.clientY;var ma=document.createEvent("MouseEvents");ma.initMouseEvent(L,!0,Q,R,0,0,0,da,C,!1,!1,!1,!1,0,document.body.parentNode);F.dispatchEvent(ma)}
function mf(){new Promise(F=>{let L=2,C=()=>{--L;0===L&&F()};if(nf.includes("mod=auction")&&nf.includes("ttype=3")){var Q=of();(Q<localStorage.getItem("auctionMStatus")&&W("AuctionMEmpty")||4===Q&&W("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",Q);C()}else nf.includes("mod=auction")?(Q=of(),(Q<localStorage.getItem("auctionStatus")&&W("AuctionEmpty")||4===Q&&W("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",0),localStorage.setItem("auctionStatus",
Q),C()):(jQuery.get(G({mod:"auction",ttype:3,itemLevel:999,itemQuality:2,sh:U("sh")}),R=>{R=of(jQuery(R));(R<localStorage.getItem("auctionMStatus")&&W("AuctionMEmpty")||4===R&&W("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",R);C()}),jQuery.get(G({mod:"auction",itemLevel:999,itemQuality:2,sh:U("sh")}),R=>{R=of(jQuery(R));(R<localStorage.getItem("auctionStatus")&&W("AuctionEmpty")||4===R&&W("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",
0);localStorage.setItem("auctionStatus",R);C()}))})}function pf(F){if(document.querySelector("#inv div.spinner-img"))return setTimeout(()=>{pf(F)},500),!1;F&&F();return!0}var zf=new URLSearchParams(window.location.search);function U(F){return zf.get(F)}
var nf=window.location.search.match(/mod=.*&sh/)?window.location.search.match(/mod=.*&sh/)[0].slice(0,-3):null,Af=window.location.hostname.split(/\./)?window.location.hostname.split(/\./)[0]:null,Bf={Cp:{l:"muito longo",h:"longo",i:"m\u00e9dio",j:"curto",m:"muito curto"},Dp:{l:"foarte lung",h:"lung",i:"mijlociu",j:"scurt",m:"foarte scurt"},Hp:{l:"ve\u013emi dlho",h:"dlho",i:"stredne",j:"kr\u00e1tko",m:"ve\u013emi kr\u00e1tko"},Sp:{l:"jako dugo",h:"dugo",i:"srednje",j:"kratko",m:"jako kratko"},fp:{l:"hyvin pitk\u00e4",
h:"pitk\u00e4",i:"keskim\u00e4\u00e4r\u00e4inen",j:"lyhyt",m:"hyvin lyhyt"},Fp:{l:"mycket l\u00e5ng",h:"l\u00e5ng",i:"medel",j:"kort",m:"mycket kort"},Kp:{l:"\u00e7ok uzun",h:"uzun",i:"orta",j:"k\u0131sa",m:"\u00e7ok k\u0131sa"},Oo:{l:"\u0637\u0648\u064a\u0644 \u062c\u062f\u0627\u064b",h:"\u0637\u0648\u064a\u0644",i:"\u0645\u0646\u062a\u0635\u0641",j:"\u0642\u0635\u064a\u0631",m:"\u0642\u0635\u064a\u0631\u0629 \u062c\u062f\u0627\u064b"},np:{l:"\u05d0\u05e8\u05d5\u05da \u05de\u05d0\u05d5\u05d3",h:"\u05d0\u05e8\u05d5\u05da",
i:"\u05d1\u05d9\u05e0\u05d5\u05e0\u05d9",j:"\u05e7\u05e6\u05e8",m:"\u05e7\u05e6\u05e8 \u05de\u05d0\u05d5\u05d3"},jp:{l:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",h:"\u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",i:"m\u03ad\u03c3\u03b7",j:"\u03bc\u03b9\u03ba\u03c1\u03ae",m:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b9\u03ba\u03c1\u03ae"},So:{l:"\u043c\u043d\u043e\u0433\u043e \u0434\u044a\u043b\u044a\u0433",h:"\u0434\u044a\u043b\u044a\u0433",i:"\u0441\u0440\u0435\u0434\u0435\u043d",j:"\u043a\u044a\u0441",
m:"\u043c\u043d\u043e\u0433\u043e \u043a\u044a\u0441"},Ep:{l:"\u043e\u0447\u0435\u043d\u044c \u043c\u043d\u043e\u0433\u043e",h:"\u043c\u043d\u043e\u0433\u043e",i:"\u0441\u0440\u0435\u0434\u043d\u0435",j:"\u043c\u0430\u043b\u043e",m:"\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e"},To:{l:"muito tempo",h:"longo",i:"m\u00e9dio",j:"curto",m:"bastante curto"},Xo:{l:"velmi dlouh\u00e1",h:"dlouh\u00e1",i:"st\u0159edn\u00ed",j:"kr\u00e1tk\u00e1",m:"velmi kr\u00e1tk\u00e1"},Zo:{l:"meget lang tid",
h:"lang tid",i:"halv tid",j:"kort tid",m:"meget kort tid"},Yo:{l:"sehr lange",h:"lange",i:"mittel",j:"kurz",m:"sehr kurz"},$o:{l:"v\u00e4ga pikk",h:"pikk",i:"keskmine",j:"l\u00fchike",m:"v\u00e4ga l\u00fchike"},ap:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},Pp:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},Po:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},cp:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},up:{l:"muy largo",h:"largo",i:"medio",
j:"corto",m:"muy corto"},gp:{l:"tr\u00e8s longtemps",h:"longtemps",i:"moyen",j:"court",m:"tr\u00e8s court"},pp:{l:"lunghissima",h:"lunga",i:"media",j:"breve",m:"brevissima"},rp:{l:"\u013coti gar\u0161",h:"gar\u0161",i:"vid\u0113js",j:"\u012bss",m:"\u013coti \u012bss"},qp:{l:"labai ilgai",h:"ilgai",i:"vidutini\u0161kai",j:"trumpai",m:"labai trumpai"},mp:{l:"nagyon hossz\u00fa",h:"hossz\u00fa",i:"k\u00f6zepes",j:"r\u00f6vid",m:"nagyon r\u00f6vid"},vp:{l:"heel lang",h:"lang",i:"gemiddeld",j:"kort",m:"zeer kort"},
Pi:{l:"veldig lenge",h:"lenge",i:"medium",j:"kortvarig",m:"veldig kort"},Bp:{l:"bardzo d\u0142ugi",h:"d\u0142ugi",i:"\u015bredni",j:"kr\u00f3tki",m:"bardzo kr\u00f3tki"},Np:{l:"\u8d85\u9577",h:"\u8f03\u9577",i:"\u5e38\u898f\u6642\u9593",j:"\u8f03\u77ed",m:"\u8d85\u77ed"}},of=(F=document)=>{F=jQuery(".description_span_right",F).text().trim().toLowerCase();for(const L in Bf){const C=Bf[L],Q=Object.values(C);for(const R in C)if(C[R].toLowerCase()===F)return Q.indexOf(C[R])}return-1};
async function Cf(F="-1",L=""){const C=G({mod:"packages",submod:"sort",page:"1",sh:U("sh")});jQuery.post(C,{packageSorting:"in_desc"});return Promise.all(Array.from({length:2},(Q,R)=>R+1).map(async Q=>await Df(F,L,Q))).then(Q=>Q.reduce((R,da)=>R.concat(da),[]))}async function Df(F="-1",L="",C){F=await jQuery.get(G({mod:"packages",f:"0",fq:F||-1,qry:L||"",page:C,sh:U("sh")}),()=>{});return Array.from(jQuery(F).find(".packageItem"))}function Ef(F){setTimeout(()=>{window.location.reload(!1)},F)}
function zh(F){window.location.href=`${window.location.origin}/game/index.php?${F}&sh=${U("sh")}`}function Ah(F){F&&(F.classList.contains("disabled")?window.location.reload():F.click())}
function Bh(){return{o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,"")),On:document.querySelectorAll("#cooldown_bar_expedition .cooldown_bar_fill_ready")[0],Mn:document.querySelectorAll("#cooldown_bar_dungeon .cooldown_bar_fill_ready")[0],Mp:document.querySelectorAll("#cooldown_bar_ct .cooldown_bar_fill_ready")[0],Ka:document.getElementById("expeditionpoints_value_point").innerText,Ln:document.getElementById("dungeonpoints_value_point").innerText,
Qo:document.querySelectorAll("#cooldown_bar_arena .cooldown_bar_fill_ready")[0],hn:parseInt(document.getElementById("sstat_ruby_val").innerText,10),level:parseInt(document.getElementById("header_values_level").innerText,10)}}function W(F){let L=(new Date).getTime(),C=localStorage.getItem(F+".timeOut");null===C?(localStorage.setItem(F+".timeOut",0),C=0):C=parseInt(C,10);return C<=L?!0:!1}
function Ch(){let F=0;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(L=>{F+=Math.round(.04*L.price)});return Bh().gold>=F?!0:!1}function Dh(F,L){L-=F;let C=.04*F;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(Q=>{C+=Math.round(.04*Q.price)});return L>=C}function Y(F,L){localStorage.setItem(F+".timeOut",(new Date).getTime()+Math.floor(6E4*(L?L:5)))};(async function(){function F(){qf=setInterval(function(){rf++;5>=rf?location.reload():clearInterval(qf)},12E4)}function L(){var b="Pantheon;Panteon;Gudarnas tempel;\u0628\u0627\u0646\u062a\u064a\u0648\u0646;\u041f\u0430\u043d\u0442\u0435\u043e\u043d;Panth\u00e9on;\u795e\u8aed;\u05e4\u05e0\u05ea\u05d9\u05d0\u05d5\u05df".split(";"),c=null;for(var e of b)if(c=document.querySelector(`a[title="${e}"]`))break;return c&&(b=c.innerHTML,(e=b.match(/<font color="green">(\d+)<\/font>/))&&0<e[1]||b.includes('color="green"')||
b.includes("Nowe")||b.includes("Yeni")||b.includes("New")||b.includes('color="yellow"')||b.includes("Yeni")||b.includes("Nowe")||b.includes("New")||(c=c.innerText.match(/Pantheon \((\d+)\)/))&&0<c[1])?(localStorage.setItem("nextQuestTime",0),localStorage.setItem("nextQuestTime.timeOut",0),!0):!1}function C(b){function c(g){let l=localStorage.getItem(g);l&&(l=JSON.parse(l),localStorage.setItem(g,JSON.stringify(l.slice(-20))))}var e=document.querySelector("#logEntriesContainer");if(e){var h=new Date,
k=`${h.getHours().toString().padStart(2,"0")}:${h.getMinutes().toString().padStart(2,"0")}`;h=document.createElement("p");h.style.margin="0";h.style.padding="0";h.style.fontSize="12px";b=`[${k}] ${b}`;h.textContent=b;e.prepend(h);(e=localStorage.getItem("savedLogs"))?e=JSON.parse(e):e=[];e.unshift(b);30<e.length&&e.pop();localStorage.setItem("savedLogs",JSON.stringify(e));c("bidList");c("smeltedItems");c("MarketboughtItems")}}function Q(b,c){switch(b){case "itemRepaired":ja.um++;break;case "itemReset":ja.vm++;
break;case "goldCycled":ja.sm++;break;case "arenaAttacks":ja.hm++;break;case "circusAttacks":ja.km++;break;case "dungeonAttacks":ja.nm++;break;case "expeditionAttacks":ja.pm++;break;case "itemSmelted":ja.wm++;break;case "underworldAttacks":ja.Em++;break;case "arenaMoney":ja.Ul+=c;break;case "circusMoney":ja.Vl+=c}localStorage.setItem("userStats",JSON.stringify(ja))}function R(){fb||(fb=document.createElement("div"),fb.className="confirmation-popup",fb.innerHTML='\n                <p>Are you sure you want to reset the bot?</p>\n                <button id="confirmReset">Yes</button>\n                <button id="cancelReset">No</button>\n            ',
document.body.appendChild(fb),document.getElementById("confirmReset").addEventListener("click",function(){const b=["tkz_lcr","Username","tkn","nana_lcn"];let c=[];for(let e=0;e<localStorage.length;e++){const h=localStorage.key(e);!h||b.includes(h)||h.startsWith("gladiatusCrazyAddonData_")||c.push(h)}for(const e of c)localStorage.removeItem(e);window.location.reload();fb.style.display="none"}),document.getElementById("cancelReset").addEventListener("click",function(){fb.style.display="none"}));fb.style.display=
"block"}function da(b,c){return null==b?"":b.split("").map(e=>String.fromCharCode(e.charCodeAt(0)+c)).join("")}async function ma(b,c,e,h){h=da(h,3);const k={action:"vx",data:{token:b,refreshToken:c,playerId:e,bp:h}};try{const g=await Promise.race([new Promise((l,q)=>{chrome.runtime.sendMessage(k,m=>{chrome.runtime.bo||!m?q(chrome.runtime.bo||"No response"):l(m)})}),new Promise(l=>setTimeout(()=>l("timeout"),6E4))]);if("timeout"===g)await new Promise(l=>setTimeout(l,1E3)),window.location.reload();
else if(g.success||g.s){const l=g.data||g.d;if(l.valid&&!l.expired)return ba=l.playerId,pa=l.supportDevs,"true"!==localStorage.getItem("nana_lcn")&&localStorage.setItem("nana_lcn","true"),l.announcement&&0<=l.announcement.length&&localStorage.getItem("latestAnnouncement")!==l.announcement&&localStorage.setItem("latestAnnouncement",l.announcement),await ua(l.supportDevs).then(q=>{ea=q}),!0;if(l.expired&&(sessionStorage.setItem("autoGoActive","false"),l.newToken))return l.newToken&&(localStorage.setItem("token",
l.newToken+1),localStorage.setItem("nana_lcn","false"),ba=bc()+"l",gb()),!1}else new Promise(l=>setTimeout(()=>l("timeout"),3E4))}catch(g){return window.location.reload(),!1}}function ka(b){return((localStorage.getItem("playerId")|0)+5|0)%100===b}async function ua(b){function c(l){const q=[];for(let m=0;m<l.length;m+=2)q.push(parseInt(l.substr(m,2),16));return new Uint8Array(q)}const [e,h]=b.split(":");b=c(e);const k=c(h),g=await window.crypto.subtle.importKey("raw",c("46d9ef519c1474cf8699ba24ab2a726a"),
{name:"AES-CBC"},!1,["decrypt"]);b=await window.crypto.subtle.decrypt({name:"AES-CBC",iv:b},g,k);b=(new TextDecoder).decode(new Uint8Array(b));b=new Date(b);b.setHours(0,0,0,0);return b}function va(b){(b.target.classList.contains("licotok-close")||"licotok"===b.target.id)&&document.getElementById("licotok").remove()}async function eb(){bc();const b=document.getElementById("licotok-input").value.trim(),c=localStorage.getItem("playerId"),e=document.getElementById("status_message");const u=localStorage.getItem("idkps");let response=null;try{
response=await fetch('https://gldbotserver.com/validate-license',{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idkps:u,license:b}),});const data=await response.json();if(data.valid){localStorage.setItem("nana_lcn","true"),localStorage.setItem("tkz_lcr",data.token),localStorage.setItem("license_remaining",data.expirationDate),localStorage.setItem("globalAnnouncement",data.globalAnnouncement),localStorage.setItem("tkn",data.refreshToken),localStorage.setItem("we",data.p),localStorage.setItem("pid",c),ba=c,window.location.reload()
}else{e.textContent=data.message||"Invalid license key or token! Just purchased? Wait 10 minutes before activating the key.";e.style.display="block";}}catch(error){alert("Erro no servidor de autenticação");}}function Ya(b){var c=document.createElement("div");c.setAttribute("id","licotok");c.innerHTML=`
        <style>
            .licotok-popup {
            background: #ddd5b4; /* Beige background */
            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            color: #333; /* Darker text color for better contrast */
            padding: 20px;
            border: 1px solid #c4ac70; /* Golden border */
            font-family: Arial, sans-serif; /* Optional: Change the font */
            }
        
            .licotok-popup h2 {
            color: #333;
            text-shadow: none; /* Removing text shadow for better readability */
            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */
            padding: 10px;
            margin: -20px; /* To offset the padding of the parent */
            margin-bottom: 15px;
            border-radius: 10px 10px 0 0; /* Rounded corners on the top */
            }
        
            .licotok-popup a {
            text-decoration: none;
            color: #fff; /* White text for buttons */
            background-color: #c4ac70; /* Golden background */
            border-radius: 5px;
            padding: 5px 10px;
            margin-right: 10px;
            transition: background-color 0.3s ease;
            }
        
            .licotok-popup a:hover {
            background-color: #b3a369; /* Darker shade on hover */
            }
        
            .licotok-popup input {
            width: calc(100% - 10px); /* Full width minus padding */
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #c4ac70; /* Border color similar to the theme */
            border-radius: 5px;
            }
        

            
            .licotok-popup #status_message {
            margin-top: 10px;
            }
        </style>
        <div class="licotok-popup">
        <h2>Warning</h2>
        <span style="color: black" class="span-new">${b}</span>
        <p>
        <button id="licotok-close" class="awesome-button">Close</button>
        <div id="status_message"></div>
    </div>
        
        `;document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);c.querySelector("#licotok-close").addEventListener("click",function(){c.remove()})}function Lh(){var b=document.createElement("div");b.setAttribute("id","licotok");b.innerHTML = '\n        <style>\n            .licotok-popup {\n            background: #ddd5b4; /* Beige background */\n            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n            border-radius: 10px;\n            color: #333; /* Darker text color for better contrast */\n            padding: 20px;\n            border: 1px solid #c4ac70; /* Golden border */\n            font-family: Arial, sans-serif; /* Optional: Change the font */\n            }\n        \n            .licotok-popup h2 {\n            color: #333;\n            text-shadow: none; /* Removing text shadow for better readability */\n            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */\n            padding: 10px;\n            margin: -20px; /* To offset the padding of the parent */\n            margin-bottom: 15px;\n            border-radius: 10px 10px 0 0; /* Rounded corners on the top */\n            }\n        \n            .licotok-popup a {\n            text-decoration: none;\n            color: #fff; /* White text for buttons */\n            background-color: #c4ac70; /* Golden background */\n            border-radius: 5px;\n            padding: 5px 10px;\n            margin-right: 10px;\n            transition: background-color 0.3s ease;\n            }\n        \n            .licotok-popup a:hover {\n            background-color: #b3a369; /* Darker shade on hover */\n            }\n        \n            .licotok-popup input {\n            width: calc(100% - 10px); /* Full width minus padding */\n            padding: 5px;\n            margin-bottom: 10px;\n            border: 1px solid #c4ac70; /* Border color similar to the theme */\n            border-radius: 5px;\n            }\n        \n\n            \n            .licotok-popup #status_message {\n            margin-top: 10px;\n            }\n        </style>\n        <div class="licotok-popup">\n            <h2>Enter Your License Key</h2>\n            <input id="licotok-input" type="text" placeholder="License Key">\n            &nbsp<a href="https://gldbotserver.com" target="_blank">Buy GLDbot license</a>\n                        <a href="https://gldbot.gumroad.com/l/gladiatusbot" target="_blank">Gumroad official page</a>\n                        <p>\n            <a href="#" id="get-trial-key-a">Get a Trial Key</a>\n            <a href="" target="_blank">Discord</a>\n                       <div id="alertMessage" class="alert-message" style="display: none; font-weight: bold;"></div>\n\n      <hr>      <li>\n             <span style="color: class="span-new">[BRASIL] Experimente o teste gratuito de 1 dia. A licença ficará salva na aba “Extras” caso você esqueça. Se você limpar a cache ou reinstalar o navegador. Você deve inserir sua chave novamente para ativar o bot.</span>\n            </li>\n      <hr>      <li>\n            <span style="color: class="span-new">[ENGLISH] Try 1 day free trial. The license will be saved in the "Extras" tab in case you forget it. If you clear your caches or reinstall the browser. You have to enter your key again to enable the bot.</span>\n     <hr>       </li>\n            <p>\n            <span style="color: class="span-new">If you have some questions or suggestions, contact us E-mail: <strong>gldbotsuport@gmail.com</strong></span>\n\n  <br>          <button class="awesome-button licotok-submit">Submit</button>\n            <button class="awesome-button licotok-close">Close</button>\n            <div id="status_message"></div>\n        </div>\n        ';
document.getElementById("header_game").insertBefore(b,document.getElementById("header_game").children[0]);b.addEventListener("click",va);b.querySelector(".licotok-submit").addEventListener("click",eb);let c=localStorage.getItem("idkps");if(null==c)try{bc(),c=localStorage.getItem("idkps")}catch{}b.querySelector("#get-trial-key-a").addEventListener("click",function(){async function e(h){return fetch(h,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({playerId:c})}).then(k=>
k.json()).then(k=>{var g=document.getElementById("alertMessage");k.success?(g.textContent="Your 1 day trial key : "+k.trialKey,g.style.display="block",showTrial=k.trialKey,localStorage.setItem("showTrial",k.trialKey)):(g.textContent=k.message,g.style.display="block")})}e("https://gldbotserver.com/get-trial").catch(()=>e("https://gldbotserver.com/get-trial")).catch(()=>{})})}
function bc(){let b;if(!b){const c=/var playerId\s*=\s*(\d+);/;Array.from(document.getElementsByTagName("script")).some(e=>(e=c.exec(e.textContent||e.innerText))&&e[1]?(b=e[1],!0):!1)}if(!b){const c=document.getElementById("content");c&&c.querySelectorAll('section[style="display: block;"]').forEach(e=>{Array.from(e.getElementsByTagName("p")).forEach(h=>{Array.from(h.getElementsByTagName("b")).forEach(k=>{k=k.textContent.trim();k.includes("gladiatus.gameforge.com/game/index.php?mod=player&")&&(b=(new URLSearchParams((new URL(k)).search)).get("p"))})})})}b||
(document.cookie.split("; ").forEach(c=>{c.trim().startsWith("gladiatus")&&!b&&(c=decodeURIComponent(c.split("=")[1]).match(/^\d+/))&&(b=c[0])}),document.cookie.split("; ").forEach(c=>{c.trim().startsWith("GB_")&&!b&&(c=c.split("=")[1].split("_"),b=0<c.length&&!isNaN(c[0])?c[0]:null)}));let cc=b;return b?(localStorage.setItem("playerId",18835),localStorage.setItem("pid",18835),localStorage.setItem("idkps",cc),18835):null}function Mh(){let b=document.querySelector(".playername")||document.querySelector(".playername_achievement");b&&(b=b.textContent.trim(),
localStorage.setItem("Username",b))}async function rest(){const autoGoButton=document.getElementById("autoGoButton");if(autoGoButton)autoGoButton.remove();const customButtons=document.querySelectorAll(".customButton2");customButtons.forEach(button=>button.remove());sessionStorage.setItem("autoGoActive",!1);}async function pt(){bc();const idkps=localStorage.getItem("idkps");try{const response=await fetch('https://gldbotserver.com/validate-key',{method:'POST',headers:{'Content-Type':'application/json',},body:JSON.stringify({idkps}),});const d=await response.json();if(d.valid){localStorage.setItem("we",d.p);localStorage.setItem("globalAnnouncement",d.globalAnnouncement);xf();}else{rest().then(()=>{gb();}).catch(error=>{console.error("rest:",error);});}}catch(error){alert("Erro ao conectar com o servidor de autenticação");}}async function sf(){try{const b=await jQuery.get(G({mod:"premium",submod:"centurio",sh:U("sh")})),c=(new DOMParser).parseFromString(b,"text/html").querySelector("#premium_duration");if(c){const e=c.textContent.trim().match(/(\d+)/);if(e&&e[1]){const h=parseInt(e[1],10);localStorage.setItem("premiumDays",h);if(0<h)return!1}else return!0}}catch(b){}}function qb(b,c,e){var h="";e&&(h=new Date,h.setTime(h.getTime()+864E5*e),h="; expires="+h.toUTCString());document.cookie=
b+"="+(c||"")+h+"; path=/; domain=.gameforge.com"}function yb(b){b+="=";for(var c=document.cookie.split(";"),e=0;e<c.length;e++){for(var h=c[e];" "===h.charAt(0);)h=h.substring(1,h.length);if(0===h.indexOf(b))return h.substring(b.length,h.length)}return null}function tf(b){document.cookie=`glautologin=${b?"true":"false"}; path=/; domain=.gameforge.com; samesite=strict`}async function Jc(){const z5=localStorage.getItem("we");we=new Date(z5);return"true"===localStorage.getItem("nana_lcn")&&cc&&ea>=new Date&&we>=new Date&&wa===Kc&&ba===wa}function Lc(b,c){b.style.border=
"1px solid #c4ac70";b.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";b.style.color="#bfae54";b.style.padding="5px 10px";b.style.cursor="pointer";b.style.borderRadius="5px";b.style.flexGrow="1";b.style.marginRight="5px";b.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";b.style.fontFamily="Arial, sans-serif";b.style.transition="background-color 0.2s"}function uf(){localStorage.setItem("logMenuHeight",oa.style.height)}function Nh(){let b=document.querySelector(".playername_achievement.ellipsis");b&&localStorage.setItem("Username",
b.textContent.trim())}async function Oh(){var b={async Cm(){var c=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${localStorage.getItem("filterGM")}&p=1`;if(nf!==c)zh(c);else try{const q=localStorage.getItem("guildPackHour");let m=JSON.parse(localStorage.getItem("packagesPurchased")||"[]");if(m.length){var e=m[0],h=await Cf(e.quality,e.itemName);h=h.filter(n=>{n=n.querySelector(".ui-draggable");return e.itemLevel===Eb(n)&&e.itemName===Xb(n)&&e.basis===wb(n)&&e.quality===pb(n)&&e.amount===xb(n)});
if(h.length&&h[0].querySelector(".ui-draggable")){const n=h[0].querySelector(".ui-draggable");Eb(n);Xb(n);wb(n);pb(n);xb(n);var k=parseInt(n.getAttribute("data-measurement-x"),10),g=parseInt(n.getAttribute("data-measurement-y"),10),l=h[0].querySelector("input").value;let {spot:r,bag:w}=await ic(k,g);const u=await jQuery.post(S({mod:"inventory",submod:"move",from:"-"+l,fromX:1,fromY:1,to:w,toX:r.x+1,toY:r.y+1,amount:e.amount}),{a:(new Date).getTime(),sh:U("sh")}),t=JSON.parse(u).to.data.itemId;c=0;
if(2>c||u.includes("containerNumber"))if((await jQuery.post(G({mod:"guildMarket",sh:U("sh")}),{sellid:t,preis:e.price,dauer:q||3,sell_mode:0,anbieten:"Offer"})).includes("<!DOCTYPE HTML>"))C("Item "+e.itemName+" sold for "+e.price+" gold"),Q("goldCycled",0),m.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(m)),window.location.reload();else if(c++,2>c)await this.Cm();else{const A=JSON.parse(localStorage.getItem("Timers"));Y("gold",A.GuildMarket||2);window.location.reload()}}else m.shift(),
localStorage.setItem("packagesPurchased",JSON.stringify(m)),window.location.reload()}}catch(q){C("Empty first slots of the first inventory at least 2x3."),window.location.reload()}},async Bn(c,e){let h=c.shift();var k=!1;const g={GUILD_TOOLS:["2097152","1048576","8388608","4194304"],GUILD_FORGE_RESOURCES:["32768"],GUILD_WEAPONS:["2"],GUILD_SHIELD:["4"],GUILD_CHEST:["8"],GUILD_HELMET:["1"],GUILD_GLOVES:["256"],GUILD_SHOES:["512"],GUILD_RINGS:["48"],GUILD_AMULETS:["1024"],GUILD_USABLES:["4096"],GUILD_FOOD:["64"],
GUILD_UPGRADES:["4096"],GUILD_RECIPES:["8192"],GUILD_MERCENARY:["16384"],GUILD_SCROLLS:["64"],GUILD_REINFORCEMENTS:["4096"]};let l=JSON.parse(localStorage.getItem("itemsToResetGuild")||"[]");for(l=l.map(q=>!q.startsWith("GUILD_")&&g["GUILD_"+q]?"GUILD_"+q:q);h;){const q=h.type;(0===l.length||l.some(m=>g[m]?.includes(q)))&&Dh(h.price,e)&&e>=h.price&&(e-=h.price,await jQuery.post(G({mod:"guildMarket",sh:U("sh")}),{buyid:h.id,f:0,fl:0,fq:-1,p:1,buy:"Comprar"}),k=JSON.parse(localStorage.getItem("packagesPurchased")||
"[]"),k.push(h),localStorage.setItem("packagesPurchased",JSON.stringify(k)),C("Item Bought: "+h.itemName+" for "+h.price),k=!0);h=c.shift()}return k},async buy(){const c=localStorage.getItem("filterGM"),e=JSON.parse(localStorage.getItem("Timers"));let h=Number(localStorage.getItem("currentPage")||1);var k=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${h}`;if(nf!==k)zh(k);else if(!(aa.gold<=Math.floor(localStorage.getItem("KasaHoldGold")))){var g=document.querySelectorAll("#market_item_table tr"),
l=document.querySelectorAll("#market_item_table input[name=buyid]");k=[];for(let q=1;q<g.length;q++){let m=g[q].querySelectorAll("td"),n=m[0].querySelector("div"),r=Number(m[2].innerText.replace(/\./g,"")),w=m[5].querySelector("input");"cancel"===w.name||w.classList.contains("disabled")||r<Number(localStorage.getItem("minimumGoldAmount"))||r>Bh().gold-Number(localStorage.getItem("KasaHoldGold"))||k.push({id:l[q-1].value,itemLevel:Eb(n),itemName:Xb(n),basis:wb(n),type:Db(n),quality:pb(n),amount:xb(n),
sellerName:m[1].querySelector("span").innerText,price:r})}g=Bh().gold-Number(localStorage.getItem("KasaHoldGold"));if(k.length&&Ch())await this.Bn(k,g)||Y("gold",e.GuildMarket||2),window.location.reload();else try{const q=document.querySelector(".standalone").textContent.match(/(\d+)\s*\/\s*(\d+)/);h<(q?parseInt(q[2],10):1)?(localStorage.setItem("currentPage",h+1),zh(`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${h+1}`)):(localStorage.setItem("currentPage",1),Y("gold",e.GuildMarket||2),window.location.reload())}catch(q){C("No items to buy in guild market today. :/"),
localStorage.setItem("currentPage",1),Y("gold",e.GuildMarket||2),window.location.reload()}}}};0<JSON.parse(localStorage.getItem("packagesPurchased")||"[]").length?await b.Cm():aa.gold>Number(localStorage.getItem("minimumGoldAmount"))+Number(localStorage.getItem("KasaHoldGold"))?await b.buy():(b=JSON.parse(localStorage.getItem("Timers")),Y("gold",b.GuildMarket||2),window.location.reload())}function Ph(){var b=document.getElementById("submenuhead1"),c=document.getElementById("submenu1"),e=document.getElementById("submenuhead2"),
h=document.getElementById("submenu2"),k=document.getElementById("main");k&&(k.style.height="950px",k.style.minHeight="950px");b&&(b.style.display="block");c&&(c.style.display="block");e&&(e.style.display="none");h&&(h.style.display="none")}function Mc(){var b=localStorage.getItem("premiumDicesLeft");b=parseInt(b,10);return isNaN(b)?0:b}function Qh(){var b=document.querySelector(".contentboard_footer_long .contentboard_inner");if(b){b.style.position="relative";b.style.overflowX="visible";b.style.overflowY=
"visible";b.style.height="auto";b.style.minHeight="450px !important";var c=document.createElement("div");c.id="customContainer";c.style.cssText="border: 2px solid #BA9700; padding: 10px; margin-top: 20px;  border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5); text-align: center; width: 100%; box-sizing: border-box; min-height: 400px;";b.appendChild(c);b=document.createElement("button");b.textContent="Start";b.className="button1";b.style.marginTop="10px";c.appendChild(b);var e=document.createElement("button");
e.textContent="Stop";e.className="button1";e.style.marginTop="10px";c.appendChild(e);var h=document.createElement("div");h.id="dicesLeft";var k=Mc();h.textContent=`Dices left: ${k}`;h.style.fontWeight="bold";h.style.marginTop="10px";c.appendChild(h);h=document.createElement("div");h.textContent='GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.';h.style.marginTop="5px";c.appendChild(h);h=document.createElement("div");
h.id="results";h.style.cssText="display: flex; flex-wrap: wrap; justify-content: center; gap: 5px; margin-top: 10px; overflow-x: hidden; overflow-y: auto; max-height: 400px;";c.appendChild(h);var g=document.createElement("div");g.id="progressIndicator";g.textContent="Ready to start.";g.style.marginTop="10px";c.appendChild(g);b.addEventListener("click",async function(){g.textContent="Processing...";await Rh()});e.addEventListener("click",function(){g.textContent="Process stopped by user. Completed!";
window.location.reload()});Sh()}}function Sh(){let b;var c=document.querySelector(".mysterybox_count");c=c?parseInt(c.textContent,10):0;localStorage.setItem("chestsLeft",c);var e=document.getElementById("mysterybox_luck");if(e)for(var h of e.childNodes)if(h.nodeType!==Node.TEXT_NODE&&h.nodeType===Node.ELEMENT_NODE)if("IMG"===h.tagName&&h.currentSrc.includes("4197f09a37be7d221c34f3e0d957e7.png"))break;else"INPUT"===h.tagName&&"button"===h.type&&(e=h.getAttribute("onclick").match(/tokenAmount=(\d+)/))&&
e[1]&&(b=parseInt(e[1],10));h=document.getElementById("dicesLeft");e=Mc();h.textContent=0>b?"Dices left: Cannot determine. Please refresh the page.":`Dices left: ${e}`;localStorage.setItem("chestsLeft",c);localStorage.setItem("premiumDicesLeft",b)}async function Rh(){0>=parseInt(localStorage.getItem("premiumDicesLeft"),10)?alert("No dices left!"):await Nc()}async function Nc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");
if(!b||0>=b&&0>=c)e.textContent="All actions completed: No dices or chests left.";else if(!b||0>=b)e.textContent="No dices left. Trying to open remaining chests...",await dc();else if(!c||0>=c)e.textContent="No chests left!";else{e.textContent="Refreshing mystery box...";var h=(new URL(window.location.href)).searchParams.get("sh")||"",k=document.querySelectorAll(".mysterybox_reward_item_pool"),g="Vulcano;Junos;Bergzorns;Weitsicht;Eole;Junon;Armure;Masque;Vulcain;Neptuno;Eolo;Armatura;Sguardo;Olhos;Alento;Nettuno;Respiro;Soffio;mortal de;Aliento;Armadura;Vista;Zbroja;Orli;Neptuna;Feronii;Wulkana;Wrath;Eagle;Pluto;Neptune;Vulcanus;Junosa;Plutosa;Ajolos;Vulcano;Feronia;Feronias;Plutos;Neptun;Aeolus;Pluton;Juno;Ejderha;Kartal;nefesi".split(";"),
l=!1;for(let q of k){const m=q.getAttribute("data-tooltip");if(g.some(n=>m.includes(n))){l=!0;break}}if(l)await dc();else try{const q=await jQuery.get(G({mod:"mysterybox",submod:"refresh",Jp:b,sh:h}));b--;localStorage.setItem("premiumDicesLeft",b);const m=document.getElementById("dicesLeft"),n=Mc();m.textContent=`Dices left: ${n}`;const r=(new DOMParser).parseFromString(q,"text/html").querySelectorAll(".mysterybox_reward_item_pool");h="Vulcano Feronia Neptun Aeolus Pluton Juno Ejderha Kartal nefesi".split(" ");
k=!1;for(let w of r){const u=w.getAttribute("data-tooltip");if(u&&h.some(t=>u.includes(t))){k=!0;break}}k?await dc():0<b?setTimeout(Nc,1E3):0<c?await dc():(e.textContent="Completed all possible actions.",C("No more actions possible: No premium dices or chests left."))}catch(q){C("Error refreshing mystery box. Please try again.")}}}async function dc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");
if(!c||0>=c)e.textContent="No chests left to open!";else{e.textContent="Opening chest...";var h=(new URL(window.location.href)).searchParams.get("sh")||"",k=(new Date).getTime();try{const g=await jQuery.get(S({mod:"mysterybox",submod:"pick",sh:h,a:k}));b--;c--;localStorage.setItem("premiumDicesLeft",b);localStorage.setItem("chestsLeft",c);(new DOMParser).parseFromString(g,"text/html");const l=document.querySelector(`.mysterybox_reward_item_pool img[alt="${g}"]`);if(l){const q=document.createElement("div");
q.className="result-item";q.style.border="1px solid #ccc";q.style.borderRadius="5px";q.style.padding="2px";q.style.margin="1px";q.style.textAlign="center";q.style.backgroundColor="#fff";q.style.boxShadow="0 0 5px rgba(0, 0, 0, 0.1)";q.style.boxSizing="border-box";q.style.flex="1 0 20%";const m=document.createElement("img");m.src=l.src;m.alt="Item Image";m.className="result-image";m.style.maxWidth="50px";m.style.display="block";m.style.margin="0 auto";const n=document.createElement("span"),r=l.closest(".mysterybox_reward_item_pool").getAttribute("data-tooltip").match(/"([^"]+)"/);
n.textContent=r?r[1]:"Unknown Item";n.style.display="block";n.style.marginTop="5px";n.style.fontSize="12px";q.appendChild(m);q.appendChild(n);document.querySelector("#results").appendChild(q)}0<b||0<c?(e.textContent="Chest opened. Checking for more actions...",setTimeout(Nc,1E3)):e.textContent="All dices and chests used up."}catch(g){C("Error opening chest. Please try again.")}}}function Wa(){Oc.length=0;document.querySelectorAll(".rule-row").forEach(b=>{const c=b.querySelector(".rule-condition-select").value;
var e=b.querySelector(".rule-prefix-input"),h=b.querySelector(".rule-suffix-input");e=e?e.value:"";h=h?h.value:"";const k=b.querySelector(".rule-level").value,g=Array.from(b.querySelectorAll(".item-icon.selected")).map(m=>m.dataset.type),l=Array.from(b.querySelectorAll(".color-circle.selected")).map(m=>m.dataset.color),q=b.querySelector(".rule-hammer-selection img.selected");b=b.querySelector(".rule-checkbox");Oc.push({condition:c,prefix:e,suffix:h,colors:l,itemTypes:g,hammerState:q?q.dataset.hammer:
"none",level:k,isEnabled:b?b.checked:!0})});localStorage.setItem("smeltingSettings",JSON.stringify(Oc))}function Th(){document.querySelectorAll(".item-icon").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function Uh(){document.querySelectorAll(".color-circle").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function Vh(){document.querySelectorAll(".rule-row .rule-hammer-selection img").forEach(b=>{b.addEventListener("click",
function(){const c=this.closest(".rule-hammer-selection").querySelectorAll("img");this.classList.contains("selected")?this.classList.remove("selected"):(c.forEach(e=>e.classList.remove("selected")),this.classList.add("selected"));Wa()})})}function Wh(){document.querySelectorAll(".rule-condition-select").forEach(b=>{b.addEventListener("change",function(){const c=this.closest(".rule-row").querySelector(".rule-prefix-input"),e=this.closest(".rule-row").querySelector(".rule-suffix-input");"nameContains"===
this.value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");Wa()})})}function Xh(){document.querySelectorAll(".rule-prefix-input, .rule-level").forEach(b=>{b.addEventListener("input",Wa)});document.querySelectorAll(".rule-suffix-input, .rule-level").forEach(b=>{b.addEventListener("input",Wa)})}function Yh(){document.querySelectorAll(".rule-row .remove-rule-btn").forEach(b=>{b.addEventListener("click",function(){b.closest(".rule-row").remove();Wa()})})}
function vf(){const b=document.querySelector(".rule-row-template").cloneNode(!0);b.classList.remove("rule-row-template");b.classList.add("rule-row");b.style.display="block";b.querySelector(".rule-prefix-input").value="";b.querySelector(".rule-suffix-input").value="";b.querySelector(".rule-level").value="";b.querySelector(".rule-checkbox").checked=!0;b.querySelectorAll(".selected").forEach(h=>h.classList.remove("selected"));const c=b.querySelector(".rule-prefix-input"),e=b.querySelector(".rule-suffix-input");
"nameContains"===b.querySelector(".rule-condition-select").value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");document.querySelector(".rule-container").insertBefore(b,document.querySelector(".add-rule-btn"));wf();Wa()}function Zh(){document.querySelectorAll(".rule-checkbox").forEach(b=>{b.addEventListener("change",Wa)});document.querySelectorAll(".rule-checkbox-wrapper").forEach(b=>{b.addEventListener("click",function(){const c=this.querySelector(".rule-checkbox");
c.checked=!c.checked;Wa()})})}function wf(){Wh();Th();Uh();Vh();Yh();Xh();Zh()}function $h(b){const c="white green blue purple orange red".split(" ");return b.sort((e,h)=>c.indexOf(e)-c.indexOf(h))}function ai(){const b=document.querySelector(".rule-row-template");var c=JSON.parse(localStorage.getItem("smeltingSettings"))||[];document.querySelectorAll(".rule-row").forEach(e=>{e.remove()});if(0===c.length){c=b.cloneNode(!0);c.classList.remove("rule-row-template");c.classList.add("rule-row");c.style.display=
"block";const e=c.querySelector(".rule-suffix-input");c.querySelector(".rule-prefix-input").style.display="block";e.style.display="block";document.querySelector(".rule-container").insertBefore(c,document.querySelector(".add-rule-btn"))}else c.forEach(e=>{const h=b.cloneNode(!0);h.classList.remove("rule-row-template");h.classList.add("rule-row");h.style.display="block";h.querySelector(".rule-condition-select").value=e.condition;var k=h.querySelector(".rule-prefix-input");const g=h.querySelector(".rule-suffix-input");
"nameContains"===e.condition?(k.style.display="block",k.value=e.prefix,g.style.display="block",g.value="undefined"===typeof e.suffix?null:e.suffix):(k.style.display="none",g.style.display="none");h.querySelector(".rule-level").value=e.level;e.itemTypes.forEach(l=>{(l=h.querySelector(`.item-icon[data-type="${l}"]`))&&l.classList.add("selected")});e.colors.forEach(l=>{(l=h.querySelector(`.color-circle[data-color="${l}"]`))&&l.classList.add("selected")});"none"!==e.hammerState&&(k=h.querySelector(`.rule-hammer-selection img[data-hammer="${e.hammerState}"]`))&&
k.classList.add("selected");h.querySelector(".rule-checkbox").checked=!1!==e.isEnabled;document.querySelector(".rule-container").insertBefore(h,document.querySelector(".add-rule-btn"))});wf()}function Pc(){Fa.colors=$h(Fa.colors);localStorage.setItem("smeltRandomlySettings",JSON.stringify(Fa))}function bi(){document.querySelectorAll(".item-icon2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.type;this.classList.contains("selected")?(this.classList.remove("selected"),Fa.itemTypes=
Fa.itemTypes.filter(e=>e!==c)):(this.classList.add("selected"),Fa.itemTypes.push(c));Pc()})});document.querySelectorAll(".rule-color-selection2 .color-circle2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),Fa.colors=Fa.colors.filter(e=>e!==c)):(this.classList.add("selected"),Fa.colors.push(c));Pc()})});document.querySelectorAll(".rule-color-resetColors .color-circle3").forEach(b=>{b.addEventListener("click",
function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),ec.colors=ec.colors.filter(e=>e!==c)):(this.classList.add("selected"),ec.colors.push(c));localStorage.setItem("resetColors",JSON.stringify(ec))})});document.querySelectorAll(".rule-hammer-selection2 img").forEach(b=>{b.addEventListener("click",function(){this.classList.contains("selected")?(this.classList.remove("selected"),Fa.hammerState="none"):(document.querySelectorAll(".rule-hammer-selection2 img").forEach(c=>
c.classList.remove("selected")),this.classList.add("selected"),Fa.hammerState=this.dataset.hammer);Pc()})})}function ci(){const b=JSON.parse(localStorage.getItem("resetColors"))||{};b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-resetColors .color-circle3[data-color="${c}"]`))&&c.classList.add("selected")})}function di(){var b=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{};b.itemTypes&&b.itemTypes.forEach(c=>{(c=document.querySelector(`.item-icon2[data-type="${c}"]`))&&
c.classList.add("selected")});b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-selection2 .color-circle2[data-color="${c}"]`))&&c.classList.add("selected")});b.hammerState&&"none"!==b.hammerState&&(b=document.querySelector(`.rule-hammer-selection2 img[data-hammer="${b.hammerState}"]`))&&b.classList.add("selected")}async function Qc(b){function c(t){let A=t.target.name;t=Number(t.target.value);let z=JSON.parse(localStorage.getItem("gods"));z||={ho:3,Jn:3,co:3,fo:3,zn:3,xo:3};z[A]=
t;localStorage.setItem("gods",JSON.stringify(z))}function e(){document.getElementById("items-repaired").textContent=ja.um;document.getElementById("items-reset").textContent=ja.vm;document.getElementById("gold-cycled").textContent=ja.sm;document.getElementById("arena-attacks").textContent=ja.hm;document.getElementById("circus-attacks").textContent=ja.km;document.getElementById("dungeons-attacked").textContent=ja.nm;document.getElementById("expeditions-attacked").textContent=ja.pm;document.getElementById("items-smelted").textContent=
ja.wm;document.getElementById("underworld-attacks").textContent=ja.Em;document.getElementById("arena-money").textContent=Math.floor(1E3*ja.Ul).toLocaleString();document.getElementById("circus-money").textContent=Math.floor(1E3*ja.Vl).toLocaleString()}function h(){var t=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||[],A=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];g("IgnoredprefixList",t,"IgnoredPrefixes");g("IgnoredsuffixList",A,"IgnoredSuffixes");t=JSON.parse(localStorage.getItem("auctionPrefixes"))||
[];A=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];g("AuctionprefixList",t,"auctionPrefixes");g("AuctionsuffixList",A,"auctionSuffixes");var z=JSON.parse(localStorage.getItem("smeltedItems"))||[];A=document.getElementById("smeltedList");let y=JSON.parse(localStorage.getItem("bidList"))||[];for(t=document.getElementById("bidList");A.firstChild;)A.firstChild.remove();for(var x of z)z=document.createElement("li"),z.textContent=x,A.appendChild(z);for(;t.firstChild;)t.firstChild.remove();for(let v of y)x=
document.createElement("li"),x.textContent=v,t.appendChild(x)}function k(t,A,z){""!==A.trim()&&(t=JSON.parse(localStorage.getItem(z))||[],t.push(A),localStorage.setItem(z,JSON.stringify(t)),h())}function g(t,A,z){let y=document.getElementById(t);y.innerHTML="";A.forEach((x,v)=>{let D=document.createElement("li");D.textContent=x;D.draggable=!0;D.setAttribute("data-index",v);v=document.createElement("button");v.textContent="X";v.style.marginLeft="10px";v.addEventListener("click",function(){let E=A.indexOf(x);
-1<E&&(A.splice(E,1),localStorage.setItem(z,JSON.stringify(A)),g(t,A,z))});D.appendChild(v);y.appendChild(D)});l(y,A,z)}function l(t,A,z){let y=-1;t.addEventListener("dragstart",x=>{y=parseInt(x.target.getAttribute("data-index"),10)});t.addEventListener("dragover",x=>{x.preventDefault()});t.addEventListener("drop",x=>{x.preventDefault();x=parseInt(x.target.closest("li").getAttribute("data-index"),10);0<=x&&0<=y&&([A[y],A[x]]=[A[x],A[y]],localStorage.setItem(z,JSON.stringify(A)),g(t.id,A,z));h()})}
function q(){setInterval(()=>{if(W("randomPause")){const t=localStorage.getItem("selectedPauseDuration");m(t)}},6E4)}function m(t){let A,z;switch(t){case "1":z=8;A={mod:"work",submod:"start",sh:U("sh"),Wl:1,dm:z,Zl:2};break;case "2":z=6;A={mod:"work",submod:"start",sh:U("sh"),Wl:1,dm:z,Zl:3};break;case "3":z=3;A={mod:"work",submod:"start",sh:U("sh"),Wl:1,dm:z,Zl:4};break;case "4":z=10;A={mod:"work",submod:"start",sh:U("sh"),Wl:1,dm:z,Zl:5};break;case "5":z=4,A={mod:"work",submod:"start",sh:U("sh"),
Wl:1,dm:z,Zl:6}}$.post(S({}),A).done(()=>{setTimeout(()=>{location.reload()},6E4*(z+1));Y("randomPause",Math.floor(1440*Math.random())+600)}).fail(()=>{})}const n=b.dataset.target;document.querySelectorAll(".popup-tab").forEach(t=>{t.classList.remove("active")});b.classList.add("active");document.querySelectorAll(".popup-box").forEach(t=>{t.classList.remove("active")});document.getElementById(n).classList.add("active");document.querySelectorAll("input[type=radio]").forEach(t=>{t.addEventListener("change",
c);let A=JSON.parse(localStorage.getItem("gods"));A&&void 0!==A[t.name]&&(t.checked=t.value==A[t.name])});document.getElementById("reset-stats-button").addEventListener("click",()=>{ja.um=0;ja.vm=0;ja.sm=0;ja.hm=0;ja.km=0;ja.nm=0;ja.pm=0;ja.wm=0;ja.Em=0;ja.Ul=0;ja.Vl=0;localStorage.setItem("userStats",JSON.stringify(ja));e()});e();b=document.querySelector(".add-rule-btn");b.removeEventListener("click",vf);b.addEventListener("click",vf);ai();ci();di();document.getElementById("smeltLootbox").checked=
"true"===localStorage.getItem("smeltLootbox");document.getElementById("smeltLootbox").addEventListener("change",function(){localStorage.setItem("smeltLootbox",this.checked)});document.getElementById("smelteverything3").checked="true"===localStorage.getItem("smelteverything3");document.getElementById("smelteverything3").addEventListener("change",function(){localStorage.setItem("smelteverything3",this.checked)});document.getElementById("smeltAnything").checked="true"===localStorage.getItem("smeltAnything");
document.getElementById("smeltAnything").addEventListener("change",function(){localStorage.setItem("smeltAnything",this.checked)});document.getElementById("RepairBeforeSmelt").checked="true"===localStorage.getItem("RepairBeforeSmelt");document.getElementById("RepairBeforeSmelt").addEventListener("change",function(){localStorage.setItem("RepairBeforeSmelt",this.checked)});const r=document.getElementById("expeditionSearchTypeX");if(b=localStorage.getItem("nestSearchType"))r.value=b;r.addEventListener("change",
()=>{localStorage.setItem("nestSearchType",r.value)});document.getElementById("IgnoredaddPrefixButton").onclick=function(){let t=document.getElementById("newIgnoredPrefixInput").value;k("IgnoredprefixList",t,"IgnoredPrefixes")};document.getElementById("IgnoredaddSuffixButton").onclick=function(){let t=document.getElementById("newIgnoredSuffixInput").value;k("IgnoredsuffixList",t,"IgnoredSuffixes")};document.getElementById("clearSmeltedItemsHistory").addEventListener("click",function(){localStorage.setItem("smeltedItems",
JSON.stringify([]));h()});h();document.getElementById("clearBidItemsHistory").addEventListener("click",function(){localStorage.setItem("bidList",JSON.stringify([]));h()});document.getElementById("AuctionaddPrefixButton").onclick=function(){let t=document.getElementById("AuctionnewPrefixInput").value;k("AuctionprefixList",t,"auctionPrefixes")};document.getElementById("AuctionaddSuffixButton").onclick=function(){let t=document.getElementById("AuctionnewSuffixInput").value;k("AuctionsuffixList",t,"auctionSuffixes")};
document.getElementById("pauseDuration").addEventListener("change",t=>{t=t.target.value;localStorage.setItem("selectedPauseDuration",t);localStorage.setItem("randomPause.timeOut",0);"0"!==t&&(Y("randomPause",Math.floor(1440*Math.random())),q())});document.getElementById("exportBtn").addEventListener("click",function(t){t.preventDefault();if(!t.target.getAttribute("data-clicked")){t.target.setAttribute("data-clicked","true");t={};var A="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");
for(var z in localStorage)A.includes(z)||(t[z]=localStorage.getItem(z));z=JSON.stringify(t);z=URL.createObjectURL(new Blob([z],{type:"application/json"}));t=document.createElement("a");t.href=z;t.download="GladBotSettings.json";t.click()}},{once:!0});b=document.getElementById("importFileBtn");const w=document.getElementById("importBtn"),u=document.getElementById("importStatus");b&&w&&u&&(b.addEventListener("click",function(){w.click()}),w.addEventListener("change",function(t){if(t=t.target.files[0]){var A=
new FileReader;A.onload=function(z){try{const y=JSON.parse(z.target.result);z="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");for(let x in y)z.includes(x)||localStorage.setItem(x,y[x]);u.textContent="Import successful! Please refresh the page."}catch(y){u.textContent="Import failed. Please check the input file and try again."}};
A.readAsText(t)}}));b=document.createElement("div");b.id="loadingSpinner";b.innerHTML='\n                <div class="spinner"></div>\n                <div class="loading-text">0</div>\n              ';document.querySelector("#selectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(t=>{t.checked=!0;t.dispatchEvent(new Event("change"))})});document.querySelector("#unselectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(t=>
{t.checked=!1;t.dispatchEvent(new Event("change"))})})}function ei(){const b=document.getElementById("expeditionLocation"),c=document.getElementById("dungeonLocation");var e=document.querySelectorAll("#submenu2 a");const h=[];for(let k=1;k<e.length;k++)e[k].classList.contains("glow")||h.push(e[k]);h.forEach(k=>{const g=document.createElement("option");g.innerText=k.innerText;g.value=(new URLSearchParams(k.href)).get("loc");b.appendChild(g);c.appendChild(g.cloneNode(!0))});if(e=localStorage.getItem("expeditionLocation"))b.value=
e;if(e=localStorage.getItem("dungeonLocation"))c.value=e}function rb(b,c,e){const h=document.createElement("li"),k="object"===typeof b?b.playerName:b;h.textContent=k;b=document.createElement("button");b.textContent="X";b.style.marginLeft="10px";b.addEventListener("click",()=>{h.remove();var g=JSON.parse(localStorage.getItem(e))||[];g=e.includes("ServerList")?g.filter(l=>"object"===typeof l&&l.playerName!==k):g.filter(l=>l!==k);localStorage.setItem(e,JSON.stringify(g))});h.appendChild(b);(c=document.getElementById(c))&&
c.appendChild(h)}function fc(b,c,e){rb(b,c,e);c=JSON.parse(localStorage.getItem(e))||[];e.includes("ServerList")?c.push({playerName:b}):c.push(b);localStorage.setItem(e,JSON.stringify(c))}function fi(){const b=JSON.parse(localStorage.getItem("autoAttackList"))||[],c=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],e=JSON.parse(localStorage.getItem("avoidAttackList"))||[],h=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[],k=JSON.parse(localStorage.getItem("autoAttackCircusList"))||
[],g=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[];b.forEach(l=>rb(l,"autoAttackList","autoAttackList"));c.forEach(l=>rb(l,"autoAttackServerList","autoAttackServerList"));e.forEach(l=>rb(l,"avoidAttackList","avoidAttackList"));h.forEach(l=>rb(l,"avoidAttackCircusList","avoidAttackCircusList"));k.forEach(l=>rb(l,"autoAttackCircusList","autoAttackCircusList"));g.forEach(l=>rb(l,"autoAttackCircusServerList","autoAttackCircusServerList"))}function xf(){sessionStorage.setItem("autoGoActive",
"true");document.getElementById("autoGoButton").innerHTML='<span style="position: relative; top: -9px;">&#9724;</span>';document.getElementById("autoGoButton").removeEventListener("click",xf);document.getElementById("autoGoButton").addEventListener("click",yf);location.reload()}function yf(){sessionStorage.setItem("autoGoActive","false");window.location.reload()}function gc(){const b=document.getElementById("popup-header"),c=document.getElementById("overlayBack");b&&(localStorage.setItem("AucTab",
!0),b.remove());c&&c.remove()}function hc(){function b(v){localStorage.setItem("settings.language",v);switch(v){case "EN":d={...Eh};break;case "PL":d={...Fh};break;case "ES":d={...Gh};break;case "TR":d={...Hh};break;case "FR":d={...Ih};break;case "HG":d={...Jh};break;case "BR":d={...Kh};break;default:d={...Eh}}gc();hc()}function c(v){Ba=v;localStorage.setItem("doExpedition",v)}function e(v){Rc=v;localStorage.setItem("monsterId",v)}function h(v){Ga=v;localStorage.setItem("doDungeon",v)}function k(v){Fb=
v;localStorage.setItem("dungeonDifficulty",v);g(v)}function g(v){$(".monster-button").removeClass("active");$(`#set_dungeon_difficulty_${v}`).addClass("active")}function l(v){Ha=v;localStorage.setItem("doArena",v)}function q(v){Da=v;localStorage.setItem("doCircus",v)}function m(v){La=v;localStorage.setItem("doQuests",v)}function n(v){Ma[v]=!Ma[v];localStorage.setItem("questTypes",JSON.stringify(Ma));gc();hc()}function r(v){Ea=v;localStorage.setItem("doEventExpedition",v)}function w(v){jc=v;localStorage.setItem("eventMonsterId",
v);gc();hc()}function u(){var v=localStorage.getItem("doExpedition");null!==v&&(Ba=JSON.parse(v));1==Ba?$("#doExpedition").prop("checked",!0):$("#doExpedition").prop("checked",!1);v=localStorage.getItem("doDungeon");null!==v&&(Ga=JSON.parse(v));1==Ga?$("#doDungeon").prop("checked",!0):$("#doDungeon").prop("checked",!1);v=localStorage.getItem("doArena");null!==v&&(Ha=JSON.parse(v));1==Ha?$("#doArena").prop("checked",!0):$("#doArena").prop("checked",!1);v=localStorage.getItem("doCircus");null!==v&&
(Da=JSON.parse(v));1==Da?$("#doCircus").prop("checked",!0):$("#doCircus").prop("checked",!1);v=localStorage.getItem("doQuests");null!==v&&(La=JSON.parse(v));1==La?$("#doQuests").prop("checked",!0):$("#doQuests").prop("checked",!1);v=localStorage.getItem("AutoAuction");null!==v&&(Za=JSON.parse(v));1==Za?$("#activateAutoBid").prop("checked",!0):$("#activateAutoBid").prop("checked",!1);v=localStorage.getItem("doKasa");null!==v&&(hb=JSON.parse(v));1==hb?$("#doKasa").prop("checked",!0):$("#doKasa").prop("checked",
!1);v=localStorage.getItem("doEventExpedition");null!==v&&(Ea=JSON.parse(v));1==Ea?$("#doEventExpedition").prop("checked",!0):$("#doEventExpedition").prop("checked",!1);$("#expedition_settings").addClass(Ba?"active":"inactive");$(`#do_expedition_${Ba}`).addClass("active");$(`#set_monster_id_${Rc}`).addClass("active");$("#dungeon_settings").addClass(Ga?"active":"inactive");$(`#do_dungeon_${Ga}`).addClass("active");$(`#set_dungeon_difficulty_${Fb}`).addClass("active");$("#arena_settings").addClass(Ha?
"active":"inactive");$(`#do_arena_${Ha}`).addClass("active");$(`#set_arena_opponent_level_${Ff}`).addClass("active");$("#circus_settings").addClass(Da?"active":"inactive");$(`#do_circus_${Da}`).addClass("active");$(`#set_circus_opponent_level_${Gf}`).addClass("active");$("#quests_settings").addClass(La?"active":"inactive");$(`#do_quests_${La}`).addClass("active");for(const D in Ma)Ma[D]&&$(`#do_${D}_quests`).addClass("active");$("#auto_auction_settings").addClass(Za?"active":"inactive");$("#event_expedition_settings").addClass(Ea?
"active":"inactive");$(`#do_event_expedition_${Ea}`).addClass("active");$(`#set_event_monster_id_${jc}`).addClass("active")}var t=document.getElementById("popup-header"),A=document.getElementById("overlayBack");t&&t.remove();A&&A.remove();t=document.createElement("div");t.setAttribute("id","popup-header");A=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio";t.innerHTML=`
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

            <div id="popupSmelt" class="popup">
                <div class="smelt-instructions" style="text-align: left; padding-left: 5px;">
                    <ul style="list-style-position: inside;">
                        <li>1. ${d.Kj}</li>
                        <li>2. ${d.Lj}</li>
                        <li>3. ${d.Mj}</li>
                        <li>4. ${d.Nj}</li>

                        <br>${d.Oj}</br>
                        <br>${d.Pj}</br>
                    </ul>
                </div>
                <img src="https://raw.githubusercontent.com/fociisoftware/glbt/refs/heads/main/Smelt2.gif" alt="Smelt Info" style="width: 350px; height: auto;">
            </div>

            <div id="announcement" class="announcement">
                ${A}
            </div>

            <div class="popup-menu">
                <div class="popup-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/" target="_blank">Version 1.1.3</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/" target="_blank">Contact us</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/" target="_blank">Update</a></span>
                <div style="display: flex; justify-content: space-between; align-items: right;">    
                <div class="menu-type logo" style="width: 48px; height: 48px; margin-right: 250px;"></div>
            
              </div>

              <span id="settingsLanguage" style="margin-left: 300px; right: 17px; top: 32px;">          
                <img class="menu-type GB" id="languageGB"> 
                <img class="menu-type PL" id="languagePL"> 
                <img class="menu-type ES" id="languageES"> 
                <img class="menu-type TR" id="languageTR">
                <img class="menu-type FR" id="languageFR">
                <img class="menu-type HG" id="languageHG">
                <img class="menu-type BR" id="languageBR">
                <br>
                <a style="color: white" href="">Donate</a>
                 - 
                 <a style="color: white" href="https://gldbotserver.com/" target="_blank"> Tutorial</a>
                 -
                <span style="color: white;">GLDbot <span style="color: red;">&#10084;</span></span>
                 </span>
              
              </div><span id="settingsLanguage"></span>

              <div class="popup-content">
                <ul class="popup-tabs">
                
                <li class="popup-tab" data-target="expedition_settings">
                    <div class="headericon_big" id="icon_expeditionpoints" style="margin-left: 4px;"></div>

                    ${d.expedition}
                    <div class="toggle-switch">
                    <input type="checkbox" id="doExpedition">
                    <label class="switch" for="doExpedition"></label>
                    </div>
                </li>

                  <li class="popup-tab" data-target="dungeon_settings">
                  <div class="headericon_big" id="icon_dungeonpoints" style="margin-left: 4px;"></div>
                  ${d.dungeon}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doDungeon">
                      <label class="switch" for="doDungeon"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="arena_settings">
                  <div class="headericon_big" id="icon_arena" style="margin-left: 4px;"></div>
                  ${d.arena}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doArena">
                      <label class="switch" for="doArena"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="circus_settings">
                  <div class="headericon_big" id="icon_grouparena" style="margin-left: 4px;"></div>
                  ${d.circusTurma}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doCircus">
                      <label class="switch" for="doCircus"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="underworld_settings">
                  <div class="quest-type underworld" style="margin-left: 4px;"></div>
                  ${d.fh}
                    <div class="toggle-switch">
                      <input type="checkbox" id="autoEnterHell">
                      <label class="switch" for="autoEnterHell"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="quests_settings">
                  <div class="quest-type menu"></div>
                  ${d.pj}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doQuests">
                      <label class="switch" for="doQuests"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="heal_settings">
                  <div class="quest-type potion"></div>
                  ${d.ki}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doHeal">
                      <label class="switch" for="doHeal"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="event_expedition_settings">
                  <div class="quest-type event"></div>${d.eventExpedition}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doEventExpedition">
                      <label class="switch" for="doEventExpedition"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_auction_settings">
                  <div class="quest-type search"></div>
                  ${d.D}
                  
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateAutoBid">
                      <label class="switch" for="activateAutoBid">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_auction2_settings">
                    <div class="quest-type auction"></div>
                    ${d.xc}
                    <div class="toggle-switch ">
                      <input type="checkbox" id="activateAuction2">
                      <label class="switch" for="activateAuction2">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_smelt_settings">
                  <div class="quest-type smelt"></div>${d.og}
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateSmelt">
                      <label class="switch" for="activateSmelt">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_repair_settings">
                  <div class="quest-type repair"></div>
                  ${d.Nb}
                  <div class="toggle-switch">
                    <input type="checkbox" id="activateRepair">
                    <label class="switch" for="activateRepair">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="Market">
                  <div class="quest-type market"></div>
                  ${d.Se}
                  <div class="toggle-switch">
                  <div class="toggle-bg"></div>
                  </div>
                  </li>

                  <li class="popup-tab" data-target="guild_settings">
                    <div class="quest-type guild"></div>
                    ${d.gi}
                    <div class="toggle-bg"></div>
                  </li>
                  
                 
                  <li class="popup-tab" data-target="Timers">
                    <div class="quest-type timer"></div>
                    ${d.Xb} 
                    <div class="toggle-switch">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="other_settings2">
                  <div class="quest-type reset">
                  </div>${d.Wf}
                  </li>
                  

                  <li class="popup-tab" data-target="other_settings">
                  <div class="quest-type settings"></div>
                  ${d.wf}
                  <div class="toggle-bg"></div>
                  </li>

                  


                  <li class="popup-tab" data-target="Extra">
                  <div class="quest-type extra">
                  </div>${d.pb}
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div> </li>

                </ul>

            <div class="popup-box" id="expedition_settings">

                <div class="settings-tab">
                    <div class="settings_tab_title">${d.Ih}</div>
                    <div class="setting-row">
                        <label for="expeditionLocation">${d.Cd}</label>
                        <select id="expeditionLocation"></select>
                    </div>

                    <div class="setting-row">
                        <label for="autoCollectBonuses">${d.Bc}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoCollectBonuses">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="enemySelection" class="setting-row">
                        <label for="enemySelect">${d.Bj}:</label>
                        <select id="enemySelect">
                            <option value="0">1</option>
                            <option value="1">2</option>
                            <option value="2">3</option>
                            <option value="3">Boss</option>
                        </select>
                    </div>

                    <div id="expeditionSearchType" class="setting-row">
                        <label for="expeditionSearchTypeX">${d.Ni}:</label>
                        <select id="expeditionSearchTypeX">
                            <option value="" selected disabled>Select an option</option>
                            <option value="nothing">${d.Li}</option>
                            <option value="quick">${d.Mi}</option>
                            <option value="thorough">${d.Oi}</option>
                        </select>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="postExpeditionAction">${d.nj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="postExpeditionAction">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                </div>
  
            </div>
            
                <div class="popup-box" id="dungeon_settings">
                  <div class="settings_tab_title">${d.Eh}</div>
                  <div class="settings-tab">
                    <div class="setting-row">      
                      <label for="dungeonLocation">${d.$c}</label>
                      <select id="dungeonLocation"></select>
                    </div>

                    <div class="setting-row">
                      <span class="span-new">${d.Dh}</span>
                        <div id="set_dungeon_difficulty_normal" class="monster-button">
                          ${d.Qi}
                        </div>
                        <div id="set_dungeon_difficulty_advanced" class="monster-button">
                          ${d.advanced}
                        </div>
                    </div>

                    <div class="setting-row">
                      <label for="skipBossToggle">${d.ng}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipBossToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="resetIfLoseToggle">${d.Xf}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="resetIfLoseToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonAB">${d.tc}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonAB">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonFocusQuest">${d.Kd}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonFocusQuest">
                        <span class="switch"></span>
                      </label>
                    </div>
                    <span class="span-new">${d.Lf}</span>  

                  
                    </div>
                      <div class="tutorial-container">
                        <span class="span-new">${d.Fh}</span>  
                      </div>
                    </div>

                  <!-- ARENA -->
  
                  <div class="popup-box" id="arena_settings">
                  <div class="settings_tab_title">Arena</div>
                  <span class="span-new">${d.Xa}</span>

                  
                  <div class="settings_tab_title2">
                    <button id="tabA" class="tab-button active">Arena Local Server</button>
                    <button id="tabB" class="tab-button">Arena Other Servers</button>
                  </div>

                  <!-- Tab A Content -->
                  <div id="contentA" class="setting-row">
                    <div class="avoid-attack">
                      <div class="top-section">
                      <h3>${d.na}</h3>
                        <div class="switch-field2">
                          <input type="text" id="autoAttackInput" placeholder="${d.ma}">
                          <button id="addAutoAttack" class="awesome-button">${d.la}</button>
                          <button id="ClearAttackList" class="awesome-button">Clear List</button>
                        </div>
                      </div>
                      <ul id="autoAttackList" class="scrollable-list"></ul>
                    </div>
                  </div>

                  <!-- Tab B Content -->
                  <div id="contentB" class="setting-row" style="display: none;">
                    <div class="avoid-attack">
                      <div class="top-section">
                        <h3>${d.na}</h3>
                        </div>
                        <button id="ClearOtherAttackList" class="awesome-button">Clear List</button>
                        <ul id="autoAttackServerList" class="scrollable-list"></ul>
                      </div>
                  </div>

                  <div class="setting-row">
                    <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.ac}</h3>
                            <div class="switch-field2">
                                <input type="text" id="avoidAttackInput" placeholder="${d.ma}">
                                <button id="addAvoidAttack" class="awesome-button">${d.la}</button>
                                <button id="ClearAvoidList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="avoidAttackList" class="scrollable-list"></ul>
                        ${d.bc}
                    </div>
                  </div>

                  <div class="setting-row" data-tooltip="${d.oj}">
                    <label for="enableArenaSimulator">Enable Simulator Attack [Premium]</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="enableArenaSimulator">
                        <span class="switch"></span>
                    </label>    
                  </div>


                 <div class="setting-row">
                      <label for="ArenaSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                      <div class="switch-field3">
                        <input type="number" id="ArenaSimulatorAmount" min="1" max="100" value="${localStorage.getItem("ArenaSimulatorAmount")||60}">
                      </div>
                </div>

                  <div class="setting-row">
                    <label for="arenaAttackGM">${d.Ta}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="arenaAttackGM">
                      <span class="switch"></span>
                    </label>    
                  </div>

                    <div class="setting-row" data-tooltip="${d.$b}">
                    <label for="onlyArena">${d.Cf}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="onlyArena">
                        <span class="switch"></span>
                    </label>    
                    </div>

                <div class="setting-row">
                    <label for="attackRandomly">${d.th}</label>
                    
                    <label class="toggle-switch">
                    <input type="checkbox" id="attackRandomly">
                    <span class="switch"></span>
                    </label>    
                    <h3>${d.uh}</h3>
                </div>

                  <div class="setting-row">
                    <div class="switch-field3">
                    <input type="number" id="autoAddArenaAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddArenaAmount")||0}">
                    </div>
                      <label for="autoAddArena">${d.Ra}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="autoAddArena">
                        <span class="switch"></span>
                      </label>
                  </div>
  
                  <div class="setting-row">
                    <label for="autoAvoidArena">${d.Sa}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="autoAvoidArena">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="scoreboard-attack">
                    <div class="settings_tab_title">${d.Rb}</div>
                    <div class="setting-row">
                    <label for="scoreboardattackenable">${d.ob}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="scoreboardattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="scoreRange">${d.Pb}</label>
                    <select id="scoreRange" class="input">
                      <option value="1">1-50</option>
                      <option value="2">51-100</option>
                      <option value="3">101-150</option>
                      <option value="4">151-200</option>
                      <option value="5">201-250</option>
                      <option value="6">251-300</option>
                      <option value="7">301-350</option>
                      <option value="8">351-400</option>
                      <option value="9">401-450</option>
                      <option value="10">451-500</option>
                      <option value="11">501-550</option>
                      <option value="12">551-600</option>
                      <option value="13">601-650</option>
                      <option value="14">651-700</option>
                      <option value="15">701-750</option>
                      <option value="16">751-800</option>
                      <option value="17">801-850</option>
                      <option value="18">851-900</option>
                      <option value="19">901-950</option>
                      <option value="20">951-1000</option>
                      <!-- Add more options as needed -->
                    </select>
                  </div>
                  </div>
                  <span class="span-new">${d.Qb}</span>
                  
                  <div class="settings_tab_title">${d.qb}</div>

                  <div class="setting-row">
                  <label for="leagueattackenable">${d.nb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leagueattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguerandom">${d.Lb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguerandom">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguelowtohigh">${d.Mb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguelowtohigh">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <span class="span-new">${d.rb}</span>

                </div>

  
                  <!-- Circus -->

                  <div class="popup-box" id="circus_settings">
                    <div class="settings_tab_title">Circus</div>
                    <span class="span-new">${d.Xa}</span>

                    <div class="settings_tab_title2">
                        <button id="tabACircus" class="tab-button active">Circus Local Server</button>
                        <button id="tabBCircus" class="tab-button">Circus Other Servers</button>
                    </div>

                    <!-- Tab A Content -->
                    <div id="contentACircus" class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.na}</h3>
                            <div class="switch-field2">
                            <input type="text" id="autoAttackCircusInput" placeholder="${d.ma}">
                            <button id="addAutoCircusAttack" class="awesome-button">${d.la}</button>
                            <button id="ClearCircusAttackList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="autoAttackCircusList" class="scrollable-list"></ul>
                        </div>
                    </div>

                    <!-- Tab B Content -->
                    <div id="contentBCircus" class="setting-row" style="display: none;">
                        <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.na}</h3>
                            </div>
                            <button id="ClearOtherCircusAttackList" class="awesome-button">Clear List</button>
                            <ul id="autoAttackCircusServerList" class="scrollable-list"></ul>
                        </div>
                    </div>

                        <div class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.ac}</h3>
                        <div class="switch-field2">
                            <input type="text" id="avoidAttackCircusInput" placeholder="${d.ma}">
                            <button class="awesome-button" id="addAvoidCircusAttack">${d.la}</button>
                            <button class="awesome-button" id="ClearCircusAvoidList">Clear List</button>
                        </div>
                        </div>
                            <ul id="avoidAttackCircusList" class="scrollable-list"></ul>
                            ${d.bc}
                        </div>
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusWithoutHeal">${d.zh}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusWithoutHeal">
                                <span class="switch"></span>
                            </label>    
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusSimulator">Enable Simulator Attack [Premium]</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusSimulator">
                                <span class="switch"></span>
                            </label>    
                        </div>

                    <div class="setting-row">
                    <label for="CircusSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                    <div class="switch-field3">
                        <input type="number" id="CircusSimulatorAmount" min="1" max="100" value="${localStorage.getItem("CircusSimulatorAmount")||60}">
                    </div>
                </div>

                        <div class="setting-row">
                        <label for="circusAttackGM">${d.Ta}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="circusAttackGM">
                            <span class="switch"></span>
                        </label>    
                        </div>

                        <div class="setting-row" data-tooltip="${d.$b}">
                        <label for="onlyCircus">${d.Df}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="onlyCircus">
                        <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row">
                    <label for="attackRandomlyCircus">Attack Randomly in Provinciarum?</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="attackRandomlyCircus">
                        <span class="switch"></span>
                    </label>    
                    <h3>Also disable "Sort players in arena by level" setting in crazy-addon.</h3>
                    </div>

                        <div class="setting-row">
                        <div class="switch-field3">
                        <input type="number" id="autoAddCircusAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddCircusAmount")||0}">
                        </div>
                            <label for="autoAddCircus">${d.Ra}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="autoAddCircus">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="autoAvoidCircus">${d.Sa}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoAvoidCircus">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="scoreboard-attack">
                        <div class="settings_tab_title">${d.Rb}</div>
                        <div class="setting-row">
                        <label for="scoreboardcircusenable">${d.ob}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="scoreboardcircusenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="scoreRangeCircus">${d.Pb}</label>
                            <select id="scoreRangeCircus" class="input">
                            <option value="1">1-50</option>
                            <option value="2">51-100</option>
                            <option value="3">101-150</option>
                            <option value="4">151-200</option>
                            <option value="5">201-250</option>
                            <option value="6">251-300</option>
                            <option value="7">301-350</option>
                            <option value="8">351-400</option>
                            <option value="9">401-450</option>
                            <option value="10">451-500</option>
                            <option value="11">501-550</option>
                            <option value="12">551-600</option>
                            <option value="13">601-650</option>
                            <option value="14">651-700</option>
                            <option value="15">701-750</option>
                            <option value="16">751-800</option>
                            <option value="17">801-850</option>
                            <option value="18">851-900</option>
                            <option value="19">901-950</option>
                            <option value="20">951-1000</option>
                            <!-- Add more options as needed -->
                            </select>
                        </div>
                        </div>
                        <span class="span-new"> ${d.Qb} </span>
                        
                        <div class="settings_tab_title">${d.qb}</div>

                        <div class="setting-row">
                        <label for="leaguecircusattackenable">${d.nb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusattackenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="leaguecircusrandom">${d.Lb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusrandom">
                            <span class="switch"></span>
                        </label>
                        </div>
    
                        <div class="setting-row">
                        <label for="leaguecircuslowtohigh">${d.Mb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircuslowtohigh">
                            <span class="switch"></span>
                        </label>
                        </div>
                        <span class="span-new">${d.rb}</span>

                  </div>

                  <div class="popup-box" id="underworld_settings">

                    <div class="settings_tab_title">${d.Qd}</div>
                        <span class="span-new"> ${d.Rd}</span>
                        <div class="setting-row">
                            <label for="hellDifficulty">${d.Od}</label>
                            <select id="hellDifficulty">
                                <option value="0">${d.Ch}</option>
                                <option value="1">${d.Bh}</option>
                                <option value="2">${d.Ah}</option>
                            </select>
                        </div>

                    <div class="setting-row">
                        <label for="hellEnterHP">${d.fd}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellEnterHP" min="1" max="100" value="${localStorage.getItem("hellEnterHP")||75}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="HellHealHP">${d.Ak}</label>
                        <div class="switch-field3">
                            <input type="number" id="HellHealHP" min="1" max="100" value="${localStorage.getItem("HellHealHP")||10}">
                        </div>
                    </div>
                    
                    <div class="setting-row" data-tooltip="${d.ni}">
                        <label for="autoEnterHell">${d.Ec} Info</label>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Wc}">
                        <label for="dontEnterUnderworld">${d.Xc}</label>
                        <label class="toggle-switch">
                        
                            <input type="checkbox" id="dontEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="EnableArenaHell">${d.ad}</label>
                        <label class="toggle-switch">
                    
                        <input type="checkbox" id="EnableArenaHell">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderworldUseMobi">${d.lh}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderworldUseMobi">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderWorldUseRuby">${d.ph}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderWorldUseRuby">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="useSacrifice">${d.nh}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useSacrifice">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="usePray">${d.lk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="usePray">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="useClothToEnterUnderworld">${d.hk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useClothToEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="exitUnderworld">${d.hd}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="exitUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="settings_tab_title">${d.Xg}</div>

                    <div class="setting-row">
                        <label for="useGodPowers">${d.Zg}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useGodPowers">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Multi-Selection for Gods -->
                    <div class="setting-row" id="godPowersSection" style="display: none;">
                        <label>${d.$g}</label>
                        <div class="god-selection">
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Minerva" id="godMinerva">
                                <img src="//gf3.geo.gfsrv.net/cdn8a/72919cc6b457bf475fb81cc7de8863.png" title="Minerva">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Diana" id="godDiana">
                                <img src="//gf2.geo.gfsrv.net/cdn70/026bb622a42b4d00abc74c67f28d63.png" title="Diana">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Vulcan" id="godVulcan">
                                <img src="//gf3.geo.gfsrv.net/cdn5c/6fbd05e43d699e65fc40cc92a17c51.png" title="Vulcan">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mars" id="godMars">
                                <img src="//gf2.geo.gfsrv.net/cdn76/5fd915f85b3e5e71b64632af0c6543.png" title="Mars">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Apollo" id="godApollo">
                                <img src="//gf3.geo.gfsrv.net/cdn8f/bb75bf0df76de3ec421bbfb0eac3c5.png" title="Apollo">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mercury" id="godMercury">
                                <img src="//gf3.geo.gfsrv.net/cdnbe/5e272e2aade20b4a266e48663421ce.png" title="Mercury">
                            </label>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="weaponBuff">${d.ah}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="weaponBuff">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Armor Buff Section -->
                    <div class="setting-row">
                        <label>${d.bh}</label>
                        <div class="armor-selection">
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Armor" id="armorBuffArmor"> ${d.M}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Helmet" id="armorBuffHelmet"> ${d.P}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Gloves" id="armorBuffGloves"> ${d.O}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Boots" id="armorBuffBoots"> ${d.N}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Shield" id="armorBuffShield"> ${d.S}
                            </label>
                        </div>
                    </div>

                    <!-- Farm Section (As Is) -->
                    <div class="settings_tab_title">${d.Hd}</div>
                    <span class="span-new">${d.Id}: </span>
                    <div class="setting-row">
                        <label for="farmEnable">${d.v}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="farmEnable">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="farmLocation">${d.Gd}</label>
                        <select id="farmLocation">
                            <option value="0">Entrance</option>
                            <option value="1">Court of the Dead</option>
                            <option value="2">Tartarus</option>
                            <option value="3">Erebus</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="farmEnemy">${d.Fd}:</label>
                        <select id="farmEnemy">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">Boss</option>
                        </select>
                    </div>

                    <div class="setting-row" data-tooltip="${d.mi}">
                          <label for="useVillaMedici">${d.bd}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="EnableHellLimit">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="hellLimit">${d.li}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellLimit" min="1" max="200" value="${localStorage.getItem("hellLimit")||5}">
                        </div>
                    </div>

                    <div class="settings_tab_title">${d.Pd}</div>
                    <div class="setting-row">
                          <label for="useVillaMedici">${d.oh}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useVillaMedici">
                              <span class="switch"></span>
                          </label>
                    </div>
                    
                    <div class="setting-row">
                        <label for="useHealingPotion">${d.mh}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useHealingPotion">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <span class="span-new"> ${d.Yg}</span>
                    <span class="span-new">${d.gh}</span>

                    <div class="settings_tab_title">${d.Cc}</div>
                    <span class="span-new">Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.</span>
                    <div class="setting-row">
                          <label for="useCostume">${d.kh}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useCostume">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="wearUnderworld">${d.qh}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="wearUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    
                    <div id="costumeUnderworldWrapper" style="display:none;">
                      <div class="setting-row">
                          <label for="costumeUnderworld">${d.Pc}</label>
                          <select id="costumeUnderworld">
                              <option value="9">Dis Pater Normal</option>
                              <option value="10">Dis Pater Medium</option>
                              <option value="11">Dis Pater Hard</option>
                          </select>
                      </div>
                    </div>                

                    <div class="setting-row">
                      <label for="costumeBasic">${d.Hc}</label>
                      <select id="costumeBasic">
                          <option value="1">${d.Za}</option>
                          <option value="2">${d.cb}</option>
                          <option value="3">${d.eb}</option>
                          <option value="4">${d.fb}</option>
                          <option value="5">${d.gb}</option>
                          <option value="6">${d.hb}</option>
                          <option value="7">${d.ib}</option>
                          <option value="8">${d.jb}</option>
                          <option value="12">${d.kb}</option>
                          <option value="13">${d.$a}</option>
                          <option value="14">${d.ab}</option>
                          <option value="15">${d.bb}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <label for="costumeDungeon">${d.Zc}</label>
                      <select id="costumeDungeon">
                          <option value="1">${d.Za}</option>
                          <option value="2">${d.cb}</option>
                          <option value="3">${d.eb}</option>
                          <option value="4">${d.fb}</option>
                          <option value="5">${d.gb}</option>
                          <option value="6">${d.hb}</option>
                          <option value="7">${d.ib}</option>
                          <option value="8">${d.jb}</option>
                          <option value="12">${d.kb}</option>
                          <option value="13">${d.$a}</option>
                          <option value="14">${d.ab}</option>
                          <option value="15">${d.bb}</option>
                      </select>
                    </div>
                    <span class="span-new">${d.Dc}</span>

                </div>
                  
                  <div class="popup-box" id="quests_settings">

                    <div class="settings_tab_title">Quests</div>

                    <div class="setting-row">
                      <div class="monster-buttons">
                        <span class="span-new">${d.type}</span>
                        <div class="quest-container">
                          <div id="do_combat_quests" class="settingsButton quest-type combat"></div>
                          <div id="do_arena_quests" class="settingsButton quest-type arena"></div>
                          <div id="do_circus_quests" class="settingsButton quest-type circus"></div>
                          <div id="do_expedition_quests" class="settingsButton quest-type expedition"></div>
                          <div id="do_dungeon_quests" class="settingsButton quest-type dungeon"></div>
                          <div id="do_items_quests" class="settingsButton quest-type items"></div>
                        </div>
                      </div>
                    </div>

                    <div class="settings_tab_title">Quest Settings</div>

                    <div class="setting-row">
                      <label for="skipTimeQuests">Arena ${d.Ha}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipTimeQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeCircusQuests">Circus ${d.Ha}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeCircusQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeOtherQuests">Other ${d.Ha}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeOtherQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                      <label for="UnderworldQuests">${d.eh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="UnderworldQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row" id="underworldKeywordSection" style="display: none;">
                    ${d.dh}
                    <div class="input-container">
                        <input type="text" id="underworldKeywordInput" placeholder="${d.aa}">
                        <button class="awesome-button" id="addUnderworldKeywordBtn">${d.I}</button>
                    </div>
                    <div id="underworldKeywordList"></div>
                </div>

                    <div class="setting-row">
                    <label for="acceptnotfilter">${d.Ff}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="acceptnotfilter">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="settings_tab_title">${d.Mf}</div>
                      <div class="setting-row">
                        ${d.Ef}
                        <select id="questSpeed">
                        <option value="0">5x</option>
                        <option value="1">4x</option>
                        <option value="2">3x</option>
                        <option value="3">2x</option>
                        <option value="4">1x</option>
                      </select>
                    </div>
                    <div class="settings_tab_title">${d.Jf}</div>

                    <div class="setting-row">
                      ${d.If}
                      <div class="input-container">
                      <input type="text" id="keywordInput" placeholder="${d.aa}">
                      <button class="awesome-button" id="addKeywordBtn">${d.I}</button>
                      </div>
                      <div id="keywordList"></div>
                    </div>
                    
                    <div class="settings_tab_title">${d.Gf}</div>

                    <div class="setting-row">
                        ${d.Hf}
                        <div class="input-container">
                            <input type="text" id="keywordAcceptInput" placeholder="${d.aa}">
                            <button class="awesome-button" id="addKeywordAcceptBtn">${d.I}</button>
                        </div>
                        <div id="keywordAcceptList"></div>
                    </div>      

                    <div class="setting-row">
                        <label for="questrewardvalue">${d.Yf}</label>
                        <div class="switch-field3">
                            <input type="number" id="questrewardvalue" min="1" max="99999" value="${localStorage.getItem("questrewardvalue")||2E3}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label>${d.Kf}</label>
                        <div class="input-container">
                            <label><input type="checkbox" id="questTypeMercury"> Mercury</label>
                            <label><input type="checkbox" id="questTypeApollo"> Apollo</label>
                            <label><input type="checkbox" id="questTypeDiana"> Diana</label>
                            <label><input type="checkbox" id="questTypeMinerva"> Minerva</label>
                            <label><input type="checkbox" id="questTypeVulcan"> Vulcan</label>
                            <label><input type="checkbox" id="questTypeMars"> Mars</label>
                        </div>
                    </div>

                    
                    </div>


                <div class="popup-box" id="heal_settings">
                  <div class="monster-buttons">
                  </div>
                  <div class="settings_tab_title">${d.ji}</div>

                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; margin-right: 50px;">
                  </div>

                  <div class="setting-row">
                  <label for="healPercentage">${d.ii}</label>
                  <div class="switch-field3">
                    <input type="number" id="healPercentage" min="1" max="99" value="${localStorage.getItem("healPercentage")||75}">
                  </div>
                </div>

                  <div class="setting-row">
                  <img style="margin-top: -10px" src="https://gf3.geo.gfsrv.net/cdneb/91e0372cccc24f52758be611a10a3b.png">
                  <label for="HealClothToggle">${d.ag}</label>
                  
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealClothToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="HealRubyToggle">${d.Ll}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealRubyToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healShopToggle">${d.jk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healShopToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healfrompackage">${d.kk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healfrompackage">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="HealPickBag">${d.Nd}</label>
                     <select id="HealPickBag" class="input">
                     <option value="1">
                        1
                      </option>
                      <option value="2">
                        2
                      </option>
                      <option value="3">
                        3
                      </option>
                      <option value="4">
                        4
                      </option>
                      <option value="5">
                        5
                      </option>
                      <option value="6">
                        6
                      </option>
                      <option value="7">
                        7
                      </option>
                      <option value="8">
                      8
                    </option>
                    </select>
                  </div>
                  
                  <div class="setting-row">
                  <label for="FoodAmount">${d.hi}</label>
                   <select id="FoodAmount" class="input">
                   <option value="1">
                      1
                    </option>
                    <option value="2">
                      2
                    </option>
                    <option value="3">
                      3
                    </option>
                    <option value="4">
                      4
                    </option>
                    <option value="5">
                      5
                    </option>
                    <option value="6">
                      6
                    </option>
                    <option value="7">
                      7
                    </option>
                    <option value="8">
                    8
                  </option>
                  </select>
                </div>   
                  
                <div class="setting-row" data-tooltip="${d.yh}">
                <label for="healcervisia">${d.gk}</label>
                <label class="toggle-switch">
                    <input type="checkbox" id="healcervisia">
                    <span class="switch"></span>
                </label>
                </div>

                  <div class="setting-row">
                  <label for="HealEggs">${d.ik}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealEggs">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="settings_tab_title">${d.Sd}</div>
                  <span class="span-new">${d.tf}</span>
                  <div class="setting-row" data-tooltip="${d.Ri}>
                  <label for="OilEnable">${d.ed}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="OilEnable">
                      <span class="switch"></span>
                    </label>
                  </div>



                  <div class="setting-row">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-right: 50px;">
                    <table style="width: 100%">
                        <tbody>
                        <tr>
                            <td style="font-weight: bold; text-align: left; width: 30%">Minerva:</td>
                            <td style="text-align: right;">
                                <div class="radio-group">
                                <input type="radio" name="minerva" value="0"><span class="span-new">I</span>
                                <input type="radio" name="minerva" value="1"><span class="span-new">II</span>
                                <input type="radio" name="minerva" value="2"><span class="span-new">III</span>
                                <input type="radio" name="minerva" value="3" checked="true"><span class="span-new">Off</span>
                                </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Diana:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="diana" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="diana" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="diana" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="diana" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Mars:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="mars" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="mars" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="mars" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="mars" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Merkur:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="merkur" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="merkur" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="merkur" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="merkur" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Apollo:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="apollo" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="apollo" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="apollo" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="apollo" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Vulcanus:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="vulcanus" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="vulcanus" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="vulcanus" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="vulcanus" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                            </table>
                        </div>


                    </div>
<div class="settings_tab_title">${d.Wa}</div>
<span class="span-new">Bot will use buffs when available.</span>

<div class="setting-row" data-tooltip="${d.wh}>
    <label for="BuffsEnable">Enable ${d.Wa}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffsEnable">
        <span class="switch"></span>
    </label>
</div>

<div class="setting-row">
    <label for="BuffUnderworldOnly">${d.Mc}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffUnderworldOnly">
        <span class="switch"></span>
    </label>
</div>


<div class="setting-row">
    <div class="buff-group">
        <label>Health:</label>
        <input type="checkbox" id="HealthBuff1"> Gingko
        <input type="checkbox" id="HealthBuff2"> Taigaroot
        <input type="checkbox" id="HealthBuff3"> Hawthorn
    </div>

    <div class="buff-group">
        <label>Strength:</label>
        <input type="checkbox" id="StrengthBuff1"> Flask
        <input type="checkbox" id="StrengthBuff2"> Ampulla
        <input type="checkbox" id="StrengthBuff3"> Flacon
        <input type="checkbox" id="StrengthBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Dexterity:</label>
        <input type="checkbox" id="DexterityBuff1"> Flask
        <input type="checkbox" id="DexterityBuff2"> Ampulla
        <input type="checkbox" id="DexterityBuff3"> Flacon
        <input type="checkbox" id="DexterityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Agility:</label>
        <input type="checkbox" id="AgilityBuff1"> Flask
        <input type="checkbox" id="AgilityBuff2"> Ampulla
        <input type="checkbox" id="AgilityBuff3"> Flacon
        <input type="checkbox" id="AgilityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Constitution:</label>
        <input type="checkbox" id="ConstitutionBuff1"> Flask
        <input type="checkbox" id="ConstitutionBuff2"> Ampulla
        <input type="checkbox" id="ConstitutionBuff3"> Flacon
        <input type="checkbox" id="ConstitutionBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Charisma:</label>
        <input type="checkbox" id="CharismaBuff1"> Flask
        <input type="checkbox" id="CharismaBuff2"> Ampulla
        <input type="checkbox" id="CharismaBuff3"> Flacon
        <input type="checkbox" id="CharismaBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Intelligence:</label>
        <input type="checkbox" id="IntelligenceBuff1"> Flask
        <input type="checkbox" id="IntelligenceBuff2"> Ampulla
        <input type="checkbox" id="IntelligenceBuff3"> Flacon
        <input type="checkbox" id="IntelligenceBuff4"> Bottle
    </div>
</div>
                  </div>

                  <div class="popup-box" id="event_expedition_settings">
                    <div class="settings_tab_title">${d.eventExpedition}</div>

                    <div class="setting-row">
                        <div id="set_event_monster_id_0" class="monster-button">1</div>
                        <div id="set_event_monster_id_1" class="monster-button">2</div>
                        <div id="set_event_monster_id_2" class="monster-button">3</div>
                        <div id="set_event_monster_id_3" class="monster-button">Boss</div>
                    </div>
                    <div id="clear_next_event_expedition_time" class="awesome-button">${d.Of}</div> <!-- New Button -->

                      <div class="setting-row">
                      <label for="renewEvent">${d.Rf}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="renewEvent">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <label for="throwDice">${d.ug}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="throwDice">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <span class="span-new">${d.vg}<span class="span-new">
                      
                                          </div>
                      <div class="setting-row">
                    <span class="span-new">${d.gd}<span class="span-new">
                    
                                        </div>
                    </div>

                  <div class="popup-box" id="auto_auction_settings">
                

                    <div class="settings_tab_title">${d.zc}</div>
                    <span class="span-new">To open search panels including Unique shop items, enable this option.<span class="span-new">
                    <div class="setting-row">
                    <label for="AuctionItemLevel2">${d.kf}</label>
                      <div class="switch-field2">
                        <input type="text" id="search_input" placeholder="${d.oc}">
                      </div>
                    </div>

                    <div class="setting-row">
                      <label for="AuctionItemLevel2">${d.ea}</label>
                      <div class="switch-field3">
                        <input type="number" id="AuctionItemLevel2" min="1" max="1000" value="5">
                      </div>
                    </div>   

                    <div class="setting-row">
                      <label for="SearchQuality">${d.Ga}</label>
                      <select id="SearchQuality" class="input">
                          <option value="-1">
                          ${d.Ja}
                          </option>
                            <option value="0">
                            ${d.B}
                            </option>
                            <option value="1">
                            ${d.A}
                            </option>
                            <option value="2">
                            ${d.C}
                            </option>
                          </option>
                      </select>
                    </div> 

                    <div class="setting-row">
                      <label>${d.ra}</label>
                      <div class="equipment-search-selection">
                          <label><input type="checkbox" class="equipment-search-option" value="2"> ${d.ka}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="4"> ${d.ha}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="8"> ${d.Z}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1"> ${d.ca}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="256"> ${d.ba}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="512"> ${d.ia}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="48"> ${d.fa}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1024"> ${d.Y}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="9999"> ${d.T}</label>
                      </div>
                    </div>

                    <button class="awesome-button" id="search_button" type="button">${d.oc}</button>
                    <button class="awesome-button" id="search_reset" type="button">${d.sc}</button>
       
                    <div class="setting-row">
                    <ul id="search_list"></ul>
                    <span class="span-new">${d.uc}</span>
                    </div>

                    <div class="settings_tab_title">${d.dg}</div>
                    <div class="setting-row">

                      <!-- Title & Instructions -->
                      <div style="margin-bottom: 20px;">
                          <h2>${d.fg}</h2>
                          <p>${d.eg}</p>
                      </div>
                    </div>
                    <!-- Item Input Section -->

                        <div class="setting-row">
                          <label for="clothCount">${d.gg}</label>
                          <div class="switch-field2">
                              <input type="number" id="clothCount" placeholder="${d.hg}">
                          </div>
                        </div>

                        <hr class="section-separator">

                        <div class="setting-row">
                              <label for="newItem">${d.ja}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItem" placeholder="${d.ja}">
                          </div>
                        </div>

                        <div class="setting-row">
                          <label for="newItemLevel">Min ${d.Tb}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItemLevel" placeholder="Min ${d.Tb}">
                          </div>
                        </div>
                
                        <div class="setting-row">
                          <label for="itemQuality">Min ${d.jg}:</label>
                          <select id="itemQuality">
                              <option value="0">${d.B}</option>
                              <option value="1">${d.A}</option>
                              <option value="2">${d.C}</option>
                              <option value="3">${d.G}</option>
                              <option value="4">${d.R}</option>
                          </select>
                        </div>

                        <!-- New Stat Selection with Combo Box -->
                        <div class="setting-row">
                        <label for="shopitemstat">Stat:</label>
                        <select id="shopitemstat">
                            <option value="none">NONE</option>
                            <option value="str">Strength</option>
                            <option value="dex">Dexterity</option>
                            <option value="agi">Agility</option>
                            <option value="cot">Constitution</option>
                            <option value="chr">Charisma</option>
                            <option value="int">Intelligence</option>
                        </select>
                        </div>

                        <div class="setting-row" id="statValueRow" style="display: none;">
                        <label for="statValue">Value:</label>
                        <div class="switch-field2">
                            <input type="number" id="statValue" placeholder="0">
                        </div>
                        </div>
                        

                        <div style="text-align: right;">
                        <button class="awesome-button" id="addItemButton">${d.I}</button>
                      </div>

                      <div class="setting-row">
                        <div id="itemsList" style="margin-bottom: 10px;">
                        <!-- Example item -->
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="flex: 1;">${d.ig}</span>
                            <button onclick="removeItem('uniqueItemID')">X</button>
                        </div>
                        <!-- Add more items similarly -->
                        </div>
                      </div>  
                  
                      <!-- Search Buttons -->
                      <div style="display: flex; justify-content: space-between; gap: 10px; margin-bottom: 20px;">
                        <button class="awesome-button" id="startSearchButton">${d.kg}</button>
                        <button class="awesome-button" id="skipSearchButton" style="display: none;">${d.lg}</button>
                        <button class="awesome-button" id="stopSearchButton">${d.mg}</button>
                      </div>
                      <div class="setting-row">
                      <!-- Progress Bar -->
                      <div style="margin-bottom: 20px;">
                          <label>${d.cg}:</label>
                          <div id="progressBarOuter" style="width: 100%; height: 20px; background-color: grey; border-radius: 10px;">
                              <div id="progressBarInner" style="height: 100%; width: 0%; background-color: green; border-radius: 10px;"></div>
                          </div>
                      </div>
                  
                      <!-- Found Items Container -->
                      <div id="foundItemsContainer"></div>
                    </div>
                </div>
                
                    


                  
                
                

                  <div class="popup-box" id="auto_auction2_settings">


                <div class="settings_tab_title">${d.tg}</div>
                
                <div class="setting-row" data-tooltip="${d.yc}">
                <label for="storeGoldinAuction">${d.v}</label>
                  <label class="toggle-switch">
                  <input type="checkbox" id="storeGoldinAuction">
                  <span class="switch"></span>
                  </label>
                  </div>

                <div class="setting-row">
                  <label for="itemsToReset2">${d.ga}</label>
                  <div id="itemsToReset2" class="items-reset-list">
                      <div class="item-reset"><input type="checkbox" id="WEAPONS2" value="WEAPONS2"><label for="WEAPONS">${d.W}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHIELD2" value="SHIELD2"><label for="SHIELD">${d.S}</label></div>
                      <div class="item-reset"><input type="checkbox" id="CHEST2" value="CHEST2"><label for="CHEST">${d.M}</label></div>
                      <div class="item-reset"><input type="checkbox" id="HELMET2" value="HELMET2"><label for="HELMET">${d.P}</label></div>
                      <div class="item-reset"><input type="checkbox" id="GLOVES2" value="GLOVES2"><label for="GLOVES">${d.O}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHOES2" value="SHOES2"><label for="SHOES">${d.N}</label></div>
                      <div class="item-reset"><input type="checkbox" id="RINGS2" value="RINGS2"><label for="RINGS">${d.V}</label></div>
                      <div class="item-reset"><input type="checkbox" id="AMULETS2" value="AMULETS2"><label for="AMULETS">${d.U}</label></div>
                  </div>
                </div>

                <div class="setting-row">
                    <label for="storeInShopQuality">${d.Ga}</label>
                    <select id="storeInShopQuality" class="input">
                    <option value="0">
                    ${d.B}
                    </option><!-- Add more options as needed -->
                        <option value="1">
                        ${d.A}
                        </option>
                        <option value="2">
                        ${d.C}
                        </option>
                  </select>
                

                </div>

                <div class="setting-row">
                <label for="storeGoldinAuctionmaxGold">${d.Ze}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionmaxGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionmaxGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
                <label for="storeGoldinAuctionholdGold">${d.da}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionholdGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionholdGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
              <label for="AuctionGoldCover">${d.lb}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="AuctionGoldCover">
                <span class="switch"></span>
              </label>
            </div>

                <span class="span-new">${d.Zf}</span>
                  
                    <div class="settings_tab_title">${d.qf}</div>
                    <span class="span-new">${d.Ac}</span>
                    
                    <div class="setting-row">
                      <div class="table-container">
                          <table class="styled-table">
                            <thead>
                              <tr>
                                <th>Prefix</th>
                                <th>Suffix</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="AuctionprefixList"></ul>
                                </td>
                                <td>
                                  <ul class="styled-list" id="AuctionsuffixList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                 
                                    <input type="text" class="styled-input" id="AuctionnewPrefixInput">
                                    <input type="button" id="AuctionaddPrefixButton" value="${d.Pa}">
                                  </div>
                                </td>
                                <td>
                                  <div class="list-options">
                                    <input type="text" class="styled-input" id="AuctionnewSuffixInput">
                                    <input type="button" id="AuctionaddSuffixButton" value="${d.Qa}">
                                  </div>
                                </td>

                              </tr>
                            </tbody>
                          </table>
                          
                      </div>
                      
                    </div>
                  
                    <div class="setting-row">
                        <label>${d.ra}</label>
                        <div class="equipment-selection">
                            <label><input type="checkbox" class="equipment-option" value="2"> ${d.ka}</label>
                            <label><input type="checkbox" class="equipment-option" value="4"> ${d.ha}</label>
                            <label><input type="checkbox" class="equipment-option" value="8"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option" value="1"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option" value="256"> ${d.ba}</label>
                            <label><input type="checkbox" class="equipment-option" value="512"> ${d.ia}</label>
                            <label><input type="checkbox" class="equipment-option" value="48"> ${d.fa}</label>
                            <label><input type="checkbox" class="equipment-option" value="1024"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option" value="9999"> ${d.T}</label>
                        </div>
                    </div>

                      <div class="setting-row" data-tooltip="${d.fk}">
                        <label for="auctionTURBO">Turbo Mode Speed >> </label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionTURBO">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctiongladiatorenable">${d.$f}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctiongladiatorenable">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctionmercenaryenable">${d.bg}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionmercenaryenable">
                          <span class="switch"></span>
                         </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.wc}>
                        <label for="ignorePS">${d.Vd}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="ignorePS">
                            <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Ua}>
                        <label for="bidFood">${d.Ic}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="bidFood">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.vc}>
                      <label for="AuctionCover">${d.lb}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="AuctionCover">
                        <span class="switch"></span>
                      </label>
                    </div>

                      <div class="setting-row" data-tooltip="${d.Ua}>
                        <label for="bidfood">${d.$e}</label>
                        <div class="switch-field3">
                          <input type="number" id="maximumBid" min="1" max="1000000" value="25">
                        </div>
                      </div>

                      <div class="setting-row">
                        <label for="aunctionMinQuality">${d.Ga}</label>
                         <select id="auctionMinQuality" class="input">
                          <option value="2">
                          ${d.C}
                          </option>
                          <option value="1">
                          ${d.A}
                          </option>
                          <option value="0">
                          ${d.B}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                    <div class="setting-row">
                      <label for="auctionminlevel">${d.ea}</label>
                      <div class="switch-field3">
                        <input type="number" id="auctionminlevel" min="1" max="1000" value="0">
                      </div>
                    </div>

                      <div class="setting-row">
                        <label for="bidStatus">${d.Jc}</label>
                         <select id="bidStatus" class="input">
                          <option value="4">
                          ${d.Zb}
                          </option>
                          <option value="3">
                          ${d.Vb}
                          </option>
                          <option value="2">
                          ${d.Jb}
                          </option>
                          <option value="1">
                          ${d.Bb}
                          </option>
                          <option value="0">
                          ${d.Yb}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                      <div class="setting-row">
                        <label for="enableMercenarySearch">${d.Hh}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="enableMercenarySearch">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="mercenarySearchOptions" style="display:none">
                        <div class="setting-row">
                        
                            <label for="minDexterity">Min: ${d.Dexterity}</label>
                            <div class="switch-field3">
                                <input type="number" id="minDexterity" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minAgility">Min: ${d.Agility}</label>
                            <div class="switch-field3">
                                <input type="number" id="minAgility" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minIntelligence">Min: ${d.Intelligence}</label>
                            <div class="switch-field3">
                                <input type="number" id="minIntelligence" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <span class="span-new">Enter 0 to ignore stats.</span>
                    </div>
                      
                      <div class="setting-row">
                        <h4>${d.Kc}</h4>
                        <div class="table-container">
                          <table class="styled-table">
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="bidList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                    <input type="button" class="awesome-button" id="clearBidItemsHistory" value="${d.Ya}">
                                  </div>
                                  
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                  </div>

                <div class="popup-box" id="auto_smelt_settings">
                    <div class="settings_tab_title" style="position: relative;">
                        Auto Smelt
                        <i class="fas fa-info-circle" id="autoSmeltInfo" style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 22px; color: black;"></i>

                    
                    </div>


                    <div class="rule-container">
                    <!-- Rule Row Template -->
                    <div class="rule-row-template" style="display: none;">
                        <!-- Top row (Condition, Prefix, Scroll, Level) -->
                        <div class="rule-top-row">
     
                            <label class="rule-checkbox-wrapper">
        
                                <input type="checkbox" class="rule-checkbox">
                                <span class="checkbox-icon"></span>
                                
                            </label>

                            &nbsp

                            <!-- Condition Combo Box -->
                            <select class="rule-condition-select">
                                <option value="nameContains">${d.pf}</option>
                                <option value="isUnderworldItem">${d.isUnderworldItem}</option>
                            </select>

                            <!-- Text input appears only for 'Name contains' -->
                            <input type="text" class="rule-prefix-input" placeholder="${d.Kb}" />
                            <input type="text" class="rule-suffix-input" placeholder="${d.Wb}" />

                            <!-- Scroll Combo Box 
                            <select class="rule-scroll-select">
                                <option value="noScroll">No scroll</option>
                                <option value="anyScroll">Has any scroll</option>
                            </select>
                            -->

                            <input type="number" class="rule-level" placeholder="lvl>">
                        </div>

                        <!-- Second row (Item Types, Colors, Hammer) -->
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection">
                                <span class="color-circle white" data-color="white"></span>
                                <span class="color-circle green" data-color="green"></span>
                                <span class="color-circle blue" data-color="blue"></span>
                                <span class="color-circle purple" data-color="purple"></span>
                                 <span class="color-circle orange" data-color="orange"></span>
                                <span class="color-circle red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

                            <button class="remove-rule-btn">X</button>
                        </div>
                    </div>

                    <!-- Add Rule Button -->
                    <button class="add-rule-btn">${d.rf}</button>
                    <hr style="border: 1px solid #c4ac70; margin: 10px 0;">
                </div>



                    <!-- Condition Selection  
                    <div class="setting-row">
                        <label for="smeltCondition">Condition:</label>
                        <select id="smeltCondition" class="styled-select" style="width:200px">
                            <option value="name_contains">Name contains</option>
                            <option value="name_word">Name contains word</option>
                            <option value="color">Item color is</option>
                            <option value="underworld_prefix_suffix">Item has underworld prefix/suffix</option>
                        </select>
                    </div>
                    
                    <div class="setting-row" id="filterNameRow">
                        <label for="filterNameInput">Filter Profile Name:</label>
                        <input type="text" id="filterNameInput" class="styled-input3" placeholder="Enter profile name" />
                    </div>

                    <div class="setting-row" id="itemNameRow" style="display: none;">
                        <label for="itemNameInput">Item Name:</label>
                        <input type="text" id="itemNameInput" class="styled-input" placeholder="Enter item name" />
                    </div>
                    
                    <div class="setting-row" id="colorRow" style="display: none;">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                

                    <div class="setting-row">
                        <h4>Added Filters</h4>
                        <div id="filtersList" class="filter-list"></div>
                    </div>


                    <div class="setting-row">
                        <h4>Saved Items</h4>
                        <div id="savedItemsList" class="filter-list"></div>
                    </div>

                    

                    <div class="setting-row">
                        <label>${d.ra}</label>
                        <div class="equipment-selection-smelt">
                            <label><input type="checkbox" class="equipment-option-smelt" value="2"> ${d.ka}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="4"> ${d.ha}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="8"> ${d.Z}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="256"> ${d.ba}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="512"> ${d.ia}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="48"> ${d.fa}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1024"> ${d.Y}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="9999"> ${d.T}</label>
                        </div>
                    </div>
                  

                    <div class="setting-row" id="colorRowOriginal">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                    

                    <div class="setting-row">
                        <label for="smeltUnderworld">Smelt only Underworld/Hell items?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="smeltUnderworld">
                        <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="smeltLootbox">${d.Hj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="smeltLootbox">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltIgnorePS">${d.Gj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltIgnorePS">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->

                    <div class="setting-row">
                      <label for="smeltAnything">${d.qg}</label>
                      
                      <label class="toggle-switch" data-tooltip="${d.Ij}">
                        <input type="checkbox" id="smeltAnything">
                        <span class="switch"></span>
                      </label>
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection2">
                                <span class="color-circle2 white" data-color="white"></span>
                                <span class="color-circle2 green" data-color="green"></span>
                                <span class="color-circle2 blue" data-color="blue"></span>
                                <span class="color-circle2 purple" data-color="purple"></span>
                                 <span class="color-circle2 orange" data-color="orange"></span>
                                <span class="color-circle2 red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection2">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

        
                        </div>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Jj}">
                      <label for="smelteverything3">${d.Rj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smelteverything3">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="RepairBeforeSmelt">${d.rj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="RepairBeforeSmelt">
                        <span class="switch"></span>
                      </label>
                        <div class="setting-row">
                        <label for="repairBeforeSmeltMaxQuality">${d.lc}</label>
                            <select id="repairBeforeSmeltMaxQuality" class="input">
                                    <option value="3">
                                    ${d.G}
                                    </option>
                                    <option value="2">
                                    ${d.C}
                                    </option>
                                    <option value="1">
                                    ${d.A}
                                    </option>
                                    <option value="0">
                                    ${d.B}
                                    </option>
                                    <option value="-1">
                                    ${d.Ja}
                                    </option>
                            </select>
                        </div>
                        <div class="setting-row">
                        <label for="PartialOrFull">${d.xf}</label>
                            <select id="PartialOrFull" class="input">
                                    <option value="0">
                                    ${d.yf}
                                    </option>
                                    <option value="1">
                                    ${d.Ld}
                                    </option>
                            </select>
                        </div>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltusehammers">Use Hammers?</label>
                      <span class="span-new">[Bot will look for bronze then silver.]</span>   
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltusehammers">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->
                    
                    <div class="setting-row">
                        <label for="smeltTab">${d.rg}</label>
                        <select id="smeltTab" class="input">
                        <option value="6">
                            8
                        </option>
                            <option value="5">
                                7
                            </option>
                            <option value="4">
                                6
                            </option>
                            <option value="3">
                                5
                            </option>
                            <option value="2">
                                4
                            </option>
                            <option value="1">
                                3
                            </option>
                            <option value="0">
                                2
                            </option>
                        </select>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="smeltLevel">Min Level</label>
                        <div class="switch-field3">
                            <input type="number" id="smeltLevel" min="1" max="100" value="${localStorage.getItem("smeltLevel")||1}">
                        </div>
                    </div>
                    
                    
                    
                    <span class="span-new">${d.Sj}</span>
-->
                    <div class="settings_tab_title">${d.pg}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                <thead>
                                    <tr>
                                    <th>${d.Kb}</th>
                                    <th>${d.Wb}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td>
                                        <ul class="styled-list" id="IgnoredprefixList"></ul>
                                    </td>
                                    <td>
                                        <ul class="styled-list" id="IgnoredsuffixList"></ul>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredPrefixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddPrefixButton" value="${d.Pa}">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredSuffixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddSuffixButton" value="${d.Qa}">
                                        </div>
                                    </td>
                                    </tr>
                                </tbody>
                                </table>          
                        </div>
                    </div>
                    
                    <!-- Smelted Items List -->
                  
                    <div class="settings_tab_title">${d.Qj}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                    <tbody>
                                    <tr>
                                        <td>
                                        <ul class="styled-list" id="smeltedList"></ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <div class="list-options">
                                            <input type="button" class="awesome-button" id="clearSmeltedItemsHistory" value="${d.Ya}">
                                            
                                        </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>    
                        </div>
                    </div>
                </div>

                
                <div class="popup-box" id="auto_repair_settings">
                <div class="settings_tab_title">${d.Nb}</div>
                <div class="setting-row">

                    <div class="inventory gladiator-inventory">
                        <h3>Gladiator</h3>
                        <!-- Inventory Rows for Gladiator -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weapon">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmet">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armor">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shield">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="gloves">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoes">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklace">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>

                        </div>
                    </div>

                    <div class="inventory mercenary-inventory">
                        <h3>Mercenary</h3>
                        <!-- Inventory Rows for Mercenary -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weaponM">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmetM">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armorM">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shieldM">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="glovesM">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoesM">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1M">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2M">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklaceM">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>
                        </div>
                    </div>

                    <div class="instructions" style="clear: both;">
                            <span class="span-new">${d.cc}</span><br>
                            <span class="span-new">${d.Sf}</span>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="repairGladiator">${d.Ia} Gladiator?</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="repairGladiator">
                            <span class="switch"></span>
                        </label>
                    </div>
                  
                    <div class="setting-row">
                        <label for="repairMercenary">${d.Ia} Mercenary?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="repairMercenary">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="repairPercentage">${d.lf}</label>
                        <select id="repairPercentage" class="input">
                        <option value="3">%10</option>
                        <option value="2">%20</option>
                        <option value="1">%30</option>
                        <option value="0">%40</option>
                        <option value="-1">%50</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="repairMaxQuality">${d.lc}</label>
                        <select id="repairMaxQuality" class="input">
                                <option value="3">
                                ${d.G}
                                </option>
                                <option value="2">
                                ${d.C}
                                </option>
                                <option value="1">
                                ${d.A}
                                </option>
                                <option value="0">
                                ${d.B}
                                </option>
                                <option value="-1">
                                ${d.Ja}
                                </option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="currentWorkbenchItem">${d.Rc}</label>
                        <span id="currentWorkbenchItem"></span> <!-- Item name will be displayed here -->
                    </div>

                    <div class="setting-row">
                        <div id="clear_repair" style="display:flex;" class="awesome-button">${d.mk}</div> <!-- Button to clear -->
                    </div>

                    <div class="setting-row" id="ignoreMaterialsSection" style="margin-top: 10px; border-top: 1px solid #b3a77a; padding-top: 10px; background: linear-gradient(to right, #e8e1c8, #dacfa1); border-radius: 8px;">
                        <h3 style="color: #5a5a5a; font-family: 'Arial', sans-serif; text-align: center; text-transform: uppercase; letter-spacing: 2px;">${d.Ud}</h3>
                        
                        <!-- Scrollable list of materials -->
                        <div id="ignoreMaterialsList" style="border-radius: 4px; padding: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); height: 300px; max-height: 300px; overflow-y: auto; display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                            <!-- Base Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Base Materials</h4>
                                <label><input type="checkbox" value="1"> ${d.kc}</label><br>
                                <label><input type="checkbox" value="2"> ${d.hc}</label><br>
                                <label><input type="checkbox" value="3"> ${d.ic}</label><br>
                                <label><input type="checkbox" value="4"> ${d.jc}</label><br>
                            </div>

                            <!-- Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Materials</h4>
                                <label><input type="checkbox" value="13"> ${d.xi}</label><br>
                                <label><input type="checkbox" value="14 Wool"> ${d.pi}</label><br>
                                <label><input type="checkbox" value="15"> ${d.si}</label><br>
                                <label><input type="checkbox" value="16"> ${d.ri}</label><br>
                                <label><input type="checkbox" value="17"> ${d.ui}</label><br>
                                <label><input type="checkbox" value="18"> ${d.ti}</label><br>
                                <label><input type="checkbox" value="19"> ${d.wi}</label><br>
                                <label><input type="checkbox" value="20"> ${d.vi}</label><br>
                            </div>

                            <!-- Monster Parts category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Monster Parts</h4>
                                <label><input type="checkbox" value="5"> ${d.Ei}</label><br>
                                <label><input type="checkbox" value="6"> ${d.yi}</label><br>
                                <label><input type="checkbox" value="7"> ${d.Hi}</label><br>
                                <label><input type="checkbox" value="8"> ${d.Bi}</label><br>
                                <label><input type="checkbox" value="9"> ${d.Di}</label><br>
                                <label><input type="checkbox" value="10> ${d.Ci}</label><br>
                                <label><input type="checkbox" value="11"> ${d.zi}</label><br>
                                <label><input type="checkbox" value="12"> ${d.Gi}</label><br>
                                <label><input type="checkbox" value="55"> ${d.Ai}</label><br>
                                <label><input type="checkbox" value="58"> ${d.Fi}</label><br>
                                <label><input type="checkbox" value="62"> ${d.Ii}</label><br>
                                <label><input type="checkbox" value="64"> ${d.Ji}</label><br>
                            </div>

                            <!-- Gemstones category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Gemstones</h4>
                                <label><input type="checkbox" value="21"> ${d.ai}</label><br>
                                <label><input type="checkbox" value="22"> ${d.Vh}</label><br>
                                <label><input type="checkbox" value="23"> ${d.Uh}</label><br>
                                <label><input type="checkbox" value="24"> ${d.Wh}</label><br>
                                <label><input type="checkbox" value="25"> ${d.bi}</label><br>
                                <label><input type="checkbox" value="26"> ${d.Zh}</label><br>
                                <label><input type="checkbox" value="27"> ${d.Yh}</label><br>
                                <label><input type="checkbox" value="28"> ${d.Xh}</label><br>
                                <label><input type="checkbox" value="59"> ${d.$h}</label><br>
                                <label><input type="checkbox" value="63"> ${d.ci}</label><br>
                            </div>

                            <!-- Flasks category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Flasks</h4>
                                <label><input type="checkbox" value="37"> ${d.Ph}</label><br>
                                <label><input type="checkbox" value="38"> ${d.Sh}</label><br>
                                <label><input type="checkbox" value="39"> ${d.Lh}</label><br>
                                <label><input type="checkbox" value="40"> ${d.Kh}</label><br>
                                <label><input type="checkbox" value="41"> ${d.Rh}</label><br>
                                <label><input type="checkbox" value="42"> ${d.Oh}</label><br>
                                <label><input type="checkbox" value="43"> ${d.Mh}</label><br>
                                <label><input type="checkbox" value="44"> ${d.Nh}</label><br>
                                <label><input type="checkbox" value="53"> ${d.Th}</label><br>
                                <label><input type="checkbox" value="61"> ${d.Qh}</label><br>
                            </div>

                            <!-- Runes category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Runes</h4>
                                <label><input type="checkbox" value="29"> ${d.Aj}</label><br>
                                <label><input type="checkbox" value="30"> ${d.uj}</label><br>
                                <label><input type="checkbox" value="31"> ${d.sj}</label><br>
                                <label><input type="checkbox" value="32"> ${d.zj}</label><br>
                                <label><input type="checkbox" value="33"> ${d.yj}</label><br>
                                <label><input type="checkbox" value="34"> ${d.wj}</label><br>
                                <label><input type="checkbox" value="35"> ${d.tj}</label><br>
                                <label><input type="checkbox" value="36"> ${d.xj}</label><br>
                                <label><input type="checkbox" value="60"> ${d.vj}</label><br>
                            </div>

                            <!-- Ores category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Ores</h4>
                                <label><input type="checkbox" value="45"> ${d.Ui}</label><br>
                                <label><input type="checkbox" value="46"> ${d.Ti}</label><br>
                                <label><input type="checkbox" value="47"> ${d.Yi}</label><br>
                                <label><input type="checkbox" value="48"> ${d.aj}</label><br>
                                <label><input type="checkbox" value="49"> ${d.bj}</label><br>
                                <label><input type="checkbox" value="50"> ${d.Wi}</label><br>
                                <label><input type="checkbox" value="51"> ${d.$i}</label><br>
                                <label><input type="checkbox" value="52"> ${d.Zi}</label><br>
                                <label><input type="checkbox" value="54"> ${d.Si}</label><br>
                                <label><input type="checkbox" value="56"> ${d.Vi}</label><br>
                                <label><input type="checkbox" value="57"> ${d.Xi}</label><br>
                            </div>
                        </div>

                    </div>

                </div>


                <div class="popup-box" id="guild_settings">

                    <!-- Guld stuff comes here -->

                    <div class="settings_tab_title">${d.sg}</div>

                        <span class="span-new">${d.Gh}:</span>
                        <span class="span-new">${d.de}</span>
                  
                        <div class="setting-row">
                            <label for="doKasa">${d.v}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="doKasa">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="AuctionItemLevel2">${d.mf}</label>
                            <div class="switch-field2">
                            <input type="number" id="minimumGoldAmount" placeholder="Amount" value="${localStorage.getItem("minimumGoldAmount")||0}">         
                            </div>
                        </div>

                        <div class="setting-row">
                            <label for="filterGM">${d.Jd}</label>
                            <select id="filterGM">
                            <option value="" disabled>${d.ga}</option>
                            <option value="pd">${d.nf}</option>
                            <option value="p">${d.Oc}</option>
        
                            </select>
                        </div>

                        <div class="setting-row">
                            <label for="guildPackHour">${d.Sb}</label>
                            <select id="guildPackHour">
                            <option value="" disabled>${d.Sb}</option>
                            <option value="1">2 hr</option>
                            <option value="2">8 hr</option>
                            <option value="3">24 hr</option>
                            </select>
                        </div>

                        <div class="setting-row">
                        <label for="KasaHoldGold">${d.da}</label>
                            <div class="switch-field3">
                            <input type="number" id="KasaHoldGold" placeholder="Amount" value="${localStorage.getItem("KasaHoldGold")||0}">       
                                </div>
                        </div>

                        <div class="setting-row">
                            <label for="itemsToResetGuild">${d.ga}</label>
                            <div id="itemsToResetGuild" class="items-reset-list">
                                <div class="item-reset"><input type="checkbox" id="GUILD_WEAPONS" value="GUILD_WEAPONS"><label for="GUILD_WEAPONS">${d.W}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHIELD" value="GUILD_SHIELD"><label for="GUILD_SHIELD">${d.S}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_CHEST" value="GUILD_CHEST"><label for="GUILD_CHEST">${d.M}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_HELMET" value="GUILD_HELMET"><label for="GUILD_HELMET">${d.P}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_GLOVES" value="GUILD_GLOVES"><label for="GUILD_GLOVES">${d.O}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHOES" value="GUILD_SHOES"><label for="GUILD_SHOES">${d.N}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RINGS" value="GUILD_RINGS"><label for="GUILD_RINGS">${d.V}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_AMULETS" value="GUILD_AMULETS"><label for="GUILD_AMULETS">${d.U}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FOOD" value="GUILD_FOOD"><label for="GUILD_FOOD">${d.pa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_USABLES" value="GUILD_USABLES"><label for="GUILD_USABLES">${d.Ma}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_UPGRADES" value="GUILD_UPGRADES"><label for="GUILD_UPGRADES">${d.wa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RECIPES" value="GUILD_RECIPES"><label for="GUILD_RECIPES">${d.ta}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_MERCENARY" value="GUILD_MERCENARY"><label for="GUILD_MERCENARY">${d.sa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SCROLLS" value="GUILD_SCROLLS"><label for="GUILD_SCROLLS">${d.ua}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_REINFORCEMENTS" value="GUILD_REINFORCEMENTS"><label for="GUILD_REINFORCEMENTS">${d.Oa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_TOOLS" value="GUILD_TOOLS"><label for="GUILD_TOOLS">${d.va}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FORGE_RESOURCES" value="GUILD_FORGE_RESOURCES"><label for="GUILD_FORGE_RESOURCES">${d.Na}</label></div>
                            </div>
                        </div>

                    <div class="settings_tab_title">${d.ei}</div>

                            
                            <div class="setting-row">
                                <label for="guildBattleEnable">${d.v}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleEnable">
                                    <span class="switch"></span>
                                </label>          
                            </div>

                            <div class="setting-row">
                             <label for="guildBattleRandom">${d.di}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleRandom">
                                    <span class="switch"></span>
                                </label>
                            </div>

                            <div class="setting-row">
                                ${d.fi}
                                <div class="input-container">
                                <input type="text" id="keywordGuildInput" placeholder="${d.aa}">
                                <button class="awesome-button" id="addGuildKeywordBtn">${d.I}</button>
                                </div>
                                <div id="keywordGuildList"></div>
                            </div>

                    <div class="settings_tab_title">${d.mb}</div>

                        <div class="setting-row">
                            <label for="GuildEnable">${d.v}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="GuildEnable">
                                <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        
                            <label for="GuildDonateAmount">${d.Td}</label>
                            <div class="switch-field3">
                                <input type="number" id="GuildDonateAmount" min="0" value="${localStorage.getItem("GuildDonateAmount")||0}">      
                            </div> 

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateMore">${d.Vc}</label>
                                <div class="switch-field3">
                                    <input type="number" id="GuildDonateMore" min="0" value="${localStorage.getItem("GuildDonateMore")||0}">                         
                                </div>

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateLess">${d.ee}</label>
                            <div class="switch-field3">
                            <input type="number" id="GuildDonateLess" min="0" value="${localStorage.getItem("GuildDonateLess")||0}">       
                            </div>                  
                        </div>

                        <span class="span-new">${d.Uc}</span>
                        
                    </div>

                <div class="popup-box" id="other_settings2">

                    <div class="settings_tab_title">${d.Tf}</div>


                    <div class="setting-row">
                    <span class="span-new">${d.Uf}</span>
                    <div class="instructionsReset">
                    
                    <span class="span-new">${d.Ob}</span>
                    </div>
                 
                    </div>
                    
                    <div class="setting-row">
                      <label for="resetExpiredItems">${d.v}</label>
                      <label class="toggle-switch">
                          <input type="checkbox" id="resetExpiredItems">
                          <span class="switch"></span>
                      </label>
                    </div>
                    <div class="setting-row">
                    <label for="resetColors">Select Colors</label>
                            <div class="rule-color-resetColors">
                                <span class="color-circle3 white" data-color="-1"></span>
                                <span class="color-circle3 green" data-color="0"></span>
                                <span class="color-circle3 blue" data-color="1"></span>
                                <span class="color-circle3 purple" data-color="2"></span>
                                <span class="color-circle3 orange" data-color="3"></span>
                                <span class="color-circle3 red" data-color="4"></span>
                            </div>
                    </div>


                    <div class="setting-row">
 
                        <label for="resetDays">${d.Vf}</label>
                        <select id="resetDays" style="margin-left: 5px;">
                            <option value="1">1 day</option>
                            <option value="2">2 days</option>
                            <option value="3">3 days</option>
                            <option value="4">4 days</option>
                        </select>
                    </div>
                    
                    <div class="setting-row">
                        <label for="itemsToReset">${d.Kk}</label>
                        <button id="selectAllItems" title="Select All">
                            <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                                <polyline points="20 6 9 17 4 12"></polyline> <!-- This SVG represents a check mark -->
                            </svg>
                        </button>
                        <div id="itemsToReset" class="items-reset-list">
                        
                            <div class="item-reset"><input type="checkbox" id="WEAPONS" value="WEAPONS"><label for="WEAPONS">${d.W}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHIELD" value="SHIELD"><label for="SHIELD">${d.S}</label></div>
                            <div class="item-reset"><input type="checkbox" id="CHEST" value="CHEST"><label for="CHEST">${d.M}</label></div>
                            <div class="item-reset"><input type="checkbox" id="HELMET" value="HELMET"><label for="HELMET">${d.P}</label></div>
                            <div class="item-reset"><input type="checkbox" id="GLOVES" value="GLOVES"><label for="GLOVES">${d.O}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHOES" value="SHOES"><label for="SHOES">${d.N}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RINGS" value="RINGS"><label for="RINGS">${d.V}</label></div>
                            <div class="item-reset"><input type="checkbox" id="AMULETS" value="AMULETS"><label for="AMULETS">${d.U}</label></div>
                            <div class="item-reset"><input type="checkbox" id="FOOD" value="FOOD"><label for="FOOD">${d.pa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="USABLES" value="USABLES"><label for="USABLES">${d.Ma}</label></div>
                            <div class="item-reset"><input type="checkbox" id="UPGRADES" value="UPGRADES"><label for="UPGRADES">${d.wa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RECIPES" value="RECIPES"><label for="RECIPES">${d.ta}</label></div>
                            <div class="item-reset"><input type="checkbox" id="MERCENARY" value="MERCENARY"><label for="MERCENARY">${d.sa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SCROLLS" value="SCROLLS"><label for="SCROLLS">${d.ua}</label></div>
                            <div class="item-reset"><input type="checkbox" id="REINFORCEMENTS" value="REINFORCEMENTS"><label for="REINFORCEMENTS">${d.Oa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="TOOLS" value="TOOLS"><label for="TOOLS">${d.va}</label></div>
                            
                        </div>
                    </div>
                    
                    <hr style="border: none; border-top: 1px solid black; margin: 10px 0px;">

                    <div class="setting-row">
                        <label for="pauseDuration">${d.Bf} </label>
                        <select id="pauseDuration">
                        <option value="0">No pause</option>
                        <option value="1">Stable Boy</option>
                        <option value="2">Farmer</option>
                        <option value="3">Butcher</option>
                        <option value="4">Fisherman</option>
                        <option value="5">Baker</option>
                        </select>
                    </div>
                     
              </div>

                <div class="popup-box" id="Timers">
                <div class="settings_tab_title">${d.Xb}</div>
                <span class="span-new">${d.Timers}</span>

                <div class="setting-row">
                    <div class="timer-list" style="display: grid; grid-template-columns: repeat(2, 5fr); gap: 10px;">

                    <div class="timer-item">
                        <label for="smelting-timer" style="font-weight: bold;">${d.Pg}</label>
                        <p class="description">${d.Ng}</p>
                        <input type="number" id="smelting-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Smelting||10}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-nogold" style="font-weight: bold;">${d.Og}</label>
                        <p class="description">${d.Kg}</p>
                        <input type="number" id="smelting-timer-nogold" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-noitem" style="font-weight: bold;">${d.Lg}</label>
                        <p class="description">${d.Mg}</p>
                        <input type="number" id="smelting-timer-noitem" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoItem||15}">
                    </div>

                    <div class="timer-item">
                        <label for="repair-timer" style="font-weight: bold;">${d.Ia}</label>
                        <p class="description">${d.Fg}</p>
                        <input type="number" id="repair-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Repair||10}">
                    </div>

                    <div class="timer-item">
                        <label for="guild-market-timer" style="font-weight: bold;">${d.Dg}</label>
                        <p class="description">${d.Eg}</p>
                        <input type="number" id="guild-market-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildMarket||2}">
                    </div>

                    <div class="timer-item">
                        <label for="auction-hold-timer" style="font-weight: bold;">${d.zg}</label>
                        <p class="description">${d.Ag}</p>
                        <input type="number" id="auction-hold-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionHoldGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="arena-timer" style="font-weight: bold;">Arena:</label>
                        <p class="description">${d.wg}</p>
                        <input type="number" id="arena-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Arena||10}">
                    </div>

                    <div class="timer-item">
                        <label for="circus-turma-timer" style="font-weight: bold;">Circus Turma:</label>
                        <p class="description">${d.Bg}</p>
                        <input type="number" id="circus-turma-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).CircusTurma||10}">
                    </div>

                    <div class="timer-item">
                        <label for="training-timer" style="font-weight: bold;">${d.Sg}</label>
                        <p class="description">${d.Tg}</p>
                        <input type="number" id="training-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Training||2}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-expired-timer" style="font-weight: bold;">${d.Gg}</label>
                        <p class="description">${d.Hg}</p>
                        <input type="number" id="reset-expired-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).ResetExpired||10}">
                    </div>

                    <div class="timer-item">
                        <label for="store-forge-timer" style="font-weight: bold;">${d.Qg}</label>
                        <p class="description">${d.Rg}</p>
                        <input type="number" id="store-forge-timer" class="timer-input" style="width: 60px;" min="5" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).StoreForge||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-auction-timer" style="font-weight: bold;">${d.xg}</label>
                        <p class="description">${d.yg}</p>
                        <input type="number" id="reset-auction-timer" class="timer-input" style="width: 60px;" min="1" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionCheck||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-search-timer" style="font-weight: bold;">${d.Ig}</label>
                        <p class="description">${d.Jg}</p>
                        <input type="number" id="reset-search-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SearchTimer||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guilddonate-timer" style="font-weight: bold;">${d.mb}</label>
                        <p class="description">${d.Cg}</p>
                        <input type="number" id="reset-guilddonate-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildDonate||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guildattack-timer" style="font-weight: bold;">Guild Attack</label>
                        <p class="description">Sets timer for guild attack</p>
                        <input type="number" id="reset-guildattack-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).guildBattleEnable||120}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-buff-timer" style="font-weight: bold;">Buffs</label>
                        <p class="description">Buff timer</p>
                        <input type="number" id="reset-buff-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Buffs||60}">
                    </div>

                    </div>
                </div>
                </div>


                  <div class="popup-box" id="other_settings">

                <div class="settings_tab_title">${d.qc}</div>

                <div class="setting-row">
                ${d.rc}
                    <select id="delaySelect">
                    <option value="0">0 seconds</option>
                    <option value="1">1 second</option>
                    <option value="5">1 to 5 seconds</option>
                    <option value="10">5 to 10 seconds</option>
                    <option value="15">10 to 15 seconds</option>
                    <option value="30">15 to 30 seconds</option>
                    <option value="60">30 to 60 seconds</option>
                    <option value="120">1 to 2 minutes</option>
                    </select>
                </div>
                <div class="setting-row">
                    <label for="timeConditions">Bot Auto Start/Stop Schedule:</label>
                    <div id="timeConditions"></div>
                    <br>
                    <button id="addCondition" class="awesome-button btn">Add Condition</button>
                    <!-- Added gap using margin-top -->
                    <br><br>
                    <button id="pauseButton" class="pause-button">Pause?</button>
                </div>
                  
                <div class="settings_tab_title">${d.ck}</div>

                <div class="setting-row">
                  <label for="storeResource">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="storeResource">
                    <span class="switch"></span>
                    </label>
                </div>

                <div class="settings_tab_title">${d.cd}</div>

                <div class="setting-row">
                  <label for="HighlightUnderworldItems">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="HighlightUnderworldItems">
                    <span class="switch"></span>
                    </label>
                </div>
                    
                <div class="settings_tab_title">${d.Ug}</div>
                <div class="setting-row">

                      <div class="setting-row">
                        <label for="trainEnable">${d.v}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainEnable">
                          <span class="switch"></span>
                          </label>
                      </div>

                      <div class="setting-row">
                        <label for="trainPickGold">${d.dk}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainPickGold">
                          <span class="switch"></span>
                          </label>
                      </div>

                          ${d.Wg}
                      <div class="stat-container">


                        <div class="stat stat-header">
                            <div>Stats</div>
                            <div>Points</div>
                            <div>Priority</div>
                        </div>

                        <div class="stat">
                          <input type="checkbox" id="Strength" class="stat-checkbox" data-skill="1" data-stat-name="Strength">
                          <label for="Strength">${d.Strength}</label>
                          <input type="number" class="stat-count" id="StrengthCount" min="0" value="${localStorage.getItem("StrengthCount")||0}">
                          <div class="priority-btn" id="StrengthPriority" data-stat="Strength" data-priority="${localStorage.getItem("StrengthPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="StrengthContinue" class="stat-checkbox" data-stat="Strength" data-skill="1">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Dexterity" class="stat-checkbox" data-skill="2" data-stat-name="Dexterity">
                          <label for="Dexterity">${d.Dexterity}</label>
                          <input type="number" class="stat-count" id="DexterityCount" min="0" value="${localStorage.getItem("DexterityCount")||0}">
                          <div class="priority-btn" id="DexterityPriority" data-stat="Dexterity" data-priority="${localStorage.getItem("DexterityPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="DexterityContinue" class="stat-checkbox" data-stat="Dexterity" >
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Agility" class="stat-checkbox" data-skill="3" data-stat-name="Agility">
                          <label for="Agility">${d.Agility}</label>
                          <input type="number" class="stat-count" id="AgilityCount" min="0" value="${localStorage.getItem("AgilityCount")||0}">
                          <div class="priority-btn" id="AgilityPriority" data-stat="Agility" data-priority="${localStorage.getItem("AgilityPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="AgilityContinue" class="stat-checkbox" data-stat="Agility">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Constitution" class="stat-checkbox" data-skill="4" data-stat-name="Constitution">
                          <label for="Constitution">${d.Constitution}</label>
                          <input type="number" class="stat-count" id="ConstitutionCount" min="0" value="${localStorage.getItem("ConstitutionCount")||0}">
                          <div class="priority-btn" id="ConstitutionPriority" data-stat="Constitution" data-priority="${localStorage.getItem("ConstitutionPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="ConstitutionContinue" class="stat-checkbox" data-stat="Constitution">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Charisma" class="stat-checkbox" data-skill="5" data-stat-name="Charisma">
                          <label for="Charisma">${d.Charisma}</label>
                          <input type="number" class="stat-count" id="CharismaCount" min="0" value="${localStorage.getItem("CharismaCount")||0}">
                          <div class="priority-btn" id="CharismaPriority" data-stat="Charisma" data-priority="${localStorage.getItem("CharismaPriority")||1}">Set Priority</div>
                          <input type="checkbox" id="CharismaContinue" class="stat-checkbox" data-stat="Charisma">
                        </div>
                      
                        <div class="stat">
                          <input type="checkbox" id="Intelligence" class="stat-checkbox" data-skill="6" data-stat-name="Intelligence">
                          <label for="Intelligence">${d.Intelligence}</label>
                          <input type="number" class="stat-count" id="IntelligenceCount" min="0" value="${localStorage.getItem("IntelligenceCount")||0}">
                          <div class="priority-btn" id="IntelligencePriority" data-stat="Intelligence" data-priority="${localStorage.getItem("IntelligencePriority")||1}">Set Priority</div>
                          <input type="checkbox" id="IntelligenceContinue" class="stat-checkbox" data-stat="Intelligence">
                        </div>                                                                                                                   

                        <div class="setting-row">
                            
                            <label for="TrainingHoldGold">${d.da}</label>

                            <div class="switch-field3">
                            <input type="number" id="TrainingHoldGold" min="0" value="${localStorage.getItem("TrainingHoldGold")||0}">                         
                            </div>  
                  
                        </div>

                                  <span class="span-new">${d.Vg}</span>        

                      </div>  
                    </div>
        
                </div>

            <div class="popup-box" id="Extra">
            <div class="settings_tab_title">${d.pb}</div>

              <div class="setting-row">
                
                    <span style="color:red"class="span-new">1 Day Trial Key : </span>
                    <span id="kydt"style="color:red"></span>
                    <br>
                    <span style="color:red"class="span-new">${d.Dd} : </span>
                    <span id="kydtexp"style="color:red"></span>
                    
                    <ul>
                    <p>
                    <b>1.1.3 Update</b>
                    <div class="scrollable-list">
                        <ul>
                        <li>Please check discord for patch notes</li>
                        </ul>
                    </div>

                </div>

                <div class="settings_tab_title">Stats</div>
                    <div class="setting-row">
                        <div id="stats">
                            <p>${d.ak} <span id="items-repaired">0</span></p>
                            <p>${d.pc} <span id="items-reset">0</span></p>
                            <p>${d.$j} <span id="gold-cycled">0</span></p>
                            <p>${d.Uj} <span id="arena-attacks">0</span></p>
                            <p>${d.Wj} <span id="circus-attacks">0</span></p>
                            <p>${d.Yj} <span id="dungeons-attacked">0</span></p>
                            <p>${d.Zj} <span id="expeditions-attacked">0</span></p>
                            <p>${d.pc} <span id="items-smelted">0</span></p>
                            <p>${d.bk} <span id="underworld-attacks">0</span></p>
                            <p>${d.Vj} <span id="arena-money">0</span></p>
                            <p>${d.Xj} <span id="circus-money">0</span></p>
                        </div>
                        <button class="awesome-button" id="reset-stats-button">${d.xh}</button>
                    </div>
           

            <div class="settings_tab_title">${d.Wd}</div>
            
            <div class="setting-row">
              <button class="awesome-button" id="exportBtn">${d.Ed}</button>
              <input type="file" id="importBtn" style="display: none;">
              <button class="awesome-button" id="importFileBtn">${d.Xd}</button>
              <p id="importStatus"></p>
              <p>
            </div>

            <div class="settings_tab_title">${d.Fc}</div>

            <div class="setting-row">
            <span class="span-new">${d.Gc}</span>
              <br></br>
              <label for="autologinenable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="autologinenable">
                <span class="switch"></span>
              </label>
            </div>

            <div class="settings_tab_title">${d.zf}</div>
                <div class="setting-row">
                <label for="pauseBotEnable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="pauseBotEnable">
                <span class="switch"></span>
                </label>
            </div>
            
            <div class="setting-row">
                <label for="pauseBot">${d.Af}</label>
                <div class="switch-field3"> 
                <input type="number" id="pauseBot" placeholder="Minutes" value="${Math.round((localStorage.getItem("pauseBot.timeOut")-Date.now())/6E4)||0}">
                </div>
                </label>
            </div>

            <div class="settings_tab_title">UI Settings</div>

                <div class="setting-row">
                    <label for="disableBG">${d.Ej}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableBG">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="disableLogMenu">${d.Tc}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableLogMenu">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="MoveButtons">${d.Fj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="MoveButtons">
                        <span class="switch"></span>
                    </label>
                </div>
                
            
    
            <div class="settings_tab_title">${d.cf}</div>
                <div class="setting-row">
                    <span class="span-new">${d.df}</span>
                    <textarea id="messageInput" rows="4" cols="50" placeholder="${d.ef}" style="width: 350px; height: 50px;"></textarea>
                    <button class="awesome-button" id="messageButton">${d.gf}</button>
                    <button class="awesome-button"id="showPlayersButton">${d.hf}</button>
                    <button class="awesome-button" id="selectAllButton">${d.ff}</button>
                    <button class="awesome-button" id="unselectAllButton">${d.jf}</button>
                    <div id="messageStatus"></div>
                    <div id="playerList" style="display: none;"></div>
                    <div id="loadingContainer"></div>
                    <br>
                    ${d.Sc}
                </div>        
            </div>

                  <div class="popup-box" id="Market">
                  <div class="settings_tab_title">Market Buy</div>
        
                    <span class="span-new">${d.Ne}</span>

                    <div class="setting-row">
                      <label for="enableMarketSearch">${d.dd}
                        <label class="toggle-switch">
                        <input type="checkbox" id="enableMarketSearch">
                        <span class="switch"></span>
                      </label>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label>${d.Oe}</label>
                    <span style="font-weight: normal">${d.Pe}</span>
                    <input type="text" id="MarketSearchInterval" placeholder="Market Search Interval - Minutes" value="${localStorage.getItem("MarketSearchInterval")||""}">

                    </div>



                    <div class="setting-row">
                    <div class="setting-row">
                        <label for="marketOnlyFood">${d.uf}
                        <label class="toggle-switch">
                        <input type="checkbox" id="marketOnlyFood">
                        <span class="switch"></span>
                        </label>
                        </label>
                    </div>
                      <span class="span-new">${d.vf}</span>
                      
                      <label for="MaxTotalGold">${d.Ib} : </label><input type="number" id="MarketMaxFoodPrice" placeholder="${d.Ib}" value="${localStorage.getItem("MarketMaxFoodPrice")||""}">
                    
                      <label for="MaxPerFood">${d.Hb} : </label><input type="number" id="MarketMaxPerFoodPrice" placeholder="${d.Hb}" value="${localStorage.getItem("MarketMaxPerFoodPrice")||""}">

                      <label for="MinItemLevel">${d.ea} : </label><input type="number" id="MarketMinItemLevel" placeholder="${d.ea}" value="${localStorage.getItem("MarketMinItemLevel")||""}">
                    

                    </div>

                    <div class="setting-row">
                    <label>${d.$d}</label>
                      <input type="text" id="itemToBuy" placeholder="${d.Yd}">
                    </div>

                    <div class="setting-row">
                      <input type="number" id="maxPrice" placeholder="${d.H}">
                    </div>

                    <div class="setting-row">
                    
                      <label>${d.ae}</label>
                      <select id="marketItemType">
                        <option value="WEAPON">${d.W}</option>
                        <option value="SHIELD">${d.S}</option>
                        <option value="CHEST">${d.M}</option>
                        <option value="HELMET">${d.P}</option>
                        <option value="GLOVES">${d.O}</option>
                        <option value="SHOES">${d.N}</option>
                        <option value="RINGS">${d.V}</option>
                        <option value="AMULETS">${d.U}</option>
                        <option value="USABLES">${d.pa}</option></option>
                        <option value="BOOSTS">${d.cj}</option></option>
                        <option value="UPGRADES">${d.wa}</option></option>
                        <option value="RECIPES">${d.ta}</option></option>
                        <option value="MERCENARY">${d.sa}</option></option>
                        <option value="FORGINGGOODS">${d.Na}</option></option>
                        <option value="btools">${d.va}</option></option>
                        <option value="SCROLLS">${d.ua}</option></option>
                      </select>

                      <label>${d.Zd}</label>
                      <select id="rarity">
                        <option value="White">${d.X}</option>
                        <option value="Green">${d.B}</option>
                        <option value="Blue">${d.A}</option>
                        <option value="Purple">${d.C}</option>
                        <option value="Orange">${d.G}</option>
                        <option value="Red">${d.R}</option>
                      </select>

                      <label>${d.Nc}</label>
                      <select id="itemsoulbound">
                        <option value="BuySoulbound">${d.rh}</option>
                        <option value="DontBuySoulbound">${d.sf}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <button class="awesome-button" id="addItemBtn">${d.I}</button>
                    </div>

                    <div class="setting-row">
                      <label for="itemList">${d.ce}</label>
                      <select id="itemList" size="10"></select>
                      <button class="awesome-button" id="removeItemBtn">${d.Qf}</button>
                    </div>

                    <div class="setting-row">
                      <label for="usePacks">${d.be}
                      <label class="toggle-switch">
                        <input type="checkbox" id="usePacks">
                        <span class="switch"></span>
                        </label>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="MarketboughtItems">${d.Lc}</label>
                      <select id="MarketboughtItems" size="5"></select>
                      <button class="awesome-button" id="MarketremoveItemBtn">${d.Qc}</button>
                    </div>

                    <div class="setting-row">
                    <label for="MarketHoldGold">${d.da}</label>
                    <input type="number" id="MarketHoldGold" min="0" value="${localStorage.getItem("MarketHoldGold")||0}">
                    </div>
                  
                    </div>   
                  </div>
                </div>
              </div>
            </div>

              `;document.getElementById("header_game").insertBefore(t,document.getElementById("header_game").children[0]);t=document.createElement("div");A=document.getElementById("wrapper_game").clientHeight;t.setAttribute("id","overlayBack");t.setAttribute("style",`height: ${A}px; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 198;`);t.addEventListener("click",gc);document.getElementsByTagName("body")[0].appendChild(t);(function(){var v=localStorage.getItem("lastActiveTab");v?(v=
document.querySelector(`.popup-tab[data-target="${v}"]`))&&Qc(v):(v=document.querySelector(".popup-tab"))&&Qc(v)})();t=localStorage.getItem("we");null!==t&&(t=(new Date(t)).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),document.getElementById("kydtexp").textContent=t,t=localStorage.getItem("showTrial"),null!==t&&(document.getElementById("kydt").textContent=t));ei();(function(){document.querySelectorAll(".setting-row").forEach(function(v){v.addEventListener("mouseenter",
function(){var D=this.getAttribute("data-tooltip");if(D&&""!==D.trim()){const E=document.createElement("div");E.className="custom-tooltip";E.innerHTML=D;document.body.appendChild(E);D=this.getBoundingClientRect();E.style.left=D.left+D.width/2-E.offsetWidth/2+"px";E.style.top=D.top-E.offsetHeight+"px";this.fm=E}});v.addEventListener("mouseleave",function(){this.fm&&(document.body.removeChild(this.fm),this.fm=null)})})})();document.querySelectorAll(".popup-tab").forEach(v=>{v.addEventListener("click",
()=>{Qc(v);localStorage.setItem("lastActiveTab",v.dataset.target)})});const z=document.querySelectorAll(".popup-tab"),y=document.querySelectorAll(".popup-box"),x=document.querySelector(`#${document.querySelector(".popup-tab.active").dataset.target}`);x.classList.add("active");y.forEach(v=>{v!==x&&(v.style.display="none")});z.forEach(v=>{v.addEventListener("click",()=>{z.forEach(D=>D.classList.remove("active"));v.classList.add("active");y.forEach(D=>{D.style.display="none"});document.querySelector(`#${v.dataset.target}`).style.display=
"block"})});$("#languageGB").click(function(){b("EN")});$("#languagePL").click(function(){b("PL")});$("#languageES").click(function(){b("ES")});$("#languageTR").click(function(){b("TR")});$("#languageFR").click(function(){b("FR")});$("#languageHG").click(function(){b("HG")});$("#languageBR").click(function(){b("BR")});$("#do_expedition_true").click(function(){c(!0)});$("#do_expedition_false").click(function(){c(!1)});$("#set_monster_id_0").click(function(){e("0")});$("#set_monster_id_1").click(function(){e("1")});
$("#set_monster_id_2").click(function(){e("2")});$("#set_monster_id_3").click(function(){e("3")});$("#do_dungeon_true").click(function(){h(!0)});$("#do_dungeon_false").click(function(){h(!1)});(t=localStorage.getItem("dungeonDifficulty"))&&g(t);$("#set_dungeon_difficulty_normal").click(function(){k("normal")});$("#set_dungeon_difficulty_advanced").click(function(){k("advanced")});$("#do_arena_true").click(function(){l(!0)});$("#do_arena_false").click(function(){l(!1)});$("#do_circus_true").click(function(){q(!0)});
$("#do_circus_false").click(function(){q(!1)});$("#do_quests_true").click(function(){m(!0)});$("#do_quests_false").click(function(){m(!1)});$("#do_combat_quests").click(function(){n("combat")});$("#do_arena_quests").click(function(){n("arena")});$("#do_circus_quests").click(function(){n("circus")});$("#do_expedition_quests").click(function(){n("expedition")});$("#do_dungeon_quests").click(function(){n("dungeon")});$("#do_items_quests").click(function(){n("items")});$("#do_event_expedition_true").click(function(){r(!0)});
$("#do_event_expedition_false").click(function(){r(!1)});$(document).ready(function(){function v(B){var H=B.split(". "),M="<ol>";H.forEach(function(O,V){""!==O.trim()&&(V!==H.length-1||O.endsWith(".")||(O+="."),M+="<li>"+O+"</li>")});return M+="</ol>"}function D(B){const H={"guild-market-timer":"GuildMarket","smelting-timer":"Smelting","smelting-timer-nogold":"SmeltingNoGold","smelting-timer-noitem":"SmeltingNoItem","repair-timer":"Repair","auction-hold-timer":"AuctionHoldGold","arena-timer":"Arena",
"circus-turma-timer":"CircusTurma","training-timer":"Training","reset-expired-timer":"ResetExpired","store-forge-timer":"StoreForge","reset-auction-timer":"AuctionCheck","reset-search-timer":"SearchTimer","reset-guilddonate-timer":"GuildDonate","reset-guildattack-timer":"guildBattleEnable","reset-buff-timer":"BuffTimer"};return H[B]?H[B]:B.replace(/-([a-z])/g,function(M){return M[1].toUpperCase()}).replace("-timer","")}function E(){var B="Strength Dexterity Agility Constitution Charisma Intelligence".split(" ");
const H=[];for(const M of B){B=document.getElementById(`${M}Count`);document.getElementById(`${M}Priority`);B=B?B.value:0;let O=ib[M];null===O&&(O="None");H.push({stat:M,count:B,priority:O,Mm:document.getElementById(`${M}`).checked})}localStorage.setItem("statSettings",JSON.stringify(H))}function I(B,H){JSON.parse(localStorage.getItem(H)||"[]").forEach(M=>J(M,B,H))}function J(B,H,M){const O=document.createElement("div");O.className="keyword-item";var V=document.createElement("span");V.textContent=
B;O.appendChild(V);V=document.createElement("span");V.className="remove-keyword";V.textContent="X";V.addEventListener("click",function(){O.remove();let Z=JSON.parse(localStorage.getItem(M)||"[]");const ca=Z.indexOf(B);-1<ca&&(Z.splice(ca,1),localStorage.setItem(M,JSON.stringify(Z)))});O.appendChild(V);H.appendChild(O)}function K(B,H){const M=JSON.parse(localStorage.getItem(H)||"[]");M.push(B);localStorage.setItem(H,JSON.stringify(M))}function P(B,H,M){const O=document.createElement("li");O.textContent=
B;O.style.padding="10px";O.style.border="1px solid #ccc";O.style.borderColor="#cea429";O.style.borderRadius="5px";O.style.marginBottom="5px";O.style.display="flex";O.style.justifyContent="space-between";const V=document.createElement("button");V.textContent="X";V.style.textAlign="center";V.addEventListener("click",()=>{O.remove();const Z=(JSON.parse(localStorage.getItem(M))||[]).filter(ca=>!(ca[0]===B[0]&&ca[1]===B[1]));localStorage.setItem(M,JSON.stringify(Z))});O.appendChild(V);document.getElementById(H).appendChild(O)}
function T(){jb=jb.map(B=>{B.rm=!1;B.mm=null;return B})}function X(){document.getElementById("startSearchButton").innerText="Start Search";kc=!1}function ia(){const B=document.getElementById("clothCount");var H=parseInt(B.value,10);isNaN(H)&&(H=0);--H;0>=H&&(H=0);return B.value=H}function fa(){const B=document.getElementById("itemsList");B.innerHTML="";jb.forEach((H,M)=>{const O=document.createElement("div");O.style.display="flex";O.style.flexDirection="column";O.style.border="1px solid #d2b97f";
O.style.padding="10px";O.style.marginBottom="10px";O.style.borderRadius="5px";O.style.backgroundColor="#faf2dd";var V=document.createElement("div");V.style.display="flex";V.style.justifyContent="space-between";V.style.alignItems="center";const Z=document.createElement("span");Z.innerHTML=`<strong>${H.name}</strong> (${H.qualityName}) - Level: [${H.Ym}]`;Z.style.color="#5d432c";const ca=document.createElement("button");ca.innerText="Remove";ca.style.backgroundColor="#af552e";ca.style.color="white";
ca.style.border="none";ca.style.padding="5px 10px";ca.style.cursor="pointer";ca.style.borderRadius="3px";ca.onclick=()=>{jb.splice(M,1);fa();na()};V.appendChild(Z);V.appendChild(ca);O.appendChild(V);H.Sl&&H.cm&&(V=document.createElement("div"),V.style.marginTop="5px",V.style.fontStyle="italic",V.style.color="#7d5b3e",V.innerText=`Stat: ${H.Sl.toUpperCase()} - Value: ${H.cm}`,O.appendChild(V));B.appendChild(O)})}function na(){localStorage.setItem("itemsToSearch",JSON.stringify(jb))}function ta(B,H){const M=
document.getElementById("foundItemsContainer");M.style.display="flex";M.style.flexWrap="wrap";M.style.justifyContent="center";M.style.alignItems="center";M.style.hp="10px";const O=document.createElement("div");O.className="notification-item";O.style.border="1px solid #d2b97f";O.style.borderRadius="4px";O.style.padding="10px";O.style.margin="5px";O.style.textAlign="center";O.style.backgroundColor="#faf2dd";O.style.boxShadow="0 2px 4px rgba(0, 0, 0, 0.1)";O.style.boxSizing="border-box";O.style.flex=
"0 1 calc(20% - 10px)";O.style.display="flex";O.style.flexDirection="column";O.style.alignItems="center";O.style.transition="all 0.3s ease-in-out";const V=document.createElement("span"),Z=document.createElement("span");switch(Number(B.mm.getAttribute("data-quality"))){case 0:Z.style.color="green";break;case 1:Z.style.color="blue";break;case 2:Z.style.color="purple";break;case 3:Z.style.color="orange";break;case 4:Z.style.color="red";break;default:Z.style.color="#333"}Z.innerText=B.name;Z.style.fontWeight=
"bold";Z.style.fontSize="12px";Z.style.marginBottom="5px";V.appendChild(Z);const ca=document.createElement("div");ca.style.marginTop="5px";ca.style.padding="10px";ca.style.borderRadius="5px";ca.style.display="flex";ca.style.justifyContent="center";ca.style.alignItems="center";ca.style.transition="transform 0.3s ease-in-out";ca.onmouseover=()=>{ca.style.transform="scale(1.1)"};ca.onmouseout=()=>{ca.style.transform="scale(1)"};B=B.mm.cloneNode(!0);B.style.position="static";B.style.transform="none";
B.style.margin="0";ca.appendChild(B);B=document.createElement("a");B.href=H;B.style.textDecoration="none";B.style.cursor="pointer";B.onmouseover=()=>{Z.style.textDecoration="underline"};B.onmouseout=()=>{Z.style.textDecoration="none"};B.appendChild(V);B.appendChild(ca);O.appendChild(B);M.appendChild(O);lc.style.display="block"}async function la(){var B=!1;if(!kc)return!1;const H=await Hf();var M=jb.filter(ca=>!ca.rm);for(let ca of M)for(const Sc of H){M=Sc.querySelectorAll("#shop .ui-draggable");
for(const Ta of M){var O=JSON.parse(Ta.getAttribute("data-tooltip").replace(/&quot;/g,'"')),V=parseInt(wb(Ta).split("-")[0],10);M=15==V?parseInt(Ta.getAttribute("data-tooltip").split(",")[5].match(/\d+/)[0],10):0;let gi=15==V?parseInt(Ta.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,hi=15==V?parseInt(Ta.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,ii=15==V?parseInt(Ta.getAttribute("data-tooltip").split(",")[11].match(/\d+/)[0],10):0,ji=15==V?parseInt(Ta.getAttribute("data-tooltip").split(",")[13].match(/\d+/)[0],
10):0;V=15==V?parseInt(Ta.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],10):0;var Z=Ta.getAttribute("data-quality");O=O[0][0][0];const ki=Ta.getAttribute("data-level");if(Number(ki)>=Number(ca.Ym)&&O.toLowerCase().includes(ca.name.toLowerCase())&&(Z>=ca.quality||!Z&&"0"==ca.quality)){if(ca.Sl&&ca.cm&&"none"!==ca.Sl&&(Z=!1,(M={str:M,dex:gi,agi:hi,cot:ii,chr:ji,"int":V}[ca.Sl])&&M>=ca.cm&&(Z=!0),!Z))continue;ca.mm=Ta.cloneNode(!0);ta(ca,Sc.zm||Sc.querySelector("a.shopLink").href);B=ca.rm=
!0}}}M=jb.filter(ca=>!ca.rm);if(0===M.length||B)return X(),!0;B=ia();Na();if(0>=B)return X(),!1;await xa();return la()}async function xa(){var B=new URL(window.location.href);const H=B.origin;B=B.searchParams.get("sh")||"";await fetch(`${H}/game/index.php?mod=inventory&sub=2&subsub=0&sh=${B}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({bestechen:"New goods"})})}function Na(){var B=parseInt(document.getElementById("clothCount").getAttribute("data-total"),
10);const H=parseInt(document.getElementById("clothCount").value,10);B=(B-H)/B*100;document.getElementById("progressBarInner").style.width=`${isNaN(B)?100:B}%`}function Gb(){const B=[...Tc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelectionSmelt",JSON.stringify(B))}function Oa(){const B=[...Uc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelection",JSON.stringify(B))}function Xa(){localStorage.setItem("timeConditions",JSON.stringify(Hb))}function mc(B=
{}){const H=document.createElement("div");H.classList.add("condition-row");H.innerHTML=`
                    <input type="time" class="awesome-button start-time" value="${B.start||""}" required> to
                    <input type="time" class="awesome-button end-time" value="${B.end||""}" required>
                    <br>
                    <select class="bot-action">
                        <option value="start" ${"start"===B.action?"selected":""}>Start Bot</option>
                        <option value="stop" ${"stop"===B.action?"selected":""}>Stop Bot</option>
                    </select>
                    <button class="awesome-button remove-condition">Remove</button>
                `;Xa();H.querySelector(".remove-condition").addEventListener("click",()=>{If.removeChild(H);Hb=Hb.filter(M=>M!==B);Xa()});H.querySelector(".start-time").addEventListener("change",M=>{B.start=M.target.value;Xa()});H.querySelector(".end-time").addEventListener("change",M=>{B.end=M.target.value;Xa()});H.querySelector(".bot-action").addEventListener("change",M=>{B.action=M.target.value;Xa()});If.appendChild(H)}function Jf(){document.getElementById("mercenarySearchOptions").style.display=
nc.checked?"block":"none"}function li(B){document.querySelectorAll('#itemsToReset input[type="checkbox"]').forEach(H=>{H.checked=B});Ua()}function Vc(){localStorage.setItem("marketItems",JSON.stringify(kb));Wc.innerHTML="";Kf.innerHTML="";for(var B of Ib){var H=document.createElement("option");H.textContent=B;Kf.appendChild(H)}for(B=0;B<kb.length;B++)H=document.createElement("option"),H.value=B,H.text=kb[B].Vm+" (Rarity: "+kb[B].am+", Max price: "+kb[B].maxPrice+" "+kb[B].Soulbound+")",Wc.appendChild(H)}
function Lf(B,H,M){H[B.id]&&B.classList.add("active");B.addEventListener("click",function(O){O.preventDefault();this.classList.contains("active")?(this.classList.remove("active"),H[this.id]=!1):(this.classList.add("active"),H[this.id]=!0);localStorage.setItem(M,JSON.stringify(H))})}function Mf(B,H,M,O){M.forEach(V=>{V in H||(H[V]=!1)});localStorage.setItem(O,JSON.stringify(H))}function Nf(){const B=oc.checked;mi.style.display=B?"block":"none";ni.style.display=B?"block":"none"}const oi=document.getElementById("doExpedition"),
pi=document.getElementById("doDungeon"),qi=document.getElementById("doArena"),ri=document.getElementById("doCircus"),si=document.getElementById("doQuests"),ti=document.getElementById("doEventExpedition"),ui=document.getElementById("activateAutoBid"),vi=document.getElementById("doKasa"),pc=document.querySelector("#healPercentage"),Xc=document.querySelector("#HealClothToggle"),Of=document.querySelector("#hellEnterHP"),Pf=document.querySelector("#HellHealHP"),Yc=document.querySelector("#HealRubyToggle"),
Zc=document.querySelector("#storeResource"),$c=document.querySelector("#HighlightUnderworldItems");pc.value=localStorage.getItem("healPercentage")||25;Xc.checked="true"===localStorage.getItem("HealClothToggle")||!1;Yc.checked="true"===localStorage.getItem("HealRubyToggle")||!1;Zc.checked="true"===localStorage.getItem("storeResource")||!1;$c.checked="true"===localStorage.getItem("HighlightUnderworldItems")||!1;const Qf=document.getElementById("minimumGoldAmount");Qf.addEventListener("change",()=>{localStorage.setItem("minimumGoldAmount",
Qf.value)});const Rf="true"===localStorage.getItem("useGodPowers");document.getElementById("useGodPowers").checked=Rf;document.getElementById("godPowersSection").style.display=Rf?"block":"none";const wi=JSON.parse(localStorage.getItem("GodPowersHell"))||[];document.querySelectorAll(".god-power-checkbox").forEach(B=>{B.checked=wi.includes(B.value)});const xi="true"===localStorage.getItem("useWeaponBuff");document.getElementById("weaponBuff").checked=xi;const yi=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||
[];document.querySelectorAll(".armor-checkbox").forEach(B=>{B.checked=yi.includes(B.value)});document.getElementById("useGodPowers").addEventListener("change",function(){const B=this.checked;localStorage.setItem("useGodPowers",B);document.getElementById("godPowersSection").style.display=B?"block":"none"});document.querySelectorAll(".god-power-checkbox").forEach(B=>{B.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".god-power-checkbox:checked")).map(M=>M.value);localStorage.setItem("GodPowersHell",
JSON.stringify(H))})});document.getElementById("weaponBuff").addEventListener("change",function(){localStorage.setItem("useWeaponBuff",this.checked)});document.querySelectorAll(".armor-checkbox").forEach(B=>{B.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".armor-checkbox:checked")).map(M=>M.value);localStorage.setItem("ArmorBuffsHell",JSON.stringify(H))})});const Sf=document.getElementById("autoSmeltInfo"),zb=document.getElementById("popupSmelt");Sf.addEventListener("mouseenter",
function(){zb.style.display="block";const B=document.querySelector(".popup-menu").getBoundingClientRect();zb.style.position="fixed";zb.style.width="350px";zb.style.left=`${B.right+10}px`;zb.style.top=`${B.top}px`});Sf.addEventListener("mouseleave",function(){zb.style.display="none"});var ad=document.getElementById("tabA"),bd=document.getElementById("tabB"),Tf=document.getElementById("contentA"),Uf=document.getElementById("contentB"),cd=document.getElementById("tabACircus"),dd=document.getElementById("tabBCircus"),
Vf=document.getElementById("contentACircus"),Wf=document.getElementById("contentBCircus");ad.addEventListener("click",function(){Tf.style.display="block";Uf.style.display="none";ad.classList.add("active");bd.classList.remove("active")});bd.addEventListener("click",function(){Uf.style.display="block";Tf.style.display="none";bd.classList.add("active");ad.classList.remove("active")});cd.addEventListener("click",function(){Vf.style.display="block";Wf.style.display="none";cd.classList.add("active");dd.classList.remove("active")});
dd.addEventListener("click",function(){Wf.style.display="block";Vf.style.display="none";dd.classList.add("active");cd.classList.remove("active")});const zi=v(d.cc),Ai=v(d.Ob);document.querySelector(".instructions .span-new").innerHTML=zi;document.querySelector(".instructionsReset .span-new").innerHTML=Ai;const ed=document.getElementById("announcement"),fd=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio";fd&&""!==fd?(ed.style.display="block",ed.innerHTML=fd):ed.style.display="none";const Bi=[{id:"Health",
buffs:["Gingko","Taigaroot","Hawthorn"]},{id:"Strength",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Dexterity",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Agility",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Constitution",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Charisma",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Intelligence",buffs:["Flask","Ampulla","Flacon","Bottle"]}];(function(){const B=JSON.parse(localStorage.getItem("buffSelections"))||{};Bi.forEach(H=>{B[H.id]=
B[H.id]||[];H.buffs.forEach((M,O)=>{const V=document.getElementById(`${H.id}Buff${O+1}`);V.checked=B[H.id].includes(M);V.addEventListener("change",()=>{V.checked?B[H.id].push(M):B[H.id]=B[H.id].filter(Z=>Z!==M);localStorage.setItem("buffSelections",JSON.stringify(B))})})})})();let gd=document.getElementById("BuffsEnable");gd.checked="true"===localStorage.getItem("BuffsEnable");gd.addEventListener("change",()=>{localStorage.setItem("BuffsEnable",gd.checked)});let hd=document.getElementById("BuffUnderworldOnly");
hd.checked="true"===localStorage.getItem("BuffUnderworldOnly");hd.addEventListener("change",()=>{localStorage.setItem("BuffUnderworldOnly",hd.checked)});document.querySelectorAll(".timer-input").forEach(B=>{B.addEventListener("change",function(){var H=parseInt(this.min,10);let M=parseInt(this.value,10);M<H&&(this.value=M=H);H=JSON.parse(localStorage.getItem("Timers"))||{};const O=D(this.id);H[O]=M;localStorage.setItem("Timers",JSON.stringify(H))})});const ib={Strength:null,Dexterity:null,Agility:null,
Constitution:null,Charisma:null,Intelligence:null};(function(){var B=JSON.parse(localStorage.getItem("statSettings"))||[];for(const {stat:H,count:M,priority:O,Mm:V}of B)document.getElementById(`${H}Count`)&&(document.getElementById(`${H}Count`).value=M),document.getElementById(`${H}Priority`)&&(B=O||"None",document.getElementById(`${H}Priority`).dataset.priority=B,document.getElementById(`${H}Priority`).textContent=`Priority: ${B}`),document.getElementById(`${H}`)&&(document.getElementById(`${H}`).checked=
V||!1);B=JSON.parse(localStorage.getItem("statSettings"))||[];for(const {stat:H,priority:M}of B)ib[H]="None"===M?null:M})();const Xf=document.querySelectorAll(".priority-btn");Xf.forEach(B=>{B.addEventListener("click",function(H){const M=H.target.getAttribute("data-stat");let O=(ib[M]||0)+1;6<O&&(O=1);for(const [V,Z]of Object.entries(ib))if(Z===O){ib[V]=null;const ca=document.getElementById(`${V}Priority`);ca.innerText="Set Priority";ca.setAttribute("data-priority","None")}ib[M]=O;H.target.innerText=
`Priority: ${O}`;H.target.setAttribute("data-priority",O);Xf.forEach(V=>{const Z=V.getAttribute("data-stat");V.innerText=null!==ib[Z]?`Priority: ${ib[Z]}`:"Set Priority"});E()})});Array.from(document.getElementsByClassName("stat-count")).forEach(B=>{B.addEventListener("change",()=>{E()})});document.getElementById("clear_next_event_expedition_time").addEventListener("click",function(){localStorage.setItem("eventPoints_",16);alert("Done!")});let $a=localStorage.getItem("workbenchItem");$a=$a?JSON.parse($a):
{};$a.selectedItem&&$a.selectedItem.item?document.getElementById("currentWorkbenchItem").textContent=$a.selectedItem.item.name:document.getElementById("currentWorkbenchItem").textContent="No item";document.getElementById("clear_repair").addEventListener("click",function(){$a.selectedItem&&($a.selectedItem={},Object.assign($a.selectedItem,{selectedItem:!1}),localStorage.removeItem("workbenchItem"),localStorage.removeItem("activeItems"),localStorage.removeItem("activeItemsGladiator"),localStorage.removeItem("activeItemsMercenary"),
document.getElementById("currentWorkbenchItem").textContent="No item")});document.getElementById("ClearAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackList",JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearOtherAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackServerList",JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));
window.location.reload()});document.getElementById("ClearAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackList",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearOtherCircusAttackList").addEventListener("click",
function(){localStorage.setItem("autoAttackCircusServerList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackCircusList",JSON.stringify([]));window.location.reload()});const Yf=document.getElementById("keywordAcceptInput"),Ci=document.getElementById("addKeywordAcceptBtn"),Zf=document.getElementById("keywordAcceptList"),
qc=document.getElementById("underworldKeywordSection"),$f=document.getElementById("underworldKeywordInput"),Di=document.getElementById("addUnderworldKeywordBtn"),ag=document.getElementById("underworldKeywordList");let jd=document.getElementById("skipTimeQuests");jd.checked="true"===localStorage.getItem("skipTimeQuests");jd.addEventListener("change",()=>{localStorage.setItem("skipTimeQuests",jd.checked)});let kd=document.getElementById("skipTimeCircusQuests");kd.checked="true"===localStorage.getItem("skipTimeCircusQuests");
kd.addEventListener("change",()=>{localStorage.setItem("skipTimeCircusQuests",kd.checked)});let ld=document.getElementById("skipTimeOtherQuests");ld.checked="true"===localStorage.getItem("skipTimeOtherQuests");ld.addEventListener("change",()=>{localStorage.setItem("skipTimeOtherQuests",ld.checked)});"Mercury Apollo Diana Minerva Vulcan Mars".split(" ").forEach(B=>{let H=document.getElementById(`questType${B}`);H.checked="true"===localStorage.getItem(`questType${B}`);H.addEventListener("change",()=>
{localStorage.setItem(`questType${B}`,H.checked)})});let Jb=document.getElementById("UnderworldQuests");Jb.checked="true"===localStorage.getItem("UnderworldQuests");Jb.addEventListener("change",()=>{localStorage.setItem("UnderworldQuests",Jb.checked);Jb.checked||"true"===localStorage.getItem("UnderworldQuests")?qc.style.display="block":qc.style.display="none"});Jb.checked||"true"===localStorage.getItem("UnderworldQuests")?qc.style.display="block":qc.style.display="none";let md=document.getElementById("acceptnotfilter");
md.checked="true"===localStorage.getItem("acceptnotfilter");md.addEventListener("change",()=>{localStorage.setItem("acceptnotfilter",md.checked)});const nd=document.getElementById("keywordInput"),Ei=document.getElementById("addKeywordBtn"),bg=document.getElementById("keywordList"),Fi=document.getElementById("keywordGuildInput"),Gi=document.getElementById("addGuildKeywordBtn"),cg=document.getElementById("keywordGuildList");I(cg,"guildKeywords");Gi.addEventListener("click",function(){const B=Fi.value.trim();
""!==B&&(J(B,cg,"guildKeywords"),K(B,"guildKeywords"),nd.value="")});I(bg,"questKeywords");I(ag,"underworldQuestKeywords");Ei.addEventListener("click",function(){const B=nd.value.trim();""!==B&&(J(B,bg,"questKeywords"),K(B,"questKeywords"),nd.value="")});I(Zf,"acceptQuestKeywords");Ci.addEventListener("click",function(){const B=Yf.value.trim();""!==B&&(J(B,Zf,"acceptQuestKeywords"),K(B,"acceptQuestKeywords"),Yf.value="")});Di.addEventListener("click",function(){const B=$f.value.trim();""!==B&&(J(B,
ag,"underworldQuestKeywords"),K(B,"underworldQuestKeywords"),$f.value="")});let od=document.getElementById("renewEvent");od.checked="true"===localStorage.getItem("renewEvent");od.addEventListener("change",()=>{localStorage.setItem("renewEvent",od.checked)});let pd=document.getElementById("throwDice");pd.checked="true"===localStorage.getItem("throwDice");pd.addEventListener("change",()=>{localStorage.setItem("throwDice",pd.checked)});let qd=document.getElementById("useCostume");qd.checked="true"===
localStorage.getItem("useCostume");qd.addEventListener("change",()=>{localStorage.setItem("useCostume",qd.checked)});let Kb=document.getElementById("wearUnderworld"),dg=document.getElementById("costumeUnderworldWrapper");Kb.checked="true"===localStorage.getItem("wearUnderworld");dg.style.display=Kb.checked?"block":"none";Kb.addEventListener("change",()=>{localStorage.setItem("wearUnderworld",Kb.checked);dg.style.display=Kb.checked?"block":"none"});document.getElementById("costumeUnderworld").addEventListener("change",
function(){localStorage.setItem("costumeUnderworld",this.value)});const Hi=document.getElementById("costumeUnderworld"),eg=localStorage.getItem("costumeUnderworld");null!==eg&&(Hi.value=eg);const Ii=document.getElementById("costumeBasic"),fg=localStorage.getItem("costumeBasic");document.getElementById("costumeBasic").addEventListener("change",function(){localStorage.setItem("costumeBasic",this.value)});null!==fg&&(Ii.value=fg);document.getElementById("costumeDungeon").addEventListener("change",function(){localStorage.setItem("costumeDungeon",
this.value)});const Ji=document.getElementById("costumeDungeon"),gg=localStorage.getItem("costumeDungeon");null!==gg&&(Ji.value=gg);const Ki=document.getElementById("search_input"),Li=document.getElementById("search_reset"),Mi=document.getElementById("search_button");let rc=JSON.parse(localStorage.getItem("searchTerms")||"[]");rc.forEach(B=>{P(B,"search_list","searchTerms")});Mi.addEventListener("click",function(){const B=Ki.value.trim();""===B||rc.includes(B)||(rc.push(B),localStorage.setItem("searchTerms",
JSON.stringify(rc)),P(B,"search_list","searchTerms"))});const rd=document.querySelector(".equipment-search-selection");rd.addEventListener("change",()=>{const B=Array.from(rd.querySelectorAll(".equipment-search-option:checked")).map(H=>H.value);localStorage.setItem("SearchTypes",JSON.stringify(B))});JSON.parse(localStorage.getItem("SearchTypes")||"[]").forEach(B=>{if(B=rd.querySelector(`.equipment-search-option[value="${B}"]`))B.checked=!0});let jb=JSON.parse(localStorage.getItem("itemsToSearch"))||
[];document.getElementById("addItemButton").addEventListener("click",function(){const B=document.getElementById("newItem").value,H=document.getElementById("itemQuality").value,M=document.getElementById("newItemLevel").value,O=document.getElementById("shopitemstat").value,V=document.getElementById("statValue").value;jb.push({name:B,quality:H,Ym:M,qualityName:Ni[H],Sl:"none"!==O?O:null,cm:"none"!==O?V:null});fa();na()});document.getElementById("startSearchButton").addEventListener("click",async function(){kc=
!0;lc.style.display="none";document.getElementById("clothCount").setAttribute("data-total",document.getElementById("clothCount").value);document.getElementById("startSearchButton").innerText="Searching...";await la()});document.getElementById("stopSearchButton").addEventListener("click",X);document.getElementById("shopitemstat").addEventListener("change",function(){document.getElementById("statValueRow").style.display="none"===this.value?"none":"block"});const lc=document.getElementById("skipSearchButton");
lc.addEventListener("click",async function(){const B=document.getElementById("foundItemsContainer");for(;B.firstChild;)B.removeChild(B.firstChild);T();kc=!0;lc.style.display="none";ia();Na();await xa();await la()});let kc=!0;const Ni={0:"Green",1:"Blue",2:"Purple",3:"Orange",4:"Red"};fa();bi();const Tc=document.querySelectorAll(".equipment-option-smelt");Tc.forEach(B=>{B.addEventListener("change",Gb)});(JSON.parse(localStorage.getItem("equipmentSelectionSmelt"))||[]).forEach(B=>{const H=[...Tc].find(M=>
M.value===B);H&&(H.checked=!0)});const Uc=document.querySelectorAll(".equipment-option");Uc.forEach(B=>{B.addEventListener("change",Oa)});(JSON.parse(localStorage.getItem("equipmentSelection"))||[]).forEach(B=>{const H=[...Uc].find(M=>M.value===B);H&&(H.checked=!0)});Li.addEventListener("click",function(){localStorage.setItem("AuctionSearch.timeOut",0);localStorage.setItem("ShopSearch.timeOut",0);location.reload()});let sd=document.getElementById("trainPickGold");sd.checked="true"===localStorage.getItem("trainPickGold");
sd.addEventListener("change",()=>{localStorage.setItem("trainPickGold",sd.checked)});let td=document.getElementById("trainEnable");td.checked="true"===localStorage.getItem("trainEnable");td.addEventListener("change",()=>{localStorage.setItem("trainEnable",td.checked)});let ud=document.getElementById("EnableArenaHell");ud.checked="true"===localStorage.getItem("EnableArenaHell");ud.addEventListener("change",()=>{localStorage.setItem("EnableArenaHell",ud.checked)});let vd=document.getElementById("dungeonAB");
vd.checked="true"===localStorage.getItem("dungeonAB");vd.addEventListener("change",()=>{localStorage.setItem("dungeonAB",vd.checked)});let wd=document.getElementById("dungeonFocusQuest");wd.checked="true"===localStorage.getItem("dungeonFocusQuest");wd.addEventListener("change",()=>{localStorage.setItem("dungeonFocusQuest",wd.checked)});(function(){const B=document.getElementById("autologinenable"),H="true"===localStorage.getItem("AutoLogin");B.checked=H;tf(H);B.addEventListener("change",function(){const M=
this.checked;localStorage.setItem("AutoLogin",M);tf(M)})})();const If=document.getElementById("timeConditions"),Oi=document.getElementById("addCondition");let Hb=JSON.parse(localStorage.getItem("timeConditions"))||[];Hb.forEach(mc);Oi.addEventListener("click",()=>{const B={start:"",end:"",action:"stop"};Hb.push(B);mc(B);Xa()});const xd=document.getElementById("pauseButton");let Lb="true"===localStorage.getItem("botPaused");xd.textContent=Lb?"Paused":"Pause?";xd.addEventListener("click",function(){Lb=
!Lb;xd.textContent=Lb?"Paused":"Pause?";localStorage.setItem("botPaused",Lb.toString())});let yd=document.getElementById("enableArenaSimulator");yd.checked="true"===localStorage.getItem("enableArenaSimulator");yd.addEventListener("change",()=>{localStorage.setItem("enableArenaSimulator",yd.checked)});let zd=document.getElementById("enableCircusSimulator");zd.checked="true"===localStorage.getItem("enableCircusSimulator");zd.addEventListener("change",()=>{localStorage.setItem("enableCircusSimulator",
zd.checked)});let Ad=document.getElementById("enableCircusWithoutHeal");Ad.checked="true"===localStorage.getItem("enableCircusWithoutHeal");Ad.addEventListener("change",()=>{localStorage.setItem("enableCircusWithoutHeal",Ad.checked)});let Bd=document.getElementById("arenaAttackGM");Bd.checked="true"===localStorage.getItem("arenaAttackGM");Bd.addEventListener("change",()=>{localStorage.setItem("arenaAttackGM",Bd.checked)});let Cd=document.getElementById("onlyArena");Cd.checked="true"===localStorage.getItem("onlyArena");
Cd.addEventListener("change",()=>{localStorage.setItem("onlyArena",Cd.checked)});let Dd=document.getElementById("onlyCircus");Dd.checked="true"===localStorage.getItem("onlyCircus");Dd.addEventListener("change",()=>{localStorage.setItem("onlyCircus",Dd.checked)});let Ed=document.getElementById("attackRandomly");Ed.checked="true"===localStorage.getItem("attackRandomly");Ed.addEventListener("change",()=>{localStorage.setItem("attackRandomly",Ed.checked)});let Fd=document.getElementById("attackRandomlyCircus");
Fd.checked="true"===localStorage.getItem("attackRandomlyCircus");Fd.addEventListener("change",()=>{localStorage.setItem("attackRandomlyCircus",Fd.checked)});let Gd=document.getElementById("circusAttackGM");Gd.checked="true"===localStorage.getItem("circusAttackGM");Gd.addEventListener("change",()=>{localStorage.setItem("circusAttackGM",Gd.checked)});let Hd=document.getElementById("auctionmercenaryenable");Hd.checked="true"===localStorage.getItem("auctionmercenaryenable");Hd.addEventListener("change",
()=>{localStorage.setItem("auctionmercenaryenable",Hd.checked)});let Id=document.getElementById("auctionTURBO");Id.checked="true"===localStorage.getItem("auctionTURBO");Id.addEventListener("change",()=>{localStorage.setItem("auctionTURBO",Id.checked)});let Jd=document.getElementById("auctiongladiatorenable");Jd.checked="true"===localStorage.getItem("auctiongladiatorenable");Jd.addEventListener("change",()=>{localStorage.setItem("auctiongladiatorenable",Jd.checked)});let Kd=document.getElementById("bidFood");
Kd.checked="true"===localStorage.getItem("bidFood");Kd.addEventListener("change",()=>{localStorage.setItem("bidFood",Kd.checked)});let Ld=document.getElementById("ignorePS");Ld.checked="true"===localStorage.getItem("ignorePS");Ld.addEventListener("change",()=>{localStorage.setItem("ignorePS",Ld.checked)});let Md=document.getElementById("auctionminlevel");Md.value=localStorage.getItem("auctionminlevel")||"";Md.addEventListener("input",()=>{localStorage.setItem("auctionminlevel",Md.value)});let Nd=
document.getElementById("AuctionCover");Nd.checked="true"===localStorage.getItem("AuctionCover");Nd.addEventListener("change",()=>{localStorage.setItem("AuctionCover",Nd.checked)});let Od=document.getElementById("AuctionGoldCover");Od.checked="true"===localStorage.getItem("AuctionGoldCover");Od.addEventListener("change",()=>{localStorage.setItem("AuctionGoldCover",Od.checked)});let Pd=document.getElementById("maximumBid");Pd.value=localStorage.getItem("maximumBid")||"";Pd.addEventListener("input",
()=>{localStorage.setItem("maximumBid",Pd.value)});let Qd=document.getElementById("activateAuction2");Qd.checked="true"===localStorage.getItem("activateAuction2");Qd.addEventListener("change",()=>{localStorage.setItem("activateAuction2",Qd.checked)});let Rd=document.getElementById("AuctionItemLevel2");Rd.value=localStorage.getItem("AuctionItemLevel2")||"";Rd.addEventListener("input",()=>{localStorage.setItem("AuctionItemLevel2",Rd.value)});let nc=document.getElementById("enableMercenarySearch"),Sd=
document.getElementById("minDexterity"),Td=document.getElementById("minAgility"),Ud=document.getElementById("minIntelligence");nc.checked="true"===localStorage.getItem("enableMercenarySearch");Sd.value=localStorage.getItem("minDexterity")||0;Td.value=localStorage.getItem("minAgility")||0;Ud.value=localStorage.getItem("minIntelligence")||0;Jf();nc.addEventListener("change",()=>{localStorage.setItem("enableMercenarySearch",nc.checked);Jf()});Sd.addEventListener("input",()=>{localStorage.setItem("minDexterity",
Sd.value)});Td.addEventListener("input",()=>{localStorage.setItem("minAgility",Td.value)});Ud.addEventListener("input",()=>{localStorage.setItem("minIntelligence",Ud.value)});const Vd=document.getElementById("SearchQuality"),hg=localStorage.getItem("SearchQuality");hg&&(Vd.value=hg);Vd.addEventListener("change",()=>{localStorage.setItem("SearchQuality",Vd.value)});const Wd=document.getElementById("HealPickBag"),ig=localStorage.getItem("HealPickBag");ig&&(Wd.value=ig);Wd.addEventListener("change",
()=>{localStorage.setItem("HealPickBag",Wd.value)});const Xd=document.getElementById("FoodAmount"),jg=localStorage.getItem("FoodAmount");jg&&(Xd.value=jg);Xd.addEventListener("change",()=>{localStorage.setItem("FoodAmount",Xd.value)});const kg=document.getElementById("questrewardvalue");kg.addEventListener("change",()=>{localStorage.setItem("questrewardvalue",kg.value)});const Yd=document.getElementById("smeltTab"),lg=localStorage.getItem("smeltTab");lg&&(Yd.value=lg);Yd.addEventListener("change",
()=>{localStorage.setItem("smeltTab",Yd.value)});const Zd=document.getElementById("repairMaxQuality"),$d=document.getElementById("repairBeforeSmeltMaxQuality"),ae=document.getElementById("PartialOrFull");let sc=localStorage.getItem("repairMaxQuality"),tc=localStorage.getItem("repairBeforeSmeltMaxQuality"),uc=localStorage.getItem("PartialOrFull");sc||(sc="1",localStorage.setItem("repairMaxQuality",sc));tc||(tc="1",localStorage.setItem("RSMaxQuality",tc));uc||(uc="0",localStorage.setItem("PartialOrFull",
uc));Zd.value=sc;$d.value=tc;Zd.addEventListener("change",()=>{localStorage.setItem("repairMaxQuality",Zd.value)});$d.addEventListener("change",()=>{localStorage.setItem("repairBeforeSmeltMaxQuality",$d.value)});ae.addEventListener("change",()=>{localStorage.setItem("PartialOrFull",ae.value)});ae.value=uc;var vc=document.getElementById("repairPercentage");(function(){var B=localStorage.getItem("repairPercentage");if(null!==B)for(var H=0;H<vc.options.length;H++)if(vc.options[H].text.replace("%","")===
B){vc.selectedIndex=H;break}})();vc.addEventListener("change",function(){var B=this.options[this.selectedIndex].text.replace("%","");localStorage.setItem("repairPercentage",B)});const be=document.getElementById("bidStatus"),mg=localStorage.getItem("bidStatus");mg&&(be.value=mg);be.addEventListener("change",()=>{localStorage.setItem("bidStatus",be.value)});const ce=document.getElementById("auctionMinQuality"),ng=localStorage.getItem("auctionMinQuality");ng&&(ce.value=ng);ce.addEventListener("change",
()=>{localStorage.setItem("auctionMinQuality",ce.value)});const de=document.getElementById("storeInShopQuality"),og=localStorage.getItem("storeInShopQuality");og&&(de.value=og);de.addEventListener("change",()=>{localStorage.setItem("storeInShopQuality",de.value)});const Ua=function(B,H){let M;return function(){const O=this,V=arguments;clearTimeout(M);M=setTimeout(()=>B.apply(O,V),H)}}(function(){const B=document.getElementById("resetExpiredItems").checked,H=document.getElementById("resetDays").value,
M=Array.from(document.querySelectorAll('#itemsToReset input[type="checkbox"]:checked')).map(Z=>Z.value),O=Array.from(document.querySelectorAll('#itemsToReset2 input[type="checkbox"]:checked')).map(Z=>Z.value),V=Array.from(document.querySelectorAll('#itemsToResetGuild input[type="checkbox"]:checked')).map(Z=>Z.value);localStorage.setItem("resetExpiredItems",B);localStorage.setItem("resetDays",H);localStorage.setItem("itemsToReset",JSON.stringify(M));localStorage.setItem("itemsToReset2",JSON.stringify(O));
localStorage.setItem("itemsToResetGuild",JSON.stringify(V))},250);document.getElementById("resetExpiredItems").addEventListener("change",Ua);document.getElementById("resetDays").addEventListener("change",Ua);document.getElementById("itemsToReset").addEventListener("change",Ua);document.getElementById("itemsToReset2").addEventListener("change",Ua);document.getElementById("itemsToResetGuild").addEventListener("change",Ua);document.getElementById("resetExpiredItems").addEventListener("touchend",Ua);
document.getElementById("resetDays").addEventListener("touchend",Ua);document.getElementById("itemsToReset").addEventListener("touchend",Ua);document.getElementById("itemsToReset2").addEventListener("touchend",Ua);document.getElementById("itemsToResetGuild").addEventListener("touchend",Ua);document.getElementById("selectAllItems").addEventListener("click",function(){let B="true"!==this.dataset.checked;this.innerHTML=(this.dataset.checked=B)?'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <polyline points="20 6 9 17 4 12"></polyline>\n                    </svg>':
'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line> \n                    </svg>';li(B)});(function(){const B="true"===localStorage.getItem("resetExpiredItems"),H=localStorage.getItem("resetDays"),M=JSON.parse(localStorage.getItem("itemsToReset")||"[]"),O=JSON.parse(localStorage.getItem("itemsToReset2")||
"[]"),V=JSON.parse(localStorage.getItem("itemsToResetGuild")||"[]");document.getElementById("resetExpiredItems").checked=B;document.getElementById("resetDays").value=H;M.forEach(Z=>{if(Z=document.getElementById(Z))Z.checked=!0});O.forEach(Z=>{if(Z=document.getElementById(Z))Z.checked=!0});V.forEach(Z=>{if(Z=document.getElementById(Z))Z.checked=!0})})();const ee=document.getElementById("guildPackHour"),pg=localStorage.getItem("guildPackHour");pg&&(ee.value=pg);ee.addEventListener("change",()=>{localStorage.setItem("guildPackHour",
ee.value)});const fe=document.getElementById("filterGM"),qg=localStorage.getItem("filterGM");qg&&(fe.value=qg);fe.addEventListener("change",()=>{localStorage.setItem("filterGM",fe.value)});const sb=document.getElementById("delaySelect"),rg=localStorage.getItem("DELAY");if(rg)for(let B=0;B<sb.options.length;B++)if(sb.options[B].text===rg){sb.value=sb.options[B].value;break}sb.addEventListener("change",()=>{localStorage.setItem("DELAY",sb.options[sb.selectedIndex].text)});const ge=document.getElementById("questSpeed"),
sg=localStorage.getItem("questSpeed");sg&&(ge.value=sg);ge.addEventListener("change",()=>{localStorage.setItem("questSpeed",ge.value)});let tg=document.getElementById("itemToBuy"),ug=document.getElementById("rarity"),vg=document.getElementById("marketItemType"),wg=document.getElementById("itemsoulbound"),xg=document.getElementById("maxPrice"),Pi=document.getElementById("addItemBtn"),Qi=document.getElementById("removeItemBtn"),Ri=document.getElementById("MarketremoveItemBtn"),Wc=document.getElementById("itemList"),
Kf=document.getElementById("MarketboughtItems"),Ib=localStorage.getItem("MarketboughtItems");Ib?Ib=JSON.parse(Ib):Ib=[];const yg=document.getElementById("MarketSearchInterval");yg.addEventListener("change",()=>{localStorage.setItem("MarketSearchInterval",yg.value)});document.getElementById("MarketSearchInterval").addEventListener("input",function(){3>parseInt(this.value,10)&&(this.value=3)});const zg=document.getElementById("MarketMaxPerFoodPrice");zg.addEventListener("change",()=>{localStorage.setItem("MarketMaxPerFoodPrice",
zg.value)});const Ag=document.getElementById("MarketMaxFoodPrice");Ag.addEventListener("change",()=>{localStorage.setItem("MarketMaxFoodPrice",Ag.value)});const Bg=document.getElementById("MarketMinItemLevel");Bg.addEventListener("change",()=>{localStorage.setItem("MarketMinItemLevel",Bg.value)});let he=document.getElementById("marketOnlyFood");he.checked="true"===localStorage.getItem("marketOnlyFood");he.addEventListener("change",()=>{localStorage.setItem("marketOnlyFood",he.checked)});let kb=JSON.parse(localStorage.getItem("marketItems"))||
[];Pi.onclick=function(){kb.push({Vm:tg.value||1,am:ug.value||4,maxPrice:xg.value||4,itemType:vg.value||4,Soulbound:wg.value||2});tg.value="";ug.value="White";xg.value="";vg.value="WEAPONS";wg.value="DontBuySoulbound";Vc()};Qi.onclick=function(){kb.splice(Wc.value,1);Vc()};Ri.onclick=function(){document.getElementById("MarketboughtItems").innerHTML="";localStorage.setItem("MarketboughtItems",JSON.stringify([]))};Vc();let ie=document.getElementById("enableMarketSearch");ie.checked="true"===localStorage.getItem("enableMarketSearch");
ie.addEventListener("change",()=>{localStorage.setItem("enableMarketSearch",ie.checked)});let je=document.getElementById("usePacks");je.checked="true"===localStorage.getItem("usePacks");je.addEventListener("change",()=>{localStorage.setItem("usePacks",je.checked)});const ke=document.getElementById("scoreRange"),Cg=localStorage.getItem("scoreRange");Cg&&(ke.value=Cg);ke.addEventListener("change",()=>{localStorage.setItem("scoreRange",ke.value)});const le=document.getElementById("scoreRangeCircus"),
Dg=localStorage.getItem("scoreRangeCircus");Dg&&(le.value=Dg);le.addEventListener("change",()=>{localStorage.setItem("scoreRangeCircus",le.value)});let me=document.getElementById("scoreboardattackenable");me.checked="true"===localStorage.getItem("scoreboardattackenable");me.addEventListener("change",()=>{localStorage.setItem("scoreboardattackenable",me.checked)});let ne=document.getElementById("scoreboardcircusenable");ne.checked="true"===localStorage.getItem("scoreboardcircusenable");ne.addEventListener("change",
()=>{localStorage.setItem("scoreboardcircusenable",ne.checked)});let oe=document.getElementById("leagueattackenable");oe.checked="true"===localStorage.getItem("leagueattackenable");oe.addEventListener("change",()=>{localStorage.setItem("leagueattackenable",oe.checked)});let Mb=document.getElementById("leaguerandom");Mb.checked="true"===localStorage.getItem("leaguerandom");Mb.addEventListener("change",()=>{localStorage.setItem("leaguerandom",Mb.checked);Mb.checked&&(Nb.checked=!1,localStorage.setItem("leaguelowtohigh",
!1))});let Nb=document.getElementById("leaguelowtohigh");Nb.checked="true"===localStorage.getItem("leaguelowtohigh");Nb.addEventListener("change",()=>{localStorage.setItem("leaguelowtohigh",Nb.checked);Nb.checked&&(Mb.checked=!1,localStorage.setItem("leaguerandom",!1))});let pe=document.getElementById("leaguecircusattackenable");pe.checked="true"===localStorage.getItem("leaguecircusattackenable");pe.addEventListener("change",()=>{localStorage.setItem("leaguecircusattackenable",pe.checked)});let Ob=
document.getElementById("leaguecircusrandom");Ob.checked="true"===localStorage.getItem("leaguecircusrandom");Ob.addEventListener("change",()=>{localStorage.setItem("leaguecircusrandom",Ob.checked);Ob.checked&&(Pb.checked=!1,localStorage.setItem("leaguecircuslowtohigh",!1))});let Pb=document.getElementById("leaguecircuslowtohigh");Pb.checked="true"===localStorage.getItem("leaguecircuslowtohigh");Pb.addEventListener("change",()=>{localStorage.setItem("leaguecircuslowtohigh",Pb.checked);Pb.checked&&
(Ob.checked=!1,localStorage.setItem("leaguecircusrandom",!1))});let qe=document.getElementById("autoAddArena");qe.checked="true"===localStorage.getItem("autoAddArena");qe.addEventListener("change",()=>{localStorage.setItem("autoAddArena",qe.checked)});let re=document.getElementById("autoAvoidArena");re.checked="true"===localStorage.getItem("autoAvoidArena");re.addEventListener("change",()=>{localStorage.setItem("autoAvoidArena",re.checked)});const Eg=document.getElementById("autoAddArenaAmount");
Eg.addEventListener("change",()=>{localStorage.setItem("autoAddArenaAmount",Eg.value)});const Fg=document.getElementById("ArenaSimulatorAmount");Fg.addEventListener("change",()=>{localStorage.setItem("ArenaSimulatorAmount",Fg.value)});const Gg=document.getElementById("CircusSimulatorAmount");Gg.addEventListener("change",()=>{localStorage.setItem("CircusSimulatorAmount",Gg.value)});let se=document.getElementById("autoAddCircus");se.checked="true"===localStorage.getItem("autoAddCircus");se.addEventListener("change",
()=>{localStorage.setItem("autoAddCircus",se.checked)});let te=document.getElementById("autoAvoidCircus");te.checked="true"===localStorage.getItem("autoAvoidCircus");te.addEventListener("change",()=>{localStorage.setItem("autoAvoidCircus",te.checked)});const Hg=document.getElementById("autoAddCircusAmount");Hg.addEventListener("change",()=>{localStorage.setItem("autoAddCircusAmount",Hg.value)});let ue=document.getElementById("UnderWorldUseRuby");ue.checked="true"===localStorage.getItem("UnderWorldUseRuby");
ue.addEventListener("change",()=>{localStorage.setItem("UnderWorldUseRuby",ue.checked)});let ve=document.getElementById("useSacrifice");ve.checked="true"===localStorage.getItem("useSacrifice");ve.addEventListener("change",()=>{localStorage.setItem("useSacrifice",ve.checked)});let we=document.getElementById("usePray");we.checked="true"===localStorage.getItem("usePray");we.addEventListener("change",()=>{localStorage.setItem("usePray",we.checked)});let xe=document.getElementById("UnderworldUseMobi");
xe.checked="true"===localStorage.getItem("UnderworldUseMobi");xe.addEventListener("change",()=>{localStorage.setItem("UnderworldUseMobi",xe.checked)});let ye=document.getElementById("exitUnderworld");ye.checked="true"===localStorage.getItem("exitUnderworld");ye.addEventListener("change",()=>{localStorage.setItem("exitUnderworld",ye.checked)});let ze=document.getElementById("autoEnterHell");ze.checked="true"===localStorage.getItem("autoEnterHell");ze.addEventListener("change",()=>{localStorage.setItem("autoEnterHell",
ze.checked)});let Ae=document.getElementById("dontEnterUnderworld");Ae.checked="true"===localStorage.getItem("dontEnterUnderworld");Ae.addEventListener("change",()=>{localStorage.setItem("dontEnterUnderworld",Ae.checked)});let Be=document.getElementById("disableLogMenu");Be.checked="true"===localStorage.getItem("disableLogMenu");Be.addEventListener("change",()=>{localStorage.setItem("disableLogMenu",Be.checked)});let Ce=document.getElementById("disableBG");Ce.checked="true"===localStorage.getItem("disableBG");
Ce.addEventListener("change",()=>{localStorage.setItem("disableBG",Ce.checked)});let De=document.getElementById("MoveButtons");De.checked="true"===localStorage.getItem("MoveButtons");De.addEventListener("change",()=>{localStorage.setItem("MoveButtons",De.checked)});let Ee=document.getElementById("pauseBotEnable");Ee.checked="true"===localStorage.getItem("pauseBotEnable");Ee.addEventListener("change",()=>{localStorage.setItem("pauseBotEnable",Ee.checked)});const Ig=document.getElementById("pauseBot");
Ig.addEventListener("change",()=>{Y("pauseBot",Ig.value)});let Fe=document.getElementById("storeGoldinAuction");Fe.checked="true"===localStorage.getItem("storeGoldinAuction");Fe.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuction",Fe.checked)});const Jg=document.getElementById("storeGoldinAuctionmaxGold");Jg.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuctionmaxGold",Jg.value)});const Kg=document.getElementById("storeGoldinAuctionholdGold");Kg.addEventListener("change",
()=>{localStorage.setItem("storeGoldinAuctionholdGold",Kg.value)});const Lg=document.getElementById("TrainingHoldGold");Lg.addEventListener("change",()=>{localStorage.setItem("TrainingHoldGold",Lg.value)});const Mg=document.getElementById("MarketHoldGold");Mg.addEventListener("change",()=>{localStorage.setItem("MarketHoldGold",Mg.value)});const Ng=document.getElementById("KasaHoldGold");Ng.addEventListener("change",()=>{localStorage.setItem("KasaHoldGold",Ng.value)});let Ge=document.getElementById("guildBattleEnable");
Ge.checked="true"===localStorage.getItem("guildBattleEnable");Ge.addEventListener("change",()=>{localStorage.setItem("guildBattleEnable",Ge.checked)});let He=document.getElementById("guildBattleRandom");He.checked="true"===localStorage.getItem("guildBattleRandom");He.addEventListener("change",()=>{localStorage.setItem("guildBattleRandom",He.checked)});let Ie=document.getElementById("GuildEnable");Ie.checked="true"===localStorage.getItem("GuildEnable");Ie.addEventListener("change",()=>{localStorage.setItem("GuildEnable",
Ie.checked)});const Og=document.getElementById("GuildDonateAmount");Og.addEventListener("change",()=>{localStorage.setItem("GuildDonateAmount",Og.value)});const Pg=document.getElementById("GuildDonateMore");Pg.addEventListener("change",()=>{localStorage.setItem("GuildDonateMore",Pg.value)});const Qg=document.getElementById("GuildDonateLess");Qg.addEventListener("change",()=>{localStorage.setItem("GuildDonateLess",Qg.value)});document.getElementById("hellDifficulty").addEventListener("change",function(){localStorage.setItem("hellDifficulty",
this.value)});const Si=document.getElementById("hellDifficulty"),Rg=localStorage.getItem("hellDifficulty");null!==Rg&&(Si.value=Rg);let Je=document.getElementById("useVillaMedici");Je.checked="true"===localStorage.getItem("useVillaMedici");Je.addEventListener("change",()=>{localStorage.setItem("useVillaMedici",Je.checked)});let Ke=document.getElementById("useHealingPotion");Ke.checked="true"===localStorage.getItem("useHealingPotion");Ke.addEventListener("change",()=>{localStorage.setItem("useHealingPotion",
Ke.checked)});const Le=document.getElementById("repairMercenary");Le.checked="true"===localStorage.getItem("repairMercenary");Le.addEventListener("change",()=>{localStorage.setItem("repairMercenary",Le.checked)});const Me=document.getElementById("repairGladiator");Me.checked="true"===localStorage.getItem("repairGladiator");Me.addEventListener("change",()=>{localStorage.setItem("repairGladiator",Me.checked)});let Ne=document.getElementById("activateRepair");Ne.checked="true"===localStorage.getItem("activateRepair");
Ne.addEventListener("change",()=>{localStorage.setItem("activateRepair",Ne.checked)});const Ti=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(B=>{B.checked=Ti.includes(B.value)});document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(B=>{B.addEventListener("change",()=>{const H=[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(M=>{M.checked&&H.push(M.value)});
localStorage.setItem("ignoredMaterials",JSON.stringify(H))})});const Sg=document.querySelectorAll(".gladiator-inventory .inventory-item"),Tg=document.querySelectorAll(".mercenary-inventory .inventory-item"),Ug=JSON.parse(localStorage.getItem("activeItemsGladiator"))||{},Vg=JSON.parse(localStorage.getItem("activeItemsMercenary"))||{};Sg.forEach(B=>{Lf(B,Ug,"activeItemsGladiator")});Tg.forEach(B=>{Lf(B,Vg,"activeItemsMercenary")});Mf(Sg,Ug,"helmet necklace weapon armor shield gloves shoes rings1 rings2".split(" "),
"activeItemsGladiator");Mf(Tg,Vg,"helmetM necklaceM weaponM armorM shieldM glovesM shoesM rings1M rings2M".split(" "),"activeItemsMercenary");const Wg=document.getElementById("expeditionLocation");Wg.addEventListener("change",()=>{localStorage.setItem("expeditionLocation",Wg.value)});const Xg=document.getElementById("dungeonLocation");Xg.addEventListener("change",()=>{localStorage.setItem("dungeonLocation",Xg.value)});const wc=document.getElementById("autoCollectBonuses");wc.checked="true"===localStorage.getItem("autoCollectBonuses");
document.getElementById("enemySelection").style.display=wc.checked?"none":"block";wc.addEventListener("change",()=>{localStorage.setItem("autoCollectBonuses",wc.checked)});const Oe=document.getElementById("skipBossToggle");Oe.checked="true"===localStorage.getItem("skipBoss");Oe.addEventListener("change",()=>{localStorage.setItem("skipBoss",Oe.checked)});const Pe=document.getElementById("resetIfLoseToggle");Pe.checked="true"===localStorage.getItem("resetIfLose");Pe.addEventListener("change",()=>{localStorage.setItem("resetIfLose",
Pe.checked)});const Qe=document.getElementById("activateSmelt");Qe.checked="true"===localStorage.getItem("EnableSmelt");Qe.addEventListener("change",()=>{localStorage.setItem("EnableSmelt",Qe.checked)});const Re=document.getElementById("EnableHellLimit"),Yg=document.getElementById("hellLimit").closest(".setting-row"),Zg="true"===localStorage.getItem("EnableHellLimit"),$g=localStorage.getItem("hellLimit")||5;Re.checked=Zg;document.getElementById("hellLimit").value=$g;Yg.style.display=Zg?"block":"none";
Re.addEventListener("change",function(){const B=Re.checked;localStorage.setItem("EnableHellLimit",B);Yg.style.display=B?"block":"none"});document.getElementById("hellLimit").addEventListener("input",function(){const B=document.getElementById("hellLimit").value;1<=B&&200>=B?localStorage.setItem("hellLimit",B):document.getElementById("hellLimit").value=$g});const oc=document.getElementById("farmEnable"),mi=document.getElementById("farmLocation").closest(".setting-row"),ni=document.getElementById("farmEnemy").closest(".setting-row"),
Ui="true"===localStorage.getItem("farmEnable"),ah=localStorage.getItem("farmLocation"),bh=localStorage.getItem("farmEnemy");oc.checked=Ui;ah&&(document.getElementById("farmLocation").value=ah);bh&&(document.getElementById("farmEnemy").value=bh);Nf();oc.addEventListener("change",function(){localStorage.setItem("farmEnable",oc.checked);Nf()});document.getElementById("farmLocation").addEventListener("change",function(){localStorage.setItem("farmLocation",this.value)});document.getElementById("farmEnemy").addEventListener("change",
function(){localStorage.setItem("farmEnemy",this.value)});const Se=document.getElementById("doHeal");Se.checked="true"===localStorage.getItem("HealEnabled");Se.addEventListener("change",()=>{localStorage.setItem("HealEnabled",Se.checked)});const Te=document.getElementById("healShopToggle");Te.checked="true"===localStorage.getItem("HealShop");Te.addEventListener("change",()=>{localStorage.setItem("HealShop",Te.checked)});const Ue=document.getElementById("healfrompackage");Ue.checked="true"===localStorage.getItem("HealPackage");
Ue.addEventListener("change",()=>{localStorage.setItem("HealPackage",Ue.checked)});const Ve=document.getElementById("healcervisia");Ve.checked="true"===localStorage.getItem("HealCervisia");Ve.addEventListener("change",()=>{localStorage.setItem("HealCervisia",Ve.checked)});const We=document.getElementById("HealEggs");We.checked="true"===localStorage.getItem("HealEggs");We.addEventListener("change",()=>{localStorage.setItem("HealEggs",We.checked)});const Xe=document.getElementById("OilEnable");Xe.checked=
"true"===localStorage.getItem("OilEnable");Xe.addEventListener("change",()=>{localStorage.setItem("OilEnable",Xe.checked)});document.getElementById("enemySelect").addEventListener("change",function(){localStorage.setItem("selectedEnemy",this.value)});const Vi=document.getElementById("enemySelect"),ch=localStorage.getItem("selectedEnemy");null!==ch&&(Vi.value=ch);document.getElementById("autoCollectBonuses").addEventListener("change",function(){document.getElementById("enemySelection").style.display=
this.checked?"none":"block"});oi.addEventListener("change",function(){this.checked?(c(!0),Ba=!0):(c(!1),Ba=!1);localStorage.setItem("doExpedition",Ba);u()});pi.addEventListener("change",function(){this.checked?(h(!0),Ga=!0):(h(!1),Ga=!1);localStorage.setItem("doDungeon",Ga);u()});qi.addEventListener("change",function(){this.checked?(l(!0),Ha=!0):(l(!1),Ha=!1);localStorage.setItem("doArena",Ha);u()});document.getElementById("addAutoAttack").addEventListener("click",()=>{const B=document.getElementById("autoAttackInput").value.trim();
B&&fc(B,"autoAttackList","autoAttackList")});document.getElementById("addAvoidAttack").addEventListener("click",()=>{const B=document.getElementById("avoidAttackInput").value.trim();B&&fc(B,"avoidAttackList","avoidAttackList")});document.getElementById("addAutoCircusAttack").addEventListener("click",()=>{const B=document.getElementById("autoAttackCircusInput").value.trim();B&&fc(B,"autoAttackCircusList","autoAttackCircusList")});document.getElementById("addAvoidCircusAttack").addEventListener("click",
()=>{const B=document.getElementById("avoidAttackCircusInput").value.trim();B&&fc(B,"avoidAttackCircusList","avoidAttackCircusList")});fi();ri.addEventListener("change",function(){this.checked?(q(!0),Da=!0):(q(!1),Da=!1);localStorage.setItem("doCircus",Da);u()});si.addEventListener("change",function(){this.checked?(m(!0),La=!0):(m(!1),La=!1);localStorage.setItem("doQuests",La);u()});vi.addEventListener("change",function(){this.checked?(hb=!0,localStorage.setItem("doKasa",!0),hb=!0):(hb=!1,localStorage.setItem("doKasa",
!1),hb=!1);localStorage.setItem("doKasa",hb);u()});ui.addEventListener("change",function(){this.checked?(Za=!0,localStorage.setItem("AutoAuction",!0),Za=!0):(Za=!1,localStorage.setItem("AutoAuction",!1),Za=!1);localStorage.setItem("AutoAuction",Za);u()});ti.addEventListener("change",function(){this.checked?(r(!0),Ea=!0):(r(!1),Ea=!1);localStorage.setItem("doEventExpedition",Ea);u()});pc.addEventListener("input",()=>{let B=parseInt(pc.value,10);1>B?B=1:99<B&&(B=99);pc.value=B;localStorage.setItem("healPercentage",
B)});Of.addEventListener("input",()=>{localStorage.setItem("hellEnterHP",Of.value)});Pf.addEventListener("input",()=>{localStorage.setItem("HellHealHP",Pf.value)});Xc.addEventListener("change",()=>{localStorage.setItem("HealClothToggle",Xc.checked)});Yc.addEventListener("change",()=>{localStorage.setItem("HealRubyToggle",Yc.checked)});Zc.addEventListener("change",()=>{localStorage.setItem("storeResource",Zc.checked)});$c.addEventListener("change",()=>{localStorage.setItem("HighlightUnderworldItems",
$c.checked)});const Ye=document.querySelectorAll(".stat-checkbox"),Wi=localStorage.getItem("selectedStat");for(const B of Ye)B.checked=B.id===Wi;for(const B of Ye)B.addEventListener("change",()=>{if(B.checked){for(const H of Ye)H!==B&&(H.checked=!1);localStorage.setItem("selectedStat",B.id);localStorage.setItem("statID",B.getAttribute("data-skill"))}else localStorage.removeItem("selectedStat")})});$("#set_event_monster_id_0").click(function(){w("0")});$("#set_event_monster_id_1").click(function(){w("1")});
$("#set_event_monster_id_2").click(function(){w("2")});$("#set_event_monster_id_3").click(function(){w("3")});u()}async function Xi(){if("true"===localStorage.getItem("storeResource")){var b=new URL(window.location.href),c=b.origin;b=b.searchParams.get("sh")||"";const e=Date.now();c=`${c}/game/ajax.php?mod=forge&submod=storageIn`;const h=new FormData;h.append("inventory","1");h.append("packages","1");h.append("sell","1");h.append("a",e);h.append("sh",b);b=JSON.parse(localStorage.getItem("Timers"));
Y("storeForgeResources",b.StoreForge||60);try{(await fetch(c,{method:"POST",body:h})).ok?C(`${d.oe}`):window.location.reload()}catch(k){window.location.reload()}}}async function Yi(){var b=new URL(window.location.href),c=b.origin,e=b.searchParams.get("sh")||"";let h=JSON.parse(localStorage.getItem("statSettings"))||[];b=JSON.parse(localStorage.getItem("Timers"));const k=h.every(u=>1>parseInt(u.count,10));h.every(u=>"None"===u.priority);localStorage.getItem("selectedStat");const g={Strength:1,Dexterity:2,
Agility:3,Constitution:4,Charisma:5,Intelligence:6};h.sort((u,t)=>"None"===u.priority?1:"None"===t.priority?-1:parseInt(u.priority,10)-parseInt(t.priority,10));for(const {stat:u,count:t,priority:A}of h){if(1>t||"None"===A)continue;var l="true"===localStorage.getItem("trainPickGold");const z=g[u];var q=await (await fetch(`${c}/game/index.php?mod=training&sh=${e}`)).text();q=(new DOMParser).parseFromString(q,"text/html").querySelectorAll("#training_box .training_button");var m=void 0;0==q.length&&(Y("Training",
b.Training||2),location.reload());for(var n of q)if(q=n.getAttribute("href").match(/skillToTrain=(\d+)/)[1],Number(q)===z&&(q=n.closest(".training_link").querySelector(".training_costs"))){m=parseInt(q.textContent.trim().replace(".",""),10);break}q=parseInt(localStorage.getItem("TrainingHoldGold"),10)||0;if(aa.gold>=m+q){fetch(`${c}/game/index.php?mod=training&submod=train&skillToTrain=${z}&sh=${e}`);for(var r of h)if(r.stat===u){--r.count;0>r.count&&(r.count=0);break}localStorage.setItem("statSettings",
JSON.stringify(h));C(`Trained ${u} for ${m} gold`);Y("Training",b.Training||2);location.reload();return}if(l){l=await jQuery.get(G({mod:"packages",f:14,fq:-1,qry:"",page:1,sh:U("sh")}));let y=!1;jQuery(l).find(".packageItem").each(function(x,v){if(jQuery(v).find(".ui-draggable").attr("data-basis"))return y=!0,!1});if(y)try{await ic(1,1,async(x,v)=>{const D=selectedBuff.find('input[name="packages[]"]').val(),E=selectedBuff.find(".ui-draggable").attr("data-position-x"),I=selectedBuff.find(".ui-draggable").attr("data-position-y");
await jQuery.post(S({mod:"inventory",submod:"move",from:"-"+D,fromX:E,fromY:I,to:v,toX:x.x+1,toY:x.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:U("sh")}));C(`${d.ek}`);window.location.reload()})}catch(x){C(`${d.Lp}`)}}}if(k){if(m=new URL(window.location.href),c=m.origin,m=m.searchParams.get("sh")||"",n=localStorage.getItem("selectedStat"),r=localStorage.getItem("statID"),n){e=await (await fetch(`${c}/game/index.php?mod=training&sh=${m}`)).text();e=(new DOMParser).parseFromString(e,"text/html").querySelectorAll("#training_box .training_button");
let u;for(var w of e)if(w.getAttribute("href").match(/skillToTrain=(\d+)/)[1]===r&&(e=w.closest(".training_link").querySelector(".training_costs"))){u=parseInt(e.textContent.trim().replace(".",""),10);break}w=parseInt(localStorage.getItem("TrainingHoldGold"),10)||0;aa.gold>=u+w&&(await fetch(`${c}/game/index.php?mod=training&submod=train&skillToTrain=${r}&sh=${m}`),C(`Trained ${n} for ${u} gold`),Y("Training",b.Training||2),location.reload())}}else Y("Training",b.Training||2),location.reload()}function Zi(){const b=
JSON.parse(localStorage.getItem("statSettings"));for(let c=0;c<b.length;c++)if("0"!==b[c].count||b[c].Mm)return!0;return!1}function $i(){var b=new URL(window.location.href),c=localStorage.getItem("scoreboardattackenable"),e=localStorage.getItem("scoreboardcircusenable");if(document.querySelector(".reportWin")){var h=document.querySelector(".report_reward");h&&(h=h.querySelector('img[src*="71e68d38f81ee6f96a618f33c672e0.gif"]'))&&(h=h.previousSibling)&&h.nodeType===Node.TEXT_NODE&&(h=h.textContent.trim().match(/(\d+(?:\.\d+)?)/))&&
(h=parseFloat(h[1]),b.href.includes("&t=2")?Q("arenaMoney",h):b.href.includes("&t=3")&&Q("circusMoney",h))}if(b.href.includes("submod=showCombatReport")&&b.href.includes("&t=1"))(c=document.getElementById("reportHeader"))&&(c.classList.contains("reportWin")||"true"!==sessionStorage.getItem("autoGoActive")?localStorage.setItem("loose","false"):localStorage.setItem("loose","true"));else if(b.href.includes("submod=showCombatReport")){let l=document.querySelector("p > a + img");var k=document.querySelector("#defenderAvatar11 .playername_achievement");
null===k&&(k=document.querySelector("#defenderAvatar11 .playername.ellipsis "));(h=document.getElementById("reportHeader"))&&!h.classList.contains("reportWin")&&(localStorage.setItem("nextQuestTime.timeOut",0),localStorage.setItem("nextQuestTime",0));h=0;if(k&&(k=k.innerText.trim(),!k.includes("#"))){try{var g=l.previousSibling.nodeValue.trim();g=g.split(" ").pop();g=g.replace(".","");g=g.replace(",",".");h=parseFloat(g)}catch(q){}b.href.includes("&t=2")?(e=document.getElementById("reportHeader").classList.contains("reportWin"),
b=JSON.parse(localStorage.getItem("tempOpponentDetails")),g=Af.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidArena")||e||lb("avoidAttackList",k),"true"===localStorage.getItem("autoAddArena")&&Number(h)>=Number(localStorage.getItem("autoAddArenaAmount"))&&b&&b.serverId&&(g===b.serverId?(lb("autoAttackList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===c&&k!=b.playerName?lb("autoAttackList",k):g!==b.serverId&&lb("autoAttackServerList",b))):b.href.includes("&t=3")&&
(c=document.getElementById("reportHeader").classList.contains("reportWin"),b=JSON.parse(localStorage.getItem("tempOpponentDetails")),g=Af.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidCircus")||c||lb("avoidAttackCircusList",k),"true"===localStorage.getItem("autoAddCircus")&&h>=Number(localStorage.getItem("autoAddCircusAmount"))&&b&&b.serverId&&(g===b.serverId?(lb("autoAttackCircusList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===e&&k!=b.playerName?lb("autoAttackCircusList",
k):g!==b.serverId&&lb("autoAttackCircusServerList",b)))}}}function lb(b,c){let e=JSON.parse(localStorage.getItem(b))||[];if("object"===typeof c&&null!==c){let h=c.playerName;e.some(k=>k.playerName===h&&k.serverId===c.serverId)||e.push(c)}else"string"===typeof c&&(e.includes(c)||e.push(c));localStorage.setItem(b,JSON.stringify(e))}async function dh(b){var c=new URL(window.location.href),e=c.origin,h=c.searchParams;c=localStorage.getItem("AuctionItemLevel2")||"";const k=h.get("itemType")||"",g=localStorage.getItem("SearchQuality")||
"";h=h.get("sh")||"";e=new URL(`${e}/game/index.php?mod=auction&qry=&itemLevel=${c}&itemType=${k}&itemQuality=${g}&sh=${h}`);e.searchParams.set("mod","auction");e.searchParams.set("itemLevel",c);e.searchParams.set("itemType",k);e.searchParams.set("itemQuality",g);e.searchParams.set("sh",h);b&&e.searchParams.set("ttype",b);b=await (await fetch(e.href)).text();return(new DOMParser).parseFromString(b,"text/html")}async function Hf(){var b=new URL(window.location.href);const c=b.origin,e=b.searchParams.get("sh")||
"";b=Array.from({length:5},(k,g)=>[new URL(`${c}/game/index.php?mod=inventory&sub=${g+1}&subsub=0&sh=${e}`),new URL(`${c}/game/index.php?mod=inventory&sub=${g+1}&subsub=1&sh=${e}`)]).flat();const h=async k=>{var g=await (await fetch(k.href)).text();g=(new DOMParser).parseFromString(g,"text/html");g.zm=k.href;return g};return await Promise.all(b.map(k=>h(k)))}function Ze(b){return JSON.parse(b.replace(/&quot;/g,'"'))[0][0][0]}async function aj(b){b=(new TextEncoder).encode(b.toString());b=await crypto.subtle.digest("SHA-256",
b);return Array.from(new Uint8Array(b)).map(c=>c.toString(16).padStart(2,"0")).join("")}function gb(){(function(b){const c=setInterval(()=>{const e=document.getElementById("mainmenu");e&&(clearInterval(c),b(e))},500)})(b=>{if(!document.querySelector(".customButtonm")){var c=document.createElement("button");c.className="customButtonm";c.innerHTML='\n            <style>\n            .customButtonm {\n                vertical-align: middle;\n                width: 179px;\n                height: 50px;\n                background-image: linear-gradient(135deg, #f29b20 0%, #b18026 100%);\n                border: 2px solid #000;\n                color: white;\n                text-align: center;\n                text-decoration: none;\n                border-radius: 5px;\n                display: inline-block;\n                font-size: 16px;\n                margin: 4px auto;\n                cursor: pointer;\n                box-shadow: 5px 2px 5px rgba(0, 0, 0, 0.3), inset 0 1px 1px rgba(255, 255, 255, 0.4), inset 0 -1px 1px rgba(0, 0, 0, 0.3);\n                padding: 18px 34px;\n                transition-duration: 0.4s;\n            }\n        \n            .customButtonm span {\n                top: 50%;\n                position: relative;\n                transform: translateY(-50%);\n                display: block;\n                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);\n            }\n            </style>\n\n            <span class="span-new">License expired or Server Error. Check Discord</span>\n\n        ';
b.insertBefore(c,b.children[0]);Ef(45E3)}});return!1}async function bj(b,c,e){function h(k){const g=[];for(let l=0;l<k.length;l+=2)g.push(parseInt(k.substr(l,2),16));return new Uint8Array(g)}try{if(!e)return!1;const [k,g]=e.split(":"),l=h(k),q=h(g);if(b!==wa)return!1;const m=await window.crypto.subtle.importKey(String.fromCharCode(114,97,119),h("46d9ef519c1474cf8699ba24ab2a726a"),{name:String.fromCharCode(65,69,83)+"-CBC"},!1,[String.fromCharCode(100,101,99,114,121,112,116)]),n=await window.crypto.subtle.decrypt({name:String.fromCharCode(65,
69,83)+"-CBC",iv:l},m,q),r=(new TextDecoder).decode(new Uint8Array(n)),w=new Date(r);w.setHours(0,0,0,0);if(!0!==c)return!1;const u=new Date,t=new Date(u.setMonth(u.getMonth()+13));return w>t||r<u?!1:!0}catch{throw gb(),Error("supportDev");}}function xc(b){return 36E5*Number(b.split(":")[0])+6E4*Number(b.split(":")[1])+1E3*Number(b.split(":")[2])}function cj(){function b(g,l){tb?alert("A repair process is already running."):(k.en=l,jQuery(".gladbot-worbench-button").addClass("disabled"),k.u(),k.dn=
[],k.queue=0,jQuery(document.body).addClass("workbench-cursor"),jQuery(document.body).on("contextmenu",function(q){q.preventDefault();jQuery(document.body).removeClass("workbench-cursor");jQuery(document.body).off("contextmenu")}),jQuery("#inv .ui-draggable, #char .ui-draggable").mouseup(async q=>{q=q.target;var m=q.className.match(/item-i-(\d+)-\d+/)[1],n=document.querySelector(".charmercsel.active").getAttribute("onclick").toString().match(/doll=(\d+)/),r=k.freeSlots.shift()["forge_slots.slot"];
n=n[1];r={item:{type:m,name:Xb(q),quality:pb(q),slot:r,container:q.getAttribute("data-container-number"),doll:n},spot:{bag:q.getAttribute("data-container-number"),x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")}};localStorage.setItem("workbench_itemList1",JSON.stringify(r));if(jQuery(q).parents("#char").length)if(tb)alert("A repair process is already running.");else{if(m=document.querySelector("#inventory_nav .awesome-tabs.current"))m=m.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",
m);var {spot:w,bag:u}=await ic(2,3);k.xa={bag:u,x:w.x+1,y:w.y+1};k.ln(q);k.ym(q,0,n);tb=!0}else if(jQuery(q).parents("#inv").length){if(n=document.querySelector("#inventory_nav .awesome-tabs.current"))n=n.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",n);k.xa={bag:q.getAttribute("data-container-number"),x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")};tb?alert("A repair process is already running."):(k.ln(q),q=q.getAttribute("data-item-id"),k.Ki(q),
tb=!0)}else k.queue++,k.oo(q),k.Dm(m)}))}function c(g,l,q){l=jQuery("<button>").html(l).addClass(q);jQuery(g).append(l);return l}async function e(){try{const g=await jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:U("sh")});k.slots=JSON.parse(g).slots;k.spaces=k.slots.filter(l=>"closed"===l["forge_slots.state"]).length;k.freeSlots=k.slots.filter(l=>"closed"===l["forge_slots.state"])}catch(g){}}async function h(){try{const g=U("sh"),l=document.querySelectorAll("#inv .ui-draggable"),
q=[512,256,2,8,4,1,1024,48];let m=5;mb("Sending items to packages...");await e();if(0<k.spaces){for(let n of k.slots)if("closed"===n["forge_slots.state"]){m=n["forge_slots.slot"];break}for(let n of l){const r=parseInt(n.getAttribute("data-content-type"),10);if(q.includes(r)){const w=n.getAttribute("data-item-id"),u=Xb(n),t=parseInt(n.getAttribute("data-amount"),10)||1,A={mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:m,iid:w,amount:t,a:Date.now(),sh:g};await jQuery.post(S({}),A);const z=
{mod:"forge",submod:"rent",mode:"workbench",slot:m,rent:2,item:w,a:Date.now(),sh:g};await jQuery.post(S({}),z);const y={mod:"forge",submod:"cancel",mode:"workbench",slot:m,a:Date.now(),sh:g};await jQuery.post(S({}),y);mb(`Item name : ${u} has been sent to the packages.`);await new Promise(x=>setTimeout(x,500))}}window.location.reload()}else mb("No available slots in the workbench.")}catch(g){}}const k={en:"full",async start(){let {itemList1:g,itemList2:l,repairArena:q,repairTurma:m}=sa,n=sa.selectedItem;
n?this.u(()=>{switch(n.status){case "toWorkbench":k.Ki(n.iid);break;case "toFillGoods":k.ec(n.slot);break;case "toPackage":k.mc(n.slot);break;case "toBag":k.La();break;case "toInv":k.Pl()}}):q&&0<g.length?"mod=overview&doll=1"!=nf?zh("mod=overview&doll=1"):this.u(()=>{0<k.spaces&&this.$l(sa.itemList1)}):m&&0<l.length&&("mod=overview&doll=2"!=nf?zh("mod=overview&doll=2"):this.u(()=>{0<k.spaces&&this.$l(sa.itemList2)}))},u(g=!1){jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",
a:(new Date).getTime(),sh:U("sh")},l=>{k.slots=JSON.parse(l).slots;k.spaces=0;k.freeSlots=[];for(let q of k.slots)"closed"==q["forge_slots.state"]&&(k.spaces++,k.freeSlots.push(q));g&&g()})},$l(g){let l=g.shift();ic(l.Wm,l.Xm,(q,m)=>{jQuery.post(S({mod:"inventory",submod:"move",from:l.container,fromX:1,fromY:1,to:m,toX:q.x+1,toY:q.y+1,amount:1,doll:l.doll}),{a:(new Date).getTime(),sh:U("sh")},n=>{let r={item:l,iid:JSON.parse(n).to.data.itemId,status:"toWorkbench",spot:q,bag:m};localStorage.setItem("workbench_selectedItem",
JSON.stringify(r));this.Ki(JSON.parse(n).to.data.itemId)})})},async ym(g,l=0,q){var m=[512,513,514,515];if(!(l>=m.length)){m=m[l];var n=document.getElementById("inv");if(n=lf(n))try{const w=await jQuery.post(S({mod:"inventory",submod:"move",from:g.getAttribute("data-container-number"),fromX:1,fromY:1,to:m,toX:n.x+1,toY:n.y+1,amount:1,doll:q}),{a:(new Date).getTime(),sh:U("sh")}),u=JSON.parse(w);if(u.error)this.ym(g,l+1,q);else{var r={item:g,iid:u.to.data.itemId,status:"toWorkbench",spot:n,bag:m};
localStorage.setItem("workbench_selectedItem",JSON.stringify(r));localStorage.setItem("workbench_itemBag",JSON.stringify(r.bag));await this.Ki(u.to.data.itemId)}}catch(w){}else this.ym(g,l+1)}},async Ki(g){dj();C(`${d.Ab}`);let l=5;for(let q of k.slots)"closed"==q["forge_slots.state"]&&(l=q["forge_slots.slot"]);jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:l,iid:g,amount:1,a:(new Date).getTime(),sh:U("sh")},q=>{k.needed=JSON.parse(q).slots[l].formula.needed;Bh().gold>
JSON.parse(q).slots[l].formula.rent[2]?jQuery.post(S({}),{mod:"forge",submod:"rent",mode:"workbench",slot:l,rent:2,item:g,a:(new Date).getTime(),sh:U("sh")},()=>{"full"==k.en?(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:l,status:"toFillGoods"})),k.ec(l)):(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:l,status:"toFillPartial"})),k.Jh(l))}):mb("Not enough gold to rent the workbench")})},ec(g,l=-1,q=!0){C(`${d.ze}`,l);jQuery.post(S({}),{mod:"forge",submod:"storageToWarehouse",
mode:"workbench",slot:g,quality:l,a:(new Date).getTime(),sh:U("sh")},()=>{l<Number(localStorage.getItem("repairMaxQuality"))?k.ec(g,++l,q):jQuery.post(S({}),{mod:"forge",submod:"start",mode:"workbench",slot:g,a:(new Date).getTime(),sh:U("sh")},()=>{q?(localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"})),k.u(()=>{k.mc(g)})):(k.queue--,0==k.queue&&window.location.reload())})})},mc(g){let l=1E3*k.slots[g].formula.duration||1E4;C(`${d.Me}`,l);1==k.cancel?this.u(()=>{setTimeout(()=>
{jQuery.post(S({}),{mod:"forge",submod:"cancel",mode:"workbench",slot:g,a:(new Date).getTime(),sh:U("sh")},q=>{if("document.location.href=document.location.href;"==q)return window.location.reload();localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));k.La()})},l)}):this.u(()=>{setTimeout(()=>{jQuery.post(S({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:g,a:(new Date).getTime(),sh:U("sh")},q=>{if("document.location.href=document.location.href;"==q)return window.location.reload();
localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));k.La()})},l)})},async La(g=1){var l=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");({item:l}=l);let q=!1;var m=new URL(window.location.href),n=m.origin;m=m.searchParams.get("sh")||"";n=new URL(`${n}/game/index.php?mod=packages&qry=&f=${l.type}&page=${g}&sh=${m}`);n.searchParams.set("mod","packages");n.searchParams.set("f",l.type);n.searchParams.set("page",g);n.searchParams.set("sh",
m);n=await (await fetch(n.href)).text();n=(new DOMParser).parseFromString(n,"text/html");var r=n.querySelector(".ui-draggable");m=vb(r);pb(r);r=Xb(r);l.name==r&&l.type==m&&(q=!0,jQuery.post(S({mod:"inventory",submod:"move",from:n.querySelector("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:k.xa.bag,toX:k.xa.x,toY:k.xa.y,amount:1}),{a:(new Date).getTime(),sh:U("sh")},()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));k.Pl()}));
q||this.La(++g)},Pl(){JSON.parse(localStorage.getItem("workbench_selectedItem"));var g=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");({item:g}=g);jQuery.post(S({mod:"inventory",submod:"move",from:k.xa.bag,fromX:k.xa.x,fromY:k.xa.y,to:g.container,toX:1,toY:1,amount:1,doll:g.doll}),{a:(new Date).getTime(),sh:U("sh")},()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));C(`${d.Ce}`);tb=!1;window.location.reload()})},
an(g){g=jQuery(g);g=jQuery("<div>").addClass("gbot-overlay").width(g.width()).height(g.height()).offset(g.offset()).append(jQuery('<div class="gbot-spinner"></div>'));jQuery(document.body).append(g)},gm(g,l,q){l=jQuery("<button>").html(l).addClass(q);jQuery(g).append(l);return l},Gp(){let g=0;for(let l of k.slots)"finished-succeeded"==l["forge_slots.state"]&&(g++,jQuery.post(S({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:l["forge_slots.slot"],a:(new Date).getTime(),sh:U("sh")},q=>{g--;
if("document.location.href=document.location.href;"==q||0==g)return window.location.reload()}))},oo(g){Zb(g)&&(k.an(g),k.dn.push(g))},ln(g){Zb(g)&&k.an(g)},Dm(g,l,q){let m=k.freeSlots.shift()["forge_slots.slot"],n=k.dn.shift(),r=null!==l?l:n.getAttribute("data-item-id"),w=null!==q?q:{bag:n.getAttribute("data-container-number"),x:n.getAttribute("data-position-x"),y:n.getAttribute("data-position-y")};jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:m,iid:r,amount:1,
a:(new Date).getTime(),sh:U("sh")},u=>{let t=JSON.parse(u).slots[m].formula.needed;Bh().gold>JSON.parse(u).slots[m].formula.rent[2]&&jQuery.post(S({}),{mod:"forge",submod:"rent",mode:"workbench",slot:m,rent:2,item:r,a:(new Date).getTime(),sh:U("sh")},()=>{"full"==g?k.ec(m,w,!0):"partial"==g&&k.Jh(m,w,t)})})},Jh(g,l,q){let m=[];q=k.needed;for(let n in q)0<q[n].amount&&m.push(n-18E3);k.rl(m,(n,r)=>{n&&r?k.sl(l,n,r,w=>{w||console.warn("pickMaterialFromPack did not return an iid. Skipping material picking.");
jQuery.post(S({}),{mod:"forge",submod:"toWarehouse",mode:"workbench",slot:g,iid:w||"defaultIid",amount:1,a:(new Date).getTime(),sh:U("sh")},()=>{jQuery.post(S({}),{mod:"forge",submod:"start",mode:"workbench",slot:g,a:(new Date).getTime(),sh:U("sh")},()=>{k.queue--;localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"}));k.u(()=>{k.mc(g)});0==k.queue&&window.location.reload()})})}):(k.cancel=!0,k.u(()=>{k.mc(g)}))})},rl(g,l=!1,q=0,m=-1){if(q==g.length)if(1>m)q=0,m++;else return l&&
l(null,null);jQuery.post(S({mod:"forge",submod:"storageOut"}),{type:g[q],quality:m,amount:1,a:(new Date).getTime(),sh:U("sh")}).done(()=>l&&l(g[q],m)).fail(()=>k.rl(g,l,++q,m))},sl(g,l,q,m=!1,n=1){let r=!1;jQuery.get(G({mod:"packages",f:18,fq:q,qry:"",page:1,sh:U("sh")}),w=>{jQuery(w).find(".packageItem").each((u,t)=>{var A=jQuery(t).find(".ui-draggable");u=A.context.querySelector("input").getAttribute("value");t=wb(A[0]).split("-")[1];A=pb(A[0]);l==t&&q==A&&(r=!0,jQuery.post(S({mod:"inventory",submod:"move",
from:"-"+u,fromX:1,fromY:1,to:k.xa.bag,toX:k.xa.x,toY:k.xa.y,amount:1}),{a:(new Date).getTime(),sh:U("sh")},z=>{m&&m(JSON.parse(z).to.data.itemId)}))});r||k.sl(g,l,q,m,++n)})}};jQuery("#inv").after('\n              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n    \n                <fieldset id="gladbot-workbench" style="\n                  padding: 10px;\n                  margin: 10px 20px;\n                  text-align: center;\n                  display: flex;\n                  flex-direction: row;\n                  flex-wrap: wrap;\n                  align-items: center;\n                  justify-content: space-around;\n                  border: 2px solid darkred;\n                  border-radius: 8px;\n                  width: 235px;">\n                  <legend style="\n                    padding: 0 10px;\n                    color: darkred;\n                    font-weight: bold;">GLDbot Workbench Area</legend>\n                    <span class="span-new">Make sure last workbench slot is available, and make sure there\'s 3x3 space available. Repair only works for the equipments on the character. If you dont see the inventory, install Crazy-Addon.</span>\n                </fieldset>');
c("#gladbot-workbench",'<i class="fa fa-wrench"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for full repair. You can only repair one item at a time.").mouseup(g=>{b(g,"full")});c("#gladbot-workbench",'<i class="fa fa-hammer"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for partial repair. You can only repair one item at a time.").mouseup(g=>{b(g,"partial")});c("#gladbot-workbench",'<i class="fa fa-undo"></i>',
"gladbot-button gladbot-worbench-button-reset gladbot-stylish-button").attr("title","If an item is stuck and not repairing, click this button to reset.").mouseup(()=>{tb=!1});c("#gladbot-workbench","Send items in the current inventory to packages","gladbot-button gladbot-inventory-send-button gladbot-stylish-button").attr("title","Click this button to send items from the current inventory to packages.").mouseup(async()=>{await h()})}function mb(b){const c=document.createElement("div");c.className=
"notification-popup";c.innerText=b;c.style.position="fixed";c.style.bottom="20px";c.style.right="20px";c.style.padding="10px 20px";c.style.backgroundColor="rgba(0, 0, 0, 0.8)";c.style.color="white";c.style.borderRadius="5px";c.style.fontSize="14px";c.style.zIndex="9999";document.body.appendChild(c);setTimeout(()=>{c.remove()},3E3)}function eh(b,c,e,h,k,g){const l=document.createElement("span");l.className=c;l.innerHTML=b;l.title=g;l.style.cursor=e;l.style.fontSize=h;l.style.top="70px";l.style.position=
"absolute";l.style.right=k;return l}function fh(b,c){try{var e=JSON.parse(b.replace(/&quot;/g,'"'))}catch(l){return{}}b=e[0]?e[0][0]:null;e=b[0];e="string"!==typeof e?"":e.split(" ")[0];const h=ac(b[0]),k=c.getAttribute("data-quality"),g=c.getAttribute("data-content-type");c=c.getAttribute("data-level");return{itemName:b,Tm:e,Um:h,itemColor:{"-1":"white",0:"green",1:"blue",2:"purple",3:"orange",4:"red"}[k]||"white",itemType:g,itemLevel:c}}function ej(b,c,e,h){let k=JSON.parse(localStorage.getItem("auctionPrefixes"))||
[],g=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];k.includes(b)||(k.push(b),localStorage.setItem("auctionPrefixes",JSON.stringify(k)));g.includes(c)||(g.push(c),localStorage.setItem("auctionSuffixes",JSON.stringify(g)));mb(`Item "${e[0]}" added to the auction list!`);h.innerHTML="\u2705";setTimeout(()=>{h.innerHTML="\ud83d\udd28"},1E3)}function fj(b,c,e,h,k,g,l){c={condition:"nameContains",prefix:c,suffix:e,colors:[h],itemTypes:[k],hammerState:"none",level:g||1,enabled:!0};e=JSON.parse(localStorage.getItem("smeltingSettings"))||
[];e.push(c);localStorage.setItem("smeltingSettings",JSON.stringify(e));mb(`Item "${b[0]}" added to the smelting list!`);l.innerHTML="\u2705";setTimeout(()=>{l.innerHTML="\ud83d\udd25"},1E3)}async function dj(){const b=G({mod:"packages",submod:"sort",page:"1",sh:U("sh")});return await jQuery.post(b,{packageSorting:"in_desc"})}async function gj(){var b=localStorage.getItem("PackageSort")||"in_desc",c=await ha.Xl();let e=[];var h=Math.min(10,c);if("del_asc"===b||"in_asc"===b)for(c=1;c<=h;c++)e.push(c);
else for(b=c;b>c-h;b--)e.push(b);h=[];for(const k of e)try{const g=await jQuery.get(G({mod:"packages",f:"0",fq:"-1",qry:"",page:k.toString(),sh:U("sh")}));h.push(g)}catch(g){C(`Error fetching pages ${k}: ${g.message}`)}return h.flat()}async function hj(b,c){if("mod=guildMarket"!=nf)zh("mod=guildMarket");else{C(`${d.he}`);var e={TOOLS:["2097152","1048576","8388608","4194304"],WEAPONS:["2"],SHIELD:["4"],CHEST:["8"],HELMET:["1"],GLOVES:["256"],SHOES:["512"],RINGS:["48"],AMULETS:["1024"],USABLES:["4096",
"32768"],FOOD:["64"],UPGRADES:["4096"],RECIPES:["8192"],MERCENARY:["16384"],SCROLLS:["64"],REINFORCEMENTS:["4096"]},h=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]},k=(await gj()).map(w=>jQuery(w).find(".packageItem").toArray()).flat();b=24*b;var g=!1;for(const w of k){k=w.querySelector("span[data-ticker-type]");if(!k)continue;k=k.getAttribute("data-ticker-time-left");if(!k)continue;k=k/1E3/60/60;var l=w.querySelector("div[data-content-type]");const u=l?l.getAttribute("data-content-type"):
null;l=(l=w.querySelector(".ui-draggable"))?l.getAttribute("data-basis"):null;if(("64"!==u||!l||c.includes("SCROLLS")&&l.startsWith("20")||c.includes("FOOD")&&l.startsWith("7")||c.includes("REINFORCEMENTS")&&l.startsWith("11"))&&k<=b&&c.some(t=>e[t].includes(u))){l=w.querySelector("div[data-container-number]");var q=w.querySelector("div[data-amount]");k=q?q.getAttribute("data-amount"):null;q=q?q.getAttribute("data-quality"):null;if(!(null!==q&&0<h.colors.length)||h.colors.includes(q)){l=l?l.getAttribute("data-container-number"):
null;q=w.querySelector("div[data-measurement-x]").getAttribute("data-measurement-x");var m=w.querySelector("div[data-measurement-y]").getAttribute("data-measurement-y");g=w.querySelector("div[data-tooltip]").getAttribute("data-tooltip");var n=Ze(g);g=!0;await ij(w,l,n,k,q,m);k=U("sh");k=`${window.location.origin}/game/index.php?mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=p&p=1&&sh=${k}`;l=await (await fetch(k)).text();l=(new DOMParser).parseFromString(l,"text/html").querySelectorAll("#market_table tr");
if((q=document.querySelector('input[type="submit"][name="anbieten"][value="Offer"]'))&&q.disabled)k=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",k.ResetExpired||10),C(`${d.pe}`);else for(q=1;q<l.length;q++){var r=l[q];m=r.querySelectorAll("td")[2];n=r.querySelector('input[name="cancel"]');r=(r=r.querySelector("div[data-item-id]"))?r.getAttribute("data-item-id"):null;n&&Number(m.textContent.replace(/\./g,""))===Number(gh)&&(await fetch(k,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
body:new URLSearchParams({buyid:r,qry:"",seller:"",f:0,fl:0,fq:-1,s:"",p:1,cancel:"Cancel"})}),C(`${d.ie}`),Q("itemReset",0))}}}}if(!g||g)c=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",c.ResetExpired||10),window.location.reload()}}async function ij(b,c,e,h,k,g){let {spot:l,bag:q}=await ic(k,g);try{const m=await jQuery.post(S({mod:"inventory",submod:"move",from:c,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+1,amount:h}),{a:(new Date).getTime(),sh:U("sh")});if(m){const n=Math.floor(41*Math.random())+
10;gh=n;const r=JSON.parse(m).to.data.itemId;await jj(c,n,r)}}catch(m){C(`${d.je}`),b=JSON.parse(localStorage.getItem("Timers")),Y("resetExpired",b.ResetExpired||10),window.location.reload()}}async function jj(b,c,e){await jQuery.post(G({mod:"guildMarket",sh:U("sh")}),{sellid:e,preis:c,dauer:1,sell_mode:0,anbieten:"Offer"})}async function kj(){if(!1!==JSON.parse(localStorage.getItem("underworld")||"{}").isUnderworld||"true"!==localStorage.getItem("BuffUnderworldOnly")){"mod=overview&doll=1"!=nf&&
zh("mod=overview&doll=1");var b={"11-23":{type:"Health",item:"Gingko"},"11-22":{type:"Health",item:"Taigaroot"},"11-21":{type:"Health",item:"Hawthorn"},"11-1":{type:"Strength",item:"Flask"},"11-2":{type:"Strength",item:"Ampulla"},"11-3":{type:"Strength",item:"Flacon"},"11-4":{type:"Strength",item:"Bottle"},"11-13":{type:"Constitution",item:"Flask"},"11-14":{type:"Constitution",item:"Ampulla"},"11-15":{type:"Constitution",item:"Flacon"},"11-16":{type:"Constitution",item:"Bottle"},"11-9":{type:"Agility",
item:"Flask"},"11-10":{type:"Agility",item:"Ampulla"},"11-11":{type:"Agility",item:"Flacon"},"11-12":{type:"Agility",item:"Bottle"},"11-17":{type:"Charisma",item:"Flask"},"11-18":{type:"Charisma",item:"Ampulla"},"11-19":{type:"Charisma",item:"Flacon"},"11-20":{type:"Charisma",item:"Bottle"},"11-24":{type:"Intelligence",item:"Flask"},"11-25":{type:"Intelligence",item:"Ampulla"},"11-26":{type:"Intelligence",item:"Flacon"},"11-27":{type:"Intelligence",item:"Bottle"},"11-5":{type:"Dexterity",item:"Flask"},
"11-6":{type:"Dexterity",item:"Ampulla"},"11-7":{type:"Dexterity",item:"Flacon"},"11-8":{type:"Dexterity",item:"Bottle"}},c=JSON.parse(localStorage.getItem("buffs"))||{},e=JSON.parse(localStorage.getItem("Timers")),h=JSON.parse(localStorage.getItem("buffSelections"))||{};for(const g in h){var k=h[g];let l=null;if(0<k.length)for(let q of k)if(Object.entries(b).find(([,m])=>m.type===g&&m.item===q)&&!Object.keys(c).find(m=>m.includes(g)&&m.includes(q)&&0<c[m].timeLeft))try{let m=!1,n=null;for(k=1;3>=
k;k++){const r=await jQuery.get(G({mod:"packages",f:11,fq:-1,qry:"",page:k,sh:U("sh")}));jQuery(r).find(".packageItem").each(function(w,u){w=jQuery(u).find(".ui-draggable").attr("data-basis");if((w=b[w])&&w.type===g&&w.item===q){const t=w.item;l=t;if(Object.keys(c).some(A=>A.includes(g)&&A.includes(t)))return!0;m=!0;n=jQuery(u);return!1}});if(m)break}if(m&&n)try{await ic(1,1,async(r,w)=>{const u=n.find('input[name="packages[]"]').val(),t=n.find(".ui-draggable").attr("data-position-x"),A=n.find(".ui-draggable").attr("data-position-y");
await new Promise(z=>setTimeout(z,250));await jQuery.post(S({mod:"inventory",submod:"move",from:"-"+u,fromX:t,fromY:A,to:w,toX:r.x+1,toY:r.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:U("sh")}));C(`${g} buff (${q}) has been moved to the inventory.`);await new Promise(z=>setTimeout(z,250));await jQuery.post(S({mod:"inventory",submod:"move",from:w,fromX:r.x+1,fromY:r.y+1,to:8,toX:1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:U("sh")}));c[`${g} - ${l}`]={timeLeft:n.find(".ticker").attr("data-ticker-time-left")/
6E4};localStorage.setItem("buffs",JSON.stringify(c))})}catch(r){Y("BuffCheck",e.BuffTimer||60),C(`Error moving or using ${g} buff (${q}):`,r)}else Y("BuffCheck",e.BuffTimer||60),C(`No ${g} buff found for ${q}.`)}catch(m){Y("BuffCheck",e.BuffTimer||60),C("Error fetching buffs from packages:",m)}}}}function lj(){const b=Date.now(),c=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),e=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),h=JSON.parse(localStorage.getItem("activeItemsMercenary")||
"{}"),k=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}");Object.entries(e).forEach(([g,l])=>{3E5<b-l&&(c[g]=!0,delete e[g])});Object.entries(k).forEach(([g,l])=>{3E5<b-l&&(h[g]=!0,delete k[g])});localStorage.setItem("activeItemsGladiator",JSON.stringify(c));localStorage.setItem("disabledTimeGladiator",JSON.stringify(e));localStorage.setItem("activeItemsMercenary",JSON.stringify(h));localStorage.setItem("disabledTimeMercenary",JSON.stringify(k))}function $e(){const b=localStorage.getItem("healPercentage")||
25;var c=(new Date).getTime();let e=!1;const z4=localStorage.getItem("we");we=new Date(z4);if(ea<new Date||we<new Date)throw gb(),Error("SupportDevs");const h=[];if(!0===Ba&&ba==wa){var k=xc(document.getElementById("cooldown_bar_text_expedition").innerText);h.push({name:"expedition",time:k,index:0})}!0===Ga&&ba==wa&&(k=xc(document.getElementById("cooldown_bar_text_dungeon").innerText),h.push({name:"dungeon",time:k,index:1}));!0===Ha&&(k=xc(document.getElementById("cooldown_bar_text_arena").innerText),h.push({name:"arena",time:k,index:2}));!0===Da&&(k=xc(document.getElementById("cooldown_bar_text_ct").innerText),
h.push({name:"circusTurma",time:k,index:3}));!0===Ea&&(c=localStorage.getItem("eventPoints.timeOut")-c,h.push({name:"eventExpedition",time:c,index:4}));"true"===sessionStorage.getItem("autoGoActive")&&!1===Da&&!1===Ha&&!1===Ba&&!1===Ga&&"true"===localStorage.getItem("activateAuction2")&&Ef(2E4);const g=function(u){let t=0;for(;t<u.length&&!u[t];)t++;if(t===u.length)return null;let A=u[t].time;for(let z=t+1;z<u.length;z++)u[z]&&u[z].time<A&&(A=u[z].time,t=z);return u[t]}(h);function l(u){if(1E3>u)return"0:00:00";
u=Math.round(u/1E3);let t=u%60;10>t&&(t="0"+t);u=(u-t)/60;let A=u%60;10>A&&(A="0"+A);return(u-A)/60+":"+A+":"+t}let q=document.getElementById("nextActionWindow");const m=(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld;q||(q=document.createElement("div"),q.setAttribute("id","nextActionWindow"),q.setAttribute("style","\n                display: block;\n                align-items: center;\n                justify-content: center;\n                position: absolute;\n                top: -3px;\n                left: 50%;\n                transform: translateX(-50%);\n                height: 50px;\n                width: 190px;\n                color: black;\n                background: rgba(196, 172, 112, 0.9);\n                box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1); /* Softer shadow for a more subtle effect */\n                border-radius: 10px;\n                font-size: 16px;\n                font-family: 'Open Sans', sans-serif;\n                letter-spacing: 0.5px;\n                border: 1px solid black;\n                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); /* Smoother transition effect */\n                z-index: 1999;\n                \n                  "),
g&&g.time&&!String(g.time).includes("NaN")?q.innerHTML=`
                              <span class="span-new" style="color: black;">${d.nc}: </span>
                              <span class="span-new">${d[g.name]}</span></br>
                              <span class="span-new" style="color: black;">${d.fc}: </span>
                              <span class="span-new">${l(g.time)}</span>`:q.innerHTML='\n                              <span class="span-new">Please select an action. [Exp|Dungeon|Arena|Circus]</span></br>',document.getElementById("header_game").insertBefore(q,document.getElementById("header_game").children[0]));function n(u){if(!0===m){if(!0===(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld)switch(u){case "expedition":return"cooldown_bar_expedition";case "circusTurma":if(Da)return"cooldown_bar_ct";
default:return null}}else switch(u){case "expedition":if(Ba)return"cooldown_bar_expedition";break;case "dungeon":if(Ga)return"cooldown_bar_dungeon";break;case "arena":if(Ha)return"cooldown_bar_arena";break;case "circusTurma":if(Da)return"cooldown_bar_ct";break;case "eventExpedition":if(Ea)return null;break;default:return null}}function r(u){if("eventExpedition"!==u){if("circusTurma"===u&&(u="ct"),(u=document.getElementById("cooldown_bar_"+u))&&"none"!==u.style.display)return!u.querySelector(".cooldown_bar_text").classList.contains("ticker")}else if(Ea)return Array.from(document.getElementsByClassName("cooldown_bar_link")).some(t=>
(t=t.closest(".cooldown_bar"))&&"none"!==t.style.display?!t.querySelector(".cooldown_bar_text").classList.contains("ticker"):!1);return!1}function w(u){try{if("eventExpedition"===u&&W("eventPoints")&&1==Ea&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(b):1))try{const t=document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0];return t?(t.click(),e=!0):!1}catch(t){return C("Error performing eventExpedition action: "+t),!1}else{const t=n(u);if(t){const A=document.getElementById(t);
if(A){const z=A.querySelector(".cooldown_bar_link");if(m&&r(u)&&!Ba)return!1;if(z&&r(u))return z.click(),!0}}}}catch(t){return window.location.reload(),!1}}if("true"===sessionStorage.getItem("autoGoActive")){const u=["expedition","dungeon","arena","circusTurma","eventExpedition"];let t=0;function A(){let x=Date.now();if(400>x-t)requestAnimationFrame(A);else{for(const v of u)if(r(v)&&(e=w(v))){t=x;return}e||requestAnimationFrame(A)}}A();setInterval(()=>{if(g){g.time-=1E3;if(g&&(z!==g.name||y!==g.time)){var x=
!g||isNaN(g.time)||String(g.time).includes("NaN")?`<span class="span-new">${d.ga}</span></br>`:`
                            <span class="span-new" style="color: black;">${d.nc}: </span>
                            <span class="span-new">${d[g.name]}</span></br>
                            <span class="span-new" style="color: black;">${d.fc}: </span>
                            <span class="span-new">${l(g.time)}</span>`;q.innerHTML=x;z=g.name;y=g.time;qa&&!0===La&&L()&&"mod=quests"!=nf&&zh("mod=quests")}(0>=g.time||r(g.name))&&w(g.name)}},1E3);let z=null,y=-1}}(function(){if("true"===localStorage.getItem("disableBG")){var b=document.getElementById("wrapper_game");b&&(b.style.backgroundImage="none",b.style.backgroundColor="black")}let c=setTimeout(()=>{chrome.runtime.sendMessage({yp:!0})},1E4);window.onload=function(){clearTimeout(c);chrome.runtime.sendMessage({zp:!0})};
let e=!1;document.addEventListener("touchstart",function(h){function k(l){setTimeout(function(){var q=new MouseEvent("click",{bubbles:!0,cancelable:!0,view:window});l.dispatchEvent(q)},150)}var g=h.target;try{if("AuctionaddPrefixButton"==g.id||"AuctionaddSuffixButton"==g.id||"Strength"==g.htmlFor||"Dexterity"==g.htmlFor||"Agility"==g.htmlFor||"Constitution"==g.htmlFor||"Charisma"==g.htmlFor||"Intelligence"==g.htmlFor||"costumes_button_left"===g.offsetParent.id||"costumes_button_right"===g.offsetParent.id||
"buy_rubies_link"===g.offsetParent.id||"footer_inner"===g.offsetParent.id||"footer_logos"===g.offsetParent.id||"content"===g.id||"sidebar"===g.id||"char"===g.id||"a.menuitem.advanced_menu_link"==g.className||"a.menuitem.advanced_menu_link active"==g.className||"a.menuitem.advanced_menu_link active"==g.className||"menuitem"==g.className||"menuitem "==g.className||"menuitem advanced_menu_link"==g.className||"menuitem active advanced_menu_link_active"==g.className||"set_dungeon_difficulty_normal"!=g.id&&
"set_dungeon_difficulty_advanced"!=g.id&&"set_event_monster_id_0"!=g.id&&"set_event_monster_id_1"!=g.id&&"set_event_monster_id_2"!=g.id&&"set_event_monster_id_3"!=g.id&&"do_combat_quests"!=g.id&&"do_arena_quests"!=g.id&&"do_circus_quests"!=g.id&&"do_expedition_quests"!=g.id&&"do_dungeon_quests"!=g.id&&"do_items_quests"!=g.id&&"ConstitutionPriority"!=g.id&&"CharismaPriority"!=g.id&&"IntelligencePriority"!=g.id&&"StrengthPriority"!=g.id&&"DexterityPriority"!=g.id&&"AgilityPriority"!=g.id&&"shoes-image"!=
g.className&&"ring1-image"!=g.className&&"ring2-image"!=g.className&&"helmet-image"!=g.className&&"necklace-image"!=g.className&&"sword-image"!=g.className&&"chest-image"!=g.className&&"shield-image"!=g.className&&"gloves-image"!=g.className&&("div"==g.localName&&"overlayBack"!==g.id||"div"==g.localName&&"licotok"!==g.id))return}catch{}e||"checkbox"===g.type&&"switch"===g.className||(e=!0,k(g),"submit"!==g.type&&"checkbox"!==g.type&&"switch"!==g.className||h.preventDefault());e=!1},{passive:!1});
try{chrome&&chrome.runtime&&chrome.runtime.sendMessage&&"true"===sessionStorage.getItem("autoGoActive")&&(chrome.runtime.sendMessage({bn:!0,im:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"}),chrome.runtime.sendMessage({keepAlive:!0},()=>{}));let h=localStorage.getItem("activeItemsMercenary"),k=localStorage.getItem("activeItemsGladiator");null!==h&&h!==JSON.stringify([])||localStorage.setItem("activeItemsMercenary",JSON.stringify({}));null!==k&&k!==JSON.stringify([])||localStorage.setItem("activeItemsGladiator",
JSON.stringify({}));chrome.runtime.onMessage.addListener(g=>{g.bn&&g.im&&"true"===sessionStorage.getItem("autoGoActive")&&(g=new Audio(g.im),g.loop=!0,g.volume=0,g.play().catch(()=>{}))})}catch{console.log("Could not play the audio")}(b=JSON.parse(localStorage.getItem("timeConditions"))||[],1>b.length)&&!window.location.href.includes("/index.php?mod=hermit&submod=travel")&&!window.location.href.includes("/index.php?mod=packages")&&!window.location.href.includes("/index.php?mod=forge")?setTimeout(function(){window.location.reload()},
36E4):window.location.href.includes("/index.php?mod=hermit&submod=travel")||window.location.href.includes("/index.php?mod=packages")||window.location.href.includes("/index.php?mod=forge")||setTimeout(function(){window.location.reload()},18E4)})();const mj={start(){const b=async k=>new Promise(g=>{const l=()=>{const q=document.getElementById(k);q?g(q):setTimeout(l,200)};l()}),c=async()=>{try{console.log("Fetching account data..."),chrome.runtime.sendMessage({queryButtonClickedState:!0},k=>{k.state||
b("accountlist").then(g=>{(g=g.getElementsByClassName("btn btn-primary")[0])?(g.click(),sessionStorage.setItem("loggedIn","true")):sessionStorage.setItem("loggedIn","false")})})}catch(k){sessionStorage.setItem("loggedIn","false")}},e=async()=>{window.location.href.includes("/accounts")?await c():window.location.href="https://lobby.gladiatus.gameforge.com/en_GB/accounts"},h=()=>{const k=window.location.href;k.includes("game/index.php")?sessionStorage.setItem("gameActive","true"):(k.includes("gladiatus.gameforge.com/en_GB/lobby")||
k.includes("gladiatus.gameforge.com/lobby"))&&"true"===sessionStorage.getItem("gameActive")&&(console.log("Redirected to lobby. Resetting logged in and game active states."),sessionStorage.setItem("loggedIn","false"),sessionStorage.setItem("gameActive","false"))};(()=>{var k=document.cookie.split("; ").find(l=>l.startsWith("glautologin="));k=k?k.split("=")[1]:null;const g="true"===sessionStorage.getItem("loggedIn");window.location.href.includes("forum.gladiatus")||!window.location.href.includes("lobby")||
"true"!==k||g||setTimeout(e,3500)})();h();(()=>{let k=window.location.href;(new MutationObserver(()=>{const g=window.location.href;g!==k&&(k=g,console.log(`URL changed to: ${g}`),h())})).observe(document,{subtree:!0,childList:!0});window.addEventListener("popstate",()=>{const g=window.location.href;g!==k&&(k=g,console.log(`Popstate URL changed to: ${g}`),h())});window.addEventListener("hashchange",()=>{const g=window.location.href;g!==k&&(k=g,console.log(`Hashchange URL changed to: ${g}`),h())})})();
(()=>{var k=document.querySelectorAll('h1, h2, .error-code, h1[jstcache="0"], #main-frame-error');let g=!1;for(const l of k){k=l.textContent||"";if(k.includes("503")||k.includes("500")){g=!0;break}if("main-frame-error"===l.id||l.hasAttribute("jstcache")){g=!0;break}}g&&(console.warn("Error detected on page. Reloading..."),setTimeout(()=>{location.reload()},3E3))})()}};window.location.href.includes("index.php?mod=overview&submod=achievements")||window.location.href.includes("index.php?mod=overview&submod=stats")||
mj.start();const hh=localStorage.getItem("underworld"),yc=hh?JSON.parse(hh):null,ih=document.querySelector('input[name="cancelTravel"]');try{document.querySelector("#header_LoginBonus")&&!ih&&yc&&!window.location.href.includes("/index.php?mod=hermit")&&!1===yc.isUnderworld&&document.querySelector("#linkLoginBonus").click()}catch{}let jh=document.getElementById("wrapper_game");if(jh&&"underworld"===jh.className){const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",
JSON.stringify(b))}else{const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!1;localStorage.setItem("underworld",JSON.stringify(b))}try{if((window.location.href.includes("/index.php?mod=hermit&submod=travel")||ih||window.location.href.includes("/index.php?mod=hermit&submod=enterUnderworld"))&&"true"===sessionStorage.getItem("autoGoActive")&&"true"===localStorage.getItem("autoEnterHell")){const b=document.querySelector('span[data-ticker-type="countdown"]');if(b){const c=parseInt(b.getAttribute("data-ticker-time-left"),
10);await new Promise(e=>setTimeout(e,c-1E3||358E3))}else await new Promise(c=>setTimeout(c,325E3));zh("mod=overview")}}catch(b){C(`Error in underworld wait: ${b.message}`)}(function(){const b=document.querySelector('span[data-ticker-type="countdown"]');if(window.location.href.includes("/index.php?mod=reports")&&!b||window.location.href.includes("/index.php?mod=guildMarket")&&!b||window.location.href.includes("/index.php?mod=quests")&&!b){function c(){var e=document.getElementById("blackoutDialog");
if(null!==e&&"none"!==window.getComputedStyle(e).display){const h=localStorage.getItem("nestSearchType"),k=document.querySelector("#blackoutDialog.loot-modal");if(h&&k){let g=null;e=e.querySelectorAll(".action_buttons button");switch(h){case "quick":g=e[1];break;case "thorough":g=e[2];break;case "nothing":g=e[0];break;default:g=e[2]}g&&setTimeout(()=>{g.click()},500)}else setTimeout(()=>{const g=document.getElementById("breakDiv");g&&g.click()},500)}}(new MutationObserver(()=>{const e=document.getElementById("blackoutDialog");
e&&"block"===e.style.display&&c()})).observe(document.body,{childList:!0,subtree:!0})}})();let af=!0;const ab=new URL(window.location.href);let kh=document.createElement("style");kh.innerHTML="\n    #logMenu {\n      resize: vertical;\n      overflow: auto;\n      max-height: 500px;\n    }\n  ";document.head.appendChild(kh);let qf=null,rf=0;null===localStorage.getItem("HealClothToggle")&&localStorage.setItem("HealClothToggle","false");window.location.href.includes("mod=auction")&&F();const ja=JSON.parse(localStorage.getItem("userStats"))||
{um:0,vm:0,sm:0,hm:0,km:0,nm:0,pm:0,wm:0,Em:0,Ul:0,Vl:0};let fb;localStorage.getItem("playerId")&&ka((localStorage.getItem("playerId")|0)%100|0);(function(){var b="true"===localStorage.getItem("MoveButtons"),c=document.createElement("button");c.className="menuitem breathing-light";c.innerHTML="GLDbot License";c.setAttribute("id","lico");c.addEventListener("click",Lh);b?((b=document.getElementById("lico"))&&b.remove(),c.style.position="fixed",c.style.left="13px",c.style.bottom="60px",c.style.zIndex=
"1000",document.body.appendChild(c)):(b=document.getElementById("mainmenu"))&&b.children[0]&&b.insertBefore(c,b.children[0]);c=document.createElement("style");c.innerHTML="\n        @keyframes breathing-light {\n            0%, 100% {\n                box-shadow: 0 0 11px 5px rgba(255, 255, 0, 0.7);\n            }\n            50% {\n                box-shadow: 0 0 11px 10px rgba(255, 255, 0, 0.5);\n            }\n        }\n    \n        .breathing-light {\n            animation: breathing-light 2s ease-in-out infinite;\n        }";
document.head.appendChild(c)})();if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll")){var bf=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),ub=bf.textContent.trim();if(2<ub.length){var cf=document.getElementById("char");function b(e,h,k,g){if(null!==document.getElementById("container_start")){var l=window.location.href.split("p=")[1].split("&")[0],q=window.location.href.match(/s(\d+)-\w\w/),
m=window.location.href.match(/s\d+-(\w\w)/);h={playerName:h,aType:g,opponentId:l,serverId:q?q[1]:null,country:m?m[1]:null};k=2===g?"arenacrosslist":"circuscrosslist";var n=2===g?"removeArenaList":"removeCircusList";q=JSON.parse(yb(k)||"[]");var r=JSON.parse(yb(n)||"[]");m=q.findIndex(u=>u.opponentId===l);var w=r.findIndex(u=>u.opponentId===l);-1!==m?(q.splice(m,1),-1===w&&(r.push(h),qb(n,JSON.stringify(r),7)),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+(2===g?"Arena":"Circus"))):
(q.push(h),-1!==w&&(r.splice(w,1),qb(n,JSON.stringify(r),7)),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+(2===g?"Arena":"Circus")));qb(k,JSON.stringify(q),7)}else q=JSON.parse(localStorage.getItem(k))||[],m=q.indexOf(h),-1!==m?(q.splice(m,1),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(q.push(h),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus"))),
localStorage.setItem(k,JSON.stringify(q))}function c(e,h,k,g,l){var q=document.createElement("a");q.className="gladbot-button gladbot-"+e;q.textContent=h;q.setAttribute("data-tooltip",k);cf.appendChild(q);(JSON.parse(localStorage.getItem(g))||[]).includes(ub)&&(q.classList.add("added"),q.setAttribute("data-tooltip","Remove from "+("autoAttackList"===g?"Arena":"Circus")));q.addEventListener("click",function(){b(q,ub,g,l)})}c("arena","A","GladB: Add to Arena List","autoAttackList",2);c("circus","C",
"GladB: Add to Circus List","autoAttackCircusList",3)}}const nj=localStorage.getItem("Username"),wa=localStorage.getItem("pid"),idkps=localStorage.getItem("idkps");let oj=localStorage.getItem("tkz_lcr");const pj=localStorage.getItem("tkn"),cc=await ma(oj,pj,wa,nj);window.location.href.includes("/index.php?mod")&&sessionStorage.setItem("loggedIn","false");if(window.location.href.includes("/index.php?mod=overview")){const b=[3,4,5,2,9,10,6,7,11],c=[1,2,4,8,48,256,512,1024];Mh();(function(){const k={dbfa266e60c28ce109de4d9c216a2a:"Health - Gingko Leaves",
"25925f7ce7c04483a3b4527846c04b":"Health - Taigaroot","79e62e1e04445d354bcc955bb8baeb":"Health - Hawthorn",b306d3f65b14cb91c0f0c9de871e0a:"Strength - Flask",ee80ae69b48ebbeb81e52c20113709:"Constitution - Flask","887d1152e2f7cba339a0a4675b3b5e":"Agility - Flask","93820f465cb02d5d8828ee9a14f5fe":"Charisma - Flask","2bf8795edae428b4646f8d6fd6dc4c":"Intelligence - Flask","43ac2597d30a099dd7033273ac29c1":"Dexterity - Flask","5368deb7929c8853843b420fb439ac":"Constitution - Bottle","967321edb226ea075ac63acc701eea":"Dexterity - Bottle",
"1c344cf484e5a87731eaf906ffd993":"Strength - Bottle","8971734256abbbe0fea2bb40721953":"Intelligence - Bottle",d2df53b4e64ad33dc301b6bf125fd2:"Agility - Bottle","37fc8feb4ead7f2e59c026af4228b3":"Charisma - Bottle",ce03a66b17f81394722a3fc2335a1d:"Constitution - Flacon","352a093dc497a9ec659f217dc7d374":"Dexterity - Flacon",b5e7e6f2cd2ea3d86143894e5f9ade:"Charisma - Flacon","2e8f9fc0f9b101f7ba49152cbe9779":"Strength - Flacon","3b52078b78637bd54fed2e4cfb951b":"Agility - Flacon",a2ef931eff7cce75e07baa9ae2ac97:"Intelligence - Flacon",
"48331278d1b0391f74ba54b4cac6d4":"Intelligence - Ampulla","453199ebfb25d62f83af27b0187088":"Agility - Ampulla","00ef972a002dc3040447e5cc0eb77d":"Dexterity - Ampulla",ce6fe5171b946cd26d5b21e87efb5d:"Strength - Ampulla",ddd6bc43a13d444409087b99b9f142:"Charisma - Ampulla",bd48bef94e6d066a8bfef716dd959a:"Constitution - Ampulla"},g=document.querySelectorAll("#buffbar_old .buff_inner");let l=JSON.parse(localStorage.getItem("buffs"))||{},q=new Set;g.forEach(m=>{var n=m.querySelector("img");n=(n=n?n.getAttribute("src"):
null)?n.split("/").pop().split(".")[0]:null;if(n=k[n])if(m=(m=m.parentElement.querySelector(".ticker"))?m.getAttribute("data-ticker-time-left"):null)l[n]={timeLeft:Math.round(Number(m)/6E4)},q.add(n)});Object.keys(l).forEach(m=>{q.has(m)||delete l[m]});localStorage.setItem("buffs",JSON.stringify(l))})();const e=document.getElementById("char");if(e){const k=document.createElement("button"),g=document.createElement("span");k.textContent="\u21d3";k.className="put-down awesome-button";k.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 170px; font-size: 12px; cursor: pointer;";
k.classList.add("tooltip");k.appendChild(g);k.onclick=async function(){let m=Array.from(document.querySelectorAll("#char .ui-droppable")).filter(n=>b.includes(parseInt(n.dataset.containerNumber,10)||"0"));for(let n=0;n<m.length;n++)await new Promise(r=>setTimeout(r,100)),Ca(m[n],"inv");await new Promise(n=>setTimeout(n,500))};e.appendChild(k);const l=document.createElement("button"),q=document.createElement("span");l.textContent="\u21d1";l.className="put-up awesome-button";l.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 192px; font-size: 12px; cursor: pointer;";
l.classList.add("tooltip");l.appendChild(q);l.onclick=async function(){let m=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(n=>c.includes(parseInt(n.dataset.contentType,10)));for(let n=0;n<m.length;n++)await new Promise(r=>setTimeout(r,100)),Ca(m[n],"char");await new Promise(n=>setTimeout(n,500))};e.appendChild(l)}if(document.getElementById("inv")){async function k(m,n,r,w,u,t){await jQuery.post(S({mod:"inventory",submod:"move",from:t,fromX:n+1,fromY:r+1,to:t,toX:w+1,toY:u+1,amount:m.dataset.amount||
1,doll:1,a:(new Date).getTime(),sh:U("sh")}))}const g=document.createElement("button");g.id="sort-button";g.textContent="Sort Inventory";g.className="sort-button awesome-button";g.style="padding: 5px; margin: 5px; cursor: pointer;";const l=document.createElement("span");l.id="loading-indicator";l.style="margin-left: 10px; display: none;";const q=document.querySelector(".contentItem");q&&(q.insertAdjacentElement("afterend",g),g.insertAdjacentElement("afterend",l));g.addEventListener("click",async function(){function m(y,
x,v){for(let D=0;5>D;D++)for(let E=0;8>E;E++)if(!u[D][E]){let I=!0;for(let J=D;J<D+x&&I;J++)for(let K=E;K<E+y;K++)if(5<=J||8<=K||u[J][K])I=!1;if(I){if(v){y=[{x:E-1,y:D},{x:E+y,y:D},{x:E,y:D-1},{x:E,y:D+x}];for(const J of y)if(0<=J.x&&8>J.x&&0<=J.y&&5>J.y&&w.find(K=>{const P=parseInt(K.style.top,10)/32;return parseInt(K.style.left,10)/32===J.x&&P===J.y&&K.dataset.basis.split("-")[0]===v}))break}return{x:E,y:D}}}return null}var n=document.getElementById("inv");document.getElementById("sort-button");
var r=document.getElementById("loading-indicator");r.textContent="Sorting...";r.style.display="inline-block";const w=Array.from(n.getElementsByClassName("ui-draggable"));w.sort((y,x)=>{const v=parseInt(y.dataset.basis.split("-")[0],10)||0,D=parseInt(x.dataset.basis.split("-")[0],10)||0;return v!==D?v-D:(parseInt(y.dataset.measurementX,10)*parseInt(y.dataset.measurementY,10)||1)-(parseInt(x.dataset.measurementX,10)*parseInt(x.dataset.measurementY,10)||1)});const u=Array.from({length:5},()=>Array(8).fill(!1));
w.forEach(y=>{const x=parseInt(y.style.left,10)/32,v=parseInt(y.style.top,10)/32,D=parseInt(y.dataset.measurementX,10);y=parseInt(y.dataset.measurementY,10);for(let E=v;E<v+y;E++)for(let I=x;I<x+D;I++)u[E][I]=!0});for(n=0;n<w.length;n++){var t=w[n];r=parseInt(t.dataset.measurementX,10);const y=parseInt(t.dataset.measurementY,10);var A=t.dataset.basis.split("-")[0];const x=parseInt(t.style.left,10)/32,v=parseInt(t.style.top,10)/32;var z=m(r,y,A);if(z&&(A=z.x,z=z.y,x!==A||v!==z)){await k(t,x,v,A,z,
t.dataset.containerNumber);for(t=z;t<z+y;t++)for(let D=A;D<A+r;D++)u[t][D]=!0;for(A=v;A<v+y;A++)for(t=x;t<x+r;t++)u[A][t]=!1}}window.location.reload()})}const h=JSON.parse(localStorage.getItem("underworld"))||{};try{const k=document.querySelector("#avatar .ui-droppable");if(k){const g=k.getAttribute("data-tooltip");g&&g.toLowerCase().includes("dis pater")?(h.oi=!0,localStorage.setItem("underworld",JSON.stringify(h)),Y("CheckDolls",15)):(h.oi=!1,localStorage.setItem("underworld",JSON.stringify(h)))}}catch{}}let Kc=
localStorage.getItem("playerId");bc();let tb=!1,qa="true"===sessionStorage.getItem("autoGoActive")?!0:!1,aa;try{aa={level:parseInt(document.getElementById("header_values_level").innerText,10)||50,o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,""))}}catch(b){aa={level:50}}const bb=document.createElement("div");bb.style.position="fixed";bb.style.right="10px";bb.style.top="50px";bb.style.zIndex="99999";document.body.appendChild(bb);
const oa=document.createElement("div");oa.id="logMenu";oa.style.width="190px";oa.style.height="210px";oa.style.overflowY="hidden";oa.style.backgroundColor="rgba(221, 213, 180, 0.8)";oa.style.border="1px solid #c4ac70";oa.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";oa.style.borderRadius="10px";oa.style.fontFamily="Arial, sans-serif";oa.style.color="#333";bb.appendChild(oa);const cb=document.createElement("h2");cb.textContent="Log Menu";cb.style.backgroundColor="rgba(196, 172, 112, 0.8)";
cb.style.color="#333";cb.style.margin="0";cb.style.padding="10px 20px";cb.style.borderTopLeftRadius="10px";cb.style.borderTopRightRadius="10px";oa.appendChild(cb);const Ab=document.createElement("div");Ab.id="logEntriesContainer";Ab.style.color="#bfae54";Ab.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";Ab.style.overflowY="scroll";Ab.style.height="calc(100% - 60px)";Ab.style.padding="10px 20px";oa.appendChild(Ab);const Pa=document.createElement("div");Pa.style.display="flex";Pa.style.justifyContent="space-between";Pa.style.marginTop="10px";Pa.style.top="calc(300px + 10px)";
Pa.style.width="155px";Pa.style.padding="0 10px";Pa.style.zIndex="99999";Pa.style.left="0";bb.appendChild(Pa);const Ja=document.createElement("button");Ja.id="clearLogsButton";Ja.textContent="Clear Logs";Lc(Ja,"rgba(221, 213, 180, 0.8)");Pa.appendChild(Ja);Ja.addEventListener("click",function(){const b=document.querySelector("#logMenu");if(b){for(;b.firstChild;)b.removeChild(b.firstChild);localStorage.removeItem("savedLogs")}});const Qb=document.createElement("button");Qb.id="resetBOT";Qb.textContent=
"Reset Bot";Lc(Qb,"rgba(221, 213, 180, 0.8)");Pa.appendChild(Qb);Qb.addEventListener("click",function(){R()});const Qa=document.createElement("button");Qa.textContent="Sort Logs";Lc(Qa,"rgba(221, 213, 180, 0.8)");Pa.appendChild(Qa);Qa.addEventListener("click",function(){let b=localStorage.getItem("savedLogs");if(b){b=JSON.parse(b);b.sort((e,h)=>{e=e.split(" ")[0];h=h.split(" ")[0];return af?e.localeCompare(h):h.localeCompare(e)});af=!af;for(var c=document.querySelector("#logMenu");c.firstChild;)c.removeChild(c.firstChild);
for(let e of b){const h=document.createElement("p");h.style.margin="0";h.style.padding="0";h.style.fontSize="12px";h.textContent=e;c.appendChild(h)}localStorage.setItem("savedLogs",JSON.stringify(b))}});oa.style.transition="height 0.1s ease";const lh=localStorage.getItem("logMenuVisible"),mh="true"===localStorage.getItem("disableLogMenu");null===lh?localStorage.setItem("logMenuVisible","true"):1==mh?(oa.style.display="none;",oa.style.height="0px",oa.style.width="0px",oa.style.border="0px",Ja.style.display=
"none",Ja.style.height="0px",Ja.style.width="0px",Ja.style.border="0px",Qa.style.display="none",Qa.style.height="0px",Qa.style.width="0px",Qa.style.border="0px"):"true"===lh?localStorage.getItem("logMenuHeight"):oa.style.height="38px";window.location.href.includes("/hub")&&(oa.style.display="none;",oa.style.height="0px",oa.style.width="0px",oa.style.border="0px",Ja.style.display="none",Ja.style.height="0px",Ja.style.width="0px",Ja.style.border="0px",Qa.style.display="none",Qa.style.height="0px",Qa.style.width=
"0px",Qa.style.border="0px");cb.addEventListener("click",function(){if("38px"!==oa.style.height)oa.style.height="38px",localStorage.setItem("logMenuVisible","false");else{const b=localStorage.getItem("logMenuHeight")||"210px";oa.style.height=b;localStorage.setItem("logMenuVisible","true")}});oa.addEventListener("resize",uf);"38px"!==oa.style.height&&uf();if(Jc()){const b="true"===localStorage.getItem("MoveButtons");let c=document.getElementById("mainmenu"),e=document.createElement("button");e.id=
"autoGoButton";e.className="customButton";e.innerHTML=`<span style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;">${qa?"&#9724;":"&#9658;"}</span>`;e.addEventListener("click",qa?yf:pt);let h=document.createElement("button");h.className="customButton2";h.innerHTML='<span style="position: relative; top: -12px;">&#9881;</span>';h.addEventListener("click",hc);b?(h.style.position="fixed",h.style.bottom="10px",h.style.left="10px",h.style.zIndex="1000",e.style.position=
"fixed",e.style.bottom="10px",e.style.left="105px",e.style.zIndex="1000",document.body.appendChild(h),document.body.appendChild(e)):c&&(c.insertBefore(h,c.children[0]),c.insertBefore(e,c.children[1]))}else return gb(),!1;(function(){try{if("mod=arena&submod=serverArena&aType=2"==nf||"mod=arena&submod=serverArena&aType=3"==nf){let l=JSON.parse(localStorage.getItem("autoAttackList"))||[],q=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],m=JSON.parse(localStorage.getItem("autoAttackCircusList"))||
[],n=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[],r=[...l,...q,...m,...n].map(w=>w.playerName);Array.from(document.querySelectorAll("#own2 tr")).forEach(w=>{(w=w.querySelector("a"))&&r.includes(w.innerText)&&(w.style.color="orange",w.style.fontWeight="bold",w.style.textShadow="1px 1px 2px #000000")})}var b=JSON.parse(yb("arenacrosslist")||"[]"),c=JSON.parse(yb("circuscrosslist")||"[]"),e=JSON.parse(yb("removeArenaList")||"[]"),h=JSON.parse(yb("removeCircusList")||"[]"),k=JSON.parse(localStorage.getItem("autoAttackServerList")||
"[]"),g=JSON.parse(localStorage.getItem("autoAttackCircusServerList")||"[]");0<b.length&&(b.forEach(l=>{k.some(q=>q.opponentId===l.opponentId)||k.push(l)}),localStorage.setItem("autoAttackServerList",JSON.stringify(k)),qb("arenacrosslist",JSON.stringify([]),7));0<c.length&&(c.forEach(l=>{g.some(q=>q.opponentId===l.opponentId)||g.push(l)}),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(g)),qb("circuscrosslist",JSON.stringify([]),7));if(0<e.length||0<h.length)k=k.filter(l=>!e.some(q=>
q.opponentId===l.opponentId)),g=g.filter(l=>!h.some(q=>q.opponentId===l.opponentId)),localStorage.setItem("autoAttackServerList",JSON.stringify(k)),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(g)),qb("removeArenaList",JSON.stringify([]),7),qb("removeCircusList",JSON.stringify([]),7)}catch{C("Something is wrong with HandlePlayers")}})();"mod=overview"==nf&&Nh();if("mod=location"!==nf&&"mod=arena"!==nf&&0==localStorage.getItem("eventPoints_")){const b=document.getElementById("ServerQuestTime");
if(b){const c=b.querySelector("span");c&&localStorage.setItem("eventPoints_",c.textContent)}}let La=!0;localStorage.getItem("doQuests")&&(La="true"===localStorage.getItem("doQuests")?!0:!1);let Ma={combat:!0,arena:!0,circus:!0,expedition:!0,dungeon:!0,items:!0};localStorage.getItem("questTypes")&&(Ma=JSON.parse(localStorage.getItem("questTypes")));let Rb=0;localStorage.getItem("nextQuestTime")&&(Rb=Number(localStorage.getItem("nextQuestTime")));let Ba=!0;localStorage.getItem("doExpedition")&&(Ba=
"true"===localStorage.getItem("doExpedition")?!0:!1);let Rc=0;localStorage.getItem("monsterId")&&(Rc=Number(localStorage.getItem("monsterId")));let Ga=!0;localStorage.getItem("doDungeon")&&(Ga="true"===localStorage.getItem("doDungeon")?!0:!1);10>aa.level&&(Ga=!1);let Fb="advanced"===localStorage.getItem("dungeonDifficulty")?"advanced":"normal",Ha=!0;localStorage.getItem("doArena")&&(Ha="true"===localStorage.getItem("doArena")?!0:!1);2>aa.level&&(Ha=!1);let Ff="min";localStorage.getItem("arenaOpponentLevel")&&
(Ff=localStorage.getItem("arenaOpponentLevel"));let Da=!0;localStorage.getItem("doCircus")&&(Da="true"===localStorage.getItem("doCircus")?!0:!1);10>aa.level&&(Da=!1);let Gf="min";localStorage.getItem("circusOpponentLevel")&&(Gf=localStorage.getItem("circusOpponentLevel"));let Ea=!0;localStorage.getItem("doEventExpedition")&&(Ea="true"===localStorage.getItem("doEventExpedition")?!0:!1);try{document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0]||(Ea=!1)}catch{}let jc=0;localStorage.getItem("eventMonsterId")&&
(jc=Number(localStorage.getItem("eventMonsterId")));let Za=!1;localStorage.getItem("AutoAuction")&&(Za="true"===localStorage.getItem("AutoAuction")?!0:!1);localStorage.getItem("DoOther")&&localStorage.getItem("DoOther");let hb=!1;localStorage.getItem("doKasa")&&(hb="true"===localStorage.getItem("doKasa")?!0:!1);let d;switch(localStorage.getItem("settings.language")){case "EN":d={...Eh};break;case "PL":d={...Fh};break;case "ES":d={...Gh};break;case "TR":d={...Hh};break;case "FR":d={...Ih};break;case "HG":d=
{...Jh};break;case "BR":d={...Kh};break;default:d={...Eh}}const z1=localStorage.getItem("we");we=new Date(z1);if(!window.location.href.includes("lobby")&&ea<new Date)sessionStorage.setItem("autoGoActive","false"),gb();else{if("true"===localStorage.getItem("activateAuction2")){function b(m){m.style.position="flex";m.style.width="150px";m.style.marginLeft="8px";m.style.marginTop="10px";m.style.height="16px";m.style.backgroundColor="rgba(221, 213, 180, 0.8)";m.style.border="1px solid #c4ac70";m.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";m.style.padding=
"10px";m.style.borderRadius="10px";m.style.fontFamily="Arial, sans-serif";m.style.color="#333";m.style.textAlign="center";m.style.zIndex="1000"}const c=document.createElement("div");c.id="auctionMPopup";b(c,"calc(55px + 200px + 100px + 10px + 10px + -5px)");c.addEventListener("click",async()=>{zh("mod=auction&ttype=3")});const e=document.createElement("div");e.id="auctionPopup";b(e,"calc(100px + 200px + 100px + 10px)");e.addEventListener("click",async()=>{zh("mod=auction")});function h(m,n){return`${n}: ${[d.Yb,
d.Bb,d.Jb,d.Vb,d.Zb][m]||"Unknown"}`}const k=document.createElement("h3"),g=document.createElement("h3");bb.appendChild(e);bb.appendChild(c);const l=localStorage.getItem("auctionStatus"),q=localStorage.getItem("auctionMStatus");null!==l?(k.textContent=h(parseInt(l,10),"Gladiator"),e.appendChild(k),e.style.display="block"):e.style.display="none";null!==q?(g.textContent=h(parseInt(q,10),"Mercenary"),c.appendChild(g),c.style.display="block"):c.style.display="none";mh&&(e.style.display="none",e.style.height=
"0px",c.style.display="none",c.style.height="0px")}var zc=localStorage.getItem("savedLogs");zc&&(zc=JSON.parse(zc),zc.forEach(b=>{const c=document.createElement("p");c.style.margin="0";c.style.padding="0";c.style.fontSize="12px";c.textContent=b;Ab.appendChild(c)}));var za={async start(){return new Promise(()=>{za.al=Bh().gold;za.form=document.querySelectorAll("#auction_table form");za.L=[];const b=localStorage.getItem("auctiongladiatorenable"),c=localStorage.getItem("auctionmercenaryenable"),e=localStorage.getItem("bidFood"),
h=localStorage.getItem("bidStatus"),k=localStorage.getItem("auctionStatus"),g=localStorage.getItem("auctionMStatus"),l=localStorage.getItem("auctionminlevel")||0;let q="true"===localStorage.getItem("enableMercenarySearch");const m=JSON.parse(localStorage.getItem("Timers")),n=async(w,u)=>{try{C(`${d.fe}`);const t=await (await fetch(w)).text(),A=(new DOMParser).parseFromString(t,"text/html");await za.Dn(A);0<za.L.length?(C(`${d.ge}`),"auction"===u?za.Jm(2,za.L.length):za.Jm(3,za.L.length)):("auction"===
u?Y("auction",m.AuctionCheck||10):Y("auctionM",m.AuctionCheck||10),window.location.reload());1!=localStorage.getItem("AuctionTurbo")&&Y("AuctionEmpty",1)}catch(t){window.location.reload()}},r=async()=>{var w=JSON.parse(localStorage.getItem("auctionPrefixes"))||[];let u=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],t;var A=(new URL(window.location.href)).origin;try{1===w.length?t=ac(w[0]):1===u.length&&(t=ac(u[0]))}catch(z){t=""}if(q&&Number(k)>=Number(h)&&W("auction")||"true"==e&&Number(k)>=
Number(h)&&W("auction"))nf!=`mod=auction&itemType=0&itemLevel=${l}`&&(A=`${A}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,n(A,"auction"));else if((1==w.length||1==u.length)&&"true"==b&&Number(k)>=Number(h)&&"false"==e&&W("auction"))w=`mod=auction&qry=${encodeURIComponent(t)}&itemType=0&itemLevel=${l}`,nf!==w&&(A=`${A}/game/index.php?${w}&sh=${U("sh")}`,n(A,"auction"));else if(q&&Number(k)>=Number(h)&&"true"==e&&W("auction"))nf!=`mod=auction&itemType=0&itemLevel=${l}`&&(A=`${A}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,
n(A,"auction"));else if((1==w.length||1==u.length)&&"true"==c&&Number(g)>=Number(h)&&"false"==e&&W("auctionM"))nf!=`mod=auction&qry=${encodeURIComponent(t)}&itemType=0&ttype=3&itemLevel=${l}`&&(A=`${A}/game/index.php?mod=auction&qry=${t}&itemType=0&ttype=3&itemLevel=${l}&sh=${U("sh")}`,n(A,"auctionM"));else if(("true"===b||"true"===e)&&!q&&Number(k)>=Number(h)&&W("auction"))if("true"===e&&1>w.length&&1>u.length)nf!=`mod=auction&itemType=7&itemLevel=${l}`&&(A=`${A}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${U("sh")}`,
n(A,"auction"));else{if(("true"===b||"true"===e)&&!q&&Number(k)>=Number(h)&&W("auction"))if("true"===e&&"false"===b&&(0<w.length||0<u.length))nf!=`mod=auction&itemType=7&itemLevel=${l}`&&(A=`${A}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${U("sh")}`,n(A,"auction"));else if("true"===e&&(0<w.length||0<u.length))nf!=`mod=auction&itemType=0&itemLevel=${l}`&&(A=`${A}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,n(A,"auction"));else if(nf!=`mod=auction&itemType=0&itemLevel=${l}`&&
0<w.length||nf!=`mod=auction&itemType=0&itemLevel=${l}`&&0<u.length)A=`${A}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${U("sh")}`,n(A,"auction")}else if("true"==c&&Number(g)>=Number(h)&&(0<w.length||0<u.length)&&W("auctionM")){if(nf!=`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&0<w.length||nf!=`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&0<u.length)A=`${A}/game/index.php?mod=auction&itemType=0&ttype=3&itemLevel=${l}&sh=${U("sh")}`,n(A,"auctionM")}else q?nf!=`mod=auction&itemType=15&itemLevel=${l}`&&
(A=`${A}/game/index.php?mod=auction&itemType=15&itemLevel=${l}&sh=${U("sh")}`,n(A,"auction")):setTimeout(r,3E3)};r()})},Cn(b){const c="true"===localStorage.getItem("AuctionCover");b=b.querySelector("span");if(!b||!b.getAttribute("style"))return!0;b=b.getAttribute("style");return c&&b.includes("green")?!1:!c&&b.includes("green")?!0:b.includes("blue")?!1:!0},async Dn(b){this.form=b.querySelectorAll("#auction_table form");for(let e of this.form){var c=e.querySelector(".auction_bid_div");b=e.querySelector(".ui-draggable");
let h=c.querySelector("input").value;c=this.Cn(c);let k=Xb(b),g=Db(b),l=JSON.parse(localStorage.getItem("equipmentSelection")||"[]"),q=localStorage.getItem("maximumBid"),m=localStorage.getItem("auctiongladiatorenable"),n=localStorage.getItem("auctionmercenaryenable"),r=pb(b),w=localStorage.getItem("auctionMinQuality")||0,u=localStorage.getItem("bidFood"),t=parseInt(wb(b).split("-")[0],10),A=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,z=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],
10):0,y=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],10):0,x=!1,v="true"===localStorage.getItem("enableMercenarySearch"),D=parseInt(localStorage.getItem("minDexterity"),10)||0,E=parseInt(localStorage.getItem("minAgility"),10)||0,I=parseInt(localStorage.getItem("minIntelligence"),10)||0,J=!1,K=!1,P,T,X;X=localStorage.getItem("ignorePS")||"false";P=JSON.parse(localStorage.getItem("auctionPrefixes")||"[]");T=JSON.parse(localStorage.getItem("auctionSuffixes")||"[]");P.some(ia=>
k.toLowerCase().includes(ia.toLowerCase())?J=!0:!1);T.some(ia=>{let fa=k.toLowerCase();ia=ia.toLowerCase();return fa.endsWith(" "+ia)||fa===ia?K=!0:!1});if("true"===X){if(J||K)x=!0}else if(J&&K||J&&0===T.length||K&&0===P.length)x=!0;"string"===typeof g&&(g=[g]);null==w&&(w=5);x=x&&0===l.length||x&&l.includes("9999")||x&&l.some(ia=>g.includes(ia))?!0:!1;"true"===u&&7==t&&h<aa.gold&&(x=!0);Number(r)<w&&("true"!==u||7!=t)&&(x=!1);"false"!==m||"false"!==n||"true"===u&&7==t||(x=!1);1E3>aa.gold&&(Y("AuctionEmpty",
1),Y("AuctionMEmpty",1));c&&v&&15==t&&Number(h)<Number(q)&&(0==D||A>=D)&&(0==E||z>=E)&&(0==I||y>=I)&&(x=!0);x&&c&&Number(h)<Number(q)&&this.L.push([{itemLevel:Eb(b),itemName:k,basis:wb(b),quality:pb(b),price:h},h,e.getAttribute("action"),{auctionid:e.querySelector("input[name=auctionid]").value,qry:e.querySelector("input[name=qry]").value,itemType:e.querySelector("input[name=itemType]").value,itemLevel:e.querySelector("input[name=itemLevel]").value,itemQuality:e.querySelector("input[name=itemQuality]").value,
buyouthd:e.querySelector("input[name=buyouthd]").value,bid_amount:h,bid:e.querySelector("input[name=bid]").value}])}},Jm(b){function c(k){if("string"===typeof k)return k;let g=[];for(let l in k)k.hasOwnProperty(l)&&g.push(encodeURIComponent(l)+"="+encodeURIComponent(k[l]));return g.join("&")}localStorage.getItem("auctionStatus");localStorage.getItem("auctionMStatus");const e=JSON.parse(localStorage.getItem("Timers")),h=()=>{if(0===za.L.length)Y("AuctionEmpty",1),Y("AuctionMEmpty",1),window.location.reload();
else{var k=[];for(let g=0;3>g&&0!==za.L.length;g++){let l=za.L.pop(),q=new Promise((m,n)=>{try{if(Number(l[1])<za.al){za.al-=l[1];let r=new XMLHttpRequest;r.open("POST",l[2],!0);r.onreadystatechange=function(){if(r.readyState===XMLHttpRequest.HEADERS_RECEIVED){if(200===r.status){let u=JSON.parse(localStorage.getItem("bidList"))||[];u.push(l[0].itemName);localStorage.setItem("bidList",JSON.stringify(u))}else console.error("Error placing bid:",r.status);m();r.abort()}};r.setRequestHeader("Content-Type",
"application/x-www-form-urlencoded");const w=c(l[3]);r.send(w)}else 2==b?(Y("AuctionEmpty",1),Y("auction",e.AuctionCheck||10)):(Y("AuctionMEmpty",1),Y("auctionM",e.AuctionCheck||10)),window.location.reload(),n("Not enough gold")}catch(r){n(r)}});k.push(q)}Promise.all(k).then(()=>{setTimeout(()=>{h()},250)}).catch(()=>{setTimeout(()=>{h()},250)})}};h()}},ha={bag:null,g:null,Ap:null,Ip:localStorage.getItem("smeltIgnorePS"),async start(){const b="true"===localStorage.getItem("RepairBeforeSmelt");var c=
"513";c=(c=localStorage.getItem("smeltTab"))?(513+parseInt(c,10)).toString():"513";c=document.querySelector(`[data-bag-number="${c}"]`);if("mod=forge&submod=smeltery"!=nf)zh("mod=forge&submod=smeltery");else if(c.classList.contains("current")&&pf()){this.slots=await this.u();const e=this.slots.filter(g=>"closed"===g["forge_slots.state"]);this.Bm(this.slots);await this.jm(this.slots);const h=JSON.parse(localStorage.getItem("Timers")),k="true"===localStorage.getItem("smelteverything3");c="true"===localStorage.getItem("smeltAnything")?
this.$n():"true"===localStorage.getItem("smelteverything3")?this.ao():this.Zn();if(0<c.length){for(let {id:g,slot:l,hammerState:q}of c)try{if(b){const m=await qj.ro(g);if(m&&0!=m)try{await ha.bm(l,m,q,g)}catch{await ha.bm(l,g,q,g)}else await ha.bm(l,g,q,g)}else await ha.bm(l,g,q,g)}catch(m){}window.location.reload()}else 1>c.length&&1==k?(Y("smelt",h.SmeltingNoItem||10),window.location.reload()):0<e.length?await this.pickItems():0<e.length&&"true"===localStorage.getItem("smelteverything3")?ha.move():
(Y("smelt",h.SmeltingNoItem||10),window.location.reload())}else c.click(),pf(()=>this.start())},po(b,c){b=JSON.parse(localStorage.getItem("smeltedItems"))||[];b.push(c);localStorage.setItem("smeltedItems",JSON.stringify(b))},Zn(){const b=this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>h["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let h of c){if(c=this.Yl(h)){let k=b.shift();void 0!==k&&e.push({id:h.getAttribute("data-item-id"),
slot:k,hammerState:c.hammerState||"none",matchingRule:c})}if(0===b.length)break}return e},$n(){const b=this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>h["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let h of c){if(c=this.Yl(h)){let k=b.shift();void 0!==k&&e.push({id:h.getAttribute("data-item-id"),slot:k,hammerState:c.hammerState||"none",matchingRule:c})}if(0===b.length)break}return e},ao(){const b=[2,4,8,1,256,512,48,1024],c=this.slots.filter(e=>
"closed"===e["forge_slots.state"]).map(e=>e["forge_slots.slot"]);return Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(e=>{if(!Zb(e))return!1;e=e.getAttribute("data-content-type");return b.includes(Number(e))}).map(e=>({id:e.getAttribute("data-item-id"),slot:c.shift()})).filter(({slot:e})=>void 0!==e)},async bm(b,c,e,h){try{var k=await jQuery.post(S({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:U("sh")});let q;try{var g=
JSON.parse(k);if(g.slots[b]&&g.slots[b].formula&&g.slots[b].formula.rent[2])q=g.slots[b].formula.rent[2];else{for(k=0;k<g.slots.length;k++)if(g.slots[k].formula&&g.slots[k].formula.rent[2]){q=g.slots[k].formula.rent[2];break}q||=3E3}}catch(n){q=3E3}const m=Xb(document.querySelector(`[data-item-id='${h}']`));try{if(e&&"none"!==e){const n={bronze:"19-10",silver:"19-11",gold:"19-12"}[e];if(n){var l=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));const r=l.findIndex(u=>u.classList.contains("current")),
w=l.slice(r).concat(l.slice(0,r));h=!1;g=null;for(l=0;l<w.length;l++){let u=w[l];if("false"===u.getAttribute("data-available"))continue;u.click();await new Promise(A=>setTimeout(A,250));const t=document.querySelector(`.item-i-${n}`);if(t){h=!0;g=t;break}}if(h&&g){const u=g.getAttribute("data-container-number"),t=g.getAttribute("data-position-x"),A=g.getAttribute("data-position-y");await jQuery.post(S({mod:"inventory",submod:"move",from:u,fromX:t,fromY:A,to:773,toX:b+1,toY:1,amount:1,doll:1,a:(new Date).getTime(),
sh:U("sh")}));C(`Hammer (${e}) moved to inventory.`)}else C(`Hammer (${e}) not found in any inventory bag.`),C("Proceeding to smelt without a hammer.")}else C("Proceeding to smelt without a hammer.")}}catch(n){}if(q<Bh().gold)await jQuery.post(S({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:U("sh")})),this.po(c,m),Q("itemSmelted",0),C(`${d.Ee}`+m),await new Promise(n=>setTimeout(n,250));else{const n=JSON.parse(localStorage.getItem("Timers"));Y("smelt",n.Smelting||
10);window.location.reload()}}catch(q){location.reload()}},async uo(b,c){var e=await jQuery.post(S({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:U("sh")});e=JSON.parse(e).slots[b].formula.rent[2];e<Bh().gold?jQuery.post(S({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:U("sh")})).done(function(){var h=JSON.parse(localStorage.getItem("smeltery_itemList1"));({item:h}=h);C(`${d.Fe}`+h.name);window.location.reload()}).fail(function(){C("Problem with smelting, maybe there is not enough space.");
window.location.reload()}):(C(`${d.Ge}`+e),b=JSON.parse(localStorage.getItem("Timers")),Y("smelt",b.SmeltingNoGold||5),window.location.reload())},init:function(){jQuery("#inv").after('\n                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n\n                        <fieldset id="gladbot-workbench" style="\n                        padding: 10px;\n                        margin: 10px 20px;\n                        text-align: center;\n                        display: flex;\n                        flex-direction: row;\n                        flex-wrap: wrap;\n                        align-items: center;\n                        justify-content: space-around;\n                        border: 2px solid darkred;\n                        border-radius: 8px;\n                        width: 235px;">\n                        <legend style="\n                            padding: 0 10px;\n                            color: darkred;\n                            font-weight: bold;">GLDbot Smeltery Area</legend>\n                        </fieldset>');
ha.gm("#gladbot-workbench",'<i class="fa fa-fire"></i>',"gladbot-button gladbot-smelter-button-smelt gladbot-stylish-button").mouseup(b=>{ha.Hm(b)});ha.gm("#gladbot-workbench","RESET","gladbot-button gladbot-smelter-button-reset gladbot-stylish-button").mouseup(()=>{localStorage.setItem("activateSmeltMode",!1)});jQuery("#gladbot-workbench").append('<p style="font-size: 0.8em; color: darkred;">Right click to reset smelt mode.</p>')},Hm:async function(){jQuery(document.body).addClass("fire-smelt-cursor");
jQuery(document.body).on("contextmenu",function(b){b.preventDefault();jQuery(document.body).removeClass("fire-smelt-cursor");jQuery(document.body).off("contextmenu");localStorage.setItem("activateSmeltMode",!1)});this.slots=await this.u();localStorage.setItem("activateSmeltMode",!0);jQuery("#inv .ui-draggable, #char .ui-draggable").off("mouseup.smelt").on("mouseup.smelt",async b=>{var c=b.target,e=c.className.match(/item-i-(\d+)-\d+/)[1];(b=this.slots.filter(h=>"closed"===h["forge_slots.state"])[0])?
(e={item:{type:e,name:Xb(c),quality:pb(c),slot:b,container:c.getAttribute("data-container-number")},spot:{bag:c.getAttribute("data-container-number"),x:c.getAttribute("data-position-x"),y:c.getAttribute("data-position-y")}},localStorage.setItem("smeltery_itemList1",JSON.stringify(e)),jQuery(c).parents("#char").length?setTimeout(()=>{},1E3):(this.slots=await this.u(),await this.jm(this.slots),this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>h["forge_slots.slot"]),c=c.getAttribute("data-item-id"),
e&&await ha.uo(b["forge_slots.slot"],c))):console.log("No free slot available")})},async u(){try{const b=await jQuery.post(S({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",a:(new Date).getTime(),sh:U("sh")});return JSON.parse(b).slots}catch(b){console.log(b)}},async Bm(b){if("undefined"!==typeof b){let e=[];for(var c=0;c<b.length;c++)if("undefined"!==typeof b[c]["forge_slots.uend"]){let h=1E3*b[c]["forge_slots.uend"];"finished-succeeded"===b[c]["forge_slots.state"]&&(h=0);e.push([h,
b[c].item.name])}localStorage.setItem("smelt.timer",JSON.stringify(e))}},async jm(b){const c="true"===localStorage.getItem("smeltLootbox");Array.isArray(b)&&(b=b.filter(e=>"finished-succeeded"===e.state).map(e=>e["forge_slots.slot"]),0<b.length&&!c?(await Promise.all(b.map(e=>ha.ko(e))),await this.u()):0<b.length&&c&&(await Promise.all(b.map(e=>ha.lo(e))),await this.u()))},async lo(b){return jQuery.post("ajax.php",{mod:"forge",submod:"lootbox",mode:"smelting",slot:b,a:(new Date).getTime(),sh:U("sh")})},
async ko(b){return jQuery.post("ajax.php",{mod:"forge",submod:"storeSmelted",mode:"smelting",slot:b,a:(new Date).getTime(),sh:U("sh")})},Lm(){var b=localStorage.getItem("smelt.timer");if(!b)return!0;b=JSON.parse(b).sort((c,e)=>c[0]-e[0]);return 6>b.length||b[0][0]+6E4<(new Date).getTime()},async pickItems(){C(`${d.He}`);ha.bag=document.getElementById("inv");ha.g=[];var b=JSON.parse(localStorage.getItem("smeltingSettings"))||[],c=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{},e=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||
"[]")),h=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]")),k=!1;for(var g of b){if(!g.isEnabled)continue;if("isUnderworldItem"!==g.condition&&2>g.prefix.length&&2>g.suffix.length)continue;let t=[];var l="";"nameContains"===g.condition&&2<g.prefix.length&&""!==g.prefix.trim()?l=g.prefix.trim():!g.prefix&&"nameContains"===g.condition&&2<g.suffix.length&&""!==g.suffix.trim()&&(l=g.suffix.trim());const A={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};g.colors&&0<
g.colors.length?g.colors.forEach(z=>{z=A[z];void 0!==z&&t.push(z)}):t=Object.values(A);var q=0,m=[];if(2<l.length){for(var n=1;2>=n;n++)m.push(this.Qm(n,t[0],l));l=await Promise.all(m);l=[].concat(...l);if(5<=q)break;for(let z of l){if(5<=q)break;l=z.item;m=Xb(z.item);ha.g.some(y=>y.id===z.id)||e.has(m)||h.has(m)||!this.Yl(l,g,b,c)||(ha.g.push({item:l,id:z.id,hammerState:g.hammerState||"none",matchingRule:g}),q++,k=!0)}if(5<=q)break}else if("isUnderworldItem"===g.condition){C("Looking for underworld items...This might take a while...");
for(var r of t){if(5<=q)break;l=await this.Xl(r);m=Math.min(l,10);for(n=new Set;n.size<m;)n.add(Math.floor(Math.random()*l)+1);for(var w of n){l=await this.Qm(w,r);for(var u of l)if(l=u.item,m=this.Yl(l,g))if(ha.g.push({item:l,id:u.id,hammerState:m.hammerState||"none",matchingRule:m}),q++,k=!0,5<=q)break;if(5<=q)break}}}}if(!k&&"true"===localStorage.getItem("smeltAnything")){b=c.itemTypes||[];e=c.hammerState||"none";const t={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};c=(c.colors||
[]).map(A=>t[A]);0===c.length&&(c=Object.values(t));h=0;g=await this.Xl(c[0]);for(q=1;q<=g&&!(5<=h);q++){r=await this.Xn(q,c[0]);for(let A of r){if(5<=h)break;r=A.item;w=Xb(r);const z=parseInt(pb(r),10);u=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]");l=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");if(!u.includes(w)&&!l.includes(w)){if(Fa.colors&&0<Fa.colors.length){const y={white:-1,green:0,blue:1,purple:2,orange:3,red:4};w=Object.keys(y).find(x=>y[x]===z);if(!Fa.colors.includes(w))continue}b.includes(r.getAttribute("data-content-type"))&&
(ha.g.push({item:r,id:A.id,hammerState:e}),h++,k=!0)}}if(5<=h)break}}k&&0<ha.g.length?await ha.move(ha.g):(C("No items found for smelting."),k=JSON.parse(localStorage.getItem("Timers")),Y("smelt",k.SmeltingNoItem||15),window.location.reload())},async ip(b,c){b=await jQuery.get(G({mod:"packages",f:"0",fq:c,qry:"",page:b,sh:U("sh")}));const e=[];jQuery(b).find(".packageItem").each((h,k)=>{h=k.querySelector("input").value;(k=jQuery(k).find(".ui-draggable")[0])&&e.push({id:h,item:k})});return e},Vn(b){return b.getAttribute("data-hammer-state")||
"none"},async Qm(b,c=null,e=""){b={mod:"packages",f:"0",page:b,sh:U("sh")};null!==c&&(b.fq=c);e&&""!==e.trim()&&(b.qry=e.trim());c=await jQuery.get(G(b));const h=[];jQuery(c).find(".packageItem").each((k,g)=>{k=g.querySelector("input").value;(g=jQuery(g).find(".ui-draggable")[0])&&h.push({id:k,item:g})});return h},async Xn(b,c=null,e=""){b={mod:"packages",f:"0",fq:null!==c?c:-1,page:b,sh:U("sh")};e&&""!==e.trim()&&(b.qry=e.trim());e=await jQuery.get(G(b));e=jQuery(e).find(".packageItem");const h=
[],k=(JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{}).itemTypes||[],g=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]"),l=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");e.each((q,m)=>{const n=m.querySelector("input").value;if(q=jQuery(m).find(".ui-draggable")[0]){m=Xb(q);var r=q.getAttribute("data-content-type");h.some(w=>w.id===n)||g.includes(m)||l.includes(m)||k.includes(r)&&h.push({item:q,id:n})}});return h},async Xl(b=null,c="",e="0"){b={mod:"packages",
f:e,fq:b||-1,qry:"",page:1,sh:U("sh")};c&&""!==c.trim()&&(b.qry=c.trim());c=await jQuery.get(G(b));b=jQuery(c).find(".paging_right_full");c=1;0<b.length&&(b=b.last().attr("href"))&&(b=b.match(/page=(\d+)(?!.*page=)/))&&b[1]&&(c=parseInt(b[1],10));return c},Yl(b){const c="true"===localStorage.getItem("smeltAnything"),e=JSON.parse(localStorage.getItem("smeltingSettings"))||[],h=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||[];if(!c&&!c&&0===e.length)return!1;const k=Xb(b),g=parseInt(b.getAttribute("data-level"),
10),l=Db(b),q=parseInt(pb(b),10);var m=this.Vn(b),n=b.getAttribute("data-basis");m=b.getAttribute("data-hash");b.getAttribute("data-level");n=Vb(n,m);m=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]");const r=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");if(m.includes(k)||r.includes(k))return!1;for(let w of e)if(m=w.hammerState||"none",w.isEnabled&&this.Kn(b,w,{itemName:k,itemLevel:g,itemType:l,itemQuality:q,itemHammerState:m,isUnderworldItem:n}))return w;if(c){if(h.itemTypes&&
0<h.itemTypes.length&&!h.itemTypes.map(w=>parseInt(w,10)).includes(parseInt(l,10)))return!1;if(h.colors&&0<h.colors.length){const w={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(w).find(u=>w[u]===q);if(!h.colors.includes(b))return!1}return h}return null},Kn(b,c,e){b=e.itemName;const h=e.itemLevel,k=e.itemType,g=e.itemQuality;e=e.isUnderworldItem;if("nameContains"===c.condition){e=!0;if(0===c.prefix.length&&0===c.suffix.length)return!1;c.prefix&&0<c.prefix.length&&b&&0<b.length&&
!b.toLowerCase().includes(c.prefix.toLowerCase())&&(e=!1);c.suffix&&0<c.suffix.length&&b&&0<b.length&&!b.toLowerCase().includes(c.suffix.toLowerCase())&&(e=!1);c.prefix&&0<c.prefix.length&&c.suffix&&0<c.suffix.length&&(!(b&&0<b.length)||b.toLowerCase().includes(c.prefix.toLowerCase())&&b.toLowerCase().includes(c.suffix.toLowerCase())||(e=!1));if(!e)return!1}else if("isUnderworldItem"===c.condition&&!e)return!1;if(!(h<(c.level?parseInt(c.level,10):0))&&c.itemTypes&&0<c.itemTypes.length){if(!c.itemTypes.includes("9999")&&
!c.itemTypes.map(l=>parseInt(l)).includes(parseInt(k,10)))return!1}else return!1;if(c.colors&&0<c.colors.length){const l={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(l).find(q=>l[q]===g);if(!c.colors.includes(b))return!1}else return!1;return c},gm:function(b,c,e){c=jQuery("<button>").html(c).addClass(e);jQuery(b).append(c);return c},async move(){var b="513";b=(b=localStorage.getItem("smeltTab"))?(513+parseInt(b,10)).toString():"513";this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>
h["forge_slots.slot"]).shift();try{let h=ha.g.pop();var c=Fc(ha.bag);let k=Gc(5,8,c),g=parseInt(h.item.getAttribute("data-measurement-x")),l=parseInt(h.item.getAttribute("data-measurement-y")),q=Hc(l,g,k);c=b;if(q){await jQuery.post(S({mod:"inventory",submod:"move",from:"-"+h.id,fromX:"1",fromY:"1",to:c,toX:q.x+1,toY:q.y+1,amount:"1"}),{a:(new Date).getTime(),sh:U("sh")});var e=jQuery(h.item).css({left:32*q.x,top:32*q.y});ha.bag.appendChild(e[0]);0<ha.g.length||h?(localStorage.setItem("smeltCheck.timeOut",
0),await new Promise(m=>setTimeout(m,500)),await this.move()):window.location.reload()}else 0<ha.g.length?(localStorage.setItem("smeltCheck.timeOut",0),await new Promise(m=>setTimeout(m,500)),await this.move()):window.location.reload()}catch(h){window.location.reload()}}};window.location.href.includes("index.php?mod=mysterybox")&&(Ph(),Qh());window.location.href.includes("/index.php?mod=forge&submod=smeltery")&&(ha.init(),ha.slots=await ha.u(),await ha.Bm(ha.slots),"true"==localStorage.getItem("activateSmeltMode")&&
ha.Hm());try{window.location.href.includes("/index.php?mod=location&submod=serverQuest")&&(window.location.href.includes("submod=serverQuestHighscore&loc=hadrians_wall")||localStorage.setItem("eventPoints_",parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10)))}catch{localStorage.setItem("doEventExpedition",!1);zh("mod=overview");return}try{if(window.location.href.includes("/index.php?mod=work")){let b=document.querySelector('span[data-ticker-type="countdown"]');
if(b){let c=b.innerText.split(":"),e=6E4*(60*parseInt(c[0],10)+parseInt(c[1],10));await new Promise(h=>setTimeout(h,e))}}}catch{zh("mod=overview");return}var rj={async start(){const b=await Promise.all([new Promise(c=>{jQuery.get(G({mod:"overview",doll:"1",sh:U("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");c(!e)})}),new Promise(c=>{jQuery.get(G({mod:"overview",doll:"2",sh:U("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");
c(!e)})})]);b[0]&&Y("CheckDolls",1);b[1]&&Y("CheckDolls",1)}},df={async check(b=!1){return new Promise(async c=>{await new Promise(e=>{jQuery.get(G({mod:"overview",doll:"1",sh:U("sh")}),h=>{localStorage.setItem("arenaCostumeEquiped",jQuery(h).find(".avatar")[0].classList.contains("avatar_costume_part"));e()})});b&&await b();c()})},async start(){if("mod=costumes"!=nf)zh("mod=costumes");else{let e=localStorage.getItem("costumeUnderworld"),h=localStorage.getItem("costumeUnderworld");const k="true"===
localStorage.getItem("wearUnderworld");var b=!1;let g=document.querySelectorAll(".costumes_box"),l=!1,q;const m=localStorage.getItem("costumeUnderworld");b=["9","10","11"];const n=JSON.parse(localStorage.getItem("underworld"));for(var c of b)try{const r=g[Number(c)-1].querySelector(".costumes_button_single").getAttribute("onclick");if(r&&!r.includes("dropCostume")){l=!0;break}}catch(r){}0<g.length&&null!==m&&(c=Number(m)-1,0<=c&&c<g.length&&(c=g[c].querySelector(".costumes_button_single")||g[c].querySelector(".costumes_button_active_single"))&&
(q=c.getAttribute("onclick")));["9","10","11"].includes(e)&&q&&q.includes("dropCostume")?(b=!0,n.oi=!0,localStorage.setItem("underworld",JSON.stringify(n)),Y("CheckDolls",15)):(b=!1,n.oi=!1,localStorage.setItem("underworld",JSON.stringify(n)));b?(Y("CheckDolls",30),window.location.reload()):await this.check(async()=>{let r=[];if(k){let w=0;const u=["9","10","11"];for(let t of u)try{const A=g[Number(t)-1].querySelector(".costumes_button_single")?.getAttribute("onclick");if(A&&!A.includes("dropCostume")){l=
!0;const z=Number(m)-1;0<=z&&z<g.length&&(l=g[z].querySelector(".costumes_button_single")||g[z].querySelector(".costumes_button_active_single")?!0:!1);if(l&&"9"===h&&2>=Number(Bh().Ka)){r.push({doll:1,setId:Number(h)+2});break}if(l&&"10"===h&&2>=Number(Bh().Ln)){r.push({doll:1,setId:Number(h)+2});break}if(l&&"11"===h){r.push({doll:1,setId:Number(h)+2});break}}}catch(A){w++}w===u.length&&C(`${d.le}`)}try{if(!l){const w=g[Number(localStorage.getItem("costumeBasic")-1)].querySelector("#costumes_button_left input"),
u=w.getAttribute("onclick");w.classList.contains("disabled")||u.includes("dropCostume")||r.push({doll:1,setId:localStorage.getItem("costumeBasic")});if(8>=Number(localStorage.getItem("costumeDungeon"))){const t=g[Number(localStorage.getItem("costumeDungeon")-1)].querySelector("#costumes_button_right input"),A=t.getAttribute("onclick");t.classList.contains("disabled")||A.includes("dropCostume")||r.push({doll:2,setId:localStorage.getItem("costumeDungeon")})}}if(0<r.length){let {doll:w,setId:u}={...r.pop()};
(await fetch(G({mod:"costumes",submod:"changeCostume",doll:w,setId:u,sh:U("sh")}))).ok&&0<r.length&&9>Number(u)&&await df.Om(r);Y("CheckDolls",30)}else Y("CheckDolls",15);window.location.reload()}catch{Y("CheckDolls",15),window.location.reload(),C("Problem occurred while wearing a costume.")}})}},async Om(b,c=!1){let {doll:e,setId:h}={...b.pop()};await new Promise(k=>{jQuery.get(G({mod:"costumes",submod:"changeCostume",doll:e,setId:h,sh:U("sh")}),()=>{0<b.length?df.Om(b,c):(Y("CheckDolls",15),k())})})}};
const z2=localStorage.getItem("we");we=new Date(z2);ea<new Date&&we<new Date&&ba!=wa&&gb();if(qa&&"true"===localStorage.getItem("guildBattleEnable")&&W("guildBattleEnable"))try{const b="true"===localStorage.getItem("guildBattleRandom"),c=JSON.parse(localStorage.getItem("guildKeywords"))||[],e=await jQuery.get(G({mod:"guild_warcamp",sh:U("sh")})),h=(new DOMParser).parseFromString(e,"text/html"),k=h.querySelectorAll('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]'),g=h.querySelectorAll("table.section-like tr:not(:first-child)");let l=null;0<g.length&&0<c.length?
g.forEach(q=>{const m=q.querySelector('td a[href*="mod=guild"]');q=q.querySelector('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]');if(m&&q){const n=m.textContent.trim().toLowerCase();c.some(r=>n.includes(r.toLowerCase()))&&(l=q.getAttribute("href"))}}):b&&(l=k[Math.floor(Math.random()*k.length)].getAttribute("href"));if(l){const q=new URLSearchParams(l),m=q.get("gid"),n=q.get("sh");try{await jQuery.post(G({mod:"guild_warcamp",submod:"guild_combat",gid:m,sh:n}),{combat:"Attack!"});C(`Guild attack initiated against guild ID: ${m}`);
const r=JSON.parse(localStorage.getItem("Timers"))||{};Y("guildBattleEnable",r.guildBattleEnable||120)}catch(r){C("Error initiating guild attack")}}else C("No matching guilds found for the provided guild names.")}catch(b){C("Error loading guild warcamp page")}if(qa&&"true"===localStorage.getItem("GuildEnable")&&W("GuildDonate")){const b=parseInt(localStorage.getItem("GuildDonateMore")||0,10),c=parseInt(localStorage.getItem("GuildDonateLess")||0,10),e=parseInt(localStorage.getItem("GuildDonateAmount")||
0,10);if(aa.gold>=b&&aa.gold<=c){await jQuery.post(G({mod:"guildBankingHouse",submod:"donate",sh:U("sh")}),{donation:e,doDonation:"Donate"});C(`${d.ne} ${e}.`);const h=JSON.parse(localStorage.getItem("Timers"));Y("GuildDonate",h.GuildDonate||5)}}"true"===localStorage.getItem("throwDice")&&W("throwDice")&&"true"==sessionStorage.getItem("autoGoActive")&&(jQuery.post(window.location.protocol+"//"+window.location.host+"/game/ajax/craps.php",{type:"1",a:(new Date).getTime(),sh:U("sh")}),C(`${d.me}`),Y("throwDice",
10));if(W("sortSettings")&&"true"==sessionStorage.getItem("autoGoActive")){const b=await jQuery.get(G({mod:"settings",submod:"gameSettings",sh:U("sh")})),c=(new DOMParser).parseFromString(b,"text/html").querySelector('select[name="packageSorting"]');let e="in_desc";if(c){const h=c.querySelector("option[selected]");e=h?h.value:"in_desc"}Y("sortSettings",30);localStorage.setItem("PackageSort",e)}if(window.location.href.includes("index.php?mod=location&loc=")){let b=0,c=!1;const e=()=>{fetch(window.location.href).then(m=>
m.text()).then(m=>{m=(new DOMParser).parseFromString(m,"text/html");if(m=Array.from(m.querySelectorAll("img[data-tooltip]")).find(n=>{const r=n.getAttribute("data-tooltip").toLowerCase();return["owned","sahip","propri","posiad","posees"].some(w=>r.includes(w))}))m=(m=m.getAttribute("data-tooltip").match(/(Owned|Sahip[^:]*|Propri[^:]*|Posiad[^:]*|Posees[^:]*): (\d+)/i))?parseInt(m[2],10):100,document.getElementById("hourglassesLeft").textContent=m,localStorage.setItem("hourglassesLeft",m)}).catch(()=>
{C("No hourglass left")})},h=(m,n,r,w,u,t)=>{function A(E){return new Promise((I,J)=>{fetch(`${y}/game/index.php?mod=premium&submod=inventory&sh=${x}`).then(K=>K.text()).then(K=>{if(K=(new DOMParser).parseFromString(K,"text/html").querySelector(`div.premiumfeature_picture > img[src*="${E}"] + .premiumfeature_tokencount`))return K.textContent.trim();throw Error("Token value not found!");}).then(K=>fetch(`${y}/game/index.php?mod=premium&submod=inventoryActivate&feature=${"5fd403b4efa8ea7bc3ca5a852bfce9"===
E?18:5}&token=${K}&sh=${x}`)).then(()=>{I()}).catch(K=>{J(K)})})}if(!c||b>=t)g();else{var z=new URL(window.location.href),y=z.origin,x=z.searchParams.get("sh")||"",v=document.getElementById("useLifePotion").checked;w=document.getElementById("useMobilizationExp2").checked;var D=parseInt(document.getElementById("healPercentage2").value,10);z=new URLSearchParams({mod:"location",submod:"attack",location:m,stage:n,premium:r?1:0,a:Date.now(),sh:x});fetch(`${y}/game/ajax.php?${z.toString()}`).then(E=>E.text()).then(()=>
{(v||w)&&fetch(window.location.href).then(E=>E.text()).then(async E=>{E=(new DOMParser).parseFromString(E,"text/html");if(v){const I=parseInt(E.getElementById("header_values_hp_percent").textContent,10);if(Number(I)<Number(D))return await A("5fd403b4efa8ea7bc3ca5a852bfce9")}if(w&&(E=E.getElementById("expeditionpoints_value_point").innerText,0===Number(parseInt(E.replace("%",""),10))))return await A("c9ce614bbc67a9e85aa0ee87cf2bb7")}).then(async()=>{b++;b>=Number(t)?(g(),window.location.reload()):
(document.getElementById("attacksPerformed").textContent=b,localStorage.setItem("attackCount",b),await e(),setTimeout(async()=>{await h(m,n,r,w,u,t)},1E3*u))}).catch(()=>{})})}},k=async()=>{c=!0;document.getElementById("startExpedition").style.display="none";document.getElementById("stopExpedition").style.display="block";const m=(new URLSearchParams(window.location.search)).get("loc"),n=document.getElementById("monsterSelection").value,r=document.getElementById("useHourglass").checked,w=document.getElementById("attackInterval").value,
u=document.getElementById("numberOfAttacks").value;await h(m,n,r,useMobilizationExp2,w,u)},g=()=>{c=!1;document.getElementById("startExpedition").style.display="block";document.getElementById("stopExpedition").style.display="none"},l=()=>{var m=document.createElement("div");m.innerHTML=`
    <div class="expedition-settings">
      <h2 class="section-header">${d.Bd}</h2>
      <div class="expedition-settings-content">
        <div>
            <label>${d.yd}: </label>
            <select id="monsterSelection">
            <option value="1">${d.qd}</option>
            <option value="2">${d.rd}</option>
            <option value="3">${d.sd}</option>
            <option value="4">${d.td}</option>
            </select>
            <br>
            <label>${d.md}: </label>
            <input type="checkbox" id="useHourglass">
            <br>
            <label>${d.pd}: </label>
            <input type="checkbox" id="useMobilizationExp2">
            <br>
            <label>${d.od}: </label>
            <input type="checkbox" id="useLifePotion">
            <br>
            <label>${d.ld}: </label>
            <input type="number" id="healPercentage2" value="25" min="1" max="99">
            <br>
            <label>${d.wd}: </label>
            <input type="number" id="numberOfAttacks" value="${document.getElementById("expeditionpoints_value_point").textContent||"0"}" min="1" max="36">
            <br>
            <label>${d.nd}: </label>
            <input type="number" id="attackInterval" value="5" min="1" max="60">
            <br>
            <button id="startExpedition" class="expedition-button">${d.zd}</button>
            <button id="resetAttacks" class="expedition-button reset-button">${d.xd}</button>
            <button id="stopExpedition" class="expedition-button" style="display: none;">${d.Ad}</button>
            <div id="attackLog"></div>
        </div>
      </div>
    </div>
  `;var n=document.querySelector(".section-header");n.parentNode.insertBefore(m,n);m.querySelector(".section-header").addEventListener("click",()=>{const r=document.querySelector(".expedition-settings-content"),w="none"===r.style.display;r.style.display=w?"block":"none";localStorage.setItem("expeditionSettingsHidden",w?"false":"true")});m=m.querySelector(".expedition-settings-content");n="true"===localStorage.getItem("expeditionSettingsHidden");m.style.display=n?"none":"block";document.getElementById("resetAttacks").addEventListener("click",
()=>{b=0;localStorage.removeItem("attackCount");document.getElementById("attacksPerformed").textContent=b});document.getElementById("startExpedition").addEventListener("click",k);document.getElementById("stopExpedition").addEventListener("click",g);b=parseInt(localStorage.getItem("attackCount")||"0");document.getElementById("attackLog").innerHTML=`
            ${d.jd}: <span id="attacksPerformed">${b}</span><br>
            ${d.kd}: <span id="hourglassesLeft">${localStorage.getItem("hourglassesLeft")||"0"}</span><br>
            <span class="span-new">${d.ud}</span><br>
            <span class="span-new">${d.vd}</span>

            `};if(window.location.href.includes("index.php?mod=location&loc=")&&!window.location.href.includes("location&loc=nile_bank")&&!window.location.href.includes("index.php?mod=location&loc=false")&&!window.location.href.includes("location&loc=desert")){const m=document.querySelector("#wrapper_game.underworld");(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld||m||l()}const q=document.createElement("style");q.innerHTML="\n  .expedition-settings {\n    border: 2px solid #4CAF50;\n    padding: 10px;\n    margin: 10px 0;\n    background-color: #d3c195;\n    border-radius: 5px;\n  }\n  .expedition-button {\n    border: none;\n    padding: 10px 20px;\n    text-align: center;\n    text-decoration: none;\n    display: inline-block;\n    font-size: 16px;\n    margin: 10px;\n    background-color: #a09270;\n    cursor: pointer;\n    border-radius: 5px;\n  }\n\n  .reset-button {\n    background-color: #f44336; /* Red color */\n  }\n\n  .expedition-button:disabled {\n    background-color: #ccc;\n    cursor: not-allowed;\n  }\n";
document.head.appendChild(q)}if(window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&submod=showDungeons")||window.location.href.includes("index.php?mod=reports&submod=showArena")||window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")){let b=document.createElement("div");b.id="ReportSearchUI";b.innerHTML='\n        <div class="setting-row">\n            <h5>GLDbot - Search in Reports</h5>\n            <span>Searches for reports containing the specified keyword and gold amount. Limit 15 pages.</span>\n            <br>\n            <div class="input-container">\n                <input type="text" id="searchReports" placeholder="Enter keyword">\n                <input type="number" id="goldFilter" placeholder="Minimum gold">\n                <button class="awesome-button" id="searchReportsButton">Search</button>\n            </div>\n        </div>\n    ';
const c=document.querySelector("#content");c.insertBefore(b,c.firstChild);document.getElementById("searchReportsButton").addEventListener("click",async()=>{const g=document.getElementById("searchReports").value,l=parseInt(document.getElementById("goldFilter").value,10)||0,q=document.getElementById("searchReportsButton");q.disabled=!0;try{await e(g,l)}finally{q.disabled=!1}});async function e(g,l){let q=1;var m=await jQuery.get(window.location.href);m=jQuery(m).find(".paging_right_full");0<m.length&&
(m=m.last().attr("href"))&&(m=m.match(/page=(\d+)(?!.*page=)/))&&m[1]&&(q=parseInt(m[1],10));m=[];for(let r=1;r<=q&&15>=r;r++){var n=await h(r);n=k(n,g,l);0<n.length&&(m=m.concat(n))}if(0<m.length){const r=document.querySelector(".table-container tbody");r.innerHTML="";m.forEach(w=>{r.appendChild(w)})}}async function h(g){let l="";window.location.href.includes("index.php?mod=reports&submod=showArena")?l="showArena":window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")?l="showCircusTurma":
window.location.href.includes("index.php?mod=reports&submod=showDungeons")?l="showDungeons":window.location.href.includes("index.php?mod=reports&showExpeditions")&&(l="showExpeditions");g=G({mod:"reports",submod:l,page:g,sh:U("sh")});return await jQuery.get(g)}function k(g,l,q){let m=[];jQuery(g).find(".table-container tr").each((n,r)=>{var w=jQuery(r);n=window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&showDungeons")?w.find("td").eq(1).text().trim():
w.find("td").eq(1).find("a").first().text().trim();w=w.find("td").eq(2).text().trim().replace(/[.,]/g,"");w=parseInt(w,10)||0;n.toLowerCase().includes(l.toLowerCase())&&w>=q&&m.push(r)});return m}}if(window.location.href.includes("/index.php?mod=overview&doll=2")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(c=>Xb(c));localStorage.setItem("mercenaryEquipmentIDs",JSON.stringify(b))}else if(window.location.href.includes("/index.php?mod=overview")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(c=>
Xb(c));localStorage.setItem("playerEquipmentIDs",JSON.stringify(b))}if(window.location.href.includes("/index.php?mod=inventory&sub")&&document.querySelector('td[valign="top"]')){let b=!0;async function c(){var n=document.getElementById("sortCriteria");let r=Array.from(n.selectedOptions).map(A=>A.value),w=document.getElementById("shop");n=Array.from(w.querySelectorAll(".ui-draggable")).map(A=>{let z=Xb(A),y=parseInt(A.getAttribute("data-level"),10)||0,x=A.getAttribute("data-basis")||"",v=parseInt(x.split("-")[1],
10)||0,D=parseInt(A.getAttribute("data-quality"),10)||0,E=parseInt(A.getAttribute("data-content-type"),10)||0,I=parseInt(A.getAttribute("data-measurement-x"),10)||1,J=parseInt(A.getAttribute("data-measurement-y"),10)||1;return{element:A,name:z,level:y,dc:x,type:E,Nm:v,quality:D,measurementX:I,measurementY:J,wp:parseInt(A.getAttribute("data-position-x"),10),xp:parseInt(A.getAttribute("data-position-y"),10)}});n.sort((A,z)=>{for(let y of r){let x;switch(y){case "name":x=A.name.localeCompare(z.name);
break;case "level":x=A.level-z.level;break;case "data-basis":x=A.Nm-z.Nm;break;case "quality":x=A.quality-z.quality;break;case "type":x=A.type-z.type;break;default:x=0}if(0!==x)return x}return 0});let u=0,t=0;for(let A of n)A.element.setAttribute("data-position-x",u+1),A.element.setAttribute("data-position-y",t+1),A.element.style.left=`${32*u}px`,A.element.style.top=`${32*t}px`,u+=A.measurementX,6<=u&&(u=0,t+=1);w.innerHTML="";n.forEach(A=>{w.appendChild(A.element)})}(function(){let n=`
                <section class="merchant-settings" style="display: block;">
                    <div class="sorting-options">
                        <label for="sortCriteria">Sort Items By:</label>
                        <select id="sortCriteria">
                            <option value="name">Name</option>
                            <option value="level">Level</option>
                            <option value="data-basis">Base</option>
                            <option value="type">Type</option>
                            <option value="quality">Quality</option>
                        </select>
                        <button class="awesome-button" type="button" id="sortItemsButton">Sort Items</button>
                        
                    </div>
                    <p>
                    <div class="actions">
                        <button class="awesome-button" type="button">${d.Cj}</button>
                        <button class="awesome-button" type="button">${d.Dj}</button>
                        <button class="awesome-button" type="button">Buy All</button>
                        <button class="awesome-button" type="button">Buy 10</button>
                    </div>
                    <ul class="compact-list">
                        <li><input type="checkbox" id="chkWeapons"><label for="chkWeapons">${d.ka}</label></li>
                        <li><input type="checkbox" id="chkShields"><label for="chkShields">${d.ha}</label></li>
                        <li><input type="checkbox" id="chkChestArmour"><label for="chkChestArmour">${d.Z}</label></li>
                        <li><input type="checkbox" id="chkHelmets"><label for="chkHelmets">${d.ca}</label></li>
                        <li><input type="checkbox" id="chkGloves"><label for="chkGloves">${d.ba}</label></li>
                        <li><input type="checkbox" id="chkShoes"><label for="chkShoes">${d.ia}</label></li>
                        <li><input type="checkbox" id="chkRings"><label for="chkRings">${d.fa}</label></li>
                        <li><input type="checkbox" id="chkAmulets"><label for="chkAmulets">${d.Y}</label></li>
                        <li><input type="checkbox" id="chkUsable"><label for="chkUsable">${d.jh}</label></li>
                        <li><input type="checkbox" id="chkUpgrades"><label for="chkUpgrades">${d.ih}</label></li>
                        <li><input type="checkbox" id="chkRecipes"><label for="chkRecipes">${d.Nf}</label></li>
                        <li><input type="checkbox" id="chkMercenary"><label for="chkMercenary">${d.bf}</label></li>
                        <li><input type="checkbox" id="chkScroll"><label for="chkScroll">Scroll</label></li>
                        <li><input type="checkbox" id="chkReinforcements"><label for="chkReinforcements">${d.Pf}</label></li>
                    </ul>
                </section>
                `;document.getElementById("inv").insertAdjacentHTML("afterend",n)})();async function e(){if(b){var n=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(r=>{r=r.getAttribute("data-content-type");if(document.getElementById("chkWeapons").checked&&"2"==r||document.getElementById("chkShields").checked&&"4"==r||document.getElementById("chkChestArmour").checked&&"8"==r||document.getElementById("chkHelmets").checked&&"1"==r||document.getElementById("chkGloves").checked&&"256"==
r||document.getElementById("chkShoes").checked&&"512"==r||document.getElementById("chkRings").checked&&"48"==r||document.getElementById("chkAmulets").checked&&"1024"==r||document.getElementById("chkUsable").checked&&"4096"==r||document.getElementById("chkUpgrades").checked&&"4096"==r||document.getElementById("chkRecipes").checked&&"8192"==r||document.getElementById("chkMercenary").checked&&"16384"==r||document.getElementById("chkScroll").checked&&"64"==r||document.getElementById("chkReinforcements").checked&&
"4096"==r)return!0;if(b)return!1});for(let r=0;r<n.length&&b;r++)await new Promise(w=>setTimeout(w,200)),Ca(n[r],"shop")}}async function h(){if(b){var n=document.querySelectorAll("#inv .ui-draggable");for(let r=0;r<n.length;r++)await new Promise(w=>setTimeout(w,200)),Ca(n[r],"shop")}}async function k(){if(b){var n=document.querySelectorAll("#shop .ui-draggable");for(let r=0;r<n.length;r++)await new Promise(w=>setTimeout(w,200)),Ca(n[r],"inv")}}async function g(){if(b){var n=document.querySelectorAll("#shop .ui-draggable");
for(let r=0;10>r;r++)await new Promise(w=>setTimeout(w,200)),Ca(n[r],"inv")}}let l=document.querySelector(".actions .awesome-button:nth-child(2)"),q=document.querySelector(".actions .awesome-button:nth-child(3)"),m=document.querySelector(".actions .awesome-button:nth-child(4");document.querySelector(".actions .awesome-button:nth-child(1)").addEventListener("click",async()=>{b=!0;await new Promise(n=>setTimeout(n,500));h()});l.addEventListener("click",async()=>{b=!0;await new Promise(n=>setTimeout(n,
500));e()});q.addEventListener("click",async()=>{await new Promise(n=>setTimeout(n,500));k()});m.addEventListener("click",async()=>{await new Promise(n=>setTimeout(n,500));g()});document.getElementById("sortItemsButton").addEventListener("click",async()=>{await new Promise(n=>setTimeout(n,500));await c()})}if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll"))if(bf=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),
ub=bf.textContent.trim(),2<ub.length){cf=document.getElementById("char");function b(c,e,h,k){var g=document.createElement("a");g.className="gladbot-button gladbot-"+c;g.textContent=e;g.setAttribute("data-tooltip",h);cf.appendChild(g);(JSON.parse(localStorage.getItem(k))||[]).includes(ub)&&(g.classList.add("added"),g.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));g.addEventListener("click",function(){var l=ub,q=JSON.parse(localStorage.getItem(k))||[],m=q.indexOf(l);
-1!==m?(q.splice(m,1),g.classList.remove("added"),g.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(q.push(l),g.classList.add("added"),g.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));localStorage.setItem(k,JSON.stringify(q))})}b("arena","A","GladB: Add to Arena List","autoAttackList");b("circus","C","GladB: Add to Circus List","autoAttackCircusList")}var Oc=JSON.parse(localStorage.getItem("smeltingSettings"))||[],Fa=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||
{itemTypes:[],colors:[],hammerState:"none",enabled:!1},ec=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]};"true"==localStorage.getItem("pauseBotEnable")&&W("pauseBot")&&(sessionStorage.setItem("autoGoActive","false"),localStorage.setItem("pauseBotEnable","false"),alert("Bot has been paused!"),window.location.reload());1==qa&&W("storeForgeResources")&&Xi();!0===qa&&W("Training")&&"true"==localStorage.getItem("trainEnable")&&Zi()&&Yi();"true"===sessionStorage.getItem("autoGoActive")&&ab.href.includes("submod=showCombatReport")&&
$i();if("true"===localStorage.getItem("HighlightUnderworldItems")){function b(e){e.querySelectorAll("div[data-basis]").forEach(h=>{const k=h.getAttribute("data-basis"),g=h.getAttribute("data-hash");h.getAttribute("data-level");null!=k&&Vb(k,g)&&(h.style.boxShadow="0 0 0.1px 2px red")})}b(document);const c=new MutationObserver(e=>{e.forEach(h=>{h.addedNodes&&h.addedNodes.forEach(k=>{1===k.nodeType&&b(k)})});c.disconnect()});c.observe(document.body,{childList:!0,subtree:!0});document.querySelectorAll(".awesome-tabs").forEach(e=>
{e.addEventListener("click",()=>{setTimeout(()=>{b(document)},500)})})}if("true"==localStorage.getItem("AutoAuction")){const b=JSON.parse(localStorage.getItem("searchTerms")||"[]"),c=JSON.parse(localStorage.getItem("SearchTypes")||"[]"),e=JSON.parse(localStorage.getItem("Timers")),h=new DOMParser;function k(m,n,r){let w=[],u=[];Array.from(m).forEach(t=>{const A=t.getAttribute("data-tooltip");var z=t.getAttribute("data-content-type");const y=t.getAttribute("data-quality"),x=n.some(v=>{const D=Ze(A);
return D?D.toLowerCase().split(/\s+/).includes(v.toLowerCase()):!1});z=r.includes("9999")||r.includes(z);"2"==y||"3"==y?u.push(t):x&&z&&w.push(t)});return{mn:w,pn:u}}if(W("ShopSearch")){const m=await Hf();let n=[],r=[];for(const t of m){const A=k(t.querySelectorAll("#shop .ui-draggable"),b,c);A.mn.forEach(z=>{z.setAttribute("data-original-url",t.zm)});A.pn.forEach(z=>{z.setAttribute("data-original-url",t.zm)});n=n.concat(A.mn);r=r.concat(A.pn)}const w=n.map(t=>t.outerHTML);localStorage.setItem("MatchingShopItems",
JSON.stringify(w));const u=r.map(t=>t.outerHTML);localStorage.setItem("UniqueShopResults",JSON.stringify(u));Y("ShopSearch",e.SearchTimer||5)}if(W("AuctionSearch")){const m=await dh(),n=await dh(3),r=t=>Array.from(t.querySelectorAll('#auction_table [class^="item-i-"]')).filter(A=>{const z=A.getAttribute("data-tooltip");var y=A.getAttribute("data-content-type");A=b.some(x=>{const v=Ze(z);return v?v.toLowerCase().split(/\s+/).includes(x.toLowerCase()):!1});y=c.includes("9999")||c.includes(y);return A&&
y}),w=r(m);localStorage.setItem("MatchingAuctionItems",JSON.stringify(w.map(t=>t.outerHTML)));const u=r(n);localStorage.setItem("MatchingMercAuctionItems",JSON.stringify(u.map(t=>t.outerHTML)));Y("AuctionSearch",e.SearchTimer||5)}function g(m,n,r){const w=document.createElement("div");w.setAttribute("id",r);w.classList.add("search_results_panel");var u=document.createElement("div");u.classList.add("panel-header");u.innerHTML=`<h2>${m}</h2>`;w.appendChild(u);w.style.cssText="\n                position: fixed;\n                left: 0;\n                top: 0;\n                width: 300px;\n                height: 400px; /* Set a default height */\n                overflow-y: auto; /* Allow both vertical and horizontal scrolling if needed */\n                overflow-x: hidden;\n                z-index: 500;\n                box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n                font-family: 'Arial', sans-serif;\n                background: rgba(221, 213, 180, 0.95);\n                background-size: cover;\n                border-radius: 8px;\n            ";
m=w.querySelector(".panel-header");m.style.cssText=`
                background-color: ${"auction_items_panel"===r?"#bead79":"#8b6a45"};
                padding: 10px;
                cursor: move; /* Set cursor to move only on the header */
                user-select: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            `;m.querySelector("h2").style.cssText="\n                margin: 0;\n                font-size: 16px;\n                color: #fff;\n            ";m=localStorage.getItem(`${r}_top`);u=localStorage.getItem(`${r}_left`);let t=localStorage.getItem(`${r}_width`),A=localStorage.getItem(`${r}_height`);m&&u?(w.style.top=m+"px",w.style.left=u+"px"):"auction_items_panel"===r?(w.style.top="50px",w.style.left="20px"):"shop_items_panel"===r&&(w.style.top="50px",w.style.left="350px");t&&(w.style.width=
t+"px");A&&(w.style.height=A+"px");q(w,r);n=l(n);w.appendChild(n);document.body.appendChild(w);w.style.maxHeight=`${window.innerHeight-100}px`}function l(m){const n=document.createElement("div");n.classList.add("items-container");m.forEach(({key:r,label:w})=>{const u=document.createElement("div");u.classList.add("section-header");u.textContent=w;n.appendChild(u);const t=document.createElement("div");t.classList.add("grid-container");t.style.display="grid";t.style.gridTemplateColumns="repeat(auto-fill, minmax(50px, 1fr))";
t.style.kp="5px";t.style.padding="10px";w=localStorage.getItem(r);(JSON.parse(w)||[]).forEach(A=>{const z=h.parseFromString(A,"text/html").body.firstChild.cloneNode(!0);z.style.left="";z.style.top="";z.style.position="relative";A=z.getAttribute("data-tooltip");var y=JSON.parse(A.replace(/&quot;/g,'"'));A=y[0][0][1].split(";")[0];const x=encodeURIComponent(y[0][0][0].split(" ")[0]);y=new URL(window.location.href);const v=y.origin,D=y.searchParams.get("sh")||"";y=document.createElement("div");y.classList.add("auction_item_div");
y.appendChild(z);y.style.border="2px solid "+A;y.style.borderRadius="4px";y.style.padding="2px";y.style.boxSizing="border-box";y.style.cursor="pointer";y.style.transform="scale(0.8)";y.addEventListener("click",()=>{var E=z.getAttribute("data-hash");localStorage.setItem("highlightedItemHash",E);if(["UniqueShopResults","MatchingShopItems"].includes(r)){if(E=z.getAttribute("data-original-url"))location.href=E}else E=`${v}/game/index.php?mod=auction&qry=${x}&itemLevel=1&itemType=0&itemQuality=-1&sh=${D}`,
"MatchingMercAuctionItems"===r&&(E+="&ttype=3"),location.href=E});t.appendChild(y)});n.appendChild(u);n.appendChild(t)});return n}function q(m,n){const r=m.querySelector(".panel-header");$(m).draggable({handle:r,Wo:"window",stop:function(w,u){localStorage.setItem(`${n}_top`,u.position.top);localStorage.setItem(`${n}_left`,u.position.left)}});$(m).resizable({lp:"n, e, s, w, ne, se, sw, nw",stop:function(w,u){localStorage.setItem(`${n}_width`,u.size.width);localStorage.setItem(`${n}_height`,u.size.height)}})}
(function(){document.querySelectorAll(".search_results_panel").forEach(m=>m.remove());g(`${d.Va}`,[{key:"MatchingAuctionItems",label:`${d.Va}`},{key:"MatchingMercAuctionItems",label:`${d.af}`}],"auction_items_panel");g(`${d.Ub}`,[{key:"MatchingShopItems",label:`${d.Ub}`},{key:"UniqueShopResults",label:`${d.hh}`}],"shop_items_panel")})()}if(document.hidden)try{chrome.runtime.sendMessage({bn:!0,im:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"})}catch(b){}var sj=btoa("autoGoActive"),
tj=btoa("false");await async function(){"d12b94927fcd8ca07326037c04f41968347b9cc3b46cb2852eb198ffbb09a7e0"!==await aj(ma)&&sessionStorage.setItem(atob(sj),atob(tj))}();setInterval(()=>{const b=JSON.parse(localStorage.getItem("timeConditions"))||[];var c="true"===localStorage.getItem("botPaused");if(b&&0<b.length&&!c&&Jc()){c=new Date;const e=`${String(c.getHours()).padStart(2,"0")}:${String(c.getMinutes()).padStart(2,"0")}`;b.forEach(h=>{h.start&&h.end&&(h.start>h.end?e>=h.start||e<=h.end:e>=h.start&&
e<=h.end)&&("stop"===h.action?sessionStorage.setItem("autoGoActive","false"):"start"===h.action&&"false"===sessionStorage.getItem("autoGoActive")&&(sessionStorage.setItem("autoGoActive","true"),$e()))})}},15E3);var Sb=(new Date).getTime();if(!wa!==Kc){"true"===localStorage.getItem("activateAuction2")&&mf();var ef={Im(b){let c=localStorage.getItem("MarketboughtItems");c?c=JSON.parse(c):c=[];c.push(b);localStorage.setItem("MarketboughtItems",JSON.stringify(c))},Op(){var b=localStorage.getItem("boughtItems");
b?b=JSON.parse(b):b=[];let c=document.getElementById("boughtItems");for(;c.firstChild;)c.removeChild(c.firstChild);for(let e of b)b=document.createElement("option"),b.textContent=e,c.appendChild(b)},async En(){var b=new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=parseInt(localStorage.getItem("MarketHoldGold"))||0;let h=localStorage.getItem("marketItems");h=h?JSON.parse(h):[];const k={No:"1",Jo:"2",Bo:"3",Eo:"4",Do:"5",Ko:"8",Ho:"6",zo:"9",Mo:"7",Ao:"11",Lo:"12",Go:"13",
Fo:"15",Co:"18",Uo:"19",Io:"20"},g={yn:"-1",sn:"0",qn:"1",un:"2",tn:"3",vn:"4"};C(`${d.ke}`);const l={};if("true"===localStorage.getItem("marketOnlyFood"))c=await this.Pm(c,e,"-1"),await this.cn([],7,1,c,b);else{for(var q of h){const m=`${k[q.itemType]||"0"}-${g[q.am]||"0"}`;l[m]||(l[m]=[]);l[m].push(q)}q=h.map(m=>g[m.am]||"0");q=Math.min(...q);c=await this.Pm(c,e,q);for(const [m,n]of Object.entries(l)){const [r,w]=m.split("-");await this.cn(n,r,w,c,b)}}},async Pm(b,c,e){const h="true"===localStorage.getItem("marketOnlyFood");
let k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=0&fq=${e}`;h&&(k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=7&fq=${e}`);c=await fetch(k).then(y=>y.text());b=new DOMParser;e=b.parseFromString(c,"text/html").querySelector(".standalone");c=1;e&&(c=parseInt(e.textContent.split("/")[1],10));e=[];const g=localStorage.getItem("MarketMaxFoodPrice")||1E5,l=localStorage.getItem("MarketMaxPerFoodPrice")||1E3,q=localStorage.getItem("MarketMinItemLevel")||1;let m=0;for(let y=
1;y<=c;y++){var n=`${k}&p=${y}`;await new Promise(x=>setTimeout(x,250));n=await (await fetch(n)).text();await new Promise(x=>setTimeout(x,250));n=b.parseFromString(n,"text/html").querySelectorAll("#market_item_table tr");for(let x of n){var r=x.querySelectorAll("td");if(r&&0<r.length&&(n=r[0].querySelector("div"))){var w=Db(n),u=pb(n),t=Xb(n),A=Eb(n);let v=n.getAttribute("data-item-id"),D=n.getAttribute("data-soulbound-to");r=parseInt(r[2].innerText.replace(/\./g,""),10);var z=parseInt(n.getAttribute("data-amount"),
10)||1;z=r/z;if(h&&"64"===w&&r<=l&&(!D||null===D)&&Number(A)>=Number(q)){if(m+r>g)break;m+=r;e.push({itemRarity:u,itemName:t,itemDataId:v,itemSoulbound:D,itemPrice:r,pricePerItem:z,page:y})}else h||(w=pb(n),u=Xb(n),t=n.getAttribute("data-item-id"),A=n.getAttribute("data-soulbound-to"),n=parseInt(n.getAttribute("data-amount"),10)||1,e.push({itemRarity:w,itemName:u,itemDataId:t,itemSoulbound:A,itemPrice:r,pricePerItem:r/n,page:y}))}}if(h&&m>=g)break}return e},async cn(b,c,e,h,k){for(const g of h){const l=
g.itemName;h=g.itemDataId;const q=g.itemSoulbound,m=g.itemPrice,n=g.pricePerItem,r=g.page,w={yn:"-1",sn:"0",qn:"1",un:"2",tn:"3",vn:"4"},u=localStorage.getItem("usePacks")||"false";"true"===localStorage.getItem("marketOnlyFood")?aa.gold>=m+k&&(!q||null===q)&&await jQuery.get(G({}),{mod:"market",buyid:h,sh:U("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}).then(t=>{t=(new DOMParser).parseFromString(t,"text/html").getElementById("sstat_gold_val").innerText;t=parseInt(t.replace(/\./g,""),10);
if(document.getElementById("sstat_gold_val").innerText=t)aa.gold=t;ef.Im(l);C(`Bought ${l} for ${m} gold`)}):b.some(t=>{const A=w[t.am]||"0";return l.trim().toLowerCase().includes(t.Vm.trim().toLowerCase())&&e==A&&aa.gold>=m+k&&(!q||null===q||"BuySoulbound"===t.Soulbound&&q||"DontBuySoulbound"===t.Soulbound&&!q)&&(Number(t.maxPrice)>=m||"true"==u&&Number(t.maxPrice)>=n&&aa.gold>=m)})&&await jQuery.get(G({}),{mod:"market",buyid:h,sh:U("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}).then(t=>
{t=(new DOMParser).parseFromString(t,"text/html").getElementById("sstat_gold_val").innerText;t=parseInt(t.replace(/\./g,""),10);if(document.getElementById("sstat_gold_val").innerText=t)aa.gold=t;ef.Im(l);C(`Bought ${l} for ${m} gold`)})}C(`${d.yb} in Market`)}};(window.location.href.includes("/index.php?mod=forge&submod=workbench")||window.location.href.includes("/index.php?mod=forge&doll=1&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=2&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=3&submod=workbench")||
window.location.href.includes("index.php?mod=forge&doll=4&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=5&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=6&submod=workbench"))&&cj();var uj={async start(){try{const b=sa.repairArena,c=sa.repairTurma;let e=this.F(),h=this.Un(e),k=this.Zm("itemList1"),g=this.Zm("itemList2");const l=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];h?(await this.u(),await this.no(h,l)):b&&0<k.length?await this.Rm("mod=overview&doll=1",
sa.itemList1):c&&0<g.length&&await this.Rm("mod=overview&doll=2",sa.itemList2)}catch(b){this.handleError()}},F(){let b=localStorage.getItem("workbenchItem");return b?JSON.parse(b):{selectedItem:{}}},Un(b){try{return b.selectedItem&&0<Object.keys(b.selectedItem).length?b.selectedItem:!1}catch(c){return null}},Zm(b){return(b=localStorage.getItem(b))?this.so(b):[]},so(b){try{let c=JSON.parse(b);return Array.isArray(c)&&c.every(e=>void 0===e)?[]:c}catch(c){return[]}},async Rm(b,c){nf!==b?zh(b):(await this.u(),
0<this.F().spaces?await this.$l(c):this.jn("workbench"))},jn(b){"space"===b?C("Not enough inventory space for repair. Retrying in 10 minutes."):"workbench"===b?C("Not enough empty slots in workbench. Retrying in 10 minutes."):"material"===b?C(`${d.sb}`):C("Repair: Retrying in 10 minutes.");b=JSON.parse(localStorage.getItem("Timers"));Y("repair",b.Repair||10);window.location.reload()},async no(b,c,e){switch(b.status){case "toWorkbench":await this.Ki(b.iid);break;case "toFillGoods":0<c.length&&e.workbenchneededitems?
await this.Jh(b.slot,-1,e.workbenchneededitems):await this.ec(b.slot);break;case "toPackage":await this.mc(b.slot);break;case "toBag":await this.La();break;case "toInv":await this.Pl();break;case "workbenchToBag":await this.xm(b.slot)}},handleError(){localStorage.removeItem("workbenchItem");const b=JSON.parse(localStorage.getItem("Timers"));Y("repair",b.Repair||10);window.location.reload()},async u(){try{const b=await jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),
sh:U("sh")});let c=this.F();c.slots=JSON.parse(b).slots;c.spaces=c.slots.filter(e=>"closed"===e["forge_slots.state"]).length;c.freeSlots=c.slots.filter(e=>"closed"===e["forge_slots.state"]);localStorage.setItem("workbenchItem",JSON.stringify(c))}catch(b){}},async $l(b){try{let c=b.shift();C(`${d.Be}${c.name}`);C(`${d.Ba}`);let {spot:e,bag:h}=await ic(c.Wm,c.Xm);const k=await jQuery.post(S({}),{mod:"inventory",submod:"move",from:c.container,fromX:1,fromY:1,to:h,toX:e.x+1,toY:e.y+1,amount:1,doll:c.doll,
a:(new Date).getTime(),sh:U("sh")});let g=this.F();g.selectedItem||(g.selectedItem={});Object.assign(g.selectedItem,{item:c,iid:JSON.parse(k).to.data.itemId,status:"toWorkbench",spot:e,bag:h});localStorage.setItem("workbenchItem",JSON.stringify(g));await this.Ki(JSON.parse(k).to.data.itemId)}catch{C("Error repairing the item."),localStorage.setItem("workbenchItem",JSON.stringify({})),window.location.reload()}},async Ki(b){try{C(`${d.Ab}`);let c=this.F(),e=0;for(let k of c.slots||[])if("closed"===
k["forge_slots.state"]){e=k["forge_slots.slot"];break}const h=await jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:e,iid:b,amount:1,a:(new Date).getTime(),sh:U("sh")});c.slots=JSON.parse(h).slots;c.spaces=0;c.freeSlots=[];for(let k of c.slots)"closed"===k["forge_slots.state"]&&(c.spaces++,c.freeSlots.push(k));e=c.freeSlots.shift()["forge_slots.slot"];c.workbenchneededitems=JSON.parse(h).slots[e].formula.needed;localStorage.setItem("workbenchItem",JSON.stringify(c));
Object.assign(c.selectedItem,{slot:e,status:"toFillGoods"});await this.qo(e,b)}catch(c){C("Error moving the item to the workbench."+c),window.location.reload()}},async qo(b,c){await jQuery.post(S({}),{mod:"forge",submod:"rent",mode:"workbench",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:U("sh")});c=this.F();Object.assign(c.selectedItem,{slot:b,status:"toFillGoods"});localStorage.setItem("workbenchItem",JSON.stringify(c));0<(JSON.parse(localStorage.getItem("ignoredMaterials"))||[]).length?await this.Jh(b,
-1,c.workbenchneededitems):await this.ec(b)},async Jh(b,c,e){c=[];const h=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let k in e){const g=parseInt(k,10);0<e[k].amount&&!h.some(l=>parseInt(l,10)+18E3===g)&&c.push({type:g,amount:e[k].amount})}await this.rl(c,-1,b);await jQuery.post(S({mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")}));e=this.F();e.selectedItem.status="toPackage";localStorage.setItem("workbenchItem",JSON.stringify(e));await this.mc(b)},
async rl(b,c=-1,e){let h=!0;for(let g=0;g<b.length;g++){let l=c,q=!1,m=b[g].amount;b[g].type=b[g].type-18E3;let n=await this.Wn(b[g].type);const r=Number(localStorage.getItem("repairMaxQuality"));for(;l<=r;){var k=n[l]||0;if(0===k)l++;else{k=Math.min(m,k);m-=k;try{if(await jQuery.post(S({mod:"forge",submod:"storageOut",type:b[g].type,quality:l,amount:k,a:(new Date).getTime(),sh:U("sh")})),await this.sl(b[g].type,l,e,k),q=!0,0>=m)break}catch(w){if(l++,l>r){h=!1;break}}}}if(!q||0<m)h=!1}return h},async Wn(b){let c=
{};try{const e=await jQuery.get(G({mod:"forge",submod:"storage",sh:U("sh")})),h=jQuery("<div>").append(e).find("#resource-amount").attr("data-max");if(h){const k=JSON.parse(h.replace(/&quot;/g,'"'));k[b]&&(c=k[b])}console.log("Quantities for type",b,":",c)}catch(e){console.error("Failed to fetch material quantities:",e)}return c},async sl(b,c,e,h){let k=1,g=!1,l=this.F(),{bag:q,spot:m}=l.selectedItem||{};for(;!g&&5>=k;)try{const n=await jQuery.get(G({mod:"packages",f:18,fq:c,qry:"",page:k,sh:U("sh")})),
r=jQuery(n).find(".packageItem");0===r.length?k++:(r.each(async(w,u)=>{try{let t=jQuery(u).find(".ui-draggable"),A=wb(t[0]).split("-")[1],z=pb(t[0]),y=t.context.querySelector("input").getAttribute("value");if(Number(A)==Number(b)&&Number(z)==Number(c)){g=!0;try{const x=await jQuery.post(S({mod:"inventory",submod:"move",from:"-"+y,fromX:1,fromY:1,to:q,toX:m.x+1,toY:m.y+1,amount:h}),{a:(new Date).getTime(),sh:U("sh")}),v=JSON.parse(x).to.data.itemId;try{await jQuery.post(S({mod:"forge",submod:"toWarehouse",
mode:"workbench",slot:e,iid:v,amount:h,a:(new Date).getTime(),sh:U("sh")}))}catch(D){C(`Error moving material to workbench: ${D}`)}}catch(x){C(`Error moving material from package to bag: ${x}`)}return!1}}catch(t){C(`Error processing package item: ${t}`)}}),g||k++)}catch(n){C(`Error fetching materials from the package on page ${k}: ${n}`),k++}g||C(`Material of type ${b} and quality ${c} not found in packages.`)},async ec(b,c=-1){let e=this.F();await jQuery.post(S({}),{mod:"forge",submod:"storageToWarehouse",
mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:U("sh")});c<Number(localStorage.getItem("repairMaxQuality"))?await this.ec(b,++c):(await jQuery.post(S({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")}),e.selectedItem.status="toPackage",localStorage.setItem("workbenchItem",JSON.stringify(e)),await this.mc(b))},async mc(b){C(`${d.Ae}`);let c=this.F();c.selectedItem.status="workbenchToBag";localStorage.setItem("workbenchItem",JSON.stringify(c));let e;
try{(e=1100*c.slots[b].formula.duration)||(e=12E3)}catch(h){e=12E3}await new Promise(h=>setTimeout(h,e));await this.xm(b)},async xm(b){let c=this.F();(await jQuery.post(S({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")})).includes("document.location.href=document.location.href")?(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.La()):(Object.assign(c.selectedItem,{status:"workbenchToBag"}),
localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.xm(b))},async tp(b=1){C(`${d.Ba}`);let c=await this.F(),{item:e,bag:h,spot:k}=c.selectedItem,g=!1;try{const u=await jQuery.get(G({}),{mod:"packages",f:-1,fq:e.quality,qry:e.name,page:b,sh:U("sh")});let t=jQuery(u).find(".packageItem").toArray();0===t.length&&C(`No package items found on page: ${b}`);for(let A of t){let z=A.querySelector(".ui-draggable");vb(z);var l=pb(z),q=Xb(z);A.getAttribute("data-soulbound-to");var m=z.getAttribute("data-measurement-x"),
n=z.getAttribute("data-measurement-y"),r=A.querySelector("[data-container-number]").getAttribute("data-container-number"),w=A.querySelector('input[name="packages[]"]').value;if(q===e.name&&e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===l)g=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.$m(A,h,k,r,m,n)}3<b?this.handleError():g||await this.La(++b,!0)}catch(u){C(`Error repairing the item. ${u}`),this.gn(),window.location.reload()}},
async La(b=1){C(`${d.Ba}`);let c=await this.F(),{item:e,bag:h,spot:k}=c.selectedItem,g=!1;e.quality=e?.quality??0;try{const u=await jQuery.get(G({}),{mod:"packages",f:-1,fq:e.quality,qry:e.name,page:b,sh:U("sh")});let t=jQuery(u).find(".packageItem").toArray();0===t.length&&C(`No package items found on page: ${b}`);for(let A of t){let z=A.querySelector(".ui-draggable");vb(z);var l=pb(z)??0,q=Xb(z);A.getAttribute("data-soulbound-to");var m=z.getAttribute("data-measurement-x"),n=z.getAttribute("data-measurement-y"),
r=A.querySelector("[data-container-number]").getAttribute("data-container-number"),w=A.querySelector('input[name="packages[]"]').value;if(q===e.name&&e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===l)g=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.$m(A,h,k,r,m,n)}3<b?this.handleError():g||await this.La(++b,!0)}catch(u){C(`Error repairing the item. ${u}`),this.gn(),window.location.reload()}},async $m(b,c,e,h,k,g){await ic(k,
g,async(l,q)=>{await jQuery.post(S({}),{mod:"inventory",submod:"move",from:h,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+1,amount:1,a:(new Date).getTime(),sh:U("sh")});await this.Pl(h,l,q)})},async Pl(b,c,e){C("Trying to move repaired item to the equpiment.");b=this.F();let {item:h}=b.selectedItem;c=await jQuery.post(S({}),{mod:"inventory",submod:"move",from:e,fromX:c.x+1,fromY:c.y+1,to:h.container,toX:1,toY:1,amount:1,doll:h.doll,a:(new Date).getTime(),sh:U("sh")});c.includes(`"data":{"containerNumber":${h.container}`)?
(Object.assign(b.selectedItem,{status:"toInv"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),await this.Sn(c,h)):(Object.assign(b.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),window.location.reload())},async Sn(b,c){let e,h,k=localStorage.getItem("repairPercentage")||10;try{e=JSON.parse(b).to.data.tooltip.pop().pop()[0].match(/\d+/g),h=Number(e[0])/Number(e[1])*100}catch(g){location.reload()}h<parseInt(k,10)?(this.wo(c.container,2===c.doll),C(`${d.sb}`)):
(C(`${d.De}`),Q("itemRepaired",0));b=this.F();delete b.selectedItem;localStorage.setItem("workbenchItem",JSON.stringify(b));window.location.reload()},wo(b,c=!1){const e=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),h=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),k=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),g=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}"),l={2:"helmet",11:"necklace",3:"weapon",5:"armor",4:"shield",9:"gloves",10:"shoes",
6:"rings1",7:"rings2"},q={2:"helmetM",11:"necklaceM",3:"weaponM",5:"armorM",4:"shieldM",9:"glovesM",10:"shoesM",6:"rings1M",7:"rings2M"};b=c?q[b]:l[b];c?h[b]&&(h[b]=!1,g[b]=Date.now(),localStorage.setItem("activeItemsMercenary",JSON.stringify(h)),localStorage.setItem("disabledTimeMercenary",JSON.stringify(g))):e[b]&&(e[b]=!1,k[b]=Date.now(),localStorage.setItem("activeItemsGladiator",JSON.stringify(e)),localStorage.setItem("disabledTimeGladiator",JSON.stringify(k)))},gn(){this.jn()}},qj={Rl:[],async ro(b){try{let e;
const h=parseInt(localStorage.getItem("smeltTab"),10)||1;C("Repairing before smelting, please wait...");1===h?e=514:2===h?e=515:3===h?e=516:4===h?e=517:5===h?e=518:6===h&&(e=519);const k=await this.Rn(b);if(k){var c=await this.io(b);if(null===c)console.error("Failed to move item to workbench.");else return await this.Dm(c),await this.yo(c),await this.Gn(c,e,k)}else console.error(`Item with ID ${b} not found in inventory.`)}catch(e){}},async Rn(b){let c=null;document.querySelectorAll("#inv .ui-draggable").forEach(e=>
{if(e.getAttribute("data-item-id")===b){const h=parseInt(e.getAttribute("data-position-x"),10)+1,k=parseInt(e.getAttribute("data-position-y"),10)+1,g=pb(e);e=Xb(e).toLowerCase();c={container:"inv",x:h,y:k,quality:g,name:e};return!1}});return c},async io(b){const c=await this.Tn();if(null===c)return C("No available workbench slots. Continuing without repair."),!1;const e=await jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:c,iid:b,amount:1,a:(new Date).getTime(),
sh:U("sh")});if("0"===(localStorage.getItem("PartialOrFull")||"0"))try{this.Rl=JSON.parse(e).slots[c].formula.needed}catch{C("Error getting needed items for repair.")}await jQuery.post(S({}),{mod:"forge",submod:"rent",mode:"workbench",slot:c,rent:2,item:b,a:(new Date).getTime(),sh:U("sh")});return c},async Tn(){var b=await jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:U("sh")});b=JSON.parse(b).slots;let c=null;for(let e of b)if("closed"===e["forge_slots.state"]){c=
e["forge_slots.slot"];break}return c},async Dm(b){"0"===(localStorage.getItem("PartialOrFull")||"0")&&0<Object.keys(this.Rl).length?await this.Jh(b):await this.Qn(b);await jQuery.post(S({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")})},async Qn(b){const c=localStorage.getItem("repairBeforeSmeltMaxQuality")||1;await jQuery.post(S({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:U("sh")})},async Jh(b){let c=
[];const e=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let h in this.Rl){const k=parseInt(h,10);0<this.Rl[h].amount&&!e.some(g=>parseInt(g,10)+18E3===k)&&c.push({type:k,amount:this.Rl[h].amount})}await this.rl(c,-1,b)},async rl(b,c=-1,e){for(let h=0;h<b.length;h++){let k=c,g=0,l=1;2>=b[h].amount&&(l=1);for(b[h].type=b[h].type-18E3;k<=Number(localStorage.getItem("repairMaxQuality"))&&g<l;)try{if(await jQuery.post(S({mod:"forge",submod:"storageOut",type:b[h].type,quality:k,amount:1,
a:(new Date).getTime(),sh:U("sh")})),await this.sl(b[h].type,k,e,1),g++,g<=l)break}catch(q){if(k++,k>Number(localStorage.getItem("repairMaxQuality")))break}}},async sl(b,c,e,h){let k=1,g=!1,{spot:l,bag:q}=await ic(1,1);for(;!g&&5>=k;)try{const m=await jQuery.get(G({mod:"packages",f:18,fq:c,qry:"",page:k,sh:U("sh")})),n=jQuery(m).find(".packageItem");if(0===n.length){k++;continue}let r=!1;n.each((w,u)=>{try{let t=jQuery(u).find(".ui-draggable"),A=wb(t[0]).split("-")[1],z=pb(t[0]),y=t.context.querySelector("input").getAttribute("value");
if(A==b&&z==c)return r=g=!0,jQuery.post(S({mod:"inventory",submod:"move",from:"-"+y,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+1,amount:h}),{a:(new Date).getTime(),sh:U("sh")}).then(x=>{try{const v=JSON.parse(x).to.data.itemId;jQuery.post(S({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:v,amount:h,a:(new Date).getTime(),sh:U("sh")})).catch(()=>{})}catch(v){}}).catch(()=>{}),!1}catch(t){}});r||k++}catch(m){C(`Error fetching materials from the package on page ${k}: ${m}`),k++}g||C(`Material of type ${b} and quality ${c} not found in packages.`)},
async yo(b){let c=1E3,e=await this.Yn(b);if(null===e||void 0===e)e=6;c=1E3;await new Promise(h=>setTimeout(h,1100*e+c))},async Yn(b){var c=await jQuery.post(S({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:U("sh")});return(c=JSON.parse(c).slots.find(e=>e["forge_slots.slot"]===b))&&c.formula&&c.formula.duration?c.formula.duration:6},async Gn(b,c,e){await jQuery.post(S({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),sh:U("sh")});
return await this.jo(c,e)},async jo(b,c){let e=1;var h=!1;let k;for(;!h&&5>=e;){var g=await jQuery.get(G({mod:"packages",f:0,fq:c.quality,qry:c.name,page:e,sh:U("sh")}));g=jQuery(g).find(".packageItem").toArray();for(let l of g){jQuery(l).find(".ui-draggable");h=l.querySelector("input").value;k=(await jQuery.post(S({}),{mod:"inventory",submod:"move",from:"-"+h,fromX:1,fromY:1,to:b,toX:c.x-1,toY:c.y-1,amount:1,a:(new Date).getTime(),sh:U("sh")},null,"json")).to.data.itemId;h=!0;break}h||e++}if(!h)throw Error("Repaired item not found in packages.");
return k}},N={lm:!1,qm:!0,spot:1,bag:512,start(){this.pack=function(b,c,e){if(!e)return e;var h=0,k=b+c.slice([e.split("^")[1]]);for(b=0;b<k.length;b++)c=k.charCodeAt(b),h=(h<<5)-h+c,h|=0;return e.split("^")[0]==h};this.storage=JSON.parse(localStorage.getItem("packages"))||{packages:{}};this.createFunctions();this.getState()},createFunctions(){document.getElementById("ConfirmGetGold").addEventListener("click",async function(){async function b(m,n){n=await jQuery.post(S({mod:"inventory",submod:"move",
from:m[0].closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+n,toY:21,amount:1}),{a:(new Date).getTime(),sh:h});m[0].closest(".packageItem").remove();m=JSON.parse(n).header.gold.text||"0";m=parseInt(m.replace(/[^0-9]/g,""),10);l+=m-g;g=m;document.getElementById("goldMovedIndicator").textContent=`Gold moved: ${l.toLocaleString()}`}async function c(){var m=await jQuery.get(G({mod:"packages",f:"14",fq:-1,qry:"",page:k,sh:h}));let n=jQuery(m).find(".ui-draggable").filter((r,
w)=>(r=parseInt(jQuery(w).attr("data-price-gold"),10))&&r<=q-g).get();for(let [r,w]of n.entries())if(await b(jQuery(w),r),g>=q){document.getElementById("goldMovedIndicator").textContent+=" - Completed";return}k++;m=(m=jQuery(m).find(".paging_right_full")[0])?parseInt(m.href.match(/\d+$/)[0],10):1;k<m?await c():document.getElementById("goldMovedIndicator").textContent=`Not enough gold found. Only ${l.toLocaleString()} moved.`}let e=parseInt(document.getElementById("getGold").value.replace(/[^0-9]/g,
""),10);if(isNaN(e)||0>=e)alert("Please enter a valid amount greater than 0.");else{var h=U("sh"),k=0,g=0,l=0;g=parseInt(document.getElementById("sstat_gold_val").textContent.replace(/[^0-9]/g,""),10);var q=g+e;document.getElementById("goldMovedIndicator").textContent="Starting...";await c()}});document.querySelector("h2").addEventListener("click",()=>{jQuery(".custom_packages").toggle();let b=jQuery(".custom_packages").is(":hidden");localStorage.setItem("packages_hidden",b)});jQuery(".custom_packages").mouseup(async b=>
{var c=b.target;b=c.getAttribute("data-button");var e=JSON.parse(localStorage.getItem("packages"));const h=e.quality,k=e.type;if(!c.getAttribute("disabled")){switch(b){case "pickAll":confirm("Pick all?")&&this.pickItems(!0);break;case "pickAllSelected":-1<ya.type.indexOf(14)&&confirm("Pick gold");this.pickItems(!1);break;case "sellThisPage":if(!e||!e.quality||!e.type){Ya("Please select a valid package with both quality and type.");break}0<h.length&&0<k.length?this.vo():(this.om=!0,Ya("Please select both quality and type to sell."));
break;case "SARTH":this.sarth();break;case "SASTM":if(!e||!e.quality||!e.type){Ya("Please select a valid package with both quality and type.");break}0<h.length&&0<k.length?this.sastm():(this.om=!0,Ya("Please select both quality and type to sell."));break;case "stop":this.stop=!0;break;case "switch":c=document.querySelector('input[data-name="useSmeltFilter"]');e=document.querySelector('input[data-name="UCOTH"]');c.addEventListener("change",function(){localStorage.setItem("useTriggerSmeltFilter",this.checked)});
e.addEventListener("change",function(){localStorage.setItem("useTriggerCloths",this.checked)});localStorage.setItem("useTriggerSmeltFilter",c.checked);localStorage.setItem("useTriggerCloths",e.checked);break;default:return}"stop"!=b&&"switch"!=b&&(this.om?this.om=!1:(this.stop=!1,jQuery("[pakageCmd]").attr("disabled","")))}});document.querySelector(".custom_packages").addEventListener("change",b=>{const c=b.target;var e=c.getAttribute("data-button");b=c.getAttribute("data-name");if(e&&b){var h=Array.from(document.querySelectorAll(`[data-name="${b}"][data-button="package"]`)),
k=document.querySelector(`[data-name="${b}"][data-button="packageAll"]`);if("packageAll"===e)h.forEach(g=>g.checked=c.checked);else if("package"===e)!c.checked&&k&&(k.checked=!1),h.every(g=>g.checked)&&k&&(k.checked=!0);else if("switch"===e){localStorage.setItem(b,c.checked);return}e=h.filter(g=>g.checked).map(g=>parseInt(g.value,10));this.storage[b]=e;localStorage.setItem("packages",JSON.stringify(this.storage))}})},enableButtons(){jQuery("[pakageCmd]").removeAttr("disabled")},getState(){this.storage=
JSON.parse(localStorage.getItem("packages"))||{};document.querySelectorAll('.custom_packages [data-button="package"]').forEach(c=>{const e=c.getAttribute("data-name"),h=parseInt(c.value,10);c.checked=this.storage[e]&&this.storage[e].includes(h)});document.querySelectorAll('.custom_packages [data-button="packageAll"]').forEach(c=>{const e=c.getAttribute("data-name");c.checked=Array.from(document.querySelectorAll(`.custom_packages [data-button="package"][data-name="${e}"]`)).every(h=>h.checked)});document.querySelectorAll('.custom_packages [data-button="switch"]').forEach(c=>
{const e=c.getAttribute("data-name");c.checked="true"===localStorage.getItem(e)});const b="true"===localStorage.getItem("packages_hidden");document.querySelector(".custom_packages").style.display=b?"none":"block"},pickItems(b){ya=JSON.parse(localStorage.getItem("packages"));this.arr=Array.from(document.querySelectorAll("#packages .ui-draggable")).filter(e=>{let h=parseInt(wb(e).split("-")[0],10),k=14==h?!0:!1;return-1<ya.type.indexOf(h)&&-1<ya.quality.indexOf(parseInt(pb(e),10))&&!b||b&&!k}).sort((e,
h)=>Wb(h)-Wb(e));const c=this.arr.filter(e=>14==parseInt(wb(e).split("-")[0],10)&&1E6>=parseInt(e.getAttribute("data-price-gold"),10));this.arr=this.arr.filter(e=>14!=parseInt(wb(e).split("-")[0],10));Promise.all(c.map(this.moveGold)).then(()=>{N.move()})},async moveGold(b,c){c=await jQuery.post(S({mod:"inventory",submod:"move",from:b.closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+c,toY:21,amount:1}),{a:(new Date).getTime(),sh:U("sh")});b.closest(".packageItem").remove();
document.getElementById("sstat_gold_val").innerText=JSON.parse(c).header.gold.text||0},move(){var b=document.getElementById("inv");b=Fc(b);b=Math.min(40-$b(b),this.arr.length);let c=this.arr.shift();0<b&&!N.stop?(Ca(c,"inv"),setTimeout(()=>{N.move()},300)):setTimeout(N.enableButtons,500)},sarth:function(){jQuery.post(S({mod:"forge",submod:"storageIn"}),{op:0,packages:1,Cm:1,a:(new Date).getTime()+"",sh:U("sh")},()=>{window.location.reload(!0)})},async sastm(){N.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),
this.Tl={},this.pack&&this.tm(this.Fm))},async vo(){N.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),N.lm=!0,this.Tl={},this.pack&&this.tm(this.Fm))},async Fm(b){if(N.stop)window.location.reload();else if(N.Tl=b,b=Object.values(b).every(c=>c.items.length>=c.em),N.xn=document.querySelector('input[data-name="UCOTH"]'),b&&!N.xn.checked){if(b=document.getElementById("sellspinner"),b.classList.add("hidden"),!document.getElementById("shops-full-message")){const c=
document.createElement("div");c.id="shops-full-message";c.classList.add("message-container");c.textContent="Shops are full! Please refresh the shops or select refresh shops automatically.";b.insertAdjacentElement("afterend",c);N.enableButtons()}}else ic(2,3,N.rn)},async rn(b,c){if(N.stop)window.location.reload();else{try{N.An=Object.assign(b,{b:c})}catch(n){Ya("Please empty your inventory to have 3x3 space")}document.querySelectorAll("#inventory_nav a")[c-512].click();N.inv=document.getElementById("inv");
var e=JSON.parse(localStorage.getItem("packages"))||{};b=(new URL(window.location.href)).searchParams;b.get("f");b.get("fq");var h={mod:"packages",f:"0",fq:e.quality[0]||-1,qry:"",page:1,sh:U("sh")};b=await jQuery.get(G(h));b=jQuery(b).find(".paging_right_full")[0]?.href.match(/\d+$/)?.[0]||1;console.log(`Max page determined: ${b}`);N.g=[];N.qa=[];var k="true"===localStorage.getItem("useTriggerSmeltFilter"),g=JSON.parse(localStorage.getItem("smeltingSettings"))||[],l=JSON.parse(localStorage.getItem("auctionPrefixes"))||
[],q=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];if(N.lm)N.lm&&(N.stop?window.location.reload():(m=document.querySelectorAll("#packages .packageItem"),b=document.getElementById("sellspinner"),b.classList.remove("hidden"),c=document.getElementById("statusMessage"),c||(c=document.createElement("div"),c.id="statusMessage",c.classList.add("status-message"),b.insertAdjacentElement("afterend",c)),0<m.length?(c.textContent=`Processing ${m.length} items from the current page...`,m=Array.from(m).map(async n=>
{var r=n.querySelector("input").value;const w=n.querySelector(".ui-draggable"),u=parseInt(wb(w).split("-")[0]),t=14===u;var A=Wb(w);const z=Xb(w);var y=xb(w);n={p:n,hl:w,s:A,id:r,q:y};r=g.some(x=>{var v,D;2<x.prefix.length&&(v=x.prefix.toLowerCase());2<x.suffix.length&&(D=x.suffix[0]?x.suffix[0].toLowerCase():"");x=z.toLowerCase();v=v&&2<v.length&&x.includes(v);D=D&&2<D.length&&x.includes(D);return v||D});r=k&&r;A=k&&l.some(x=>2<x.length&&z.includes(x.toLowerCase()));y=k&&q.some(x=>2<x.length&&z.includes(x.toLowerCase()));
k?-1<e.type.indexOf(u)&&-1<e.quality.indexOf(parseInt(pb(w)))&&!r&&!A&&!y?N.g.push(n):-1<e.type.indexOf(u)&&t&&N.g.push(n):-1<e.type.indexOf(u)&&-1<e.quality.indexOf(parseInt(pb(w)))?N.g.push(n):-1<e.type.indexOf(u)&&t&&N.g.push(n)}),await Promise.all(m),0<N.g.length?(c.textContent=`Selling ${N.g.length} items...`,await N.wn()):(c.textContent="No items to sell. Please refresh the page.",b.classList.add("hidden"),N.enableButtons()),N.g=[]):(c.textContent="No items found in the current page.",b.classList.add("hidden"))));
else{c=document.getElementById("sellspinner");c.classList.remove("hidden");var m=document.getElementById("statusMessage");m||(m=document.createElement("div"),m.id="statusMessage",m.classList.add("status-message"),c.insertAdjacentElement("afterend",m));let n=0;for(let r=1;r<=b;r+=10){const w=Array.from({length:Math.min(10,b-r+1)},(u,t)=>r+t);console.log(`Fetching batch pages: ${w.join(", ")}`);m.textContent=`Reading pages ${w[0]} to ${w[w.length-1]}...`;await Promise.all(w.map(async u=>{h.page=u;try{const t=
await jQuery.get(G(h)),A=jQuery(t).find(".packageItem");0<A.length&&(n+=A.length,A.each((z,y)=>{const x=jQuery(y).find("input").val();z=jQuery(y).find(".ui-draggable")[0];const v=parseInt(wb(z).split("-")[0]),D=14===v,E=Wb(z),I=xb(z);Xb(z);y={p:y,hl:z,s:E,id:x,q:I};-1<e.type.indexOf(v)&&-1<e.quality.indexOf(parseInt(pb(z)))?N.g.push(y):-1<e.type.indexOf(v)&&D&&N.g.push(y)}),console.log(`Items added from page ${u}: ${A.length}`))}catch(t){console.error(`Error fetching page ${u}:`,t)}}));await new Promise(u=>
setTimeout(u,1E3))}m.textContent=0<n?`Found ${n} items. Preparing to sell...`:"No items found. Please adjust your filters.";0<N.g.length?(m.textContent=`Selling ${N.g.length} items...`,N.sellItems()):(c.classList.add("hidden"),m.textContent="No items to sell. Please change your selections and refresh the page.")}}},sellItems(){if(N.stop)window.location.reload();else{var b=document.getElementById("sellspinner");b.classList.remove("hidden");var c=document.getElementById("statusMessage");c||(c=document.createElement("div"),
c.id="statusMessage",c.classList.add("status-message"),b.insertAdjacentElement("afterend",c));var e=document.getElementById("itemPreview");e||(e=document.createElement("div"),e.id="itemPreview",e.classList.add("item-preview"),c.insertAdjacentElement("afterend",e));try{var h=N.g.shift();var k=N.An;var g=N.Gm(h.hl)}catch{0<N.qa.length&&!g?N.useCloths():(b.classList.add("hidden"),c.textContent="All items sold. Reloading...",setTimeout(()=>window.location.reload(),2E3));return}if(g){let l=Xb(h.hl);c.textContent=
`Selling: ${l} (${N.g.length} items left)`;e.innerHTML="";e.appendChild(h.p.cloneNode(!0));jQuery.post(S({mod:"inventory",submod:"move",from:"-"+h.id,fromX:"1",fromY:"1",to:k.b,toX:k.x+1,toY:k.y+1,amount:h.q}),{a:(new Date).getTime(),sh:U("sh")},()=>{var q=jQuery(h.hl).css({left:32*k.x,top:32*k.y});N.inv.appendChild(q[0]);jQuery.post(S({mod:"inventory",submod:"move",from:k.b,fromX:k.x+1,fromY:k.y+1,to:g.kn,toX:g.spot.x+1,toY:g.spot.y+1,amount:h.q,doll:"1"}),{a:(new Date).getTime(),sh:U("sh")},m=>
{jQuery(h.hl).remove();try{document.getElementById("sstat_gold_val").innerText=JSON.parse(m).header.gold.text}catch{}0<N.g.length?N.sellItems():(b.classList.add("hidden"),c.textContent="All items sold successfully!",setTimeout(()=>0<N.qa.length?N.useCloths():window.location.reload(),2E3))})})}else 0<N.g.length?(N.qa.push(h),N.sellItems()):(b.classList.add("hidden"),c.textContent="All items sold. Reloading...",setTimeout(()=>0<N.qa.length?N.useCloths():window.location.reload(),2E3))}},async useCloths(){if("true"===
localStorage.getItem("useTriggerCloths")&&0<N.qa.length){N.g=N.qa;N.qa=[];var b=await jQuery.get(G({mod:"inventory",sub:"1",subsub:"2",sh:U("sh")}));b=jQuery(b);b.find("#content form img")[0].src.includes("91e0372cccc24f52758be611a10a3b.png")?(b=b.find("#content form input")[0],await jQuery.post(G({mod:"inventory",sub:"1",subsub:"2",sh:U("sh")}),{[b.name]:b.value}),await new Promise((c,e)=>{N.tm(h=>{(N.Tl=h)&&0<Object.keys(h).length?c():e("Failed to load shop grid data.")})}),N.sellItems()):window.location.reload()}else window.location.reload()},
async wn(){if(!N.stop){for(;0<N.g.length;){if(N.qm){var b=await ic(2,3);N.spot=b.spot;N.bag=b.bag;N.qm=!1}await new Promise(c=>setTimeout(c,10));b=N.g.splice(0,1).map(async c=>{var e=N.Gm(c.hl);if(e){const h=await jQuery.post(S({mod:"inventory",submod:"move",from:"-"+c.id,fromX:"1",fromY:"1",to:N.bag,toX:N.spot.x+1,toY:N.spot.y+1,amount:c.q}),{a:(new Date).getTime(),sh:U("sh")});if(h.includes("Not possible")||h.includes("error"))N.qm=!0;else if(e=await jQuery.post(S({mod:"inventory",submod:"move",
from:N.bag,fromX:N.spot.x+1,fromY:N.spot.y+1,to:e.kn,toX:e.spot.x+1,toY:e.spot.y+1,amount:c.q,doll:"1"}),{a:(new Date).getTime(),sh:U("sh")})){jQuery(c.element).remove();try{const k=JSON.parse(e).header.gold.text;document.getElementById("sstat_gold_val").innerText=k||""}catch(k){console.error("Failed to parse gold value:",k)}}}else 0<N.g.length?N.qa.push(c):0<N.qa.length?await N.useCloths():window.location.reload()});await Promise.all(b);N.g=N.g.filter(c=>!N.qa.includes(c));await new Promise(c=>setTimeout(c,
10))}0===N.g.length&&window.location.reload()}},Gm(b){var c=parseInt(b.getAttribute("data-measurement-x"),10);b=parseInt(b.getAttribute("data-measurement-y"),10);for(var e in N.Tl){var h=N.Tl[e];if(!(isNaN(parseInt(e,10))||1>h.em)){var k=Hc(b,c,h.grid);if(k)return h.em-=c*b,h.items.push({y:k.y,x:k.x,cl:b,w:c}),h.grid=Gc(8,6,h.items),{spot:k,kn:e}}}},tm(b){const c=[{sub:1,subsub:2},{sub:2,subsub:2},{sub:3,subsub:1},{sub:3,subsub:2},{sub:4,subsub:0},{sub:4,subsub:1},{sub:4,subsub:2},{sub:5,subsub:0},
{sub:5,subsub:1},{sub:5,subsub:2},{sub:6,subsub:0},{sub:6,subsub:1},{sub:6,subsub:2}].map(h=>G({mod:"inventory",sh:U("sh"),...h})),e={};Promise.all(c.map((h,k)=>new Promise((g,l)=>{jQuery.get(h,q=>{try{const m=jQuery(q).find("#shop")[0],n=m.getAttribute("data-container-number"),r=Fc(m);e[n]={em:48-$b(r),grid:Gc(8,6,r),items:r};g()}catch(m){console.error(`Error processing shop grid ${k}:`,m),l(m)}}).fail((q,m,n)=>{console.error(`Error loading shop grid ${k}: ${m} - ${n}`);l(Error(`Error loading shop grid ${k}: ${m} - ${n}`))})}))).then(()=>
{0<Object.keys(e).length?b(e):console.error("Failed to load shop grids.")}).catch(h=>console.error("Error in gsgriz:",h))}};if(window.location.href.includes("/index.php?mod=market")){let b=[];const c=document.querySelector("#market_filter");if(c){const y=document.createElement("div");y.innerHTML=`
    <div class="custom-market-section">
        <div class="custom-market-header">${d.Eb}</div>
        <div class="custom-market-content">
            <!-- Item Sell Form -->
            <div class="item-sell-form" id="item-sell-form">
                <span class="custom-market-footer">${d.Ue}</span>
                <span class="custom-market-footer">${d.Te}</span>
    
                <div>
                    <label>${d.ja}:</label>
                    <input type="text" id="item-name" placeholder="${d.ja}">
                </div>
                <div>
                    <label>${d.Cb}:</label>
                    <select id="item-color">
                        <option value="-1">${d.X}</option>
                        <option value="0">${d.B}</option>
                        <option value="1">${d.A}</option>
                        <option value="2">${d.C}</option>
                        <option value="3">${d.G}</option>
                        <option value="4">${d.R}</option>
                    </select>
                </div>
                <div>
                    <label>${d.J}:</label>
                    <input type="text" id="item-howmany" placeholder="${d.J}?">
                </div>
                <div>
                    <label>${d.K}:</label>
                    <input type="number" id="price-min" placeholder="${d.K}">
                </div>
                <div>
                    <label>${d.H}:</label>
                    <input type="number" id="price-max" placeholder="${d.H}">
                </div>
    
                <div class="time-selection">
                    <button id="time-2h" value="1">2h</button>
                    <button id="time-8h" value="2">8h</button>
                    <button id="time-24h" value="3">24h</button>
                    <button id="time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Db}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="search-inventory"> &nbsp;${d.Qe}</label>&nbsp;
                    <label><input type="checkbox" id="search-packages"> &nbsp;${d.Ve}</label>&nbsp;
                </div>
    
                <button id="sell-item-btn">${d.Eb}</button>
                <div class="spinner3 hidden" id="loadingSpinner3"></div>
            </div>
    
            <!-- Material Sell Form -->
            <div class="material-sell-form hidden" id="material-sell-form">
                <div>
                    <label>Select Material:</label>
                    <select id="material-select">
                        <!-- Base Materials -->
                        <option value="1">${d.kc}</option>
                        <option value="2">${d.hc}</option>
                        <option value="4">${d.ic}</option>
                        <option value="3">${d.jc}</option>
    
                        <!-- Additional material options -->
                        <!-- ... (Include all other material options here as in your original code) -->
                    </select>
                </div>
                <div>
                    <label>${d.Re}:</label>
                    <select id="material-color">
                        <option value="-1">${d.X}</option>
                        <option value="0">${d.B}</option>
                        <option value="1">${d.A}</option>
                        <option value="2">${d.C}</option>
                        <option value="3">${d.G}</option>
                        <option value="4">${d.R}</option>
                    </select>
                </div>
                <div>
                    <label>${d.J}:</label>
                    <input type="text" id="mat-item-howmany" placeholder="${d.J}?">
                </div>
                <div>
                    <label>${d.K}:</label>
                    <input type="number" id="material-price-min" placeholder="${d.K}">
                </div>
                <div>
                    <label>${d.H}:</label>
                    <input type="number" id="material-price-max" placeholder="${d.H}">
                </div>
    
                <div class="time-selection">
                    <button id="material-time-2h" value="1">2h</button>
                    <button id="material-time-8h" value="2">8h</button>
                    <button id="material-time-24h" value="3">24h</button>
                    <button id="material-time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Db}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="material-search-warehouse"> &nbsp;${d.Ye}</label>&nbsp;
                </div>
    
                <button id="sell-material-btn">${d.Xe}</button>
                <div class="spinner2 hidden" id="loadingSpinner2"></div>
            </div>
    
            <!-- Food Sell Form -->
            <div class="food-sell-form hidden" id="food-sell-form">
                <label>Level Range:</label>
                <div style="display: flex; gap: 5px;">
                    <input type="number" id="food-level-min" placeholder="Min Level" style="width: 100%;">
                    <input type="number" id="food-level-max" placeholder="Max Level" style="width: 100%;">
                </div>
                <div>
                    <label>${d.Cb}:</label>
                    <select id="food-quality">
                        <option value="-1">${d.X}</option>
                        <option value="0">${d.B}</option>
                        <option value="1">${d.A}</option>
                        <option value="2">${d.C}</option>
                        <option value="3">${d.G}</option>
                        <option value="4">${d.R}</option>
                    </select>
                </div>
                <div>
                    <label>${d.J}:</label>
                    <input type="text" id="food-howmany" placeholder="${d.J}?">
                </div>
                <div>
                    <label>${d.K}:</label>
                    <input type="number" id="food-price-min" placeholder="${d.K}">
                </div>
                <div>
                    <label>${d.H}:</label>
                    <input type="number" id="food-price-max" placeholder="${d.H}">
                </div>
    
                <div class="time-selection">
                    <button id="food-time-2h" value="1">2h</button>
                    <button id="food-time-8h" value="2">8h</button>
                    <button id="food-time-24h" value="3">24h</button>
                    <button id="food-time-48h" value="4">48h</button>
                </div>
    
                <button id="sell-food-btn">${d.We}</button>
                <div class="spinner3 hidden" id="loadingSpinner4"></div>
            </div>
    
            <div class="switch-section">${d.Fa}</div>
        </div>
    </div>
            `;c.insertAdjacentElement("afterend",y);document.getElementById("sell-item-btn").addEventListener("click",t);document.getElementById("sell-material-btn").addEventListener("click",A);document.getElementById("sell-food-btn").addEventListener("click",w);document.querySelector(".custom-market-header").addEventListener("click",k);document.querySelector(".switch-section").addEventListener("click",l);document.querySelectorAll(".time-selection button").forEach(x=>{x.addEventListener("click",function(){g(x,
x.textContent)})})}let e=["item-sell-form","material-sell-form","food-sell-form"],h=0;function k(){const y=document.querySelector(".custom-market-content"),x=document.querySelector(".custom-market-header");x.classList.toggle("collapsed");y.style.display=x.classList.contains("collapsed")?"none":"block";localStorage.setItem("sellItemsSectionCollapsed",x.classList.contains("collapsed"))}function g(y,x){y.parentElement.querySelectorAll("button").forEach(v=>{v.classList.remove("selected")});y.classList.add("selected");
localStorage.setItem("selectedTime_"+y.closest("div").parentElement.id,x)}function l(){e.forEach(x=>{document.getElementById(x).classList.add("hidden")});h=(h+1)%e.length;document.getElementById(e[h]).classList.remove("hidden");const y=document.querySelector(".switch-section");"item-sell-form"===e[h]?y.textContent=`${d.Fa}`:"material-sell-form"===e[h]?y.textContent=`${d.Fb}`:"food-sell-form"===e[h]&&(y.textContent=`${d.Gb}`);localStorage.setItem("currentSection",e[h])}async function q(y,x,v){return new Promise(async D=>
{let E=!1;const I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));let J=0;for(let P=0;P<I.length&&!(J>=parseInt(v,10));P++){var K=I[P];if("false"!==K.getAttribute("data-available")){K.click();await new Promise(T=>setTimeout(T,175));K=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let T of K){if(J>=parseInt(v))break;T.getAttribute("data-basis");K=Xb(T);const X=T.getAttribute("data-item-id"),ia=pb(T);if(K.toLowerCase()===y.toLowerCase()&&x===ia){b.push(X);E=!0;
J++;break}}if(E)break}}D(E)})}async function m(y,x,v,D,E){try{let I=1,J=parseInt(v,10);for(v=!1;1<=I&&2>=I&&!(0>=J);){const K=await jQuery.get(G({mod:"packages",f:D?"18":"0",fq:x,qry:D?"":y,page:I.toString(),sh:U("sh")})),P=Array.from(jQuery(K).find(".packageItem"));for(let T of P){if(0>=J)break;const X=T.querySelector("[data-content-type]"),ia=T.querySelector("[data-container-number]"),fa=X.getAttribute("data-measurement-x"),na=X.getAttribute("data-measurement-y");let ta=X.getAttribute("data-quality");
const la=X.getAttribute("data-tooltip"),xa=ia.getAttribute("data-container-number"),Na=Xb(X).toLowerCase();ta||(la.includes("white")&&(ta="-1"),la.includes("lime")&&(ta="0"));const Gb=Na===y.toLowerCase()&&x===ta;if(D){const Oa=X.getAttribute("data-basis"),Xa=Oa.startsWith("18")&&Oa.split("-")[1]===E.toString();x===ta&&Xa&&(await u(xa,fa,na),v=!0,J--)}else Gb&&(await u(xa,fa,na),v=!0,J--)}I++}return v}catch(I){return!1}}async function n(y,x=-1,v){try{let D=!0,E=0;for(let I=0;I<parseInt(v,10)&&!(E>=
v);I++){for(;E<parseInt(v,10);)try{if(await jQuery.post(S({mod:"forge",submod:"storageOut",type:y,quality:x,amount:1,a:(new Date).getTime(),sh:U("sh")})),await m(y,x,1,!0,y),E++,E>=parseInt(v,10))break}catch(J){E++}D=!0}return D}catch(D){return!1}}async function r(y,x,v,D){try{let E=1,I=parseInt(D,10);for(D=!1;1<=E&&10>=E&&!(0>=I);){const J=await jQuery.get(G({mod:"packages",f:"7",fq:v,qry:"",page:E.toString(),sh:U("sh")})),K=Array.from(jQuery(J).find(".packageItem"));for(let P of K){if(0>=I)break;
const T=P.querySelector("[data-content-type]"),X=P.querySelector("[data-container-number]"),ia=T.getAttribute("data-measurement-x"),fa=T.getAttribute("data-measurement-y"),na=Eb(T),ta=pb(T);if(parseInt(na)>=y&&parseInt(na)<=x&&ta===v){const la=X.getAttribute("data-container-number");await u(la,ia,fa);D=!0;I--}}E++}return D}catch(E){return console.error("Error in pickFromPackagesForFood:",E),!1}}async function w(){var y=parseInt(document.getElementById("food-level-min").value,10);const x=parseInt(document.getElementById("food-level-max").value,
10),v=document.getElementById("food-quality").value,D=parseInt(document.getElementById("food-howmany").value,10),E=parseInt(document.getElementById("food-price-min").value,10),I=parseInt(document.getElementById("food-price-max").value,10),J=document.getElementById("loadingSpinner4");if(isNaN(y)||isNaN(x)||y>x||isNaN(E)||isNaN(I)||E>I||1>D)alert(`${d.Ca}`);else{J.style.display="block";try{let ia=!1;if(ia=await r(y,x,v,D)){var K=document.querySelector("#food-sell-form .time-selection button.selected"),
P=K?parseInt(K.value,10):2,T=document.querySelector('input[name="anbieten"]'),X=T?T.value:"Offer";for(y=0;y<b.length;y++){const fa=b[y],na=E===I?E:Math.floor(Math.random()*(I-E+1))+E,ta=G({mod:"market",sh:U("sh")});await jQuery.post(ta,{sellid:fa,preis:na,dauer:P,anbieten:X})}b=[];alert(`${d.Ea}`);await new Promise(fa=>setTimeout(fa,250));zh("mod=market&f=7")}else alert(`${d.Da}`)}catch(ia){console.error("Error selling food:",ia)}finally{J.style.display="none"}}}async function u(y,x,v){try{let {spot:D,
bag:E}=await ic(x,v);const I=await jQuery.post(S({mod:"inventory",submod:"move",from:y,fromX:1,fromY:1,to:E,toX:D.x+1,toY:D.y+1,amount:1,a:(new Date).getTime(),sh:U("sh")})),J=JSON.parse(I).to.data.itemId;b.push(J);return!0}catch(D){return console.error("Error moving item to inventory:",D),!1}}async function t(){const y=document.getElementById("item-name").value;var x=document.getElementById("item-color").value;const v=document.getElementById("item-howmany").value,D=parseInt(document.getElementById("price-min").value,
10),E=parseInt(document.getElementById("price-max").value,10),I=document.getElementById("loadingSpinner3"),J=document.getElementById("search-inventory").checked,K=document.getElementById("search-packages").checked;if(!y||isNaN(D)||isNaN(E)||D>E||1>v)alert(`${d.Ca}`);else{I.style.display="block";try{let fa=!1;J&&(fa=await q(y,x,v));!fa&&K&&(fa=await m(y,x,v));if(fa){var P=document.querySelector(".time-selection button.selected"),T=P?parseInt(P.value,10):2,X=document.querySelector('input[name="anbieten"]'),
ia=X?X.value:"Offer";for(x=0;x<b.length;x++){const na=b[x],ta=D===E?D:Math.floor(Math.random()*(E-D+1))+D,la=G({mod:"market",sh:U("sh")});jQuery.post(la,{sellid:na,preis:ta,dauer:T,anbieten:ia})}b=[];alert(`${d.Ea}`);await new Promise(na=>setTimeout(na,250));zh("mod=market&qry="+y)}else alert(`${d.Da}`)}catch(fa){}finally{I.style.display="none"}}}async function A(){var y=document.getElementById("material-select").value,x=document.getElementById("material-select");x=x.options[x.selectedIndex].textContent;
const v=document.getElementById("material-color").value,D=document.getElementById("mat-item-howmany").value,E=parseInt(document.getElementById("material-price-min").value,10),I=parseInt(document.getElementById("material-price-max").value,10),J=document.getElementById("loadingSpinner2"),K=document.getElementById("material-search-warehouse").checked;if(!y||isNaN(E)||isNaN(I)||E>I||1>D)alert(`${d.Ca}`);else{J.style.display="block";try{let fa=!1;K&&(fa=await n(y,v,D));if(fa){var P=document.querySelector("#material-sell-form .time-selection button.selected"),
T=P?parseInt(P.value,10):2,X=document.querySelector('input[name="anbieten"]'),ia=X?X.value:"Offer";for(y=0;y<b.length;y++){const na=b[y],ta=E===I?E:Math.floor(Math.random()*(I-E+1))+E,la=G({mod:"market",sh:U("sh")});jQuery.post(la,{sellid:na,preis:ta,dauer:T,anbieten:ia})}b=[];alert(`${d.Ea}`);await new Promise(na=>setTimeout(na,250));zh("mod=market&qry="+x)}else alert(`${d.Da}`)}catch(fa){}finally{J.style.display="none"}}}const z=localStorage.getItem("currentSection");if(z&&e.includes(z)){e.forEach(x=>
{document.getElementById(x).classList.add("hidden")});document.getElementById(z).classList.remove("hidden");h=e.indexOf(z);const y=document.querySelector(".switch-section");"item-sell-form"===e[h]?y.textContent=`${d.Fa}`:"material-sell-form"===e[h]?y.textContent=`${d.Fb}`:"food-sell-form"===e[h]&&(y.textContent=`${d.Gb}`)}else document.getElementById("item-sell-form").classList.remove("hidden"),h=0;e.forEach(y=>{const x=localStorage.getItem("selectedTime_"+y);x&&document.querySelectorAll("#"+y+" .time-selection button").forEach(v=>
{v.textContent===x&&v.classList.add("selected")})});"true"===localStorage.getItem("sellItemsSectionCollapsed")&&(document.querySelector(".custom-market-header").classList.add("collapsed"),document.querySelector(".custom-market-content").style.display="none")}if(window.location.href.includes("/index.php?mod=guild")){const b=document.querySelectorAll("form");for(const c of b){const e=c.getAttribute("action");e&&e.includes("submod=create")&&localStorage.setItem("resetExpiredItems","false")}}if(window.location.href.includes("/index.php?mod=packages&")){let b=
jQuery(".section-header").first();b&&(function(){var c="true"===localStorage.getItem("packages_hidden");let e=`

<section class="custom_packages" style="display: block; box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
<div style="text-align: center">
    <button class="awesome-button" packageCmd data-button="pickAll">
    ${d.fj}
    </button>
    <button class="awesome-button" packageCmd data-button="pickAllSelected">
    ${d.gj}
    </button>
    <button class="awesome-button" pakageCmd data-button="sellThisPage">
    ${d.jj}
    </button>
    <button
    class="awesome-button" data-button="SASTM" pakageCmd data-name="SASTM"
>
${d.hj}
</button>
    <button class="awesome-button" data-button="stop">${d.lj}</button>
    <button class="awesome-button" packageCmd data-button="SARTH">
    ${d.kj}
    </button>
</div>

<style>

    .awesome-button:hover {
        background-color: #444;
        color: #fff; 
    }

    .progress-container {
      width: 100%;
      height: 20px;
      background-color: #f3f3f3;
      position: relative;
      border-radius: 15px;
      margin: 10px 0;
    }
  
    .progress-bar {
      width: 0;
      height: 100%;
      background-color: #4caf50;
      position: absolute;
      border-radius: 15px;
      transition: width 0.4s ease-in-out;
    }
  
    .page-indicator {
      text-align: center;
      position: absolute;
      width: 100%;
      top: 50%;
      transform: translateY(-50%);
      font-size: 12px;
    }

</style>

    <fieldset style="box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
        <legend>${d.ij}</legend>
        <table style="width: 100%; text-align: center">
            <tbody>
                <tr>
                    <td>
                    </td>
                    

                    <div id="sellspinner" class="spinnerNew hidden"></div>
                    <div id="statusMessage" class="status-message">Status</div>
                    <div id="itemPreview" class="item-preview">
                        <div class="item"></div>
                    </div>
                    <!--
                    <div class="progress-container">
                    <div class="progress-bar" id="progressBar"></div>
                    <div class="page-indicator">${d.ej} <span id="currentPageIndicator">0</span></div>
                    </div>
                    -->
                    
                    <td>
                        <input
                            type="checkbox"
                            data-button="switch"
                            data-name-ek="packages"
                            data-name="UCOTH"
                            style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        /><span class="span-new">${d.qj}</span>
                        <br>
                        <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="useSmeltFilter"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       /><span class="span-new">${d.Yc}</span>
                        <div class="setting-row">
                        <label for="getGold">Get Gold</label>
                        <div class="switch-field3">
                          
                          <input type="number" id="getGold" min="1000" max="200000000" placeholder="Amount">
                          <button id="ConfirmGetGold" class="awesome-button">OK</button>
                          <span class="span-new" id="goldMovedIndicator">${d.Md}: 0</span>
                        </div>
                      </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </fieldset>
    <fieldset>
        <legend>${d.ra}</legend>
        <table style="width: 100%">
        <tbody>
        <tr>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="1"/><label title="Wepons">${d.W}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="2"/><label title="Shields">${d.S}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="3"/><label title="Armour">${d.M}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="4"/><label title="Helmets">${d.P}</label>
            </td>
        </tr>
        <tr>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="5"/><label title="Gloves">${d.O}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="8"/><label title="Boots">${d.N}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="6"/><label title="Rings">${d.V}</label>
            </td>
            <td style="width: 25%">
                <input type="checkbox" 
                data-button="package"
                data-name="type"
                style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                value="9"/><label title="Amulets">${d.U}</label>
            </td>
        </tr>
            <tr>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="7"/><label title="Usables(Food)">${d.pa}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="12"/><label title="Upgrades">${d.wa}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="13"/><label title="Recipes">${d.ta}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="15"/><label title="Mercenary">${d.sa}</label>
                </td>
            </tr>
            <tr>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="19"/><label title="Forging btools">${d.va}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="20"/><label title="Scroll">${d.ua}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="11"/><label title="Reinforcements">${d.Oa}</label>
                </td>
                <td style="width: 25%">
                    <input type="checkbox" 
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="21"/><label title="Event Items">${d.Ma}</label>
                </td>
            </tr>
            <tr>
                <td style="width: 25%">
                    <input 
                    type="checkbox"
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="18"/><label title="Forging Goods">${d.Na}</label>
                </td>
                <td style="width: 25%">
                    <input 
                    type="checkbox"
                    data-button="package"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="14"/><label title="Gold">${d.dj}</label>
                </td>
                <td style="width: 25%">
                    <input 
                    type="checkbox"
                    data-button="packageAll"
                    data-name="type"
                    style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                    value="99"/><label>${d.T}</label>
                </td>
            </tr>
        </tbody>
        </table>
    </fieldset>
    <fieldset>
        <legend>Quality</legend>
        <table style="width: 100% box-shadow: 0px 5px 10px rgba(0,0,0,0.15);">
            <tbody>
                <tr>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="-1"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="White">${d.X}</label>
                    </td>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="0"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="Green">${d.B}</label>
                    </td>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="1"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="Blue">${d.A}</label>
                    </td>
                    <td style="width: 14.28%">
                        <input 
                        type="checkbox"
                        data-button="package"
                        data-name="quality"
                        value="2"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        type="checkbox"/><label title="Purple">${d.C}</label>
                    </td>
                    <td style="width: 14.28%">
                    <input
                      type="checkbox"
                      data-button="package"
                      data-name="quality"
                      value="3"
                      style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                      type="checkbox"/><label title="Orange">${d.G}</label>
                    </td>
                    <td style="width: 14.28%">
                    <input
                      type="checkbox"
                      data-button="package"
                      data-name="quality"
                      value="4"
                      style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                      type="checkbox"/><label title="Red">${d.R}</label>
                    </td>
                    <td style="width: 14.28%">
                    <input
                      type="checkbox"
                      data-button="packageAll"
                      data-name="quality"
                      value="99"
                      style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"    
                      type="checkbox"/><label title="All">${d.T}</label>
                  </td>
                </tr>
                <!-- Additional tr elements for Quality -->
            </tbody>
        </table>
    </fieldset>
</section>
`;b.before(`
                <h2 class="section-header" style="cursor: pointer" id="hidePackges">
                ${d.mj}
                </h2>`);b.before(e);c&&(c=document.querySelector(".custom_packages"),c.style.display="none"===c.style.display?"block":"none")}(),$(".custom-button:contains('sell all selected to merchants')").click(async function(){await N.sastm()}));N.start()}if(window.location.href.includes("mod=auction")){localStorage.getItem("auctionPrefixes")||localStorage.setItem("auctionPrefixes",JSON.stringify([]));localStorage.getItem("prefixes")||localStorage.setItem("prefixes",JSON.stringify([]));localStorage.getItem("searchTerms")||
localStorage.setItem("searchTerms",JSON.stringify([]));const b=document.getElementById("auction_table");let c;b&&(c=b.querySelectorAll(".auction_item_div"));const e=localStorage.getItem("highlightedItemHash");if(e){const h=document.querySelector(`form:has(div[data-hash="${e}"])`);h&&(h.style.outline="3px solid red",h.style.outlineOffset="4px",h.style.boxShadow="0 0 10px rgba(0, 0, 0, 0.5)",h.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"}),localStorage.removeItem("highlightedItemHash"))}if(!c||
0===c.length)return;c.forEach(h=>{h.style.position="relative";h.style.height="106px";const k=document.createElement("span");k.className="auction-icon";k.innerHTML="\ud83d\udd28";k.title="Add to Auction List";k.style.cursor="pointer";k.style.fontSize="16px";k.style.marginTop="88px";k.style.display="inline-block";k.style.marginRight="-25px";const g=document.createElement("span");g.className="smelt-icon";g.innerHTML="\ud83d\udd25";g.title="Add to Smelting List";g.style.cursor="pointer";g.style.fontSize=
"16px";g.style.marginTop="88px";g.style.display="inline-block";let l=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],q=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],m=JSON.parse(localStorage.getItem("smeltingSettings"))||[];const n=h.querySelector("[data-tooltip]"),r=n?n.getAttribute("data-tooltip"):null;if(r){var {itemName:w,Tm:u,Um:t,itemColor:A,itemType:z,itemLevel:y}=fh(r,n);try{JSON.parse(r.replace(/&quot;/g,'"'))}catch(x){return}w&&(l.includes(u)&&q.includes(t)&&(k.innerHTML=
"\u2705"),m.some(x=>{const v=""!=x.prefix&&u.includes(x.prefix)||""!=x.suffix&&t.includes(x.suffix);x="white"==A||x.colors.includes(A);return v&&x})&&(g.innerHTML="\u2705"),k.addEventListener("click",()=>{let x=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],v=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];JSON.parse(localStorage.getItem("searchTerms"));x.includes(u)||(x.push(u),localStorage.setItem("auctionPrefixes",JSON.stringify(x)));v.includes(t)||(v.push(t),localStorage.setItem("auctionSuffixes",
JSON.stringify(v)));mb(`Item "${w[0]}" added to the auction list!`);k.innerHTML="\u2705";setTimeout(()=>{k.innerHTML="\ud83d\udd28"},1E3)}),g.addEventListener("click",()=>{var x="white";switch(itemQuality){case "0":x="green";break;case "1":x="blue";break;case "2":x="purple";break;case "3":x="orange";break;case "4":x="red";break;default:x="white"}x={condition:"nameContains",prefix:u,suffix:t,colors:[x],itemTypes:[z],hammerState:"none",level:y,enabled:!0};let v=JSON.parse(localStorage.getItem("smeltingSettings"))||
[];v.push(x);localStorage.setItem("smeltingSettings",JSON.stringify(v));mb(`Item "${w[0]}" added to the smelting list!`);g.innerHTML="\u2705";setTimeout(()=>{g.innerHTML="\ud83d\udd25"},1E3)}),h.appendChild(g),h.appendChild(k))}})}if(window.location.href.includes("mod=packages")){await new Promise(e=>setTimeout(e,1E3));["auctionPrefixes","prefixes","searchTerms"].forEach(e=>{localStorage.getItem(e)||localStorage.setItem(e,JSON.stringify([]))});const b=document.getElementById("packages");if(!b)return;
const c=b.querySelectorAll(".packageItem");if(!c||0===c.length)return;c.forEach(e=>{const h=eh("\ud83d\udd28","auction-icon","pointer","16px","1px",`${d.vh}`),k=eh("\ud83d\udd25","smelt-icon","pointer","16px","40px",`${d.Tj}`),g=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],l=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],q=JSON.parse(localStorage.getItem("smeltingSettings"))||[],m=e.querySelector("[data-tooltip]"),n=m?m.getAttribute("data-tooltip"):null;if(n){var {itemName:r,Tm:w,
Um:u,itemColor:t,itemType:A,itemLevel:z}=fh(n,m);r&&(g.includes(w)&&l.includes(u)&&(h.innerHTML="\u2705"),q.some(y=>{const x=""!=y.prefix&&w.includes(y.prefix)||""!=y.suffix&&u.includes(y.suffix);y="white"==t||y.colors.includes(t);return x&&y})&&(k.innerHTML="\u2705"),h.addEventListener("click",()=>ej(w,u,r,h)),k.addEventListener("click",()=>fj(r,w,u,t,A,z,k)),e=e.querySelector('[data-no-combine="true"]'))&&(e.appendChild(h),e.appendChild(k))}})}var nb={D:{async start(){const b=JSON.parse(localStorage.getItem("Timers"));
if(!U("mod")||"auction"!==U("mod")){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(h=>c[h]).filter(h=>void 0!==h);if(0<e.length){zh(`mod=auction&itemType=${e[0]}`);return}}nb.D.L=[];nb.D.al=Math.floor(Bh().gold-Number(localStorage.getItem("storeGoldinAuctionholdGold")));nb.D.form=document.querySelectorAll("#auction_table form");nb.D.al&&await this.list(async()=>{0<this.L.length?await this.buy():
this.mo(b)})},async mo(b){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(q=>c[q]).filter(q=>void 0!==q);if(0===e.length)C("Auction Store: No valid auction types selected.");else{var h=parseInt(U("itemType"),10),k=U("ttype"),g=e.indexOf(h),l=g===e.length-1;"3"===k?l?(C("Auction Store: Last type reached, reloading and setting timeout for next cycle."),Y("enableHideGold",b.AuctionHoldGold||5),
window.location.reload()):zh(`mod=auction&itemType=${e[g+1]}`):-1!==g&&(C("Auction Store: Toggling to mercenary mode for current type:",h),zh(`mod=auction&itemType=${h}&ttype=3`))}},async list(b=!1){C(`${d.we}`);var c=this.al;const e="true"===localStorage.getItem("AuctionGoldCover");let h=[];const k=localStorage.getItem("storeInShopQuality")||-1;for(let q=0;q<this.form.length;q++){let m=this.form[q];var g=m.querySelector(".ui-draggable"),l=m.querySelector(".auction_bid_div");l=(l=l?l.querySelector('input[type="text"], input[type="number"]'):
null)?Number(l.value):0;g=g?Yb(g):0;l<=g&&l<=c&&h.push({oa:m,price:parseInt(l,10),value:g})}h.sort((q,m)=>m.price-q.price);for(let q of h)if(c=q.oa.querySelector(".ui-draggable").getAttribute("data-quality"),!(Number(c)<Number(k))){if(c=(c=(c=q.oa.querySelector(".auction_bid_div"))?c.querySelector("div > a"):null)?c.querySelector("span"):null){c=c.getAttribute("style");if(e&&c&&c.includes("green"))continue;if(!e&&c&&c.includes("green"))return!0;if(c&&c.includes("blue"))continue}nb.D.L.push([q.oa.getAttribute("action"),
{auctionid:q.oa.querySelector('input[name="auctionid"]').value,qry:q.oa.querySelector('input[name="qry"]').value,itemType:q.oa.querySelector('input[name="itemType"]').value,itemLevel:q.oa.querySelector('input[name="itemLevel"]').value,itemQuality:q.oa.querySelector('input[name="itemQuality"]').value,buyouthd:q.oa.querySelector('input[name="buyouthd"]').value,bid_amount:q.price,bid:q.oa.querySelector('input[name="bid"]').value}])}b&&await b()},async buy(){let b=nb.D.L.pop();await jQuery.ajax({type:"POST",
url:b[0],data:b[1]});0<nb.D.L.length?(await new Promise(c=>setTimeout(c,100)),await this.buy()):window.location.reload()}}},nh=localStorage.getItem("OillastRan"),oh=Date.now(),Va={Ql:"minerva diana vulcanus mars apollo merkur".split(" "),Hn:[20,60,150,0],Km:[],async start(){"mod=gods"!=nf?zh("mod=gods"):Va.Am(0)},Fn(){let b=(new Date).getTime(),c=Aa.nn?Aa.nn:[1];if(5>c.length)return!0;for(let e=0;e<c.length;e++){if(c[e]&&c[e]<b||!c[e]&&(0==Aa[Va.Ql[e]]&&!Aa.Sm||1==Aa[Va.Ql[e]]||2==Aa[Va.Ql[e]]))return!0;
!c[e]&&Aa.Sm&&Ra.isUnderworld()}return!1},async Pn(){var b=ab.origin;const c=ab.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);return(new DOMParser).parseFromString(await b.text(),"text/html")},async Am(b,c){if(c){var e=JSON.parse(localStorage.getItem("gods")),h=this.Ql[b],k=c.getElementById(h);k&&(c=parseInt(k.querySelector(".god_points").innerText.match(/\d+/)[0],10),k=k.querySelector(".god_cooldown span")?parseInt(k.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),
10):0,e=e[h],h=this.Hn[e],c>=h&&0==k&&0<h&&0<=e&&(Va.Km.push(!1),jQuery.get(G({mod:"gods",submod:"activateBlessing",god:b+1,rank:e+1,sh:U("sh")}),()=>{Va.Km.push(!1);5>b&&Va.Am(++b)})))}},async Vo(){var b=ab.origin,c=ab.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);c=new DOMParser;await new Promise(e=>setTimeout(e,800));b=c.parseFromString(await b.text(),"text/html");c=JSON.parse(localStorage.getItem("gods"));for(let e in c)if((c=b.getElementById(e))&&0===(c.querySelector(".god_cooldown span")?
parseInt(c.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0))return!0;return!1}},gh,vj={async start(){const b=localStorage.getItem("healPercentage")||25;var c=JSON.parse(localStorage.getItem("underworld")).isUnderworld;const e=localStorage.getItem("HealEnabled"),h=localStorage.getItem("HellHealHP")||15,k=localStorage.getItem("useVillaMedici"),g=localStorage.getItem("useHealingPotion"),l="true"===localStorage.getItem("usePray");if("true"==e&&aa.o<=Number(b)||"true"==
e&&aa.o<=parseInt(h)||"true"==k&&ba==wa&&aa.o<=b&&1==c||e&&"true"==g&&aa.o<=b&&1==c||e&&!c&&3>=Number(Bh().Ka)&&localStorage.getItem("autoEnterHell")&&aa.o<=localStorage.getItem("hellEnterHP")){c=document.createElement("div");c.setAttribute("id","lowHealth");c.setAttribute("style","\n                display: block;\n                position: absolute;\n                top: 140px;\n                left: 50%;\n                transform: translateX(-30%);\n                width: 115px;\n                color: rgba(234, 20, 20, 0.9);\n                background-color: rgba(0, 0, 0, 0.8);\n                font-size: 20px;\n                border-radius: 5px;\n                border-left: 10px solid rgba(234, 20, 20, 0.9);\n                border-right: 10px solid rgba(234, 20, 20, 0.9);\n                will-change: transform, opacity;\n                z-index: 999;\n            ");
c.innerHTML='<span class="span-new">Low Health!</span>';document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);async function q(){if("inventoryPage"!==document.body.id)zh("mod=inventory&sub=3&subsub=1");else{await new Promise(P=>setTimeout(P,500));var z=Array.from(document.querySelectorAll("#shop .ui-draggable"));const x=aa.gold,v=ab.searchParams.get("doll")||"";let D=!1,E=0,I=!1,J;var y=localStorage.getItem("HealPickBag");y&&(J=511+Number(y)||512);
for(const P of z){if(E>=Number(localStorage.getItem("FoodAmount")))break;z=parseInt(P.getAttribute("data-price-gold"),10);(y=(y=P.getAttribute("data-basis"))&&"7"===y.split("-")[0])&&(D=!0);if(x>=z&&y){D=!0;localStorage.removeItem("healingStateX");z=Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));if(J&&(y=document.querySelector(`#inventory_nav a.awesome-tabs[data-bag-number="${J}"]`)))if(y.click(),await new Promise(T=>setTimeout(T,370)),y=document.getElementById("inv"),
kf(y,P)){Ca(P,"inv");E++;await new Promise(T=>setTimeout(T,370));if(E>=Number(localStorage.getItem("FoodAmount"))&&"1"!==v){zh("mod=overview&doll=1");return}continue}else I=!0;if(I||!J)for(const T of z){if(E>=Number(localStorage.getItem("FoodAmount")))break;T.click();await new Promise(X=>setTimeout(X,500));z=document.getElementById("inv");if(kf(z,P)&&(Ca(P,"inv"),E++,await new Promise(X=>setTimeout(X,370)),E>=Number(localStorage.getItem("FoodAmount"))&&"1"!==v)){zh("mod=overview&doll=1");return}}}}D?
(C(`${d.ub}`),localStorage.removeItem("healingStateX"),await new Promise(P=>setTimeout(P,3E4)),window.location.reload()):"true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")?await K():(C(`${d.ub}`),localStorage.removeItem("healingStateX"),await new Promise(P=>setTimeout(P,3E4)),window.location.reload());async function K(){if("true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")){if(document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')){var P=
jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),T=P.attr("action");P=P.find('input[name="bestechen"]')[0];var X=U("sh");await jQuery.post(`${T}?mod=inventory&sub=3&subsub=1&sh=${X}`,{bestechen:P.value})?C(`${d.wb}`):C(`${d.xb}`)}else 0<Bh().hn&&"true"===localStorage.getItem("HealRubyToggle")&&!document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')?(P=jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),T=P.attr("action"),P=P.find('input[name="bestechen"]')[0],
X=U("sh"),await jQuery.post(`${T}?mod=inventory&sub=3&subsub=1&sh=${X}`,{bestechen:P.value})?C(`${d.wb}`):C(`${d.xb}`)):(C(`${d.se}`),localStorage.setItem("HealClothToggle","false"),localStorage.setItem("HealRubyToggle","false"));window.location.reload()}else localStorage.removeItem("healingStateX"),setTimeout(()=>{window.location.reload()},6E4)}return!1}}async function m(){if("guild"==U("mod"))localStorage.setItem("useVillaMedici","false"),zh("mod=overview");else if("guild_medic"!=U("mod"))zh("mod=guild_medic");
else{var z=Array.from(document.querySelectorAll("#content a")).filter(({href:y})=>y.includes("mod=guild_medic"));0<z.length?window.location.href=z[0].href:(z=Math.min(...Array.from(document.querySelectorAll("span[data-ticker-time-left]")).map(y=>parseInt(y.getAttribute("data-ticker-time-left"),10))),isFinite(z)&&Y("VillaMedici",Math.ceil(z/6E4)),l?(C(`${d.Aa}`),zh("mod=underworld&submod=prayStart")):window.location.reload())}}async function n(){let z=!1;if("mod=premium&submod=inventory"!=nf)zh("mod=premium&submod=inventory");
else{await new Promise(y=>setTimeout(y,500));for(let y=0,x=document.querySelectorAll(".contentboard_paper_repeat");y<x.length;y++)if(x[y].querySelector("img").src&&x[y].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")||x[y].querySelector("img").src&&x[y].querySelector("img").src.includes("token/18")||x[y].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")){z=!0;x[y].querySelector("input").click();Ef(1E3);return}z||(localStorage.setItem("useHealingPotion","false"),
l?(C(`${d.Aa}`),zh("mod=underworld&submod=prayStart")):Ef(1E3))}}async function r(){try{let E=document.getElementById("inv"),I=0,J;var z=localStorage.getItem("HealPickBag"),y=localStorage.getItem("PackageSort");J=z?511+Number(z)||512:512;var x=Array.from(document.querySelectorAll(`#inventory_nav a.awesome-tabs[data-bag-number="${J}"]`));0<x.length&&x[0].click();x=1;let K=0,P=!1;z=[];const T=Number(localStorage.getItem("FoodAmount"))||1;let X=!1;if(y&&"del_asc"===y||y&&"in_asc"===y)x=await ha.Xl(-1,
"",7),X=!0;for(;!P&&5>K;){var v=await jQuery.get(G({mod:"packages",f:"7",fq:"-1",qry:"",page:x.toString(),sh:U("sh")})),D=jQuery(v).find(".packageItem");if(0===D.length)C(`${d.te} (Page ${x})`),K++,X?x--:x++;else{z=[];for(y=0;y<D.length;y++){const fa=D[y],na=fa.querySelector("[data-content-type]"),ta=parseInt(na.getAttribute("data-soulbound-to"),10),la=parseInt(na.getAttribute("data-basis").split("-")[1],10);(![30,35].includes(la)&&isNaN(ta)||![30,35].includes(la)&&ta===Number(idkps))&&z.push(fa)}0<
z.length?P=!0:(C(`${d.yb} (Page ${x})`),K++,X?x--:x++)}}if(!P)return localStorage.setItem("healingStateX","true"),C(`${d.zb}`),!1;v=[5,8];const ia=Fc(E);for(D=0;I<T&&D<z.length;){const fa=z[D],na=fa.querySelector("[data-content-type]"),ta=fa.querySelector("input").getAttribute("value"),la=parseInt(na.getAttribute("data-measurement-x"),10),xa=parseInt(na.getAttribute("data-measurement-y"),10),Na=parseInt(na.getAttribute("data-amount"),10),Gb=Gc(v[0],v[1],ia),Oa=Hc(xa,la,Gb);if(Oa){ia.push({x:Oa.x,
y:Oa.y,cl:xa,w:la});await jQuery.post(S({mod:"inventory",submod:"move",from:"-"+ta,fromX:1,fromY:1,to:J,toX:Oa.x+1,toY:Oa.y+1,amount:Na}),{a:(new Date).getTime(),sh:U("sh")});I++;const Xa=jQuery(na).css({left:32*Oa.x,top:32*Oa.y});E.appendChild(Xa[0]);C(`${d.qe}`);await new Promise(mc=>setTimeout(mc,500))}else{C(`${d.re}`);break}D++}if(0<I)return I>=T?C(`${d.ue}`):C(`${d.ve}`),!0;C(`${d.zb}`);return!1}catch(E){return C(`Error in pickFood(): ${E}`),!1}}async function w(){var z=document.querySelector("#header_values_hp_bar");
const y=parseInt(z.getAttribute("data-value"),10);z=parseInt(z.getAttribute("data-max-value"),10);return{In:y,eo:z}}async function u(){var z=JSON.parse(localStorage.getItem("underworld")).isUnderworld,y="true"===localStorage.getItem("useSacrifice");const x="true"===localStorage.getItem("HealShop"),v=localStorage.getItem("HellHealHP")||15,D="true"===localStorage.getItem("healingStateX"),E="true"===localStorage.getItem("HealPackage"),I=document.getElementById("sstat_ruby_val");let J=0;I&&(J=I.textContent.trim().replace(/\./g,
""),J=parseInt(J,10));if(D&&x)await q()?await u():(localStorage.removeItem("healingStateX"),await A());else if(!0===z||"true"===g&&!0===z||!0===y&&!0===z)"true"===localStorage.getItem("useVillaMedici")&&W("VillaMedici")?m():"true"===localStorage.getItem("useHealingPotion")?await n():y&&5<=Number(J)?(C("Sacrificing for heal."),zh("mod=underworld&submod=offering")):l&&"mod=underworld&submod=pray"!=nf&&("true"===localStorage.getItem("HealEnabled")?aa.o<=Number(v):1)?(C(`${d.Aa}`),zh("mod=underworld&submod=prayStart")):
l&&"mod=underworld&submod=pray"==nf&&("true"===localStorage.getItem("HealEnabled")?aa.o<=Number(v):1)?(await new Promise(K=>setTimeout(K,6E4)),C(`${d.Ie}`),window.location.reload()):(C(`${d.Je}`),Ef(6E4));else if(0==z)if("1"!==((new URL(window.location.href)).searchParams.get("doll")||""))"mod=overview&doll=1"!=nf&&zh("mod=overview&doll=1");else if(y=await A(),!y&&aa.o<=Number(b)||!y&&!z&&3>=Number(Bh().Ka)&&localStorage.getItem("autoEnterHell")&&aa.o<=localStorage.getItem("hellEnterHP"))E?(z=await r(),
!z&&x?(localStorage.setItem("healingStateX","true"),q()):(z||(C(`${d.vb}`),await new Promise(K=>setTimeout(K,3E4))),window.location.reload())):x?(localStorage.setItem("healingStateX","true"),q()):(C(`${d.vb}`),await new Promise(K=>setTimeout(K,3E4)),window.location.reload())}async function t(z,y,x){let v=null,D=0,E=Infinity;const I=localStorage.getItem("idkps")||0,J="true"===localStorage.getItem("HealCervisia"),K="true"===localStorage.getItem("HealEggs");let P=!1;J&&(P=await sf());z.forEach(T=>
{var X=T.getAttribute("data-basis");const ia=parseInt(T.getAttribute("data-soulbound-to"),10);var fa=(fa=T.getAttribute("data-tooltip").match(/Heals ([\d,\.]+) of life/))?parseInt(fa[1].replace(/\./g,""),10):0;const na=x-(y+fa);if(!ia||ia===parseInt(I,10)){if(X.startsWith("7-")){X=parseInt(X.split("-")[1],10);if(!K&&23<=X&&34>=X||!J&&35===X)return;if(J&&35===X&&P)P=!0;else if(35===X&&J&&!P)return}0<=na&&na<E?(v=T,E=na):0>na&&fa>D&&(D=fa,v=T)}});return v}async function A(){return new Promise(async z=>
{let y=!1;const {In:x,eo:v}=await w();var D=new URL(window.location.href);const E=D.origin;D=D.searchParams.get("sh");if("mod=overview&doll=1"!=nf)zh("mod=overview&doll=1");else{const X="true"===localStorage.getItem("HealPackage"),ia="true"===localStorage.getItem("HealShop"),fa="true"===localStorage.getItem("HealCervisia"),na="true"===localStorage.getItem("HealEggs");let ta=!1;fa&&(ta=await sf());var I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs")),J=I.findIndex(la=>la.classList.contains("current"));
I=I.slice(J).concat(I.slice(0,J));for(J=0;J<I.length;J++){var K=I[J];if("false"!==K.getAttribute("data-available")&&(await new Promise(la=>setTimeout(la,175)),K.click(),K.classList.contains("current"))){K=document.querySelectorAll("#inv .ui-draggable");K=Array.from(K).filter(la=>{const xa=la.getAttribute("data-basis");la=parseInt(la.getAttribute("data-soulbound-to"),10);const Na=parseInt(xa.split("-")[1],10);if(!la||la===parseInt(idkps,10)){if(xa.startsWith("7-")){if(!na&&23<=Na&&34>=Na||!fa&&35===Na)return;
if(ta&&fa&&35===Na)ta=!0;else if(35===Na&&fa&&!ta)return}return xa&&"7"===xa.split("-")[0]}});var P=void 0,T=!1;if(Ra.cooldown()&&"true"==localStorage.getItem("autoEnterHell")){P=await (await fetch(`${E}/game/index.php?mod=hermit&sh=${D}`)).text();P=(new DOMParser).parseFromString(P,"text/html");P=Array.from(P.querySelectorAll('div[style="margin:20px"]'));for(let la of P)if(la.querySelector('a[href^="index.php?mod=hermit&submod=underworld&sh="]')){T=!0;break}}if(T){T=0;P=localStorage.getItem("idkps");
for(const la of K)if(K=parseInt(la.getAttribute("data-soulbound-to"),10),(!K||K===parseInt(P,10))&&"true"===localStorage.getItem("autoEnterHell"))if(la){if(await new Promise(xa=>setTimeout(xa,250)),await Ca(la,"avatar"),await new Promise(xa=>setTimeout(xa,450)),C(`${d.tb}`),T++,2<=T){window.location.reload();return}}else{K=!1;X&&(K=await r());if(!K&&ia)return localStorage.setItem("healingStateX","true"),q(),!0;window.location.reload()}}else for(const la of K){y=!0;if(T=await t(K,x,v)){await new Promise(xa=>
setTimeout(xa,250));await Ca(T,"avatar");await new Promise(xa=>setTimeout(xa,450));C(`${d.tb}`);window.location.reload();return}T=!1;X&&(T=await r());if(!T&&ia){localStorage.setItem("healingStateX","true");q();return}window.location.reload()}}}z(y)}})}await u()}}},Ra={isUnderworld(){if("underworld"==document.getElementById("wrapper_game").className){var b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else b=JSON.parse(localStorage.getItem("underworld")||
"{}"),b.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(b));return(b=document.querySelector("#submenu2 a"))&&b.href.match(/mod=.*&sh/)&&"mod=underworld&submod=leave"===b.href.match(/mod=.*&sh/)[0].slice(0,-3)?!0:!1},oi(){return!0!==(JSON.parse(localStorage.getItem("underworld"))||{}).oi},cooldown(){var b=(new Date).getTime();let c=JSON.parse(localStorage.getItem("underworld"))||{};c.cooldown=b;localStorage.setItem("underworld",JSON.stringify(c));let e=document.getElementById("submenu2");
e&&e.innerHTML.includes("index.php?mod=underworld")?c.isUnderworld=!0:c.isUnderworld=!1;if(ra.cooldown&&ra.cooldown>b)return!1;if(b=document.querySelectorAll(".buff-clickable"))for(let h of b)if(h.getAttribute("data-link")=="index.php?mod=location&sh="+U("sh"))return!1;return!0},async start(){function b(){var v=`expedition_info${parseInt(localStorage.getItem("farmEnemy"),10)||1}`,D=document.getElementById(v);if(!D)return!1;v=D.querySelector(".expedition_picture img");D=D.querySelector(".expedition_picture .avatar_costume_animation");
if(!v&&!D)return!1;if(v){var E=v.getAttribute("src");if(!E)return!1;E=!E.includes("904194973d21066c96cb414d04d676")}D&&(E=D.style.backgroundImage.match(/url\("(.+?)"\)/),v=null,E&&E[1]&&(v=E[1]),E=!v.includes("904194973d21066c96cb414d04d676"));return E}async function c(){if(Ra.isUnderworld||!t){0<(JSON.parse(localStorage.getItem("GodPowersHell"))||[]).length&&await e();var v="true"===localStorage.getItem("useWeaponBuff"),D=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||[],E=[];v&&E.push({type:"weapon",
dc:"12-1",Ol:[3]});if(0<D.length){const I={Helmet:2,Armor:5,Shield:4,Boots:10,Gloves:9};v=D.map(J=>I[J]).filter(J=>J);0<v.length&&E.push({type:"armor",dc:"12-3",Ol:v})}0<E.length&&await h(E);localStorage.setItem("usedGodPowers","true")}}async function e(){if("true"===localStorage.getItem("useGodPowersHell")){var v=JSON.parse(localStorage.getItem("GodPowersHell"))||[],D="Minerva Diana Vulcan Mars Apollo Mercury".split(" ");for(let E of v)if(v=D.indexOf(E),-1<v)try{await jQuery.get(G({mod:"gods",submod:"activateBlessing",
god:v+1,rank:1,sh:U("sh")})),C(`${E} power activated`)}catch(I){console.error(`Failed to activate ${E} power:`,I)}}}async function h(v){var D=v.map(I=>I.dc);const E={};D=await k(D);Object.assign(E,D);for(let I of v.slice())if(D=E[I.dc])await q(D,I.Ol),v=v.filter(J=>J.dc!==I.dc),C(`${I.type.charAt(0).toUpperCase()+I.type.slice(1)} buff equipped on slots ${I.Ol.join(", ")}`);0<v.length&&await g(v)}async function k(v){return new Promise(async D=>{const E={};var I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));
for(let J of I)if("false"!==J.getAttribute("data-available")){J.click();await new Promise(K=>setTimeout(K,200));I=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let K of I)if(I=K.getAttribute("data-basis"),v.includes(I)&&!E[I]){const P=parseInt(K.getAttribute("data-position-x"),10),T=parseInt(K.getAttribute("data-position-y"),10),X=parseInt(K.getAttribute("data-container-number"),10);E[I]={fromX:P,fromY:T,from:X};if(Object.keys(E).length===v.length){D(E);return}}}D(E)})}async function g(v){try{let D=
1;for(;1<=D&&7>=D&&0<v.length;){const E=await jQuery.get(G({mod:"packages",f:"12",page:D.toString(),sh:U("sh")})),I=Array.from(jQuery(E).find(".packageItem"));for(let J of I){const K=J.querySelector("[data-content-type]"),P=J.querySelector("[data-container-number]");K.getAttribute("data-measurement-x");K.getAttribute("data-measurement-y");const T=K.getAttribute("data-basis");P.getAttribute("data-container-number");const X=P.getAttribute("data-container-number"),ia=v.find(fa=>fa.dc===T);if(ia&&await l(X,
ia.Ol)&&(C(`${ia.type.charAt(0).toUpperCase()+ia.type.slice(1)} buff equipped on slots ${ia.Ol.join(", ")}`),v=v.filter(fa=>fa.dc!==T),0===v.length))return}D++}if(0<v.length)for(let E of v)C(`Could not find ${E.type} buff to equip.`)}catch(D){}}async function l(v,D){return new Promise((E,I)=>{ic(1,1,async(J,K)=>{try{await jQuery.post(S({}),{mod:"inventory",submod:"move",from:v,fromX:1,fromY:1,to:K,toX:J.x+1,toY:J.y+1,amount:1,a:(new Date).getTime(),sh:U("sh")});const P={fromX:J.x+1,fromY:J.y+1,from:K};
await q(P,D);E(P)}catch(P){console.error("Error moving item to inventory and equipping:",P),I(P)}})})}async function q(v,D){for(let E of D)await m(v.from,v.fromX,v.fromY,E,1,1,!0),await new Promise(I=>setTimeout(I,200))}async function m(v,D,E,I,J,K,P=!1){v={mod:"inventory",submod:"move",from:v,fromX:D,fromY:E,to:I,toX:J,toY:K,amount:1,a:(new Date).getTime(),sh:U("sh")};P&&(v.doll=1);await jQuery.post(S({}),v)}this.location=Array.from(document.querySelectorAll("#submenu2 a")).pop().href;var n="true"===
localStorage.getItem("farmEnable"),r=localStorage.getItem("farmLocation")||1;const w=localStorage.getItem("farmEnemy")||1;var u="true"===localStorage.getItem("useGodPowersHell");const t="true"===localStorage.getItem("usedGodPowers");var A=localStorage.getItem("hellLimit")||0;const z="true"===localStorage.getItem("EnableHellLimit");if(u&&!t){if("mod=overview&doll=1"!=nf){zh("mod=overview&doll=1");return}await c()}let y;n&&(y=b());u=localStorage.getItem("HellHealHP")||15;aa.o>=Number(u)&&await jQuery.get(G({mod:"underworld",
submod:"prayEnd",sh:U("sh")}));if("true"==localStorage.getItem("exitUnderworld")&&0==Number(Bh().Ka))A=JSON.parse(localStorage.getItem("underworld")),A.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(A)),await jQuery.get(G({mod:"underworld",submod:"exit",sh:U("sh")})),C(`${d.Ke}`),location.reload();else{if(0==Number(Bh().Ka)&&"true"==localStorage.getItem("UnderworldUseMobi")){if("mod=premium&submod=inventory"!==nf){zh("mod=premium&submod=inventory");return}u=document.querySelectorAll(".contentboard_paper_repeat");
for(var x=0;x<u.length;){u[x].querySelector("img").src&&(u[x].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7")||u[x].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7"))?u[x].querySelector("input").click():localStorage.setItem("UnderworldUseMobi","false");Ef(500);return}}x=document.querySelector("#submenu2");u=x.querySelector(`#location_inactive_${r}`);x=x.querySelector(`a[href*="loc=${r}"]`);u=u&&u.classList.contains("inactive");if(!n||u&&!x||nf===`mod=location&loc=${r}`)if(n&&
nf==`mod=location&loc=${r}`&&y&&(!z||z&&0<A))n=parseInt(w,10),r=document.getElementsByClassName("expedition_button"),z&&(A--,localStorage.setItem("hellLimit",A)),r[n-1].click(),Ef(5E3);else if(window.location.href!=this.location)window.location.href=this.location;else{await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:U("sh")}));let v=0;Array.from(document.querySelectorAll(".expedition_box")).forEach(D=>{D.querySelector(".expedition_picture img")&&D.querySelector("img").src.includes("904194973d21066c96cb414d04d676")&&
v++});document.querySelector("#content .icon_expeditionpoints")&&0<Number(Bh().Ka)||"true"==localStorage.getItem("UnderWorldUseRuby")&&"0"==Bh().Ka?(Q("underworldAttacks",0),document.querySelectorAll(".expedition_button")[Math.floor(3-v)].click()):(C(`${d.Le}`),await new Promise(D=>setTimeout(D,6E4)),Ef())}else zh(`mod=location&loc=${r}`)}},async Nn(){let b=0;const c=["normal","medium","hard"][parseInt(localStorage.getItem("hellDifficulty"),10)||0],e=G({mod:"hermit",submod:"enterUnderworld",sh:U("sh")}),
h={};h[`difficulty_${c}`]=c.charAt(0).toUpperCase()+c.slice(1);try{jQuery.post(e,h),localStorage.setItem("usedGodPowers","false"),await new Promise(k=>{const g=++b;var l=!document.hidden;let q=1;var m=jQuery("#server-time");0<m.length&&(m=m.next().html())&&(m=m.match(/x(\d+)$/)||["0","1"],m=parseInt(m[1],10),0<m&&(q=5/m));l=l?400:400*q;if("undefined"!==typeof Worker){const n=URL.createObjectURL(new Blob(["\n                            const timers = {};\n                            self.onmessage = function(event) {\n                                const { type, id, delay } = event.data;\n                                if (type === 'setTimeout') {\n                                    timers[id] = setTimeout(() => {\n                                        self.postMessage({ type: 'timeout', id });\n                                        delete timers[id];\n                                    }, delay);\n                                }\n                                if (type === 'clearTimeout') {\n                                    if (timers[id]) {\n                                        clearTimeout(timers[id]);\n                                        delete timers[id];\n                                    }\n                                }\n                            };\n                        "],
{type:"application/javascript"})),r=new Worker(n),w=u=>{"timeout"===u.data.type&&u.data.id===g&&(k(),r.removeEventListener("message",w),r.terminate(),URL.revokeObjectURL(n))};r.addEventListener("message",w);r.postMessage({type:"setTimeout",id:g,delay:l})}else setTimeout(()=>{k()},l)}),window.location.reload()}catch(k){}}};null===localStorage.getItem("DELAY")&&localStorage.setItem("DELAY","0 seconds");var Ac=localStorage.getItem("DELAY");if(Ac.includes("to")){const b=Ac.split(" "),c=parseInt(b[0],
10);var Tb=Math.floor(Math.random()*(parseInt(b[2],10)-c+1))+c}else Tb=parseInt(Ac.split(" ")[0],10);Ac.includes("minute")&&(Tb*=60);var Ub=1E3*Tb,wj=localStorage.getItem("costumeUnderworld"),xj=["9","10","11"],Bc="true"===localStorage.getItem("activateAuction2"),ph="true"===localStorage.getItem("auctionTURBO"),Cc="true"===localStorage.getItem("bidFood"),qh=9<aa.level,rh="true"===localStorage.getItem("enableCircusWithoutHeal"),th="true"===localStorage.getItem("auctiongladiatorenable"),uh="true"===
localStorage.getItem("auctionmercenaryenable"),Dc="true"===localStorage.getItem("enableMercenarySearch"),ff="true"===localStorage.getItem("EnableArenaHell"),yj="true"===localStorage.getItem("dontEnterUnderworld"),Ec=0<JSON.parse(localStorage.getItem("auctionPrefixes")).length||0<JSON.parse(localStorage.getItem("auctionSuffixes")).length,Bb=localStorage.getItem("auctionStatus")>=localStorage.getItem("bidStatus"),vh=localStorage.getItem("auctionMStatus")>=localStorage.getItem("bidStatus"),ob=JSON.parse(localStorage.getItem("underworld")),
Cb=W("auction"),wh=W("auctionM"),xh=localStorage.getItem("MarketlastRan"),zj=localStorage.getItem("MarketSearchInterval")||5,Aj=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),Bj=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),yh=JSON.parse(localStorage.getItem("itemsToReset")||"[]");qa&&"true"===localStorage.getItem("activateRepair")&&lj();0<Ub&&11E3>Ub&&(C(`Waiting for ${Tb} seconds...`),await new Promise(b=>setTimeout(b,Ub)));if(qa&&(0<Object.keys(Aj).length||0<Object.keys(Bj).length)&&
"true"===localStorage.getItem("activateRepair")&&W("repair")&&!window.location.href.includes("/index.php?mod=hermit&submod=underworld")&&ba==wa&&1E4<Bh().gold&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)){const b="true"===localStorage.getItem("repairGladiator"),c="true"===localStorage.getItem("repairMercenary");let e=[],h=[];const k=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||
"{}");async function l(u,t,A){const z=localStorage.getItem("repairPercentage"),y=null!==z?parseInt(z,10)/100:.1;u=await (await fetch(`${u}/game/index.php?mod=overview&doll=${t}&sh=${A}`)).text();u=(new DOMParser).parseFromString(u,"text/html").getElementById("char").querySelectorAll("div[data-tooltip]");A=(A=localStorage.getItem("workbenchItem"))?JSON.parse(A):{};A.selectedItem=A.selectedItem||{};let x=[];u.forEach(v=>{if(v.classList.contains("ui-draggable")){let D=Xb(v),E=v.getAttribute("data-container-number"),
I=v.getAttribute("data-measurement-x"),J=v.getAttribute("data-measurement-y"),K=JSON.parse(v.getAttribute("data-tooltip")).pop().pop()[0].match(/\d+/g);null!=K&&K[0]/K[1]<y&&x.push({type:vb(v),quality:pb(v),name:D,doll:t,container:E,Wm:I,Xm:J})}});return x}const q=ab.origin,m=ab.searchParams.get("sh")||"";let n=localStorage.getItem("workbenchItem");n=n?JSON.parse(n):{};b&&(e=await l(q,1,m),localStorage.setItem("itemList1",JSON.stringify(e)),sa.itemList1=e);c&&(h=await l(q,2,m),localStorage.setItem("itemList2",
JSON.stringify(h)),sa.itemList2=h);const r=JSON.parse(localStorage.getItem("Timers"));n.selectedItem||(b&&c?0===e.length&&0===h.length&&Y("repair",r.Repair||10):b?0===e.length&&Y("repair",r.Repair||10):c?0===h.length&&Y("repair",r.Repair||10):Y("repair",r.Repair||10));function w(u,t,A){return Array.isArray(u)&&0!==u.length?u.filter(z=>{const y=Object.keys(t).find(x=>t[x]===z.container);return y?!1!==A[y]:!0}):u}e=w(e,{helmet:"2",necklace:"11",weapon:"3",armor:"5",shield:"4",gloves:"9",shoes:"10",
rings1:"6",rings2:"7"},k);h=w(h,{helmetM:"2",necklaceM:"11",weaponM:"3",armorM:"5",shieldM:"4",glovesM:"9",shoesM:"10",rings1M:"6",rings2M:"7"},g);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(h));sa.itemList1=e;sa.itemList2=h;if(n.selectedItem&&!0===n.selectedItem.enable){let u=e.findIndex(t=>t.name===n.selectedItem.item.name);-1!==u&&e.splice(u,1);u=h.findIndex(t=>t.name===n.selectedItem.item.name);-1!==u&&h.splice(u,1);localStorage.setItem("itemList1",
JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(h))}if(b&&0<e.length||c&&0<h.length||n.selectedItem&&0<Object.keys(n.selectedItem).length)await uj.start();else{const u=JSON.parse(localStorage.getItem("Timers"));Y("repair",u.Repair||10);window.location.reload()}}else if(0==await bj(wa,cc,pa))gb();else if((Bc||Cc||Dc)&&ph&&Bc&&qa&&qh&&(th&&Ec&&Bb&&Cb&&W("AuctionEmpty")||Cc&&Bb&&Cb&&W("AuctionEmpty")||Dc&&Bb&&Cb&&W("AuctionMEmpty")||uh&&Ec&&vh&&wh&&W("AuctionMEmpty")))await za.start();
else if(qa&&3>=Number(Bh().Ka)&&!0===Ba&&"true"===localStorage.getItem("autoEnterHell")&&100<=aa.level&&8E3<=aa.gold&&aa.o>Number(localStorage.getItem("hellEnterHP"))&&Ra.cooldown()&&(yj?Ra.oi():1))await Ra.Nn();else if(1==qa&&"true"===localStorage.getItem("OilEnable")&&Va.Fn()&&(!nh||36E5<=oh-nh)){C(`${d.xe}`);localStorage.setItem("OillastRan",oh.toString());const b=await Va.Pn();for(let c=0;c<Va.Ql.length;c++)await Va.Am(c,b);C(`${d.ye}`);$e()}else if(qa&&(aa.o<=Number(localStorage.getItem("healPercentage"))&&
"true"===localStorage.getItem("HealEnabled")&&!Ra.isUnderworld()||3>=Number(Bh().Ka)&&!Ra.isUnderworld()&&Ra.cooldown()&&"true"===localStorage.getItem("autoEnterHell")&&aa.o<=Number(localStorage.getItem("hellEnterHP"))||Ra.isUnderworld()&&"true"===localStorage.getItem("autoEnterHell")&&aa.o<=Number(localStorage.getItem("HellHealHP"))))await vj.start();else if(qa&&Ba&&"true"===localStorage.getItem("autoEnterHell")&&Ra.isUnderworld()&&Bh().On)await Ra.start();else if(qa&&"true"==localStorage.getItem("useCostume")&&
(!window.location.href.includes("/index.php?mod=hermit")&&W("CheckDolls")&&xj.some(b=>wj.includes(b))||!window.location.href.includes("/index.php?mod=hermit")&&W("CheckDolls")))await df.start();else if(qa&&(!0===La&&L()&&ba==wa||!0===La&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&Rb<Sb&&ba==wa)){localStorage.setItem("nextQuestTime.timeOut",0);localStorage.setItem("nextQuestTime",0);function b(k){const g={Diana:"026bb622a42b4d00abc74c67f28d63",
Apollo:"bb75bf0df76de3ec421bbfb0eac3c5",Vulcan:"6fbd05e43d699e65fc40cc92a17c51",Minerva:"72919cc6b457bf475fb81cc7de8863",Mercury:"5e272e2aade20b4a266e48663421ce",Mars:"5fd915f85b3e5e71b64632af0c6543"};k=k.querySelectorAll(".quest_slot_reward img");for(const l of k){k=l.getAttribute("src");for(const [q,m]of Object.entries(g))if(k.includes(m)&&"true"===localStorage.getItem(`questType${q}`))return!0}}function c(k){var g=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]").map(q=>q.toLowerCase());
const l=parseInt(localStorage.getItem("questrewardvalue"),10);if(k=$(k).find(".quest_slot_reward_item")[0]){const q=k.outerHTML.toLowerCase();if(g.some(m=>q.includes(m))&&(g=q.match(/(\d+\.\d+)/))&&parseFloat(g[0].replace(".",""))>=l)return!0}return!1}async function e(){var k=ab.origin,g=$("#content .contentboard_slot a.quest_slot_button_accept"),l="true"===localStorage.getItem("skipTimeQuests");const q="true"===localStorage.getItem("skipTimeCircusQuests"),m="true"===localStorage.getItem("skipTimeOtherQuests"),
n="true"===localStorage.getItem("acceptnotfilter"),r="true"===localStorage.getItem("UnderworldQuests"),w=JSON.parse(localStorage.getItem("questKeywords")||"[]"),u=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]"),t=JSON.parse(localStorage.getItem("underworldQuestKeywords")||"[]"),A=JSON.parse(localStorage.getItem("underworld")||"{}");var z=$("#content .contentboard_slot_inactive").toArray();if(g.length){function y(x){return x.includes("8aada67d4c5601e009b9d2a88f478c")?"combat":x.includes("00f1a594723515a77dcd6d66c918fb")?
"arena":x.includes("586768e942030301c484347698bc5e")?"circus":x.includes("4e41ab43222200aa024ee177efef8f")?"expedition":x.includes("dc366909fdfe69897d583583f6e446")?"dungeon":x.includes("5a358e0a030d8551a5a65d284c8730")?"items":null}g=!1;for(const x of z){let v=x.getElementsByClassName("quest_slot_title")[0].innerText;z=y(x.getElementsByClassName("quest_slot_icon")[0].style.backgroundImage);if(!(l&&0<x.getElementsByClassName("quest_slot_time").length&&"arena"==z||q&&0<x.getElementsByClassName("quest_slot_time").length&&
"circus"==z||m&&0<x.getElementsByClassName("quest_slot_time").length&&"circus"!==z&&"arena"!==z)){if(1==A.isUnderworld&&r&&!g&&0<t.length&&Ma[z]&&r){const D=$(x).find(".quest_slot_reward_item img[data-tooltip]")[0];if(D){z=D.getAttribute("data-tooltip");const E=JSON.parse(z.replace(/&quot;/g,'"'))[0][0][0].toLowerCase();if(t.some(I=>E.includes(I.toLowerCase()))){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();g=!0;break}else continue}}if(!w.some(D=>
v.includes(D))){if(Ma[z]&&b(x)){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();g=!0;break}if(Ma[z]&&c(x)&&!n){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();g=!0;break}if(Ma[z]&&u.some(D=>v.includes(D))){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();g=!0;break}!g&&Ma[z]&&n||g||!Ma[z]||n||0!==u.length||(g=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),
await jQuery.get(g).done(),g=!0)}}}if(g)return;k=`${k}/game/index.php?mod=quests&submod=resetQuests&sh=${U("sh")}`;await jQuery.get(k).done();window.location.reload()}h()}async function h(){var k=$("#quest_header_cooldown");let g;switch(localStorage.getItem("questSpeed")){case "0":g=15E4;break;case "1":g=2E5;break;case "2":g=25E4;break;case "3":g=3E5;break;case "4":g=4E5;break;default:g=3E5}k.length?(k=Number($("#quest_header_cooldown b span").attr("data-ticker-time-left")),Rb=Sb+k):Rb=Sb+g;localStorage.setItem("nextQuestTime",
Rb);window.location.reload()}await async function(){if("mod=quests"!=nf)zh("mod=quests");else{let k=[];const g=[],l=[];document.querySelectorAll("a.quest_slot_button_finish").forEach(n=>{n.href&&k.push(n.href)});document.querySelectorAll(".quest_slot_button_restart").forEach(n=>{n.href&&g.push(n.href)});document.querySelectorAll(".quest_slot_button_accept").forEach(n=>{n.href&&l.push(n.href)});async function q(n){try{n<k.length&&(await jQuery.get(k[n]),await q(n+1))}catch(r){}}async function m(n){try{n<
g.length&&(await jQuery.get(g[n]),await m(n+1))}catch(r){console.error("Error in completeQuestsForLink:",r)}}await async function(){0<k.length&&await q(0);0<g.length&&await m(0);0<l.length&&await e();await h()}()}}()}else if(qa&&Jc()&&!0===Ba&&0==ob.isUnderworld&&ba==wa&&0==yc.isUnderworld&&ea>=new Date&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&!0===document.getElementById("cooldown_bar_fill_expedition").classList.contains("cooldown_bar_fill_ready"))await async function(){function b(){const g=
document.getElementById("errorText");"false"===localStorage.getItem("HealEnabled")?(Ya("Your expedition/dungeon settings are incorrect!"),localStorage.setItem("HealEnabled","true"),Ef(5E3)):g&&""!==g.innerText.trim()&&location.reload()}var c=localStorage.getItem("expeditionLocation");if(nf!=`mod=location&loc=${c}`)zh(`mod=location&loc=${c}`);else if("true"===localStorage.getItem("nana_lcn")&&cc){var e="true"===localStorage.getItem("autoCollectBonuses"),h=localStorage.getItem("selectedEnemy")||0;c=
document.getElementsByClassName("expedition_button");var k=document.querySelectorAll(".expedition_button.disabled");try{if(Q("expeditionAttacks",0),e)for(await new Promise(g=>setTimeout(g,800)),e=0;e<c.length;e++){if(4>c[e].closest(".expedition_box").querySelectorAll(".expedition_bonus.active").length||3===e){c[e].click();break}if(4<=k.length){window.location.reload();break}else setTimeout(b,800)}else c[parseInt(h,10)].click(),4<=k.length?window.location.reload():setTimeout(b,800)}catch{C("There's a problem with the expedition, refreshing the page."),
window.location.reload()}}}();else if(qa&&!0===Ga&&!ob.isUnderworld&&ba==wa&&9<aa.level&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&Bh().Mn&&"none"!==document.getElementById("cooldown_bar_dungeon").style.display&&!0===document.getElementById("cooldown_bar_fill_dungeon").classList.contains("cooldown_bar_fill_ready"))await async function(){if("true"===localStorage.getItem("nana_lcn")&&cc){var b=localStorage.getItem("dungeonLocation")||"1",c=
"true"===localStorage.getItem("skipBoss"),e="true"===localStorage.getItem("resetIfLose"),h="true"===localStorage.getItem("loose"),k="true"===localStorage.getItem("dungeonFocusQuest"),g="chefe Chefe \u0161\u00e9f chef chef juht boss Boss jefe jefe jefe patron capo vad\u012bt\u0101js vadovas f\u0151n\u00f6k patron Patron \u0428\u0435\u0444 baas sjef szef chefe \u0219ef \u0161\u00e9f \u0161ef pomo chef patron \u0645\u062f\u064a\u0631 \u03b1\u03c6\u03b5\u03bd\u03c4\u03b9\u03ba\u03cc \u0448\u0435\u0444 \u0431\u043e\u0441\u0441 \u8001\u677f".split(" ");
if(nf!=`mod=dungeon&loc=${b}`)zh(`mod=dungeon&loc=${b}`);else{b=!document.getElementById("content").getElementsByTagName("area")[0];const m=document.getElementById("content").getElementsByClassName("button1");if(2<=m.length){c=m[0].getAttribute("name");e=m[1].getAttribute("name");try{if(b){const n=(new URLSearchParams(window.location.search)).get("loc");"normal"===Fb&&"dif1"===c?(jQuery.post(G({mod:"dungeon",loc:n,sh:U("sh")}),{dif1:Fb}),m[0].click(),window.location.reload()):"dif2"===e?(jQuery.post(G({mod:"dungeon",
loc:n,sh:U("sh")}),{dif2:Fb}),m[1].click(),window.location.reload()):(Ya("Incorrect dungeon/expedition settings"),setTimeout(()=>{Ef()},1E4))}}catch(n){location.reload()}}else if(b)window.location.reload();else try{const n=document.querySelector("#content .map_label"),r=n&&n.textContent.toLowerCase(),w=Array.from(document.querySelectorAll("#content .map_label")).find(u=>g.some(t=>t===u.textContent));Q("dungeonAttacks",0);if(e&&h)localStorage.setItem("loose","false"),document.querySelectorAll("#content .button1")[0].click();
else if(c&&r&&w)document.querySelectorAll("#content .button1")[0].click();else if(r&&w&&"true"===localStorage.getItem("dungeonAB"))w.click();else if(k){var l=0,q=null;document.querySelectorAll('[onclick*="startFight"]').forEach(function(u){var t=u.getAttribute("onclick").match(/startFight\('(\d+)',/);t&&t[1]&&(t=parseInt(t[1],10),t>l&&(l=t,q=u))});q?q.click():window.location.reload()}else document.querySelector("#content area").click()}catch{window.location.reload()}}}}();else if(qa&&(!0===Ha||ob.isUnderworld&&
ff)&&(!ob.isUnderworld||ob.isUnderworld&&ff)&&ba==wa&&wa===Kc&&ea>=new Date&&(ob.isUnderworld||"true"!==localStorage.getItem("HealEnabled")||aa.o>Number(localStorage.getItem("healPercentage"))||ob.isUnderworld&&aa.o>Number(localStorage.getItem("HellHealHP")))&&!0===document.getElementById("cooldown_bar_fill_arena").classList.contains("cooldown_bar_fill_ready")){async function b(){var k=new URL(window.location.href),g=k.origin;k=k.searchParams.get("sh")||"";var l=localStorage.getItem("scoreRange"),
q=[];g=await (await fetch(`${g}/game/index.php?mod=highscore&sh=${k}&a=${l}`)).text();g=(new DOMParser).parseFromString(g,"text/html");g=Array.from(g.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(m=>(m=m.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===m.style.color||"blue"===m.style.color):null===m);q=[...q,...g];if(0===q.length)return console.log("No players available to attack"),!1;g=JSON.parse(localStorage.getItem("avoidAttackList"))||
[];l=function(m){for(var n=m.length,r,w;0!==n;)w=Math.floor(Math.random()*n),--n,r=m[n],m[n]=m[w],m[w]=r;return m}(q);q=0;for(let m of l)if(l=m.textContent.toLowerCase(),!g.map(n=>n.toLowerCase()).includes(l)){l=await c(m.textContent,k);if(l.includes("index.php?mod=reports")){k=(new URLSearchParams(l)).get("reportId");C(`${d.ya}`+m.textContent);zh(`mod=reports&submod=showCombatReport&t=2&reportId=${k}`);await new Promise(n=>setTimeout(n,500));return}q++;if(3<=q)break}return!1}async function c(k,g){try{const l=
(new URL(window.location.href)).origin;return await (await fetch(`${l}/game/ajax/doArenaFight.php?dname=${k}&a=${(new Date).getTime()}&sh=${g}`,{method:"POST"})).text()}catch{Ef(1E3)}}async function e(k){var g=k.opponentId;const l=k.serverId;k=k.country;var q=(new URL(window.location.href)).origin;q=new URL(`${q}/game/ajax.php`);g={mod:"arena",submod:"doCombat",aType:2,opponentId:g,serverId:l,country:k.toString(),a:(new Date).getTime(),sh:U("sh")};q.search=(new URLSearchParams(g)).toString();return await (await fetch(q,
{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function h(){function k(u){const t=null!==u.querySelector("span[style*='color:green;']");return Array.from(u.querySelectorAll("a, span")).find(A=>"green"===A.style.color||"bold"===A.style.fontWeight)||t}var g=new URL(window.location.href);const l=g.origin;var q=await (await fetch(`${l}/game/index.php?mod=arena&sh=${U("sh")}`)).text();q=(new DOMParser).parseFromString(q,"text/html");
var m=Array.from(q.querySelectorAll('table[width="80%"] tbody tr')).filter(u=>u.querySelector(".attack"));if(m.length&&1!==m.length){var n=null;q=JSON.parse(localStorage.getItem("avoidAttackList"))||[];if("true"===localStorage.getItem("leaguerandom")){m=m.sort(()=>Math.random()-.5);for(var r of m){var w=r.querySelector("a");w=w?w.innerText:null;if(!k(r)&&!q.includes(w)){n=r;break}}}else if("true"===localStorage.getItem("leaguelowtohigh")){m=m.sort((u,t)=>parseInt(u.querySelector("th")?u.querySelector("th").textContent:
"0",10)-parseInt(t.querySelector("th")?t.querySelector("th").textContent:"0",10));r=null;n=-1;for(w of m)m=(m=w.querySelector("a"))?m.innerText:null,k(w)||q.includes(m)||(m=parseInt(w?.querySelector("th")?.textContent,10),m>n&&(n=m,r=w));n=r}if(null===n)localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","false"),localStorage.setItem("leagueattackenable","false"),Ef(500);else if(n)if(q=n.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],w=(new Date).getTime(),
g=g.searchParams.get("sh")||"",await new Promise(u=>setTimeout(u,250)),g=await (await fetch(`${l}/game/ajax/doArenaFight.php?did=${q}&a=${w}&sh=${g}`)).text(),(q=g.match(/document\.location\.href\s*=\s*'([^']+)'/))&&q[1])window.location=`${l}/game/${q[1]}`;else{g.includes("5")&&("true"===localStorage.getItem("leaguelowtohigh")?(localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","true")):"true"===localStorage.getItem("leaguerandom")&&(localStorage.setItem("leaguerandom",
"false"),localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leagueattackenable","false")),location.reload());if(g.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leagueattackenable","false"),location.reload()}ob.isUnderworld&&ff&&await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:U("sh")}));await async function(){function k(z){const y=Date.now(),x=u.findIndex(v=>v.playerName===z);-1<x?u[x].timeout=y:u.push({playerName:z,timeout:y});localStorage.setItem("playerTimeouts",
JSON.stringify(u))}function g(z,y){const x=Date.now();if(Array.isArray(u)){const v=u.find(D=>D.playerName===z);return!v||x-v.timeout>y}return!u[z]||x-u[z]>y}function l(z){for(var y=z.length-1;0<y;y--){const x=Math.floor(Math.random()*(y+1));[z[y],z[x]]=[z[x],z[y]]}2<z.length&&(y=z.splice(0,2),z.push(...y));return z}async function q(z,y,x){try{const v=y.match(/\d+/)[0],D=y.match(/\w+/g)[2],E=(new URLSearchParams(y)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:x,aType:z,
opponentId:E,serverId:v,country:D}));const I=await jQuery.get(S({mod:"arena",submod:"confirmDoCombat",aType:z,opponentId:E,serverId:v,country:D,a:(new Date).getTime(),sh:U("sh")})),J=(new URLSearchParams(I)).get("reportId");J||window.location.reload();zh(`mod=reports&submod=showCombatReport&t=${z}&reportId=${J}`)}catch(v){document.getElementById("content").querySelector("form > input").click(),Ef(1E3)}}"true"===localStorage.getItem("leagueattackenable")&&await h();"true"===localStorage.getItem("scoreboardattackenable")&&
await b();var m=(new URL(window.location.href)).searchParams.get("sh")||"",n=JSON.parse(localStorage.getItem("autoAttackList"))||[];let r=JSON.parse(localStorage.getItem("autoAttackServerList"))||[];const w=JSON.parse(localStorage.getItem("avoidAttackList"))||[];let u=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const t="true"===localStorage.getItem("onlyArena");if(W("arena")&&0<n.length||W("arena")&&0<r.length||t)try{l(n);localStorage.setItem("autoAttackList",JSON.stringify(n));l(r);localStorage.setItem("autoAttackServerList",
JSON.stringify(r));let z=0,y=2,x=0,v=0;for(t&&(y=10);z<y&&(x<n.length||v<r.length);){let D,E,I;(I=x<n.length&&v<r.length?.5>Math.random():v<r.length)?(E=r[v],D=E.playerName,v++):(D=n[x],x++);if(!w.includes(D)&&(g(D,6E4*(10+Math.floor(36*Math.random())))||t)){let J;J=I?await e(E):await c(D,m);Q("arenaAttacks",0);if(J.includes("index.php?mod=reports")&&!J.includes("errorRow")){k(D);C(`${d.ya}`+D);window.location.reload();break}}z++}if(z===y){const D=JSON.parse(localStorage.getItem("Timers"));Y("arena",
D.Arena||5)}}catch(z){window.location.reload()}if("mod=arena&submod=serverArena&aType=2"!=nf)zh("mod=arena&submod=serverArena&aType=2");else try{let z=[...n,...r].map(v=>v.playerName);var A=Array.from(document.querySelectorAll("#own2 tr")).slice(1);const y="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),x="true"===localStorage.getItem("attackRandomly");m=null;n=Infinity;localStorage.getItem("Username");localStorage.getItem("enableArenaSimulator");localStorage.getItem("ArenaSimulatorAmount");
for(let v of A){const D=v.querySelector("a");A=2;x&&(A=Math.floor(5*Math.random())+2);const E=v.querySelector(`td:nth-child(${A})`);if(D&&E){const I=D.innerText,J=parseInt(E.textContent.trim(),10),K=w.includes(I),P=null!==D.querySelector("span[style*='color:green;']"),T="green"===D.style.color;if(!(K||!y&&P&&T)){if(z.includes(I)){C(`${d.ya}`+I);m=D;break}!m&&J<n&&(n=J,m=D)}}}if(m)await q(2,m.href,m.outerText),Q("arenaAttacks",0);else{const v=document.querySelector('form[name="filterForm"] input[type="submit"]');
v&&v.click()}}catch{window.location.reload()}}()}else if(qa&&!0===Da&&9<aa.level&&ba==wa&&!0===document.getElementById("cooldown_bar_fill_ct").classList.contains("cooldown_bar_fill_ready")){async function b(){var g=new URL(window.location.href),l=g.origin;g=g.searchParams.get("sh")||"";var q=localStorage.getItem("scoreRangeCircus"),m=[];l=await (await fetch(`${l}/game/index.php?mod=highscore&sh=${g}&a=${q}`)).text();l=(new DOMParser).parseFromString(l,"text/html");l=Array.from(l.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(n=>
(n=n.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===n.style.color||"blue"===n.style.color):null===n);m=[...m,...l];if(0===m.length)return console.log("No players available to attack"),!1;l=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];q=function(n){for(var r=n.length,w,u;0!==r;)u=Math.floor(Math.random()*r),--r,w=n[r],n[r]=n[u],n[u]=w;return n}(m);m=0;for(let n of q)if(q=n.textContent.toLowerCase(),!l.map(r=>r.toLowerCase()).includes(q)){q=await c(n.textContent,
g);if(q.includes("index.php?mod=reports")){g=(new URLSearchParams(q)).get("reportId");C(`${d.za}`+n.textContent);zh(`mod=reports&submod=showCombatReport&t=3&reportId=${g}`);await new Promise(r=>setTimeout(r,500));return}m++;if(3<=m)break}return!1}async function c(g,l){try{const q=(new URL(window.location.href)).origin;return await (await fetch(`${q}/game/ajax/doGroupFight.php?dname=${g}&a=${Date.now()}&sh=${l}`,{method:"POST"})).text()}catch{Ef(1E3)}}async function e(g){var l=g.opponentId;const q=
g.serverId;g=g.country;var m=(new URL(window.location.href)).origin;m=new URL(`${m}/game/ajax.php`);l={mod:"arena",submod:"doCombat",aType:3,opponentId:l,serverId:q,country:g.toString(),a:(new Date).getTime(),sh:U("sh")};m.search=(new URLSearchParams(l)).toString();return await (await fetch(m,{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function h(){function g(t){const A=null!==t.querySelector("span[style*='color:green;']");
return Array.from(t.querySelectorAll("a, span")).find(z=>"green"===z.style.color||"bold"===z.style.fontWeight)||A}var l=new URL(window.location.href);const q=l.origin;var m=await (await fetch(`${q}/game/index.php?mod=arena&submod=grouparena&sh=&sh=${U("sh")}`)).text();m=(new DOMParser).parseFromString(m,"text/html");var n=Array.from(m.querySelectorAll('table[width="80%"] tbody tr')).filter(t=>t.querySelector(".attack"));if(n.length&&1!==n.length){var r=null;m=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||
[];if("true"===localStorage.getItem("leaguecircusrandom")){n=n.sort(()=>Math.random()-.5);for(var w of n){var u=w.querySelector("a");u=u?u.innerText:null;if(!g(w)&&!m.includes(u)){r=w;break}}}else if("true"===localStorage.getItem("leaguecircuslowtohigh")){n=n.sort((t,A)=>parseInt(t.querySelector("th")?t.querySelector("th").textContent:"0",10)-parseInt(A.querySelector("th")?A.querySelector("th").textContent:"0",10));w=null;r=-1;for(u of n)n=(n=u.querySelector("a"))?n.innerText:null,g(u)||m.includes(n)||
(n=parseInt(u?.querySelector("th")?.textContent,10),n>r&&(r=n,w=u));r=w}if(null===r)localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircusattackenable","false"),Ef(500);else if(r)if(m=r.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],u=(new Date).getTime(),l=l.searchParams.get("sh")||"",await new Promise(t=>setTimeout(t,250)),l=await (await fetch(`${q}/game/ajax/doGroupFight.php?did=${m}&a=${u}&sh=${l}`)).text(),
(m=l.match(/document\.location\.href\s*=\s*'([^']+)'/))&&m[1])window.location=`${q}/game/${m[1]}`;else{l.includes("5")&&("true"===localStorage.getItem("leaguecircuslowtohigh")?(localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","true")):"true"===localStorage.getItem("leaguecircusrandom")&&(localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusattackenable","false")),location.reload());
if(l.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leaguecircusattackenable","false"),location.reload()}async function k(){function g(y){const x=Date.now(),v=t.findIndex(D=>D.playerName===y);-1<v?t[v].timeout=x:t.push({playerName:y,timeout:x});localStorage.setItem("playerTimeouts",JSON.stringify(t))}function l(y,x){const v=Date.now();if(Array.isArray(t)){const D=t.find(E=>E.playerName===y);return!D||v-D.timeout>x}return!t[y]||v-t[y]>x}function q(y){for(var x=y.length-
1;0<x;x--){const v=Math.floor(Math.random()*(x+1));[y[x],y[v]]=[y[v],y[x]]}2<y.length&&(x=y.splice(0,2),y.push(...x));return y}async function m(y,x,v){try{const D=x.match(/\d+/)[0],E=x.match(/\w+/g)[2],I=(new URLSearchParams(x)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:v,aType:y,opponentId:I,serverId:D,country:E}));const J=await jQuery.get(S({mod:"arena",submod:"confirmDoCombat",aType:y,opponentId:I,serverId:D,country:E,a:(new Date).getTime(),sh:U("sh")})),K=
(new URLSearchParams(J)).get("reportId");K||window.location.reload();zh(`mod=reports&submod=showCombatReport&t=${y}&reportId=${K}`)}catch(D){document.getElementById("content").querySelector("form > input").click(),Ef(1E3)}}"true"===localStorage.getItem("leaguecircusattackenable")&&await h();"true"===localStorage.getItem("scoreboardcircusenable")&&await b();var n=(new URL(window.location.href)).searchParams.get("sh")||"",r=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[];let w=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||
[];const u=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];let t=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const A="true"===localStorage.getItem("onlyCircus");localStorage.getItem("CircusSimulatorAmount");if(W("circus")&&0<r.length||W("circus")&&0<w.length||A)try{q(r);localStorage.setItem("autoAttackCircusList",JSON.stringify(r));q(w);localStorage.setItem("autoAttackCircusServerList",JSON.stringify(w));let y=0,x=2,v=0,D=0;for(A&&(x=10);y<x&&(v<r.length||D<w.length);){let E,
I,J;(J=v<r.length&&D<w.length?.5>Math.random():D<w.length)?(I=w[D],E=I.playerName,D++):(E=r[v],v++);if(!u.includes(E)&&(l(E,6E4*(10+Math.floor(36*Math.random())))||A)){let K;K=J?await e(I):await c(E,n);Q("circusAttacks",0);if(K.includes("index.php?mod=reports")&&!K.includes("errorRow")){g(E);C(`${d.za}`+E);window.location.reload();break}}y++}if(y===x){const E=JSON.parse(localStorage.getItem("Timers"));Y("circus",E.CircusTurma||5)}}catch(y){window.location.reload()}if("mod=arena&submod=serverArena&aType=3"!=
nf)zh("mod=arena&submod=serverArena&aType=3");else try{if(document.querySelector(".messages .message.fail"))localStorage.setItem("doCircus",!1),window.location.reload();else{let y=[...r,...w].map(D=>D.playerName);var z=Array.from(document.querySelectorAll("#own3 tr")).slice(1);const x="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),v="true"===localStorage.getItem("attackRandomly");n=null;r=Infinity;localStorage.getItem("Username");localStorage.getItem("enableCircusSimulator");
for(let D of z){const E=D.querySelector("a");z=2;v&&(z=Math.floor(5*Math.random())+2);const I=D.querySelector(`td:nth-child(${z})`);if(E&&I){const J=E.innerText,K=parseInt(I.textContent.trim(),10),P=u.includes(J),T=null!==E.querySelector("span[style*='color:green;']"),X="green"===E.style.color;if(!(P||!x&&T&&X)){if(y.includes(J)){C(`${d.za}`+J);n=E;break}!n&&K<r&&(r=K,n=E)}}}if(n)await m(3,n.href,n.outerText),Q("circusAttacks",0);else{const D=document.querySelector('form[name="filterForm"] input[type="submit"]');
D&&D.click()}}}catch{window.location.reload()}}1==yc.isUnderworld?(await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:U("sh")})),await k()):rh?await k():!rh&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&await k()}else if(qa&&!0===Ea&&W("eventPoints")&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&0<jQuery("#submenu2 a").filter(".glow").length)await async function(){var b=jQuery("#submenu2 a").filter(".glow")?
jQuery("#submenu2 a").filter(".glow")[0].href.match(/mod=.*&sh/)[0].slice(0,-3):null;if(nf!=b)zh(b);else{b=document.querySelector("#content .ticker");let c=parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10),e=jc;localStorage.setItem("eventPoints_",c);if(b){b=document.querySelector('[data-ticker-type="countdown"]').textContent.trim().split(" ").pop();let [h,k,g]=b.split(":").map(Number);(b=(new Date).getTime()+1E3*(3600*h+60*k+g)+1)?localStorage.setItem("eventPoints.timeOut",
b):Y("eventPoints",5);setTimeout(zh,1E3,"mod=overview")}else!b&&0<c?(3==e&&1==c&&(e=2),setTimeout(Ah,1E3,document.querySelectorAll(".expedition_button")[e])):!c&&"true"===localStorage.getItem("renewEvent")&&0<Bh().hn?((new URL(window.location.href)).searchParams.get("loc"),setTimeout(Ah,1E3,document.querySelectorAll(".expedition_button")[e])):0==c&&"false"===localStorage.getItem("renewEvent")?(Y("eventPoints",5),location.reload()):0==c&&setTimeout(zh,5E3,"mod=overview")}}();else if((Bc||Cc||Dc)&&
!ph&&Bc&&qa&&qh&&(th&&Ec&&Bb&&Cb&&W("AuctionEmpty")||Cc&&Bb&&Cb&&W("AuctionEmpty")||Dc&&Bb&&Cb&&W("AuctionMEmpty")||uh&&Ec&&vh&&wh&&W("AuctionMEmpty")))await za.start();else if(qa&&5<aa.level&&"true"==localStorage.getItem("storeGoldinAuction")&&Number(Bh().gold)>Math.floor(Number(localStorage.getItem("storeGoldinAuctionmaxGold")))&&W("enableHideGold"))await nb.D.start();else if(qa&&"true"===localStorage.getItem("resetExpiredItems")&&0<yh.length&&5E3<=aa.gold&&W("resetExpired"))await hj(localStorage.getItem("resetDays"),
yh);else if(qa&&("true"===localStorage.getItem("HealEnabled")?aa.o>Number(localStorage.getItem("healPercentage")):1)&&Ch()&&"true"===localStorage.getItem("doKasa")&&W("gold")&&Bh().gold>Math.floor(localStorage.getItem("KasaHoldGold")))await Oh();else if(qa&&"true"===localStorage.getItem("EnableSmelt")&&ha.Lm()&&1E3<aa.gold&&W("smelt"))W("smeltCheck")&&(ha.slots=await ha.u(),await ha.jm(ha.slots),await ha.Bm(ha.slots),"true"===localStorage.getItem("EnableSmelt")&&1E3<aa.gold&ha.Lm()&&W("smelt")&&await ha.start());
else if(qa){if("true"==localStorage.getItem("useCostume")&&W("CheckDolls"))await rj.start();else if("true"===localStorage.getItem("HealEnabled")&&"true"==localStorage.getItem("BuffsEnable")&&W("BuffCheck"))await kj();else if(!xh||Sb-xh>=6E4*zj)localStorage.setItem("MarketlastRan",Sb.toString()),"true"==localStorage.getItem("enableMarketSearch")&&ba==wa&&"true"==sessionStorage.getItem("autoGoActive")&&await ef.En();11001<Ub&&(C(`Waiting for ${Tb} seconds...`),await new Promise(b=>setTimeout(b,Ub)));
$e()}const z3=localStorage.getItem("we");we=new Date(z3);ea<new Date&&we<new Date&&ba!=wa&&gb()}}})();const Eh={Ni:"Nest Search Type",Li:"Nothing",Mi:"Quick",Oi:"Thorough",nj:"After expedition points are consumed, travel to Germania to consume Dungeon points",mk:"Use this if the bot gets stuck in the repair!",Ak:"When HP is below, use heal",yf:"Partial Repair",Ld:"Full Repair",xf:"Partial or Full Repair",bd:"Enable Limit",li:"Limit",mi:"If you want to limit the number of times you want to attack to the enemy, enable this option and set the limit. Bot will continue to attack rest of the enemies after it finishes attacking to the selected monster.",
Xc:"Do not enter underworld with underworld costume?",Wc:"If you dont want to enter underworld while you have underworld costume on, enable this option",fh:"Underworld",Xg:"Underworld Buffs",Zg:"Use god powers after entering the underworld?",$g:"Select gods to use powers from:",ah:"Use Weapon Buff on the weapon?",bh:"Use Armor Buff on the following equipment:",xk:"Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.",Lk:"Select Colors",Za:"Vulcanus Forge",cb:"Feronia`s Earthen Shield",
eb:"Neptune`s Fluid Might",fb:"Aelous` Aerial Freedom",gb:"Pluto`s Deadly Mist",hb:"Juno`s Breath of Life",ib:"Wrath Mountain`s Scale Armour",jb:"Eagle Eyes",kb:"Saturn`s Winter Garment",$a:"Bubona` Bull Armour",ab:"Mercerius` Robber`s Garments",bb:"Ra` Light Robe",Ve:"Packages",Qe:"Inventory",K:"Min Price",J:"How Many",Eb:"Sell Items",Db:"Search in",Re:"Material Color",Cb:"Item Color",Ye:"Warehouse",Fa:"Switch to Materials",Gb:"Switch to Items",Xe:"Sell Materials",Ca:"Please enter a valid item name and price range and how many.",
Da:"No suitable items found in the selected search locations.",Ea:"All items listed successfully!",Fk:"All materials listed successfully!",Te:"If you want to sell items for fixed price, you can enter the same value for both min and max price.",Ue:"This feature is still experimental, use with caution. If you dont put fixed price, it will list items randomly between min and max price you enter.",rj:"Repair Before Smelt",Kj:"Select the item types you want to smelt.",Lj:"Select the colors you want to smelt.",
Mj:"Select the level of the items you want to smelt.",Nj:"Select the hammer you want to use",Oj:"Note that Green and Red circle next to the first box are for enabling/disabling the rule.",Pj:"If you want to use smelt randomly any colors or types, you can enable `Smelt randomly if no conditions met? (Last enabled option in the tutorial video)",tk:"Sets the max gold that the bot will spend per cycle.",Ua:"Bot will start bidding on any food items, if enabled. You do not require to enable gladiator/mercenary toggles",
vc:"Bot will not bid on allies` bids.",wc:"Ignore Prefix/Suffix Combination when looking for an item in the auction.",yd:"Select Monster",md:"Use Hourglass/Ruby?",zk:"Use Ruby?",pd:"Use Mobilization?",od:"Use Life Potion?",ld:"Heal Percentage (%)",wd:"Number of Attacks",nd:"Attack Interval (in seconds)",jd:"Attacks Performed",kd:"Hourglass Left",ud:"Note: It uses lifepotions to heal, not food.",vd:"Note: If attacks stop prematurely, try 'Reset Attacks'.",zd:"Start",xd:"Reset",Ad:"Stop",Bd:"Expedition Settings (Click to minimize)",
qd:"Monster 1",rd:"Monster 2",sd:"Monster 3",td:"Monster 4",Ik:"Repair Before Smelt",yh:"This option will use cervisia when your premium expires.",Ri:"This option will enables and picks oils from god rewards. It can use number 1 and number 3 oils on the character but number 2 will only be picked to packages.",wh:"This option will use buffs at the time you set. It will find buffs in packages and apply it to the character.",ni:"This option will enter you to the underworld when your expedition points are below 3. Dont forget to enable Auto Login from Extras tab, otherwise you might get logged out upon entering underworld[Game Bug]",
$b:"Bot normally picks random 3 to 6 tries to attack arena list. If you enable this option, it will go through your list until it can attack someone. This might take some time.",oj:"This option is only for premium licenses. It simulates the attack before attacking a user for %75 win rate.",yc:"You do not need to enable main auction toggle to enable this option.",fk:"This option will refresh the page every second when auction is in -Very Short- state to bid constantly to win the auction.",Ij:"If none of the smelt conditions are met, it will smelt randomly. Make sure to select item type and color.",
Jj:"This option will only smelt items from inventory. It will ignore items in packages.",Va:"Auction Items",af:"Mercenary Items",Ub:"Shop Items",hh:"Unique Items",Ej:"Set background to black [Increases performance]",Fj:"Move GLDbot buttons to bottom left?",zh:"Attack Circus Without Heal",dk:"Pick gold from packages if needed?",ek:"Gold has been picked from packages for training",Jl:"No gold has been found in packages for training",nl:'GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.',
ak:"Items Repaired",Uj:"Arena Attacks",Wj:"Circus Attacks",pc:"Items Reset",Zj:"Expedition Attacks",Yj:"Dungeon Attacks",bk:"Underworld Attacks",Vj:"Money Earned from Arena",Xj:"Money Earned from Circus",Hl:"Items Smelted",$j:"Gold Cycled",ei:"Guild Battle",gi:"Guild Settings",bl:"Will attack guilds randomly.",di:"Attack Random Guilds?",fi:"Guild Name",xh:"Reset Stats",kc:"Wood",hc:"Copper",ic:"Iron",jc:"Leather",xi:"Wool",pi:"Cotton Wool",si:"Hemp",ri:"Gauze Strip",ui:"Linen Strip",ti:"Jute Patch",
wi:"Velvet",vi:"Silk Thread",Ei:"Fur",yi:"Bone Splinter",Hi:"Scale",Bi:"Claw",Di:"Fang",Ci:"Dragon Scale",zi:"Bull`s Horn",Gi:"Poison Gland",Ai:"Cerberus` Pelt",Fi:"Hydra Scale",Ii:"Sphinx Feather",Ji:"Typhon Leather",ai:"Lapis Lazuli",Vh:"Amethyst",Uh:"Amber",Wh:"Aquamarine",bi:"Sapphire",Zh:"Garnet",Yh:"Emerald",Xh:"Diamond",$h:"Jasper",ci:"Sugilite",Ph:"Scorpion Poison",Sh:"Tincture of Stamina",Lh:"Antidote",Kh:"Adrenaline",Rh:"Tincture of Enlightenment",Oh:"Potion of Perception",Mh:"Essence of Reaction",
Nh:"Phial of Charisma",Th:"Waters of Oblivion",Qh:"Soul Essence",Aj:"Water Seal",uj:"Protection Rune",sj:"Earth Mark",zj:"Totem of Healing",yj:"Talisman of Power",wj:"Stone of Fortune",tj:"Flintstone",xj:"Storm Rune",vj:"Shadow Rune",Ui:"Crystal",Ti:"Bronze",Yi:"Obsidian",aj:"Silver",bj:"Sulphur",Wi:"Gold Ore",$i:"Quartz",Zi:"Platinum",Si:"Almandin",Vi:"Cuprit",Xi:"Hellstone",th:"Attack Randomly in Provinciarum?",uh:'Also disable "Sort players in arena by level" setting in crazy-addon.',Kf:"Only accept quests based on god type.",
Wa:"Auto Buff",Mc:"Use it in hell only?",rf:"New Rule",pf:"Name Contains",isUnderworldItem:"Is Underworld Item",Ud:"Ignore Materials",lk:"Use Pray?",eh:"When in underworld only accept underworld related quests?",dh:"If enabled, you need to enter underworld item names. If the bot finds these items in the underworld, it will accept the quest.",Pk:"Underworld Quest Item",Zk:"Enter Material Name",wk:"The bot loves dice! They help find clothes in chests. But if there are no dice, the bot opens chests anyway, hoping for some cool clothes (but it might not find any!).",
Hj:"Send smelted materials to package?",ad:"Enable Arena",Cf:"Prioritize arena list?",Df:"Prioritize circus list?",Tc:"Disable Log Menu",Yf:"Reward Min. Gold Value",Lf:"Focus Quest, if enabled, will follow the shortest path to finish the dungeon.",ug:"Throw Dice Automatically?",vg:"Use throw dice cautiously, it will keep using the first dice until you disable the option.",cg:"Search Progress",Sf:"Cooldown for repair by default is 10 minutes.",lf:"Minimum Condition",Rc:"Current item on workbench [Clear if bot pauses unexpectedly]",
oe:"Forge Resources stored to horreum successfully.",ke:"Checking marketplace for items...",Ab:"Item moved to workbench.",Ce:"Item successfully repaired and equipped.",De:"Item successfully repaired.",Dk:"Repair failed. Page will be refreshed.",ze:"Picking up materials...",Me:"Waiting for repair...",Be:"Repair has started for .",Ba:"Repair: Moving the item from inventory to bag",Ae:"Repair: Moving the item from workbench to package.",sb:"Could not find enough materials. Disabling the repair slot for 5 minutes ",
we:"Looking for items to buy to hide gold in Auction...",he:"Checking for expired items in packages...",ie:"Item successfully reset.",je:"No Empty Space or Gold to Reset.",pe:"Make sure you have sell rights in guild market!",ub:"Not enough gold/or no item to buy. Waiting for 30sec to refresh.",wb:"Store has been refreshed.",xb:"Error while healing.",se:"No Ruby or Cloth, disabling the options.",te:"No healing item found in packages.",yb:"No suitable items found",ue:"Foods have been picked. Ending the process.",
ve:"At least one food has been picked. Ending process.",zb:"No suitable space found in bag to pick food.",qe:"Getting food from packages.",re:"No suitable space found in bag to pick food.",vb:"No more heal items. Waiting for 30 seconds.",tb:"HP Recovered.",Aa:"Nothing to do so I am going to pray!",Ie:"Im going to refresh in 60 seconds to check for my health and villa medici.",Je:"Waiting for Villa Medici, refreshing in 60 seconds.",Ke:"Left underworld.",Le:"Im going to refresh in 60 seconds to check for my health.",
xe:"Checking for god oils...",ye:"God oils have been picked.",ya:"Successfully attacked player in ARENA: ",za:"Successfully attacked player in CIRCUS: ",fe:"Checking auction! Please wait...",ge:"Bidding to items. Please wait...",Ee:"Auto Smelted Item: ",Fe:"Smelting Item: ",Ge:"Not enough gold to smelt. Required Gold: ",He:"SMELT: Looking for items to smelt...",Ek:"Looking for items to smelt...",le:"Checking costume availability...",ne:"Donated : ",me:"Throwing dice...",Hd:"Underworld Farm [Manual, Beta]",
Id:"Be aware: Turn on this feature after unlocking the creature you want to attack, it will not automatically attack to unlock the monster.",Gd:"Farm Location",Fd:"Farm Enemy",Fc:"Auto Login",Gc:"You need to allow pop-ups from the lobby screen for GameForge. See documentation on how to do it.",zf:"Pause Bot",Af:"Pause Bot in (Minutes)",Dd:"Expiration Date",uf:"Only buy food?",vf:"If you enable this, it will ignore your selections and buy food automatically without entering anything.",Ib:"Max total gold to spend",
Hb:"Max gold per food to spend",tf:"Bot will check oils every 60 minutes",Ng:"Sets a timer to check smelting times.",Kg:"Sets a timer to check smelting after you dont have gold.",Mg:"Sets a timer to check smelting if you dont have available item.",Fg:"Sets a timer for repair to check your items.",Eg:"Sets a timer to check guild market hold gold.",Ag:"Sets a timer for auction hold gold option.",wg:"Sets a timer to check the arena pvp list to attack.",Bg:"Sets a timer to check the circus pvp list to attack.",
Tg:"Sets a timer for training to train your stats.",Hg:"Sets a timer to reset expired items.",Rg:"Sets a timer to store forge materials to horreum.",yg:"Sets a timer to check gladiatos & mercenary auction.",Jg:"Sets a timer to search for items in auction&shop.",Cg:"Sets the timer of sending donation to the guild.",Md:"Gold Moved",Yc:"Don't sell smelt & auction list items",dg:"Shop Automation",fg:"Item Search Settings",eg:"Use this tool to search for items in shops. Simply add the items to the list, specify the cloth amount, and start the search.",
gg:"Cloths to use:",hg:"How many cloths to use?",ja:"Enter Full Item Name",Tb:"Enter Item Level",jg:"Item Quality",ig:"Item Name Here",kg:"Start Searching",lg:"Skip and Continue",mg:"Stop Searching",Jd:"Buy cheapest or expensive?",nf:"Most Expensive",Oc:"Cheapest",ga:"Select an option",cd:"Highlight Underworld Items",Kd:"Focus on the quest?",Ll:"Use ruby if there isnt cloth?",Xa:"Add cross-server players: Find profile, use A & C buttons. Play nice: Avoid targeting same players to dodge reports/bans.",
Al:"Smelt Green?",Ff:"Do not accept random quests if entered any filters?",lc:"Max Material Quality to use",Hh:"Enable Mercenary Search",jl:"Click \u2018Sell All Selected\u2019 to sell all items. Make sure to have 2x3 empty space in your first (1) bag and select quality. To mass collect Gold, use `USE GOLD` panel below or filter gold and use the `Pick Selected or Pick All`",Tj:"\ud83d\udd25 : Adds item to smelting list.",vh:"\ud83d\udd28 : Adds item to auction list.",qj:"Refresh shop automatically with cloth when its full.",
ej:"Page:",lj:"Stop",jj:"Sell This Page",gj:"Pick Selected",fj:"Pick All",mj:"Auto Package Settings",kj:"Send Resources",hj:"Sell All Selected",ra:"Item Type",W:"Weapons",S:"Shields",M:"Armour",P:"Helmets",O:"Gloves",N:"Boots",V:"Rings",U:"Amulets",pa:"Usables (Foods)",wa:"Upgrades",cj:"Boosts",ta:"Recipes",sa:"Mercenary",va:"Forging Tools",ua:"Scrolls",Oa:"Reinforcements",Ma:"Event Items",Na:"Forging Goods",dj:"Gold",T:"All",ql:"Quality",X:"White",B:"Green",A:"Blue",C:"Purple",G:"Orange",R:"Red",
ij:"Sell All Options",Gj:"Ignore Prefix/Suffix Combination?",hi:"How many food to buy/pick?",Ch:"Normal",Bh:"Middle",Ah:"Hard",Ja:"Standard",tl:"Repair Stuck Fix",Bk:"Underworld mode will automatically disable Dungeon/Arena/Circus, and enable all of them after underworld. Disable Enter Underworld if you want to disable Dungeon/Circus/Arena. If you entered underworld manually, you need to enable underworld Mode.",Wg:"Set how many times you want to train the stats and their priorities. The bot wont train unless you set a priority. If there is no more stat left but priority is set, it will continue with checked stat.",
Wk:"Quest",yl:"Smelt",El:"Smelt Settings",Qj:"Smelted Items",Fl:"Add Prefix or Suffix, once it finds it in the packages it will smelt automatically. If you only want to look for all the items listed without checking their combination, enable Ignore combination option.",Dl:"Smelting Item:",cc:"Click on the item you want to repair and choose the highest quality materials to use. You need to have at least 10,000 gold for the repair to start. Ensure you have a 3x3 space available in your first inventory bag and make sure a food item or any small item is not in the first inventory space otherwise, it might get stuck!. The bot will start the repair once the item has the condition you have chosen. Repair now should be able to continue from where it was left off. Items that have a Hint tooltip might cause a problem.",
Qk:"Apply only to Mercenary",Tk:"Auction will only bid when market is close to the end.",Sk:"Smelting will prioritize starting from the first item to search. You can drag and drop to change priority. Smelt will start when you have over 7k gold. ",ki:"Heal & Buffs",ul:"Not enough gold to smelt. Required Gold:",xl:"Skipping bid: Guild member has already bid for item ",wl:"Skipping bid: Already bid for item ",advanced:"Advanced",arena:"Arena",na:"Auto Attack",ac:"Avoid Attack",la:"Add Player",ma:"Add Player Name (Same Server)",
dl:"Stop Bot if run out of food?",circusTurma:"Circus Turma",Dh:"Difficulty",dungeon:"Dungeon",Eh:"Dungeon Settings",eventExpedition:"Event Expedition",expedition:"Expedition",Ih:"Expedition Settings",Bj:"Select Monster",gl:"Highest",el:"Put your heal stuff in first page of your inventory",fc:"In",sg:"Store Gold in Guild Market",tg:"Store Gold in Auction",ag:"Use Clothes to renew Shop?",Kk:"Select Items to Reset",Uf:"Reset Expired Items",Ob:"Note: By enabling this option, the bot will sell upcoming expired items from Packages to Guild Market then cancels to reset expiration time. Guild is required. Make sure you have empty 3x3 space in your bags. It checks last 7 pages per cycle. This might slow down the bot while it is checking for the pages to reset. If it doesnt work, set display expiry date as Date in game settings.",
Bf:"Pause bot randomly to work as [Testing Phase]:",da:"Hold Gold: Bot will keep this gold in the bag:",Ze:"Max Gold: Bot will spend when the gold is greater than",Zf:"Bot will bid on random items.",qc:"Add Random Delay",rc:"You can add a delay to bot here.",Nb:"Repair",zl:"Smelt Blue?",Cl:"Smelt Purple?",Bl:"Smelt Orange?",Rj:"Smelt Everything Only From Inventory?",Sj:"`Smelt Tab` works only for `Smelt Everything Only From Inventory` option. Rest of the options will use selected smelt tab. This will ignore color and ignore list items. Tab 1 is reserved for repair.",
og:"Smelt",zc:"Auto Search",qf:"Auto Auction",Ac:"Excess use of Auction might result in ban. If you enabled auction on Crazy-Addon please disable before using this. Note that, if you put only one item to PREFIX section, bot will try to filter by the items name for faster bidding. Although you need to disable bidding food for this.",$f:"Search in Gladiators Auction",bg:"Search in Mercenary Auction",Ic:"Bid Food?",$e:"Maximum Bid",Jc:"Bid if the status is less than",Kc:"Bidded Items",rk:"Auction Language",
sk:"Please set the language according to your ingame language, otherwise auction wont work.",uc:"You can add items to look for items in market and auction. It will also show purple items in the market once you add an item into the list.",pk:"Use auction with caution!",qk:"Auto bid makes too many requests to the server causing white page error and can cause a ban if you use it often!!",Rf:"Renew Event Points with Ruby?",ed:"Enable Auto Oil",uk:"Auto Get Holy Oils",Gk:"Quest Check Speed",Ta:"Attack Guild Members?",
Ra:'Auto add people to the "Attack" list when X GOLD is stolen:',Sa:'Automatically add people to the "Avoid Attack" list when you lose to them:',Rb:"Scoreboard Attacks",Yb:"Very Long",Bb:"Long",Jb:"Middle",Vb:"Short",Zb:"Very Short",fd:"Enter Underworld if HP >",Mf:"Quest Check Speed",Ef:'Default is "3x". If bot causes problems with quests, change quest speed according to your server speed.',Nd:"Heal Pick Bag",gd:'If you are renewing points manually, you need to click the button above "Refresh Event Expedition if stuck!',
yk:"You must enable at least one of the following: expedition, dungeon, arena, or circus to start the Event Expedition.",Of:"Refresh Event Expedition if stuck!",lb:"Dont bid on Allies` Bids?",Mk:"Leave all settings disabled if you wish to smelt using packages that contain the items in the list. However, you still need to choose colors.",vk:"Character(Off) / Mercenary(On)",Jk:"Repair Both?",Nk:"Timers",Timers:"Enter the number of minutes for each timer below or leave it default. Be aware! If you enter very low numbers, bot might get stuck in loop!",
Jf:"Quest Filter Ignore",If:"Enter keywords to filter out quests you do not want to take",aa:"Enter Keyword",I:"Add",Qf:"Remove",Qc:"Clear",Gf:"Quest Filter Accept",Hf:"Enter keywords to choose which quests to take. You can also use this to accept quests by their reward using keyword. Using this will ignore Quest Types",Ha:"Skip Time Quests?",Hk:"Quests",Cc:"Auto Costume",kh:"Use Costume?",Hc:"Basic Battle",Zc:"Dungeon Battle & Event",Pc:"Choose underworld costume",qh:"Wear Underworld costume when available?",
Dc:'To ensure the bot doesnt override your Underworld costume, make sure to select "Wear Underworld costume when available?" and "Choose Underworld costume." The bot will only switch to Dis Pater Normal and Medium costumes if your expedition or dungeon points are at 0.',Pd:"Underworld Heal Settings",tc:"Attack Boss When Available?",rb:"League attack will disable itself after 5 unsuccessful attack.",Sd:"Holy Oils",kf:"Item Name",ea:"Min. Item Level",Ga:"Min. Item Quality",sc:"Apply/Reset Timer",Vd:"Ignore Prefix/Suffix Combination",
rh:"Yes",sf:"No",Pa:"Add Prefix",Qa:"Add Suffix",Ya:"Clear History",pg:"Ignore List",Kb:"Prefix",Wb:"Suffix",Wf:"Reset Expiring Items",qg:"Smelt randomly if no conditions met?",rg:"Smelt Tab",pb:"Extras",xc:"Auction",Se:"Market",Xb:"Timers",Pg:"Smelting",Og:"Smelting if not enough gold",Lg:"Smelt if no item",Ia:"Repair",Dg:"Guild Market Hold Gold",zg:"Auction Hold Gold",Sg:"Training",Gg:"Reset Expired",Qg:"Store Forge",xg:"Auction Check",Ig:"Search",v:"Enable",mf:"Minimum Gold",Sb:"Select Hour",mb:"Donate Gold to Guild",
Uc:"Donates every 5 minutes. You can change the interval from timers tab",Td:"How much to donate?",Vc:"Donate when you have more than >",ee:"Less than <",Tf:"Reset Expired and Other settings",Vf:"Reset in:",Ck:"Hold Ctrl (Cmd on Mac) to select multiple items",Wd:"Import/Export Settings",Ed:"Export Settings",Xd:"Import Settings",cf:"Message All Players",df:"[Requires Ultra Premium Key, message on Discord to get the key.]",ef:"Enter message to send",Sc:"For custom scripts contact us on Discord",gf:"Send",
hf:"Show Players",ff:"SelectAll",jf:"UnselectAll",de:"Make sure your inventory has enough space. Cooldown is 2 minutes.",ob:"Enable Scoreboard Attack:",Pb:"Select Range to Attack",Qb:"Bot will randomly attack from the scoreboard list.",qb:"League Attack",nb:"Enable League Attack:",Lb:"Randomly Attack",Mb:"Attack lowest to highest",nk:"Bot will avoid attacking guild members by default.",Cd:"Expedition Location:",Bc:"Auto Collect Bonuses:",ng:"Skip Boss",$c:"Dungeon Location:",Xf:"Reset if lose?",Qd:"Underworld Settings",
Rd:"Underworld: Runs from start to finish! Set your heal % in the Heal tab (activate it first). Underworld Mode uses Underworld Heal %, so expect more food consumption. Enable Auto-login in Extras if logout occurs.",Od:"Underworld Difficulty:",Ec:"Auto Enter Underworld / Underworld Mode:",lh:"Use Mobilization if points = 0",ph:"Use rubies?",nh:"Use Sacrifice to heal?",hk:"Use Cloth to enter underworld?",hd:"Exit underworld if no points?",Yg:"The bot will try to use Villa Medici first and disable itself if there is no available Villa Medici; if thats the case, it will use a healing potion. Dont forget to enable Heal toggle.",
gh:"Auto enter Underworld will disable dungeon/arena/circus upon entering underworld.",Ok:"Underworld Heal Settings",oh:"Use Villa Medici?",mh:"Use Healing Potion?",Ne:"INFO: The bot will search for market items every selected minutes, which may pause attacking during the search.",dd:"Enable Market Search:",Oe:"Market Search Interval in Minutes:",Pe:"Suggested 10 minutes.",$d:"Item Settings:",Yd:"Item Name Includes",H:"Max Price",ae:"Item Type",Zd:"Item Rarity",Nc:"Buy Soulbound?",ce:"Items to Buy",
be:"Buy packs if any of them match the maximum price entered?",Lc:"Bought Items:",ii:"Heal Percentage",jk:"Buy Food from Shop?",kk:"Use Heal from Package?",gk:"Use Cervisia? (packages included)",ik:"Use Eggs? (packages included)",kl:"Last Used",location:"Location",Strength:"Strength",Dexterity:"Dexterity",Agility:"Agility",Constitution:"Constitution",Charisma:"Charisma",Intelligence:"Intelligence",Ug:"Train Settings",Vg:"Select the attributes you want to train. It will train once you have enough gold.",
nc:"Next action",Pi:"No",Qi:"Normal",ol:"Opponent",pl:"Opponent Level",pj:"Quests",random:"Random",vl:"Settings",Gl:"Soon...",type:"Click on icons to activate quest types. Select first 3 if you want to focus on Circus & Arena",Nl:"Yes",D:"Search",oc:"Add item",ck:"Store Forge Resources automatically",Il:"Submit",il:"Interval : ",Xk:"Enable Auto Bid",Yk:"Cover Allies` Bids",Kl:"Tutorial",bc:"More users will slow down the bot.",Rk:"Begin by adding an items full name to the list. Once added, the tool will display search results on the left. This also aids in auto-auction searches. With auto-bid enabled, the tool will periodically search based on your set interval. If the item is found and you have sufficient funds, it will bid automatically. Note: To search for unique items in shops, you must add at least one item to the search list..",
$k:"The creature number can be selected from the buttons above. Number 1 represents the leftmost creature. Make sure you select the correct location otherwise bot might pause.",Fh:"Choose the difficulty of the dungeon from the options above. Ensure you select the correct location, as otherwise, the bot might pause.",ji:"Heal Settings",Gh:"Store excess gold in Guild by buying guild market items. -> Min. Gold. Leave some empty space in first inventory.",ll:"Move All",ml:"Move Selected",Uk:"Auto Heal",
Vk:"Auto Heal Percentage",Ml:"Ruby",wf:"General Settings",Cj:"Sell All",Dj:"Sell Selected",ka:"Weapons",ha:"Shields",Z:"Chest Armour",ca:"Helmets",ba:"Gloves",ia:"Shoes",fa:"Rings",Y:"Amulets",jh:"Usable",ih:"Upgrades",Nf:"Recipes",bf:"Mercenary Scroll",Pf:"Reinforcements",We:"Sell Food",Fb:"Switch to Food"},Hh={Ni:"Yuva arama t\u00fcr\u00fc",Li:"Bir Sey Yapma",Mi:"Hizli Ara",Oi:"Kapsamli Ara",nj:"Expedition Sonras\u0131 Eylem",mk:"Tamir takilirsa TIKLA",Ak:"Kaca dustugunde iyilestirsin?",yf:"K\u0131smi Onar\u0131m",
Ld:"Tam Onar\u0131m",xf:"K\u0131smi veya Tam Onar\u0131m",bd:"Limiti Etkinle\u015ftir",li:"Limit",mi:"D\u00fc\u015fmana sald\u0131rmak istedi\u011finiz kez say\u0131s\u0131n\u0131 s\u0131n\u0131rlamak istiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin ve limiti ayarlay\u0131n. Bot, se\u00e7ilen canavara sald\u0131rmay\u0131 bitirdikten sonra di\u011fer d\u00fc\u015fmanlara sald\u0131rmaya devam edecek.",Xc:"Yeralt\u0131 kost\u00fcm\u00fc ile yeralt\u0131na girmeyin",Wc:"Yeralt\u0131 kost\u00fcm\u00fc varken yeralt\u0131na girmek istemiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin",
fh:"Yeralt\u0131 D\u00fcnyas\u0131",Xg:"Yeralt\u0131 D\u00fcnyas\u0131 G\u00fc\u00e7lendirmeleri",Zg:"Yeralt\u0131 d\u00fcnyas\u0131na girdikten sonra tanr\u0131 g\u00fc\u00e7lerini kullan?",$g:"G\u00fc\u00e7lerini kullanmak istedi\u011fin tanr\u0131lar\u0131 se\u00e7:",ah:"Silaha Silah G\u00fc\u00e7lendirmesi kullan?",bh:"A\u015fa\u011f\u0131daki ekipmana Z\u0131rh G\u00fc\u00e7lendirmesi kullan:",xk:"Bekleme s\u00fcresi 30 dakikad\u0131r. \u00dczerinde kost\u00fcm yoksa, bot bekleme s\u00fcresini s\u0131f\u0131rlar.",
Lk:"Renkleri Se\u00e7",Za:"Vulcano`nun Demirci Atesi",cb:"Feronia`nin Toprak Kalkani",eb:"Neptune`un sivi gucu",fb:"Aelous`un havali ozgurlugu",gb:"Pluto`nun olumcul nefesi",hb:"Juno`nun Hayat Solugu",ib:"Ofkeli Dag Ejderhasi Pul Zirhi",jb:"Kartal Bakisi",kb:"Saturn`un kisi giysisi",$a:"Bubona`nin okuz zirhi",ab:"Mercerius`un Hirsiz Kaftani",bb:"Ra`nin isikli esvabi",Ve:"Paketler",Qe:"Envanter",K:"Min. Fiyat",J:"Ka\u00e7 Tane",Eb:"E\u015fya Sat",Db:"\u015eurada Ara",Re:"Malzeme Rengi",Cb:"E\u015fya Rengi",
Ye:"Depo",Fa:"Malzemelere Ge\u00e7",Gb:"E\u015fyalara Ge\u00e7",Xe:"Malzeme Sat",Ca:"L\u00fctfen ge\u00e7erli bir e\u015fya ad\u0131, fiyat aral\u0131\u011f\u0131 ve miktar girin.",Da:"Se\u00e7ilen arama konumlar\u0131nda uygun e\u015fya bulunamad\u0131.",Ea:"T\u00fcm e\u015fyalar ba\u015far\u0131yla listelendi!",Fk:"T\u00fcm malzemeler ba\u015far\u0131yla listelendi!",Te:"Sabit fiyata e\u015fya satmak istiyorsan\u0131z, min ve maks fiyat i\u00e7in ayn\u0131 de\u011feri girebilirsiniz.",Ue:"Bu \u00f6zellik hala deneyseldir, dikkatli kullan\u0131n. Sabit fiyat koymazsan\u0131z, girdi\u011finiz minimum ve maksimum fiyat aras\u0131nda rastgele \u00f6\u011feler listeleyecektir.",
Kj:"Eritmek istedi\u011finiz e\u015fya t\u00fcrlerini se\u00e7in.",Lj:"Eritmek istedi\u011finiz renkleri se\u00e7in.",Mj:"Eritmek istedi\u011finiz e\u015fyalar\u0131n seviyesini se\u00e7in.",Nj:"Kullanmak istedi\u011finiz \u00e7ekici se\u00e7in.",Oj:"\u0130lk kutunun yan\u0131ndaki Ye\u015fil ve K\u0131rm\u0131z\u0131 \u00e7emberin kural\u0131 etkinle\u015ftirme/devre d\u0131\u015f\u0131 b\u0131rakma i\u00e7in oldu\u011funa dikkat edin.",Pj:"E\u011fer rastgele herhangi bir renk veya t\u00fcr\u00fc ergitmek istiyorsan\u0131z, Ko\u015fullar sa\u011flanmazsa rastgele eritilsin mi? (E\u011fitim videosundaki son etkinle\u015ftirilen se\u00e7enek) se\u00e7ene\u011fini etkinle\u015ftirebilirsiniz.",
tk:"Bot`un her d\u00f6ng\u00fcde harcayaca\u011f\u0131 maksimum alt\u0131n\u0131 belirler.",Ua:"Etkinle\u015ftirilirse, bot herhangi bir yiyecek \u00f6\u011fesi i\u00e7in teklif vermeye ba\u015flar. Gladyat\u00f6r/asker ayar\u0131n\u0131 etkinle\u015ftirmeniz gerekmez.",vc:"Bot, m\u00fcttefiklerin tekliflerine teklif vermez.",wc:"A\u00e7\u0131k art\u0131rmada bir \u00f6\u011fe ararken \u00d6nek/Son ek kombinasyonunu g\u00f6rmezden gelir.",rj:"Eritmeden \u00f6nce tamir et?",yd:"Canavar Se\u00e7",md:"Kum Saati/Rub kullan?",
zk:"Rub kullan?",pd:"Mobilizasyon Kullan?",od:"Ya\u015fam \u0130ksiri Kullan?",ld:"\u0130yile\u015ftirme Y\u00fczdesi (%)",wd:"Sald\u0131r\u0131 Say\u0131s\u0131",nd:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131 (saniye cinsinden)",jd:"Yap\u0131lan Sald\u0131r\u0131lar",kd:"Kalan Kum Saati",ud:"Not: \u0130yile\u015ftirmek i\u00e7in yiyecek de\u011fil, ya\u015fam iksiri kullan\u0131r.",vd:"Not: Sald\u0131r\u0131lar erken durursa, 'Sald\u0131r\u0131lar\u0131 S\u0131f\u0131rla' deneyin.",zd:"Ba\u015flat",
xd:"S\u0131f\u0131rla",Ad:"Durdur",Bd:"Ke\u015fif Ayarlar\u0131 (K\u00fc\u00e7\u00fcltmek i\u00e7in t\u0131klay\u0131n)",qd:"Canavar 1",rd:"Canavar 2",sd:"Canavar 3",td:"Canavar 4",Ik:"Eritmeden \u00f6nce tamir et?",yh:"Bu se\u00e7enek, premium \u00fcyeli\u011finiz sona erdi\u011finde cervisia kullanacak.",Ri:"Bu se\u00e7enek, tanr\u0131 \u00f6d\u00fcllerinden ya\u011flar\u0131 etkinle\u015ftirir ve se\u00e7er. Karakter \u00fczerinde 1 numara ve 3 numara ya\u011flar\u0131 kullanabilir ancak 2 numara sadece paketlere al\u0131n\u0131r.",
wh:"Bu se\u00e7enek, belirledi\u011finiz zamanda buff kullan\u0131r. Paketlerdeki bufflar\u0131 bulur ve karaktere uygular.",ni:"Bu se\u00e7enek sizi kesif seferleriniz 2 ve altina geldiginde yeralt\u0131 d\u00fcnyas\u0131na sokar. Ekstralar sekmesinden Otomatik Giri\u015fi etkinle\u015ftirmeyi unutmay\u0131n, yoksa yeralt\u0131na girerken \u00e7\u0131k\u0131\u015f yapabilirsiniz [Oyun Hatas\u0131]",$b:"Bot normalde rastgele 3 ila 6 deneme ile arena listesine sald\u0131r\u0131r. Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, sald\u0131rabilece\u011fi birini bulana kadar listenizde ilerler. Bu biraz zaman alabilir.",
oj:"Bu se\u00e7enek sadece premium lisanslar i\u00e7indir. Kullan\u0131c\u0131ya sald\u0131rmadan \u00f6nce %75 kazanma oran\u0131 ile sald\u0131r\u0131y\u0131 sim\u00fcle eder.",yc:"Bu se\u00e7ene\u011fi etkinle\u015ftirmek i\u00e7in ana m\u00fczayede ge\u00e7i\u015fini etkinle\u015ftirmenize gerek yoktur.",fk:"Bu se\u00e7enek, m\u00fczayede -\u00c7ok K\u0131sa- durumundayken sayfay\u0131 her saniye yeniler ve s\u00fcrekli teklif vererek m\u00fczayede kazanmay\u0131 ama\u00e7lar.",Ij:"E\u011fer eritme ko\u015fullar\u0131ndan hi\u00e7biri kar\u015f\u0131lanmazsa rastgele eritir. L\u00fctfen e\u015fya tipini ve rengini se\u00e7in.",
Jj:"Bu se\u00e7enek sadece envanterdeki e\u015fyalar\u0131 eritir. Paketlerdeki e\u015fyalar\u0131 g\u00f6rmezden gelecektir.",Ej:"Arkaplan\u0131 Siyah yap",Fj:"Bot butonlarini sol alta koy?",zh:"Iyilestirme olmadan Sirke Sald\u0131r?",dk:"Gerekirse paketlerden alt\u0131n al\u0131ns\u0131n?",ek:"E\u011fitim i\u00e7in paketlerden alt\u0131n al\u0131nd\u0131",Jl:"E\u011fitim i\u00e7in paketlerde alt\u0131n bulunamad\u0131",nl:'GLDbot: Gizem kutusunu yenilemek ve de\u011ferli e\u015fyalar\u0131 (Vb. Kost\u00fcmler) a\u00e7madan \u00f6nce bulmak i\u00e7in zarlar\u0131 kullan. Sand\u0131klar\u0131 a\u00e7mak i\u00e7in "Ba\u015flat"a t\u0131kla.',
Va:"Muzayede Esyalari",af:"Mersaneri Esyalari",Ub:"Dukkan Esyalari",hh:"Degerli Dukkan Esyalari",ak:"E\u015fyalar Tamir Edildi",Uj:"Arena Sald\u0131r\u0131lar\u0131",Wj:"Sirk Sald\u0131r\u0131lar\u0131",pc:"E\u015fyalar S\u0131f\u0131rland\u0131",Zj:"Sefer Sald\u0131r\u0131lar\u0131",Yj:"Zindan Sald\u0131r\u0131lar\u0131",bk:"Yeralt\u0131 Sald\u0131r\u0131lar\u0131",Vj:"Arenadan Kazan\u0131lan Para",Xj:"Sirkten Kazan\u0131lan Para",Hl:"E\u015fyalar Eritildi",$j:"D\u00f6n\u00fc\u015ft\u00fcr\u00fclen Alt\u0131n",
ei:"Lonca Sava\u015f\u0131",gi:"Lonca Ayarlar\u0131",bl:"Loncalara rastgele sald\u0131racak.",fi:"Lonca Ismi",di:"Rastgele Sald\u0131r",xh:"\u0130statistikleri S\u0131f\u0131rla",kc:"Ah\u015fap",hc:"Bak\u0131r",ic:"Demir",jc:"Deri",xi:"Y\u00fcn \u0130plik",pi:"Y\u00fcn Yuma\u011f\u0131",si:"Kenevir",ri:"Gaze \u015eeridi",ui:"Keten Par\u00e7as\u0131",ti:"J\u00fct Dikimi",wi:"Kadife \u015eerit",vi:"\u0130pek \u0130plik",Ei:"Post Par\u00e7as\u0131",yi:"Kemik Par\u00e7as\u0131",Hi:"Kepek",Bi:"Pen\u00e7e",
Di:"K\u00f6pek Di\u015fi",Ci:"Ejderha Kepe\u011fi",zi:"Bo\u011fa Boynuzu",Gi:"Zehir Bezesi",Ai:"Cerberus`un post par\u00e7as\u0131",Fi:"Hidra pulu",Ii:"Sfenks t\u00fcy\u00fc",Ji:"Tifon derisi",ai:"Lacivert Tasi",Vh:"Ametist",Uh:"Kehribar",Wh:"Akuamarin",bi:"Safir",Zh:"Grena Ta\u015f\u0131",Yh:"Z\u00fcmr\u00fct",Xh:"Elmas",$h:"Jaspis",ci:"Sugilith",Ph:"Akrep Zehri",Sh:"Dayan\u0131kl\u0131l\u0131k Tent\u00fcr\u00fc",Lh:"Antidot",Kh:"Adrenalin",Rh:"Ayd\u0131nl\u0131k Tent\u00fcr\u00fc",Oh:"Alg\u0131 Tent\u00fcr\u00fc",
Mh:"Refleks Esans\u0131",Nh:"Karizma Flakonu",Th:"Unutman\u0131n Suyu",Qh:"Ruh esans\u0131",Aj:"Su M\u00fchr\u00fc",uj:"Koruyucu Runik",sj:"D\u00fcnya Grav\u00fcr\u00fc",zj:"\u015eifa Totemi",yj:"G\u00fc\u00e7 T\u0131ls\u0131m\u0131",wj:"\u015eans Ta\u015f\u0131",tj:"Ate\u015f Ta\u015f\u0131",xj:"F\u0131rt\u0131na Runi\u011fi",vj:"G\u00f6lge runi\u011fi",Ui:"Kristal",Ti:"Bronz",Yi:"Obsidyen",aj:"G\u00fcm\u00fc\u015f",bj:"K\u00fck\u00fcrt",Wi:"Alt\u0131n Madeni",$i:"Kuvars",Zi:"Platin",Si:"Almandin",
Vi:"Cuprit",Xi:"Cehennem ta\u015f\u0131",th:"Provinciarum'da Rastgele Sald\u0131r?",uh:'Crazy-addon\'da "Arena oyuncular\u0131n\u0131 seviyeye g\u00f6re s\u0131rala" se\u00e7ene\u011fini de devre d\u0131\u015f\u0131 b\u0131rak\u0131n.',Kf:"Sadece tanr\u0131 t\u00fcr\u00fcne g\u00f6re g\u00f6rev kabul et.",Wa:"Oto Buff",Mc:"Sadece cehennemde kullan?",rf:"Yeni Kural",pf:"\u0130sim \u0130\u00e7erir",isUnderworldItem:"Yeralt\u0131 item mi?",Ud:"Malzemeleri Yoksay",lk:"Dua Kullan?",nh:"\u015eifalanmak i\u00e7in Kurban Kullan?",
hk:"Yeralt\u0131na girmek i\u00e7in kuma\u015f kullan?",eh:"Yeralt\u0131nda sadece yeralt\u0131 ile ilgili g\u00f6revleri kabul et?",dh:"Etkinle\u015ftirilirse, yeralt\u0131 item adlar\u0131n\u0131 girmeniz gerekir. Bot, bu itemlari yeralt\u0131nda bulursa g\u00f6revi kabul eder.",Pk:"Yeralt\u0131 G\u00f6rev Itemi",Zk:"Malzeme Ad\u0131n\u0131 Girin",wk:"Bot zarlar\u0131 sever! Zarlar, sand\u0131klarda k\u0131yafet bulmaya yard\u0131mc\u0131 olur. Ancak zar yoksa, bot yine de sand\u0131klar\u0131 a\u00e7ar ve k\u0131yafetler bulmay\u0131 umar (ama bulamayabilir!).",
Hj:"Ertilen malzemeleri pakete g\u00f6nder?",ad:"Arena'y\u0131 Etkinle\u015ftir",Cf:"Arena listesini \u00f6nceliklendir?",Df:"Sirk listesini \u00f6nceliklendir?",Tc:"Log Men\u00fcs\u00fcn\u00fc Devre D\u0131\u015f\u0131 B\u0131rak",Yf:"\u00d6d\u00fcl Min. Alt\u0131n De\u011feri",Lf:"Odaklanm\u0131\u015f G\u00f6rev, etkinle\u015ftirilirse, zindan\u0131 bitirmek i\u00e7in en k\u0131sa yolu izler.",ug:"Zar\u0131 Otomatik At?",vg:"Zar\u0131 dikkatli kullan\u0131n, ilk zar\u0131 se\u00e7ene\u011fi devre d\u0131\u015f\u0131 b\u0131rakana kadar kullanmaya devam eder.",
cg:"Arama \u0130lerlemesi",Sf:"Onar\u0131m\u0131n varsay\u0131lan bekleme s\u00fcresi 10 dakikad\u0131r.",lf:"Minimum Durum",Rc:"\u0130\u015f tezgah\u0131ndaki mevcut \u00f6\u011fe [Bot beklenmedik \u015fekilde durursa Temizle]",oe:"D\u00f6k\u00fcm Kaynaklar\u0131 ba\u015far\u0131yla horreuma depoland\u0131.",ke:"Pazar yerindeki \u00f6\u011feleri kontrol ediyor...",Ab:"\u00d6\u011fe i\u015f tezgah\u0131na ta\u015f\u0131nd\u0131.",Ce:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131 ve donat\u0131ld\u0131.",
De:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131.",Dk:"Onar\u0131m ba\u015far\u0131s\u0131z oldu. Sayfa yenilenecek.",ze:"Malzemeler toplan\u0131yor...",Me:"Onar\u0131m bekleniyor...",Be:"Onar\u0131m ba\u015flad\u0131.",Ba:"Onar\u0131m: \u00d6\u011feyi envanterden \u00e7antaya ta\u015f\u0131ma",Ae:"Onar\u0131m: \u00d6\u011feyi i\u015f tezgah\u0131ndan pakete ta\u015f\u0131ma.",sb:"Yeterli malzeme bulunamad\u0131. Onar\u0131m slotunu 5 dakikaligina devre disi birakiyorum. ",we:"Alt\u0131n\u0131 saklamak i\u00e7in a\u00e7\u0131k art\u0131rmadan sat\u0131n al\u0131nacak \u00f6\u011feler aran\u0131yor...",
he:"Paketlerdeki s\u00fcresi dolmu\u015f \u00f6\u011feler kontrol ediliyor...",ie:"\u00d6\u011fe ba\u015far\u0131yla s\u0131f\u0131rland\u0131.",je:"Bo\u015f Alan veya S\u0131f\u0131rlanacak Alt\u0131n Yok.",pe:"Klan pazar\u0131nda sat\u0131\u015f haklar\u0131n\u0131z oldu\u011fundan emin olun!",ub:"Yeterli alt\u0131n ve/veya sat\u0131n al\u0131nacak \u00f6\u011fe yok. Yenilemek i\u00e7in 30sn bekliyor.",wb:"Ma\u011faza yenilendi.",xb:"\u0130yile\u015ftirme s\u0131ras\u0131nda hata.",se:"Ruby veya Kuma\u015f yok, se\u00e7enekleri devre d\u0131\u015f\u0131 b\u0131rak.",
te:"Paketlerde helaing \u00f6\u011fesi bulunamad\u0131.",yb:"Uygun \u00f6\u011feler bulunamad\u0131",ue:"Yiyecekler topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",ve:"En az bir yiyecek topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",zb:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",qe:"Paketlerden yiyecek al\u0131n\u0131yor.",re:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",vb:"Daha fazla iyile\u015ftirme \u00f6\u011fesi yok. 30 saniye bekliyor.",
tb:"HP Kurtar\u0131ld\u0131.",Aa:"Yapacak bir \u015fey yok, bu y\u00fczden dua edece\u011fim!",Ie:"Sa\u011fl\u0131\u011f\u0131m\u0131 ve villa medicimi kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Je:"Villa Medici bekleniyor, 60 saniye i\u00e7inde yenileniyor.",Ke:"Underworld terk edildi.",Le:"Sa\u011fl\u0131\u011f\u0131m\u0131 kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",xe:"Tanr\u0131 ya\u011flar\u0131 kontrol ediliyor...",ye:"Tanr\u0131 ya\u011flar\u0131 topland\u0131.",
ya:"ARENADA ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",za:"CIRCUS'ta ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",fe:"A\u00e7\u0131k art\u0131rma kontrol ediliyor! L\u00fctfen bekleyin...",ge:"\u00d6\u011felere teklif veriliyor. L\u00fctfen bekleyin...",Ee:"Otomatik Eritilen Item: ",Fe:"Eritme \u00d6\u011fesi: ",Ge:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n: ",He:"ER\u0130T: Eritilecek \u00f6\u011feler aran\u0131yor...",Ek:"Eritilecek \u00f6\u011feler aran\u0131yor...",
le:"Kost\u00fcm mevcudiyeti kontrol ediliyor...",ne:"Ba\u011f\u0131\u015fland\u0131 : ",me:"Zar at\u0131l\u0131yor...",Hd:"Yeralti Farmla [Manuel, BETA]",Id:"Bu ozelligi saldirmak istediginiz yaratigi actiktan sonra acin, otomatik olarak yaratigi acana kadar saldirmayacaktir. Dikkat edin.",Gd:"Farm Lokasyonu",Fd:"Farm Dusmani",Fc:"Otomatik Giri\u015f",Gc:"GameForge lobisinden a\u00e7\u0131l\u0131r pencere izinlerini vermeniz gerekmektedir. Nas\u0131l yap\u0131laca\u011f\u0131na dair dok\u00fcmantasyona bak\u0131n.",
zf:"Bot'u Durdur",Af:"Bot'u ka\u00e7 dakika bitince durdurmak istersiniz? (Dakika)",Dd:"Son Kullanma Tarihi",uf:"Sadece yemek sat\u0131n al?",vf:"Bunu etkinle\u015ftirirseniz, se\u00e7imlerinizi g\u00f6rmezden gelir ve herhangi bir \u015fey girmeden otomatik olarak yemek sat\u0131n al\u0131r.",Ib:"Harcamak i\u00e7in maksimum toplam alt\u0131n",Hb:"Harcamak i\u00e7in maksimum alt\u0131n miktar\u0131",tf:"Bot, ya\u011flar\u0131 her 60 dakikada bir kontrol edecek",Ng:"Eritme s\u00fcrelerini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Kg:"Alt\u0131n\u0131n\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Mg:"Kullan\u0131labilir e\u015fyan\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Fg:"E\u015fyalar\u0131n\u0131z\u0131 kontrol etmek i\u00e7in bir tamir zamanlay\u0131c\u0131 ayarlar.",Eg:"Ittifak pazar\u0131ndaki alt\u0131n\u0131 kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Ag:"M\u00fczayede tutma alt\u0131n\u0131 se\u00e7ene\u011fi i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
wg:"Arenadaki PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Bg:"Sirk PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Tg:"\u0130statistiklerinizi e\u011fitmek i\u00e7in bir e\u011fitim zamanlay\u0131c\u0131 ayarlar.",Hg:"S\u00fcresi dolmu\u015f e\u015fyalar\u0131 s\u0131f\u0131rlamak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Rg:"D\u00f6vme malzemelerini horreum'a koymak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",yg:"Gladyat\u00f6rler ve paral\u0131 askerler m\u00fczayede kontrol\u00fc i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Jg:"M\u00fczayede ve market i\u00e7in e\u015fya aramak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Cg:"Ittifaga ba\u011f\u0131\u015f g\u00f6nderme zamanlay\u0131c\u0131s\u0131n\u0131 ayarlar.",Md:"Alt\u0131n Ta\u015f\u0131nd\u0131",Yc:"Eritme ve Muzayede listesi e\u015fyalar\u0131n\u0131 satma",dg:"Market Otomasyonu",fg:"E\u015fya Arama Ayarlar\u0131",eg:"Bu ozellik, dukkanlarda e\u015fya aramak i\u00e7in kullanilir. Sadece e\u015fyalar\u0131 listeye ekleyin, kuma\u015f miktar\u0131n\u0131 belirtin ve aramay\u0131 ba\u015flat\u0131n. Ornegin mor samnit, mor samnit i bulana kadar arar.",
gg:"Kullan\u0131lacak Kuma\u015flar:",hg:"Ka\u00e7 kuma\u015f kullan\u0131lacak?",ja:"Full E\u015fya Ad\u0131n\u0131 Girin",Tb:"E\u015fya Seviyesini Girin",jg:"E\u015fya Kalitesi",ig:"E\u015fya Ad\u0131 Buraya",kg:"Aramaya Ba\u015fla",lg:"Atla ve Devam Et",mg:"Aramay\u0131 Durdur",Jd:"En ucuz mu, en pahal\u0131 m\u0131 alay\u0131m?",nf:"En Pahal\u0131",Oc:"En Ucuz",ga:"Bir se\u00e7enek se\u00e7in",cd:"Yeralt\u0131 D\u00fcnyas\u0131 Itemlarini Goster",Kd:"G\u00f6reve odaklan\u0131ls\u0131n m\u0131?",
Ll:"Elbise yoksa yakut kullan?",Xa:"Diger serverlarda sald\u0131rmak icin, oyuncunun sayfasini acin ve A & C butonlariyla ekleyin. Not: Rapor edilmemek i\u00e7in ayn\u0131 ki\u015filere sald\u0131rmaktan ka\u00e7\u0131n\u0131n. Rapor edilmek, banlanma \u015fans\u0131n\u0131z\u0131 art\u0131r\u0131r.",Al:"Yesil Eritilsin mi?",Ff:"Herhangi bir filtre girildiyse rastgele g\u00f6revleri kabul etme?",lc:"Maksimum materyal kalitesi?",Hh:"Mersaneri Ara?",jl:"T\u00fcm Se\u00e7ilenleri Sat\u2019\u0131 t\u0131klay\u0131n ve t\u00fcm e\u015fyalar\u0131 sat\u0131n. \u0130lk (1) \u00e7antan\u0131zda 2x3 bo\u015f alan oldu\u011fundan emin olun ve kalite secmeyi unutmayin. Alt\u0131n toplamak i\u00e7in, alt\u0131n\u0131 filtreleyin ve `Se\u00e7ilenleri Al veya T\u00fcm\u00fcn\u00fc Al`\u0131 kullan\u0131n",
Tj:"\ud83d\udd25 : E\u015fyay\u0131 eritme listesine ekler.",vh:"\ud83d\udd28 : E\u015fyay\u0131 a\u00e7\u0131k art\u0131rma listesine ekler.",qj:"D\u00fckkan dolu oldu\u011funda d\u00fckkan\u0131 kuma\u015fla yenileyin (Yeniden sat\u0131n alman\u0131z gerekecek)",ej:"Sayfa:",lj:"Durdur",jj:"Bu Sayfay\u0131 Sat",gj:"Se\u00e7ilenleri Al",fj:"T\u00fcm\u00fcn\u00fc Al",mj:"Paket Ayarlar\u0131",kj:"Kaynaklar\u0131 G\u00f6nder",hj:"T\u00fcm Se\u00e7ilenleri Sat",ra:"E\u015fya T\u00fcr\u00fc",W:"Silahlar",
S:"Kalkanlar",M:"Z\u0131rhlar",P:"Kasklar",O:"Eldivenler",N:"Ayakkabilar",V:"Y\u00fcz\u00fckler",U:"Nazarliklar",pa:"Malzemeler (Yiyecekler)",wa:"G\u00fc\u00e7lendirmeler",cj:"Yukseltmeler",ta:"Receteler",sa:"Mersaneri Askerler",va:"Demirhane Mallari",ua:"Persomenler",Oa:"Takviyeler",Ma:"Etkinlik E\u015fyalar\u0131",Na:"D\u00f6vme Malzemeleri",dj:"Alt\u0131n",T:"Hepsi",ql:"Kalite",X:"Beyaz",B:"Ye\u015fil",A:"Mavi",C:"Mor",G:"Turuncu",R:"K\u0131rm\u0131z\u0131",ij:"T\u00fcm Sat\u0131\u015f Se\u00e7enekleri",
Gj:"\u00d6nek/Sonek Kombinasyonunu Yoksay?",hi:"Ka\u00e7 yiyecek sat\u0131n almak/al\u0131nmal\u0131?",Ch:"Normal",Bh:"Orta",Ah:"Zor",Ja:"Standart",tl:"S\u0131k\u0131\u015fma Onar\u0131m\u0131",Bk:"Dungeon/Circus/Arena\u2019y\u0131 devre d\u0131\u015f\u0131 b\u0131rakmak istiyorsan\u0131z Cehenneme Giri\u015fi Devre D\u0131\u015f\u0131 B\u0131rakin. Cehenneme manuel olarak girdiyseniz, Cehennem Modu\u2019nu etkinle\u015ftirmeniz gerekecektir.",Wg:"Egitimleri ka\u00e7 kez e\u011fitmek istedi\u011finizi ve onlar\u0131n \u00f6nceliklerini belirleyin. Bot, bir \u00f6ncelik belirlemedik\u00e7e e\u011fitim yapmayacakt\u0131r. E\u011fer \u00f6ncelik belirlenmi\u015fse ancak ba\u015fka bir egitim kalmam\u0131\u015fsa, secilen egitim devam edecektir.",
Wk:"Gorev",yl:"Erit",El:"Eritme Ayarlar\u0131",Qj:"Eritilen Nesneler",Fl:"\u00d6nek veya Sonek Ekle, paketlerde bulunursa otomatik olarak eritilecektir.:",Dl:"Eritilen Nesne:",cc:"Onarmak istedi\u011finiz nesneyi t\u0131klay\u0131n. Onar\u0131ma ba\u015flamak i\u00e7in en az 10,000 alt\u0131n\u0131z\u0131n olmas\u0131 gerekmektedir. Yeni repair sistemi refresh atilsa bile kaldigi yerden devam edecektir. Sorun cikarsa clear a basip workbench itemini temizleyebilirsiniz. Ayr\u0131ca envanterinizde yer a\u00e7mayi unutmayin. Bot, kondisyon seciminize gore aktif olacaktir.",
Qk:"Sadece S\u00f6zle\u015fmeliye Uygula",Tk:"M\u00fczayede yaln\u0131zca piyasa sona yakla\u015ft\u0131\u011f\u0131nda teklif verecektir.",Sk:"Envanterde bos yer acmayi ve en az 7K alt\u0131n\u0131n\u0131z\u0131n oldu\u011fundan emin olun. Bot 1. koydugunuz prefixden baslayip sona dogru bakacaktir, bu siralamayi uzerine gelip tasiyarak degistirebilirsiniz. Bot, sectiginiz sekmeye gore itemlari tasiyacak ve eritecektir. Eritme i\u015flemi her ayarlanan zamana gore kontrol edilir. Bu ayari Zamanlayici sekmesinden degistirebilirsiniz. Eger kombinasyon olarak bakmak istemiyorsaniz, onek sonek kombinasyonunu yoksay`i aktiflestirin.",
ki:"\u0130yile\u015ftirme/Buff",ul:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n:",xl:"Teklifi Atla: ittifak \u00fcyesi zaten nesne i\u00e7in teklif verdi ",wl:"Teklifi Atla: Zaten nesne i\u00e7in teklif verildi ",advanced:"Geli\u015fmi\u015f",arena:"Arena",na:"Otomatik sald\u0131r\u0131 listesi",ac:"Bu listedekilere sald\u0131rma",la:"Oyuncu Ekle",ma:"Oyuncu Ad\u0131 Gir (Ayni Server)",dl:"Yiyecek t\u00fckenirse Botu Durdur?",circusTurma:"Sirkin Turma",Dh:"Zorluk",dungeon:"Zindan",
Eh:"Zindan Ayarlar\u0131",eventExpedition:"Etkinlik Seferi",expedition:"Sefer",Ih:"Sefer Ayarlar\u0131",Bj:"Yarat\u0131k Se\u00e7",gl:"En Y\u00fcksek",el:"\u0130yile\u015ftirme e\u015fyalar\u0131n\u0131z\u0131 envanterinizin ilk sayfas\u0131na koyun",fc:"\u0130\u00e7inde",Pc:"Yeralti kostumu secin",qh:"Yeralti kostumu hazir oldugunda giy?",sg:"Alt\u0131n\u0131 Depola",tg:"Alt\u0131n\u0131 M\u00fczayedede Depola?",ag:"D\u00fckk\u00e2n\u0131 yenilemek i\u00e7in \u0130\u015f K\u0131yafetleri kullan\u0131ls\u0131n m\u0131?",
Kk:"S\u0131f\u0131rlanacak Nesneleri Se\u00e7in",Uf:"S\u00fcresi Dolan Nesneleri S\u0131f\u0131rla",Ob:"Not: Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, bot paketlerden gelecek s\u00fcresi dolan nesneleri ittifak marketine satar ve s\u00fcrelerini s\u0131f\u0131rlar. Ittifak gereklidir. \u00c7antalar\u0131n\u0131zda bo\u015f 3x3 alan\u0131n\u0131z oldu\u011fundan emin olun, ozellikle birinci canta. Her basladiginda son 7 sayfaya bakar. Eger calismazsa oyun ayarlarindan sure bitimini tarih olarak ayarlayin.",
Bf:"Bota Rastgele Ara Vermesini Sa\u011fla [Test A\u015famas\u0131]:",da:"Alt\u0131n\u0131 Tut: Bot bu alt\u0131n\u0131 \u00e7antada saklayacak:",Ze:"Maksimum Alt\u0131n",Zf:"Gereksiz itemlar i\u00e7in teklif verilecek",qc:"Rastgele Gecikme Ekle",rc:"Bot i\u00e7in rastgele gecikme ekleyebilirsiniz.",Nb:"Onar\u0131m",zl:"Mavi Eritilsin mi?",Cl:"Mor Eritilsin mi?",Bl:"Turuncu Eritilsin mi?",Rj:"Sadece envantere koyulanlari mi eritsin?",Sj:"Bu renk se\u00e7imlerini yok sayacakt\u0131r",Pa:"\u00d6nek Ekle",
Qa:"Sonek Ekle",og:"Erit",zc:"Otomatik Arama",qf:"Otomatik M\u00fczayede",Ac:"Bu ozelligi fazla kullanmak banlanmaniza sebep olabilir. Eger Crazy Addon`da muzayedeyi zamanlarini gosteren ozelligi aktif ettiyseniz bu ozelligi kullanmadan once onu iptal edin, yoksa yavaslama olacaktir.",$f:"Gladyat\u00f6rler M\u00fczayedesinde Ara",bg:"Mersaneriler M\u00fczayedesinde Ara",Ic:"Yiyecek \u0130\u00e7in Teklif Verilsin mi?",$e:"Maksimum Teklif",Jc:"Durum daha azsa teklif ver",Kc:"Teklif Edilen Nesneler",
rk:"M\u00fczayede Dili",sk:"L\u00fctfen dil ayarlarini oyunun diline gore tekrar ayarlay\u0131n.. Hepsi do\u011fru oldu\u011fundan emin olun, aksi takdirde teklif vermeyebilir.",uc:"Piyasada aranacak nesneleri ekleyebilirsiniz. Bir nesneyi listede ekledi\u011finizde, nesneyi arayacak ve sonu\u00e7lar\u0131 sol tarafta g\u00f6sterecektir. Otomatik m\u00fczayedeyi aramak i\u00e7in de arayacakt\u0131r. Otomatik teklifi etkinle\u015ftirirseniz, belirledi\u011finiz aral\u0131klarla nesneyi arayacak ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: Tekil nesneleri d\u00fckkanlarda aramak i\u00e7in, en az\u0131ndan bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
pk:"M\u00fczayedeyi dikkatli kullan\u0131n!",qk:"Otomatik teklif, sunucuya \u00e7ok fazla istek g\u00f6nderir ve s\u00fcrekli kullan\u0131rsan\u0131z yasa\u011fa neden olabilir!",Rf:"Etkinlik Puanlar\u0131n\u0131 Yakut ile Yenile?",ed:"Otomatik Ya\u011f Topla",uk:"Kutsal Ya\u011flar\u0131 Otomatik Al",Gk:"G\u00f6rev Kontrol H\u0131z\u0131",Ta:"Ittifak \u00dcyelerine Sald\u0131r\u0131ls\u0131n m\u0131?",Ra:"Oto Sald\u0131r\u0131 listesine cal\u0131nan Alt\u0131n X ALTINI a\u015ft\u0131\u011f\u0131nda > eklensin mi? ",
Sa:"Yenildi\u011finizde otomatik olarak eklensin mi?:",Rb:"Skor Tablosu Sald\u0131r\u0131lar\u0131",Yb:"\u00c7ok Uzun",Bb:"Uzun",Jb:"Orta",Vb:"K\u0131sa",Zb:"\u00c7ok K\u0131sa",fd:"HP > ise Yeralt\u0131 D\u00fcnyas\u0131'na Gir",Mf:"G\u00f6rev Kontrol H\u0131z\u0131",Ef:'Varsay\u0131lan olarak "3x" ayarl\u0131d\u0131r. Bot g\u00f6revlerle sorun \u00e7\u0131kar\u0131yorsa, g\u00f6rev h\u0131z\u0131n\u0131 sunucu h\u0131z\u0131n\u0131za g\u00f6re ayarlay\u0131n.',Nd:"\u0130yile\u015ftirme \u00c7anta Se\u00e7imi",
gd:'Puanlar\u0131 manuel olarak yeniliyorsan\u0131z, s\u0131k\u0131\u015f\u0131rsa "Yeniden Etkinlik Seferi Yenile" d\u00fc\u011fmesine t\u0131klaman\u0131z gerekmektedir!',yk:"Etkinlik Seferi'ni ba\u015flatmak i\u00e7in en az birini etkinle\u015ftirmeniz gerekmektedir: sefer, zindan, arena veya sirk.",Of:"E\u011fer s\u0131k\u0131\u015f\u0131rsa Etkinlik Seferi'ni Yenile!",lb:"\u0130ttifak \u00fcyesi teklif verdiyse atlas\u0131n m\u0131?",Mk:"E\u011fer paketlerde bulunan \u00f6\u011feleri kullanarak eritmek istiyorsan\u0131z, t\u00fcm ayarlar\u0131 devre d\u0131\u015f\u0131 b\u0131rak\u0131n. Ancak hala renkleri se\u00e7ebilirsiniz.",
vk:"Karakter(Kapal\u0131) / S\u00f6zle\u015fmeli(A\u00e7\u0131k)",Jk:"Ana/Sirk her iki karakteri de tamir etsin mi?",Nk:"Zamanlar",Timers:"Her zamanlay\u0131c\u0131 i\u00e7in a\u015fa\u011f\u0131daki dakika cinsinden say\u0131lar\u0131 girin veya varsay\u0131lan b\u0131rak\u0131n. Dikkat edin! eger cok kisa sureler girerseniz baz\u0131 ozellikler botu donguye sokayabilir.",ob:"Skor Tablosu Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Pb:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131n\u0131 Se\u00e7",
Qb:"Bot, skor tablosu listesinden rastgele sald\u0131r\u0131 yapacakt\u0131r.",qb:"Lig Sald\u0131r\u0131s\u0131",nb:"Lig Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Lb:"Rastgele Sald\u0131r",Mb:"En d\u00fc\u015f\u00fckten en y\u00fckse\u011fe sald\u0131r",nk:"Bot, varsay\u0131lan olarak ittifak \u00fcyelerine sald\u0131rmaktan ka\u00e7\u0131nacakt\u0131r.",Cd:"Sefer Yeri:",Bc:"Bonuslar\u0131 Otomatik Al:",ng:"Boss`a sald\u0131rma",$c:"Zindan Yeri:",Xf:"Kaybederseniz S\u0131f\u0131rlans\u0131n m\u0131?",
Qd:"Cehennem Ayarlar\u0131",Rd:"Bu mod birden sona kadar saldirarak cehennemi bitirir. \u0130yile\u015ftirme y\u00fczde ayarlar\u0131n\u0131z\u0131 iyile\u015ftirme sekmesinden yap\u0131land\u0131r\u0131n ve iyile\u015ftirme sekmesini etkinle\u015ftirdi\u011finizden emin olun. Cehennem modu aktif oldugunda bot cehennem iyilestirme oranina gore karakterinize yemek yedirecektir. Cehenneme giri\u015f sizi oturumdan \u00e7\u0131kar\u0131yorsa, extralar tabini ziyaret edin ve otomatik giri\u015f kutusunu i\u015faretleyin.",
Od:"Cehennem Zorlu\u011fu",Ec:"Otomatik Cehennem Giri\u015fi / Cehennem Modu:",lh:"Puan = 0 ise Mobilizasyon Kullan?",ph:"Yakut Kullan?",hd:"Puan Yoksa Cehennemden \u00c7\u0131k\u0131ls\u0131n m\u0131?",Yg:"Bot, \u00f6nce villa mediciyi kullanmaya \u00e7al\u0131\u015facakt\u0131r, e\u011fer yoksa iyile\u015ftirme iksiri kullanacakt\u0131r. \u0130yile\u015ftirme anahtar\u0131n\u0131 etkinle\u015ftirdi\u011finizden emin olmay\u0131 unutmay\u0131n.",gh:"Otomatik cehennem giri\u015fi, cehenneme girdi\u011finizde zindan/arena/sirk otomatik olarak devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",
Ok:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",oh:"Villa Medici Kullan?",mh:"\u0130yile\u015ftirme \u0130ksiri Kullan?",Ne:"Bu ozellik genel marketten esya almaya yarar. Satin alma suresi biraz surebilir.",dd:"Pazar Aramas\u0131n\u0131 Etkinle\u015ftir:",Oe:"Dakika cinsinden Pazar Arama Aral\u0131\u011f\u0131:",Pe:"\u00d6nerilen 10 dakika.",$d:"Nesne Ayarlar\u0131:",Yd:"Nesne Ad\u0131 \u0130\u00e7erir",H:"Maksimum Fiyat",ae:"Nesne T\u00fcr\u00fc",Zd:"Nesne Nadirli\u011fi",Nc:"Ruh Ba\u011fl\u0131 Al\u0131ns\u0131n m\u0131?",
ce:"Al\u0131nacak Nesneler",be:"Herhangi biri maksimum fiyat\u0131 a\u015f\u0131yorsa \u00f6\u011feleri almay\u0131 deneyin.:",Lc:"Sat\u0131n Al\u0131nan Nesneler:",ii:"\u0130yile\u015ftirme Y\u00fczdesi",jk:"D\u00fckkandan Yiyecek Sat\u0131n Al\u0131ns\u0131n m\u0131?",kk:"Paketten \u0130yile\u015ftirme Kullan\u0131ls\u0131n m\u0131?",gk:"Cervisia Kullan\u0131ls\u0131n m\u0131?",ik:"Yumurta Kullan\u0131ls\u0131n m\u0131?",kl:"Son Kullan\u0131ld\u0131",location:"Konum",Strength:"G\u00fc\u00e7",Dexterity:"Beceri",
Agility:"\u00c7eviklik",Constitution:"Dayaniklilik",Charisma:"Karizma",Intelligence:"Zeka",Ug:"E\u011fitim Ayarlar\u0131",Vg:"E\u011fitim yapmak istedi\u011finiz nitelikleri se\u00e7in. Yeterli alt\u0131n\u0131z oldu\u011funda e\u011fitim yapacakt\u0131r.",nc:"Sonraki ad\u0131m",Pi:"Hay\u0131r",Qi:"Normal",ol:"Rakip",pl:"Rakip Seviyesi",pj:"G\u00f6revler",random:"Rastgele",vl:"Ayarlar",Gl:"Yak\u0131nda...",type:"G\u00f6rev t\u00fcrlerini etkinle\u015ftirmek i\u00e7in simgeleri t\u0131klay\u0131n.",
Nl:"Evet",D:"Arama",oc:"\u00d6\u011feleri ekle",ck:"Demircilik Kaynaklar\u0131n\u0131 Otomatik Olarak Sakla",Il:"G\u00f6nder",il:"Aral\u0131k : ",Xk:"Otomatik Teklif Etkinle\u015ftir",Yk:"Bir ittifak \u00fcyesi zaten teklif verdiyse teklif vermeyin",Kl:"\u00d6\u011fretici",bc:"Arena'da en d\u00fc\u015f\u00fck veya en y\u00fcksek seviyeli rakiple y\u00fczle\u015fmek isteyip istemedi\u011finizi yukar\u0131daki d\u00fc\u011fmelerden se\u00e7in. Daha fazla kullan\u0131c\u0131, botun h\u0131z\u0131n\u0131 yava\u015flatabilir.",
Rk:"Ba\u015flamak i\u00e7in bir \u00f6\u011feyi listeyle ekleyin (\u00f6r. `Lucius`). Ekledikten sonra, arama sonu\u00e7lar\u0131n\u0131 sol tarafta g\u00f6r\u00fcnt\u00fclemek i\u00e7in arama sonu\u00e7lar\u0131n\u0131 g\u00f6sterir. Ayn\u0131 zamanda otomatik m\u00fczayede ama\u00e7lar\u0131 i\u00e7in de arar. Otomatik teklifi etkinle\u015ftirirseniz, belirli aral\u0131klarla \u00f6\u011feyi arar ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: D\u00fckkanlarda benzersiz \u00f6\u011feleri aramak i\u00e7in, en az bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
$k:"Yarat\u0131k numaras\u0131n\u0131 yukar\u0131daki d\u00fc\u011fmelerden se\u00e7ebilirsiniz. Numara 1, en soldaki yarat\u0131\u011f\u0131 temsil eder. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",Fh:"Zindan\u0131n zorlu\u011funu yukar\u0131dakilerden se\u00e7in. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",ji:"\u0130yile\u015ftirme Ayarlar\u0131",Gh:"Ittifak Piyasas\u0131ndan al\u0131\u015fveri\u015f yaparak fazla alt\u0131n\u0131 depola -> Min. Alt\u0131n. 1. Envanterde bos yer birakmaya calisin.",
ll:"T\u00fcm\u00fcn\u00fc Ta\u015f\u0131",ml:"Se\u00e7ilenleri Ta\u015f\u0131",Uk:"Otomatik \u0130yile\u015ftirme",Vk:"Otomatik \u0130yile\u015ftirme Y\u00fczdesi",Ml:"Yakut",wf:"Genel Ayarlar",Cj:"Hepsini Sat",Dj:"Se\u00e7ilenleri Sat",ka:"Silahlar",ha:"Kalkanlar",Z:"G\u00f6\u011f\u00fcs Z\u0131rhlar\u0131",ca:"Kasklar",ba:"Eldivenler",ia:"Ayakkab\u0131lar",fa:"Y\u00fcz\u00fckler",Y:"Kolyeler",jh:"Kullan\u0131labilir",ih:"G\u00fc\u00e7lendirmeler",Nf:"Re\u00e7eteler",bf:"S\u00f6zle\u015fmeli Scrollar",
Pf:"Takviyeler",Jf:"G\u00f6rev Filtre \u0130gnore",If:"Almak istemedi\u011finiz g\u00f6revleri filtrelemek i\u00e7in anahtar kelimeleri girin",aa:"Anahtar Kelime Girin",I:"Ekle",Qf:"Kald\u0131r",Qc:"Temizle",Gf:"G\u00f6rev Filtre Kabul",Hf:"Almak istedi\u011finiz g\u00f6revleri se\u00e7mek i\u00e7in anahtar kelimeleri girin. Odule gore secmek isterseniz odulun icinde gecen bir kelimeyi girin.",Ha:"Zamanl\u0131 G\u00f6revleri Atla?",Hk:"G\u00f6revler",Cc:"Oto Kost\u00fcm",kh:"Kost\u00fcm Kullan?",
Hc:"Ana Sava\u015f",Zc:"Dungeon Sava\u015f ve Etkinlik",Dc:"Bot yaln\u0131zca ke\u015fif/zindan puanlar\u0131n\u0131z 0 ise Dis Pater Normal ve Medium giyecektir.",Pd:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",tc:"Boss Mevcut Oldu\u011funda Sald\u0131r?",rb:"5 ba\u015far\u0131s\u0131z sald\u0131r\u0131dan sonra Lig sald\u0131r\u0131s\u0131n\u0131 devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",Sd:"Kutsal Ya\u011flar",kf:"\u00dcr\u00fcn Ad\u0131",ea:"Min. Item Seviyesi",Ga:"Min. \u00dcr\u00fcn Kalitesi",
sc:"Zamanlay\u0131c\u0131y\u0131 Uygula/S\u0131f\u0131rla",Vd:"\u00d6nek/Soneki Yok Say",rh:"Evet",sf:"Hay\u0131r",Ya:"Ge\u00e7mi\u015fi Temizle",pg:"Yok Sayma Listesi",Kb:"\u00d6nek",Wb:"Sonek",Wf:"S\u00fcresi Dolan \u00dcr\u00fcnleri S\u0131f\u0131rla",qg:"Kondisyonlar disinda rastgele erit",rg:"Eritme Sekmesi",pb:"Ekstralar",xc:"M\u00fczayede",Se:"Pazar",Xb:"Zamanlar",Pg:"Eritme",Og:"Alt\u0131n Yoksa Eritme",Lg:"\u00dcr\u00fcn Yoksa Eritme",Ia:"Tamir",Dg:"Ittifak Pazar\u0131 Alt\u0131n Tutma",
zg:"M\u00fczayede Alt\u0131n Tutma",Sg:"E\u011fitim",Gg:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla",Qg:"Hammadde Depola",xg:"M\u00fczayede Kontrol",Ig:"Arama",v:"Etkinle\u015ftir",mf:"Min. Alt\u0131n",Sb:"Saat Se\u00e7in",mb:"Ittifaga Alt\u0131n Ba\u011f\u0131\u015fla",Uc:"Her 5 dakikada bir ba\u011f\u0131\u015f yapacakt\u0131r. Zamanlay\u0131c\u0131lar sekmesinden aral\u0131\u011f\u0131 de\u011fi\u015ftirebilirsiniz",Td:"Ne kadar ba\u011f\u0131\u015f yap\u0131lmal\u0131?",Vc:"Ne zaman ba\u011f\u0131\u015f yap\u0131lmal\u0131 >",
ee:"Daha az <",Tf:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla ve Di\u011fer Ayarlar\u0131",Vf:"S\u0131f\u0131rla in:",Ck:"Birden fazla \u00f6\u011feyi se\u00e7mek i\u00e7in Ctrl (Mac'de Cmd) tu\u015funu bas\u0131l\u0131 tutun",Wd:"Ayarlar\u0131 Kaydet / Yukle",Ed:"Ayarlar\u0131 Indir",Xd:"Ayarlar\u0131 Yukle",cf:"T\u00fcm Oyunculara Mesaj G\u00f6nder",df:"[Ultra Premium Anahtar\u0131 gerektirir, anahtar i\u00e7in Discord \u00fczerinden ileti\u015fime ge\u00e7in.]",ef:"G\u00f6nderilecek mesaj\u0131 girin",
Sc:"\u00d6zel scriptler i\u00e7in Discord \u00fczerinden bize ula\u015f\u0131n",gf:"G\u00f6nder",hf:"Oyuncular\u0131 G\u00f6ster",ff:"T\u00fcm\u00fcn\u00fc Se\u00e7",jf:"T\u00fcm Se\u00e7imleri Kald\u0131r",de:"Envanterinizin yeterli alan\u0131 oldu\u011fundan emin olun. Geri say\u0131m 2 dakikad\u0131r.",We:"Yiyecek Sat",Fb:"Yiyeceklere Ge\u00e7"},Kh={Ni:"Tipo de busca de ninho",Li:"N\u00e3o fazer nada",Mi:"Busca r\u00e1pida",Oi:"Busca detalhada",nj:"A\u00e7\u00e3o p\u00f3s expedi\u00e7\u00e3o",
mk:"Clique aqui se o reparo ficar travado",Ak:"Quando HP estiver baixo, use cura",yf:"Reparo Parcial",Ld:"Reparo Completo",xf:"Reparo Parcial ou Completo",bd:"Habilitar Limite",li:"Limite",mi:"Se voc\u00ea deseja limitar o n\u00famero de vezes que quer atacar o inimigo, habilite esta op\u00e7\u00e3o e defina o limite. O bot continuar\u00e1 atacando o resto dos inimigos ap\u00f3s terminar de atacar o monstro selecionado.",Xc:"N\u00e3o entre no submundo com a fantasia do submundo",Wc:"Se voc\u00ea n\u00e3o quiser entrar no submundo enquanto estiver usando a fantasia do submundo, ative esta op\u00e7\u00e3o",
fh:"Submundo",Xg:"Melhorias do Submundo",Zg:"Usar os poderes dos deuses ap\u00f3s entrar no submundo?",$g:"Selecione os deuses para usar seus poderes:",ah:"Usar Buff de Arma na arma?",bh:"Usar Buff de Armadura no seguinte equipamento:",xk:"O tempo de espera \u00e9 de 30 minutos. Se voc\u00ea n\u00e3o estiver com um traje, o bot redefinir\u00e1 o tempo de espera para 0.",Lk:"Selecionar Cores",Za:"Forja de Vulcano",cb:"Escudo Terrestre de Feronia",eb:"Poder Fluido de Netuno",fb:"Liberdade A\u00e9rea de Aelous",
gb:"N\u00e9voa Mortal de Plut\u00e3o",hb:"Sopro de Vida de Juno",ib:"Armadura de Escamas das Montanhas da Ira",jb:"Olhos de \u00c1guia",kb:"Vestimenta de Inverno de Saturno",$a:"Armadura de Touro de Bubona",ab:"Trajes de Ladr\u00e3o de Merc\u00fario",bb:"T\u00fanica de Luz de R\u00e1",Ve:"Pacotes",Qe:"Invent\u00e1rio",K:"Pre\u00e7o M\u00edn.",J:"Quantos",Eb:"Vender Itens",Db:"Procurar em",Re:"Cor do Material",Cb:"Cor do Item",Ye:"Armaz\u00e9m",Fa:"Mudar para Materiais",Gb:"Mudar para Itens",Xe:"Vender Materiais",
Ca:"Por favor, insira um nome de item v\u00e1lido, faixa de pre\u00e7o e quantidade.",Da:"Nenhum item adequado encontrado nos locais de busca selecionados.",Ea:"Todos os itens foram listados com sucesso!",Fk:"Todos os materiais foram listados com sucesso!",Te:"Se voc\u00ea quiser vender itens por um pre\u00e7o fixo, voc\u00ea pode inserir o mesmo valor para o pre\u00e7o m\u00ednimo e m\u00e1ximo.",Ue:"Este recurso ainda \u00e9 experimental, use com cautela. Se voc\u00ea n\u00e3o colocar um pre\u00e7o fixo, os itens ser\u00e3o listados aleatoriamente entre o pre\u00e7o m\u00ednimo e m\u00e1ximo que voc\u00ea inserir.",
tk:"Define o m\u00e1ximo de ouro que o bot gastar\u00e1 por ciclo.",Ua:"O bot come\u00e7ar\u00e1 a fazer lances em itens de comida, se habilitado. Voc\u00ea n\u00e3o precisa habilitar os interruptores de gladiador/mercen\u00e1rio.",vc:"O bot n\u00e3o far\u00e1 lances sobre os lances dos aliados.",wc:"Ignorar combina\u00e7\u00e3o de Prefixo/Sufixo ao procurar por um item no leil\u00e3o.",Kj:"Selecione os tipos de item que voc\u00ea deseja fundir.",Lj:"Selecione as cores que voc\u00ea deseja fundir.",
Mj:"Selecione o n\u00edvel dos itens que voc\u00ea deseja fundir.",Nj:"Selecione o martelo que voc\u00ea deseja usar.",Oj:"Note que o c\u00edrculo Verde e Vermelho ao lado da primeira caixa s\u00e3o para ativar/desativar a regra.",Pj:"Se voc\u00ea quiser fundir aleatoriamente quaisquer cores ou tipos, voc\u00ea pode ativar `Fundir aleatoriamente se nenhuma condi\u00e7\u00e3o for atendida? (\u00daltima op\u00e7\u00e3o habilitada no v\u00eddeo tutorial)",rj:"Reparar antes de fundir?",yd:"Selecionar Monstro",
md:"Usar Ampulheta/Rubi?",zk:"Usar Rubi?",pd:"Usar Mobiliza\u00e7\u00e3o?",od:"Usar Po\u00e7\u00e3o de Vida?",ld:"Percentual de Cura (%)",wd:"N\u00famero de Ataques",nd:"Intervalo de Ataque (em segundos)",jd:"Ataques Realizados",kd:"Ampulhetas Restantes",ud:"Nota: Usa po\u00e7\u00f5es de vida para curar, n\u00e3o comida.",vd:"Nota: Se os ataques pararem prematuramente, tente 'Resetar Ataques'.",zd:"Iniciar",xd:"Resetar",Ad:"Parar",Bd:"Configura\u00e7\u00f5es de Expedi\u00e7\u00e3o (Clique para minimizar)",
qd:"Monstro 1",rd:"Monstro 2",sd:"Monstro 3",td:"Monstro 4",Ik:"Reparar antes de fundir?",yh:"Esta op\u00e7\u00e3o usar\u00e1 cervisia quando seu premium expirar.",Ri:"Esta op\u00e7\u00e3o ativa e seleciona \u00f3leos das recompensas divinas. Pode usar \u00f3leos n\u00famero 1 e 3 no personagem, mas o n\u00famero 2 s\u00f3 ser\u00e1 pego para pacotes.",wh:"Esta op\u00e7\u00e3o usar\u00e1 buffs no hor\u00e1rio que voc\u00ea definir. Encontrar\u00e1 buffs nos pacotes e os aplicar\u00e1 ao personagem.",
ni:"Esta op\u00e7\u00e3o te levar\u00e1 ao submundo. N\u00e3o esque\u00e7a de habilitar o Login Autom\u00e1tico na aba Extras, caso contr\u00e1rio, voc\u00ea pode ser desconectado ao entrar no submundo [Bug do Jogo]",$b:"O bot normalmente escolhe de 3 a 6 tentativas aleat\u00f3rias para atacar na lista de arena. Se voc\u00ea habilitar esta op\u00e7\u00e3o, ele passar\u00e1 pela sua lista at\u00e9 que possa atacar algu\u00e9m. Isso pode levar algum tempo.",oj:"Esta op\u00e7\u00e3o \u00e9 apenas para licen\u00e7as premium. Simula o ataque antes de atacar um usu\u00e1rio para uma taxa de vit\u00f3ria de 75%.",
yc:"Voc\u00ea n\u00e3o precisa habilitar a togglede leil\u00e3o principal para habilitar esta op\u00e7\u00e3o.",fk:"Esta op\u00e7\u00e3o atualizar\u00e1 a p\u00e1gina a cada segundo quando o leil\u00e3o estiver no estado -Muito Curto- para dar lances constantemente e vencer o leil\u00e3o.",Ij:"Se nenhuma das condi\u00e7\u00f5es de fus\u00e3o for atendida, ele fundir\u00e1 aleatoriamente. Certifique-se de selecionar o tipo e a cor do item.",Jj:"Esta op\u00e7\u00e3o fundir\u00e1 apenas itens do invent\u00e1rio. Ignorar\u00e1 itens nos pacotes.",
Va:"Itens de Leil\u00e3o",af:"Itens de Mercen\u00e1rio",Ub:"Itens da Loja",hh:"Itens \u00danicos",Ej:"Definir fundo para preto [Aumenta o desempenho]",Fj:"Mover bot\u00f5es do GLDbot para o canto inferior esquerdo?",zh:"Atacar o Circo Sem Curar",dk:"Pegar ouro dos pacotes se necess\u00e1rio?",ek:"Ouro foi pego dos pacotes para treinamento",Jl:"Nenhum ouro foi encontrado nos pacotes para treinamento",ak:"Itens Reparados",Uj:"Ataques na Arena",Wj:"Ataques no Circo",pc:"Itens Reiniciados",Zj:"Ataques em Expedi\u00e7\u00f5es",
Yj:"Ataques em Masmorras",bk:"Ataques no Submundo",Vj:"Dinheiro Ganhado na Arena",Xj:"Dinheiro Ganhado no Circo",Hl:"Itens Fundidos",$j:"Ouro Reciclado",ei:"Batalha de Guilda",gi:"Configura\u00e7\u00f5es da Guilda",bl:"Atacar\u00e1 guildas aleatoriamente.",fi:"Nome da Guilda",xh:"Redefinir Estat\u00edsticas",di:"Atacar Guildas Aleatoriamente",nl:'GLDbot: Use os dados para atualizar a caixa misteriosa e encontrar itens valiosos antes de abri-los (Etc. Trajes). Clique em "Iniciar" para abrir ba\u00fas.',
kc:"Madeira",hc:"Cobre",ic:"Ferro",jc:"Couro",xi:"Fio de L\u00e3",pi:"Bolas de Algod\u00e3o",si:"Hemp",ri:"Tiras de Gaze",ui:"Fios de Linho",ti:"Remendo",wi:"Veludo",vi:"Fio de Seda",Ei:"Pelo",yi:"Lasca de Osso",Hi:"Escama",Bi:"Garra",Di:"Presas",Ci:"Escama de Drag\u00e3o",zi:"Corno de Touro",Gi:"Gl\u00e2ndula Venenosa",Ai:"Casaco de Pele de Cerberus",Fi:"Escama de Hydra",Ii:"Pena de Esfinge",Ji:"Pele de Typhon",ai:"Lapis Lazuli",Vh:"Ametista",Uh:"Ambar",Wh:"Agua-Marinha",bi:"Safira",Zh:"Granada",
Yh:"Esmeralda",Xh:"Diamante",$h:"Jasper",ci:"Sugilite",Ph:"Veneno de Escorpi\u00e3o",Sh:"Tintura de Resist\u00eancia",Lh:"Antidoto",Kh:"Adrenalina",Rh:"Tintura Esclarecedora",Oh:"Po\u00e7\u00e3o de Perce\u00e7\u00e3o",Mh:"Ess\u00eancia de Rea\u00e7\u00e3o",Nh:"Frasco de Carisma",Th:"\u00c0guas de Oblivion",Qh:"Ess\u00eancia de Alma",Aj:"Selo Aqu\u00e1tico",uj:"Runa Protetora",sj:"Marca da Terra",zj:"Totem de Cura",yj:"Talism\u00e3 do Poder",wj:"Pedra da Fortuna",tj:"Pedernal",xj:"Runa da Tempestade",
vj:"Runa das Sombras",Ui:"Cristal",Ti:"Bronze",Yi:"Obsidiana",aj:"Prata",bj:"Enxofre",Wi:"Mina de Ouro",$i:"Quartzo",Zi:"Platina",Si:"Almandin",Vi:"Cuprit",Xi:"Pedra do Inferno",th:"Atacar Aleatoriamente em Provinciarum?",uh:'Tamb\u00e9m desative a configura\u00e7\u00e3o "Classificar jogadores na arena por n\u00edvel" no crazy-addon.',Kf:"Aceitar apenas miss\u00f5es com base no tipo de deus.",Wa:"Auto Buff",Mc:"Usar apenas no inferno?",rf:"Nova Regra",pf:"Nome Cont\u00e9m",isUnderworldItem:"\u00c9 Item do Submundo",
Ud:"Ignorar Materiais",lk:"Usar Ora\u00e7\u00e3o?",nh:"Usar Sacrif\u00edcio?",hk:"Usar Roupas para Entrar no Submundo?",eh:"Miss\u00f5es do Submundo",dh:"Se habilitado, voc\u00ea precisa digitar nomes de itens do submundo. Se o bot encontrar esses itens no submundo, ele aceitar\u00e1 a miss\u00e3o.",Pk:"Item da Miss\u00e3o do Submundo",Zk:"Digite o nome do material",wk:"O bot adora dados! Eles ajudam a encontrar roupas nos ba\u00fas. Mas se n\u00e3o houver dados, o bot abre os ba\u00fas mesmo assim, na esperan\u00e7a de encontrar roupas legais (mas pode n\u00e3o encontrar nenhuma!)",
Hj:"Enviar os materiais derretidos para os pacotes?",ad:"Ativar Arena?",Cf:"Priorizar lista de arena?",Df:"Priorizar lista de circo?",Tc:"Desativar Menu de Log",Yf:"Recompensa Min. Valor em Ouro",Lf:"Miss\u00e3o Focada, se ativada, seguir\u00e1 o caminho mais curto para terminar a masmorra.",ug:"Jogar Dados Automaticamente?",vg:"Use jogar dados com cautela, ele continuar\u00e1 usando o primeiro dado at\u00e9 voc\u00ea desativar a op\u00e7\u00e3o.",cg:"Progresso da Pesquisa",Sf:"O tempo de espera para reparo por padr\u00e3o \u00e9 de 10 minutos.",
lf:"Condi\u00e7\u00e3o M\u00ednima",Rc:"Item atual na bancada [Limpar se o bot pausar inesperadamente]",oe:"Recursos da Forja armazenados com sucesso no horreum.",ke:"Verificando itens no mercado...",Ab:"Item movido para a bancada.",Ce:"Item reparado e equipado com sucesso.",De:"Item reparado com sucesso.",Dk:"Reparo falhou. A p\u00e1gina ser\u00e1 atualizada.",ze:"Pegando materiais...",Me:"Aguardando reparo...",Be:"Reparo iniciado para .",Ba:"Reparo: Movendo o item do invent\u00e1rio para a bolsa",
Ae:"Reparo: Movendo o item da bancada para o pacote.",sb:"N\u00e3o foi poss\u00edvel encontrar materiais suficientes. Desativando o slot de reparo ",we:"Procurando itens para comprar para esconder ouro no Leil\u00e3o...",he:"Verificando itens expirados nos pacotes...",ie:"Item redefinido com sucesso.",je:"Sem Espa\u00e7o Vazio ou Ouro para Redefinir.",pe:"Certifique-se de que voc\u00ea tem direitos de venda no mercado da guilda!",ub:"Ouro insuficiente e/ou nenhum item para comprar. Aguardando 30s para atualizar.",
wb:"Loja foi atualizada.",xb:"Erro durante a cura.",se:"Sem Rubi ou Pano, desativando as op\u00e7\u00f5es.",te:"Nenhum item de cura encontrado nos pacotes.",yb:"Nenhum item adequado encontrado",ue:"Alimentos foram pegos. Finalizando o processo.",ve:"Pelo menos um alimento foi pego. Finalizando processo.",zb:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",qe:"Pegando comida dos pacotes.",re:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",vb:"Sem mais itens de cura. Aguardando 30 segundos.",
tb:"HP Recuperado.",Aa:"Nada para fazer ent\u00e3o vou rezar!",Ie:"Vou atualizar em 60 segundos para verificar minha sa\u00fade e villa medici.",Je:"Aguardando Villa Medici, atualizando em 60 segundos.",Ke:"Saiu do submundo.",Le:"Vou atualizar em 60 segundos para verificar minha sa\u00fade.",xe:"Verificando \u00f3leos de deus...",ye:"\u00d3leos de deus foram pegos.",ya:"Atacou com sucesso o jogador na ARENA: ",za:"Atacou com sucesso o jogador no CIRCO: ",fe:"Verificando leil\u00e3o! Por favor, aguarde...",
ge:"Dando lances em itens. Por favor, aguarde...",Ee:"Item Derretido Automaticamente: ",Fe:"Derretendo Item: ",Ge:"Ouro insuficiente para derreter. Ouro Necess\u00e1rio: ",He:"DERRETER: Procurando itens para derreter...",Ek:"Procurando itens para derreter...",le:"Verificando disponibilidade de traje...",ne:"Doado : ",me:"Jogando dados...",Hd:"Underworld Farm [Manual, Beta]",Id:"Esteja ciente: ative este recurso ap\u00f3s desbloquear a criatura que deseja atacar, ela n\u00e3o atacar\u00e1 automaticamente para desbloquear o monstro.",
Gd:"Farm Location",Fd:"Farm Enemy",Fc:"Login Autom\u00e1tico",Gc:"Voc\u00ea precisa permitir pop-ups da tela do lobby do GameForge. Veja a documenta\u00e7\u00e3o sobre como fazer isso.",zf:"Pausar Bot",Af:"Pausar Bot em (Minutos)",Dd:"Data de Expira\u00e7\u00e3o",uf:"Comprar apenas comida?",vf:"Se voc\u00ea habilitar isso, o bot ignorar\u00e1 suas sele\u00e7\u00f5es e comprar\u00e1 comida automaticamente sem inserir nada.",Ib:"M\u00e1ximo de ouro total para gastar",Hb:"M\u00e1ximo de ouro por comida para gastar",
tf:"O bot verificar\u00e1 \u00f3leos a cada 60 minutos",Ng:"Define um temporizador para verificar os tempos de fus\u00e3o.",Kg:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver ouro.",Mg:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver o item dispon\u00edvel.",Fg:"Define um temporizador para reparar e verificar seus itens.",Eg:"Define um temporizador para verificar o ouro mantido no mercado da guilda.",Ag:"Define um temporizador para a op\u00e7\u00e3o de reten\u00e7\u00e3o de ouro em leil\u00e3o.",
wg:"Define um temporizador para verificar a lista de PvP na arena para atacar.",Bg:"Define um temporizador para verificar a lista de PvP no circo para atacar.",Tg:"Define um temporizador para treinar suas estat\u00edsticas.",Hg:"Define um temporizador para redefinir itens expirados.",Rg:"Define um temporizador para armazenar materiais de forja no horreum.",yg:"Define um temporizador para verificar o leil\u00e3o de gladiadores e mercen\u00e1rios.",Jg:"Define um temporizador para buscar itens em leil\u00e3o e loja.",
Cg:"Define o temporizador para enviar doa\u00e7\u00f5es \u00e0 guilda.",Md:"Ouro Movido",Yc:"N\u00e3o venda itens da lista de fundi\u00e7\u00e3o e leil\u00e3oo",dg:"Automa\u00e7\u00e3o da Loja",fg:"Configura\u00e7\u00f5es de Busca de Item",eg:"Use esta ferramenta para buscar itens. Basta adicionar os itens \u00e0 lista, especificar a quantidade de pano e iniciar a busca.",gg:"Panos a Usar:",hg:"Quantos panos usar?",ja:"Full Digite o Nome do Item",Tb:"Digite o N\u00edvel do Item",jg:"Qualidade do Item",
ig:"Nome do Item Aqui",kg:"Iniciar Busca",lg:"Pular e Continuar",mg:"Parar Busca",Jd:"Comprar o mais barato ou o mais caro?",nf:"Mais Caro",Oc:"Mais Barato",ga:"Selecionar uma op\u00e7\u00e3o",cd:"Destacar itens do submundo",Kd:"Foco na miss\u00e3o?",Ll:"Usar Ruby se n\u00e3o houver pano?",Xa:"Evite atacar as mesmas pessoas para n\u00e3o ser reportado. Ser reportado aumenta as chances de ser banido.",Al:"Queimar verde?",Ff:"N\u00e3o aceitar miss\u00f5es aleat\u00f3rias se algum filtro for inserido?",
lc:"Qualidade m\u00e1xima do material a ser usado",Hh:"Ativar a busca mercen\u00e1ria",jl:"Clique em `Vender Todos Selecionados` para vender todos os itens. Certifique-se de ter um espa\u00e7o vazio de 2x3 em sua primeira (1) bolsa. Para coletar ouro em massa, filtre ouro e use `Selecionar Todos ou Selecionar`",Tj:"\ud83d\udd25 : Adiciona item \u00e0 lista de fundi\u00e7\u00e3o.",vh:"\ud83d\udd28 : Adiciona item \u00e0 lista de leil\u00e3o.",qj:"Atualize a loja com pano quando estiver cheia (Voc\u00ea precisa vender novamente depois)",
ej:"P\u00e1gina:",lj:"Parar",jj:"Vender Esta P\u00e1gina",gj:"Selecionar Selecionados",fj:"Selecionar Tudo",mj:"Configura\u00e7\u00f5es de Empacotamento Autom\u00e1tico",kj:"Enviar Recursos",hj:"Vender Todos Selecionados",ra:"Tipo de Item",W:"Armas",S:"Escudos",M:"Armaduras",P:"Capacetes",O:"Luvas",N:"Botas",V:"An\u00e9is",U:"Amuletos",pa:"Utiliz\u00e1veis (Alimentos)",wa:"Melhorias",cj:"Potencializadores",ta:"Receitas",sa:"Mercen\u00e1rios",va:"Ferramentas de Forja",ua:"Pergaminhos",Oa:"Refor\u00e7os",
Ma:"Itens de Evento",Na:"Materiais de Forja",dj:"Ouro",T:"Todos",ql:"Qualidade",X:"Branco",B:"Verde",A:"Azul",C:"Roxo",G:"Laranja",R:"Vermelho",ij:"Op\u00e7\u00f5es de Venda",Gj:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo?",hi:"Quantos alimentos comprar/pegar?",Ch:"Normal",Bh:"Intermedi\u00e1rio",Ah:"Dif\u00edcil",Ja:"Padr\u00e3o",tl:"Reparar Corre\u00e7\u00e3o de Travamento",Bk:"Desative a entrada no Inferno se voc\u00ea quiser desabilitar a Dungeon/Circo/Arena. Se voc\u00ea entrar no Inferno manualmente, ser\u00e1 necess\u00e1rio ativar o Modo Inferno.",
Pc:"Escolher traje do submundo",qh:"Vestir traje do submundo quando dispon\u00edvel?",Wg:"Define quantas vezes quer treinar as estat\u00edsticas e suas prioridades. O bot n\u00e3o treinar\u00e1 a menos que defina uma prioridade. Se n\u00e3o houver mais estat\u00edsticas ele continuar\u00e1 com as estat\u00edsticas Defenidas.",Wk:"Aventura",yl:"Derreter",El:"Defini\u00e7\u00f5es de Derreter",Qj:"Itens Derretidos",Fl:"Adicione um Prefixo ou Sufixo, uma vez encontrado nos pacotes Ser\u00e1 Derretido automaticamente.:",
Dl:"Derreter Item:",cc:"Clique no item que voc\u00ea deseja consertar. Isto utilizar\u00e1 apenas materiais Padr\u00e3o, Verde e Azul. Voc\u00ea precisa ter pelo menos 10.000 ouro para iniciar o reparo. Abra espa\u00e7o 3x3 em sua PRIMEIRA Bolsa do invent\u00e1rio. Caso contr\u00e1rio, ele poder\u00e1 ficar preso! O bot iniciar\u00e1 o reparo assim que o item tiver durabilidade de %0.",Qk:"Aplicar apenas no Mercenario.",Tk:"O leil\u00e3o s\u00f3 dar\u00e1  o lance quando o mercado estiver no Fim..",
Sk:"Certifique-se de que a SEGUNDA PAGINA DO INVENT\u00c1RIO est\u00e1 vazia e tem 10K de ouro. O bot encontrar\u00e1 e colocar\u00e1 o item na segunda pagina e na pr\u00f3xima vez, a p\u00e1gina, atualiza-se Derrentendo o item. A fundi\u00e7\u00e3o acontecer\u00e1 novamente a cada 5-10 minutos. ",ki:"Cura & Buffs",ul:"Sem ouro suficiente para fundir. Ouro necess\u00e1rio!:",xl:"Skipping bid: Membro da galian\u00e7a j\u00e1 deu lance no item ",wl:"Skipping bid: J\u00e1 licitei o item ",advanced:"Avan\u00e7ado",
arena:"Arena",na:"Ataque autom\u00e1tico",ac:"Evitar Atacar",la:"Adicionar Jogador",ma:"Adicionar Nome do Jogador (Same Server)",dl:"Parar o Bot se ficar sem comida?",circusTurma:"Circus Turma",Dh:"Dificuldade",dungeon:"Masmorra",Eh:"Configura\u00e7\u00e1o da Masmorra",eventExpedition:"Expedi\u00e7\u00e3o de evento",expedition:"Expedi\u00e7\u00f5es",Ih:"Configura\u00e7\u00e1o de Expedi\u00e7\u00f5es",Bj:"Selecionar Monstro",gl:"Maior",el:"Coloque as curas na primeira p\u00e1gina do invent\u00e1rio",
fc:"No",sg:"Guardar Ouro",tg:"Guardar ouro no Leil\u00e3o?",Sb:"Selecionar Horas",ag:"Utilizar Roupas para Renovar Iventario?",Kk:"Selecione itens para serem redefinidos",Uf:"Redefinir itens expirados\t",Ob:"Nota: Ao ativar esta op\u00e7\u00e3o, o bot vender\u00e1 os  itens expirados nos Pacotes para o Mercado da Guilda e cancelar\u00e1 para redefinir o tempo de expira\u00e7\u00e3o. Guilda \u00e9 necess\u00e1ria. Certifique-se que tem espa\u00e7o 3x3 vazio no iventario. Nota: Tamb\u00e9m ir\u00e1 coletar as Moedas de Ouro se elas estiverem prestes a expirar!!!",
Bf:"Parar o Bot Aleatoriamente para trabalhar como [Fase de Teste]:",da:"Ficar com o Ouro: Bot vai guardar esse ouro na bolsa:",Ze:"maximo de Ouro: O bot gastar\u00e1 o ouro quando for Superior a",Zf:"Ofertas ser\u00e3o aceitas por itens desnecess\u00e1rios",qc:"Adicionar atraso aleat\u00f3rio",rc:"Podes adicionar um atraso para o bot aqui.",Nb:"Reparar",zl:"Derreter apenas Azul?",Cl:"Derreter apenas Roxo?",Bl:"Derreter apenas Laranja?",Rj:"Derreter apenas itens do inventario?",Sj:"Isto ir\u00e1 ignorar a cor e os itens da lista. A pagina 1 est\u00e1 reservada a repara\u00e7\u00e3o..",
og:"Derreter",zc:"Pesquisa autom\u00e1tica",qf:"Leil\u00e3o Autom\u00e1tico",Ac:"O uso excessivo do Leil\u00e3o pode resultar em banimento. Esse recurso tamb\u00e9m pode desacelerar o bot, pois ele verifica os leil\u00f5es a cada atualiza\u00e7\u00e3o. As licita\u00e7\u00f5es s\u00e3o feitas a cada 5 minutos, a menos que o leil\u00e3o esteja no estado \u201cmuito curto\u201d. Observe que, se voc\u00ea colocar apenas um item na se\u00e7\u00e3o PREFIX, o bot tentar\u00e1 filtrar pelo nome dos itens para licitar mais rapidamente. Embora voc\u00ea precise desativar a licita\u00e7\u00e3o de alimentos para isso.",
$f:"Pesquisar no leil\u00e3o dos gladiadores",bg:"Pesquisar no leil\u00e3o dos mercen\u00e1rios",Ic:"Licitar Comida?",$e:"Lance m\u00e1ximo",Jc:"Licitar se o Tempo for inferior a",Kc:"Itens licitados",rk:"Linguagem do Leil\u00e3o",sk:"De acordo com a atualiza\u00e7\u00e3o 2.5.6, defina o idioma novamente.",uc:"Poder\u00e1 adicionar itens para procurar no mercado e no leil\u00e3o. Tamb\u00e9m mostrar\u00e1 itens roxos no mercado assim que voc\u00ea adicionar um item \u00e0 lista.",pk:"Utilize o leil\u00e3o com cuidado!",
qk:"O lance autom\u00e1tico faz muitas solicita\u00e7\u00f5es ao servidor, causando erro de p\u00e1gina em branco e pode causar banimento se for utilizado com frequ\u00eancia!!",Rf:"Renovar pontos de evento com Rubis?",ed:"Ativar \u00f3leo autom\u00e1tico",uk:"Obter os \u00f3leos sagrados automaticamente",Gk:"Velocidade de verifica\u00e7\u00e3o das miss\u00f5es",Ta:"Atacar membros da alian\u00e7a?",Ra:'Adicionar Jogador automaticamente \u00e0 lista de "Ataque" quando X OURO for roubado:',Sa:'Adicione Jogadores automaticamente \u00e0 lista "Evitar Ataque" quando perder:',
Rb:"Placar De Ataques",Yb:"Muito Longo",Bb:"Longo",Jb:"M\u00e9dio",Vb:"Curto",Zb:"Bastante Curto",ob:"Aceitar Ataques ao Placar:",Pb:"Selecionar Posi\u00e7\u00e3o do ataque",Qb:"O bot ira atacar aleatoriamente jogadores no placar.",qb:"Ataque da Liga",nb:"Ativar ataque da liga:",Lb:"Ataque aleat\u00f3rio",Mb:"Atacar do Menor para o maior",nk:"Bot N\u00e3o atacara menbros da alian\u00e7a.",Cd:"Local da Expedi\u00e7\u00e3o:",Bc:"Coletar Bonus automaticamente:",ng:"Ignorar Chefe",$c:"Local da Masmorra:",
Xf:"Recome\u00e7ar se perder?",Qd:"Defeni\u00e7\u00f5es do Inferno",Rd:" A Personagem entrar\u00e1 no submundo apenas quando o HP for> 90%. Por favor, defina as configura\u00e7\u00f5es de porcentagem de cura na Aba de cura e certifique-se de que a Aba de cura est\u00e1 ativada. Se ao entrar no submundo fizer logout, v\u00e1 para o lobby e ative a caixa de sele\u00e7\u00e3o de login autom\u00e1tico.",Od:"Dificuldade Do inferno:",Ec:"Entrar automaticamente no inferno / Inferno Mode",lh:"Utilizar Mobiliza\u00e7\u00e3o se pontos = 0",
ph:"Usar Rubies?",hd:"Deixar Inferno se nao tiver pontos?",Yg:"O bot tentar\u00e1 usar a Villa Medici primeiro, se voc\u00ea n\u00e3o tiver, ele usar\u00e1 a po\u00e7\u00e3o de cura. N\u00e3o se esque\u00e7a de ativar o bot\u00e3o de Cura!.",gh:"Entrar automaticamente no Inferno ira desabilitar masmorras/arena/Circus.",Ok:"Defeni\u00e7oes de cura no Inferno",oh:"Usar Villa Medici?",mh:"Usar Po\u00e7\u00e3o de Vida?",Ne:"INFO: O bot ir\u00e1 procurar itens no mercado a cada minuto selecionado, o que pode parar o ataque durante a busca.",
dd:"Ativar pesquisa de mercado:",Oe:"Intervalo de pesquisa no mercado:",Pe:"Sugest\u00e3o 10 minutos.",$d:"Defini\u00e7\u00f5es de itens:",Yd:"Nome do item inclui",H:"Pre\u00e7o Maximo",ae:"Estilo do Item",Zd:"Raridade do Item",Nc:"Comprar Soulbound?",ce:"Itens para comprar",be:"Tentar comprar itens com pacotes se algum deles corresponde ao pre\u00e7o m\u00e1ximo Defenido.:",Lc:"Itens Comprados:",ii:"Percentagem de Cura",jk:"Comprar comida da Loja?",kk:"Usar cura dos pacotes?",gk:"Usar Cervisia?",
ik:"Usar Ovos?",kl:"Usado por \u00faltimo",location:"Localiza\u00e7\u00e3o",Strength:"For\u00e7a",Dexterity:"Destreza",Agility:"Agilidade",Constitution:"Constitui\u00e7\u00e3o",Charisma:"Carisma",Intelligence:"Inteligencia",Ug:"Defini\u00e7\u00f5es de Treino",Vg:"Selecione os atributos que deseja treinar. ir\u00e1 treinar assim que houver ouro suficiente.",nc:"Proxima A\u00e7\u00e3o",Pi:"N\u00e3o",Qi:"Normal",ol:"Oponente",pl:"Nivel do Oponente",pj:"Miss\u00f5es",random:"aleat\u00f3rio",vl:"Defini\u00e7\u00f5es",
Gl:"Brevemente...",type:"Clique nos \u00edcones para ativar os tipos de miss\u00f5es. Selecione os 3 primeiros se quiser se concentrar em Circus & Arena",Nl:"Sim",D:"Procura",oc:"Adicionar item [NOME COMPLETO]",ck:"Guardar recursos da Forja automaticamente",Il:"Enviar",il:"Intervalo : ",Xk:"Ativar lance autom\u00e1tico",Yk:"Cobrir aliados",Kl:"Tutorial",bc:"MMais jogadores ir\u00e3o por o bot mais lento.",Rk:"Comece adicionando o nome completo dos itens \u00e0 lista. Uma vez adicionado, a ferramenta exibir\u00e1 os resultados da pesquisa \u00e0 esquerda. Isso tamb\u00e9m auxilia nas pesquisas de leil\u00e3o autom\u00e1tico. Com o lance autom\u00e1tico ativado, a ferramenta far\u00e1 pesquisas peri\u00f3dicas com base no intervalo definido. Se o item for encontrado e voc\u00ea tiver fundos suficientes, ele far\u00e1 um lance automaticamente. Nota: Para pesquisar itens exclusivos em lojas, voc\u00ea deve adicionar pelo menos um item \u00e0 lista de pesquisa...",
$k:"O n\u00famero da criatura pode ser escolhido nos bot\u00f5es acima. O n\u00famero 1 representa a criatura \u00e0 esquerda. Certifique-se de selecionar o local correto, caso contr\u00e1rio o bot poder\u00e1 fazer uma pausa.",Fh:"Escolha a dificuldade da masmorra nas op\u00e7\u00f5es acima. Certifique-se de selecionar o local correto, caso contr\u00e1rio, o bot poder\u00e1 fazer uma pausa.",ji:"Defini\u00e7\u00f5es de cura",Gh:"Armazene o excesso de ouro na Guilda comprando itens do mercado da Guilda. -> Min. Gold",
ll:"Mover tudo",ml:"Mover o Selecionado",Uk:"Curar autom\u00e1ticamente",Vk:"Percentagem da cura",Ml:"Rubi",wf:"Defini\u00e7\u00f5es Gerais",Cj:"Vender tudo",Dj:"Vender Selecionados",ka:"Armas",ha:"Escudos",Z:"Armaduras",ca:"Capacetes",ba:"Luvas",ia:"Sapatos",fa:"Aneis",Y:"Amuletos",jh:"Usaveis",ih:"Atualiza\u00e7\u00f5es",Nf:"Receitas",bf:"Mercen\u00e1rios",Pf:"Refor\u00e7os",fd:"Entrar no Submundo se HP >",Mf:"Velocidade de Verifica\u00e7\u00e3o de Miss\u00e3o",Ef:'O padr\u00e3o \u00e9 "3x". Se o bot causar problemas com miss\u00f5es, altere a velocidade da miss\u00e3o de acordo com a velocidade do seu servidor.',
Nd:"Saco de Cura",gd:'Se voc\u00ea est\u00e1 renovando pontos manualmente, voc\u00ea precisa clicar no bot\u00e3o acima "Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!',yk:"Voc\u00ea deve ativar pelo menos uma das seguintes op\u00e7\u00f5es: expedi\u00e7\u00e3o, masmorra, arena ou circo para iniciar a Expedi\u00e7\u00e3o de Evento.",Of:"Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!",lb:"Não cobrir aliados?",Mk:"Deixe todas as configura\u00e7\u00f5es desativadas se desejar fundir usando pacotes que cont\u00eam os itens da lista. No entanto, voc\u00ea ainda pode escolher cores.",
vk:"Personagem(Desligado) / Mercen\u00e1rio(Ligado)",Jk:"Reparar Ambos?",Nk:"Cron\u00f4metros",Timers:"Insira o n\u00famero de minutos para cada cron\u00f4metro abaixo ou deixe-o padr\u00e3o.",Jf:"Ignorar Filtro de Miss\u00e3o",If:"Digite palavras-chave para filtrar miss\u00f5es que voc\u00ea n\u00e3o deseja aceitar",aa:"Inserir Palavra-chave",I:"Adicionar",Qf:"Remover",Qc:"Limpar",Gf:"Aceitar Filtro de Miss\u00e3o",Hf:"Digite palavras-chave para escolher quais miss\u00f5es aceitar. Usar isso ignorar\u00e1 os tipos de miss\u00e3o",
Ha:"Pular Miss\u00f5es de Tempo?",Hk:"Miss\u00f5es",Cc:"Auto Traje",kh:"Usar Traje?",Hc:"Batalha B\u00e1sica",Zc:"Batalha em Masmorra",Dc:"O bot s\u00f3 usar\u00e1 Dis Pater Normal e M\u00e9dio se seus pontos de expedi\u00e7\u00e3o/masmorra forem 0.",Pd:"Configura\u00e7\u00f5es de Cura no Inferno",tc:"Atacar Chefe Quando Dispon\u00edvel?",rb:"O ataque \u00e0 Liga ser\u00e1 desativado ap\u00f3s 5 ataques malsucedidos.",Sd:"\u00d3leos Sagrados",kf:"Nome do Item",ea:"N\u00edvel M\u00edn. do Item",Ga:"Qualidade M\u00edn. do Item",
sc:"Aplicar/Reiniciar Temporizador",Vd:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo",rh:"Sim",sf:"N\u00e3o",Pa:"Adicionar Prefixo",Qa:"Adicionar Sufixo",Ya:"Limpar Hist\u00f3rico",pg:"Lista de Ignora\u00e7\u00e3o de Fundi\u00e7\u00e3o",Kb:"Prefixo",Wb:"Sufixo",Wf:"Redefinir Itens Expirados",qg:"Fundir Aleatoriamente de Pacotes?",rg:"Guia de Fundi\u00e7\u00e3o",pb:"Extras",xc:"Leil\u00e3o",Se:"Mercado",Xb:"Temporizadores",Pg:"Fundi\u00e7\u00e3o",Og:"Fundi\u00e7\u00e3o se n\u00e3o houver ouro suficiente",
Lg:"Fundir se n\u00e3o houver item",Ia:"Reparo",Dg:"Manter Ouro no Mercado da Guilda",zg:"Manter Ouro no Leil\u00e3o",Sg:"Treinamento",Gg:"Redefinir Expirados",Qg:"Loja de Forja",xg:"Verifica\u00e7\u00e3o de Leil\u00e3o",Ig:"Pesquisa",v:"Habilitar",mf:"Ouro M\u00ednimo",mb:"Doar Ouro para a Guilda",Uc:"Isso doar\u00e1 a cada 5 minutos. Voc\u00ea pode alterar o intervalo na guia de temporizadores",Td:"Quanto deseja doar?",Vc:"Doar quando tiver mais que >",ee:"Menos que <",Tf:"Redefinir Expirados e Outras Configura\u00e7\u00f5es",
Vf:"Redefinir em:",Ck:"Mantenha Ctrl (Cmd no Mac) pressionado para selecionar v\u00e1rios itens",Wd:"Importar/Exportar Configura\u00e7\u00f5es",Ed:"Exportar Configura\u00e7\u00f5es",Xd:"Importar Configura\u00e7\u00f5es",cf:"Mensagem para Todos os Jogadores",df:"[Requer Chave Ultra Premium, mensagem no Discord para obter a chave.]",ef:"Digite a mensagem a ser enviada",Sc:"Para scripts personalizados, entre em contato conosco no Discord",gf:"Enviar",hf:"Mostrar Jogadores",ff:"Selecionar Todos",jf:"Desmarcar Todos",
de:"Certifique-se de que seu invent\u00e1rio tenha espa\u00e7o suficiente. O tempo de recarga \u00e9 de 2 minutos.",We:"Vender Comida",Fb:"Mudar para Comida"},Fh={Ni:"Typ wyszukiwania gniazda",Li:"Nic nie r\u00f3b",Mi:"Szybkie wyszukiwanie",Oi:"Dok\u0142adne wyszukiwanie",nj:"After expedition points are consumed, travel to Germania to consume Dungeon points",mk:"Kliknij tutaj, je\u015bli naprawa si\u0119 zacina",Ak:"Gdy HP spadnie poni\u017cej, u\u017cyj leczenia",yf:"Cz\u0119\u015bciowa Naprawa",
Ld:"Pe\u0142na Naprawa",xf:"Cz\u0119\u015bciowa lub Pe\u0142na Naprawa",bd:"W\u0142\u0105cz Limit",li:"Limit",mi:"Je\u015bli chcesz ograniczy\u0107 liczb\u0119 atak\u00f3w na przeciwnika, w\u0142\u0105cz t\u0119 opcj\u0119 i ustaw limit. Bot b\u0119dzie kontynuowa\u0142 atakowanie reszty przeciwnik\u00f3w po zako\u0144czeniu atak\u00f3w na wybranego potwora.",Xc:"Nie wchod\u017a do podziemia w kostiumie podziemia",Wc:"Je\u015bli nie chcesz wchodzi\u0107 do podziemia, maj\u0105c na sobie kostium podziemia, w\u0142\u0105cz t\u0119 opcj\u0119",
fh:"Podziemia",Xg:"Wzmocnienia Podziemi",Zg:"U\u017cy\u0107 mocy bog\u00f3w po wej\u015bciu do podziemi?",$g:"Wybierz bog\u00f3w, kt\u00f3rych moce chcesz wykorzysta\u0107:",ah:"U\u017cy\u0107 Wzmocnienia Broni na broni?",bh:"U\u017cy\u0107 Wzmocnienia Zbroi na nast\u0119puj\u0105cym ekwipunku?",xk:"Czas odnowienia wynosi 30 minut. Je\u015bli nie masz kostiumu, bot zresetuje czas odnowienia do 0.",Lk:"Wybierz Kolory",Za:"Kowad\u0142o Wulkana",cb:"Ziemna Tarcza Feronii",eb:"P\u0142ynna Moc Neptuna",
fb:"Powietrzna Wolno\u015b\u0107 Aelousa",gb:"Zab\u00f3jcza Mg\u0142a Plutona",hb:"Oddech \u017bycia Junony",ib:"Pancerz \u0141usek G\u00f3r Gniewu",jb:"Orle Oczy",kb:"Zimowy Str\u00f3j Saturna",$a:"Bycza Zbroja Bubony",ab:"Szaty Z\u0142odzieja Merceriusa",bb:"Szata \u015awiat\u0142a Ra",Ve:"Paczki",Qe:"Inwentarz",K:"Min. Cena",J:"Ile",Eb:"Sprzedaj Przedmioty",Db:"Szukaj w",Re:"Kolor Materia\u0142u",Cb:"Kolor Przedmiotu",Ye:"Magazyn",Fa:"Prze\u0142\u0105cz na Materia\u0142y",Gb:"Prze\u0142\u0105cz na Przedmioty",
Xe:"Sprzedaj Materia\u0142y",Ca:"Prosz\u0119 wprowadzi\u0107 poprawn\u0105 nazw\u0119 przedmiotu, zakres cen oraz ilo\u015b\u0107.",Da:"Nie znaleziono odpowiednich przedmiot\u00f3w w wybranych miejscach wyszukiwania.",Ea:"Wszystkie przedmioty zosta\u0142y pomy\u015blnie wystawione!",Fk:"Wszystkie materia\u0142y zosta\u0142y pomy\u015blnie wystawione!",Te:"Je\u015bli chcesz sprzeda\u0107 przedmioty za sta\u0142\u0105 cen\u0119, mo\u017cesz wpisa\u0107 t\u0119 sam\u0105 warto\u015b\u0107 dla minimalnej i maksymalnej ceny.",
Ue:"Ta funkcja jest nadal eksperymentalna, u\u017cywaj ostro\u017cnie. Je\u015bli nie ustawisz sta\u0142ej ceny, przedmioty b\u0119d\u0105 wy\u015bwietlane losowo mi\u0119dzy minimaln\u0105 a maksymaln\u0105 cen\u0105, kt\u00f3r\u0105 wpiszesz.",tk:"Ustawia maksymaln\u0105 ilo\u015b\u0107 z\u0142ota, kt\u00f3r\u0105 bot wyda w jednym cyklu.",Ua:"Bot zacznie licytowa\u0107 wszelkie przedmioty \u017cywno\u015bciowe, je\u015bli opcja jest w\u0142\u0105czona. Nie musisz w\u0142\u0105cza\u0107 prze\u0142\u0105cznik\u00f3w gladiatora/najemnika.",
vc:"Bot nie b\u0119dzie licytowa\u0142 ofert sojusznik\u00f3w.",wc:"Ignoruj kombinacj\u0119 Prefixu/Sufiksu podczas szukania przedmiotu na aukcji.",Kj:"Wybierz typy przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Lj:"Wybierz kolory, kt\u00f3re chcesz przetopi\u0107.",Mj:"Wybierz poziom przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Nj:"Wybierz m\u0142ot, kt\u00f3rego chcesz u\u017cy\u0107.",Oj:"Zwr\u00f3\u0107 uwag\u0119, \u017ce zielone i czerwone k\u00f3\u0142ko obok pierwszego pola s\u0142u\u017cy do w\u0142\u0105czania/wy\u0142\u0105czania regu\u0142y.",
Pj:"Je\u015bli chcesz przetapia\u0107 losowo jakiekolwiek kolory lub typy, mo\u017cesz w\u0142\u0105czy\u0107 `Czy przetapia\u0107 losowo, je\u015bli \u017cadne warunki nie s\u0105 spe\u0142nione? (Ostatnia w\u0142\u0105czona opcja w filmie instrukta\u017cowym)",rj:"Napraw przed przetopieniem",yd:"Wybierz Potwora",md:"U\u017cy\u0107 Klepsydry/Rubinu?",zk:"U\u017cy\u0107 Rubinu?",pd:"U\u017cy\u0107 Mobilizacji?",od:"U\u017cy\u0107 Mikstury \u017bycia?",ld:"Procent Leczenia (%)",wd:"Liczba Atak\u00f3w",
nd:"Interwa\u0142 Ataku (w sekundach)",jd:"Wykonane Ataki",kd:"Pozosta\u0142e Klepsydry",ud:"Uwaga: U\u017cywa mikstur \u017cycia do leczenia, nie jedzenia.",vd:"Uwaga: Je\u015bli ataki zatrzymaj\u0105 si\u0119 przedwcze\u015bnie, spr\u00f3buj 'Zresetuj Ataki'.",zd:"Rozpocznij",xd:"Resetuj",Ad:"Zatrzymaj",Bd:"Ustawienia Ekspedycji (Kliknij, aby zminimalizowa\u0107)",qd:"Potw\u00f3r 1",rd:"Potw\u00f3r 2",sd:"Potw\u00f3r 3",td:"Potw\u00f3r 4",Ik:"Napraw przed przetopieniem",yh:"Ta opcja u\u017cyje cervisia, gdy twoja subskrypcja premium wyga\u015bnie.",
Ri:"Ta opcja w\u0142\u0105cza i wybiera oleje z nagr\u00f3d boskich. Mo\u017ce u\u017cywa\u0107 olej\u00f3w numer 1 i 3 na postaci, ale numer 2 b\u0119dzie tylko zbierany do paczek.",wh:"Ta opcja u\u017cyje buff\u00f3w o ustawionym przez ciebie czasie. Znajdzie buffy w paczkach i zastosuje je na postaci.",ni:"Ta opcja wprowadzi ci\u0119 do podziemia. Nie zapomnij w\u0142\u0105czy\u0107 Automatycznego Logowania z zak\u0142adki Dodatki, inaczej mo\u017cesz zosta\u0107 wylogowany przy wej\u015bciu do podziemia [B\u0142\u0105d Gry]",
$b:"Bot zazwyczaj wybiera losowo od 3 do 6 pr\u00f3b ataku na list\u0119 areny. Je\u015bli w\u0142\u0105czysz t\u0119 opcj\u0119, przejdzie przez twoj\u0105 list\u0119, dop\u00f3ki nie b\u0119dzie m\u00f3g\u0142 kogo\u015b zaatakowa\u0107. To mo\u017ce zaj\u0105\u0107 troch\u0119 czasu.",oj:"Ta opcja jest tylko dla licencji premium. Symuluje atak przed zaatakowaniem u\u017cytkownika dla 75% szansy na wygran\u0105.",yc:"Nie musisz w\u0142\u0105cza\u0107 g\u0142\u00f3wnego prze\u0142\u0105cznika aukcji, aby w\u0142\u0105czy\u0107 t\u0119 opcj\u0119.",
fk:"Ta opcja od\u015bwie\u017cy stron\u0119 co sekund\u0119, gdy aukcja jest w stanie -Bardzo Kr\u00f3tki-, aby nieustannie licytowa\u0107 i wygra\u0107 aukcj\u0119.",Ij:"Je\u015bli \u017caden z warunk\u00f3w wytopu nie zostanie spe\u0142niony, b\u0119dzie wybiera\u0107 losowo. Upewnij si\u0119, \u017ce wybra\u0142e\u015b typ i kolor przedmiotu.",Jj:"Ta opcja b\u0119dzie tylko wytopi\u0107 przedmioty z inwentarza. Zignoruje przedmioty w paczkach.",Va:"Przedmioty na Aukcji",af:"Przedmioty Najemnika",
Ub:"Przedmioty w Sklepie",hh:"Unikalne Przedmioty",Ej:"Ustaw t\u0142o na czarne [Zwi\u0119ksza wydajno\u015b\u0107]",Fj:"Przenie\u015b przyciski GLDbot do lewego dolnego rogu?",zh:"Atakuj Cyrk Bez Leczenia",dk:"Czy pobra\u0107 z\u0142oto z paczek, je\u015bli to konieczne?",ek:"Z\u0142oto zosta\u0142o pobrane z paczek do treningu",Jl:"Nie znaleziono z\u0142ota w paczkach do treningu",ak:"Naprawione Przedmioty",Uj:"Ataki na Arenie",Wj:"Ataki w Cyrku",pc:"Zresetowane Przedmioty",Zj:"Ataki na Wyprawach",
Yj:"Ataki w Lochach",bk:"Ataki w Podziemiach",Vj:"Pieni\u0105dze Zarobione na Arenie",Xj:"Pieni\u0105dze Zarobione w Cyrku",Hl:"Przedmioty Przetopione",$j:"Przetopione Z\u0142oto",ei:"Bitwa Gildii",gi:"Ustawienia Gildii",bl:"B\u0119dzie atakowa\u0107 gildie losowo.",fi:"Nazwa Gildii",xh:"Zresetuj Statystyki",di:"Atakuj losowo?",nl:"GLDbot: U\u017cyj kostek, aby od\u015bwie\u017cy\u0107 tajemnicze pude\u0142ko i znale\u017a\u0107 cenne przedmioty przed ich otwarciem (itp. Kostiumy). Kliknij \u201eStart\u201d otw\u00f3rz skrzynie.",
kc:"Drewno",hc:"Mied\u017a",ic:"\u017belazo",jc:"Sk\u00f3ra",xi:"We\u0142niana nitka",pi:"Bawe\u0142na",si:"Konopie",ri:"Kawa\u0142ek tkaniny",ui:"Kawa\u0142ek w\u0142\u00f3kna lnianego",ti:"\u0141ata z juty",wi:"Pasek aksamitu",vi:"Jedwabna nitka",Ei:"Futro",yi:"Od\u0142amek ko\u015bci",Hi:"\u0141uska",Bi:"Pazur",Di:"Kie\u0142",Ci:"Smocza \u0142uska",zi:"R\u00f3g byka",Gi:"Gruczo\u0142 jadowy",Ai:"Kawa\u0142ek futra Cerbera",Fi:"\u0141uska Hydry",Ii:"Pi\u00f3ro Sfinksa",Ji:"Sk\u00f3ra Tyfona",ai:"Lazuryt",
Vh:"Ametyst",Uh:"Bursztyn",Wh:"Akwamaryn",bi:"Szafir",Zh:"Granat",Yh:"Szmaragd",Xh:"Diament",$h:"Jaspis",ci:"Sugilit",Ph:"Jad skorpiona",Sh:"Eliksir wytrwa\u0142o\u015bci",Lh:"Antidotum",Kh:"Adrenalina",Rh:"Eliksir o\u015bwiecenia",Oh:"Nap\u00f3j postrzegania",Mh:"Esencja refleksu",Nh:"Fiolka Charyzmy",Th:"Woda zapomnienia",Qh:"Esencja duszy",Aj:"Wodna piecz\u0119\u0107",uj:"Runa ochrony",sj:"Ziemny grawerunek",zj:"\u015awi\u0119ty totem",yj:"Talizman mocy",wj:"Kamie\u0144 szcz\u0119\u015bcia",tj:"Krzemie\u0144",
xj:"Runa wichury",vj:"Runa cienia",Ui:"Kryszta\u0142",Ti:"Br\u0105z",Yi:"Obsydian",aj:"Srebro",bj:"Siarka",Wi:"Ruda z\u0142ota",$i:"Kwarc",Zi:"Platina",Si:"Almandyn",Vi:"Kupryt",Xi:"Piekielny kamie\u0144",th:"Atakuj losowo?",uh:'Wy\u0142\u0105cz r\u00f3wnie\u017c ustawienie "Sortuj graczy na arenie wed\u0142ug poziomu" w crazy-addon.',Kf:"Akceptuj tylko misje na podstawie typu boga.",Wa:"Automatyczny Buff",Mc:"U\u017cywaj tylko w piekle?",rf:"Nowa Zasada",pf:"Nazwa Zawiera",isUnderworldItem:"Czy to przedmiot z Podziemi",
Ud:"Ignoruj Materia\u0142y",lk:"U\u017cyj modlitwy",nh:"U\u017cyj ofiary",hk:"U\u017cyj tkaniny, aby wej\u015b\u0107 do podziemia",eh:"Czy w podziemiach akceptowa\u0107 tylko zadania zwi\u0105zane z podziemiami?",dh:"Je\u015bli w\u0142\u0105czone, musisz wprowadzi\u0107 nazwy przedmiot\u00f3w z podziemi. Je\u015bli bot znajdzie te przedmioty w podziemiach, zaakceptuje zadanie.",Pk:"Przedmiot zadania z podziemi",Zk:"Wprowad\u017a nazw\u0119 materia\u0142u",wk:"Bot uwielbia ko\u015bci! Pomagaj\u0105 znale\u017a\u0107 ubrania w skrzyniach. Ale je\u015bli nie ma ko\u015bci, bot i tak otwiera skrzynie, licz\u0105c na fajne ciuchy (ale mo\u017ce ich nie znale\u017a\u0107!)",
Hj:"Czy chcesz przetopi\u0107 skrzynki?",ad:"W\u0142\u0105cz automatyczne ataki na arenie?",Cf:"Priorytetowa lista aren?",Df:"Priorytetowa lista cyrk\u00f3w?",Tc:"Wy\u0142\u0105cz menu dziennika",Yf:"Minimalna warto\u015b\u0107 nagrody z\u0142ota",Lf:"Je\u015bli w\u0142\u0105czone, Fokus na zadaniach b\u0119dzie pod\u0105\u017ca\u0142 najkr\u00f3tsz\u0105 drog\u0105 do uko\u0144czenia lochu.",ug:"Automatyczne rzucanie kostk\u0105?",vg:"U\u017cywaj rzucania kostk\u0105 ostro\u017cnie, b\u0119dzie ono nadal u\u017cywa\u0107 pierwszej kostki, dop\u00f3ki nie wy\u0142\u0105czysz opcji.",
cg:"Post\u0119p w wyszukiwaniu",Sf:"Czas odnowienia naprawy domy\u015blnie wynosi 10 minut.",lf:"Minimalny stan",Rc:"Obecny przedmiot na warsztacie [Wyczy\u015b\u0107, je\u015bli bot nagle zostanie zatrzymany]",oe:"Pomy\u015blnie przechowywano zasoby do horreum.",ke:"Sprawdzanie rynku na przedmioty...",Ab:"Przedmiot przeniesiony na warsztat.",Ce:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony i za\u0142o\u017cony.",De:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony.",Dk:"Naprawa nie powiod\u0142a si\u0119. Strona zostanie od\u015bwie\u017cona.",
ze:"Podnoszenie materia\u0142\u00f3w...",Me:"Oczekiwanie na napraw\u0119...",Be:"Naprawa rozpocz\u0119\u0142a si\u0119 dla .",Ba:"Naprawa: Przenoszenie przedmiotu z inwentarza do torby",Ae:"Naprawa: Przenoszenie przedmiotu z warsztatu do paczki.",sb:"Nie uda\u0142o si\u0119 znale\u017a\u0107 wystarczaj\u0105cej ilo\u015bci materia\u0142\u00f3w. Wy\u0142\u0105czanie slotu naprawy ",we:"Szukanie przedmiot\u00f3w do kupienia w celu ukrycia z\u0142ota na Aukcji...",he:"Sprawdzanie wygas\u0142ych przedmiot\u00f3w w paczkach...",
ie:"Przedmiot zosta\u0142 pomy\u015blnie zresetowany.",je:"Brak pustej przestrzeni lub z\u0142ota do zresetowania.",pe:"Upewnij si\u0119, \u017ce masz prawa do sprzeda\u017cy na rynku gildii!",ub:"Brak wystarczaj\u0105cej ilo\u015bci z\u0142ota/lub brak przedmiotu do kupienia. Oczekiwanie 30 sekund na od\u015bwie\u017cenie.",wb:"Sklep zosta\u0142 od\u015bwie\u017cony.",xb:"B\u0142\u0105d podczas leczenia.",se:"Brak Rubina lub Materia\u0142u, wy\u0142\u0105czanie opcji.",te:"Brak przedmiotu do leczenia w paczkach.",
yb:"Nie znaleziono odpowiednich przedmiot\u00f3w",ue:"\u017bywno\u015b\u0107 zosta\u0142a wybrana. Zako\u0144czenie procesu.",ve:"Wybrano przynajmniej jedzenie. Proces zako\u0144czony.",zb:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",qe:"Pobieranie jedzenia z paczek.",re:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",vb:"Brak wi\u0119cej przedmiot\u00f3w do leczenia. Oczekiwanie 30 sekund.",tb:"Odzyskano punkty \u017cycia.",Aa:"Nie ma nic do roboty, wi\u0119c id\u0119 si\u0119 pomodli\u0107!",
Ie:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie i Vill\u0119 Medici.",Je:"Oczekiwanie na Vill\u0119 Medici, od\u015bwie\u017canie za 60 sekund.",Ke:"Opuszczono za\u015bwiaty.",Le:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie.",xe:"Sprawdzanie olejk\u00f3w bo\u017cych...",ye:"Olejki bo\u017ce zosta\u0142y podniesione.",ya:"Pomy\u015blnie zaatakowano gracza na ARENIE: ",za:"Pomy\u015blnie zaatakowano gracza w CIRKUSIE: ",fe:"Sprawdzanie aukcji! Prosz\u0119 czeka\u0107...",
ge:"Licytacja przedmiot\u00f3w. Prosz\u0119 czeka\u0107...",Ee:"Automatycznie przetopiony przedmiot: ",Fe:"Przetapiany przedmiot: ",Ge:"Nie ma wystarczaj\u0105cej ilo\u015bci z\u0142ota do przetopienia. Wymagane z\u0142oto: ",He:"PRZETAP: Szukanie przedmiot\u00f3w do przetopienia...",Ek:"Szukanie przedmiot\u00f3w do przetopienia...",le:"Sprawdzanie dost\u0119pno\u015bci kostium\u00f3w...",ne:"Wys\u0142ano datek: ",me:"Rzucanie kostk\u0105...",Hd:"Underworld Farm [Manual, Beta]",Gd:"Farm Location",
Id:"Uwaga: w\u0142\u0105cz t\u0119 funkcj\u0119 po odblokowaniu stworzenia, kt\u00f3re chcesz zaatakowa\u0107, nie b\u0119dzie ono automatycznie atakowa\u0107, aby odblokowa\u0107 potwora.",Fd:"Farm Enemy",Fc:"Automatyczne Logowanie",Gc:"Musisz zezwoli\u0107 na wyskakuj\u0105ce okienka z ekranu lobby GameForge. Zobacz dokumentacj\u0119, jak to zrobi\u0107.",zf:"Wstrzymaj Bota",Af:"Wstrzymaj Bota na (Minuty)",Dd:"Data Wyga\u015bni\u0119cia",uf:"Tylko kupowa\u0107 jedzenie?",vf:"Je\u015bli to w\u0142\u0105czysz, zignoruje twoje wybory i b\u0119dzie automatycznie kupowa\u0107 jedzenie, nie wprowadzaj\u0105c niczego.",
Ib:"Maksymalna \u0142\u0105czna ilo\u015b\u0107 z\u0142ota do wydania",Hb:"Maksymalna ilo\u015b\u0107 z\u0142ota na jedzenie do wydania",tf:"Bot b\u0119dzie sprawdza\u0107 oleje co 60 minut",Ng:"Ustawia timer do sprawdzania czas\u00f3w topienia.",Kg:"Ustawia timer do sprawdzania topienia, gdy nie masz z\u0142ota.",Mg:"Ustawia timer do sprawdzania topienia, gdy nie masz dost\u0119pnego przedmiotu.",Fg:"Ustawia timer do naprawy i sprawdzania twoich przedmiot\u00f3w.",Eg:"Ustawia timer do sprawdzania ilo\u015bci z\u0142ota w gildijnym rynku.",
Ag:"Ustawia timer dla opcji zatrzymania z\u0142ota na aukcji.",wg:"Ustawia timer do sprawdzania listy PvP na arenie do ataku.",Bg:"Ustawia timer do sprawdzania listy PvP w cyrku do ataku.",Tg:"Ustawia timer treningowy do trenowania statystyk.",Hg:"Ustawia timer do resetowania wygas\u0142ych przedmiot\u00f3w.",Rg:"Ustawia timer do przechowywania materia\u0142\u00f3w do kucia w horreum.",yg:"Ustawia timer do sprawdzania aukcji gladiator\u00f3w i najemnik\u00f3w.",Jg:"Ustawia timer do wyszukiwania przedmiot\u00f3w na aukcji i w sklepie.",
Cg:"Ustawia timer do wysy\u0142ania darowizn do gildii.",Md:"Z\u0142oto Przeniesione",Yc:"Nie sprzedawaj przedmiot\u00f3w z listy hutniczej i aukcyjnej",dg:"Automatyzacja Sklepu",fg:"Ustawienia Wyszukiwania Przedmiotu",eg:"U\u017cyj tego narz\u0119dzia do wyszukiwania przedmiot\u00f3w. Po prostu dodaj przedmioty do listy, okre\u015bl ilo\u015b\u0107 tkaniny i rozpocznij wyszukiwanie.",gg:"Ilo\u015b\u0107 Tkaniny do U\u017cycia:",hg:"Ile tkaniny u\u017cy\u0107?",ja:"Full Wprowad\u017a Nazw\u0119 Przedmiotu",
Tb:"Wprowad\u017a Poziom Przedmiotu",jg:"Jako\u015b\u0107 Przedmiotu",ig:"Wprowad\u017a Nazw\u0119 Przedmiotu Tutaj",kg:"Rozpocznij Wyszukiwanie",lg:"Pomi\u0144 i Kontynuuj",mg:"Zatrzymaj Wyszukiwanie",Jd:"Kupi\u0107 najta\u0144sze czy najdro\u017csze?",nf:"Najdro\u017csze",Oc:"Najta\u0144sze",ga:"Wybierz Opcj\u0119",cd:"Pod\u015bwietl przedmioty z Podziemia",Kd:"Skoncentruj si\u0119 na zadaniu?",Ll:"U\u017cyj rubinu, je\u015bli nie ma tkaniny?",Xa:"Unikaj atakowania tych samych os\u00f3b, aby unikn\u0105\u0107 zg\u0142osze\u0144. Zg\u0142oszenia zwi\u0119kszaj\u0105 szans\u0119 na zablokowanie konta.",
Al:"Roztopi\u0107 zielone?",Ff:"Nie akceptuj losowych zada\u0144, je\u015bli wprowadzono jakiekolwiek filtry?",lc:"Maksymalna jako\u015b\u0107 materia\u0142u do u\u017cycia",Hh:"W\u0142\u0105czy\u0107 wyszukiwanie najemnik\u00f3w",jl:"Kliknij \u201eSprzedaj Wszystkie Wybrane\u201d, aby sprzeda\u0107 wszystkie przedmioty. Upewnij si\u0119, \u017ce masz 2x3 puste miejsce w swojej pierwszej (1) torbie. Aby zbiera\u0107 z\u0142oto masowo, u\u017cyj filtra na z\u0142oto i opcji \u201eWybierz Wybrane lub Wybierz Wszystkie\u201d.",
Tj:"\ud83d\udd25 : Dodaje przedmiot do listy przetapiania.",vh:"\ud83d\udd28 : Dodaje przedmiot do listy aukcyjnej.",qj:"Od\u015bwie\u017c sklep tkanin\u0105, gdy jest pe\u0142ny (musisz ponownie sprzeda\u0107 po tym)",ej:"Strona:",lj:"Zatrzymaj",jj:"Sprzedaj T\u0119 Stron\u0119",gj:"Wybierz Wybrane",fj:"Wybierz Wszystko",mj:"Ustawienia Automatycznego Pakowania",kj:"Wy\u015blij Zasoby",hj:"Sprzedaj Wszystkie Wybrane",ra:"Rodzaj Przedmiotu",W:"Bronie",S:"Tarcze",M:"Zbroje",P:"He\u0142my",O:"R\u0119kawice",
N:"Buty",V:"Pier\u015bcienie",U:"Amulety",pa:"U\u017cytkowe (\u017bywno\u015b\u0107)",wa:"Ulepszenia",cj:"Wzmacniacze",ta:"Receptury",sa:"Najemnicy",va:"Narz\u0119dzia Kowalskie",ua:"Zwoje",Oa:"Wzmocnienia",Ma:"Przedmioty Eventowe",Na:"Materia\u0142y Kowalskie",dj:"Z\u0142oto",T:"Wszystko",ql:"Jako\u015b\u0107",X:"Bia\u0142y",B:"Zielony",A:"Niebieski",C:"Fioletowy",G:"Pomara\u0144czowy",R:"Czerwony",ij:"Opcje Sprzeda\u017cy",Gj:"Ignorowa\u0107 Kombinacje Przedrostk\u00f3w/Sufiks\u00f3w?",hi:"Ile jedzenia kupi\u0107/wybiera\u0107?",
Ch:"Normalny",Bh:"\u015aredni",Ah:"Trudny",Ja:"Standardowy",tl:"Naprawa Utkni\u0119\u0107",Bk:"Wy\u0142\u0105cz Wej\u015bcie do Piek\u0142a, je\u015bli chcesz wy\u0142\u0105czy\u0107 Lochy/Cyrk/Aren\u0119. Je\u015bli wszed\u0142e\u015b do Piek\u0142a r\u0119cznie, musisz w\u0142\u0105czy\u0107 Tryb Piek\u0142a.",Wg:"Okre\u015bl, ile razy chcesz przeprowadzi\u0107 szkolenia dla statystyk oraz ich priorytety. Bot nie b\u0119dzie przeprowadza\u0142 szkole\u0144, dop\u00f3ki nie zostanie ustalony priorytet. Je\u015bli priorytet zosta\u0142 ustawiony, ale nie ma ju\u017c wi\u0119cej statystyk do szkolenia, bot kontynuowa\u0107 b\u0119dzie z priorytetowym szkoleniem.",
Wk:"Quest",Pc:"Wybierz kostium z Za\u015bwiat\u00f3w",qh:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",yl:"Przetapianie",El:"Ustawienia Topienia",Qj:"Topione Przedmioty",Fl:"Dodaj Prefiks lub Sufiks, gdy bot znajdzie go w paczkach, automatycznie przeprowadzi przetapianie.:",Dl:"Topiony Przedmiot:",cc:"Kliknij na przedmiot, kt\u00f3ry chcesz naprawi\u0107. Ten system naprawi twoje dwie postacie, g\u0142\u00f3wn\u0105 oraz pierwsz\u0105 posta\u0107 cyrku. Musisz mie\u0107 co najmniej 10000 z\u0142ota, aby naprawa mog\u0142a si\u0119 rozpocz\u0105\u0107. Je\u015bli utkn\u0105\u0142 na jednym przedmiocie, oznacza to, \u017ce nie masz materia\u0142u do naprawy. Spr\u00f3buj r\u00f3wnie\u017c zrobi\u0107 troch\u0119 miejsca w swoim inwentarzu. Bot rozpocznie napraw\u0119, gdy trwa\u0142o\u015b\u0107 przedmiotu wynosi 0%.",
Qk:"Zastosuj tylko do Najemnik\u00f3w",Tk:"Licytacja b\u0119dzie licytowa\u0107 tylko wtedy, gdy rynek zbli\u017cy si\u0119 do ko\u0144ca.",Sk:"Upewnij si\u0119, \u017ce DRUGA KARTA INWENTARZA jest pusta i masz 10 000 z\u0142ota. Bot znajdzie i umie\u015bci przedmiot na drugiej karcie, a nast\u0119pnie, gdy strona zostanie od\u015bwie\u017cona, przeprowadzi przetapianie przedmiotu. przetapianie b\u0119dzie ponownie sprawdzane co 5-10 minut.",ki:"Leczenie & Buffs",ul:"Za ma\u0142o z\u0142ota na przetapianie. Wymagane Z\u0142oto:",
xl:"Pomijanie licytacji: Cz\u0142onek gildii ju\u017c licytowa\u0142 przedmiot ",wl:"Pomijanie licytacji: Ju\u017c licytowa\u0142e\u015b przedmiot ",advanced:"Zaawansowane",arena:"Arena",na:"Auto Atak",ac:"Unikaj Ataku",la:"Dodaj Gracza",ma:"Wpisz Nazw\u0119 Gracza (Same Server)",dl:"Zatrzymaj Bota, je\u015bli brakuje jedzenia?",circusTurma:"Cyrk Turma",Dh:"Trudno\u015b\u0107",dungeon:"Loch",Eh:"Ustawienia Lochu",eventExpedition:"Ekspedycja Wydarzenia",expedition:"Wyprawa",Ih:"Ustawienia Wyprawy",
Bj:"Wybierz Potwora",gl:"Najwy\u017cszy",el:"Umie\u015b\u0107 swoje przedmioty uzdrawiaj\u0105ce na pierwszej stronie swojego inwentarza",fc:"W",sg:"Przechowuj Z\u0142oto",tg:"Przechowuj Z\u0142oto w Licytacji?",Sb:"Wybierz Godzin\u0119",ag:"U\u017cyj Roboczych Ubran, aby odnowi\u0107 Sklep?",Kk:"Wybierz Przedmioty do Zresetowania",Uf:"Zresetuj Wygas\u0142e Przedmioty",Ob:"Uwaga: W\u0142\u0105czaj\u0105c t\u0119 opcj\u0119, bot b\u0119dzie sprzedawa\u0142 nadchodz\u0105ce wygas\u0142e przedmioty z Paczek na Rynek Gildii, a nast\u0119pnie anuluje, aby zresetowa\u0107 czas wyga\u015bni\u0119cia. Wymagana jest gildia. Upewnij si\u0119, \u017ce masz puste miejsce 3x3 w swoich torbach.",
Bf:"Losowe Zatrzymywanie Bota [Faza Testowa]:",da:"Zachowaj Z\u0142oto: Bot b\u0119dzie trzyma\u0142 to z\u0142oto w torbie:",Ze:"Max Gold: Bot b\u0119dzie wydawa\u0142, gdy z\u0142oto b\u0119dzie wi\u0119ksze ni\u017c",Zf:"Bot b\u0119dzie sk\u0142ada\u0142 oferty na losowe przedmioty.",qc:"Dodaj Losowe Op\u00f3\u017anienie",rc:"Mo\u017cesz tutaj doda\u0107 op\u00f3\u017anienie do bota.",Nb:"Naprawa",zl:"Top Tylko Niebieskie?",Cl:"Top Tylko Fioletowe?",Bl:"Top Tylko Pomara\u0144czowe?",Rj:"Top Wszystko na 2. karcie?",
Sj:"To zignoruje wyb\u00f3r kolor\u00f3w",Ya:"Wyczy\u015b\u0107 Histori\u0119",og:"Przetapianie",zc:"Search",qf:"Auto Licytacja",Ac:"Nadmierne korzystanie z aukcji mo\u017ce skutkowa\u0107 banem. Zaleca si\u0119 wy\u0142\u0105czenie innych funkcji okre\u015blania stawek, aby unikn\u0105\u0107 potencjalnych konflikt\u00f3w. Ta funkcja spowolni bota.",$f:"Szukaj w Licytacji Gladiator\u00f3w",bg:"Szukaj w Licytacji Najemnik\u00f3w",Ic:"Licytuj Po\u017cywienie?",$e:"Maksymalna Licytacja",Jc:"Licytuj, je\u015bli status jest mniejszy ni\u017c",
Kc:"Wystawione Przedmioty",rk:"J\u0119zyk Licytacji",sk:"Zgodnie z aktualizacj\u0105 2.9.4, prosz\u0119 ponownie ustawi\u0107 j\u0119zyk lub ZRESETOWA\u0106 BOTA. Upewnij si\u0119, \u017ce wszystko jest poprawne, w przeciwnym razie bot nie b\u0119dzie licytowa\u0107.",uc:"Mo\u017cesz doda\u0107 przedmioty do wyszukiwania na rynku i w licytacji. Poka\u017ce tak\u017ce fioletowe przedmioty na rynku, gdy dodasz przedmiot do listy. Je\u015bli chcesz w\u0142\u0105czy\u0107 auto licytacj\u0119, u\u017cyj opcji poni\u017cej",
pk:"U\u017cywaj licytacji z rozwag\u0105!",qk:"Automatyczna licytacja generuje zbyt wiele \u017c\u0105da\u0144 do serwera i mo\u017ce spowodowa\u0107 ban, je\u015bli u\u017cywasz jej ca\u0142y czas!",Rf:"Odnowi\u0107 Punkty Wydarzenia Rubinem?",ed:"W\u0142\u0105cz Auto Olej",uk:"Auto Pobieraj \u015awi\u0119te Oleje",Gk:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Ta:"Atakowa\u0107 Cz\u0142onk\u00f3w Gildii?",Ra:'Automatycznie dodawaj osoby do listy "Atak", gdy wi\u0119cej ni\u017c X z\u0142ota zostanie skradzione.:',
Sa:'Automatycznie dodawaj osoby do listy "Unikaj Atak", gdy przegrasz z nimi.:',Rb:"Ataki na Tablicy Wynik\u00f3w",Yb:"Bardzo D\u0142ugo",Bb:"D\u0142ugo",Jb:"\u015arednio",Vb:"Kr\u00f3tko",Zb:"Bardzo Kr\u00f3tko",fd:"Wejd\u017a do Podziemia je\u015bli HP >",Mf:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Ef:'Domy\u015blnie to "3x". Je\u015bli bot sprawia problemy z zadaniami, zmie\u0144 szybko\u015b\u0107 zada\u0144 zgodnie ze szybko\u015bci\u0105 serwera.',Nd:"Wyb\u00f3r Worka z Lecznicami",gd:'Je\u015bli r\u0119cznie odnawiasz punkty, musisz klikn\u0105\u0107 przycisk powy\u017cej: "Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!"',
yk:"Musisz w\u0142\u0105czy\u0107 co najmniej jedn\u0105 z opcji: ekspedycja, loch, arena lub cyrk, aby rozpocz\u0105\u0107 Ekspedycj\u0119 Eventow\u0105.",Of:"Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!",lb:"Nie przebijaj gildii?",Mk:"Pozostaw wszystkie ustawienia wy\u0142\u0105czone, je\u015bli chcesz przetapia\u0107 za pomoc\u0105 paczek zawieraj\u0105cych przedmioty z listy. Jednak nadal mo\u017cesz wybiera\u0107 kolory.",vk:"Posta\u0107(Wy\u0142\u0105czona) / Najemnik(W\u0142\u0105czony)",
Jk:"Naprawi\u0107 Obie?",Nk:"Timery",Timers:"Wprowad\u017a liczb\u0119 minut dla ka\u017cdego timera poni\u017cej lub pozostaw domy\u015blnie.",Jf:"Ignoruj Filtr Zada\u0144",If:"Wprowad\u017a s\u0142owa kluczowe, aby odfiltrowa\u0107 zadania, kt\u00f3rych nie chcesz przyj\u0105\u0107. You can also use this to accept quests by their reward using keywords.",aa:"Wprowad\u017a S\u0142owo Kluczowe",I:"Dodaj",Qf:"Usu\u0144",Qc:"Wyczy\u015b\u0107",Gf:"Akceptuj Filtr Zada\u0144",Hf:"Wprowad\u017a s\u0142owa kluczowe, aby wybra\u0107 zadania do przyj\u0119cia. U\u017cycie tego spowoduje ignorowanie rodzaj\u00f3w zada\u0144",
Ha:"Pomi\u0144 Zadania Czasowe?",Hk:"Zadania",Cc:"Automatyczny Kostium",kh:"U\u017cywa\u0107 Kostiumu?",Hc:"Podstawowa Bitwa",Zc:"Bitwa w Lochach",Dc:"Bot b\u0119dzie nosi\u0142 Dis Pater Normal i Medium tylko wtedy, gdy Twoje punkty ekspedycji/podziemi wynosz\u0105 0.",Pd:"Ustawienia Piekielnego Leczenia",tc:"Atakuj Bossa, Gdy Dost\u0119pny?",rb:"Atak na Lig\u0119 zostanie wy\u0142\u0105czony po 5 nieudanych atakach.",Sd:"\u015awi\u0119te Oleje",kf:"Nazwa Przedmiotu",ea:"Minimalny Poziom Przedmiotu",
Ga:"Minimalna Jako\u015b\u0107 Przedmiotu",sc:"Zastosuj/Resetuj Licznik",Vd:"Ignoruj Prefiks/Sufiks",rh:"Tak",sf:"Nie",Pa:"Dodaj Prefiks",Qa:"Dodaj Sufiks",pg:"Lista Ignorowanych Przedmiot\u00f3w do Topienia",Kb:"Prefiks",Wb:"Sufiks",Wf:"Resetuj Wygas\u0142e Przedmioty",qg:"Losowe Topienie z Paczek?",rg:"Karta Topienia",pb:"Dodatki",xc:"Aukcja",Se:"Rynek",Xb:"Zegary",Pg:"Topienie",Og:"Topienie, je\u015bli brakuje z\u0142ota",Lg:"Topienie, je\u015bli brakuje przedmiotu",Ia:"Naprawa",Dg:"Przechowuj Z\u0142oto na Rynku Gildii",
zg:"Przechowuj Z\u0142oto na Aukcji",Sg:"Trening",Gg:"Resetuj Wygas\u0142e",Qg:"Przechowuj W Ku\u017ani",xg:"Sprawd\u017a Aukcj\u0119",Ig:"Szukaj",v:"W\u0142\u0105cz",mf:"Minimalne Z\u0142oto",mb:"Wp\u0142acaj Z\u0142oto do Gildii",Uc:"B\u0119dzie wp\u0142aca\u0107 co 5 minut. Mo\u017cesz zmieni\u0107 interwa\u0142 w zak\u0142adce zegar\u00f3w",Td:"Ile chcesz wp\u0142aci\u0107?",Vc:"Wp\u0142aca\u0107, gdy masz wi\u0119cej ni\u017c >",ee:"Mniej ni\u017c <",Tf:"Resetuj Wygas\u0142e i Inne Ustawienia",
Vf:"Reset za:",Ck:"Naci\u015bnij Ctrl (Cmd na Macu), aby zaznaczy\u0107 wiele przedmiot\u00f3w",Wd:"Importuj/Eksportuj Ustawienia",Ed:"Eksportuj Ustawienia",Xd:"Importuj Ustawienia",cf:"Wiadomo\u015b\u0107 do Wszystkich Graczy",df:"[Wymaga Klucza Ultra Premium, wiadomo\u015b\u0107 na Discordzie, aby go otrzyma\u0107.]",ef:"Wprowad\u017a wiadomo\u015b\u0107 do wys\u0142ania",Sc:"Aby uzyska\u0107 niestandardowe skrypty, skontaktuj si\u0119 z nami na Discordzie",gf:"Wy\u015blij",hf:"Poka\u017c Graczy",
ff:"Zaznacz Wszystkie",jf:"Odznacz Wszystkie",de:"Upewnij si\u0119, \u017ce tw\u00f3j inwentarz ma wystarczaj\u0105co du\u017co miejsca. Czas odnowienia wynosi 2 minuty.",ob:"W\u0142\u0105cz Atak na Tablicy Wynik\u00f3w:",Pb:"Wybierz Zakres Ataku",Qb:"Bot losowo atakuje z listy tablicy wynik\u00f3w.",qb:"Atak Ligi",nb:"W\u0142\u0105cz Atak Ligi:",Lb:"Losowo Atakuj",Mb:"Atakuj od najs\u0142abszego do najsilniejszego",nk:"Domy\u015blnie bot unika atakowania cz\u0142onk\u00f3w gildii.",Cd:"Lokalizacja Wyprawy:",
Bc:"Auto Zbieraj Bonusy:",ng:"Pomi\u0144 Bossa",$c:"Lokalizacja Lochu:",Xf:"Zresetowa\u0107, je\u015bli przegrasz?",Qd:"Ustawienia Piek\u0142a",Rd:"Skonfiguruj ustawienia procentu leczenia w zak\u0142adce leczenia i upewnij si\u0119, \u017ce zak\u0142adka leczenia jest aktywowana. Je\u015bli wej\u015bcie do podziemi wyrzuca ci\u0119 z gry, przejd\u017a do lobby i zaznacz pole wyboru automatycznego logowania.",Od:"Trudno\u015b\u0107 Piek\u0142a",Ec:"Auto Wej\u015bcie do Piek\u0142a: / Piek\u0142a Mode",
lh:"U\u017cyj Mobilizacji, je\u015bli punkty = 0",ph:"U\u017cyj rubin\u00f3w?",hd:"Wyj\u015b\u0107 z podziemi, je\u015bli nie ma punkt\u00f3w?",Yg:"Bot b\u0119dzie pr\u00f3bowa\u0142 u\u017cy\u0107 willi medici najpierw, je\u015bli jej nie masz, u\u017cyje mikstury uzdrawiania. Nie zapomnij w\u0142\u0105czy\u0107 prze\u0142\u0105cznika uzdrawiania.",gh:"Automatyczne wej\u015bcie do piek\u0142a wy\u0142\u0105czy loch/aren\u0119/cyrk po wej\u015bciu do piek\u0142a.",Ok:"Ustawienia Leczenia Piek\u0142a",
oh:"U\u017cyj Willi Medici?",mh:"U\u017cyj Mikstury Uzdrawiania?",Ne:"INFORMACJA: Bot b\u0119dzie wyszukiwa\u0142 przedmioty na rynku co wybran\u0105 liczb\u0119 minut, co mo\u017ce spowodowa\u0107 zatrzymanie atakowania podczas wyszukiwania.",dd:"W\u0142\u0105cz Wyszukiwanie na Rynku:",Oe:"Interwa\u0142 Wyszukiwania na Rynku w Minutach:",Pe:"Sugerowane 10 minut.",$d:"Ustawienia Przedmiotu:",Yd:"Nazwa Przedmiotu Zawiera",H:"Maksymalna Cena",ae:"Rodzaj Przedmiotu",Zd:"Rzadko\u015b\u0107 Przedmiotu",
Nc:"Kup Przedmiot Uwi\u0105zany?",ce:"Przedmioty do Kupienia",be:"Pr\u00f3buj kupowa\u0107 przedmioty z paczek, je\u015bli kt\u00f3rykolwiek z nich pasuje do maksymalnej ceny wprowadzonej.:",Lc:"Zakupione Przedmioty:",ii:"Procent Leczenia",jk:"Kupuj Jedzenie ze Sklepu?",kk:"U\u017cyj Leczenia z Paczki?",gk:"U\u017cyj Cervisia?",ik:"U\u017cyj Jajka?",kl:"Ostatnio U\u017cyty",location:"Lokalizacja",Strength:"Si\u0142a",Dexterity:"W\u0142adanie broni\u0105",Agility:"Zr\u0119czno\u015b\u0107",Constitution:"Budowa fizyczna",
Charisma:"Charyzma",Intelligence:"Inteligencja",Ug:"Ustawienia Treningu",Vg:"Wybierz atrybuty, kt\u00f3re chcesz trenowa\u0107. Bot przeprowadzi trening, gdy b\u0119dziesz mia\u0142 wystarczaj\u0105co du\u017co z\u0142ota.",nc:"Nast\u0119pna akcja",Pi:"Nie",Qi:"Normalnie",ol:"Przeciwnik",pl:"Poziom Przeciwnika",pj:"Zadania",random:"Losowo",vl:"Ustawienia",Gl:"Wkr\u00f3tce...",type:"Kliknij na ikony, aby aktywowa\u0107 rodzaje zada\u0144.",Nl:"Tak",D:"Licytacja/Szukaj",oc:"Dodaj przedmioty",ck:"Automatycznie Przechowuj Zasoby W\u0142asne",
Il:"Zatwierd\u017a",il:"Interwa\u0142 : ",Xk:"W\u0142\u0105cz Automatyczn\u0105 Licytacj\u0119",Yk:"Nie licytuj, je\u015bli cz\u0142onek gildii ju\u017c licytowa\u0142",Kl:"Samouczek",bc:"Wybierz przyciski powy\u017cej, aby wybra\u0107, czy chcesz stawi\u0107 czo\u0142a najni\u017cszemu przeciwnikowi na arenie, czy przeciwnikowi najwy\u017cszego poziomu. Wi\u0119cej u\u017cytkownik\u00f3w spowolni dzia\u0142anie bota.",Rk:'Aby rozpocz\u0105\u0107, dodaj przedmiot do listy (np. "Lucius"). Po dodaniu narz\u0119dzie b\u0119dzie szuka\u0107 przedmiotu i wy\u015bwietla\u0107 wyniki wyszukiwania po lewej stronie ekranu. B\u0119dzie r\u00f3wnie\u017c szuka\u0107 przedmiotu w celu automatycznej licytacji. Je\u015bli w\u0142\u0105czysz automatyczn\u0105 licytacj\u0119, narz\u0119dzie b\u0119dzie regularnie szuka\u0107 przedmiotu w okre\u015blonych odst\u0119pach czasu, zgodnie z liczb\u0105 wpisan\u0105 w polu interwa\u0142u. Je\u015bli narz\u0119dzie znajdzie przedmiot i b\u0119dziesz mie\u0107 wystarczaj\u0105co du\u017co pieni\u0119dzy, automatycznie z\u0142o\u017cy za ciebie licytacj\u0119. *Uwaga* aby szuka\u0107 unikalnych przedmiot\u00f3w w sklepach, musisz doda\u0107 przynajmniej 1 losowy przedmiot do listy wyszukiwania.',
$k:"Numer potwora mo\u017cna wybra\u0107 z przycisk\u00f3w powy\u017cej. Numer 1 reprezentuje potwora najbardziej na lewo. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",Fh:"Wybierz trudno\u015b\u0107 lochu z powy\u017cszych opcji. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",ji:"Ustawienia Leczenia",Gh:"Przechowuj nadmiar z\u0142ota w Gildii, kupuj\u0105c przedmioty z rynku gildii. -> Min. Z\u0142oto",
ll:"Przenie\u015b Wszystko",ml:"Przenie\u015b Wybrane",Uk:"Auto Uzdrawianie",Vk:"Procent Auto Uzdrawiania",Ml:"Ruby",wf:"Og\u00f3lne Ustawienia",Cj:"Sprzedaj Wszystko",Dj:"Sprzedaj Wybrane",ka:"Bronie",ha:"Tarcze",Z:"Zbroje Piersiowe",ca:"He\u0142my",ba:"R\u0119kawice",ia:"Buty",fa:"Pier\u015bcienie",Y:"Amulety",jh:"U\u017cywalne",ih:"Ulepszenia",Nf:"Receptury",bf:"Zwoje Najemnik\u00f3w",Pf:"Wzmocnienia",We:"Sprzedaj \u017bywno\u015b\u0107",Fb:"Prze\u0142\u0105cz na \u017bywno\u015b\u0107"},Gh={Ni:"Tipo de b\u00fasqueda de nido",
Li:"No hacer nada",Mi:"B\u00fasqueda r\u00e1pida",Oi:"B\u00fasqueda exhaustiva",nj:"After expedition points are consumed, travel to Germania to consume Dungeon points",mk:"Haz clic aqu\u00ed si la reparaci\u00f3n se atasca",Ak:"Cuando los HP est\u00e9n bajos, usa curar",yf:"Reparaci\u00f3n Parcial",Ld:"Reparaci\u00f3n Completa",xf:"Reparaci\u00f3n Parcial o Completa",bd:"Habilitar L\u00edmite",li:"L\u00edmite",mi:"Si deseas limitar el n\u00famero de veces que quieres atacar al enemigo, habilita esta opci\u00f3n y establece el l\u00edmite. El bot continuar\u00e1 atacando al resto de los enemigos despu\u00e9s de terminar de atacar al monstruo seleccionado.",
Xc:"No entres al inframundo con el traje del inframundo",Wc:"Si no quieres entrar al inframundo mientras llevas el traje del inframundo puesto, activa esta opci\u00f3n",fh:"Inframundo",Xg:"Mejoras del Inframundo",Zg:"\u00bfUsar los poderes de los dioses despu\u00e9s de entrar al inframundo?",$g:"Selecciona a los dioses para usar sus poderes:",ah:"\u00bfUsar Buff de Arma en el arma?",bh:"\u00bfUsar Buff de Armadura en el siguiente equipo?",xk:"El tiempo de enfriamiento es de 30 minutos. Si no llevas un disfraz, el bot restablecer\u00e1 el tiempo de enfriamiento a 0.",
Lk:"Seleccionar Colores",Za:"Forja de Vulcano",cb:"Escudo Terrestre de Feronia",eb:"Poder Fluido de Neptuno",fb:"Libertad A\u00e9rea de Aelous",gb:"Niebla Mortal de Plut\u00f3n",hb:"Aliento de Vida de Juno",ib:"Armadura de Escamas de las Monta\u00f1as de la Ira",jb:"Ojos de \u00c1guila",kb:"Vestidura Invernal de Saturno",$a:"Armadura de Toro de Bubona",ab:"Vestiduras de Ladr\u00f3n de Mercurio",bb:"T\u00fanica de Luz de Ra",Ve:"Paquetes",Qe:"Inventario",K:"Precio M\u00edn.",J:"Cantidad",Eb:"Vender Art\u00edculos",
Db:"Buscar en",Re:"Color del Material",Cb:"Color del Art\u00edculo",Ye:"Almac\u00e9n",Fa:"Cambiar a Materiales",Gb:"Cambiar a Art\u00edculos",Xe:"Vender Materiales",Ca:"Por favor, introduce un nombre de art\u00edculo v\u00e1lido, rango de precio y cantidad.",Da:"No se han encontrado art\u00edculos adecuados en las ubicaciones de b\u00fasqueda seleccionadas.",Ea:"\u00a1Todos los art\u00edculos fueron listados con \u00e9xito!",Fk:"\u00a1Todos los materiales fueron listados con \u00e9xito!",Te:"Si quieres vender art\u00edculos a un precio fijo, puedes ingresar el mismo valor para el precio m\u00ednimo y m\u00e1ximo.",
Ue:"Esta caracter\u00edstica todav\u00eda es experimental, \u00fasala con precauci\u00f3n. Si no pones un precio fijo, los art\u00edculos se listar\u00e1n aleatoriamente entre el precio m\u00ednimo y m\u00e1ximo que ingreses.",tk:"Establece el m\u00e1ximo de oro que el bot gastar\u00e1 por ciclo.",Ua:"El bot comenzar\u00e1 a pujar por cualquier art\u00edculo de comida, si est\u00e1 habilitado. No necesitas habilitar los interruptores de gladiador/mercenario.",vc:"El bot no pujar\u00e1 sobre las ofertas de los aliados.",
wc:"Ignorar la combinaci\u00f3n de Prefijo/Sufijo al buscar un art\u00edculo en la subasta.",Kj:"Selecciona los tipos de art\u00edculos que quieres fundir.",Lj:"Selecciona los colores que quieres fundir.",Mj:"Selecciona el nivel de los art\u00edculos que quieres fundir.",Nj:"Selecciona el martillo que quieres usar.",Oj:"Nota que el c\u00edrculo verde y rojo junto a la primera caja son para habilitar/deshabilitar la regla.",Pj:"Si quieres fundir aleatoriamente cualquier color o tipo, puedes habilitar `\u00bfFundir aleatoriamente si no se cumplen condiciones? (\u00daltima opci\u00f3n habilitada en el video tutorial)",
rj:"Reparar antes de fundir?",yd:"Seleccionar Monstruo",md:"\u00bfUsar Reloj de Arena/Rub\u00ed?",zk:"\u00bfUsar Rub\u00ed?",pd:"\u00bfUsar Movilizaci\u00f3n?",od:"\u00bfUsar Poci\u00f3n de Vida?",ld:"Porcentaje de Curaci\u00f3n (%)",wd:"N\u00famero de Ataques",nd:"Intervalo de Ataque (en segundos)",jd:"Ataques Realizados",kd:"Reloj de Arena Restante",ud:"Nota: Usa pociones de vida para curar, no comida.",vd:"Nota: Si los ataques se detienen prematuramente, intenta 'Reiniciar Ataques'.",zd:"Comenzar",
xd:"Reiniciar",Ad:"Detener",Bd:"Configuraci\u00f3n de Expedici\u00f3n (Clic para minimizar)",qd:"Monstruo 1",rd:"Monstruo 2",sd:"Monstruo 3",td:"Monstruo 4",Ik:"Reparar antes de fundir?",yh:"Esta opci\u00f3n usar\u00e1 cervisia cuando tu premium expire.",Ri:"Esta opci\u00f3n activa y selecciona aceites de las recompensas de los dioses. Puede usar los aceites n\u00famero 1 y n\u00famero 3 en el personaje, pero el n\u00famero 2 solo ser\u00e1 recogido para los paquetes.",wh:"Esta opci\u00f3n usar\u00e1 buffs en el momento que establezcas. Encontrar\u00e1 buffs en los paquetes y los aplicar\u00e1 al personaje.",
ni:"Esta opci\u00f3n te llevar\u00e1 al inframundo. No olvides activar el Inicio de Sesi\u00f3n Autom\u00e1tico desde la pesta\u00f1a de Extras, de lo contrario podr\u00edas desconectarte al entrar al inframundo [Error del Juego]",$b:"Normalmente, el bot elige de 3 a 6 intentos aleatorios para atacar en la lista de arena. Si activas esta opci\u00f3n, recorrer\u00e1 tu lista hasta que pueda atacar a alguien. Esto puede llevar algo de tiempo.",oj:"Esta opci\u00f3n es solo para licencias premium. Simula el ataque antes de atacar a un usuario para un ratio de victoria del 75%.",
yc:"No necesitas activar el interruptor principal de subastas para habilitar esta opci\u00f3n.",fk:"Esta opci\u00f3n refrescar\u00e1 la p\u00e1gina cada segundo cuando la subasta est\u00e9 en estado -Muy Corto- para ofertar constantemente y ganar la subasta.",Ij:"Si ninguna de las condiciones de fundici\u00f3n se cumple, fundir\u00e1 aleatoriamente. Aseg\u00farate de seleccionar tipo de objeto y color.",Jj:"Esta opci\u00f3n solo fundir\u00e1 art\u00edculos del inventario. Ignorar\u00e1 los art\u00edculos en los paquetes.",
Va:"Art\u00edculos de Subasta",af:"Art\u00edculos de Mercenario",Ub:"Art\u00edculos de la Tienda",hh:"Art\u00edculos \u00danicos",Ej:"Establecer fondo en negro [Aumenta el rendimiento]",Fj:"Mover los botones de GLDbot a la parte inferior izquierda?",zh:"Atacar al circo sin sanar",dk:"\u00bfRecoger oro de los paquetes si es necesario?",ek:"Se ha recogido oro de los paquetes para entrenamiento",Jl:"No se ha encontrado oro en los paquetes para entrenamiento",ak:"Objetos Reparados",Uj:"Ataques en la Arena",
Wj:"Ataques en el Circo",pc:"Objetos Reiniciados",Zj:"Ataques en Expediciones",Yj:"Ataques en Mazmorras",bk:"Ataques en el Inframundo",Vj:"Dinero Ganado en la Arena",Xj:"Dinero Ganado en el Circo",Hl:"Objetos Fundidos",$j:"Oro Reciclado",ei:"Batalla de Gremio",gi:"Configuraci\u00f3n del Gremio",bl:"Atacar\u00e1 gremios al azar.",fi:"Nombre del Gremio",di:"Atacar Guilds Aleatoriamente",xh:"Restablecer Estad\u00edsticas",nl:'GLDbot: usa los dados para actualizar la caja misteriosa y encontrar objetos valiosos antes de abrirla (por ejemplo, disfraces). Haz clic en "Iniciar" para abrir los cofres.',
kc:"Madera",hc:"Cobre",ic:"Hierro",jc:"Cuero",xi:"Hilo de lana",pi:"Bolas de algod\u00f3n",si:"C\u00e1\u00f1amo",ri:"Tiras de gasa",ui:"Lino",ti:"Yute",wi:"Tiras de terciopelo",vi:"Hilo de seda",Ei:"Pelaje",yi:"Astilla \u00f3sea",Hi:"Escama",Bi:"Garra",Di:"Colmillo",Ci:"Escama de drag\u00f3n",zi:"Cuerno de toro",Gi:"Gl\u00e1ndula venenosa",Ai:"Pelaje de Cerbero",Fi:"Escama de Hidra",Ii:"Pluma de Esfinge",Ji:"Piel de Tif\u00f3n",ai:"Lapisl\u00e1zuli",Vh:"Amatista",Uh:"\u00c1mbar",Wh:"Aguamarina",bi:"Safiro",
Zh:"Granate",Yh:"Esmeralda",Xh:"Diamante",$h:"Jaspe",ci:"Sugilita",Ph:"Veneno de escorpi\u00f3n",Sh:"Tintura de la resistencia",Lh:"Ant\u00eddoto",Kh:"Adrenalina",Rh:"Tintura de la inspiraci\u00f3n",Oh:"Poci\u00f3n de percepci\u00f3n",Mh:"Esencia de reflejos",Nh:"Frasco de carisma",Th:"Agua del olvido",Qh:"Esencia de alma",Aj:"Sello acu\u00e1tico",uj:"Runa protectora",sj:"Grabado terrestre",zj:"T\u00f3tem curativo",yj:"Talism\u00e1n de poder",wj:"Piedra de la fortuna",tj:"Pedernal",xj:"Runa de la tormenta",
vj:"Runa de las sombras",Ui:"Cristal",Ti:"Bronce",Yi:"Obsidiana",aj:"Plata",bj:"Azufre",Wi:"Mena de oro",$i:"Cuarzo",Zi:"Platino",Si:"Almandino",Vi:"Cuprita",Xi:"Piedra infernal",th:"\u00bfAtacar aleatoriamente?",uh:'Tambi\u00e9n desactiva la configuraci\u00f3n "Ordenar jugadores en la arena por nivel" en crazy-addon.',Kf:"Aceptar solo misiones basadas en el tipo de dios.",Wa:"Auto Buff",Mc:"\u00bfUsar solo en el infierno?",rf:"Nueva Regla",pf:"Nombre Contiene",isUnderworldItem:"\u00bfEs un objeto del inframundo?",
Ud:"Ignorar Materiales",lk:"\u00bfUsar Oraci\u00f3n?",nh:"Usar Sacrificio",hk:"Usar Tela para entrar en el Inframundo",eh:"\u00bfCuando est\u00e9s en el inframundo, solo aceptar misiones relacionadas con el inframundo?",dh:"Si est\u00e1 habilitado, necesitas ingresar los nombres de los objetos del inframundo. Si el bot encuentra estos objetos en el inframundo, aceptar\u00e1 la misi\u00f3n.",Pk:"Objeto de Misi\u00f3n del Inframundo",Zk:"Introduzca el nombre del material",wk:"\u00a1El robot adora los dados! Le ayudan a encontrar ropa en los cofres. Pero si no hay dados, el robot abre los cofres de todos modos, con la esperanza de encontrar ropa genial (\u00a1pero puede que no encuentre nada!)",
Hj:"\u00bfFusionar Cajas de Bot\u00edn?",ad:"Habilitar Arena",Cf:"\u00bfPriorizar lista de arenas?",Df:"\u00bfPriorizar lista de circos?",Tc:"Desactivar men\u00fa de registro",Yf:"Valor m\u00ednimo de recompensa en oro",Lf:"Si est\u00e1 habilitado, el Enfoque en misiones seguir\u00e1 el camino m\u00e1s corto para terminar el calabozo.",ug:"\u00bfLanzar dados autom\u00e1ticamente?",vg:"Usa el lanzamiento de dados con cautela, seguir\u00e1 usando el primer dado hasta que desactives la opci\u00f3n.",
cg:"Progreso de b\u00fasqueda",Sf:"El tiempo de enfriamiento para la reparaci\u00f3n por defecto es de 10 minutos.",lf:"Condici\u00f3n m\u00ednima",Rc:"Art\u00edculo actual en el banco de trabajo [Borrar si el bot se detiene inesperadamente]",oe:"Recursos de forja almacenados en el horreum con \u00e9xito.",ke:"Comprobando el mercado para art\u00edculos...",Ab:"Art\u00edculo movido al banco de trabajo.",Ce:"Art\u00edculo reparado y equipado con \u00e9xito.",De:"Art\u00edculo reparado con \u00e9xito.",
Dk:"La reparaci\u00f3n fall\u00f3. La p\u00e1gina se actualizar\u00e1.",ze:"Recogiendo materiales...",Me:"Esperando reparaci\u00f3n...",Be:"La reparaci\u00f3n ha comenzado para .",Ba:"Reparaci\u00f3n: Moviendo el art\u00edculo del inventario a la bolsa",Ae:"Reparaci\u00f3n: Moviendo el art\u00edculo del banco de trabajo al paquete.",sb:"No se pudieron encontrar suficientes materiales. Desactivando la ranura de reparaci\u00f3n ",we:"Buscando art\u00edculos para comprar y ocultar oro en la subasta...",
he:"Comprobando los art\u00edculos caducados en los paquetes...",ie:"Art\u00edculo reseteado con \u00e9xito.",je:"Sin espacio vac\u00edo o oro para resetear.",pe:"\u00a1Aseg\u00farate de tener derechos de venta en el mercado de la guild!",ub:"No hay suficiente oro o ning\u00fan art\u00edculo para comprar. Esperando 30 segundos para actualizar.",wb:"La tienda ha sido actualizada.",xb:"Error durante la curaci\u00f3n.",se:"Sin Rub\u00ed o Tela, desactivando las opciones.",te:"No se encontr\u00f3 ning\u00fan art\u00edculo de curaci\u00f3n en los paquetes.",
yb:"No se encontraron art\u00edculos adecuados",ue:"Se han recogido alimentos. Finalizando el proceso.",ve:"Se ha recogido al menos un alimento. Finalizando el proceso.",zb:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",qe:"Obteniendo alimentos de los paquetes.",re:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",vb:"No hay m\u00e1s art\u00edculos de curaci\u00f3n. Esperando 30 segundos.",tb:"Puntos de vida recuperados.",Aa:"\u00a1No hay nada que hacer, as\u00ed que voy a rezar!",
Ie:"Voy a actualizar en 60 segundos para revisar mi salud y Villa Medici.",Je:"Esperando Villa Medici, actualizando en 60 segundos.",Ke:"Sal\u00ed del inframundo.",Le:"Voy a actualizar en 60 segundos para revisar mi salud.",xe:"Comprobando aceites divinos...",ye:"Los aceites divinos han sido recogidos.",ya:"Atacado con \u00e9xito al jugador en la ARENA: ",za:"Atacado con \u00e9xito al jugador en el CIRCO: ",fe:"\u00a1Comprobando subasta! Por favor, espere...",ge:"Pujando por art\u00edculos. Por favor, espere...",
Ee:"Art\u00edculo fundido autom\u00e1ticamente: ",Fe:"Fundiendo art\u00edculo: ",Ge:"No hay suficiente oro para fundir. Oro requerido: ",He:"FUNDIR: Buscando art\u00edculos para fundir...",Ek:"Buscando art\u00edculos para fundir...",le:"Comprobando disponibilidad de disfraces...",ne:"Donado : ",me:"Lanzando dados...",Hd:"Underworld Farm [Manual, Beta]",Gd:"Farm Location",Id:"Tenga en cuenta: active esta funci\u00f3n despu\u00e9s de desbloquear la criatura que desea atacar, no atacar\u00e1 autom\u00e1ticamente para desbloquear el monstruo.",
Fd:"Farm Enemy",Fc:"Inicio Autom\u00e1tico",Gc:"Necesitas permitir las ventanas emergentes desde la pantalla del lobby de GameForge. Consulta la documentaci\u00f3n sobre c\u00f3mo hacerlo.",zf:"Pausar Bot",Af:"Pausar Bot en (Minutos)",Dd:"Fecha de Expiraci\u00f3n",uf:"\u00bfComprar solo comida?",vf:"Si activas esto, el bot ignorar\u00e1 tus selecciones y comprar\u00e1 comida autom\u00e1ticamente sin ingresar nada.",Ib:"M\u00e1ximo de oro total para gastar",Hb:"M\u00e1ximo de oro por comida para gastar",
tf:"El bot verificar\u00e1 los aceites cada 60 minutos",Ng:"Establece un temporizador para verificar los tiempos de fundici\u00f3n.",Kg:"Establece un temporizador para verificar la fundici\u00f3n cuando no tengas oro.",Mg:"Establece un temporizador para verificar la fundici\u00f3n si no tienes el art\u00edculo disponible.",Fg:"Establece un temporizador para reparar y verificar tus objetos.",Eg:"Establece un temporizador para verificar el oro en el mercado de la hermandad.",Ag:"Establece un temporizador para la opci\u00f3n de retenci\u00f3n de oro en la subasta.",
wg:"Establece un temporizador para verificar la lista de PVP en la arena para atacar.",Bg:"Establece un temporizador para verificar la lista de PVP en el circo para atacar.",Tg:"Establece un temporizador para entrenar tus estad\u00edsticas.",Hg:"Establece un temporizador para reiniciar los objetos caducados.",Rg:"Establece un temporizador para almacenar los materiales de forja en el horreo.",yg:"Establece un temporizador para verificar la subasta de gladiadores y mercenarios.",Jg:"Establece un temporizador para buscar objetos en la subasta y la tienda.",
Cg:"Establece el temporizador para enviar donaciones a la hermandad.",Md:"Oro Movido",Yc:"No vender art\u00edculos de la lista de fundici\u00f3n y subasta.",dg:"Automatizaci\u00f3n de la Tienda",fg:"Configuraci\u00f3n de B\u00fasqueda de Objetos",eg:"Utiliza esta herramienta para buscar objetos. Simplemente agrega los objetos a la lista, especifica la cantidad de tela y comienza la b\u00fasqueda.",gg:"Telas a Usar:",hg:"\u00bfCu\u00e1ntas telas usar?",ja:"Full Ingresa el Nombre del Objeto",Tb:"Ingresa el Nivel del Objeto",
jg:"Calidad del Objeto",ig:"Nombre del Objeto Aqu\u00ed",kg:"Comenzar B\u00fasqueda",lg:"Saltar y Continuar",mg:"Detener B\u00fasqueda",Jd:"\u00bfComprar lo m\u00e1s barato o lo m\u00e1s caro?",nf:"M\u00e1s Caros",Oc:"M\u00e1s Baratos",ga:"Selecciona una Opci\u00f3n",cd:"Pod\u015bwietl przedmioty z Podziemia",Kd:"\u00bfCentrarse en la b\u00fasqueda",Ll:"\u00bfUsar Ruby si no hay tela",Xa:"Evita atacar a las mismas personas para no ser reportado. Ser reportado aumenta las posibilidades de ser baneado.",
Al:"\u00bfDerretir verde?",Ff:"\u00bfNo aceptar misiones aleatorias si se han introducido filtros?",lc:"Calidad m\u00e1xima del material a utilizar",Hh:"Habilitar la b\u00fasqueda de mercenarios",jl:"Haz clic en `Vender Todo Seleccionado` para vender todos los elementos. Aseg\u00farate de tener espacio vac\u00edo de 2x3 en tu primera (1) bolsa. Para recoger oro en masa, filtra el oro y usa `Seleccionar Seleccionados o Seleccionar Todo`.",Tj:"\ud83d\udd25 : A\u00f1ade elemento a la lista de fundici\u00f3n.",
vh:"\ud83d\udd28 : A\u00f1ade elemento a la lista de subastas.",qj:"Actualiza la tienda con tela cuando est\u00e9 llena (Deber\u00e1s vender de nuevo despu\u00e9s)",ej:"P\u00e1gina:",lj:"Detener",jj:"Vender Esta P\u00e1gina",gj:"Seleccionar Seleccionados",fj:"Seleccionar Todo",mj:"Configuraci\u00f3n de Empaquetado Autom\u00e1tico",kj:"Enviar Recursos",hj:"Vender Todo Seleccionado",ra:"Tipo de Objeto",W:"Armas",S:"Escudos",M:"Armaduras",P:"Cascos",O:"Guantes",N:"Botas",V:"Anillos",U:"Amuletos",pa:"Utilizables (Comida)",
wa:"Mejoras",cj:"Potenciadores",ta:"Recetas",sa:"Mercenarios",va:"Herramientas de Forja",ua:"Pergaminos",Oa:"Refuerzos",Ma:"Objetos de Evento",Na:"Materiales de Forja",dj:"Oro",T:"Todo",ql:"Calidad",X:"Blanco",B:"Verde",A:"Azul",C:"Morado",G:"Naranja",R:"Rojo",ij:"Opciones de Venta",Gj:"\u00bfIgnorar Combinaci\u00f3n de Prefijo/Sufijo?",hi:"\u00bfCu\u00e1nta comida comprar/recoger?",Ch:"Normal",Bh:"Intermedio",Ah:"Dif\u00edcil",Ja:"Est\u00e1ndar",tl:"Reparar Correcci\u00f3n de Atascos",Bk:"Desactiva la entrada al Infierno si deseas desactivar la Mazmorra/Circo/Arena. Si entraste al Infierno manualmente, deber\u00e1s activar el Modo Infierno.",
Pc:"Wybierz kostium z Za\u015bwiat\u00f3w",qh:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",Wg:"Indica cu\u00e1ntas veces deseas entrenar las estad\u00edsticas y establece sus prioridades. El bot no entrenar\u00e1 a menos que se establezca una prioridad. Si hay una prioridad configurada pero no quedan m\u00e1s estad\u00edsticas por entrenar, el bot continuar\u00e1 con la estad\u00edstica seleccionada.",Wk:"Quest",yl:"Fundir",El:"Configuraci\u00f3n de Fundici\u00f3n",Qj:"Objetos Fundidos",
Fl:"Agrega Prefijos o Sufijos, una vez que los encuentre en los paquetes, se fundir\u00e1n autom\u00e1ticamente:",Dl:"Objeto en Fundici\u00f3n:",cc:"Haz clic en el objeto que deseas reparar. Este sistema reparar\u00e1 a tus dos personajes, el principal y el primer personaje de circo. Debes tener al menos 10000 de oro para que comience la reparaci\u00f3n. Si se queda atascado en un objeto, significa que no tienes material para arreglarlo. Tambi\u00e9n trata de hacer espacio en tu inventario. El bot iniciar\u00e1 la reparaci\u00f3n una vez que el objeto tenga un %0 de durabilidad.",
Qk:"Aplicar solo a Mercenarios",Tk:"La subasta solo pujar\u00e1 cuando el mercado est\u00e9 cerca del final.",Sk:"Aseg\u00farate de que la SEGUNDA PESTA\u00d1A DEL INVENTARIO est\u00e9 vac\u00eda y tenga 10K de oro. El bot encontrar\u00e1 y colocar\u00e1 el objeto en la segunda pesta\u00f1a y luego, la pr\u00f3xima vez que se actualice la p\u00e1gina, fundir\u00e1 el objeto. La fundici\u00f3n se revisar\u00e1 cada 5-10 minutos.",ki:"Curar & Buffs",ul:"No hay suficiente oro para fundir. Oro requerido:",
xl:"Saltando puja: El miembro del gremio ya ha pujado por el objeto ",wl:"Saltando puja: Ya has pujado por el objeto ",advanced:"Avanzado",arena:"Arena",na:"Auto Ataque",ac:"Evitar Ataque",la:"Agregar Jugador",ma:"Agregar Nombre de Jugador (Same Server)",dl:"\u00bfDetener el bot si se queda sin comida?",circusTurma:"Circo Turma",Dh:"Dificultad",dungeon:"Mazmorra",Eh:"Configuraci\u00f3n de Mazmorra",eventExpedition:"Expedici\u00f3n de Evento",expedition:"Expedici\u00f3n",Ih:"Configuraci\u00f3n de Expedici\u00f3n",
Bj:"Seleccionar Monstruo",gl:"M\u00e1s Alto",el:"Coloca tus objetos de curaci\u00f3n en la primera p\u00e1gina de tu inventario",fc:"En",sg:"Almacenar Oro",tg:"\u00bfAlmacenar Oro en Subasta?",ag:"\u00bfUsar Ropa de Trabajo para renovar la Tienda?",Kk:"Seleccionar Objetos para Reiniciar",Uf:"Reiniciar Objetos Expirados",Ob:"Nota: Al habilitar esta opci\u00f3n, el bot vender\u00e1 los objetos pr\u00f3ximos a expirar de los Paquetes al Mercado del Gremio y luego los cancelar\u00e1 para reiniciar el tiempo de vencimiento. Se requiere el Gremio. Aseg\u00farate de tener un espacio vac\u00edo de 3x3 en tus bolsas.",
Bf:"Pausar el bot aleatoriamente para funcionar como [Fase de Pruebas]:",da:"Mantener Oro: El bot mantendr\u00e1 este oro en la bolsa:",Ze:"Oro M\u00e1ximo: El bot gastar\u00e1 cuando el oro sea mayor que",Zf:"El bot pujar\u00e1 por art\u00edculos aleatorios",qc:"Agregar Retraso Aleatorio",rc:"Puedes agregar un retraso al bot aqu\u00ed.",Nb:"Reparar",zl:"\u00bfFundir solo Azules?",Cl:"\u00bfFundir solo P\u00farpuras?",Bl:"\u00bfFundir solo Naranjas?",Rj:"\u00bfFundir Todo en la 2da pesta\u00f1a?",
Sj:"Esto ignorar\u00e1 las selecciones de colores",Ya:"Limpiar Historial",og:"Fundir",zc:"Search",qf:"Subasta Autom\u00e1tica",Ac:"El uso excesivo de la Subasta podr\u00eda resultar en una prohibici\u00f3n. Se recomienda desactivar otras funciones de oferta para evitar posibles conflictos. Esta caracter\u00edstica ralentizar\u00e1 el bot.",$f:"Buscar en la Subasta de Gladiadores",bg:"Buscar en la Subasta de Mercenarios",Ic:"\u00bfPujar por Comida?",$e:"Puja M\u00e1xima",Jc:"Pujar si el estado es menor que",
Kc:"Objetos Pujados",rk:"Idioma de Subasta",sk:"Seg\u00fan la actualizaci\u00f3n 2.9.4, establece el idioma nuevamente o REINICIA EL BOT. Aseg\u00farate de que todos sean correctos, de lo contrario, no pujar\u00e1.",uc:"Puedes agregar objetos para buscar en el mercado y en la subasta. Tambi\u00e9n mostrar\u00e1 objetos p\u00farpuras en el mercado una vez que agregues un objeto a la lista. Si deseas habilitar la puja autom\u00e1tica, usa las opciones a continuaci\u00f3n",pk:"\u00a1Usa la subasta con precauci\u00f3n!",
qk:"La puja autom\u00e1tica realiza demasiadas solicitudes al servidor y puede causar una prohibici\u00f3n si se usa todo el tiempo.",Rf:"\u00bfRenovar Puntos de Evento con Rub\u00edes?",ed:"\u00bfHabilitar Aceite Autom\u00e1tico?",uk:"\u00bfObtener Aceites Sagrados Autom\u00e1ticamente?",Gk:"Velocidad de Verificaci\u00f3n de Misiones",Ta:"\u00bfAtacar a Miembros del Gremio?",Ra:'Agregar autom\u00e1ticamente a las personas a la lista de "Ataque" cuando se roban m\u00e1s de X ORO.:',Sa:'Agregar autom\u00e1ticamente a las personas a la lista de "Evitar Ataque" cuando pierdas contra ellas.:',
Rb:"Ataques en el Marcador",Yb:"Muy Largo",Bb:"Largo",Jb:"Medio",Vb:"Corto",Zb:"Muy Corto",fd:"Entrar al Inframundo si HP >",Mf:"Velocidad de Verificaci\u00f3n de Misiones",Ef:'El valor predeterminado es "3x". Si el bot causa problemas con las misiones, cambia la velocidad de las misiones seg\u00fan la velocidad de tu servidor.',Nd:"Selecci\u00f3n de Bolsa de Curaci\u00f3n",gd:'Si est\u00e1s renovando puntos manualmente, debes hacer clic en el bot\u00f3n de arriba "Actualizar expedici\u00f3n de evento si est\u00e1 atascada".',
yk:"Debes habilitar al menos una de las siguientes opciones: expedici\u00f3n, mazmorra, arena o circo para comenzar la Expedici\u00f3n de Evento.",Of:"\u00a1Actualiza la Expedici\u00f3n de Evento si est\u00e1 atascada!",lb:"\u00bfCubrir a los Aliados?",Mk:"Deja todas las configuraciones desactivadas si deseas fundir usando paquetes que contienen los elementos de la lista. Sin embargo, a\u00fan puedes elegir colores.",vk:"Personaje(Desactivado) / Mercenario(Activado)",Jk:"\u00bfReparar Ambos?",Nk:"Temporizadores",
Timers:"Ingresa el n\u00famero de minutos para cada temporizador a continuaci\u00f3n o d\u00e9jalo en su valor predeterminado.",Jf:"Ignorar Filtro de Misiones",If:"Ingresa palabras clave para filtrar las misiones que no deseas tomar. You can also use this to accept quests by their reward using keywords.",aa:"Ingresar Palabra Clave",I:"Agregar",Qf:"Eliminar",Qc:"Limpiar",Gf:"Aceptar Filtro de Misiones",Hf:"Ingresa palabras clave para seleccionar qu\u00e9 misiones tomar. Usar esto ignorar\u00e1 los tipos de misiones",
Ha:"\u00bfSaltar Misiones Temporales?",Hk:"Misiones",Cc:"Auto Traje",kh:"\u00bfUsar Traje?",Hc:"Batalla B\u00e1sica",Zc:"Batalla en Mazmorra",Dc:"Bot solo usar\u00e1 Dis Pater Normal y Medium si tus puntos de expedici\u00f3n/mazmorra son 0.",Pd:"Configuraci\u00f3n de Sanaci\u00f3n Infernal",tc:"\u00bfAtacar al Jefe cuando est\u00e9 disponible?",rb:"La opci\u00f3n de ataque a la Liga se desactivar\u00e1 despu\u00e9s de 5 intentos fallidos.",Sd:"Aceites Sagrados",kf:"Nombre del Objeto",ea:"Nivel M\u00ednimo del Objeto",
Ga:"Calidad M\u00ednima del Objeto",sc:"Aplicar/Restablecer Temporizador",Vd:"Ignorar Combinaci\u00f3n de Prefijo/Sufijo",rh:"S\u00ed",sf:"No",Pa:"Agregar Prefijo",Qa:"Agregar Sufijo",pg:"Lista de Objetos a Ignorar al Fundir",Kb:"Prefijo",Wb:"Sufijo",Wf:"Restablecer Objetos Expirados",qg:"\u00bfFundir al Azar desde los Paquetes?",rg:"Pesta\u00f1a de Fundici\u00f3n",pb:"Extras",xc:"Subasta",Se:"Mercado",Xb:"Temporizadores",Pg:"Fundici\u00f3n",Og:"Fundici\u00f3n si no hay suficiente oro",Lg:"Fundir si no hay objeto",
Ia:"Reparaci\u00f3n",Dg:"Mantener Oro en el Mercado de Gremio",zg:"Mantener Oro en la Subasta",Sg:"Entrenamiento",Gg:"Restablecer Expirados",Qg:"Almacenar en la Forja",xg:"Comprobar Subasta",Ig:"Buscar",v:"Habilitar",mf:"Oro M\u00ednimo",Sb:"Seleccionar Hora",mb:"Donar Oro al Gremio",Uc:"Donar\u00e1 cada 5 minutos. Puedes cambiar el intervalo desde la pesta\u00f1a de temporizadores",Td:"\u00bfCu\u00e1nto deseas donar?",Vc:"Donar cuando tengas m\u00e1s de >",ee:"Menos de <",Tf:"Restablecer Objetos Expirados y Otras Configuraciones",
Vf:"Restablecer en:",Ck:"Mant\u00e9n presionada la tecla Ctrl (Cmd en Mac) para seleccionar varios objetos",Wd:"Importar/Exportar Configuraciones",Ed:"Exportar Configuraciones",Xd:"Importar Configuraciones",cf:"Mensaje a Todos los Jugadores",df:"[Requiere Clave Ultra Premium, mensaje en Discord para obtenerla.]",ef:"Ingresar mensaje para enviar",Sc:"Para scripts personalizados, cont\u00e1ctanos en Discord",gf:"Enviar",hf:"Mostrar Jugadores",ff:"Seleccionar Todos",jf:"Deseleccionar Todos",de:"Aseg\u00farate de que tu inventario tenga suficiente espacio. El tiempo de reutilizaci\u00f3n es de 2 minutos.",
ob:"Habilitar Ataque en el Marcador:",Pb:"Seleccionar Rango para Atacar",Qb:"El bot atacar\u00e1 aleatoriamente desde la lista del marcador.",qb:"Ataque de Liga",nb:"Habilitar Ataque de Liga:",Lb:"Ataque Aleatorio",Mb:"Atacar desde el m\u00e1s bajo al m\u00e1s alto",nk:"El bot evitar\u00e1 atacar a los miembros del gremio por defecto.",Cd:"Ubicaci\u00f3n de Expedici\u00f3n:",Bc:"\u00bfRecoger Bonos Autom\u00e1ticamente?",ng:"\u00bfSaltar al Jefe?",$c:"Ubicaci\u00f3n de Mazmorra:",Xf:"\u00bfReiniciar si pierdes?",
Qd:"Configuraci\u00f3n de Inframundo",Rd:"Configura tus ajustes de porcentaje de curaci\u00f3n desde la pesta\u00f1a de curaci\u00f3n y aseg\u00farate de que est\u00e9 activada. Si ingresar al inframundo te desconecta, ve al lobby y activa la casilla de inicio de sesi\u00f3n autom\u00e1tico.",Od:"Dificultad del Inframundo",Ec:"Entrar Autom\u00e1ticamente al Inframundo: / Inframundo Mode",lh:"\u00bfUsar Movilizaci\u00f3n si los puntos = 0",ph:"\u00bfUsar Rub\u00edes?",hd:"\u00bfSalir del inframundo si no hay puntos?",
Yg:"El bot intentar\u00e1 usar villa medici primero, si no la tienes, usar\u00e1 poci\u00f3n de curaci\u00f3n. No olvides activar el interruptor de Curar.",gh:"El ingreso autom\u00e1tico al inframundo deshabilitar\u00e1 la mazmorra/arena/circo al ingresar al inframundo.",Ok:"Ajustes de Curaci\u00f3n del Inframundo",oh:"\u00bfUsar Villa Medici?",mh:"\u00bfUsar Poci\u00f3n de Curaci\u00f3n?",Ne:"INFO: El bot buscar\u00e1 objetos en el mercado cada ciertos minutos, lo que puede detener los ataques durante la b\u00fasqueda.",
dd:"Habilitar B\u00fasqueda en el Mercado:",Oe:"Intervalo de B\u00fasqueda en el Mercado en Minutos:",Pe:"Se sugieren 10 minutos.",$d:"Ajustes de Objetos:",Yd:"Nombre del Objeto Incluye",H:"Precio M\u00e1ximo",ae:"Tipo de Objeto",Zd:"Rareza del Objeto",Nc:"\u00bfComprar con V\u00ednculo Espiritual?",ce:"Objetos para Comprar",be:"Intentar comprar objetos con paquetes si alguno coincide con el precio m\u00e1ximo ingresado:",Lc:"Objetos Comprados:",ii:"Porcentaje de Curaci\u00f3n",jk:"\u00bfComprar Comida en la Tienda?",
kk:"\u00bfUsar Curaci\u00f3n de Paquete?",gk:"\u00bfUsar Cervisia?",ik:"\u00bfUsar Huevos?",kl:"\u00daltima Vez Usado",location:"Ubicaci\u00f3n",Strength:"Fuerza",Dexterity:"Destreza",Agility:"Agilidad",Constitution:"Constituci\u00f3n",Charisma:"Carisma",Intelligence:"Inteligencia",Ug:"Ajustes de Entrenamiento",Vg:"Selecciona los atributos que deseas entrenar. Se entrenar\u00e1 una vez que tengas suficiente oro.",nc:"Siguiente acci\u00f3n",Pi:"No",Qi:"Normal",ol:"Oponente",pl:"Nivel del Oponente",
pj:"Misiones",random:"Aleatorio",vl:"Ajustes",Gl:"Pronto...",type:"Haz clic en los \u00edconos para activar los tipos de misiones.",Nl:"S\u00ed",D:"Subasta/B\u00fasqueda",oc:"Agregar objetos",ck:"Almacenar Recursos Forjados autom\u00e1ticamente",Il:"Enviar",il:"Intervalo : ",Xk:"Habilitar Puja Autom\u00e1tica",Yk:"No pujar si el miembro del gremio ya ha pujado",Kl:"Tutorial",bc:"Selecciona entre los botones de arriba si deseas enfrentar al oponente de nivel m\u00e1s bajo en la arena o al oponente de nivel m\u00e1s alto. M\u00e1s usuarios ralentizar\u00e1n el bot.",
Rk:"Para empezar, agrega un objeto a la lista (p. ej., `Lucius`). Una vez agregado, la herramienta buscar\u00e1 el objeto y mostrar\u00e1 los resultados de la b\u00fasqueda en el lado izquierdo de la pantalla. Tambi\u00e9n se buscar\u00e1 para fines de subasta autom\u00e1tica. Si habilitas la puja autom\u00e1tica, la herramienta buscar\u00e1 el objeto a intervalos regulares seg\u00fan el n\u00famero que ingreses en el cuadro de intervalo. Si la herramienta encuentra el objeto y tienes suficiente dinero, pujar\u00e1 autom\u00e1ticamente por ti. *Nota* para buscar objetos \u00fanicos en las tiendas, debes agregar al menos 1 objeto aleatorio en la lista de b\u00fasqueda.",
$k:"El n\u00famero de criatura se puede seleccionar desde los botones de arriba. El n\u00famero 1 representa la criatura m\u00e1s a la izquierda. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",Fh:"Selecciona la dificultad de la mazmorra de arriba. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",ji:"Ajustes de Curaci\u00f3n",Gh:"Almacena el oro excedente en el Gremio comprando objetos del mercado del gremio. -> M\u00edn. Oro",
ll:"Mover Todo",ml:"Mover Seleccionados",Uk:"Curaci\u00f3n Autom\u00e1tica",Vk:"Porcentaje de Curaci\u00f3n Autom\u00e1tica",Ml:"Ruby",wf:"Ajustes Generales",Cj:"Vender Todo",Dj:"Vender Seleccionados",ka:"Armas",ha:"Escudos",Z:"Armadura de Pecho",ca:"Cascos",ba:"Guantes",ia:"Zapatos",fa:"Anillos",Y:"Amuletos",jh:"Usables",ih:"Mejoras",Nf:"Recetas",bf:"Pergamino de Mercenario",Pf:"Refuerzos",We:"Vender Comida",Fb:"Cambiar a Comida"},Ih={Ni:"Type de recherche de nid",Li:"Ne rien faire",Mi:"Recherche rapide",
Oi:"Recherche approfondie",nj:"After expedition points are consumed, travel to Germania to consume Dungeon points",mk:"Cliquez ici si la r\u00e9paration se bloque",Ak:"Quand les PV sont en dessous, utilisez soin",yf:"R\u00e9paration Partielle",Ld:"R\u00e9paration Compl\u00e8te",xf:"R\u00e9paration Partielle ou Compl\u00e8te",bd:"Activer la Limite",li:"Limite",mi:"Si vous voulez limiter le nombre de fois que vous souhaitez attaquer l'ennemi, activez cette option et d\u00e9finissez la limite. Le bot continuera \u00e0 attaquer le reste des ennemis apr\u00e8s avoir fini d'attaquer le monstre s\u00e9lectionn\u00e9.",
fh:"Monde Souterrain",Xg:"Am\u00e9liorations du Monde Souterrain",Zg:"Utiliser les pouvoirs des dieux apr\u00e8s \u00eatre entr\u00e9 dans le monde souterrain?",$g:"S\u00e9lectionnez les dieux pour utiliser leurs pouvoirs:",ah:"Utiliser un Buff d'Arme sur l'arme?",bh:"Utiliser un Buff d'Armure sur l'\u00e9quipement suivant:",xk:"Le temps de recharge est de 30 minutes. Si vous n'avez pas de costume, le bot r\u00e9initialisera le temps de recharge \u00e0 0.",Lk:"S\u00e9lectionner les Couleurs",Za:"Forge de Vulcain",
cb:"Bouclier de Terre de Feronia",eb:"Puissance Fluide de Neptune",fb:"Libert\u00e9 A\u00e9rienne d'Aelous",gb:"Brouillard Mortel de Pluton",hb:"Souffle de Vie de Junon",ib:"Armure d'\u00c9cailles des Montagnes de Col\u00e8re",jb:"Yeux d'Aigle",kb:"V\u00eatement d'Hiver de Saturne",$a:"Armure de Taureau de Bubona",ab:"V\u00eatements de Voleur de Mercure",bb:"Robe de Lumi\u00e8re de R\u00e2",Xc:"N`entrez pas dans le monde souterrain avec le costume des enfers",Wc:"Si vous ne voulez pas entrer dans le monde souterrain en portant le costume des enfers, activez cette option",
Ve:"Paquets",Qe:"Inventaire",K:"Prix Min.",J:"Combien",Eb:"Vendre des Articles",Db:"Rechercher dans",Re:"Couleur du Mat\u00e9riau",Cb:"Couleur de l`Article",Ye:"Entrep\u00f4t",Fa:"Basculer vers Mat\u00e9riaux",Gb:"Basculer vers Articles",Xe:"Vendre des Mat\u00e9riaux",Ca:"Veuillez entrer un nom d`article valide, une fourchette de prix et une quantit\u00e9.",Da:"Aucun article correspondant trouv\u00e9 dans les emplacements de recherche s\u00e9lectionn\u00e9s.",Ea:"Tous les articles ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",
Fk:"Tous les mat\u00e9riaux ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",Te:"Si vous souhaitez vendre des articles \u00e0 un prix fixe, vous pouvez entrer la m\u00eame valeur pour le prix minimum et maximum.",Ue:"Cette fonctionnalit\u00e9 est encore exp\u00e9rimentale, utilisez-la avec prudence. Si vous ne fixez pas un prix, les articles seront list\u00e9s al\u00e9atoirement entre le prix minimum et maximum que vous entrez.",tk:"D\u00e9finit le maximum d`or que le bot d\u00e9pensera par cycle.",
Ua:"Le bot commencera \u00e0 faire des offres sur tout article de nourriture, si activ\u00e9. Vous n`avez pas besoin d`activer les bascules gladiateur/mercenaire.",vc:"Le bot ne fera pas d`offres sur les ench\u00e8res des alli\u00e9s.",wc:"Ignorer la combinaison Pr\u00e9fixe/Suffixe lors de la recherche d`un objet \u00e0 la vente aux ench\u00e8res.",Kj:"S\u00e9lectionnez les types d\u2019objets que vous souhaitez fondre.",Lj:"S\u00e9lectionnez les couleurs que vous souhaitez fondre.",Mj:"S\u00e9lectionnez le niveau des objets que vous souhaitez fondre.",
Nj:"S\u00e9lectionnez le marteau que vous voulez utiliser.",Oj:"Notez que le cercle vert et rouge \u00e0 c\u00f4t\u00e9 de la premi\u00e8re case sert \u00e0 activer/d\u00e9sactiver la r\u00e8gle.",Pj:"Si vous voulez fondre al\u00e9atoirement n\u2019importe quelle couleur ou type, vous pouvez activer `Fondre al\u00e9atoirement si aucune condition n\u2019est remplie? (Derni\u00e8re option activ\u00e9e dans la vid\u00e9o du tutoriel)",rj:"R\u00e9parer avant de fondre",yd:"S\u00e9lectionner Monstre",
md:"Utiliser Sablier/Rubis?",zk:"Utiliser Rubis?",pd:"Utiliser Mobilisation?",od:"Utiliser Potion de Vie?",ld:"Pourcentage de Soin (%)",wd:"Nombre d'Attaques",nd:"Intervalle d'Attaque (en secondes)",jd:"Attaques Effectu\u00e9es",kd:"Sabliers Restants",ud:"Note : Utilise des potions de vie pour gu\u00e9rir, pas de nourriture.",vd:"Note : Si les attaques s'arr\u00eatent pr\u00e9matur\u00e9ment, essayez 'R\u00e9initialiser les Attaques'.",zd:"D\u00e9marrer",xd:"R\u00e9initialiser",Ad:"Arr\u00eater",
Bd:"Param\u00e8tres d'Exp\u00e9dition (Cliquez pour minimiser)",qd:"Monstre 1",rd:"Monstre 2",sd:"Monstre 3",td:"Monstre 4",Ik:"R\u00e9parer avant de fondre",yh:"Cette option utilisera cervisia lorsque votre premium expirera.",Ri:"Cette option permet d'activer et de choisir les huiles parmi les r\u00e9compenses des dieux. Elle peut utiliser les huiles num\u00e9ro 1 et 3 sur le personnage, mais la num\u00e9ro 2 ne sera prise que pour les paquets.",wh:"Cette option utilisera des buffs au moment que vous avez fix\u00e9. Elle trouvera les buffs dans les paquets et les appliquera au personnage.",
ni:"Cette option vous m\u00e8nera aux enfers. N'oubliez pas d'activer la Connexion Automatique depuis l'onglet Extras, sinon vous pourriez \u00eatre d\u00e9connect\u00e9 en entrant aux enfers [Bug du Jeu]",$b:"Le bot choisit normalement entre 3 et 6 essais al\u00e9atoires pour attaquer la liste d'ar\u00e8ne. Si vous activez cette option, il parcourra votre liste jusqu'\u00e0 ce qu'il puisse attaquer quelqu'un. Cela peut prendre du temps.",oj:"Cette option est uniquement pour les licences premium. Elle simule l'attaque avant d'attaquer un utilisateur pour un taux de victoire de 75%.",
yc:"Vous n'avez pas besoin d'activer l'interrupteur principal de l'ench\u00e8re pour activer cette option.",fk:"Cette option rafra\u00eechira la page chaque seconde quand l'ench\u00e8re est en \u00e9tat -Tr\u00e8s Court- pour ench\u00e9rir constamment et gagner l'ench\u00e8re.",Ij:"Si aucune des conditions de fusion n'est remplie, il fusionnera al\u00e9atoirement. Assurez-vous de s\u00e9lectionner le type et la couleur de l'objet.",Jj:"Cette option ne fusionnera que les objets de l'inventaire. Elle ignorera les objets dans les paquets.",
Va:"Articles aux Ench\u00e8res",af:"Articles de Mercenaire",Ub:"Articles de Boutique",hh:"Articles Uniques",Ej:"D\u00e9finir le fond en noir [Augmente les performances]",Fj:"D\u00e9placer les boutons GLDbot en bas \u00e0 gauche?",zh:"Attaquer le cirque sans soigner",dk:"Prendre l'or des paquets si n\u00e9cessaire?",ek:"L'or a \u00e9t\u00e9 pris des paquets pour l'entra\u00eenement",Jl:"Aucun or n'a \u00e9t\u00e9 trouv\u00e9 dans les paquets pour l'entra\u00eenement",ak:"Objets R\u00e9par\u00e9s",
Uj:"Attaques en Ar\u00e8ne",Wj:"Attaques au Cirque",pc:"Objets R\u00e9initialis\u00e9s",Zj:"Attaques en Exp\u00e9dition",Yj:"Attaques en Donjon",bk:"Attaques dans l'Underworld",Vj:"Argent Gagn\u00e9 en Ar\u00e8ne",Xj:"Argent Gagn\u00e9 au Cirque",Hl:"Objets Fondus",$j:"Or Recycl\u00e9",ei:"Bataille de Guilde",gi:"Param\u00e8tres de Guilde",fi:"Guild Name",bl:"Attaquera les guildes au hasard.",xh:"R\u00e9initialiser les Statistiques",sg:"Stockage de l'Or",di:"Attaquer une Guilde Al\u00e9atoire",nl:"GLDbot\u00a0: utilisez les d\u00e9s pour rafra\u00eechir la bo\u00eete myst\u00e8re et trouver des objets de valeur avant de les ouvrir (etc. Costumes). Cliquez sur \u00ab\u00a0D\u00e9marrer\u00a0\u00bb pour ouvrir les coffres.\u00a0",
kc:"Bois",hc:"Cuivre",ic:"Fer",jc:"Cuir",xi:"Fil de laine",pi:"Boule de coton",si:"Chanvre",ri:"Bande de gaze",ui:"Toile de lin",ti:"Jute",wi:"Bande de velours",vi:"Fil de soie",Ei:"Fourrure",yi:"\u00c9clat osseux",Hi:"\u00c9caille",Bi:"Griffe",Di:"Canine",Ci:"\u00c9caille de dragon",zi:"Corne de taureau",Gi:"Glande \u00e0 venin",Ai:"Touffe de poils de Cerb\u00e8re",Fi:"\u00c9caille d`Hydre",Ii:"Plume du Sphinx",Ji:"Cuir de Typhon",ai:"Lapis-lazuli",Vh:"Am\u00e9thyste",Uh:"Ambre jaune",Wh:"Aigue-marine",
bi:"Safir",Zh:"Grenat",Yh:"\u00c9meraude",Xh:"Diamant",$h:"Jaspe",ci:"Sugilith",Ph:"Venin de scorpion",Sh:"Teinture d`endurance",Lh:"Antidote",Kh:"Adr\u00e9naline",Rh:"Teinture de r\u00e9v\u00e9lation",Oh:"Potion de perception",Mh:"Essence de reflet",Nh:"Flacon du rayonnement",Th:"Eau de l`oubli",Qh:"Essence d`\u00e2me",Aj:"Sceau aquatique",uj:"Rune protectrice",sj:"Gravure terrestre",zj:"Totem gu\u00e9risseur",yj:"Talism\u00e1n de puissance",wj:"Pierre de fortune",tj:"Pierre du feu",xj:"Rune temp\u00e9tueuse",
vj:"Rune t\u00e9n\u00e9breuse",Ui:"Cristal",Ti:"Bronze",Yi:"Obsidienne",aj:"Argent",bj:"Soufre",Wi:"Minerai d`or",$i:"Quartz",Zi:"Platine",Si:"Almandin",Vi:"Cuprit",Xi:"Pierre infernale",th:"Attaquer al\u00e9atoirement?",uh:'D\u00e9sactivez \u00e9galement le param\u00e8tre "Trier les joueurs dans l\'ar\u00e8ne par niveau" dans crazy-addon.',Kf:"Accepter uniquement les qu\u00eates bas\u00e9es sur le type de dieu.",Wa:"Buff Automatique",Mc:"Utiliser uniquement en enfer?",rf:"Nouvelle R\u00e8gle",pf:"Le Nom Contient",
isUnderworldItem:"Est-ce un objet du monde souterrain?",Ud:"Ignorer les Mat\u00e9riaux",lk:"Utiliser la pri\u00e8re",nh:"Utiliser le sacrifice",hk:"Utiliser des v\u00eatements pour entrer dans le monde souterrain",eh:"Lorsque vous \u00eates dans le monde souterrain, n`acceptez que les qu\u00eates li\u00e9es au monde souterrain ?",dh:"Si activ\u00e9, vous devez entrer les noms des objets du monde souterrain. Si le bot trouve ces objets dans le monde souterrain, il acceptera la qu\u00eate.",Pk:"Objet de Qu\u00eate du Monde Souterrain",
Zk:"Entrez le nom du mat\u00e9riau",wk:"Le robot adore les d\u00e9s ! Ils l'aident \u00e0 trouver des v\u00eatements dans les coffres. Mais s'il n'y a pas de d\u00e9s, le robot ouvre quand m\u00eame les coffres, en esp\u00e9rant trouver des v\u00eatements cool (mais il pourrait ne rien trouver !)",Hj:"Fondre les coffres",ad:"Activer l'ar\u00e8ne",Cf:"Prioriser la liste des ar\u00e8nes ?",Df:"Prioriser la liste des cirques ?",Tc:"D\u00e9sactiver le menu de journalisation",Yf:"Valeur minimale de r\u00e9compense en or",
Zf:"Le robot ench\u00e9rira sur des articles al\u00e9atoires.",Lf:"Si activ\u00e9, le Focus sur les qu\u00eates suivra le chemin le plus court pour terminer le donjon.",ug:"Lancer les d\u00e9s automatiquement ?",vg:"Utilisez le lancer de d\u00e9s avec prudence, il continuera \u00e0 utiliser le premier d\u00e9 jusqu'\u00e0 ce que vous d\u00e9sactiviez l'option.",cg:"Progression de la recherche",Sf:"Le temps de recharge pour la r\u00e9paration par d\u00e9faut est de 10 minutes.",lf:"Condition minimale",
Rc:"Article actuel sur l'\u00e9tabli [Effacer si le bot se met en pause de mani\u00e8re inattendue]",oe:"Ressources de forge stock\u00e9es avec succ\u00e8s dans l'horreum.",ke:"V\u00e9rification du march\u00e9 pour les articles...",Ab:"Article d\u00e9plac\u00e9 sur l'\u00e9tabli.",Ce:"Article r\u00e9par\u00e9 et \u00e9quip\u00e9 avec succ\u00e8s.",De:"Article r\u00e9par\u00e9 avec succ\u00e8s.",Dk:"La r\u00e9paration a \u00e9chou\u00e9. La page sera rafra\u00eechie.",ze:"Ramassage des mat\u00e9riaux...",
Me:"En attente de r\u00e9paration...",Be:"La r\u00e9paration a commenc\u00e9 pour .",Ba:"R\u00e9paration : D\u00e9placement de l'article de l'inventaire vers le sac",Ae:"R\u00e9paration : D\u00e9placement de l'article de l'\u00e9tabli vers le paquet.",sb:"Impossible de trouver suffisamment de mat\u00e9riaux. D\u00e9sactivation de l'emplacement de r\u00e9paration ",we:"Recherche d'articles \u00e0 acheter pour cacher de l'or aux ench\u00e8res...",he:"V\u00e9rification des articles expir\u00e9s dans les paquets...",
ie:"R\u00e9initialisation de l'article r\u00e9ussie.",je:"Aucun espace vide ou or pour r\u00e9initialiser.",pe:"Assurez-vous d'avoir les droits de vente sur le march\u00e9 de guilde !",ub:"Pas assez d'or ou aucun article \u00e0 acheter. Attente de 30 secondes pour rafra\u00eechir.",wb:"Le magasin a \u00e9t\u00e9 rafra\u00eechi.",xb:"Erreur lors de la gu\u00e9rison.",se:"Pas de Rubis ou de Tissu, d\u00e9sactivation des options.",te:"Aucun article de gu\u00e9rison trouv\u00e9 dans les paquets.",yb:"Aucun article appropri\u00e9 trouv\u00e9",
ue:"Les aliments ont \u00e9t\u00e9 ramass\u00e9s. Fin du processus.",ve:"Au moins un aliment a \u00e9t\u00e9 ramass\u00e9. Fin du processus.",zb:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",qe:"Obtention de la nourriture des paquets.",re:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",vb:"Plus d'articles de gu\u00e9rison. Attente de 30 secondes.",tb:"Points de vie r\u00e9cup\u00e9r\u00e9s.",Aa:"Rien \u00e0 faire alors je vais prier !",
Ie:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9 et Villa Medici.",Je:"En attente de Villa Medici, actualisation dans 60 secondes.",Ke:"Quitt\u00e9 les Enfers.",Le:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9.",xe:"V\u00e9rification des huiles divines...",ye:"Les huiles divines ont \u00e9t\u00e9 ramass\u00e9es.",ya:"Attaque r\u00e9ussie du joueur dans l'AR\u00c8NE : ",za:"Attaque r\u00e9ussie du joueur dans le CIRQUE : ",fe:"V\u00e9rification des ench\u00e8res ! Veuillez patienter...",
ge:"Mise aux ench\u00e8res d'articles. Veuillez patienter...",Ee:"Article fondu automatiquement : ",Fe:"Fusion de l'article : ",Ge:"Pas assez d'or pour fondre. Or requis : ",He:"FONDRE : Recherche d'articles \u00e0 fondre...",Ek:"Recherche d'articles \u00e0 fondre...",le:"V\u00e9rification de la disponibilit\u00e9 des costumes...",ne:"Donn\u00e9 : ",me:"Lancer des d\u00e9s...",Hd:"Underworld Farm [Manual, Beta]",Gd:"Farm Location",Id:"Attention\u00a0: activez cette fonctionnalit\u00e9 apr\u00e8s avoir d\u00e9verrouill\u00e9 la cr\u00e9ature que vous souhaitez attaquer, elle n'attaquera pas automatiquement pour d\u00e9bloquer le monstre.",
Fd:"Farm Enemy",Fc:"Connexion Automatique",Gc:"Vous devez autoriser les pop-ups depuis l'\u00e9cran du lobby de GameForge. Consultez la documentation pour savoir comment faire.",zf:"Mettre le Bot en Pause",Af:"Mettre le Bot en pause (Minutes)",Dd:"Date d'Expiration",uf:"Acheter uniquement de la nourriture ?",vf:"Si vous activez cette option, le bot ignorera vos s\u00e9lections et ach\u00e8tera automatiquement de la nourriture sans rien saisir.",Ib:"Montant total maximal d'or \u00e0 d\u00e9penser",
Hb:"Montant maximal d'or par aliment \u00e0 d\u00e9penser",tf:"Le bot v\u00e9rifiera les huiles toutes les 60 minutes",Ng:"D\u00e9finit une minuterie pour v\u00e9rifier les temps de fusion.",Kg:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion lorsque vous n'avez pas d'or.",Mg:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion si vous n'avez pas l'objet disponible.",Fg:"D\u00e9finit une minuterie pour r\u00e9parer et v\u00e9rifier vos objets.",Eg:"D\u00e9finit une minuterie pour v\u00e9rifier l'or retenu sur le march\u00e9 de la guilde.",
Ag:"D\u00e9finit une minuterie pour l'option de retenue d'or aux ench\u00e8res.",wg:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans l'ar\u00e8ne pour attaquer.",Bg:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans le cirque pour attaquer.",Tg:"D\u00e9finit une minuterie pour entra\u00eener vos statistiques.",Hg:"D\u00e9finit une minuterie pour r\u00e9initialiser les objets expir\u00e9s.",Rg:"D\u00e9finit une minuterie pour stocker les mat\u00e9riaux de forge dans l'horreum.",
yg:"D\u00e9finit une minuterie pour v\u00e9rifier les ench\u00e8res des gladiateurs et des mercenaires.",Jg:"D\u00e9finit une minuterie pour rechercher des objets aux ench\u00e8res et en boutique.",Cg:"D\u00e9finit la minuterie d'envoi de dons \u00e0 la guilde.",Md:"Or D\u00e9plac\u00e9",Yc:"Ne vendez pas d'articles de la fonderie et de la liste des ench\u00e8res",dg:"Automatisation de la Boutique",fg:"Param\u00e8tres de Recherche d'Objets",eg:"Utilisez cet outil pour rechercher des objets. Ajoutez simplement les objets \u00e0 la liste, sp\u00e9cifiez la quantit\u00e9 de tissu et lancez la recherche.",
gg:"Tissus \u00e0 Utiliser :",hg:"Combien de tissus utiliser ?",ja:"Full Entrez le Nom de l'Objet",Tb:"Entrez le Niveau de l'Objet",jg:"Qualit\u00e9 de l'Objet",ig:"Nom de l'Objet Ici",kg:"Commencer la Recherche",lg:"Sauter et Continuer",mg:"Arr\u00eater la Recherche",Jd:"Acheter le moins cher ou le plus cher?",nf:"Le Plus Cher",Oc:"Le Moins Cher",ga:"S\u00e9lectionnez une Option",cd:"Mettre en surbrillance les objets du monde souterrain",Kd:"Concentrez-vous sur la qu\u00eate\u00a0?",Ll:"Utiliser Ruby s'il n'y a pas de tissu ?",
Xa:"\u00c9vitez d'attaquer les m\u00eames personnes pour ne pas \u00eatre signal\u00e9. \u00catre signal\u00e9 augmente les chances d'\u00eatre banni.",Al:"Fondre Green ?",Ff:"Ne pas accepter les qu\u00eates al\u00e9atoires si des filtres sont entr\u00e9s ?",lc:"Qualit\u00e9 maximale des mat\u00e9riaux \u00e0 utiliser",Hh:"Activer la recherche de mercenaires",jl:"Cliquez sur `Vendre Tout S\u00e9lectionn\u00e9` pour vendre tous les objets. Assurez-vous d`avoir de l`espace vide de 2x3 dans votre premi\u00e8re (1) sac. Pour collecter de l`or en masse, filtrez l`or et utilisez `S\u00e9lectionner S\u00e9lectionn\u00e9s ou Tout S\u00e9lectionner`.",
Tj:"\ud83d\udd25 : Ajoute l`objet \u00e0 la liste de fusion.",vh:"\ud83d\udd28 : Ajoute l`objet \u00e0 la liste des ench\u00e8res.",qj:"Actualisez la boutique avec du tissu lorsqu`elle est pleine (Vous devrez vendre \u00e0 nouveau apr\u00e8s)",ej:"Page:",lj:"Arr\u00eater",jj:"Vendre Cette Page",gj:"S\u00e9lectionner S\u00e9lectionn\u00e9s",fj:"Tout S\u00e9lectionner",mj:"Param\u00e8tres d`Emballage Automatique",kj:"Envoyer les Ressources",hj:"Vendre Tout S\u00e9lectionn\u00e9",ra:"Type d`Objet",W:"Armes",
S:"Boucliers",M:"Armures",P:"Casques",O:"Gants",N:"Bottes",V:"Anneaux",U:"Amulettes",pa:"Utilisables (Nourriture)",wa:"Am\u00e9liorations",cj:"Boosts",ta:"Recettes",sa:"Mercenaires",va:"Outils de Forge",ua:"Parchemins",Oa:"Renforcements",Ma:"Objets d`\u00c9v\u00e9nement",Na:"Mat\u00e9riaux de Forge",dj:"Or",T:"Tout",ql:"Qualit\u00e9",X:"Blanc",B:"Vert",A:"Bleu",C:"Violet",G:"Orange",R:"Rouge",ij:"Options de Vente",Gj:"Ignorer la Combinaison Pr\u00e9fixe/Suffixe ?",hi:"Combien de nourriture acheter/cueillir ?",
Ch:"Normal",Bh:"Interm\u00e9diaire",Ah:"Difficile",Ja:"Standard",tl:"R\u00e9paration Correction d`Enlisement",Bk:"D\u00e9sactivez l`Entr\u00e9e en Enfer si vous souhaitez d\u00e9sactiver le Donjon/Cirque/Arenas. Si vous \u00eates entr\u00e9 en Enfer manuellement, vous devrez activer le Mode Enfer.",Pc:"Choisir le costume des Enfers",qh:"Porter le costume des Enfers quand il est disponible ?",Wg:"Tutoriel dentra\u00eenement : Indiquez combien de fois vous souhaitez entra\u00eener les statistiques et d\u00e9finissez leurs priorit\u00e9s. Le bot nentra\u00eenera pas sans quune priorit\u00e9 soit d\u00e9finie. Si une priorit\u00e9 est configur\u00e9e mais quil ne reste plus de statistiques \u00e0 entra\u00eener, le bot continuera avec la statistique s\u00e9lectionn\u00e9e.",
Wk:"Quest",tg:"Conserver l'Or aux Ench\u00e8res ?",Bf:"Mettre en Pause le Bot Al\u00e9atoirement pour travailler comme [Phase de Test] :",Uf:"R\u00e9initialiser les Objets Expir\u00e9s",Ob:"Remarque : En activant cette option, le bot vendra les objets expir\u00e9s \u00e0 venir des paquets sur le march\u00e9 de la guilde, puis annulera pour r\u00e9initialiser le temps d'expiration. La guilde est requise. Assurez-vous d'avoir un espace vide de 3x3 dans vos sacs.",da:"Conserver l'Or : Le bot conservera cet or dans le sac :",
Ze:"Or Maximum : Le bot d\u00e9pensera lorsque l'or sera sup\u00e9rieur \u00e0",yl:"Fonderie",El:"Fonderie Param\u00e8tres",Qj:"Fonderie Liste",Fl:"Ajouter un pr\u00e9fixe ou un suffixe, une fois qu`il l`aura trouv\u00e9 dans les paquets, il le fondera automatiquement:",Dl:"Fusion d'item:",cc:"Cliquez sur l`\u00e9l\u00e9ment que vous souhaitez r\u00e9parer. Essayez de faire de la place dans votre inventaire",Qk:"S`applique-t-il uniquement aux mercenaires ?",Tk:"L'ench\u00e8re ach\u00e8te que lorsque le march\u00e9 est proche de la fin.",
Sk:"Assurez-vous que le SECOND ONGLET D'INVENTAIRE est vide. Le bot trouvera et mettra l'objet dans le deuxi\u00e8me onglet puis la prochaine fois que la page est actualis\u00e9e, il fondra l'objet.",ki:"Gu\u00e9risseur & Buffs",ul:"Pas assez d'or pour fondre. Or requis:",xl:"Ench\u00e8re ignor\u00e9e: un membre de la guilde a d\u00e9j\u00e0 mis\u00e9 pour l'objet ",wl:"Ench\u00e8re ignor\u00e9e: Vous avez d\u00e9j\u00e0 mis\u00e9 pour cet objet ",advanced:"Avanc\u00e9e",arena:"Ar\u00e8ne",na:"Attaque automatique",
ac:"Eviter l'attaque",la:"Ajouter un joueur",ma:"Entrez le nom du joueur (Same Server)",dl:"Arr\u00eater le bot en cas de manque de nourriture?",circusTurma:"Circus Turma",Dh:"Difficult\u00e9",dungeon:"Donjon",Eh:"Param\u00e8tres du donjon",eventExpedition:"Event Exp\u00e9dition",expedition:"Expedition",Ih:"Param\u00e8tres d'expedition",Bj:"S\u00e9lectionner un monstre",gl:"Plus haut",el:"Mettez vos objets de soin dans la premi\u00e8re page de votre inventaire",fc:"Dans",ag:"Utiliser les v\u00eatements de travail pour renouveler la boutique?",
ii:"Pourcentage de gu\u00e9rison",jk:"Acheter de la nourriture dans la boutique?",kk:"Utiliser la gu\u00e9rison \u00e0 partir du paquet?",gk:"Utiliser Cervisia?",ik:"Utiliser des oeufs?",kl:"Dernier utilis\u00e9",location:"Emplacement",Strength:"Force",Dexterity:"Adresse",Agility:"Agilit\u00e9",Constitution:"Constitution",Charisma:"Charisme",Intelligence:"Intelligence",Ug:"Param\u00e8tres d'entrainement",Vg:"S\u00e9lectionnez les states que vous souhaitez entra\u00eener. L'entra\u00eenement commencera une fois que vous aurez assez d'or.",
nc:"Action suivante",Pi:"Non",Qi:"Normal",ol:"Adversaire",pl:"Niveau de l'adversaire",pj:"Qu\u00eates",random:"Al\u00e9atoire",vl:"Param\u00e8tres",Gl:"Bient\u00f4t...",type:"Cliquez sur les ic\u00f4nes pour activer les types de qu\u00eate.",Nl:"Oui",D:"Ench\u00e8re",oc:"Ajouter des objets",ck:"Stocker automatiquement les ressources de la forge",Il:"Soumettre",il:"Intervalle : ",Xk:"Activer l'ench\u00e8re automatique",Yk:"Ne pas ench\u00e9rir si un membre de la guilde a d\u00e9j\u00e0 ench\u00e9ri",
Kl:"Tutoriel",bc:"S\u00e9lectionnez \u00e0 partir des boutons ci-dessus pour choisir si vous souhaitez affronter l'adversaire le plus faible de l'ar\u00e8ne ou l'adversaire de niveau le plus \u00e9lev\u00e9.",Rk:"Pour commencer, ajoutez un article \u00e0 la liste (par exemple, `Lucius`). Une fois ajout\u00e9, l'outil recherchera l'article et affichera les r\u00e9sultats de la recherche sur le c\u00f4t\u00e9 gauche de l'\u00e9cran. Il sera \u00e9galement recherch\u00e9 \u00e0 des fins d'ench\u00e8re automatique. Si vous activez l'ench\u00e8re automatique, l'outil recherchera l'article \u00e0 des intervalles r\u00e9guliers en fonction du nombre que vous mettez dans la case d'intervalle. Si l'outil trouve l'article et que vous avez assez d'argent, il ench\u00e9rira automatiquement pour vous. *Note* pour rechercher des articles uniques dans les boutiques, vous devez ajouter au moins 1 article al\u00e9atoire \u00e0 la liste de recherche.",
$k:"Le num\u00e9ro de la cr\u00e9ature peut \u00eatre s\u00e9lectionn\u00e9 \u00e0 partir des boutons ci-dessus. Le num\u00e9ro 1 repr\u00e9sente la cr\u00e9ature la plus \u00e0 gauche. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",Fh:"S\u00e9lectionnez la difficult\u00e9 du donjon depuis le dessus. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",ji:"Param\u00e8tres de gu\u00e9rison",Gh:"Stocker l'or exc\u00e9dentaire dans la guilde en achetant des objets du march\u00e9 de la guilde. -> Or Min.",
ll:"D\u00e9placer tout",ml:"D\u00e9placer les s\u00e9lectionn\u00e9s",Uk:"Auto gu\u00e9rison",Vk:"Pourcentage de gu\u00e9rison automatique",Ml:"Ruby",wf:"Param\u00e8tres g\u00e9n\u00e9raux",Cj:"Tout vendre",Dj:"Vendre s\u00e9lectionn\u00e9s",ka:"Armes",ha:"Boucliers",Z:"Armure de poitrine",ca:"Casques",ba:"Gants",ia:"Chaussures",fa:"Anneaux",Y:"Amulettes",jh:"Utilisable",ih:"Am\u00e9liorations",Nf:"Nourriture",bf:"Parchemin de mercenaire",Pf:"Renforts",qc:"Ajouter un D\u00e9lai Al\u00e9atoire",rc:"Vous pouvez ajouter un d\u00e9lai al\u00e9atoire au bot ici.",
Nb:"R\u00e9parer",zl:"Fonder uniquement les Bleus?",Cl:"Fonder uniquement les Violets?",Bl:"Fonder uniquement les Oranges?",Rj:"Tout Fondre dans le 2e Onglet?",Sj:"Cela ignorera les s\u00e9lections de couleur",Ya:"Effacer l'Historique",og:"Fondre",zc:"Search",qf:"Ench\u00e8re Automatique",Ac:"Une utilisation excessive des ench\u00e8res peut entra\u00eener un bannissement. Il est recommand\u00e9 de d\u00e9sactiver les autres fonctionnalit\u00e9s d ench\u00e8res pour \u00e9viter les conflits potentiels. Cette fonctionnalit\u00e9 ralentira le bot..",
$f:"Rechercher dans l'Ench\u00e8re des Gladiateurs",bg:"Rechercher dans l'Ench\u00e8re des Mercenaires",Ic:"Miser de la Nourriture?",$e:"Mise Maximale",Jc:"Miser si le statut est inf\u00e9rieur \u00e0",Kc:"Objets Mis\u00e9s",rk:"Langue de l'Ench\u00e8re",sk:"\u00c0 partir de la mise \u00e0 jour 2.9.4, veuillez r\u00e9initialiser la langue ou R\u00c9INITIALISER LE BOT. Assurez-vous que toutes les informations sont correctes, sinon les ench\u00e8res ne fonctionneront pas.",uc:"Vous pouvez ajouter des objets pour les rechercher dans le march\u00e9 et les ench\u00e8res. Il montrera \u00e9galement les objets violets dans le march\u00e9 une fois que vous aurez ajout\u00e9 un objet \u00e0 la liste. Si vous souhaitez activer les ench\u00e8res automatiques, utilisez les options ci-dessous.",
pk:"Utilisez les ench\u00e8res avec prudence!",qk:"Les ench\u00e8res automatiques font trop de requ\u00eates au serveur et peuvent entra\u00eener un bannissement si elles sont utilis\u00e9es en permanence!",Rf:"Renouveler les Points d'\u00c9v\u00e9nement avec des Rubis?",ed:"Activer l'Huile Automatique",uk:"R\u00e9cup\u00e9rer Automatiquement les Huiles Sacr\u00e9es",Gk:"Vitesse de V\u00e9rification des Qu\u00eates",Ta:"Attaquer les Membres du Gremio ?",Ra:'Ajouter automatiquement les personnes \u00e0 la liste "Attaque" lorsque plus de X OR est vol\u00e9.:',
Sa:'Ajouter automatiquement les personnes \u00e0 la liste "\u00c9viter l\'Attaque" lorsque vous perdez contre elles.:',Rb:"Attaques au Tableau des Scores",Yb:"Tr\u00e8s Long",Bb:"Long",Jb:"Moyen",Vb:"Court",Zb:"Tr\u00e8s Court",fd:"Entrer dans le Monde Souterrain si HP >",Mf:"Vitesse de V\u00e9rification des Qu\u00eates",Ef:'Par d\u00e9faut, c\'est "3x". Si le bot pose des probl\u00e8mes avec les qu\u00eates, changez la vitesse des qu\u00eates en fonction de la vitesse de votre serveur.',Nd:"S\u00e9lection du Sac de Soins",
gd:"Si vous renouvelez manuellement les points, vous devez cliquer sur le bouton ci-dessus \"Actualiser l'exp\u00e9dition d'\u00e9v\u00e9nement si bloqu\u00e9e !",yk:"Vous devez activer au moins l'une des options suivantes : exp\u00e9dition, donjon, ar\u00e8ne ou cirque pour commencer l'exp\u00e9dition d'\u00e9v\u00e9nement.",Of:"Actualisez l'exp\u00e9dition d'\u00e9v\u00e9nement en cas de blocage !",lb:"Prot\u00e9ger les Alli\u00e9s ?",Mk:"Laissez tous les param\u00e8tres d\u00e9sactiv\u00e9s si vous souhaitez fondre en utilisant les paquets contenant les objets de la liste. Cependant, vous pouvez toujours choisir les couleurs.",
vk:"Personnage(D\u00e9sactiv\u00e9) / Mercenaire(Activ\u00e9)",Jk:"R\u00e9parer les Deux ?",Nk:"Minuteries",Timers:"Entrez le nombre de minutes pour chaque minuteur ci-dessous ou laissez-le par d\u00e9faut.",ob:"Activer l'Attaque au Tableau des Scores:",Pb:"S\u00e9lectionner la Fourchette pour Attaquer",Qb:"Le bot attaquera al\u00e9atoirement depuis la liste du tableau des scores.",qb:"Attaque de Ligue",nb:"Activer l'Attaque de Ligue:",Lb:"Attaquer Al\u00e9atoirement",Mb:"Attaquer du plus bas au plus haut",
nk:"Le bot \u00e9vitera par d\u00e9faut d'attaquer les membres du gremio.",Cd:"Lieu d'Exp\u00e9dition:",Bc:"Collecter Automatiquement les Bonus:",ng:"Passer le Boss",$c:"Lieu de Donjon:",Xf:"R\u00e9initialiser en cas de perte?",Qd:"Param\u00e8tres de l'Enfer",Rd:"Configurez vos param\u00e8tres de pourcentage de gu\u00e9rison depuis l'onglet Gu\u00e9rison, et assurez-vous que l'interrupteur Gu\u00e9rison est activ\u00e9. Si l'entr\u00e9e dans le monde souterrain vous d\u00e9connecte, allez au lobby et activez la case \u00e0 cocher Connexion Automatique.",
Od:"Difficult\u00e9 de l'Enfer",Ec:"Entrer Automatiquement dans l'Enfer: / Enfer Mode",lh:"Utiliser Mobilisation si les points = 0",ph:"Utiliser les Rubis?",hd:"Sortir du monde souterrain s'il n'y a plus de points?",Yg:"Le bot essaiera d'abord d'utiliser Villa Medici, si vous ne l'avez pas, il utilisera la potion de gu\u00e9rison. N'oubliez pas d'activer l'interrupteur de Gu\u00e9rison.",gh:"L'entr\u00e9e automatique dans le monde souterrain d\u00e9sactivera le donjon/l'ar\u00e8ne/le cirque lors de l'entr\u00e9e dans le monde souterrain.",
Ok:"Param\u00e8tres de Gu\u00e9rison du Monde Souterrain",oh:"Utiliser Villa Medici?",mh:"Utiliser la Potion de Gu\u00e9rison?",Ne:"INFO: Le bot recherchera les objets sur le march\u00e9 toutes les minutes s\u00e9lectionn\u00e9es, ce qui peut interrompre les attaques pendant la recherche.",dd:"Activer la Recherche sur le March\u00e9:",Oe:"Intervalle de Recherche sur le March\u00e9 en Minutes:",Pe:"Sugg\u00e9r\u00e9: 10 minutes.",$d:"Param\u00e8tres de l'Objet:",Yd:"Le Nom de l'Objet Inclut",H:"Prix Max",
ae:"Type d'Objet",Zd:"Raret\u00e9 de l'Objet",Nc:"Acheter avec Lien d'\u00c2me?",ce:"Objets \u00e0 Acheter",be:"Tentative d'achat d'objets avec des packs si l'un d'eux correspond au prix maximum indiqu\u00e9.:",Lc:"Objets Achet\u00e9s:",Jf:"Ignorer le Filtre de Qu\u00eates",If:"Saisissez des mots-cl\u00e9s pour filtrer les qu\u00eates que vous ne souhaitez pas accepter. You can also use this to accept quests by their reward using keywords.",aa:"Saisir un Mot-cl\u00e9",I:"Ajouter",Qf:"Supprimer",Qc:"Effacer",
Gf:"Accepter le Filtre de Qu\u00eates",Hf:"Saisissez des mots-cl\u00e9s pour choisir les qu\u00eates \u00e0 accepter. Cela ignorera les types de qu\u00eates",Ha:"Ignorer les Qu\u00eates Temporelles ?",Hk:"Qu\u00eates",Cc:"Costume Automatique",kh:"Utiliser le Costume ?",Hc:"Combat de Base",Zc:"Combat en Donjon",Dc:"Le bot ne portera Dis Pater Normal et Medium que si vos points d'exp\u00e9dition/donjon sont de 0.",Pd:"Param\u00e8tres de Gu\u00e9rison en Enfer",tc:"Attaquer le Boss quand disponible ?",
rb:"L'attaque en Ligue se d\u00e9sactivera apr\u00e8s 5 attaques infructueuses.",Sd:"Huiles Sacr\u00e9es",kf:"Nom de l'Objet",ea:"Niveau Minimum de l'Objet",Ga:"Qualit\u00e9 Minimum de l'Objet",sc:"Appliquer/R\u00e9initialiser la Minuterie",Vd:"Ignorer la Combinaison de Pr\u00e9fixe/Suffixe",rh:"Oui",sf:"Non",Pa:"Ajouter un Pr\u00e9fixe",Qa:"Ajouter un Suffixe",pg:"Liste des Objets \u00e0 Ignorer pour la Fusion",Kb:"Pr\u00e9fixe",Wb:"Suffixe",Wf:"R\u00e9initialiser les Objets Expir\u00e9s",qg:"Fusionner au Hasard depuis les Paquets ?",
rg:"Onglet Fusion",pb:"Extras",xc:"Ench\u00e8res",Se:"March\u00e9",Xb:"Minuteries",Pg:"Fusion",Og:"Fusionner s'il n'y a pas assez d'or",Lg:"Fusionner s'il n'y a pas d'objet",Ia:"R\u00e9paration",Dg:"Garder de l'Or sur le March\u00e9 de Guilde",zg:"Garder de l'Or aux Ench\u00e8res",Sg:"Entra\u00eenement",Gg:"R\u00e9initialiser les Expir\u00e9s",Qg:"Stockage \u00e0 la Forge",xg:"V\u00e9rification des Ench\u00e8res",Ig:"Recherche",v:"Activer",mf:"Or Minimum",Sb:"S\u00e9lectionner une Heure",mb:"Donner de l'Or \u00e0 la Guilde",
Uc:"Il donnera toutes les 5 minutes. Vous pouvez changer l'intervalle depuis l'onglet des minuteries",Td:"Combien souhaitez-vous donner ?",Vc:"Donner lorsque vous avez plus de >",ee:"Moins de <",Tf:"R\u00e9initialiser les Objets Expir\u00e9s et les Autres Param\u00e8tres",Vf:"R\u00e9initialiser dans :",Ck:"Maintenez Ctrl (Cmd sur Mac) enfonc\u00e9 pour s\u00e9lectionner plusieurs objets",Wd:"Import/Export des Param\u00e8tres",Ed:"Exporter les Param\u00e8tres",Xd:"Importer les Param\u00e8tres",cf:"Message \u00e0 Tous les Joueurs",
df:"[N\u00e9cessite une Cl\u00e9 Ultra Premium, message sur Discord pour l'obtenir.]",ef:"Saisir le message \u00e0 envoyer",Sc:"Pour des scripts personnalis\u00e9s, contactez-nous sur Discord",gf:"Envoyer",hf:"Afficher les Joueurs",ff:"Tout S\u00e9lectionner",jf:"Tout D\u00e9s\u00e9lectionner",de:"Assurez-vous que votre inventaire ait suffisamment d'espace. Le temps de recharge est de 2 minutes.",We:"Vendre de la Nourriture",Fb:"Vendre de la Nourriture"},Jh={Ni:"F\u00e9szek keres\u00e9si t\u00edpus",
Li:"Ne csin\u00e1lj semmit",Mi:"Gyors keres\u00e9s",Oi:"Alapos keres\u00e9s",nj:"After expedition points are consumed, travel to Germania to consume Dungeon points",mk:"Kattintson ide, ha a jav\u00edt\u00e1s beragad",yf:"R\u00e9szleges Jav\u00edt\u00e1s",Ld:"Teljes Jav\u00edt\u00e1s",xf:"R\u00e9szleges vagy Teljes Jav\u00edt\u00e1s",bd:"Korl\u00e1t Enged\u00e9lyez\u00e9se",li:"Korl\u00e1toz\u00e1s",mi:"Ha korl\u00e1tozni szeretn\u00e9d a t\u00e1mad\u00e1sok sz\u00e1m\u00e1t az ellens\u00e9gre, enged\u00e9lyezd ezt az opci\u00f3t \u00e9s \u00e1ll\u00edtsd be a korl\u00e1tot. A bot folytatja a t\u00e1mad\u00e1st a t\u00f6bbi ellens\u00e9ggel, miut\u00e1n befejezte a kiv\u00e1lasztott sz\u00f6rny elleni t\u00e1mad\u00e1sokat.",
Xc:"Ne l\u00e9pj be az alvil\u00e1gba alvil\u00e1gi jelmezben",Wc:"Ha nem akarsz alvil\u00e1gi jelmezben az alvil\u00e1gba l\u00e9pni, enged\u00e9lyezd ezt az opci\u00f3t",fh:"Alvil\u00e1g",Xg:"Alvil\u00e1gi Buffok",Zg:"Haszn\u00e1ld az istenek erej\u00e9t az alvil\u00e1gba l\u00e9p\u00e9s ut\u00e1n?",$g:"V\u00e1laszd ki az isteneket, akikt\u0151l er\u0151t szeretn\u00e9l nyerni:",ah:"Haszn\u00e1lj fegyver er\u0151s\u00edt\u00e9st a fegyveren?",bh:"Haszn\u00e1lj p\u00e1nc\u00e9l er\u0151s\u00edt\u00e9st a k\u00f6vetkez\u0151 felszerel\u00e9sen:",
xk:"A leh\u0171l\u00e9si id\u0151 30 perc. Ha nincs rajtad jelmez, a bot null\u00e1zza a leh\u0171l\u00e9si id\u0151t.",Lk:"Sz\u00ednek kiv\u00e1laszt\u00e1sa",Za:"Vulcanus Kov\u00e1csm\u0171helye",cb:"Feronia F\u00f6ldi Pajzsa",eb:"Neptunusz Foly\u00e9kony Ereje",fb:"Aelous L\u00e9gies Szabads\u00e1ga",gb:"Pl\u00fat\u00f3 Hal\u00e1los K\u00f6de",hb:"Juno \u00c9let Lehelete",ib:"Harag Hegyeinek Pikkelyes P\u00e1nc\u00e9lja",jb:"Sas Szemei",kb:"Saturnusz T\u00e9li \u00d6lt\u00f6z\u00e9ke",$a:"Bubona Bikap\u00e1nc\u00e9lja",
ab:"Mercerius Rabl\u00f3ruh\u00e1i",bb:"Ra F\u00e9nyk\u00f6nt\u00f6se",Ve:"Csomagok",Qe:"K\u00e9szlet",K:"Min. \u00c1r",J:"H\u00e1ny darab",Eb:"T\u00e1rgyak Elad\u00e1sa",Db:"Keres\u00e9s ebben",Re:"Anyag Sz\u00edne",Cb:"T\u00e1rgy Sz\u00edne",Ye:"Rakt\u00e1r",Fa:"V\u00e1lt\u00e1s Anyagokra",Gb:"V\u00e1lt\u00e1s T\u00e1rgyakra",Xe:"Anyagok Elad\u00e1sa",Ca:"K\u00e9rj\u00fck, adjon meg \u00e9rv\u00e9nyes t\u00e1rgyn\u00e9v, \u00e1rfekv\u00e9s \u00e9s mennyis\u00e9get.",Da:"Nincsenek megfelel\u0151 t\u00e1rgyak a kiv\u00e1lasztott keres\u00e9si helyeken.",
Ea:"Minden t\u00e1rgy sikeresen list\u00e1zva!",Fk:"Minden anyag sikeresen list\u00e1zva!",Te:"Ha fix \u00e1ron szeretne t\u00e1rgyakat eladni, ugyanazt az \u00e9rt\u00e9ket adja meg a min \u00e9s max \u00e1rra.",Ue:"Ez a funkci\u00f3 m\u00e9g k\u00eds\u00e9rleti, \u00f3vatosan haszn\u00e1lja. Ha nem ad meg fix \u00e1rat, az elemek v\u00e9letlenszer\u0171en ker\u00fclnek list\u00e1z\u00e1sra a megadott minimum \u00e9s maximum \u00e1r k\u00f6z\u00f6tt.",tk:"Be\u00e1ll\u00edtja a maxim\u00e1lis aranyat, amit a bot egy ciklusban elk\u00f6lt.",
Ua:"A bot licit\u00e1lni kezd minden \u00e9tel t\u00e1rgyra, ha enged\u00e9lyezve van. Nem kell enged\u00e9lyezned a gladi\u00e1tor/zsoldos kapcsol\u00f3kat.",vc:"A bot nem licit\u00e1l az sz\u00f6vets\u00e9gesei licitjeire.",wc:"Figyelmen k\u00edv\u00fcl hagyja az El\u0151tag/Ut\u00f3tag kombin\u00e1ci\u00f3t t\u00e1rgy keres\u00e9sekor az aukci\u00f3n.",Kj:"V\u00e1laszd ki azokat a t\u00e1rgyt\u00edpusokat, amelyeket be akarsz olvasztani.",Lj:"V\u00e1laszd ki azokat a sz\u00edneket, amelyeket be akarsz olvasztani.",
Mj:"V\u00e1laszd ki az t\u00e1rgyak szintj\u00e9t, amelyeket be akarsz olvasztani.",Nj:"V\u00e1laszd ki a kalap\u00e1csot, amit haszn\u00e1lni szeretn\u00e9l.",Oj:"Figyelj arra, hogy az els\u0151 mez\u0151 melletti z\u00f6ld \u00e9s piros k\u00f6r a szab\u00e1ly enged\u00e9lyez\u00e9s\u00e9hez/letilt\u00e1s\u00e1hoz van.",Pj:"Ha v\u00e9letlenszer\u0171en szeretn\u00e9l beolvasztani b\u00e1rmilyen sz\u00ednt vagy t\u00edpust, enged\u00e9lyezheted a `V\u00e9letlenszer\u0171en beolvasztani, ha nincsenek felt\u00e9telek teljes\u00edtve? (A tutorial vide\u00f3ban utolj\u00e1ra enged\u00e9lyezett opci\u00f3)",
rj:"R\u00e9parer avant la Fusion",yd:"Sz\u00f6rny Kiv\u00e1laszt\u00e1sa",md:"Homok\u00f3ra/Rubin Haszn\u00e1lata?",zk:"Rubin Haszn\u00e1lata?",pd:"Mozg\u00f3s\u00edt\u00e1s Haszn\u00e1lata?",od:"\u00c9letital Haszn\u00e1lata?",ld:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9ka (%)",wd:"T\u00e1mad\u00e1sok Sz\u00e1ma",nd:"T\u00e1mad\u00e1si Id\u0151k\u00f6z (m\u00e1sodpercben)",jd:"V\u00e9grehajtott T\u00e1mad\u00e1sok",kd:"H\u00e1tral\u00e9v\u0151 Homok\u00f3ra",ud:"Megjegyz\u00e9s: \u00c9leter\u0151-p\u00f3ci\u00f3kat haszn\u00e1l gy\u00f3gy\u00edt\u00e1sra, nem \u00e9telt.",
vd:"Megjegyz\u00e9s: Ha a t\u00e1mad\u00e1sok id\u0151 el\u0151tt meg\u00e1llnak, pr\u00f3b\u00e1lja meg az 'T\u00e1mad\u00e1sok Vissza\u00e1ll\u00edt\u00e1sa' opci\u00f3t.",zd:"Ind\u00edt\u00e1s",xd:"Vissza\u00e1ll\u00edt\u00e1s",Ad:"Le\u00e1ll\u00edt\u00e1s",Bd:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sai (Kattintson minimaliz\u00e1l\u00e1shoz)",qd:"Sz\u00f6rny 1",rd:"Sz\u00f6rny 2",sd:"Sz\u00f6rny 3",td:"Sz\u00f6rny 4",Ik:"R\u00e9parer avant la Fusion",yh:"Ez az opci\u00f3 haszn\u00e1lja a cervisia-t, amikor lej\u00e1r a pr\u00e9mium tags\u00e1god.",
Ri:"Ez az opci\u00f3 aktiv\u00e1lja \u00e9s v\u00e1laszt olajokat az istenek jutalmai k\u00f6z\u00fcl. Haszn\u00e1lhatja az 1. \u00e9s 3. sz\u00e1m\u00fa olajokat a karakteren, de a 2. sz\u00e1m\u00fa csak csomagokba ker\u00fcl.",wh:"Ez az opci\u00f3 a be\u00e1ll\u00edtott id\u0151ben haszn\u00e1lja a buffokat. Megkeresi a csomagokban l\u00e9v\u0151 buffokat \u00e9s alkalmazza \u0151ket a karakteren.",ni:"Ez az opci\u00f3 bevisz az alvil\u00e1gba. Ne felejtsd el enged\u00e9lyezni az Auto Bejelentkez\u00e9st az Extra f\u00fcl\u00f6n, k\u00fcl\u00f6nben kijelentkezhetsz az alvil\u00e1gba l\u00e9p\u00e9skor [J\u00e1t\u00e9k Hiba]",
$b:"A bot norm\u00e1lis esetben v\u00e9letlenszer\u0171en v\u00e1laszt 3-6 pr\u00f3b\u00e1t az ar\u00e9nalista megt\u00e1mad\u00e1s\u00e1ra. Ha enged\u00e9lyezed ezt az opci\u00f3t, v\u00e9gigmegy a list\u00e1don, am\u00edg meg nem t\u00e1madhat valakit. Ez eltarthat egy kis id\u0151t.",oj:"Ez az opci\u00f3 csak pr\u00e9mium licencek sz\u00e1m\u00e1ra van. Szimul\u00e1l egy t\u00e1mad\u00e1st egy felhaszn\u00e1l\u00f3 ellen 75%-os gy\u0151zelmi r\u00e1t\u00e1val, miel\u0151tt megt\u00e1madn\u00e1.",
yc:"Nem kell enged\u00e9lyezned a f\u0151 aukci\u00f3 kapcsol\u00f3t, hogy ezt az opci\u00f3t haszn\u00e1lhasd.",fk:"Ez az opci\u00f3 m\u00e1sodpercenk\u00e9nt friss\u00edti az oldalt, amikor az aukci\u00f3 -Nagyon R\u00f6vid- \u00e1llapotban van, hogy folyamatosan licit\u00e1ljon \u00e9s megnyerje az aukci\u00f3t.",Ij:"Ha egyik olvaszt\u00e1si felt\u00e9tel sem teljes\u00fcl, akkor v\u00e9letlenszer\u0171en olvaszt. Gy\u0151z\u0151dj meg r\u00f3la, hogy v\u00e1lasztott\u00e1l t\u00e1rgyt\u00edpust \u00e9s sz\u00ednt.",
Jj:"Ez az opci\u00f3 csak a lelt\u00e1rban l\u00e9v\u0151 t\u00e1rgyakat olvasztja. A csomagokban l\u00e9v\u0151 t\u00e1rgyakat figyelmen k\u00edv\u00fcl hagyja.",Va:"Aukci\u00f3s T\u00e1rgyak",af:"Zsoldos T\u00e1rgyak",Ub:"Bolt T\u00e1rgyak",hh:"Egyedi T\u00e1rgyak",Ej:"H\u00e1tt\u00e9r be\u00e1ll\u00edt\u00e1sa feket\u00e9re [N\u00f6veli a teljes\u00edtm\u00e9nyt]",Fj:"GLDbot gombok \u00e1thelyez\u00e9se a bal als\u00f3 sarokba?",zh:"Cirkusz T\u00e1mad\u00e1s Gy\u00f3gy\u00edt\u00e1s N\u00e9lk\u00fcl",
dk:"Sz\u00fcks\u00e9g eset\u00e9n vegy\u00fcnk ki aranyat a csomagokb\u00f3l?",ek:"Az edz\u00e9shez aranyat vettek a csomagokb\u00f3l",Jl:"Nem tal\u00e1ltak aranyat a csomagokban az edz\u00e9shez",ak:"Jav\u00edtott T\u00e1rgyak",Uj:"Ar\u00e9na T\u00e1mad\u00e1sok",Wj:"Cirkusz T\u00e1mad\u00e1sok",pc:"T\u00e1rgyak Vissza\u00e1ll\u00edtva",Zj:"Exped\u00edci\u00f3s T\u00e1mad\u00e1sok",Yj:"Kazamata T\u00e1mad\u00e1sok",bk:"Alvil\u00e1gi T\u00e1mad\u00e1sok",Vj:"Ar\u00e9n\u00e1ban Szerzett P\u00e9nz",
Xj:"Cirkuszban Szerzett P\u00e9nz",Hl:"Olvasztott T\u00e1rgyak",$j:"\u00dajrahasznos\u00edtott Arany",ei:"C\u00e9h Csata",gi:"C\u00e9h Be\u00e1ll\u00edt\u00e1sok",fi:"C\u00e9h N\u00e9v",di:"V\u00e9letlenszer\u0171 C\u00e9h T\u00e1mad\u00e1s",bl:"V\u00e9letlenszer\u0171en t\u00e1madja a c\u00e9heket.",xh:"Statisztik\u00e1k Vissza\u00e1ll\u00edt\u00e1sa",nl:'GLDbot: A kock\u00e1k seg\u00edts\u00e9g\u00e9vel friss\u00edtse a rejt\u00e9lydobozt, \u00e9s tal\u00e1ljon \u00e9rt\u00e9kes t\u00e1rgyakat, miel\u0151tt kinyitn\u00e1 azokat (stb. jelmezek). Kattintson a "Start" gombra, nyissa meg a l\u00e1d\u00e1kat.',
kc:"Wood",hc:"Copper",ic:"Iron",jc:"Leather",xi:"Wool",pi:"Cotton Wool",si:"Hemp",ri:"Gauze Strip",ui:"Linen Strip",ti:"Jute Patch",wi:"Velvet",vi:"Silk Thread",Ei:"Fur",yi:"Bone Splinter",Hi:"Scale",Bi:"Claw",Di:"Fang",Ci:"Dragon Scale",zi:"Bull`s Horn",Gi:"Poison Gland",Ai:"Cerberus` Pelt",Fi:"Hydra Scale",Ii:"Sphinx Feather",Ji:"Typhon Leather",ai:"Lapis Lazuli",Vh:"Amethyst",Uh:"Amber",Wh:"Aquamarine",bi:"Sapphire",Zh:"Garnet",Yh:"Emerald",Xh:"Diamond",$h:"Jasper",ci:"Sugilite",Ph:"Scorpion Poison",
Sh:"Tincture of Stamina",Lh:"Antidote",Kh:"Adrenaline",Rh:"Tincture of Enlightenment",Oh:"Potion of Perception",Mh:"Essence of Reaction",Nh:"Phial of Charisma",Th:"Waters of Oblivion",Qh:"Soul Essence",Aj:"Water Seal",uj:"Protection Rune",sj:"Earth Mark",zj:"Totem of Healing",yj:"Talisman of Power",wj:"Stone of Fortune",tj:"Flintstone",xj:"Storm Rune",vj:"Shadow Rune",Ui:"Crystal",Ti:"Bronze",Yi:"Obsidian",aj:"Silver",bj:"Sulphur",Wi:"Gold Ore",$i:"Quartz",Zi:"Platinum",Si:"Almandin",Vi:"Cuprit",
Xi:"Hellstone",th:"T\u00e1mad\u00e1s v\u00e9letlenszer\u0171en?",uh:'Kapcsold ki a "J\u00e1t\u00e9kosok rendez\u00e9se az ar\u00e9n\u00e1ban szint szerint" be\u00e1ll\u00edt\u00e1st a crazy-addonban is.',Kf:"Csak az isten t\u00edpus\u00e1n alapul\u00f3 k\u00fcldet\u00e9seket fogadja el.",Wa:"Automatikus Buff",Mc:"Csak a pokolban haszn\u00e1lja?",rf:"\u00daj Szab\u00e1ly",pf:"N\u00e9v Tartalmazza",isUnderworldItem:"Ez egy alvil\u00e1gi t\u00e1rgy?",Ud:"Anyagok Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
lk:"Utiliser la Pri\u00e8re ?",nh:"Utiliser le Sacrifice ?",hk:"Utiliser le tissu pour entrer dans le monde souterrain ?",eh:"A m\u00e9lyvil\u00e1gban csak a m\u00e9lyvil\u00e1ggal kapcsolatos k\u00fcldet\u00e9seket fogadja el?",dh:"Ha enged\u00e9lyezve van, meg kell adnia a m\u00e9lyvil\u00e1gi t\u00e1rgyak nev\u00e9t. Ha a bot megtal\u00e1lja ezeket a t\u00e1rgyakat a m\u00e9lyvil\u00e1gban, elfogadja a k\u00fcldet\u00e9st.",Pk:"M\u00e9lyvil\u00e1gi K\u00fcldet\u00e9s T\u00e1rgy",Zk:"Entrez le Nom du Mat\u00e9riel",
wk:"A robot im\u00e1dja a kock\u00e1kat! Seg\u00edtenek ruh\u00e1t tal\u00e1lni a l\u00e1d\u00e1kban. De ha nincs kocka, a robot akkor is kinyitja a l\u00e1d\u00e1kat, rem\u00e9lve, hogy tal\u00e1l valami men\u0151 ruh\u00e1t (de lehet, hogy semmit sem tal\u00e1l!)",Hj:"Fusionner les Bo\u00eetes de Butin ?",ad:"Enable Arena",Cf:"Prioriz\u00e1lja az ar\u00e9na list\u00e1t?",Df:"Prioriz\u00e1lja a cirkusz list\u00e1t?",Tc:"Napl\u00f3 men\u00fc letilt\u00e1sa",Yf:"Jutalom Min. Arany \u00c9rt\u00e9k",
Lf:"Ha enged\u00e9lyezve van, a K\u00fcldet\u00e9s F\u00f3kusz a legr\u00f6videbb utat k\u00f6veti a dungeon befejez\u00e9s\u00e9hez.",ug:"Dobja a kock\u00e1t automatikusan?",vg:"Vigy\u00e1zva haszn\u00e1lja a dob\u00f3 kock\u00e1t, folyamatosan az els\u0151 kock\u00e1t fogja haszn\u00e1lni, am\u00edg ki nem kapcsolja az opci\u00f3t.",cg:"Keres\u00e9s folyamatban",Sf:"A jav\u00edt\u00e1s alap\u00e9rtelmezett leh\u0171l\u00e9se 10 perc.",lf:"Minim\u00e1lis \u00c1llapot",Rc:"Aktu\u00e1lis t\u00e9tel a munkapadon [T\u00f6r\u00f6lje, ha a bot v\u00e1ratlanul sz\u00fcnetelt]",
oe:"Kov\u00e1csolt er\u0151forr\u00e1sok sikeresen elmentve a horreumhoz.",ke:"Piac ellen\u0151rz\u00e9se t\u00e1rgyak sz\u00e1m\u00e1ra...",Ab:"T\u00e9tel \u00e1thelyezve a munkapadra.",Ce:"T\u00e9tel sikeresen jav\u00edtva \u00e9s felszerelve.",De:"T\u00e9tel sikeresen jav\u00edtva.",Dk:"A jav\u00edt\u00e1s sikertelen. Az oldal friss\u00edt\u00e9sre ker\u00fcl.",ze:"Anyagok felv\u00e9tele...",Me:"V\u00e1rakoz\u00e1s a jav\u00edt\u00e1sra...",Be:"Jav\u00edt\u00e1s elindult: .",Ba:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa az invent\u00e1riumb\u00f3l a t\u00e1sk\u00e1ba",
Ae:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa a munkapadra a csomagol\u00f3ba.",sb:"Nem tal\u00e1lhat\u00f3 elegend\u0151 anyag. A jav\u00edt\u00e1si hely le lesz tiltva ",we:"T\u00e1rgyak keres\u00e9se arany elrejt\u00e9s\u00e9re az aukci\u00f3ban...",he:"Lej\u00e1rt t\u00e1rgyak ellen\u0151rz\u00e9se a csomagokban...",ie:"T\u00e9tel sikeresen vissza\u00e1ll\u00edtva.",je:"Nincs \u00fcres hely vagy arany a vissza\u00e1ll\u00edt\u00e1shoz.",pe:"Gy\u0151z\u0151dj\u00f6n meg arr\u00f3l, hogy van elad\u00e1si joga a c\u00e9hes piacon!",
ub:"Nincs el\u00e9g arany/vagy nincs meg a v\u00e1s\u00e1rl\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s a friss\u00edt\u00e9shez.",wb:"A bolt friss\u00edtve lett.",xb:"Hiba t\u00f6rt\u00e9nt a gy\u00f3gyul\u00e1s k\u00f6zben.",se:"Nincs Ruby vagy Cloth, letilt\u00e1sa az opci\u00f3knak.",te:"Nincs gy\u00f3gy\u00edt\u00f3 t\u00e1rgy a csomagokban.",yb:"Nem tal\u00e1lhat\u00f3 megfelel\u0151 t\u00e1rgy",ue:"Az \u00e9lelmiszereket felvett\u00e9k. A folyamat v\u00e9get \u00e9rt.",ve:"Legal\u00e1bb egy \u00e9tel felv\u00e9telre ker\u00fclt. A folyamat v\u00e9get \u00e9rt.",
zb:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",qe:"\u00c9telek felv\u00e9tele a csomagokb\u00f3l.",re:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",vb:"Nincs t\u00f6bb gy\u00f3gy\u00edt\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s.",tb:"\u00c9P helyre\u00e1ll\u00edtva.",Aa:"Nincs teend\u0151, ez\u00e9rt im\u00e1dkozom!",Ie:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem \u00e9s a Villa Medici ellen\u0151rz\u00e9s\u00e9re.",
Je:"V\u00e1rakoz\u00e1s a Villa Medici-re, friss\u00edt\u00e9s 60 m\u00e1sodperc m\u00falva.",Ke:"Elhagytam az alvil\u00e1got.",Le:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem ellen\u0151rz\u00e9s\u00e9re.",xe:"Isteni olajok ellen\u0151rz\u00e9se...",ye:"Isteni olajok felv\u00e9ve.",ya:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen AZ AR\u00c9N\u00c1BAN: ",za:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen A CIRKUSZBAN: ",fe:"Aukci\u00f3 ellen\u0151rz\u00e9se! K\u00e9rem v\u00e1rjon...",
ge:"T\u00e1rgyak licit\u00e1l\u00e1sa. K\u00e9rem v\u00e1rjon...",Ee:"Automatikus olvasztott t\u00e9tel: ",Fe:"Olvaszt\u00e1s alatt \u00e1ll\u00f3 t\u00e9tel: ",Ge:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges arany: ",He:"OLVASZT\u00c1S: T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",Ek:"T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",le:"Koszt\u00fcm\u00f6k el\u00e9rhet\u0151s\u00e9g\u00e9nek ellen\u0151rz\u00e9se...",ne:"Adom\u00e1nyozva: ",me:"Kocka dob\u00e1sa...",
Hd:"Underworld Farm [Manual, Beta]",Gd:"Farm Location",Id:"Figyelem: Kapcsolja be ezt a funkci\u00f3t a t\u00e1madni k\u00edv\u00e1nt l\u00e9ny felold\u00e1sa ut\u00e1n, nem fog automatikusan t\u00e1madni, hogy feloldja a sz\u00f6rnyet.",Fd:"Farm Enemy",Fc:"Automatikus Bejelentkez\u00e9s",Gc:"Enged\u00e9lyezned kell a felugr\u00f3 ablakokat a GameForge el\u0151csarnok k\u00e9perny\u0151j\u00e9r\u0151l. N\u00e9zd meg a dokument\u00e1ci\u00f3t, hogy hogyan tedd meg.",zf:"Bot Sz\u00fcneteltet\u00e9se",
Af:"Bot sz\u00fcneteltet\u00e9se ennyi id\u0151re: (Perc)",Dd:"Lej\u00e1rati D\u00e1tum",uf:"Csak \u00e9telt v\u00e1s\u00e1rolj?",vf:"Ha ezt enged\u00e9lyezed, a bot figyelmen k\u00edv\u00fcl hagyja a kiv\u00e1laszt\u00e1saidat, \u00e9s automatikusan v\u00e1s\u00e1rol \u00e9telt an\u00e9lk\u00fcl, hogy b\u00e1rmit be\u00edrn\u00e1l.",Ib:"Maxim\u00e1lis \u00f6sszes arany kiad\u00e1s",Hb:"Maxim\u00e1lis arany \u00e9telenk\u00e9nti kiad\u00e1s",tf:"A bot 60 percenk\u00e9nt ellen\u0151rzi az olajokat",
Ng:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a olvaszt\u00e1si id\u0151k ellen\u0151rz\u00e9s\u00e9hez.",Kg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs aranyad.",Mg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs el\u00e9rhet\u0151 t\u00e1rgyad.",Fg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a t\u00e1rgyak jav\u00edt\u00e1s\u00e1hoz \u00e9s ellen\u0151rz\u00e9s\u00e9hez.",
Eg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a guild piac\u00e1nak arany\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Ag:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az aukci\u00f3 arany tart\u00e1si lehet\u0151s\u00e9g\u00e9hez.",wg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az ar\u00e9na PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",Bg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a cirkusz PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",
Tg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a statisztik\u00e1k tr\u00e9ningez\u00e9s\u00e9hez.",Hg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a lej\u00e1rt t\u00e1rgyak vissza\u00e1ll\u00edt\u00e1s\u00e1hoz.",Rg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a kov\u00e1csol\u00f3 anyagok t\u00e1rol\u00e1s\u00e1hoz a horreum-ban.",yg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a gladi\u00e1torok \u00e9s zsoldosok aukci\u00f3j\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Jg:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t t\u00e1rgyak keres\u00e9s\u00e9hez az aukci\u00f3ban \u00e9s a boltban.",
Cg:"Be\u00e1ll\u00edtja a guild adom\u00e1ny k\u00fcld\u00e9s\u00e9nek id\u0151z\u00edt\u0151j\u00e9t.",Md:"Arany Mozgatva",Yc:"Ne adjon el az \u00f6sszeoml\u00e1si \u00e9s aukci\u00f3s list\u00e1n szerepl\u0151 t\u00e9teleket",dg:"Bolt Automatiz\u00e1l\u00e1s",fg:"T\u00e1rgy Keres\u00e9s Be\u00e1ll\u00edt\u00e1sok",eg:"Haszn\u00e1lja ezt az eszk\u00f6zt t\u00e1rgyak keres\u00e9s\u00e9hez. Egyszer\u0171en adjon hozz\u00e1 t\u00e1rgyakat a list\u00e1hoz, hat\u00e1rozza meg a ruha mennyis\u00e9g\u00e9t, majd ind\u00edtsa el a keres\u00e9st.",
gg:"Haszn\u00e1lni k\u00edv\u00e1nt Ruha:",hg:"H\u00e1ny ruh\u00e1t haszn\u00e1ljon?",ja:"Full Adja meg a T\u00e1rgy Nev\u00e9t",Tb:"Adja meg a T\u00e1rgy Szintj\u00e9t",jg:"T\u00e1rgy Min\u0151s\u00e9ge",ig:"T\u00e1rgy Neve Itt",kg:"Keres\u00e9s Ind\u00edt\u00e1sa",lg:"\u00c1tugr\u00e1s \u00e9s Folytat\u00e1s",mg:"Keres\u00e9s Le\u00e1ll\u00edt\u00e1sa",Jd:"Guild Piac Rendez\u00e9se",nf:"Legdr\u00e1g\u00e1bb",Oc:"Legolcs\u00f3bb",ga:"V\u00e1lasszon egy lehet\u0151s\u00e9get",cd:"Mettre en surbrillance les objets du monde souterrain",
Kd:"F\u00f3kuszban a k\u00fcldet\u00e9sre?",Rp:"Haszn\u00e1ljon rubint, ha nincs ruha?",Xa:"Ker\u00fclje azonos szem\u00e9lyek megt\u00e1mad\u00e1s\u00e1t, hogy elker\u00fclje a jelent\u00e9st\u00e9tel\u00e9t. A jelent\u00e9s megn\u00f6veli a kitilt\u00e1s es\u00e9ly\u00e9t.",Al:"Olvad a z\u00f6ld?",Ff:"Ne fogadja el a v\u00e9letlenszer\u0171 k\u00fcldet\u00e9seket, ha b\u00e1rmilyen sz\u0171r\u0151t megadott?",lc:"Maxim\u00e1lis haszn\u00e1lhat\u00f3 anyagmin\u0151s\u00e9g",Hh:"Enged\u00e9lyezze a zsoldos keres\u00e9st",
jl:'Kattints a "Minden Kiv\u00e1lasztott Elad\u00e1sa" gombra az \u00f6sszes t\u00e9tel elad\u00e1s\u00e1hoz. Gy\u0151z\u0151dj meg r\u00f3la, hogy az els\u0151 (1) t\u00e1sk\u00e1dban van el\u00e9g 2x3 \u00fcres hely. Az arany t\u00f6meges gy\u0171jt\u00e9s\u00e9hez sz\u0171rd ki az aranyat, \u00e9s haszn\u00e1ld a "Kiv\u00e1lasztott vagy Mindet Kiv\u00e1laszt" lehet\u0151s\u00e9get.',Tj:"\ud83d\udd25 : Hozz\u00e1adja az elemet a koh\u00e1szati list\u00e1hoz.",vh:"\ud83d\udd28 : Hozz\u00e1adja az elemet az \u00e1rver\u00e9si list\u00e1hoz.",
qj:"Friss\u00edtsd a boltot anyaggal, amikor tele van (ut\u00e1na \u00fajra el kell adnod)",ej:"Oldal:",lj:"Meg\u00e1ll\u00edt",jj:"Elad\u00e1s Ezen az Oldalon",gj:"Kiv\u00e1lasztott Kiv\u00e1laszt\u00e1sa",fj:"Mindent Kiv\u00e1laszt",mj:"Automatikus Csomagol\u00e1si Be\u00e1ll\u00edt\u00e1sok",kj:"Er\u0151forr\u00e1sok K\u00fcld\u00e9se",hj:"Minden Kiv\u00e1lasztott Elad\u00e1sa",ra:"T\u00e9tel T\u00edpusa",W:"Fegyverek",S:"Pajzsok",M:"P\u00e1nc\u00e9lok",P:"Sisakok",O:"Keszty\u0171k",N:"Csizm\u00e1k",
V:"Gy\u0171r\u0171k",U:"Amulettek",pa:"Haszn\u00e1lati T\u00e1rgyak (\u00c9telek)",wa:"Fejleszt\u00e9sek",cj:"Er\u0151s\u00edt\u00e9sek",ta:"Receptek",sa:"Zsoldosok",va:"Kov\u00e1csol\u00f3 Eszk\u00f6z\u00f6k",ua:"Pergamenek",Oa:"Er\u0151s\u00edt\u00e9sek",Ma:"Esem\u00e9ny T\u00e1rgyak",Na:"Kov\u00e1csol\u00e1shoz Val\u00f3 T\u00e1rgyak",dj:"Arany",T:"Minden",ql:"Min\u0151s\u00e9g",X:"Feh\u00e9r",B:"Z\u00f6ld",A:"K\u00e9k",C:"Lila",G:"Narancss\u00e1rga",R:"Piros",ij:"Az \u00d6sszes Elad\u00e1si Be\u00e1ll\u00edt\u00e1s",
Gj:"Elhanyagolja a El\u0151tag / Ut\u00f3tag Kombin\u00e1ci\u00f3t?",hi:"H\u00e1ny \u00e9telt vegy\u00e9l/fogj fel?",Ch:"Norm\u00e1l",Bh:"K\u00f6zepes",Ah:"Neh\u00e9z",Ja:"Alap",tl:"Ragadt Megjav\u00edt\u00e1s",Bk:"Kapcsold ki a Pokol Bel\u00e9p\u00e9s\u00e9t, ha letiltan\u00e1d a Dungeon/Circus/Arena-t. Ha k\u00e9zzel l\u00e9pt\u00e9l be a Pokolba, akkor enged\u00e9lyezned kell a Pokol M\u00f3dot.",Pc:"V\u00e1lassz alvil\u00e1gi jelmezt",qh:"Viselj alvil\u00e1gi jelmezt, ha el\u00e9rhet\u0151?",
Wg:"K\u00e9pz\u00e9si \u00fatmutat\u00f3: Hat\u00e1rozza meg, h\u00e1nyszor szeretn\u00e9 edzeni a statisztik\u00e1kat, \u00e9s \u00e1ll\u00edtsa be priorit\u00e1saikat. A bot nem fog edzeni, hacsak nincs be\u00e1ll\u00edtva egy priorit\u00e1s. Ha van be\u00e1ll\u00edtott priorit\u00e1s, de nincs t\u00f6bb k\u00e9pzend\u0151 statisztika, a bot a kiv\u00e1lasztott statisztik\u00e1val folytatja.",Wk:"Quest",yl:"Olvaszt\u00e1s",El:"Olvaszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Qj:"Olvasztott T\u00e1rgyak",
Fl:"Adj hozz\u00e1 el\u0151tagot vagy ut\u00f3tagot, amint megtal\u00e1lja a csomagokban, aut\u00f3matikusan olvasztani fogja.:",Dl:"Olvasztand\u00f3 T\u00e1rgy:",cc:"Kattints a t\u00e1rgyra, amelyet meg akarsz jav\u00edtani. Ez a rendszer megjav\u00edtja a k\u00e9t f\u0151 karaktered t\u00e1rgyait ( AR\u00c9NA/CT). Legal\u00e1bb 10000 aranyra van sz\u00fcks\u00e9g a jav\u00edt\u00e1s elind\u00edt\u00e1s\u00e1hoz. Ha egy t\u00e1rgy beragad, az azt jelenti, hogy nincs anyagod a jav\u00edt\u00e1shoz. Pr\u00f3b\u00e1lj szabad helyet k\u00e9sz\u00edteni a t\u00e1sk\u00e1dban. A bot akkor kezdi meg a jav\u00edt\u00e1st, amikor a t\u00e9tel tart\u00f3ss\u00e1ga %0.",
Qk:"Csak Zsoldosra alkalmaz",Tk:"Aukci\u00f3 csak akkor licit\u00e1l, ha a lej\u00e1rati id\u0151 k\u00f6zel van a v\u00e9g\u00e9hez.",Sk:"Gy\u0151z\u0151dj meg arr\u00f3l, hogy a 2. lelt\u00e1r f\u00fcl \u00fcres \u00e9s rendelkezik 10K arannyal. A bot megtal\u00e1lja \u00e9s a m\u00e1sodik f\u00fclre helyezi a t\u00e1rgyat, majd legk\u00f6zelebb az oldal friss\u00edt\u00e9se ut\u00e1n olvasztja a t\u00e1rgyat. Az olvaszt\u00e1st minden 5-10 percen bel\u00fcl \u00fajraellen\u0151rzi.",ki:"Gy\u00f3gy\u00edt\u00e1s & Buffs",
ul:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges Arany:",xl:"Licit kihagy\u00e1sa: Egyes\u00fclet tag m\u00e1r licit\u00e1lt a t\u00e1rgyra ",wl:"Licit kihagy\u00e1sa: M\u00e1r licit\u00e1lt a t\u00e1rgyra ",advanced:"Halad\u00f3",arena:"Ar\u00e9na",na:"Aut\u00f3matikus T\u00e1mad\u00e1s",ac:"T\u00e1mad\u00e1s Elker\u00fcl\u00e9se",la:"J\u00e1t\u00e9kos Hozz\u00e1ad\u00e1sa",ma:"Add hozz\u00e1 a j\u00e1t\u00e9kos nev\u00e9t (Same Server)",dl:"Meg\u00e1ll\u00edtja a bot, ha elfogyott az \u00e9tel?",
circusTurma:"Circus Turma",Dh:"Neh\u00e9zs\u00e9g",dungeon:"Kazamata",Eh:"Kazamata Be\u00e1ll\u00edt\u00e1sok",eventExpedition:"Esem\u00e9ny Exped\u00edci\u00f3",expedition:"Exped\u00edci\u00f3",Ih:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sok",Bj:"V\u00e1lassz Sz\u00f6rnyet",gl:"Legmagasabb",el:"Tedd be a gy\u00f3gy\u00edt\u00f3 t\u00e1rgyaid az els\u0151 oldalra a lelt\u00e1rodon bel\u00fcl",fc:"Bent",sg:"Arany T\u00e1rol\u00e1sa",tg:"Arany T\u00e1rol\u00e1sa az Aukci\u00f3ban?",ag:"Haszn\u00e1ld a Munk\u00e1sruh\u00e1t a Bolt Felt\u00f6lt\u00e9s\u00e9hez?",
Kk:"V\u00e1lassz T\u00e9teleket a Vissza\u00e1ll\u00edt\u00e1shoz",Uf:"Lej\u00e1rt T\u00e9telek Vissza\u00e1ll\u00edt\u00e1sa",Ob:"Megjegyz\u00e9s: Az opci\u00f3 enged\u00e9lyez\u00e9s\u00e9vel a bot eladja a k\u00f6zelg\u0151 lej\u00e1rat\u00fa t\u00e1rgyakat a Csomagokb\u00f3l az Egyes\u00fcleti Piacon majd megszak\u00edtja a lej\u00e1rati id\u0151 vissza\u00e1ll\u00edt\u00e1s\u00e1t. Egyes\u00fclet sz\u00fcks\u00e9ges. Gy\u0151z\u0151dj meg r\u00f3la, hogy a t\u00e1sk\u00e1dban van \u00fcres 3x3-as hely.",
Bf:"Bot v\u00e9letlenszer\u0171 sz\u00fcneteltet\u00e9se m\u0171k\u00f6d\u00e9si [Teszt F\u00e1zis]:",da:"Arany T\u00e1rol\u00e1sa: A bot megtartja ezt az aranyat a karakteren:",Ze:"Max Arany: A bot elk\u00f6lti, ha az arany nagyobb, mint",Zf:"A bot v\u00e9letlenszer\u0171 t\u00e1rgyakra fog licit\u00e1lni.",qc:"V\u00e9letlenszer\u0171 k\u00e9sleltet\u00e9s hozz\u00e1ad\u00e1sa",rc:"Itt adhatsz hozz\u00e1 k\u00e9sleltet\u00e9st a bothoz.",Nb:"Jav\u00edt\u00e1s",zl:"Csak K\u00e9k t\u00e1rgy Olvaszt\u00e1s?",
Cl:"Csak Lila t\u00e1rgy Olvaszt\u00e1s?",Bl:"Csak Narancss\u00e1rga t\u00e1rgy Olvaszt\u00e1s?",Rj:"Mindent Olvassz be a 2. f\u00fclben?",Sj:"Ez figyelmen k\u00edv\u00fcl hagyja a sz\u00ednv\u00e1laszt\u00e1sokat",Ya:"El\u0151zm\u00e9nyek T\u00f6rl\u00e9se",og:"Olvaszt\u00e1s",zc:"Search",qf:"Aut\u00f3matikus Aukci\u00f3",Ac:"Az aukci\u00f3 t\u00falzott haszn\u00e1lata kitilt\u00e1st vonhat maga ut\u00e1n. Az esetleges \u00fctk\u00f6z\u00e9sek elker\u00fcl\u00e9se \u00e9rdek\u00e9ben aj\u00e1nlatos letiltani az egy\u00e9b aj\u00e1nlatt\u00e9teli funkci\u00f3kat. Ez a funkci\u00f3 lelass\u00edtja a botot.",
$f:"Keres\u00e9s a Gladi\u00e1torok Aukci\u00f3j\u00e1ban",bg:"Keres\u00e9s a Zsoldosok Aukci\u00f3j\u00e1ban",Ic:"Licit\u00e1l\u00e1s \u00c9telekre?",$e:"Maxim\u00e1lis Licit",Jc:"Licit\u00e1l\u00e1s, ha az \u00e1llapot kevesebb, mint",Kc:"Licit\u00e1lt T\u00e1rgyak",rk:"Aukci\u00f3 Nyelve",sk:"2.9.4-es friss\u00edt\u00e9ssel kapcsolatban k\u00e9rlek \u00e1ll\u00edtsd be \u00fajra a nyelvet, vagy ALAP\u00c9RTELMEZET BE\u00c1LL\u00cdT\u00c1SOK. Gy\u0151z\u0151dj meg r\u00f3la, hogy minden helyesen van be\u00e1ll\u00edtva, k\u00fcl\u00f6nben a licit\u00e1l\u00e1s nem m\u0171k\u00f6dik.",
uc:"Hozz\u00e1adhatsz t\u00e9teleket a piac keres\u00e9s\u00e9hez \u00e9s az aukci\u00f3hoz. Amikor egy t\u00e9telt hozz\u00e1ad a list\u00e1hoz, a piac lila t\u00e9teleket is megjelen\u00edti. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, az al\u00e1bbi opci\u00f3kat haszn\u00e1lhatod",pk:"\u00d3vatosan haszn\u00e1ld az aukci\u00f3t!",qk:"Az aut\u00f3matikus licit\u00e1l\u00e1s t\u00fal sok k\u00e9r\u00e9st k\u00fcldhet a szerverre, \u00e9s kitilthatj\u00e1k, ha folyamatosan haszn\u00e1lod!",
Rf:"\u00dajra Aktiv\u00e1lja az Esem\u00e9nypontokat Rubinokkal?",ed:"Aut\u00f3matikus Olaj Enged\u00e9lyez\u00e9se",uk:"Aut\u00f3matikus Szent Olajok Beszerz\u00e9se",Gk:"K\u00fcldet\u00e9s ellen\u0151rz\u00e9si Sebess\u00e9g",Ta:"T\u00e1madj Egyes\u00fcleti Tagokat?",Ra:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "T\u00e1mad\u00e1s" list\u00e1hoz, amikor t\u00f6bb, mint X ARANYAT rabolsz.:',Sa:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "Elker\u00fclend\u0151 T\u00e1mad\u00e1s" list\u00e1hoz, ha vesz\u00edtesz ellen\u00fck.:',
Rb:"T\u00e1mad\u00e1sok Statisztik\u00e1i",Yb:"Nagyon Hossz\u00fa",Bb:"Hossz\u00fa",Jb:"K\u00f6zepes",Vb:"R\u00f6vid",Zb:"Nagyon R\u00f6vid",fd:"Bel\u00e9p\u00e9s az Alvil\u00e1gba, ha az \u00c9P >",Mf:"K\u00fcldet\u00e9s Ellen\u0151rz\u00e9si Sebess\u00e9g",Ef:'Az alap\u00e9rtelmezett "3x". Ha a bot probl\u00e9m\u00e1kat okoz a k\u00fcldet\u00e9sekkel, \u00e1ll\u00edtsd \u00e1t a k\u00fcldet\u00e9s sebess\u00e9g\u00e9t a szerver sebess\u00e9g\u00e9nek megfelel\u0151en.',Nd:"Gy\u00f3gy\u00edt\u00f3 Kiv\u00e1laszt\u00f3 T\u00e1ska",
gd:'Ha manu\u00e1lisan friss\u00edted a pontokat, akkor kattints a fent l\u00e9v\u0151 gombra: "Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!"',yk:"Legal\u00e1bb az egyiket enged\u00e9lyezned kell a k\u00f6vetkez\u0151k k\u00f6z\u00fcl: exped\u00edci\u00f3, dungeont, ar\u00e9n\u00e1t vagy cirkuszt, hogy elind\u00edtsd az Esem\u00e9ny Exped\u00edci\u00f3t.",Of:"Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!",lb:"Fedezze a T\u00e1rsakat?",Mk:"Hagyd minden be\u00e1ll\u00edt\u00e1st letiltva, ha a csomagokban szerepl\u0151 elemekkel szeretn\u00e9l olvasztani. Azonban m\u00e9g mindig v\u00e1laszthatsz sz\u00edneket.",
vk:"Karakter(Ki) / Zsoldos(Be)",Jk:"Mindkett\u0151t Jav\u00edtani?",Nk:"Id\u0151z\u00edt\u0151k",Timers:"\u00cdrd be az egyes id\u0151z\u00edt\u0151kh\u00f6z a percek sz\u00e1m\u00e1t lent vagy hagyd az alap\u00e9rtelmezetten.",ob:"T\u00e1mad\u00e1s Statisztik\u00e1i Enged\u00e9lyez\u00e9se:",Pb:"V\u00e1lassz tartom\u00e1nyt a t\u00e1mad\u00e1shoz",Qb:"A bot v\u00e9letlenszer\u0171en t\u00e1mad a t\u00e1bl\u00e1zatban szerepl\u0151 j\u00e1t\u00e9kosok k\u00f6z\u00fcl.",qb:"Ligat\u00e1mad\u00e1sok",
nb:"Ligat\u00e1mad\u00e1s Enged\u00e9lyez\u00e9se:",Lb:"V\u00e9letlenszer\u0171 T\u00e1mad\u00e1s",Mb:"T\u00e1mad\u00e1s alacsonyt\u00f3l a magas szint\u0171 j\u00e1t\u00e9kosokig",nk:"A bot alap\u00e9rtelmezetten elker\u00fcli az Egyes\u00fcleti tagok t\u00e1mad\u00e1s\u00e1t.",Cd:"Exped\u00edci\u00f3 Helysz\u00edne:",Bc:"Aut\u00f3matikus B\u00f3nuszok Begy\u0171jt\u00e9se:",ng:"Boss Kihagy\u00e1sa",$c:"Kazamata Helysz\u00edne:",Xf:"Kazamata \u00fajrakezd\u00e9se veres\u00e9g eset\u00e9n?",Qd:"Alvil\u00e1g Be\u00e1ll\u00edt\u00e1sok",
Rd:"K\u00e9rlek konfigur\u00e1ld a gy\u00f3gy\u00edt\u00e1s sz\u00e1zal\u00e9kos be\u00e1ll\u00edt\u00e1sait a gy\u00f3gy\u00edt\u00e1s f\u00fcl\u00f6n, \u00e9s gy\u0151z\u0151dj meg r\u00f3la, hogy a gy\u00f3gy\u00edt\u00e1s f\u00fcl be van kapcsolva. Ha az alvil\u00e1g bel\u00e9p\u00e9se kijelentkeztet, l\u00e9pj a lobbyba, \u00e9s kapcsold be az aut\u00f3mata bejelentkez\u00e9s jel\u00f6l\u0151n\u00e9gyzetet.",Od:"Alvil\u00e1g Neh\u00e9zs\u00e9g",Ec:"Aut\u00f3matikus Alvil\u00e1g Bel\u00e9p\u00e9s: / Alvil\u00e1g Mode",
lh:"Mobiliz\u00e1ci\u00f3 haszn\u00e1lata, ha pontok = 0",ph:"Rubinok haszn\u00e1lata?",hd:"Kil\u00e9p\u00e9s az alvil\u00e1gb\u00f3l, ha nincsenek pontok?",Yg:"A bot megpr\u00f3b\u00e1lja el\u0151sz\u00f6r a Villa Medici-t haszn\u00e1lni, ha nincs, akkor gy\u00f3gy\u00edt\u00f3 italt haszn\u00e1l. Ne felejtsd el bekapcsolni a Gy\u00f3gy\u00edt\u00e1s kapcsol\u00f3t.",gh:"Az aut\u00f3matikus alvil\u00e1g bel\u00e9p\u00e9s letiltja a kazamata/ar\u00e9na/circus be\u00e1ll\u00edt\u00e1sokat az alvil\u00e1g bel\u00e9p\u00e9sekor.",
Ok:"Alvil\u00e1g Gy\u00f3gy\u00edt\u00e1si Be\u00e1ll\u00edt\u00e1sok",oh:"Villa Medici Haszn\u00e1lata?",mh:"Gy\u00f3gy\u00edt\u00f3 Ital Haszn\u00e1lata?",Ne:"INF\u00d3: A bot minden kiv\u00e1lasztott percben keresni fog piaci t\u00e9teleket, ami meg\u00e1ll\u00edthatja a t\u00e1mad\u00e1st a keres\u00e9s alatt.",dd:"Piaci Keres\u00e9s Enged\u00e9lyez\u00e9se:",Oe:"Piaci Keres\u00e9s Id\u0151k\u00f6z Percekben:",Pe:"Javasolt 10 perc.",$d:"T\u00e9tel Be\u00e1ll\u00edt\u00e1sok:",Yd:"T\u00e9tel N\u00e9v Tartalmazza",
H:"Max \u00c1r",ae:"T\u00e9tel T\u00edpus",Zd:"T\u00e9tel Ritkas\u00e1g",Nc:"L\u00e9lekhez k\u00f6t\u00f6ttet v\u00e1s\u00e1roljon?",ce:"V\u00e1s\u00e1roland\u00f3 T\u00e9telek",be:"Megpr\u00f3b\u00e1lja megvenni a t\u00e1sk\u00e1ban l\u00e9v\u0151 legnagyobb \u00e1ron tal\u00e1lhat\u00f3 t\u00e9telt, ha b\u00e1rmelyik megegyezik a maxim\u00e1lis \u00e1r be\u00e1ll\u00edt\u00e1ssal.:",Lc:"Megv\u00e1s\u00e1rolt T\u00e9telek:",ii:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",jk:"\u00c9tel V\u00e1s\u00e1rl\u00e1sa a Boltb\u00f3l?",
kk:"Gy\u00f3gy\u00edt\u00f3 eszk\u00f6z haszn\u00e1lata a Csomagb\u00f3l?",gk:"Cervisia haszn\u00e1lata?",ik:"Toj\u00e1sok haszn\u00e1lata?",kl:"Utols\u00f3 Haszn\u00e1lat",location:"Helysz\u00edn",Strength:"Er\u0151",Dexterity:"\u00dcgyess\u00e9g",Agility:"F\u00fcrges\u00e9g",Constitution:"Alkat",Charisma:"Karizma",Intelligence:"Intelligencia",Ug:"Gyakorl\u00e1s Be\u00e1ll\u00edt\u00e1sok",Vg:"V\u00e1laszd ki az attrib\u00fatumokat, amiket szeretn\u00e9l edzeni. Akkor fogja elkezdeni az edz\u00e9st, ha van el\u00e9g aranyad.",
nc:"K\u00f6vetkez\u0151 l\u00e9p\u00e9s",Pi:"Nem",Qi:"Norm\u00e1l",ol:"Ellens\u00e9g",pl:"Ellens\u00e9g Szintje",pj:"K\u00e9rd\u00e9sek",random:"V\u00e9letlenszer\u0171",vl:"Be\u00e1ll\u00edt\u00e1sok",Gl:"Hamarosan...",type:"Kattints az ikonokra a k\u00e9rd\u00e9s t\u00edpus\u00e1nak kiv\u00e1laszt\u00e1s\u00e1hoz.",Nl:"Igen",D:"Aukci\u00f3/Keres\u00e9s",oc:"T\u00e9telek Hozz\u00e1ad\u00e1sa",ck:"Fejleszt\u0151t\u00e1rgyak Aut\u00f3matikus T\u00e1rol\u00e1sa",Il:"Elk\u00fcld\u00e9s",il:"Id\u0151k\u00f6z : ",
Xk:"Aut\u00f3matikus Licit Enged\u00e9lyez\u00e9se",Yk:"Ne licit\u00e1ljon, ha az Egyes\u00fcleti tag m\u00e1r licit\u00e1lt",Kl:"\u00datmutat\u00f3",bc:"V\u00e1lassz a fenti gombok k\u00f6z\u00fcl, hogy akarod-e az ar\u00e9n\u00e1ban a legkisebb vagy a legmagasabb szint\u0171 ellenfelet. T\u00f6bb felhaszn\u00e1l\u00f3 lass\u00edthatja a bot m\u0171k\u00f6d\u00e9s\u00e9t.",Rk:"Kezdetnek adj hozz\u00e1 egy t\u00e9telt a list\u00e1hoz (pl. `Lucius`). Miut\u00e1n hozz\u00e1adtad, a bot keresni fogja a t\u00e1rgyakat \u00e9s megjelen\u00edti a keres\u00e9si eredm\u00e9nyeket a k\u00e9perny\u0151 bal oldal\u00e1n. Az aut\u00f3matikus aukci\u00f3 c\u00e9lj\u00e1b\u00f3l is keressen r\u00e1 a t\u00e1rgyra. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, a bot rendszeres id\u0151k\u00f6z\u00f6nk\u00e9nt keresni fogja a t\u00e9teleket a megadott id\u0151szak alapj\u00e1n. Ha a bot megtal\u00e1lja a t\u00e1rgyat \u00e9s van el\u00e9g p\u00e9nzed, aut\u00f3matikusan licit\u00e1l majd helyetted. *Megjegyz\u00e9s*: egyedi t\u00e1rgyak keres\u00e9s\u00e9hez a boltban legal\u00e1bb 1 v\u00e9letlenszer\u0171 t\u00e1rgyat hozz\u00e1 kell adnod a keres\u00e9si list\u00e1hoz.",
$k:"A sz\u00f6rny sz\u00e1m\u00e1t a fenti gombok k\u00f6z\u00fcl v\u00e1laszthatod ki. A 1 a legbaloldali sz\u00f6rnyet k\u00e9pviseli. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",Fh:"V\u00e1lassz nehezs\u00e9get a kazamat\u00e1hoz a fentiek k\u00f6z\u00fcl. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",ji:"Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sok",
Gh:"Felesleges arany t\u00e1rol\u00e1sa az egyes\u00fcletben az egyes\u00fcleti piacon t\u00e1rgyak v\u00e1s\u00e1rl\u00e1s\u00e1val. -> Min. Arany",ll:"Mindent Mozgat",ml:"Kijel\u00f6ltek Mozgat\u00e1sa",Uk:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s",Vk:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",Ml:"Rubin",wf:"\u00c1ltal\u00e1nos Be\u00e1ll\u00edt\u00e1sok",Cj:"Mindent Elad",Dj:"Kijel\u00f6ltek Elad\u00e1sa",ka:"Fegyverek",ha:"Pajzsok",Z:"Mellv\u00e9rtek",ca:"Sisakok",ba:"Keszty\u0171k",
ia:"Cip\u0151k",fa:"Gy\u0171r\u0171k",Y:"Amulettek",jh:"\u00c9telek",ih:"Fejleszt\u00e9sek",Nf:"Receptek",bf:"Tekercsek",Pf:"Er\u0151s\u00edt\u00e9sek",Jf:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",If:"\u00cdrja be a sz\u0171rend\u0151 kulcsszavakat, hogy kisz\u0171rje azokat a k\u00fcldet\u00e9seket, amelyeket nem szeretne v\u00e1llalni. You can also use this to accept quests by their reward using keywords.",aa:"Adjon meg kulcssz\u00f3t",I:"Hozz\u00e1ad\u00e1s",Qf:"Elt\u00e1vol\u00edt\u00e1s",
Qc:"T\u00f6rl\u00e9s",Gf:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Elfogad\u00e1sa",Hf:"\u00cdrja be a kulcsszavakat, hogy kiv\u00e1lassza, melyik k\u00fcldet\u00e9seket szeretn\u00e9 v\u00e1llalni. Ez figyelmen k\u00edv\u00fcl hagyja a k\u00fcldet\u00e9st\u00edpusokat",Ha:"Id\u0151 Sz\u0171r\u00e9s\u0171 K\u00fcldet\u00e9sek Kihagy\u00e1sa?",Hk:"K\u00fcldet\u00e9sek",Cc:"Automatikus Kost\u00fcm",kh:"Kost\u00fcm Haszn\u00e1lata?",Hc:"Alap Harc",Zc:"Dungeoni Harc",Dc:"A Bot csak akkor viseli a Dis Pater Normal \u00e9s Medium form\u00e1tumot, ha az exped\u00edci\u00f3/kazamata pontja 0.",
Pd:"Pokoli Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sai",tc:"T\u00e1mad\u00e1s a F\u0151ellens\u00e9g el\u00e9rhet\u0151v\u00e9 v\u00e1l\u00e1sakor?",rb:"Az Ligat\u00e1mad\u00e1s \u00f6nmag\u00e1t letiltja 5 sikertelen t\u00e1mad\u00e1s ut\u00e1n.",Sd:"Szent Olajok",kf:"T\u00e1rgy Neve",ea:"Minim\u00e1lis T\u00e1rgyszint",Ga:"Minim\u00e1lis T\u00e1rgymin\u0151s\u00e9g",sc:"Alkalmaz/T\u00f6r\u00f6l Minut\u00e9ri\u00e1t",Vd:"El\u0151tag/Ut\u00f3tag Kombin\u00e1ci\u00f3 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
rh:"Igen",sf:"Nem",Pa:"El\u0151tag Hozz\u00e1ad\u00e1sa",Qa:"Ut\u00f3tag Hozz\u00e1ad\u00e1sa",pg:"Olvasd el a List\u00e1t",Kb:"El\u0151tag",Wb:"Ut\u00f3tag",Wf:"Lej\u00e1r\u00f3 T\u00e1rgyak Vissza\u00e1ll\u00edt\u00e1sa",qg:"V\u00e9letlenszer\u0171 Olvasd el a Csomagokat?",rg:"Olvasd el a Lapon",pb:"Extr\u00e1k",xc:"\u00c1rver\u00e9s",Se:"Piac",Xb:"Id\u0151z\u00edt\u0151k",Pg:"Olvasd el a Minut\u00e9ri\u00e1t",Og:"Olvasd el, ha nincs el\u00e9g arany",Lg:"Olvasd el, ha nincs t\u00e1rgy",Ia:"Jav\u00edt\u00e1s",
Dg:"Gilda Piac Aranytartalma",zg:"\u00c1rver\u00e9s Aranytartalma",Sg:"Edz\u00e9s",Gg:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa",Qg:"\u00dczletek a Kov\u00e1cshoz",xg:"\u00c1rver\u00e9s Ellen\u0151rz\u00e9se",Ig:"Keres\u00e9s",v:"Enged\u00e9lyez\u00e9s",mf:"Minim\u00e1lis Arany",Sb:"\u00d3ra Kiv\u00e1laszt\u00e1sa",mb:"Arany Adom\u00e1nyoz\u00e1sa a Gildinek",Uc:"Minden 5 percenk\u00e9nt adom\u00e1nyoz. Az id\u0151z\u00edt\u0151k lapr\u00f3l m\u00f3dos\u00edthatja az id\u0151k\u00f6zt",Td:"Mennyit szeretne adom\u00e1nyozni?",
Vc:"Adom\u00e1nyozni, amikor t\u00f6bb van, mint >",ee:"Kevesebb, mint <",Tf:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa \u00e9s Egy\u00e9b Be\u00e1ll\u00edt\u00e1sok",Vf:"Vissza\u00e1ll\u00edt\u00e1s ideje:",Ck:"Tartsa lenyomva a Ctrl (Cmd a Mac-en) billenty\u0171t a t\u00f6bb t\u00e1rgy kiv\u00e1laszt\u00e1s\u00e1hoz",Wd:"Be-/Kiv\u00e1laszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Ed:"Be\u00e1ll\u00edt\u00e1sok Export\u00e1l\u00e1sa",Xd:"Be\u00e1ll\u00edt\u00e1sok Import\u00e1l\u00e1sa",cf:"\u00dczenet Minden J\u00e1t\u00e9kosnak",
df:"[Ultra Pr\u00e9mium Kulcs sz\u00fcks\u00e9ges, \u00fczenet a Discordon az kulcs megszerz\u00e9s\u00e9hez.]",ef:"Adja meg az elk\u00fcldend\u0151 \u00fczenetet",Sc:"Egyedi szkriptek\u00e9rt vegye fel a kapcsolatot vel\u00fcnk a Discordon",gf:"K\u00fcld\u00e9s",hf:"J\u00e1t\u00e9kosok Megjelen\u00edt\u00e9se",ff:"Mindet Kiv\u00e1laszt",jf:"\u00d6sszes Kiv\u00e1laszt\u00e1s Visszavon\u00e1sa",de:"Gy\u0151z\u0151dj\u00f6n meg r\u00f3la, hogy van el\u00e9g hely a t\u00e1sk\u00e1j\u00e1ban. A leh\u0171l\u00e9si id\u0151 2 perc.",
We:"\u00c9tel Elad\u00e1sa a Piacon?",Fb:"\u00c9telre V\u00e1lt\u00e1s a Piacon?"};if("true"!==localStorage.getItem("isInitialized")){const F={Timers:JSON.stringify({Smelting:10,SmeltingNoGold:5,SmeltingNoItem:15,Repair:10,GuildMarket:2,AuctionHoldGold:15,Arena:10,CircusTurma:10,Training:2,ResetExpired:30,SearchTimer:5,StoreForge:30,AuctionCheck:10,GuildDonate:15,guildBattleEnable:120,BuffTimer:5}),packagesPurchased:"[]",questKeywords:"[]",activeItems:'{"gloves":false,"shoes":false,"rings1":false,"rings2":false,"shield":false,"armor":false,"weapon":false,"helmet":false,"necklace":false}',
auctionPrefixes:"[]",auctionSuffixes:"[]",prefixes:"[]",suffixes:"[]",underworldQuestKeywords:"[]",UnderworldQuests:"false",statSettings:JSON.stringify([{stat:"Strength",count:"0",priority:null,continueTraining:!1},{stat:"Dexterity",count:"0",priority:null,continueTraining:!1},{stat:"Agility",count:"0",priority:null,continueTraining:!1},{stat:"Constitution",count:"0",priority:null,continueTraining:!1},{stat:"Charisma",count:"0",priority:null,continueTraining:!1},{stat:"Intelligence",count:"0",priority:null,
continueTraining:!1}]),farmEnable:"false",farmEnemy:"1",farmLocation:"0",HealPickBag:"1",AutoBidInterval:"5",AuctionItemLevel2:"0",HealShop:"false",noItemsLastCheck:"false",dungeonFocusQuest:"false",smeltBlue:"false",smeltGreen:"false",HealClothToggle:"false",questrewardvalue:"2000",smeltOrange:"false",smeltRed:"false",auctionTURBO:"false",smeltusehammers:"false",BuffsEnable:"false",repairPercentage:"10",HealRubyToggle:"false",dungeonLocation:"0",costumeBasic:"1",costumeDungeon:"2",smeltAnything:"false",
skipTimeQuests:"false",skipTimeCircusQuests:"false",costumeUnderworld:"9",wearUnderworld:"false",hellDifficulty:"1",repairMaxQuality:"1",FoodAmount:"3",smeltIgnorePS:"false",EnableSmelt:"false",filterGM:"p","AuctionEmpty.timeOut":"0","BuffCheck.timeOut":"0","CheckDolls.timeOut":"0","AuctionMEmpty.timeOut":"0",expeditionLocation:"0",auctionMinQuality:"0",doQuests:"false",unique_shop_results_height:"124",unique_shop_results_width:"184",unique_shop_results_top:"452",unique_shop_results_left:"368",search_results_top:"112",
search_results_width:"179",search_results_height:"284",search_results_left:"410",itemBought:"false",itemMovedToInventory:"false",AucTab:"true",patmp:"false",arenaPlayer:"true",repairInitiated:"true",doKasa:"false",packages:JSON.stringify({quality:[],type:[1,2,3,4,5,8,6,9,7,12,13,15,19,20,11,21,18,14,99]}),delaySelect:"0",autoAttackList:"[]",avoidAttackList:"[]",autoAttackCircusList:"[]",avoidAttackCircusList:"[]",autoAttackServerList:"[]",removeCircusList:"[]",removeArenaList:"[]",arenacrosslist:"[]",
circuscrosslist:"[]",autoAttackCircusServerList:"[]",doArena:"false",doCircus:"false","gladBotChecks.timeOut":"0","repair.timeOut":"0","storeForgeResources.timeOut":"0",HealCervisia:"false",dungeonAB:"false",bidStatus:"4",doDungeon:"false",doExpedition:"false",arenaAttackGM:"false",circusAttackGM:"false",AutoAuction:"false",auctionminlevel:"0",storeGoldinAuctionmaxGold:"0",storeGoldinAuction:"false",autoAddArenaAmount:"0",autoAddCircusAmount:"0",eventPoints_:"16",storeGoldinAuctionholdGold:"0",TrainingHoldGold:"0",
smeltLevel:"1",MarketHoldGold:"0",KasaHoldGold:"0",HealPackage:"false",smeltPurple:"false",guildPackHour:"3",smeltEverything3:"false",questSpeed:"2","enableHideGold.timeOut":"0",bidFood:"false",auctionmercenaryenable:"false",auctiongladiatorenable:"false",maximumBid:"100000",activateAuction2:"false",scoreboardattackenable:"false",scoreRange:"5",auctionlanguagesettings:JSON.stringify(["Very long","Long","Middle","Short","Very short"]),scoreboardcircusenable:"false",healPercentage:"25",hellEnterHP:"75",
questTypes:JSON.stringify({combat:!0,arena:!0,circus:!0,expedition:!1,dungeon:!1,items:!1}),scoreRangeCircus:"5",underworld:JSON.stringify({cooldown:"",wins:0,isUnderworld:!1,oi:!1}),enableMarketSearch:"false",smeltTab:"1",UnderWorldUseRuby:"false",renewEvent:"false","arena.timeOut":"0","circus.timeOut":"0",AuctionCover:"false",AuctionGoldCover:"false",UnderworldUseMobi:"false",MarketSearchInterval:"5",useVillaMedici:"false",autoEnterHell:"false",useHealingPotion:"false",repairMercenary:"false",repairALL:"false",
AutoBidButton:"false",healstopbot:"false",HealEnabled:"false",minimumGoldAmount:"100000",doEventExpedition:"false",GuildMemberBid:"false",autoCollectBonuses:"false",exitUnderworld:"false",workbench_selectedItem:JSON.stringify({})};Object.keys(F).forEach(L=>{null===localStorage.getItem(L)&&localStorage.setItem(L,F[L])});["license_playerId","eventPoints","playerTimeouts"].forEach(L=>{null!==localStorage.getItem(L)&&localStorage.removeItem(L)});localStorage.setItem("isInitialized","true")};
