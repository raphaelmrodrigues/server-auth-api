var ca="",ea="",we="",showTrial="",qa="",sa={},ua={enable:!1,wp:10,Jp:1,repairArena:!0,repairTurma:!0,itemList1:[],itemList2:[]},xa={type:[],quality:[],iq:!1,useCloths:!1},Aa={enable:!1,cn:!1,An:[1],zo:3,Yn:3,wo:3,yo:3,Mn:3,Oo:3};function G(F){let L=`${window.location.origin}/game/index.php?`;Object.entries(F).forEach((M,D)=>{L+=(0==D?"":"&")+M[0]+"="+M[1]});return L}function T(F){let L=`${window.location.origin}/game/ajax.php?`;Object.entries(F).forEach((M,D)=>{L+=(0==D?"":"&")+M[0]+"="+M[1]});return L}
async function Ha(F,L){L=await Ia(F,L);if(!L)return!1;L.slot&&Na(L.slot,F.dataset.itemId||F.parentNode.dataset.containerNumber);Ta(F,L.x,L.y);return!0}async function fb(F,L){var M=document.getElementById("inv");if(M&&L){var D=L.x;L=L.y;(M=jQuery(M).offset())?(D=Math.ceil(M.left+32*D+16),L=Math.ceil(M.top+32*L+16),console.log(`Dragging item to: x=${D}, y=${L}`),Ta(F,D,L)):console.error("Grid offset could not be determined.")}else console.error("Invalid target grid or slot coordinates.")}
async function Ta(F,L,M){var D=jQuery(F).offset();D={x:D.left,y:D.top};ob(F,"mousedown",{clientX:D.x-window.scrollX,clientY:D.y-window.scrollY});ob(document,"mousemove",{clientX:L-window.scrollX,clientY:M-window.scrollY});ob(document,"mouseup",{clientX:L-window.scrollX,clientY:M-window.scrollY});setTimeout(()=>{window.scroll(scroll.x,scroll.y)},0)}function wb(F){F=F.getAttribute("data-quality");return null!=F?F:"0"}function xb(F){return yb(F).split("-")[0]}
function Gb(F){return parseInt(F.getAttribute("data-amount"),10)}function Hb(F){return F.getAttribute("data-content-type")}function Ib(F){return F.getAttribute("data-level")}function yb(F){return F.getAttribute("data-basis")}
function Zb(F,L){var M=[248,284,275,269,283,282,272,194,259,261,241,166,266,246,258,277,247,270,202,243,242,279,254,274,256,245,250,268,244,281,257,263,278,276,289,262,280,286,267,271,252,255,288,260,264,265];F=parseInt(F.split("-")[0],10);if(![1,2,3,4,5,6,8,9,20].includes(F))return!1;L=L.split("-");F=parseInt(L[6],36);return-1<[173,156,158,182,175,168,180,178,177,162,179,174,172,155,171,183,167,159,166,176,164,157,181,169,161,163,165].indexOf(parseInt(L[5],36))||-1<M.indexOf(F)}
function $b(F){return parseInt(F.getAttribute("data-measurement-x"),10)*parseInt(F.getAttribute("data-measurement-y"),10)}function ac(F){F=F.getAttribute("data-tooltip");F=F.substring(4,F.indexOf(",")).replace('"',"");return unescape(JSON.parse('"'+F+'"'))}function bc(F){F=F.getAttribute("data-tooltip");return parseInt(F.replace(/\./g,"").match(/(\d+) (<img|<div class=\\"icon_gold\\")/i)[1],10)}
function cc(F){F=parseInt(F.getAttribute("data-basis").split("-")[0],10);return-1<[1,2,3,4,5,6,8,9].indexOf(F)}function dc(F){for(var L=0,M=0;M<F.length;M++){var D=F[M];L+=D.ml*D.w}return L}function ec(F){if("string"!==typeof F)return"";F=F.split(" ");return F[F.length-1]}
async function mc(F,L,M){return new Promise(D=>{async function P(ya){ya===fa.length&&P(ya+1);await jQuery.post(fa[ya],ta=>{ta=jQuery("<div>").append(ta)[0];ta=Hc(ta);ta=Ic(ma[0],ma[1],ta);(ta=Jc(L,F,ta))?(D({spot:ta,bag:ya+512}),M&&"function"===typeof M&&M(ta,ya+512)):P(ya+1)})}let fa=[];for(var na of[512,513,514,515])fa.push(T({mod:"inventory",submod:"loadBag",shopType:0,bag:na,sh:W("sh")}));let ma=[5,8];P(0)})}var Kc=[],kf={};
function Na(F,L){if("inv"==F.target||"shop"==F.target){var M=lf(F.target),D=[];for(let P=0;P<F.w;P++)for(let fa=0;fa<F.ml;fa++)D.push(M+"<"+(F.x+P)+","+(F.y+fa)+">");D.forEach(P=>{Kc.includes(P)||Kc.push(P)});L&&(mf(L),kf[L]=D)}}function mf(F){F&&kf.hasOwnProperty(F)&&(kf[F].forEach(L=>{L=Kc.indexOf(L);-1<L&&Kc.splice(L,1)}),delete kf[F])}
function lf(F){let L=document.getElementById(F);return L?"inv"==F?L.parentNode.getElementsByClassName("awesome-tabs current")[0].dataset.jp:"inv"==F?L.dataset.containerNumber:F:F}
function nf(F,L){var M=F.querySelectorAll('.ui-draggable:not([style*="display: none"])');F=Array(5).fill(null).map(()=>Array(8).fill(!1));const D=parseInt(L.getAttribute("data-measurement-x"),10);L=parseInt(L.getAttribute("data-measurement-y"),10);for(var P of M){M=parseInt(P.getAttribute("data-position-x"),10)-1;var fa=parseInt(P.getAttribute("data-position-y"),10)-1,na=parseInt(P.getAttribute("data-measurement-x"),10),ma=parseInt(P.getAttribute("data-measurement-y"),10);for(let ya=0;ya<na;ya++)for(let ta=
0;ta<ma;ta++)0<=M+ya&&8>M+ya&&0<=fa+ta&&5>fa+ta&&(F[fa+ta][M+ya]=!0)}for(P=0;5>P;P++)for(M=0;8>M;M++){fa=!0;for(na=0;na<D;na++){for(ma=0;ma<L;ma++)if(8<=M+na||5<=P+ma||F[P+ma][M+na]){fa=!1;break}if(!fa)break}if(fa)return{x:M,y:P}}return null}
function of(F){var L=F.querySelectorAll('.ui-draggable:not([style*="display: none"])');F=Array(5).fill(null).map(()=>Array(8).fill(!1));for(var M of L){L=parseInt(M.getAttribute("data-position-x"),10)-1;const D=parseInt(M.getAttribute("data-position-y"),10)-1,P=parseInt(M.getAttribute("data-measurement-x"),10),fa=parseInt(M.getAttribute("data-measurement-y"),10);for(let na=0;na<P;na++)for(let ma=0;ma<fa;ma++)0<=L+na&&8>L+na&&0<=D+ma&&5>D+ma&&(F[D+ma][L+na]=!0)}for(M=0;5>M;M++)for(L=0;8>L;L++)if(!F[M][L])return{x:L,
y:M};return null}
async function Ia(F,L){if("shop"==L){var M=document.getElementById("shop");var D=[Math.round(M.clientHeight/32),6]}else if("inv-guild"==L)Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));else if("inv"==L)M=document.getElementById("inv"),D=[5,8];else{if("market"==L){M=document.getElementById("market_sell");var P=jQuery(M).offset();return{x:Math.ceil(P.left+32+8),y:Math.ceil(P.top+32+8),parent:M}}if("avatar"==L)return M=document.getElementById("avatar"),P=
jQuery(M).offset(),{x:Math.ceil(P.left+84),y:Math.ceil(P.top+97),parent:M};if("char"==L)for(var fa=document.getElementById("char").children,na=Number(F.dataset.contentType||"0"),ma=0;ma<fa.length;ma++){var ya=fa[ma];if(Number(ya.getAttribute("data-content-type-accept")||"0")==na&&0==fa[ma].children.length)return P=jQuery(ya).offset(),{x:P.left+5,y:P.top+5}}else return!1}fa=Hc(M);na=parseInt(F.dataset.measurementX,10);ma=parseInt(F.dataset.measurementY,10);try{var ta="shop"!=L&&pf(F,fa)||Jc(ma,na,
Ic(D[0],D[1],fa));if(!ta)return!1;P=jQuery(M).offset();P={x:P.left,y:P.top};return ta={x:Math.ceil(P.x+32*ta.x+8),y:Math.ceil(P.y+32*ta.y+8),parent:M,slot:{target:L,x:ta.x,y:ta.y,ml:ma,w:na}}}catch{return!1}}
function Hc(F){if(!F)return[];var L=[];F=F.getElementsByClassName("ui-draggable");for(var M=0;M<F.length;M++)L.push({y:parseInt(F[M].style.top,10)/32,x:parseInt(F[M].style.left,10)/32,ml:parseInt(F[M].dataset.measurementY,10),w:parseInt(F[M].dataset.measurementX,10),basis:F[M].dataset.basis,hash:F[M].dataset.hash,amount:parseInt(F[M].dataset.amount,10)});return L}
function Ic(F,L,M){var D,P,fa=[];for(D=0;D<F;D++)for(fa.push([]),P=0;P<L;P++)fa[D].push(!1);for(F=M.length-1;0<=F;F--)for(D=0;D<M[F].ml;D++)for(P=0;P<M[F].w;P++)fa[M[F].y+D][M[F].x+P]=!0;return fa}function pf(F,L){let M=F.dataset.amount?parseInt(F.dataset.amount,10):1;for(var D=0;D<L.length;D++)if(L[D].hash==F.dataset.hash&&100>=L[D].amount+M)return{y:L[D].y,x:L[D].x};return!1}
function Jc(F,L,M){var D,P,fa,na,ma=!1;for(D=0;D<=M[0].length-L;D++){for(P=0;P<=M.length-F;P++){if(ma=!0,1==F)0==M[P][D]?ma=!0:0==M[P][D+1]?D++:ma=!1;else for(fa=0;fa<L;fa++){for(na=0;na<F;na++)if(1==M[P+na][D+fa]){ma=!1;break}if(!ma)break}if(ma){for(fa=0;fa<L;fa++)for(na=0;na<F;na++)M[P+na][D+fa]=!0;ma={y:P,x:D};break}}if(ma)break;1==F&&D++}return ma}
function ob(F,L,M){var D="mousemove"!==L,P=window;var fa=M.clientX;M=M.clientY;var na=document.createEvent("MouseEvents");na.initMouseEvent(L,!0,D,P,0,0,0,fa,M,!1,!1,!1,!1,0,document.body.parentNode);F.dispatchEvent(na)}
function qf(){new Promise(F=>{let L=2,M=()=>{--L;0===L&&F()};if(rf.includes("mod=auction")&&rf.includes("ttype=3")){var D=sf();(D<localStorage.getItem("auctionMStatus")&&X("AuctionMEmpty")||4===D&&X("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",D);M()}else rf.includes("mod=auction")?(D=sf(),(D<localStorage.getItem("auctionStatus")&&X("AuctionEmpty")||4===D&&X("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",0),localStorage.setItem("auctionStatus",
D),M()):(jQuery.get(G({mod:"auction",ttype:3,itemLevel:999,itemQuality:2,sh:W("sh")}),P=>{P=sf(jQuery(P));(P<localStorage.getItem("auctionMStatus")&&X("AuctionMEmpty")||4===P&&X("AuctionMEmpty"))&&localStorage.setItem("auctionM.timeOut",0);localStorage.setItem("auctionMStatus",P);M()}),jQuery.get(G({mod:"auction",itemLevel:999,itemQuality:2,sh:W("sh")}),P=>{P=sf(jQuery(P));(P<localStorage.getItem("auctionStatus")&&X("AuctionEmpty")||4===P&&X("AuctionEmpty"))&&localStorage.setItem("auction.timeOut",
0);localStorage.setItem("auctionStatus",P);M()}))})}function tf(F){if(document.querySelector("#inv div.spinner-img"))return setTimeout(()=>{tf(F)},500),!1;F&&F();return!0}var Df=new URLSearchParams(window.location.search);function W(F){return Df.get(F)}
var rf=window.location.search.match(/mod=.*&sh/)?window.location.search.match(/mod=.*&sh/)[0].slice(0,-3):null,Ef=window.location.hostname.split(/\./)?window.location.hostname.split(/\./)[0]:null,Ff={Tp:{l:"muito longo",h:"longo",i:"m\u00e9dio",j:"curto",m:"muito curto"},Up:{l:"foarte lung",h:"lung",i:"mijlociu",j:"scurt",m:"foarte scurt"},Yp:{l:"ve\u013emi dlho",h:"dlho",i:"stredne",j:"kr\u00e1tko",m:"ve\u013emi kr\u00e1tko"},kq:{l:"jako dugo",h:"dugo",i:"srednje",j:"kratko",m:"jako kratko"},xp:{l:"hyvin pitk\u00e4",
h:"pitk\u00e4",i:"keskim\u00e4\u00e4r\u00e4inen",j:"lyhyt",m:"hyvin lyhyt"},Wp:{l:"mycket l\u00e5ng",h:"l\u00e5ng",i:"medel",j:"kort",m:"mycket kort"},aq:{l:"\u00e7ok uzun",h:"uzun",i:"orta",j:"k\u0131sa",m:"\u00e7ok k\u0131sa"},fp:{l:"\u0637\u0648\u064a\u0644 \u062c\u062f\u0627\u064b",h:"\u0637\u0648\u064a\u0644",i:"\u0645\u0646\u062a\u0635\u0641",j:"\u0642\u0635\u064a\u0631",m:"\u0642\u0635\u064a\u0631\u0629 \u062c\u062f\u0627\u064b"},Ep:{l:"\u05d0\u05e8\u05d5\u05da \u05de\u05d0\u05d5\u05d3",h:"\u05d0\u05e8\u05d5\u05da",
i:"\u05d1\u05d9\u05e0\u05d5\u05e0\u05d9",j:"\u05e7\u05e6\u05e8",m:"\u05e7\u05e6\u05e8 \u05de\u05d0\u05d5\u05d3"},gr:{l:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",h:"\u03bc\u03b5\u03b3\u03ac\u03bb\u03b7",i:"m\u03ad\u03c3\u03b7",j:"\u03bc\u03b9\u03ba\u03c1\u03ae",m:"\u03c0\u03bf\u03bb\u03cd \u03bc\u03b9\u03ba\u03c1\u03ae"},kp:{l:"\u043c\u043d\u043e\u0433\u043e \u0434\u044a\u043b\u044a\u0433",h:"\u0434\u044a\u043b\u044a\u0433",i:"\u0441\u0440\u0435\u0434\u0435\u043d",j:"\u043a\u044a\u0441",
m:"\u043c\u043d\u043e\u0433\u043e \u043a\u044a\u0441"},Vp:{l:"\u043e\u0447\u0435\u043d\u044c \u043c\u043d\u043e\u0433\u043e",h:"\u043c\u043d\u043e\u0433\u043e",i:"\u0441\u0440\u0435\u0434\u043d\u0435",j:"\u043c\u0430\u043b\u043e",m:"\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e"},lp:{l:"muito tempo",h:"longo",i:"m\u00e9dio",j:"curto",m:"bastante curto"},pp:{l:"velmi dlouh\u00e1",h:"dlouh\u00e1",i:"st\u0159edn\u00ed",j:"kr\u00e1tk\u00e1",m:"velmi kr\u00e1tk\u00e1"},rp:{l:"meget lang tid",
h:"lang tid",i:"halv tid",j:"kort tid",m:"meget kort tid"},qp:{l:"sehr lange",h:"lange",i:"mittel",j:"kurz",m:"sehr kurz"},sp:{l:"v\u00e4ga pikk",h:"pikk",i:"keskmine",j:"l\u00fchike",m:"v\u00e4ga l\u00fchike"},tp:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},hq:{l:"very long",h:"long",i:"middle",j:"short",m:"very short"},gp:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},vp:{l:"muy largo",h:"largo",i:"medio",j:"corto",m:"muy corto"},Lp:{l:"muy largo",h:"largo",i:"medio",
j:"corto",m:"muy corto"},yp:{l:"tr\u00e8s longtemps",h:"longtemps",i:"moyen",j:"court",m:"tr\u00e8s court"},Gp:{l:"lunghissima",h:"lunga",i:"media",j:"breve",m:"brevissima"},Ip:{l:"\u013coti gar\u0161",h:"gar\u0161",i:"vid\u0113js",j:"\u012bss",m:"\u013coti \u012bss"},Hp:{l:"labai ilgai",h:"ilgai",i:"vidutini\u0161kai",j:"trumpai",m:"labai trumpai"},Dp:{l:"nagyon hossz\u00fa",h:"hossz\u00fa",i:"k\u00f6zepes",j:"r\u00f6vid",m:"nagyon r\u00f6vid"},Mp:{l:"heel lang",h:"lang",i:"gemiddeld",j:"kort",m:"zeer kort"},
oj:{l:"veldig lenge",h:"lenge",i:"medium",j:"kortvarig",m:"veldig kort"},Sp:{l:"bardzo d\u0142ugi",h:"d\u0142ugi",i:"\u015bredni",j:"kr\u00f3tki",m:"bardzo kr\u00f3tki"},cq:{l:"\u8d85\u9577",h:"\u8f03\u9577",i:"\u5e38\u898f\u6642\u9593",j:"\u8f03\u77ed",m:"\u8d85\u77ed"}},sf=(F=document)=>{F=jQuery(".description_span_right",F).text().trim().toLowerCase();for(const L in Ff){const M=Ff[L],D=Object.values(M);for(const P in M)if(M[P].toLowerCase()===F)return D.indexOf(M[P])}return-1};
async function Gf(F="-1",L=""){const M=G({mod:"packages",submod:"sort",page:"1",sh:W("sh")});jQuery.post(M,{packageSorting:"in_desc"});return Promise.all(Array.from({length:2},(D,P)=>P+1).map(async D=>await Hf(F,L,D))).then(D=>D.reduce((P,fa)=>P.concat(fa),[]))}async function Hf(F="-1",L="",M){F=await jQuery.get(G({mod:"packages",f:"0",fq:F||-1,qry:L||"",page:M,sh:W("sh")}),()=>{});return Array.from(jQuery(F).find(".packageItem"))}function If(F){setTimeout(()=>{window.location.reload(!1)},F)}
function Dh(F){window.location.href=`${window.location.origin}/game/index.php?${F}&sh=${W("sh")}`}function Eh(F){F&&(F.classList.contains("disabled")?window.location.reload():F.click())}
function Fh(){return{o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,"")),co:document.querySelectorAll("#cooldown_bar_expedition .cooldown_bar_fill_ready")[0],ao:document.querySelectorAll("#cooldown_bar_dungeon .cooldown_bar_fill_ready")[0],bq:document.querySelectorAll("#cooldown_bar_ct .cooldown_bar_fill_ready")[0],Fa:document.getElementById("expeditionpoints_value_point").innerText,$n:document.getElementById("dungeonpoints_value_point").innerText,
hp:document.querySelectorAll("#cooldown_bar_arena .cooldown_bar_fill_ready")[0],vn:parseInt(document.getElementById("sstat_ruby_val").innerText,10),level:parseInt(document.getElementById("header_values_level").innerText,10)}}function X(F){let L=(new Date).getTime(),M=localStorage.getItem(F+".timeOut");null===M?(localStorage.setItem(F+".timeOut",0),M=0):M=parseInt(M,10);return M<=L?!0:!1}
function Gh(){let F=0;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(L=>{F+=Math.round(.04*L.price)});return Fh().gold>=F?!0:!1}function Hh(F,L){L-=F;let M=.04*F;JSON.parse(localStorage.getItem("packagesPurchased")||"[]").forEach(D=>{M+=Math.round(.04*D.price)});return L>=M}function Z(F,L){localStorage.setItem(F+".timeOut",(new Date).getTime()+Math.floor(6E4*(L?L:5)))};(async function(){function F(){var b=document.querySelector('span[data-ticker-type="countdown"]');if(window.location.href.includes("/index.php?mod=reports")&&!b||window.location.href.includes("/index.php?mod=guildMarket")&&!b||window.location.href.includes("/index.php?mod=quests")&&!b){b=document.getElementById("blackoutDialog");var c=document.getElementById("blackoutDialognotification");const h=document.getElementById("blackoutDialogLoginBonus");if(null!==b&&"none"!==window.getComputedStyle(b).display){c=
localStorage.getItem("nestSearchType");var e=document.querySelector("#blackoutDialog.loot-modal");if(c&&e){e=null;b=b.querySelectorAll(".action_buttons button");switch(c){case "quick":e=b[1];D("Quick Search clicked");break;case "thorough":e=b[2];D("Thorough Search clicked");break;case "nothing":e=b[0];D("Return to Safety clicked");break;default:e=b[2],D("Thorough Search clicked")}e&&e.click()}}else null!==h&&zb&&!1===zb.isUnderworld?setTimeout(()=>{h.getElementsByTagName("input")[0]?.click()},100):
null!==c&&"none"!==window.getComputedStyle(c).display&&setTimeout(()=>{const k=document.getElementById("breakDiv");k&&k.click()},100)}}function L(){uf=setInterval(function(){vf++;5>=vf?location.reload():clearInterval(uf)},12E4)}function M(){var b="Pantheon;Panteon;Gudarnas tempel;\u0628\u0627\u0646\u062a\u064a\u0648\u0646;\u041f\u0430\u043d\u0442\u0435\u043e\u043d;Panth\u00e9on;\u795e\u8aed;\u05e4\u05e0\u05ea\u05d9\u05d0\u05d5\u05df".split(";"),c=null;for(var e of b)if(c=document.querySelector(`a[title="${e}"]`))break;
return c&&(b=c.innerHTML,(e=b.match(/<font color="green">(\d+)<\/font>/))&&0<e[1]||b.includes('color="green"')||b.includes("Nowe")||b.includes("Yeni")||b.includes("New")||b.includes('color="yellow"')||b.includes("Yeni")||b.includes("Nowe")||b.includes("New")||(c=c.innerText.match(/Pantheon \((\d+)\)/))&&0<c[1])?(localStorage.setItem("nextQuestTime",0),localStorage.setItem("nextQuestTime.timeOut",0),!0):!1}function D(b){function c(g){let l=localStorage.getItem(g);l&&(l=JSON.parse(l),localStorage.setItem(g,
JSON.stringify(l.slice(-20))))}var e=document.querySelector("#logEntriesContainer");if(e){var h=new Date,k=`${h.getHours().toString().padStart(2,"0")}:${h.getMinutes().toString().padStart(2,"0")}`;h=document.createElement("p");h.style.margin="0";h.style.padding="0";h.style.fontSize="12px";b=`[${k}] ${b}`;h.textContent=b;e.prepend(h);(e=localStorage.getItem("savedLogs"))?e=JSON.parse(e):e=[];e.unshift(b);30<e.length&&e.pop();localStorage.setItem("savedLogs",JSON.stringify(e));c("bidList");c("smeltedItems");
c("MarketboughtItems")}}function P(b,c){switch(b){case "itemRepaired":ka.Fm++;break;case "itemReset":ka.Gm++;break;case "goldCycled":ka.Dm++;break;case "arenaAttacks":ka.sm++;break;case "circusAttacks":ka.vm++;break;case "dungeonAttacks":ka.ym++;break;case "expeditionAttacks":ka.Am++;break;case "itemSmelted":ka.Hm++;break;case "underworldAttacks":ka.Om++;break;case "arenaMoney":ka.dm+=c;break;case "circusMoney":ka.em+=c}localStorage.setItem("userStats",JSON.stringify(ka))}function fa(){gb||(gb=document.createElement("div"),
gb.className="confirmation-popup",gb.innerHTML='\n                <p>Are you sure you want to reset the bot?</p>\n                <button id="confirmReset">Yes</button>\n                <button id="cancelReset">No</button>\n            ',document.body.appendChild(gb),document.getElementById("confirmReset").addEventListener("click",function(){const b=["tkz_lcr","Username","tkn","nana_lcn"];let c=[];for(let e=0;e<localStorage.length;e++){const h=localStorage.key(e);!h||b.includes(h)||h.startsWith("gladiatusCrazyAddonData_")||
c.push(h)}for(const e of c)localStorage.removeItem(e);window.location.reload();gb.style.display="none"}),document.getElementById("cancelReset").addEventListener("click",function(){gb.style.display="none"}));gb.style.display="block"}function na(b,c){return null==b?"":b.split("").map(e=>String.fromCharCode(e.charCodeAt(0)+c)).join("")}async function ma(b,c,e,h){h=na(h,3);const k={action:"vx",data:{token:b,refreshToken:c,playerId:e,up:h}};try{const g=await Promise.race([new Promise((l,q)=>{chrome.runtime.sendMessage(k,
m=>{chrome.runtime.uo||!m?q(chrome.runtime.uo||"No response"):l(m)})}),new Promise(l=>setTimeout(()=>l("timeout"),6E4))]);if("timeout"===g)await new Promise(l=>setTimeout(l,1E3)),window.location.reload();else if(g.success||g.s){const l=g.data||g.d;if(l.valid&&!l.expired)return ca=l.playerId,qa=l.supportDevs,"true"!==localStorage.getItem("nana_lcn")&&localStorage.setItem("nana_lcn","true"),l.announcement&&0<=l.announcement.length&&localStorage.getItem("latestAnnouncement")!==l.announcement&&localStorage.setItem("latestAnnouncement",
l.announcement),await ta(l.supportDevs).then(q=>{ea=q}),!0;if(l.expired&&(sessionStorage.setItem("autoGoActive","false"),l.newToken))return l.newToken&&(localStorage.setItem("token",l.newToken+1),localStorage.setItem("nana_lcn","false"),ca=fc()+"l",hb()),!1}else new Promise(l=>setTimeout(()=>l("timeout"),3E4))}catch(g){return window.location.reload(),!1}}function ya(b){return((localStorage.getItem("playerId")|0)+5|0)%100===b}async function ta(b){function c(l){const q=[];for(let m=0;m<l.length;m+=
2)q.push(parseInt(l.substr(m,2),16));return new Uint8Array(q)}const [e,h]=b.split(":");b=c(e);const k=c(h),g=await window.crypto.subtle.importKey("raw",c("46d9ef519c1474cf8699ba24ab2a726a"),{name:"AES-CBC"},!1,["decrypt"]);b=await window.crypto.subtle.decrypt({name:"AES-CBC",iv:b},g,k);b=(new TextDecoder).decode(new Uint8Array(b));b=new Date(b);b.setHours(0,0,0,0);return b}function Ph(b){(b.target.classList.contains("licotok-close")||"licotok"===b.target.id)&&document.getElementById("licotok").remove()}
async function Qh(){fc();const b=document.getElementById("licotok-input").value.trim(),c=localStorage.getItem("playerId"),e=document.getElementById("status_message");const u=localStorage.getItem("idkps");let response=null;try{response=await fetch('https://gldbotserver.com/validate-license',{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idkps:u,license:b}),});const data=await response.json();
if(data.valid){localStorage.setItem("nana_lcn","true"),localStorage.setItem("tkz_lcr",data.token),localStorage.setItem("license_remaining",data.expirationDate),localStorage.setItem("globalAnnouncement",data.globalAnnouncement),localStorage.setItem("tkn",data.refreshToken),localStorage.setItem("we",data.p),localStorage.setItem("pid",c),ca=c,window.location.reload()
}else{e.textContent=data.message||"Invalid license key or token! Just purchased? Wait 10 minutes before activating the key.";e.style.display="block";}}catch(error){alert("Erro no servidor de autenticação");}}function Ya(b){var c=document.createElement("div");c.setAttribute("id","licotok");c.innerHTML=`
        <style>
            .licotok-popup {
            background: #ddd5b4; /* Beige background */
            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            color: #333; /* Darker text color for better contrast */
            padding: 20px;
            border: 1px solid #c4ac70; /* Golden border */
            font-family: Arial, sans-serif; /* Optional: Change the font */
            }
        
            .licotok-popup h2 {
            color: #333;
            text-shadow: none; /* Removing text shadow for better readability */
            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */
            padding: 10px;
            margin: -20px; /* To offset the padding of the parent */
            margin-bottom: 15px;
            border-radius: 10px 10px 0 0; /* Rounded corners on the top */
            }
        
            .licotok-popup a {
            text-decoration: none;
            color: #fff; /* White text for buttons */
            background-color: #c4ac70; /* Golden background */
            border-radius: 5px;
            padding: 5px 10px;
            margin-right: 10px;
            transition: background-color 0.3s ease;
            }
        
            .licotok-popup a:hover {
            background-color: #b3a369; /* Darker shade on hover */
            }
        
            .licotok-popup input {
            width: calc(100% - 10px); /* Full width minus padding */
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #c4ac70; /* Border color similar to the theme */
            border-radius: 5px;
            }
        

            
            .licotok-popup #status_message {
            margin-top: 10px;
            }
        </style>
        <div class="licotok-popup">
        <h2>Warning</h2>
        <span style="color: black" class="span-new">${b}</span>
        <p>
        <button id="licotok-close" class="awesome-button">Close</button>
        <div id="status_message"></div>
    </div>
        
        `;document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);c.querySelector("#licotok-close").addEventListener("click",function(){c.remove()})}function Rh(){var b=document.createElement("div");b.setAttribute("id","licotok");b.innerHTML = '\n        <style>\n            .licotok-popup {\n            background: #ddd5b4; /* Beige background */\n            box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n            border-radius: 10px;\n            color: #333; /* Darker text color for better contrast */\n            padding: 20px;\n            border: 1px solid #c4ac70; /* Golden border */\n            font-family: Arial, sans-serif; /* Optional: Change the font */\n            }\n        \n            .licotok-popup h2 {\n            color: #333;\n            text-shadow: none; /* Removing text shadow for better readability */\n            background: linear-gradient(to right, #c4ac70, #ddd5b4); /* Gradient title background */\n            padding: 10px;\n            margin: -20px; /* To offset the padding of the parent */\n            margin-bottom: 15px;\n            border-radius: 10px 10px 0 0; /* Rounded corners on the top */\n            }\n        \n            .licotok-popup a {\n            text-decoration: none;\n            color: #fff; /* White text for buttons */\n            background-color: #c4ac70; /* Golden background */\n            border-radius: 5px;\n            padding: 5px 10px;\n            margin-right: 10px;\n            transition: background-color 0.3s ease;\n            }\n        \n            .licotok-popup a:hover {\n            background-color: #b3a369; /* Darker shade on hover */\n            }\n        \n            .licotok-popup input {\n            width: calc(100% - 10px); /* Full width minus padding */\n            padding: 5px;\n            margin-bottom: 10px;\n            border: 1px solid #c4ac70; /* Border color similar to the theme */\n            border-radius: 5px;\n            }\n        \n\n            \n            .licotok-popup #status_message {\n            margin-top: 10px;\n            }\n        </style>\n        <div class="licotok-popup">\n            <h2>Enter Your License Key</h2>\n            <input id="licotok-input" type="text" placeholder="License Key">\n            &nbsp<a href="https://gldbotserver.com/home-gld" target="_blank">Buy GLDbot license</a>\n                        <a href="https://gldbot.gumroad.com/l/gladiatusbot" target="_blank">Gumroad official page</a>\n                        <p>\n            <a href="#" id="get-trial-key-a">Get a Trial Key</a>\n            <a href="" target="_blank">Discord</a>\n                       <div id="alertMessage" class="alert-message" style="display: none; font-weight: bold;"></div>\n\n      <hr>      <li>\n             <span style="color: class="span-new">[BRASIL] Experimente o teste gratuito de 1 dia. A licença ficará salva na aba “Extras” caso você esqueça. Se você limpar a cache ou reinstalar o navegador. Você deve inserir sua chave novamente para ativar o bot.</span>\n            </li>\n      <hr>      <li>\n            <span style="color: class="span-new">[ENGLISH] Try 1 day free trial. The license will be saved in the "Extras" tab in case you forget it. If you clear your caches or reinstall the browser. You have to enter your key again to enable the bot.</span>\n     <hr>       </li>\n            <p>\n            <span style="color: class="span-new">If you have some questions or suggestions, contact us E-mail: <strong>gldbotsuport@gmail.com</strong></span>\n\n  <br>          <button class="awesome-button licotok-submit">Submit</button>\n            <button class="awesome-button licotok-close">Close</button>\n            <div id="status_message"></div>\n        </div>\n        ';
document.getElementById("header_game").insertBefore(b,document.getElementById("header_game").children[0]);b.addEventListener("click",Ph);b.querySelector(".licotok-submit").addEventListener("click",Qh);let c=localStorage.getItem("idkps");if(null==c)try{fc(),c=localStorage.getItem("idkps")}catch{}b.querySelector("#get-trial-key-a").addEventListener("click",function(){async function e(h){return fetch(h,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({playerId:c})}).then(k=>
k.json()).then(k=>{var g=document.getElementById("alertMessage");k.success?(g.textContent="Your 1 day trial key : "+k.trialKey,g.style.display="block",showTrial=k.trialKey,localStorage.setItem("showTrial",k.trialKey)):(g.textContent=k.message,g.style.display="block")})}e("https://gldbotserver.com/get-trial").catch(()=>e("https://gldbotserver.com/get-trial")).catch(()=>{})})}
function fc(){let b;if(!b){const c=/var playerId\s*=\s*(\d+);/;Array.from(document.getElementsByTagName("script")).some(e=>(e=c.exec(e.textContent||e.innerText))&&e[1]?(b=e[1],!0):!1)}if(!b){const c=document.getElementById("content");c&&c.querySelectorAll('section[style="display: block;"]').forEach(e=>{Array.from(e.getElementsByTagName("p")).forEach(h=>{Array.from(h.getElementsByTagName("b")).forEach(k=>{k=k.textContent.trim();k.includes("gladiatus.gameforge.com/game/index.php?mod=player&")&&(b=(new URLSearchParams((new URL(k)).search)).get("p"))})})})}b||
(document.cookie.split("; ").forEach(c=>{c.trim().startsWith("gladiatus")&&!b&&(c=decodeURIComponent(c.split("=")[1]).match(/^\d+/))&&(b=c[0])}),document.cookie.split("; ").forEach(c=>{c.trim().startsWith("GB_")&&!b&&(c=c.split("=")[1].split("_"),b=0<c.length&&!isNaN(c[0])?c[0]:null)}));let cc=b;return b?(localStorage.setItem("playerId",18835),localStorage.setItem("pid",18835),localStorage.setItem("idkps",cc),18835):null}function Sh(){let b=document.querySelector(".playername")||document.querySelector(".playername_achievement");b&&(b=b.textContent.trim(),
localStorage.setItem("Username",b))}async function rest(){const autoGoButton=document.getElementById("autoGoButton");if(autoGoButton)autoGoButton.remove();const customButtons=document.querySelectorAll(".customButton2");customButtons.forEach(button=>button.remove());sessionStorage.setItem("autoGoActive",!1);}async function pt(){fc();const idkps=localStorage.getItem("idkps");try{const response=await fetch('https://gldbotserver.com/validate-key',{method:'POST',headers:{'Content-Type':'application/json',},body:JSON.stringify({idkps}),});const d=await response.json();if(d.valid){localStorage.setItem("we",d.p);localStorage.setItem("globalAnnouncement",d.globalAnnouncement);Bf();}else{rest().then(()=>{hb();}).catch(error =>{console.error("rest:",error);});}}catch(error){alert("Erro ao conectar com o servidor de autenticação");}}async function wf(){try{const b=await jQuery.get(G({mod:"premium",submod:"centurio",sh:W("sh")}));return(new DOMParser).parseFromString(b,"text/html").querySelector("#premium_duration")?!1:!0}catch(b){}}function pb(b,c,e){var h="";e&&(h=new Date,h.setTime(h.getTime()+864E5*e),h="; expires="+h.toUTCString());document.cookie=b+"="+(c||"")+h+"; path=/; domain=.gameforge.com"}function qb(b){b+="=";for(var c=document.cookie.split(";"),e=0;e<c.length;e++){for(var h=c[e];" "===
h.charAt(0);)h=h.substring(1,h.length);if(0===h.indexOf(b))return h.substring(b.length,h.length)}return null}function xf(b){document.cookie=`glautologin=${b?"true":"false"}; path=/; domain=.gameforge.com; samesite=strict`}function Lc(){let z5=localStorage.getItem("we");we=new Date(z5);return"true"===localStorage.getItem("nana_lcn")&&gc&&ea>=new Date&&we>=new Date&&va===Mc&&ca===va}function Nc(b,c){b.style.border="1px solid #c4ac70";b.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";b.style.color="#bfae54";b.style.padding="5px 10px";b.style.cursor="pointer";b.style.borderRadius="5px";b.style.flexGrow=
"1";b.style.marginRight="5px";b.style.boxShadow="0px 0px 15px 2px rgba(0, 0, 0, 0.3)";b.style.fontFamily="Arial, sans-serif";b.style.transition="background-color 0.2s"}function yf(){localStorage.setItem("logMenuHeight",pa.style.height)}function Th(){var b=document.querySelector(".playername.ellipsis");const c=va;b&&(b=`${b.textContent.trim()}-${c}`,localStorage.setItem("Username",b),document.cookie=`gllastusername=${b}; path=/; domain=.gameforge.com; samesite=strict`)}async function Uh(){var b={async Mm(){var c=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${localStorage.getItem("filterGM")}&p=1`;
if(rf!==c)Dh(c);else try{const q=localStorage.getItem("guildPackHour");let m=JSON.parse(localStorage.getItem("packagesPurchased")||"[]");if(m.length){var e=m[0],h=await Gf(e.quality,e.itemName);h=h.filter(n=>{n=n.querySelector(".ui-draggable");return e.itemLevel===Ib(n)&&e.itemName===ac(n)&&e.basis===yb(n)&&e.quality===wb(n)&&e.amount===Gb(n)});if(h.length&&h[0].querySelector(".ui-draggable")){const n=h[0].querySelector(".ui-draggable");Ib(n);ac(n);yb(n);wb(n);Gb(n);var k=parseInt(n.getAttribute("data-measurement-x"),
10),g=parseInt(n.getAttribute("data-measurement-y"),10),l=h[0].querySelector("input").value;let {spot:r,bag:w}=await mc(k,g);const u=await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+l,fromX:1,fromY:1,to:w,toX:r.x+1,toY:r.y+1,amount:e.amount}),{a:(new Date).getTime(),sh:W("sh")}),t=JSON.parse(u).to.data.itemId;c=0;if(2>c||u.includes("containerNumber"))if((await jQuery.post(G({mod:"guildMarket",sh:W("sh")}),{sellid:t,preis:e.price,dauer:q||3,sell_mode:0,anbieten:"Offer"})).includes("<!DOCTYPE HTML>"))D("Item "+
e.itemName+" sold for "+e.price+" gold"),P("goldCycled",0),m.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(m)),window.location.reload();else if(c++,2>c)await this.Mm();else{const y=JSON.parse(localStorage.getItem("Timers"));Z("gold",y.GuildMarket||2);window.location.reload()}}else m.shift(),localStorage.setItem("packagesPurchased",JSON.stringify(m)),window.location.reload()}}catch(q){D("Empty first slots of the first inventory at least 2x3."),window.location.reload()}},async Qn(c,
e){let h=c.shift();var k=!1;const g={GUILD_TOOLS:["2097152","1048576","8388608","4194304"],GUILD_FORGE_RESOURCES:["32768"],GUILD_WEAPONS:["2"],GUILD_SHIELD:["4"],GUILD_CHEST:["8"],GUILD_HELMET:["1"],GUILD_GLOVES:["256"],GUILD_SHOES:["512"],GUILD_RINGS:["48"],GUILD_AMULETS:["1024"],GUILD_USABLES:["4096"],GUILD_FOOD:["64"],GUILD_UPGRADES:["4096"],GUILD_RECIPES:["8192"],GUILD_MERCENARY:["16384"],GUILD_SCROLLS:["64"],GUILD_REINFORCEMENTS:["4096"]};let l=JSON.parse(localStorage.getItem("itemsToResetGuild")||
"[]");for(l=l.map(q=>!q.startsWith("GUILD_")&&g["GUILD_"+q]?"GUILD_"+q:q);h;){const q=h.type;(0===l.length||l.some(m=>g[m]?.includes(q)))&&Hh(h.price,e)&&e>=h.price&&(e-=h.price,await jQuery.post(G({mod:"guildMarket",sh:W("sh")}),{buyid:h.id,f:0,fl:0,fq:-1,p:1,buy:"Comprar"}),k=JSON.parse(localStorage.getItem("packagesPurchased")||"[]"),k.push(h),localStorage.setItem("packagesPurchased",JSON.stringify(k)),D("Item Bought: "+h.itemName+" for "+h.price),k=!0);h=c.shift()}return k},async buy(){const c=
localStorage.getItem("filterGM"),e=JSON.parse(localStorage.getItem("Timers"));let h=Number(localStorage.getItem("currentPage")||1);var k=`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${h}`;if(rf!==k)Dh(k);else if(!(ba.gold<=Math.floor(localStorage.getItem("KasaHoldGold")))){var g=document.querySelectorAll("#market_item_table tr"),l=document.querySelectorAll("#market_item_table input[name=buyid]");k=[];for(let q=1;q<g.length;q++){let m=g[q].querySelectorAll("td"),n=m[0].querySelector("div"),
r=Number(m[2].innerText.replace(/\./g,"")),w=m[5].querySelector("input");"cancel"===w.name||w.classList.contains("disabled")||r<Number(localStorage.getItem("minimumGoldAmount"))||r>Fh().gold-Number(localStorage.getItem("KasaHoldGold"))||k.push({id:l[q-1].value,itemLevel:Ib(n),itemName:ac(n),basis:yb(n),type:Hb(n),quality:wb(n),amount:Gb(n),sellerName:m[1].querySelector("span").innerText,price:r})}g=Fh().gold-Number(localStorage.getItem("KasaHoldGold"));if(k.length&&Gh())await this.Qn(k,g)||Z("gold",
e.GuildMarket||2),window.location.reload();else try{const q=document.querySelector(".standalone").textContent.match(/(\d+)\s*\/\s*(\d+)/);h<(q?parseInt(q[2],10):1)?(localStorage.setItem("currentPage",h+1),Dh(`mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=${c}&p=${h+1}`)):(localStorage.setItem("currentPage",1),Z("gold",e.GuildMarket||2),window.location.reload())}catch(q){D("No items to buy in guild market today. :/"),localStorage.setItem("currentPage",1),Z("gold",e.GuildMarket||2),window.location.reload()}}}};
0<JSON.parse(localStorage.getItem("packagesPurchased")||"[]").length?await b.Mm():ba.gold>Number(localStorage.getItem("minimumGoldAmount"))+Number(localStorage.getItem("KasaHoldGold"))?await b.buy():(b=JSON.parse(localStorage.getItem("Timers")),Z("gold",b.GuildMarket||2),window.location.reload())}function Vh(){var b=document.getElementById("submenuhead1"),c=document.getElementById("submenu1"),e=document.getElementById("submenuhead2"),h=document.getElementById("submenu2"),k=document.getElementById("main");
k&&(k.style.height="950px",k.style.minHeight="950px");b&&(b.style.display="block");c&&(c.style.display="block");e&&(e.style.display="none");h&&(h.style.display="none")}function Oc(){var b=localStorage.getItem("premiumDicesLeft");b=parseInt(b,10);return isNaN(b)?0:b}function Wh(){var b=document.querySelector(".contentboard_footer_long .contentboard_inner");if(b){b.style.position="relative";b.style.overflowX="visible";b.style.overflowY="visible";b.style.height="auto";b.style.minHeight="450px !important";
var c=document.createElement("div");c.id="customContainer";c.style.cssText="border: 2px solid #BA9700; padding: 10px; margin-top: 20px;  border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5); text-align: center; width: 100%; box-sizing: border-box; min-height: 400px;";b.appendChild(c);b=document.createElement("button");b.textContent="Start";b.className="button1";b.style.marginTop="10px";c.appendChild(b);var e=document.createElement("button");e.textContent="Stop";e.className="button1";e.style.marginTop=
"10px";c.appendChild(e);var h=document.createElement("div");h.id="dicesLeft";var k=Oc();h.textContent=`Dices left: ${k}`;h.style.fontWeight="bold";h.style.marginTop="10px";c.appendChild(h);h=document.createElement("div");h.textContent='GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.';h.style.marginTop="5px";c.appendChild(h);h=document.createElement("div");h.id="results";h.style.cssText="display: flex; flex-wrap: wrap; justify-content: center; gap: 5px; margin-top: 10px; overflow-x: hidden; overflow-y: auto; max-height: 400px;";
c.appendChild(h);var g=document.createElement("div");g.id="progressIndicator";g.textContent="Ready to start.";g.style.marginTop="10px";c.appendChild(g);b.addEventListener("click",async function(){g.textContent="Processing...";await Xh()});e.addEventListener("click",function(){g.textContent="Process stopped by user. Completed!";window.location.reload()});Yh()}}function Yh(){let b;var c=document.querySelector(".mysterybox_count");c=c?parseInt(c.textContent,10):0;localStorage.setItem("chestsLeft",c);
var e=document.getElementById("mysterybox_luck");if(e)for(var h of e.childNodes)if(h.nodeType!==Node.TEXT_NODE&&h.nodeType===Node.ELEMENT_NODE)if("IMG"===h.tagName&&h.currentSrc.includes("4197f09a37be7d221c34f3e0d957e7.png"))break;else"INPUT"===h.tagName&&"button"===h.type&&(e=h.getAttribute("onclick").match(/tokenAmount=(\d+)/))&&e[1]&&(b=parseInt(e[1],10));h=document.getElementById("dicesLeft");e=Oc();h.textContent=0>b?"Dices left: Cannot determine. Please refresh the page.":`Dices left: ${e}`;
localStorage.setItem("chestsLeft",c);localStorage.setItem("premiumDicesLeft",b)}async function Xh(){0>=parseInt(localStorage.getItem("premiumDicesLeft"),10)?alert("No dices left!"):await Pc()}async function Pc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");if(!b||0>=b&&0>=c)e.textContent="All actions completed: No dices or chests left.";else if(!b||0>=b)e.textContent="No dices left. Trying to open remaining chests...",
await hc();else if(!c||0>=c)e.textContent="No chests left!";else{e.textContent="Refreshing mystery box...";var h=(new URL(window.location.href)).searchParams.get("sh")||"",k=document.querySelectorAll(".mysterybox_reward_item_pool"),g="Vulcano;Junos;Bergzorns;Weitsicht;Eole;Junon;Armure;Masque;Vulcain;Neptuno;Eolo;Armatura;Sguardo;Olhos;Alento;Nettuno;Respiro;Soffio;mortal de;Aliento;Armadura;Vista;Zbroja;Orli;Neptuna;Feronii;Wulkana;Wrath;Eagle;Pluto;Neptune;Vulcanus;Junosa;Plutosa;Ajolos;Vulcano;Feronia;Feronias;Plutos;Neptun;Aeolus;Pluton;Juno;Ejderha;Kartal;nefesi".split(";"),
l=!1;for(let q of k){const m=q.getAttribute("data-tooltip");if(g.some(n=>m.includes(n))){l=!0;break}}if(l)await hc();else try{const q=await jQuery.get(G({mod:"mysterybox",submod:"refresh",$p:b,sh:h}));b--;localStorage.setItem("premiumDicesLeft",b);const m=document.getElementById("dicesLeft"),n=Oc();m.textContent=`Dices left: ${n}`;const r=(new DOMParser).parseFromString(q,"text/html").querySelectorAll(".mysterybox_reward_item_pool");h="Vulcano Feronia Neptun Aeolus Pluton Juno Ejderha Kartal nefesi".split(" ");
k=!1;for(let w of r){const u=w.getAttribute("data-tooltip");if(u&&h.some(t=>u.includes(t))){k=!0;break}}k?await hc():0<b?setTimeout(Pc,1E3):0<c?await hc():(e.textContent="Completed all possible actions.",D("No more actions possible: No premium dices or chests left."))}catch(q){D("Error refreshing mystery box. Please try again.")}}}async function hc(){let b=parseInt(localStorage.getItem("premiumDicesLeft"),10),c=parseInt(localStorage.getItem("chestsLeft"),10);const e=document.getElementById("progressIndicator");
if(!c||0>=c)e.textContent="No chests left to open!";else{e.textContent="Opening chest...";var h=(new URL(window.location.href)).searchParams.get("sh")||"",k=(new Date).getTime();try{const g=await jQuery.get(T({mod:"mysterybox",submod:"pick",sh:h,a:k}));b--;c--;localStorage.setItem("premiumDicesLeft",b);localStorage.setItem("chestsLeft",c);(new DOMParser).parseFromString(g,"text/html");const l=document.querySelector(`.mysterybox_reward_item_pool img[alt="${g}"]`);if(l){const q=document.createElement("div");
q.className="result-item";q.style.border="1px solid #ccc";q.style.borderRadius="5px";q.style.padding="2px";q.style.margin="1px";q.style.textAlign="center";q.style.backgroundColor="#fff";q.style.boxSizing="border-box";q.style.flex="1 0 20%";const m=document.createElement("img");m.src=l.src;m.alt="Item Image";m.className="result-image";m.style.maxWidth="50px";m.style.display="block";m.style.margin="0 auto";const n=document.createElement("span"),r=l.closest(".mysterybox_reward_item_pool").getAttribute("data-tooltip").match(/"([^"]+)"/);
n.textContent=r?r[1]:"Unknown Item";n.style.display="block";n.style.marginTop="5px";n.style.fontSize="12px";q.appendChild(m);q.appendChild(n);document.querySelector("#results").appendChild(q)}0<b||0<c?(e.textContent="Chest opened. Checking for more actions...",setTimeout(Pc,1E3)):e.textContent="All dices and chests used up."}catch(g){D("Error opening chest. Please try again.")}}}function Wa(){Qc.length=0;document.querySelectorAll(".rule-row").forEach(b=>{const c=b.querySelector(".rule-condition-select").value;
var e=b.querySelector(".rule-prefix-input"),h=b.querySelector(".rule-suffix-input");e=e?e.value:"";h=h?h.value:"";const k=b.querySelector(".rule-level").value,g=Array.from(b.querySelectorAll(".item-icon.selected")).map(m=>m.dataset.type),l=Array.from(b.querySelectorAll(".color-circle.selected")).map(m=>m.dataset.color),q=b.querySelector(".rule-hammer-selection img.selected");b=b.querySelector(".rule-checkbox");Qc.push({condition:c,prefix:e,suffix:h,colors:l,itemTypes:g,hammerState:q?q.dataset.hammer:
"none",level:k,isEnabled:b?b.checked:!0})});localStorage.setItem("smeltingSettings",JSON.stringify(Qc))}function Zh(){document.querySelectorAll(".item-icon").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function $h(){document.querySelectorAll(".color-circle").forEach(b=>{b.addEventListener("click",function(){this.classList.toggle("selected");Wa()})})}function ai(){document.querySelectorAll(".rule-row .rule-hammer-selection img").forEach(b=>{b.addEventListener("click",
function(){const c=this.closest(".rule-hammer-selection").querySelectorAll("img");this.classList.contains("selected")?this.classList.remove("selected"):(c.forEach(e=>e.classList.remove("selected")),this.classList.add("selected"));Wa()})})}function bi(){document.querySelectorAll(".rule-condition-select").forEach(b=>{b.addEventListener("change",function(){const c=this.closest(".rule-row").querySelector(".rule-prefix-input"),e=this.closest(".rule-row").querySelector(".rule-suffix-input");"nameContains"===
this.value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");Wa()})})}function ci(){document.querySelectorAll(".rule-prefix-input, .rule-level").forEach(b=>{b.addEventListener("input",Wa)});document.querySelectorAll(".rule-suffix-input, .rule-level").forEach(b=>{b.addEventListener("input",Wa)})}function di(){document.querySelectorAll(".rule-row .remove-rule-btn").forEach(b=>{b.addEventListener("click",function(){b.closest(".rule-row").remove();Wa()})})}
function zf(){const b=document.querySelector(".rule-row-template").cloneNode(!0);b.classList.remove("rule-row-template");b.classList.add("rule-row");b.style.display="block";b.querySelector(".rule-prefix-input").value="";b.querySelector(".rule-suffix-input").value="";b.querySelector(".rule-level").value="";b.querySelector(".rule-checkbox").checked=!0;b.querySelectorAll(".selected").forEach(h=>h.classList.remove("selected"));const c=b.querySelector(".rule-prefix-input"),e=b.querySelector(".rule-suffix-input");
"nameContains"===b.querySelector(".rule-condition-select").value?(c.style.display="block",e.style.display="block"):(c.style.display="none",e.style.display="none");document.querySelector(".rule-container").insertBefore(b,document.querySelector(".add-rule-btn"));Af();Wa()}function ei(){document.querySelectorAll(".rule-checkbox").forEach(b=>{b.addEventListener("change",Wa)});document.querySelectorAll(".rule-checkbox-wrapper").forEach(b=>{b.addEventListener("click",function(){const c=this.querySelector(".rule-checkbox");
c.checked=!c.checked;Wa()})})}function Af(){bi();Zh();$h();ai();di();ci();ei()}function fi(b){const c="white green blue purple orange red".split(" ");return b.sort((e,h)=>c.indexOf(e)-c.indexOf(h))}function gi(){const b=document.querySelector(".rule-row-template");var c=JSON.parse(localStorage.getItem("smeltingSettings"))||[];document.querySelectorAll(".rule-row").forEach(e=>{e.remove()});if(0===c.length){c=b.cloneNode(!0);c.classList.remove("rule-row-template");c.classList.add("rule-row");c.style.display=
"block";const e=c.querySelector(".rule-suffix-input");c.querySelector(".rule-prefix-input").style.display="block";e.style.display="block";document.querySelector(".rule-container").insertBefore(c,document.querySelector(".add-rule-btn"))}else c.forEach(e=>{const h=b.cloneNode(!0);h.classList.remove("rule-row-template");h.classList.add("rule-row");h.style.display="block";h.querySelector(".rule-condition-select").value=e.condition;var k=h.querySelector(".rule-prefix-input");const g=h.querySelector(".rule-suffix-input");
"nameContains"===e.condition?(k.style.display="block",k.value=e.prefix,g.style.display="block",g.value="undefined"===typeof e.suffix?null:e.suffix):(k.style.display="none",g.style.display="none");h.querySelector(".rule-level").value=e.level;e.itemTypes.forEach(l=>{(l=h.querySelector(`.item-icon[data-type="${l}"]`))&&l.classList.add("selected")});e.colors.forEach(l=>{(l=h.querySelector(`.color-circle[data-color="${l}"]`))&&l.classList.add("selected")});"none"!==e.hammerState&&(k=h.querySelector(`.rule-hammer-selection img[data-hammer="${e.hammerState}"]`))&&
k.classList.add("selected");h.querySelector(".rule-checkbox").checked=!1!==e.isEnabled;document.querySelector(".rule-container").insertBefore(h,document.querySelector(".add-rule-btn"))});Af()}function Rc(){Ea.colors=fi(Ea.colors);localStorage.setItem("smeltRandomlySettings",JSON.stringify(Ea))}function hi(){document.querySelectorAll(".item-icon2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.type;this.classList.contains("selected")?(this.classList.remove("selected"),Ea.itemTypes=
Ea.itemTypes.filter(e=>e!==c)):(this.classList.add("selected"),Ea.itemTypes.push(c));Rc()})});document.querySelectorAll(".rule-color-selection2 .color-circle2").forEach(b=>{b.addEventListener("click",function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),Ea.colors=Ea.colors.filter(e=>e!==c)):(this.classList.add("selected"),Ea.colors.push(c));Rc()})});document.querySelectorAll(".rule-color-resetColors .color-circle3").forEach(b=>{b.addEventListener("click",
function(){const c=this.dataset.color;this.classList.contains("selected")?(this.classList.remove("selected"),ic.colors=ic.colors.filter(e=>e!==c)):(this.classList.add("selected"),ic.colors.push(c));localStorage.setItem("resetColors",JSON.stringify(ic))})});document.querySelectorAll(".rule-hammer-selection2 img").forEach(b=>{b.addEventListener("click",function(){this.classList.contains("selected")?(this.classList.remove("selected"),Ea.hammerState="none"):(document.querySelectorAll(".rule-hammer-selection2 img").forEach(c=>
c.classList.remove("selected")),this.classList.add("selected"),Ea.hammerState=this.dataset.hammer);Rc()})})}function ii(){const b=JSON.parse(localStorage.getItem("resetColors"))||{};b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-resetColors .color-circle3[data-color="${c}"]`))&&c.classList.add("selected")})}function ji(){var b=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{};b.itemTypes&&b.itemTypes.forEach(c=>{(c=document.querySelector(`.item-icon2[data-type="${c}"]`))&&
c.classList.add("selected")});b.colors&&b.colors.forEach(c=>{(c=document.querySelector(`.rule-color-selection2 .color-circle2[data-color="${c}"]`))&&c.classList.add("selected")});b.hammerState&&"none"!==b.hammerState&&(b=document.querySelector(`.rule-hammer-selection2 img[data-hammer="${b.hammerState}"]`))&&b.classList.add("selected")}async function Sc(b){function c(t){let y=t.target.name;t=Number(t.target.value);let A=JSON.parse(localStorage.getItem("gods"));A||={zo:3,Yn:3,wo:3,yo:3,Mn:3,Oo:3};A[y]=
t;localStorage.setItem("gods",JSON.stringify(A))}function e(){document.getElementById("items-repaired").textContent=ka.Fm;document.getElementById("items-reset").textContent=ka.Gm;document.getElementById("gold-cycled").textContent=ka.Dm;document.getElementById("arena-attacks").textContent=ka.sm;document.getElementById("circus-attacks").textContent=ka.vm;document.getElementById("dungeons-attacked").textContent=ka.ym;document.getElementById("expeditions-attacked").textContent=ka.Am;document.getElementById("items-smelted").textContent=
ka.Hm;document.getElementById("underworld-attacks").textContent=ka.Om;document.getElementById("arena-money").textContent=Math.floor(1E3*ka.dm).toLocaleString();document.getElementById("circus-money").textContent=Math.floor(1E3*ka.em).toLocaleString()}function h(){var t=JSON.parse(localStorage.getItem("IgnoredPrefixes"))||[],y=JSON.parse(localStorage.getItem("IgnoredSuffixes"))||[];g("IgnoredprefixList",t,"IgnoredPrefixes");g("IgnoredsuffixList",y,"IgnoredSuffixes");t=JSON.parse(localStorage.getItem("auctionPrefixes"))||
[];y=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];g("AuctionprefixList",t,"auctionPrefixes");g("AuctionsuffixList",y,"auctionSuffixes");var A=JSON.parse(localStorage.getItem("smeltedItems"))||[];y=document.getElementById("smeltedList");let z=JSON.parse(localStorage.getItem("bidList"))||[];for(t=document.getElementById("bidList");y.firstChild;)y.firstChild.remove();for(var x of A)A=document.createElement("li"),A.textContent=x,y.appendChild(A);for(;t.firstChild;)t.firstChild.remove();for(let v of z)x=
document.createElement("li"),x.textContent=v,t.appendChild(x)}function k(t,y,A){""!==y.trim()&&(t=JSON.parse(localStorage.getItem(A))||[],t.push(y),localStorage.setItem(A,JSON.stringify(t)),h())}function g(t,y,A){let z=document.getElementById(t);z.innerHTML="";y.forEach((x,v)=>{let C=document.createElement("li");C.textContent=x;C.draggable=!0;C.setAttribute("data-index",v);v=document.createElement("button");v.textContent="X";v.style.marginLeft="10px";v.addEventListener("click",function(){let E=y.indexOf(x);
-1<E&&(y.splice(E,1),localStorage.setItem(A,JSON.stringify(y)),g(t,y,A))});C.appendChild(v);z.appendChild(C)});l(z,y,A)}function l(t,y,A){let z=-1;t.addEventListener("dragstart",x=>{z=parseInt(x.target.getAttribute("data-index"),10)});t.addEventListener("dragover",x=>{x.preventDefault()});t.addEventListener("drop",x=>{x.preventDefault();x=parseInt(x.target.closest("li").getAttribute("data-index"),10);0<=x&&0<=z&&([y[z],y[x]]=[y[x],y[z]],localStorage.setItem(A,JSON.stringify(y)),g(t.id,y,A));h()})}
function q(){setInterval(()=>{if(X("randomPause")){const t=localStorage.getItem("selectedPauseDuration");m(t)}},6E4)}function m(t){let y,A;switch(t){case "1":A=8;y={mod:"work",submod:"start",sh:W("sh"),fm:1,om:A,im:2};break;case "2":A=6;y={mod:"work",submod:"start",sh:W("sh"),fm:1,om:A,im:3};break;case "3":A=3;y={mod:"work",submod:"start",sh:W("sh"),fm:1,om:A,im:4};break;case "4":A=10;y={mod:"work",submod:"start",sh:W("sh"),fm:1,om:A,im:5};break;case "5":A=4,y={mod:"work",submod:"start",sh:W("sh"),
fm:1,om:A,im:6}}$.post(T({}),y).done(()=>{setTimeout(()=>{location.reload()},6E4*(A+1));Z("randomPause",Math.floor(1440*Math.random())+600)}).fail(()=>{})}const n=b.dataset.target;document.querySelectorAll(".popup-tab").forEach(t=>{t.classList.remove("active")});b.classList.add("active");document.querySelectorAll(".popup-box").forEach(t=>{t.classList.remove("active")});document.getElementById(n).classList.add("active");document.querySelectorAll("input[type=radio]").forEach(t=>{t.addEventListener("change",
c);let y=JSON.parse(localStorage.getItem("gods"));y&&void 0!==y[t.name]&&(t.checked=t.value==y[t.name])});document.getElementById("reset-stats-button").addEventListener("click",()=>{ka.Fm=0;ka.Gm=0;ka.Dm=0;ka.sm=0;ka.vm=0;ka.ym=0;ka.Am=0;ka.Hm=0;ka.Om=0;ka.dm=0;ka.em=0;localStorage.setItem("userStats",JSON.stringify(ka));e()});e();b=document.querySelector(".add-rule-btn");b.removeEventListener("click",zf);b.addEventListener("click",zf);gi();ii();ji();document.getElementById("smeltLootbox").checked=
"true"===localStorage.getItem("smeltLootbox");document.getElementById("smeltLootbox").addEventListener("change",function(){localStorage.setItem("smeltLootbox",this.checked)});document.getElementById("smelteverything3").checked="true"===localStorage.getItem("smelteverything3");document.getElementById("smelteverything3").addEventListener("change",function(){localStorage.setItem("smelteverything3",this.checked)});document.getElementById("smeltAnything").checked="true"===localStorage.getItem("smeltAnything");
document.getElementById("smeltAnything").addEventListener("change",function(){localStorage.setItem("smeltAnything",this.checked)});document.getElementById("RepairBeforeSmelt").checked="true"===localStorage.getItem("RepairBeforeSmelt");document.getElementById("RepairBeforeSmelt").addEventListener("change",function(){localStorage.setItem("RepairBeforeSmelt",this.checked)});const r=document.getElementById("expeditionSearchTypeX");if(b=localStorage.getItem("nestSearchType"))r.value=b;r.addEventListener("change",
()=>{localStorage.setItem("nestSearchType",r.value)});document.getElementById("IgnoredaddPrefixButton").onclick=function(){let t=document.getElementById("newIgnoredPrefixInput").value;k("IgnoredprefixList",t,"IgnoredPrefixes")};document.getElementById("IgnoredaddSuffixButton").onclick=function(){let t=document.getElementById("newIgnoredSuffixInput").value;k("IgnoredsuffixList",t,"IgnoredSuffixes")};document.getElementById("clearSmeltedItemsHistory").addEventListener("click",function(){localStorage.setItem("smeltedItems",
JSON.stringify([]));h()});h();document.getElementById("clearBidItemsHistory").addEventListener("click",function(){localStorage.setItem("bidList",JSON.stringify([]));h()});document.getElementById("AuctionaddPrefixButton").onclick=function(){let t=document.getElementById("AuctionnewPrefixInput").value;k("AuctionprefixList",t,"auctionPrefixes")};document.getElementById("AuctionaddSuffixButton").onclick=function(){let t=document.getElementById("AuctionnewSuffixInput").value;k("AuctionsuffixList",t,"auctionSuffixes")};
document.getElementById("pauseDuration").addEventListener("change",t=>{t=t.target.value;localStorage.setItem("selectedPauseDuration",t);localStorage.setItem("randomPause.timeOut",0);"0"!==t&&(Z("randomPause",Math.floor(1440*Math.random())),q())});document.getElementById("exportBtn").addEventListener("click",function(t){t.preventDefault();if(!t.target.getAttribute("data-clicked")){t.target.setAttribute("data-clicked","true");t={};var y="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");
for(var A in localStorage)y.includes(A)||(t[A]=localStorage.getItem(A));A=JSON.stringify(t);A=URL.createObjectURL(new Blob([A],{type:"application/json"}));t=document.createElement("a");t.href=A;t.download="GladBotSettings.json";t.click()}},{once:!0});b=document.getElementById("importFileBtn");const w=document.getElementById("importBtn"),u=document.getElementById("importStatus");b&&w&&u&&(b.addEventListener("click",function(){w.click()}),w.addEventListener("change",function(t){if(t=t.target.files[0]){var y=
new FileReader;y.onload=function(A){try{const z=JSON.parse(A.target.result);A="bidList license_remaining nana_lcn playerCountry pid itemsToSearch smeltedItems rtksn MarketboughtItems tkz_lcr trlky_lcr token tkn playerId underworld savedUnderworldStates playerTimeouts tempOpponentDetails smelt.timer".split(" ");for(let x in z)A.includes(x)||localStorage.setItem(x,z[x]);u.textContent="Import successful! Please refresh the page."}catch(z){u.textContent="Import failed. Please check the input file and try again."}};
y.readAsText(t)}}));b=document.createElement("div");b.id="loadingSpinner";b.innerHTML='\n                <div class="spinner"></div>\n                <div class="loading-text">0</div>\n              ';document.querySelector("#selectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(t=>{t.checked=!0;t.dispatchEvent(new Event("change"))})});document.querySelector("#unselectAllButton").addEventListener("click",()=>{document.querySelectorAll(".playerCheckbox").forEach(t=>
{t.checked=!1;t.dispatchEvent(new Event("change"))})})}function ki(){const b=document.getElementById("expeditionLocation"),c=document.getElementById("dungeonLocation");var e=document.querySelectorAll("#submenu2 a");const h=[];for(let k=1;k<e.length;k++)e[k].classList.contains("glow")||h.push(e[k]);h.forEach(k=>{const g=document.createElement("option");g.innerText=k.innerText;g.value=(new URLSearchParams(k.href)).get("loc");b.appendChild(g);c.appendChild(g.cloneNode(!0))});if(e=localStorage.getItem("expeditionLocation"))b.value=
e;if(e=localStorage.getItem("dungeonLocation"))c.value=e}function rb(b,c,e){const h=document.createElement("li"),k="object"===typeof b?b.playerName:b;h.textContent=k;b=document.createElement("button");b.textContent="X";b.style.marginLeft="10px";b.addEventListener("click",()=>{h.remove();var g=JSON.parse(localStorage.getItem(e))||[];g=e.includes("ServerList")?g.filter(l=>"object"===typeof l&&l.playerName!==k):g.filter(l=>l!==k);localStorage.setItem(e,JSON.stringify(g))});h.appendChild(b);(c=document.getElementById(c))&&
c.appendChild(h)}function jc(b,c,e){rb(b,c,e);c=JSON.parse(localStorage.getItem(e))||[];e.includes("ServerList")?c.push({playerName:b}):c.push(b);localStorage.setItem(e,JSON.stringify(c))}function li(){const b=JSON.parse(localStorage.getItem("autoAttackList"))||[],c=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],e=JSON.parse(localStorage.getItem("avoidAttackList"))||[],h=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[],k=JSON.parse(localStorage.getItem("autoAttackCircusList"))||
[],g=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[];b.forEach(l=>rb(l,"autoAttackList","autoAttackList"));c.forEach(l=>rb(l,"autoAttackServerList","autoAttackServerList"));e.forEach(l=>rb(l,"avoidAttackList","avoidAttackList"));h.forEach(l=>rb(l,"avoidAttackCircusList","avoidAttackCircusList"));k.forEach(l=>rb(l,"autoAttackCircusList","autoAttackCircusList"));g.forEach(l=>rb(l,"autoAttackCircusServerList","autoAttackCircusServerList"))}function Bf(){sessionStorage.setItem("autoGoActive",
"true");document.getElementById("autoGoButton").innerHTML='<span style="position: relative; top: -9px;">&#9724;</span>';document.getElementById("autoGoButton").removeEventListener("click",Bf);document.getElementById("autoGoButton").addEventListener("click",Cf);location.reload()}function Cf(){sessionStorage.setItem("autoGoActive","false");window.location.reload()}function kc(){const b=document.getElementById("popup-header"),c=document.getElementById("overlayBack");b&&(localStorage.setItem("AucTab",
!0),b.remove());c&&c.remove()}function lc(){function b(v){localStorage.setItem("settings.language",v);switch(v){case "EN":d={...Ih};break;case "PL":d={...Jh};break;case "ES":d={...Kh};break;case "TR":d={...Lh};break;case "FR":d={...Mh};break;case "HG":d={...Nh};break;case "BR":d={...Oh};break;default:d={...Ih}}kc();lc()}function c(v){Ba=v;localStorage.setItem("doExpedition",v)}function e(v){Tc=v;localStorage.setItem("monsterId",v)}function h(v){Fa=v;localStorage.setItem("doDungeon",v)}function k(v){Jb=
v;localStorage.setItem("dungeonDifficulty",v);g(v)}function g(v){$(".monster-button").removeClass("active");$(`#set_dungeon_difficulty_${v}`).addClass("active")}function l(v){Ga=v;localStorage.setItem("doArena",v)}function q(v){Ca=v;localStorage.setItem("doCircus",v)}function m(v){Oa=v;localStorage.setItem("doQuests",v)}function n(v){Pa[v]=!Pa[v];localStorage.setItem("questTypes",JSON.stringify(Pa));kc();lc()}function r(v){Da=v;localStorage.setItem("doEventExpedition",v)}function w(v){nc=v;localStorage.setItem("eventMonsterId",
v);kc();lc()}function u(){var v=localStorage.getItem("doExpedition");null!==v&&(Ba=JSON.parse(v));1==Ba?$("#doExpedition").prop("checked",!0):$("#doExpedition").prop("checked",!1);v=localStorage.getItem("doDungeon");null!==v&&(Fa=JSON.parse(v));1==Fa?$("#doDungeon").prop("checked",!0):$("#doDungeon").prop("checked",!1);v=localStorage.getItem("doArena");null!==v&&(Ga=JSON.parse(v));1==Ga?$("#doArena").prop("checked",!0):$("#doArena").prop("checked",!1);v=localStorage.getItem("doCircus");null!==v&&
(Ca=JSON.parse(v));1==Ca?$("#doCircus").prop("checked",!0):$("#doCircus").prop("checked",!1);v=localStorage.getItem("doQuests");null!==v&&(Oa=JSON.parse(v));1==Oa?$("#doQuests").prop("checked",!0):$("#doQuests").prop("checked",!1);v=localStorage.getItem("AutoAuction");null!==v&&(Za=JSON.parse(v));1==Za?$("#activateAutoBid").prop("checked",!0):$("#activateAutoBid").prop("checked",!1);v=localStorage.getItem("doKasa");null!==v&&(ib=JSON.parse(v));1==ib?$("#doKasa").prop("checked",!0):$("#doKasa").prop("checked",
!1);v=localStorage.getItem("doEventExpedition");null!==v&&(Da=JSON.parse(v));1==Da?$("#doEventExpedition").prop("checked",!0):$("#doEventExpedition").prop("checked",!1);$("#expedition_settings").addClass(Ba?"active":"inactive");$(`#do_expedition_${Ba}`).addClass("active");$(`#set_monster_id_${Tc}`).addClass("active");$("#dungeon_settings").addClass(Fa?"active":"inactive");$(`#do_dungeon_${Fa}`).addClass("active");$(`#set_dungeon_difficulty_${Jb}`).addClass("active");$("#arena_settings").addClass(Ga?
"active":"inactive");$(`#do_arena_${Ga}`).addClass("active");$(`#set_arena_opponent_level_${Jf}`).addClass("active");$("#circus_settings").addClass(Ca?"active":"inactive");$(`#do_circus_${Ca}`).addClass("active");$(`#set_circus_opponent_level_${Kf}`).addClass("active");$("#quests_settings").addClass(Oa?"active":"inactive");$(`#do_quests_${Oa}`).addClass("active");for(const C in Pa)Pa[C]&&$(`#do_${C}_quests`).addClass("active");$("#auto_auction_settings").addClass(Za?"active":"inactive");$("#event_expedition_settings").addClass(Da?
"active":"inactive");$(`#do_event_expedition_${Da}`).addClass("active");$(`#set_event_monster_id_${nc}`).addClass("active")}var t=document.getElementById("popup-header"),y=document.getElementById("overlayBack");t&&t.remove();y&&y.remove();t=document.createElement("div");t.setAttribute("id","popup-header");y=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio";t.innerHTML=`
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

            <div id="popupSmelt" class="popup">
                <div class="smelt-instructions" style="text-align: left; padding-left: 5px;">
                    <ul style="list-style-position: inside;">
                        <li>1. ${d.Qj}</li>
                        <li>2. ${d.Rj}</li>
                        <li>3. ${d.Sj}</li>
                        <li>4. ${d.Tj}</li>

                        <br>${d.Uj}</br>
                        <br>${d.Vj}</br>
                    </ul>
                </div>
                <img src="https://raw.githubusercontent.com/fociisoftware/glbt/refs/heads/main/Smelt2.gif" alt="Smelt Info" style="width: 350px; height: auto;">
            </div>

            <div id="announcement" class="announcement">
                ${y}
            </div>

            <div class="popup-menu">
                <div class="popup-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Version 1.1.5</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Contact us</a></span>
                <span style="display: inline-block;"><a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank">Update</a></span>
                <div style="display: flex; justify-content: space-between; align-items: right;">    
                <div class="menu-type logo" style="width: 48px; height: 48px; margin-right: 250px;"></div>
            
              </div>

              <span id="settingsLanguage" style="margin-left: 300px; right: 17px; top: 32px;">          
                <img class="menu-type GB" id="languageGB"> 
                <img class="menu-type PL" id="languagePL"> 
                <img class="menu-type ES" id="languageES"> 
                <img class="menu-type TR" id="languageTR">
                <img class="menu-type FR" id="languageFR">
                <img class="menu-type HG" id="languageHG">
                <img class="menu-type BR" id="languageBR">
                <br>
                <a style="color: white" href="">Donate</a>
                 - 
                 <a style="color: white" href="https://gldbotserver.com/home-gld" target="_blank"> Tutorial</a>
                 -
                <span style="color: white;">GLDbot <span style="color: red;">&#10084;</span></span>
                 </span>
              
              </div><span id="settingsLanguage"></span>

              <div class="popup-content">
                <ul class="popup-tabs">
                
                <li class="popup-tab" data-target="expedition_settings">
                    <div class="headericon_big" id="icon_expeditionpoints" style="margin-left: 4px;"></div>

                    ${d.expedition}
                    <div class="toggle-switch">
                    <input type="checkbox" id="doExpedition">
                    <label class="switch" for="doExpedition"></label>
                    </div>
                </li>

                  <li class="popup-tab" data-target="dungeon_settings">
                  <div class="headericon_big" id="icon_dungeonpoints" style="margin-left: 4px;"></div>
                  ${d.dungeon}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doDungeon">
                      <label class="switch" for="doDungeon"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="arena_settings">
                  <div class="headericon_big" id="icon_arena" style="margin-left: 4px;"></div>
                  ${d.arena}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doArena">
                      <label class="switch" for="doArena"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="circus_settings">
                  <div class="headericon_big" id="icon_grouparena" style="margin-left: 4px;"></div>
                  ${d.circusTurma}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doCircus">
                      <label class="switch" for="doCircus"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="underworld_settings">
                  <div class="quest-type underworld" style="margin-left: 4px;"></div>
                  ${d.si}
                    <div class="toggle-switch">
                      <input type="checkbox" id="autoEnterHell">
                      <label class="switch" for="autoEnterHell"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="quests_settings">
                  <div class="quest-type menu"></div>
                  ${d.Dj}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doQuests">
                      <label class="switch" for="doQuests"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="heal_settings">
                  <div class="quest-type potion"></div>
                  ${d.dj}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doHeal">
                      <label class="switch" for="doHeal"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="event_expedition_settings">
                  <div class="quest-type event"></div>${d.eventExpedition}
                    <div class="toggle-switch">
                      <input type="checkbox" id="doEventExpedition">
                      <label class="switch" for="doEventExpedition"></label>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_auction_settings">
                  <div class="quest-type search"></div>
                  ${d.A}
                  
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateAutoBid">
                      <label class="switch" for="activateAutoBid">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_auction2_settings">
                    <div class="quest-type auction"></div>
                    ${d.Id}
                    <div class="toggle-switch ">
                      <input type="checkbox" id="activateAuction2">
                      <label class="switch" for="activateAuction2">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>
                  
                  <li class="popup-tab" data-target="auto_smelt_settings">
                  <div class="quest-type smelt"></div>${d.Ah}
                    <div class="toggle-switch">
                      <input type="checkbox" id="activateSmelt">
                      <label class="switch" for="activateSmelt">
                      <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="auto_repair_settings">
                  <div class="quest-type repair"></div>
                  ${d.Lb}
                  <div class="toggle-switch">
                    <input type="checkbox" id="activateRepair">
                    <label class="switch" for="activateRepair">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="Market">
                  <div class="quest-type market"></div>
                  ${d.cg}
                  <div class="toggle-switch">
                  <div class="toggle-bg"></div>
                  </div>
                  </li>

                  <li class="popup-tab" data-target="guild_settings">
                    <div class="quest-type guild"></div>
                    ${d.$i}
                    <div class="toggle-bg"></div>
                  </li>
                  
                 
                  <li class="popup-tab" data-target="Timers">
                    <div class="quest-type timer"></div>
                    ${d.Wb} 
                    <div class="toggle-switch">
                    <div class="toggle-bg"></div>
                    </div>
                  </li>

                  <li class="popup-tab" data-target="other_settings2">
                  <div class="quest-type reset">
                  </div>${d.gh}
                  </li>
                  

                  <li class="popup-tab" data-target="other_settings">
                  <div class="quest-type settings"></div>
                  ${d.Fg}
                  <div class="toggle-bg"></div>
                  </li>

                  


                  <li class="popup-tab" data-target="Extra">
                  <div class="quest-type extra">
                  </div>${d.ob}
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div>
                  <div class="toggle-bg"></div> </li>

                </ul>

            <div class="popup-box" id="expedition_settings">

                <div class="settings-tab">
                    <div class="settings_tab_title">${d.Vi}</div>
                    <div class="setting-row">
                        <label for="expeditionLocation">${d.Me}</label>
                        <select id="expeditionLocation"></select>
                    </div>

                    <div class="setting-row">
                        <label for="autoCollectBonuses">${d.Md}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoCollectBonuses">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="enemySelection" class="setting-row">
                        <label for="enemySelect">${d.Gj}:</label>
                        <select id="enemySelect">
                            <option value="0">1</option>
                            <option value="1">2</option>
                            <option value="2">3</option>
                            <option value="3">Boss</option>
                        </select>
                    </div>

                    <div id="expeditionSearchType" class="setting-row">
                        <label for="expeditionSearchTypeX">${d.lj}:</label>
                        <select id="expeditionSearchTypeX">
                            <option value="" selected disabled>Select an option</option>
                            <option value="nothing">${d.jj}</option>
                            <option value="quick">${d.kj}</option>
                            <option value="thorough">${d.mj}</option>
                        </select>
                        <hr>
                        <span style="color: class="span-new">${d.nj}</span>

                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="postExpeditionAction">${d.Bj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="postExpeditionAction">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                </div>
  
            </div>
            
                <div class="popup-box" id="dungeon_settings">
                  <div class="settings_tab_title">${d.Ri}</div>
                  <div class="settings-tab">
                    <div class="setting-row">      
                      <label for="dungeonLocation">${d.ke}</label>
                      <select id="dungeonLocation"></select>
                    </div>

                    <div class="setting-row">
                      <span class="span-new">${d.Qi}</span>
                        <div id="set_dungeon_difficulty_normal" class="monster-button">
                          ${d.pj}
                        </div>
                        <div id="set_dungeon_difficulty_advanced" class="monster-button">
                          ${d.advanced}
                        </div>
                    </div>

                    <div class="setting-row">
                      <label for="skipBossToggle">${d.zh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipBossToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="resetIfLoseToggle">${d.hh}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="resetIfLoseToggle">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonAB">${d.Ed}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonAB">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="dungeonFocusQuest">${d.Ue}</label>  
                      <label class="toggle-switch">
                        <input type="checkbox" id="dungeonFocusQuest">
                        <span class="switch"></span>
                      </label>
                    </div>
                    <span class="span-new">${d.Vg}</span>  

                  
                    </div>
                      <div class="tutorial-container">
                        <span class="span-new">${d.Si}</span>  
                      </div>
                    </div>

                  <!-- ARENA -->
  
                  <div class="popup-box" id="arena_settings">
                  <div class="settings_tab_title">Arena</div>
                  <span class="span-new">${d.Wa}</span>

                  
                  <div class="settings_tab_title2">
                    <button id="tabA" class="tab-button active">Arena Local Server</button>
                    <button id="tabB" class="tab-button">Arena Other Servers</button>
                  </div>

                  <!-- Tab A Content -->
                  <div id="contentA" class="setting-row">
                    <div class="avoid-attack">
                      <div class="top-section">
                      <h3>${d.ia}</h3>
                        <div class="switch-field2">
                          <input type="text" id="autoAttackInput" placeholder="${d.ha}">
                          <button id="addAutoAttack" class="awesome-button">${d.ga}</button>
                          <button id="ClearAttackList" class="awesome-button">Clear List</button>
                        </div>
                      </div>
                      <ul id="autoAttackList" class="scrollable-list"></ul>
                    </div>
                  </div>

                  <!-- Tab B Content -->
                  <div id="contentB" class="setting-row" style="display: none;">
                    <div class="avoid-attack">
                      <div class="top-section">
                        <h3>${d.ia}</h3>
                        </div>
                        <button id="ClearOtherAttackList" class="awesome-button">Clear List</button>
                        <ul id="autoAttackServerList" class="scrollable-list"></ul>
                      </div>
                  </div>

                  <div class="setting-row">
                    <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.$b}</h3>
                            <div class="switch-field2">
                                <input type="text" id="avoidAttackInput" placeholder="${d.ha}">
                                <button id="addAvoidAttack" class="awesome-button">${d.ga}</button>
                                <button id="ClearAvoidList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="avoidAttackList" class="scrollable-list"></ul>
                        ${d.ac}
                    </div>
                  </div>

                  <div class="setting-row" data-tooltip="${d.Cj}">
                    <label for="enableArenaSimulator">Enable Simulator Attack [Premium]</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="enableArenaSimulator">
                        <span class="switch"></span>
                    </label>    
                  </div>


                 <div class="setting-row">
                      <label for="ArenaSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                      <div class="switch-field3">
                        <input type="number" id="ArenaSimulatorAmount" min="1" max="100" value="${localStorage.getItem("ArenaSimulatorAmount")||60}">
                      </div>
                </div>

                  <div class="setting-row">
                    <label for="arenaAttackGM">${d.Sa}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="arenaAttackGM">
                      <span class="switch"></span>
                    </label>    
                  </div>

                    <div class="setting-row" data-tooltip="${d.Zb}">
                    <label for="onlyArena">${d.Mg}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="onlyArena">
                        <span class="switch"></span>
                    </label>    
                    </div>

                <div class="setting-row">
                    <label for="attackRandomly">${d.Fi}</label>
                    
                    <label class="toggle-switch">
                    <input type="checkbox" id="attackRandomly">
                    <span class="switch"></span>
                    </label>    
                    <h3>${d.Gi}</h3>
                </div>

                  <div class="setting-row">
                    <div class="switch-field3">
                    <input type="number" id="autoAddArenaAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddArenaAmount")||0}">
                    </div>
                      <label for="autoAddArena">${d.Qa}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="autoAddArena">
                        <span class="switch"></span>
                      </label>
                  </div>
  
                  <div class="setting-row">
                    <label for="autoAvoidArena">${d.Ra}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="autoAvoidArena">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="scoreboard-attack">
                    <div class="settings_tab_title">${d.Pb}</div>
                    <div class="setting-row">
                    <label for="scoreboardattackenable">${d.nb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="scoreboardattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="scoreRange">${d.Nb}</label>
                    <select id="scoreRange" class="input">
                      <option value="1">1-50</option>
                      <option value="2">51-100</option>
                      <option value="3">101-150</option>
                      <option value="4">151-200</option>
                      <option value="5">201-250</option>
                      <option value="6">251-300</option>
                      <option value="7">301-350</option>
                      <option value="8">351-400</option>
                      <option value="9">401-450</option>
                      <option value="10">451-500</option>
                      <option value="11">501-550</option>
                      <option value="12">551-600</option>
                      <option value="13">601-650</option>
                      <option value="14">651-700</option>
                      <option value="15">701-750</option>
                      <option value="16">751-800</option>
                      <option value="17">801-850</option>
                      <option value="18">851-900</option>
                      <option value="19">901-950</option>
                      <option value="20">951-1000</option>
                      <!-- Add more options as needed -->
                    </select>
                  </div>
                  </div>
                  <span class="span-new">${d.Ob}</span>
                  
                  <div class="settings_tab_title">${d.pb}</div>

                  <div class="setting-row">
                  <label for="leagueattackenable">${d.mb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leagueattackenable">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguerandom">${d.Jb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguerandom">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="leaguelowtohigh">${d.Kb}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="leaguelowtohigh">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <span class="span-new">${d.qb}</span>

                </div>

  
                  <!-- Circus -->

                  <div class="popup-box" id="circus_settings">
                    <div class="settings_tab_title">Circus</div>
                    <span class="span-new">${d.Wa}</span>

                    <div class="settings_tab_title2">
                        <button id="tabACircus" class="tab-button active">Circus Local Server</button>
                        <button id="tabBCircus" class="tab-button">Circus Other Servers</button>
                    </div>

                    <!-- Tab A Content -->
                    <div id="contentACircus" class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.ia}</h3>
                            <div class="switch-field2">
                            <input type="text" id="autoAttackCircusInput" placeholder="${d.ha}">
                            <button id="addAutoCircusAttack" class="awesome-button">${d.ga}</button>
                            <button id="ClearCircusAttackList" class="awesome-button">Clear List</button>
                            </div>
                        </div>
                        <ul id="autoAttackCircusList" class="scrollable-list"></ul>
                        </div>
                    </div>

                    <!-- Tab B Content -->
                    <div id="contentBCircus" class="setting-row" style="display: none;">
                        <div class="avoid-attack">
                        <div class="top-section">
                            <h3>${d.ia}</h3>
                            </div>
                            <button id="ClearOtherCircusAttackList" class="awesome-button">Clear List</button>
                            <ul id="autoAttackCircusServerList" class="scrollable-list"></ul>
                        </div>
                    </div>

                        <div class="setting-row">
                        <div class="avoid-attack">
                        <div class="top-section">
                        <h3>${d.$b}</h3>
                        <div class="switch-field2">
                            <input type="text" id="avoidAttackCircusInput" placeholder="${d.ha}">
                            <button class="awesome-button" id="addAvoidCircusAttack">${d.ga}</button>
                            <button class="awesome-button" id="ClearCircusAvoidList">Clear List</button>
                        </div>
                        </div>
                            <ul id="avoidAttackCircusList" class="scrollable-list"></ul>
                            ${d.ac}
                        </div>
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusWithoutHeal">${d.Li}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusWithoutHeal">
                                <span class="switch"></span>
                            </label>    
                        </div>

                        <div class="setting-row">
                            <label for="enableCircusSimulator">Enable Simulator Attack [Premium]</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="enableCircusSimulator">
                                <span class="switch"></span>
                            </label>    
                        </div>

                    <div class="setting-row">
                    <label for="CircusSimulatorAmount">Simulator Win Chance Amount [Premium]</label>
                    <div class="switch-field3">
                        <input type="number" id="CircusSimulatorAmount" min="1" max="100" value="${localStorage.getItem("CircusSimulatorAmount")||60}">
                    </div>
                </div>

                        <div class="setting-row">
                        <label for="circusAttackGM">${d.Sa}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="circusAttackGM">
                            <span class="switch"></span>
                        </label>    
                        </div>

                        <div class="setting-row" data-tooltip="${d.Zb}">
                        <label for="onlyCircus">${d.Ng}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="onlyCircus">
                        <span class="switch"></span>
                        </label>    
                    </div>

                    <div class="setting-row">
                    <label for="attackRandomlyCircus">Attack Randomly in Provinciarum?</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="attackRandomlyCircus">
                        <span class="switch"></span>
                    </label>    
                    <h3>Also disable "Sort players in arena by level" setting in crazy-addon.</h3>
                    </div>

                        <div class="setting-row">
                        <div class="switch-field3">
                        <input type="number" id="autoAddCircusAmount" placeholder="Amount" min="0" value="${localStorage.getItem("autoAddCircusAmount")||0}">
                        </div>
                            <label for="autoAddCircus">${d.Qa}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="autoAddCircus">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="autoAvoidCircus">${d.Ra}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoAvoidCircus">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="scoreboard-attack">
                        <div class="settings_tab_title">${d.Pb}</div>
                        <div class="setting-row">
                        <label for="scoreboardcircusenable">${d.nb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="scoreboardcircusenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="scoreRangeCircus">${d.Nb}</label>
                            <select id="scoreRangeCircus" class="input">
                            <option value="1">1-50</option>
                            <option value="2">51-100</option>
                            <option value="3">101-150</option>
                            <option value="4">151-200</option>
                            <option value="5">201-250</option>
                            <option value="6">251-300</option>
                            <option value="7">301-350</option>
                            <option value="8">351-400</option>
                            <option value="9">401-450</option>
                            <option value="10">451-500</option>
                            <option value="11">501-550</option>
                            <option value="12">551-600</option>
                            <option value="13">601-650</option>
                            <option value="14">651-700</option>
                            <option value="15">701-750</option>
                            <option value="16">751-800</option>
                            <option value="17">801-850</option>
                            <option value="18">851-900</option>
                            <option value="19">901-950</option>
                            <option value="20">951-1000</option>
                            <!-- Add more options as needed -->
                            </select>
                        </div>
                        </div>
                        <span class="span-new"> ${d.Ob} </span>
                        
                        <div class="settings_tab_title">${d.pb}</div>

                        <div class="setting-row">
                        <label for="leaguecircusattackenable">${d.mb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusattackenable">
                            <span class="switch"></span>
                        </label>
                        </div>

                        <div class="setting-row">
                        <label for="leaguecircusrandom">${d.Jb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircusrandom">
                            <span class="switch"></span>
                        </label>
                        </div>
    
                        <div class="setting-row">
                        <label for="leaguecircuslowtohigh">${d.Kb}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="leaguecircuslowtohigh">
                            <span class="switch"></span>
                        </label>
                        </div>
                        <span class="span-new">${d.qb}</span>

                  </div>

                  <div class="popup-box" id="underworld_settings">

                    <div class="settings_tab_title">${d.$e}</div>
                        <span class="span-new"> ${d.af}</span>
                        <div class="setting-row">
                            <label for="hellDifficulty">${d.Ye}</label>
                            <select id="hellDifficulty">
                                <option value="0">${d.Pi}</option>
                                <option value="1">${d.Oi}</option>
                                <option value="2">${d.Ni}</option>
                            </select>
                        </div>

                    <div class="setting-row">
                        <label for="hellEnterHP">${d.qe}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellEnterHP" min="1" max="100" value="${localStorage.getItem("hellEnterHP")||75}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="HellHealHP">${d.Hk}</label>
                        <div class="switch-field3">
                            <input type="number" id="HellHealHP" min="1" max="100" value="${localStorage.getItem("HellHealHP")||10}">
                        </div>
                    </div>
                    
                    <div class="setting-row" data-tooltip="${d.gj}">
                        <label for="autoEnterHell">${d.Pd} Info</label>
                    </div>

                    <div class="setting-row" data-tooltip="${d.ge}">
                        <label for="dontEnterUnderworld">${d.he}</label>
                        <label class="toggle-switch">
                        
                            <input type="checkbox" id="dontEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="EnableArenaHell">${d.le}</label>
                        <label class="toggle-switch">
                    
                        <input type="checkbox" id="EnableArenaHell">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderworldUseMobi">${d.yi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderworldUseMobi">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="UnderWorldUseRuby">${d.Ci}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="UnderWorldUseRuby">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="useSacrifice">${d.Ai}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useSacrifice">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="usePray">${d.rk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="usePray">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="useClothToEnterUnderworld">${d.mk}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useClothToEnterUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="exitUnderworld">${d.se}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="exitUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="settings_tab_title">${d.ji}</div>

                    <div class="setting-row">
                        <label for="useGodPowers">${d.li}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useGodPowers">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Multi-Selection for Gods -->
                    <div class="setting-row" id="godPowersSection" style="display: none;">
                        <label>${d.mi}</label>
                        <div class="god-selection">
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Minerva" id="godMinerva">
                                <img src="//gf3.geo.gfsrv.net/cdn8a/72919cc6b457bf475fb81cc7de8863.png" title="Minerva">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Diana" id="godDiana">
                                <img src="//gf2.geo.gfsrv.net/cdn70/026bb622a42b4d00abc74c67f28d63.png" title="Diana">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Vulcan" id="godVulcan">
                                <img src="//gf3.geo.gfsrv.net/cdn5c/6fbd05e43d699e65fc40cc92a17c51.png" title="Vulcan">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mars" id="godMars">
                                <img src="//gf2.geo.gfsrv.net/cdn76/5fd915f85b3e5e71b64632af0c6543.png" title="Mars">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Apollo" id="godApollo">
                                <img src="//gf3.geo.gfsrv.net/cdn8f/bb75bf0df76de3ec421bbfb0eac3c5.png" title="Apollo">
                            </label>
                            <label>
                                <input type="checkbox" class="god-power-checkbox" value="Mercury" id="godMercury">
                                <img src="//gf3.geo.gfsrv.net/cdnbe/5e272e2aade20b4a266e48663421ce.png" title="Mercury">
                            </label>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="weaponBuff">${d.ni}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="weaponBuff">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!-- Armor Buff Section -->
                    <div class="setting-row">
                        <label>${d.oi}</label>
                        <div class="armor-selection">
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Armor" id="armorBuffArmor"> ${d.M}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Helmet" id="armorBuffHelmet"> ${d.P}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Gloves" id="armorBuffGloves"> ${d.O}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Boots" id="armorBuffBoots"> ${d.N}
                            </label>
                            <label>
                                <input type="checkbox" class="armor-checkbox" value="Shield" id="armorBuffShield"> ${d.S}
                            </label>
                        </div>
                    </div>

                    <!-- Farm Section (As Is) -->
                    <div class="settings_tab_title">${d.Re}</div>
                    <span class="span-new">${d.Se}: </span>
                    <div class="setting-row">
                        <label for="farmEnable">${d.v}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="farmEnable">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="farmLocation">${d.Qe}</label>
                        <select id="farmLocation">
                            <option value="0">Entrance</option>
                            <option value="1">Court of the Dead</option>
                            <option value="2">Tartarus</option>
                            <option value="3">Erebus</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="farmEnemy">${d.Pe}:</label>
                        <select id="farmEnemy">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">Boss</option>
                        </select>
                    </div>

                    <div class="setting-row" data-tooltip="${d.fj}">
                          <label for="useVillaMedici">${d.me}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="EnableHellLimit">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="hellLimit">${d.ej}</label>
                        <div class="switch-field3">
                            <input type="number" id="hellLimit" min="1" max="200" value="${localStorage.getItem("hellLimit")||5}">
                        </div>
                    </div>

                    <div class="settings_tab_title">${d.Ze}</div>
                    <div class="setting-row">
                          <label for="useVillaMedici">${d.Bi}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useVillaMedici">
                              <span class="switch"></span>
                          </label>
                    </div>
                    
                    <div class="setting-row">
                        <label for="useHealingPotion">${d.zi}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="useHealingPotion">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <span class="span-new"> ${d.ki}</span>
                    <span class="span-new">${d.ti}</span>

                    <div class="settings_tab_title">${d.Nd}</div>
                    <span class="span-new">Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.</span>
                    <div class="setting-row">
                          <label for="useCostume">${d.xi}</label>
                          <label class="toggle-switch">
                              <input type="checkbox" id="useCostume">
                              <span class="switch"></span>
                          </label>
                    </div>

                    <div class="setting-row">
                        <label for="wearUnderworld">${d.Di}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="wearUnderworld">
                            <span class="switch"></span>
                        </label>
                    </div>
                    
                    <div id="costumeUnderworldWrapper" style="display:none;">
                      <div class="setting-row">
                          <label for="costumeUnderworld">${d.$d}</label>
                          <select id="costumeUnderworld">
                              <option value="9">Dis Pater Normal</option>
                              <option value="10">Dis Pater Medium</option>
                              <option value="11">Dis Pater Hard</option>
                          </select>
                      </div>
                    </div>                

                    <div class="setting-row">
                      <label for="costumeBasic">${d.Sd}</label>
                      <select id="costumeBasic">
                          <option value="1">${d.Ya}</option>
                          <option value="2">${d.bb}</option>
                          <option value="3">${d.cb}</option>
                          <option value="4">${d.eb}</option>
                          <option value="5">${d.fb}</option>
                          <option value="6">${d.gb}</option>
                          <option value="7">${d.hb}</option>
                          <option value="8">${d.ib}</option>
                          <option value="12">${d.jb}</option>
                          <option value="13">${d.Za}</option>
                          <option value="14">${d.$a}</option>
                          <option value="15">${d.ab}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <label for="costumeDungeon">${d.je}</label>
                      <select id="costumeDungeon">
                          <option value="1">${d.Ya}</option>
                          <option value="2">${d.bb}</option>
                          <option value="3">${d.cb}</option>
                          <option value="4">${d.eb}</option>
                          <option value="5">${d.fb}</option>
                          <option value="6">${d.gb}</option>
                          <option value="7">${d.hb}</option>
                          <option value="8">${d.ib}</option>
                          <option value="12">${d.jb}</option>
                          <option value="13">${d.Za}</option>
                          <option value="14">${d.$a}</option>
                          <option value="15">${d.ab}</option>
                      </select>
                    </div>
                    <span class="span-new">${d.Od}</span>

                </div>
                  
                  <div class="popup-box" id="quests_settings">

                    <div class="settings_tab_title">Quests</div>

                    <div class="setting-row">
                      <div class="monster-buttons">
                        <span class="span-new">${d.type}</span>
                        <div class="quest-container">
                          <div id="do_combat_quests" class="settingsButton quest-type combat"></div>
                          <div id="do_arena_quests" class="settingsButton quest-type arena"></div>
                          <div id="do_circus_quests" class="settingsButton quest-type circus"></div>
                          <div id="do_expedition_quests" class="settingsButton quest-type expedition"></div>
                          <div id="do_dungeon_quests" class="settingsButton quest-type dungeon"></div>
                          <div id="do_items_quests" class="settingsButton quest-type items"></div>
                        </div>
                      </div>
                    </div>

                    <div class="settings_tab_title">Quest Settings</div>

                    <div class="setting-row">
                      <label for="skipTimeQuests">Arena ${d.Ca}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="skipTimeQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeCircusQuests">Circus ${d.Ca}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeCircusQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                    <label for="skipTimeOtherQuests">Other ${d.Ca}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="skipTimeOtherQuests">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="setting-row">
                      <label for="UnderworldQuests">${d.ri}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="UnderworldQuests">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row" id="underworldKeywordSection" style="display: none;">
                    ${d.pi}
                    <div class="input-container">
                        <input type="text" id="underworldKeywordInput" placeholder="${d.V}">
                        <button class="awesome-button" id="addUnderworldKeywordBtn">${d.I}</button>
                    </div>
                    <div id="underworldKeywordList"></div>
                </div>

                    <div class="setting-row">
                    <label for="acceptnotfilter">${d.Pg}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="acceptnotfilter">
                      <span class="switch"></span>
                    </label>
                    </div>

                    <div class="settings_tab_title">${d.Wg}</div>
                      <div class="setting-row">
                        ${d.Og}
                        <select id="questSpeed">
                        <option value="0">5x</option>
                        <option value="1">4x</option>
                        <option value="2">3x</option>
                        <option value="3">2x</option>
                        <option value="4">1x</option>
                      </select>
                    </div>
                    <div class="settings_tab_title">${d.Tg}</div>

                    <div class="setting-row">
                      ${d.Sg}
                      <div class="input-container">
                      <input type="text" id="keywordInput" placeholder="${d.V}">
                      <button class="awesome-button" id="addKeywordBtn">${d.I}</button>
                      </div>
                      <div id="keywordList"></div>
                    </div>
                    
                    <div class="settings_tab_title">${d.Qg}</div>

                    <div class="setting-row">
                        ${d.Rg}
                        <div class="input-container">
                            <input type="text" id="keywordAcceptInput" placeholder="${d.V}">
                            <button class="awesome-button" id="addKeywordAcceptBtn">${d.I}</button>
                        </div>
                        <div id="keywordAcceptList"></div>
                    </div>      

                    <div class="setting-row">
                        <label for="questrewardvalue">${d.ih}</label>
                        <div class="switch-field3">
                            <input type="number" id="questrewardvalue" min="1" max="99999" value="${localStorage.getItem("questrewardvalue")||2E3}">
                        </div>
                    </div>

                    <div class="setting-row">
                        <label>${d.Ug}</label>
                        <div class="input-container">
                            <label><input type="checkbox" id="questTypeMercury"> Mercury</label>
                            <label><input type="checkbox" id="questTypeApollo"> Apollo</label>
                            <label><input type="checkbox" id="questTypeDiana"> Diana</label>
                            <label><input type="checkbox" id="questTypeMinerva"> Minerva</label>
                            <label><input type="checkbox" id="questTypeVulcan"> Vulcan</label>
                            <label><input type="checkbox" id="questTypeMars"> Mars</label>
                        </div>
                    </div>

                    
                    </div>


                <div class="popup-box" id="heal_settings">
                  <div class="monster-buttons">
                  </div>
                  <div class="settings_tab_title">${d.cj}</div>

                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; margin-right: 50px;">
                  </div>

                  <div class="setting-row">
                  <label for="healPercentage">${d.bj}</label>
                  <div class="switch-field3">
                    <input type="number" id="healPercentage" min="1" max="99" value="${localStorage.getItem("healPercentage")||75}">
                  </div>
                </div>

                  <div class="setting-row">
                  <img style="margin-top: -10px" src="https://gf3.geo.gfsrv.net/cdneb/91e0372cccc24f52758be611a10a3b.png">
                  <label for="HealClothToggle">${d.lh}</label>
                  
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealClothToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="HealRubyToggle">${d.Vl}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealRubyToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healShopToggle">${d.pk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healShopToggle">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                  <label for="healfrompackage">${d.qk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="healfrompackage">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="setting-row">
                    <label for="HealPickBag">${d.Xe}</label>
                     <select id="HealPickBag" class="input">
                     <option value="1">
                        1
                      </option>
                      <option value="2">
                        2
                      </option>
                      <option value="3">
                        3
                      </option>
                      <option value="4">
                        4
                      </option>
                      <option value="5">
                        5
                      </option>
                      <option value="6">
                        6
                      </option>
                      <option value="7">
                        7
                      </option>
                      <option value="8">
                      8
                    </option>
                    </select>
                  </div>
                  
                  <div class="setting-row">
                  <label for="FoodAmount">${d.aj}</label>
                   <select id="FoodAmount" class="input">
                   <option value="1">
                      1
                    </option>
                    <option value="2">
                      2
                    </option>
                    <option value="3">
                      3
                    </option>
                    <option value="4">
                      4
                    </option>
                    <option value="5">
                      5
                    </option>
                    <option value="6">
                      6
                    </option>
                    <option value="7">
                      7
                    </option>
                    <option value="8">
                    8
                  </option>
                  </select>
                </div>   
                  
                <div class="setting-row" data-tooltip="${d.Ki}">
                <label for="healcervisia">${d.lk}</label>
                <label class="toggle-switch">
                    <input type="checkbox" id="healcervisia">
                    <span class="switch"></span>
                </label>
                </div>

                  <div class="setting-row">
                  <label for="HealEggs">${d.nk}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="HealEggs">
                      <span class="switch"></span>
                    </label>
                  </div>

                  <div class="settings_tab_title">${d.bf}</div>
                  <span class="span-new">${d.Cg}</span>
                  <div class="setting-row" data-tooltip="${d.qj}>
                  <label for="OilEnable">${d.pe}</label>
                    <label class="toggle-switch">
                      <input type="checkbox" id="OilEnable">
                      <span class="switch"></span>
                    </label>
                  </div>



                  <div class="setting-row">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-right: 50px;">
                    <table style="width: 100%">
                        <tbody>
                        <tr>
                            <td style="font-weight: bold; text-align: left; width: 30%">Minerva:</td>
                            <td style="text-align: right;">
                                <div class="radio-group">
                                <input type="radio" name="minerva" value="0"><span class="span-new">I</span>
                                <input type="radio" name="minerva" value="1"><span class="span-new">II</span>
                                <input type="radio" name="minerva" value="2"><span class="span-new">III</span>
                                <input type="radio" name="minerva" value="3" checked="true"><span class="span-new">Off</span>
                                </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Diana:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="diana" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="diana" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="diana" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="diana" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Mars:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="mars" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="mars" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="mars" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="mars" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Merkur:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="merkur" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="merkur" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="merkur" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="merkur" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Apollo:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="apollo" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="apollo" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="apollo" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="apollo" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; width: 30%">Vulcanus:</td>
                                <td>
                                    <div class="radio-group">
                                        <input type="radio" name="vulcanus" value="0"><span class="span-new">I</span>
                                        <input type="radio" name="vulcanus" value="1"><span class="span-new">II</span>
                                        <input type="radio" name="vulcanus" value="2"><span class="span-new">III</span>
                                        <input type="radio" name="vulcanus" value="3" checked="true"><span class="span-new">Off</span>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                            </table>
                        </div>


                    </div>
<div class="settings_tab_title">${d.Va}</div>
<span class="span-new">Bot will use buffs when available.</span>

<div class="setting-row" data-tooltip="${d.Ii}>
    <label for="BuffsEnable">Enable ${d.Va}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffsEnable">
        <span class="switch"></span>
    </label>
</div>

<div class="setting-row">
    <label for="BuffUnderworldOnly">${d.Xd}</label>
    <label class="toggle-switch">
        <input type="checkbox" id="BuffUnderworldOnly">
        <span class="switch"></span>
    </label>
</div>


<div class="setting-row">
    <div class="buff-group">
        <label>Health:</label>
        <input type="checkbox" id="HealthBuff1"> Gingko
        <input type="checkbox" id="HealthBuff2"> Taigaroot
        <input type="checkbox" id="HealthBuff3"> Hawthorn
    </div>

    <div class="buff-group">
        <label>Strength:</label>
        <input type="checkbox" id="StrengthBuff1"> Flask
        <input type="checkbox" id="StrengthBuff2"> Ampulla
        <input type="checkbox" id="StrengthBuff3"> Flacon
        <input type="checkbox" id="StrengthBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Dexterity:</label>
        <input type="checkbox" id="DexterityBuff1"> Flask
        <input type="checkbox" id="DexterityBuff2"> Ampulla
        <input type="checkbox" id="DexterityBuff3"> Flacon
        <input type="checkbox" id="DexterityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Agility:</label>
        <input type="checkbox" id="AgilityBuff1"> Flask
        <input type="checkbox" id="AgilityBuff2"> Ampulla
        <input type="checkbox" id="AgilityBuff3"> Flacon
        <input type="checkbox" id="AgilityBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Constitution:</label>
        <input type="checkbox" id="ConstitutionBuff1"> Flask
        <input type="checkbox" id="ConstitutionBuff2"> Ampulla
        <input type="checkbox" id="ConstitutionBuff3"> Flacon
        <input type="checkbox" id="ConstitutionBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Charisma:</label>
        <input type="checkbox" id="CharismaBuff1"> Flask
        <input type="checkbox" id="CharismaBuff2"> Ampulla
        <input type="checkbox" id="CharismaBuff3"> Flacon
        <input type="checkbox" id="CharismaBuff4"> Bottle
    </div>

    <div class="buff-group">
        <label>Intelligence:</label>
        <input type="checkbox" id="IntelligenceBuff1"> Flask
        <input type="checkbox" id="IntelligenceBuff2"> Ampulla
        <input type="checkbox" id="IntelligenceBuff3"> Flacon
        <input type="checkbox" id="IntelligenceBuff4"> Bottle
    </div>
</div>
                  </div>

                  <div class="popup-box" id="event_expedition_settings">
                    <div class="settings_tab_title">${d.eventExpedition}</div>

                    <div class="setting-row">
                        <div id="set_event_monster_id_0" class="monster-button">1</div>
                        <div id="set_event_monster_id_1" class="monster-button">2</div>
                        <div id="set_event_monster_id_2" class="monster-button">3</div>
                        <div id="set_event_monster_id_3" class="monster-button">Boss</div>
                    </div>
                    <div id="clear_next_event_expedition_time" class="awesome-button">${d.Yg}</div> <!-- New Button -->

                      <div class="setting-row">
                      <label for="renewEvent">${d.ah}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="renewEvent">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <label for="throwDice">${d.Hh}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="throwDice">
                        <span class="switch"></span>
                      </label>
                      </div>
                      <div class="setting-row">
                      <span class="span-new">${d.Ih}<span class="span-new">
                      
                                          </div>
                      <div class="setting-row">
                    <span class="span-new">${d.re}<span class="span-new">
                    
                                        </div>
                    </div>

                  <div class="popup-box" id="auto_auction_settings">
                

                    <div class="settings_tab_title">${d.Kd}</div>
                    <span class="span-new">To open search panels including Unique shop items, enable this option.<span class="span-new">
                    <div class="setting-row">
                    <label for="AuctionItemLevel2">${d.ug}</label>
                      <div class="switch-field2">
                        <input type="text" id="search_input" placeholder="${d.yd}">
                      </div>
                    </div>

                    <div class="setting-row">
                      <label for="AuctionItemLevel2">${d.Z}</label>
                      <div class="switch-field3">
                        <input type="number" id="AuctionItemLevel2" min="1" max="1000" value="5">
                      </div>
                    </div>   

                    <div class="setting-row">
                      <label for="SearchQuality">${d.Aa}</label>
                      <select id="SearchQuality" class="input">
                          <option value="-1">
                          ${d.Ea}
                          </option>
                            <option value="0">
                            ${d.C}
                            </option>
                            <option value="1">
                            ${d.B}
                            </option>
                            <option value="2">
                            ${d.D}
                            </option>
                          </option>
                      </select>
                    </div> 

                    <div class="setting-row">
                      <label>${d.ma}</label>
                      <div class="equipment-search-selection">
                          <label><input type="checkbox" class="equipment-search-option" value="2"> ${d.fa}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="4"> ${d.ca}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="8"> ${d.U}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1"> ${d.X}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="256"> ${d.W}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="512"> ${d.da}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="48"> ${d.aa}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="1024"> ${d.T}</label>
                          <label><input type="checkbox" class="equipment-search-option" value="9999"> ${d.Ha}</label>
                      </div>
                    </div>

                    <button class="awesome-button" id="search_button" type="button">${d.yd}</button>
                    <button class="awesome-button" id="search_reset" type="button">${d.Dd}</button>
       
                    <div class="setting-row">
                    <ul id="search_list"></ul>
                    <span class="span-new">${d.Fd}</span>
                    </div>

                    <div class="settings_tab_title">${d.oh}</div>
                    <div class="setting-row">

                      <!-- Title & Instructions -->
                      <div style="margin-bottom: 20px;">
                          <h2>${d.qh}</h2>
                          <p>${d.ph}</p>
                      </div>
                    </div>
                    <!-- Item Input Section -->

                        <div class="setting-row">
                          <label for="clothCount">${d.rh}</label>
                          <div class="switch-field2">
                              <input type="number" id="clothCount" placeholder="${d.th}">
                          </div>
                        </div>

                        <hr class="section-separator">

                        <div class="setting-row">
                              <label for="newItem">${d.ea}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItem" placeholder="${d.ea}">
                          </div>
                        </div>

                        <div class="setting-row">
                          <label for="newItemLevel">Min ${d.Sb}:</label>
                          <div class="switch-field2">                              
                              <input type="text" id="newItemLevel" placeholder="Min ${d.Sb}">
                          </div>
                        </div>
                
                        <div class="setting-row">
                          <label for="itemQuality">Min ${d.vh}:</label>
                          <select id="itemQuality">
                              <option value="0">${d.C}</option>
                              <option value="1">${d.B}</option>
                              <option value="2">${d.D}</option>
                              <option value="3">${d.H}</option>
                              <option value="4">${d.R}</option>
                          </select>
                        </div>

                        <!-- New Stat Selection with Combo Box -->
                        <div class="setting-row">
                        <label for="shopitemstat">Stat:</label>
                        <select id="shopitemstat">
                            <option value="none">NONE</option>
                            <option value="str">Strength</option>
                            <option value="dex">Dexterity</option>
                            <option value="agi">Agility</option>
                            <option value="cot">Constitution</option>
                            <option value="chr">Charisma</option>
                            <option value="int">Intelligence</option>
                        </select>
                        </div>

                        <div class="setting-row" id="statValueRow" style="display: none;">
                        <label for="statValue">Value:</label>
                        <div class="switch-field2">
                            <input type="number" id="statValue" placeholder="0">
                        </div>
                        </div>
                        

                        <div style="text-align: right;">
                        <button class="awesome-button" id="addItemButton">${d.I}</button>
                      </div>

                      <div class="setting-row">
                        <div id="itemsList" style="margin-bottom: 10px;">
                        <!-- Example item -->
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="flex: 1;">${d.uh}</span>
                            <button onclick="removeItem('uniqueItemID')">X</button>
                        </div>
                        <!-- Add more items similarly -->
                        </div>
                      </div>  
                  
                      <!-- Search Buttons -->
                      <div style="display: flex; justify-content: space-between; gap: 10px; margin-bottom: 20px;">
                        <button class="awesome-button" id="startSearchButton">${d.wh}</button>
                        <button class="awesome-button" id="skipSearchButton" style="display: none;">${d.xh}</button>
                        <button class="awesome-button" id="stopSearchButton">${d.yh}</button>
                      </div>
                      <div class="setting-row">
                      <!-- Progress Bar -->
                      <div style="margin-bottom: 20px;">
                          <label>${d.nh}:</label>
                          <div id="progressBarOuter" style="width: 100%; height: 20px; background-color: grey; border-radius: 10px;">
                              <div id="progressBarInner" style="height: 100%; width: 0%; background-color: green; border-radius: 10px;"></div>
                          </div>
                      </div>
                  
                      <!-- Found Items Container -->
                      <div id="foundItemsContainer"></div>
                    </div>
                </div>
                
                    


                  
                
                

                  <div class="popup-box" id="auto_auction2_settings">


                <div class="settings_tab_title">${d.Gh}</div>
                
                <div class="setting-row" data-tooltip="${d.Jd}">
                <label for="storeGoldinAuction">${d.v}</label>
                  <label class="toggle-switch">
                  <input type="checkbox" id="storeGoldinAuction">
                  <span class="switch"></span>
                  </label>
                  </div>

                <div class="setting-row">
                  <label for="itemsToReset2">${d.ba}</label>
                  <div id="itemsToReset2" class="items-reset-list">
                      <div class="item-reset"><input type="checkbox" id="WEAPONS2" value="WEAPONS2"><label for="WEAPONS">${d.oa}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHIELD2" value="SHIELD2"><label for="SHIELD">${d.S}</label></div>
                      <div class="item-reset"><input type="checkbox" id="CHEST2" value="CHEST2"><label for="CHEST">${d.M}</label></div>
                      <div class="item-reset"><input type="checkbox" id="HELMET2" value="HELMET2"><label for="HELMET">${d.P}</label></div>
                      <div class="item-reset"><input type="checkbox" id="GLOVES2" value="GLOVES2"><label for="GLOVES">${d.O}</label></div>
                      <div class="item-reset"><input type="checkbox" id="SHOES2" value="SHOES2"><label for="SHOES">${d.N}</label></div>
                      <div class="item-reset"><input type="checkbox" id="RINGS2" value="RINGS2"><label for="RINGS">${d.na}</label></div>
                      <div class="item-reset"><input type="checkbox" id="AMULETS2" value="AMULETS2"><label for="AMULETS">${d.ka}</label></div>
                  </div>
                </div>

                <div class="setting-row">
                    <label for="storeInShopQuality">${d.Aa}</label>
                    <select id="storeInShopQuality" class="input">
                    <option value="0">
                    ${d.C}
                    </option><!-- Add more options as needed -->
                        <option value="1">
                        ${d.B}
                        </option>
                        <option value="2">
                        ${d.D}
                        </option>
                  </select>
                

                </div>

                <div class="setting-row">
                <label for="storeGoldinAuctionmaxGold">${d.jg}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionmaxGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionmaxGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
                <label for="storeGoldinAuctionholdGold">${d.Y}</label>
                  <div class="switch-field3">
                    <input type="number" id="storeGoldinAuctionholdGold" placeholder="Amount" value="${localStorage.getItem("storeGoldinAuctionholdGold")||0}">       
                  </div>
              </div>

              <div class="setting-row">
              <label for="AuctionGoldCover">${d.kb}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="AuctionGoldCover">
                <span class="switch"></span>
              </label>
            </div>

                <span class="span-new">${d.jh}</span>
                  
                    <div class="settings_tab_title">${d.zg}</div>
                    <span class="span-new">${d.Ld}</span>
                    
                    <div class="setting-row">
                      <div class="table-container">
                          <table class="styled-table">
                            <thead>
                              <tr>
                                <th>Prefix</th>
                                <th>Suffix</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="AuctionprefixList"></ul>
                                </td>
                                <td>
                                  <ul class="styled-list" id="AuctionsuffixList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                 
                                    <input type="text" class="styled-input" id="AuctionnewPrefixInput">
                                    <input type="button" id="AuctionaddPrefixButton" value="${d.Oa}">
                                  </div>
                                </td>
                                <td>
                                  <div class="list-options">
                                    <input type="text" class="styled-input" id="AuctionnewSuffixInput">
                                    <input type="button" id="AuctionaddSuffixButton" value="${d.Pa}">
                                  </div>
                                </td>

                              </tr>
                            </tbody>
                          </table>
                          
                      </div>
                      
                    </div>
                  
                    <div class="setting-row">
                        <label>${d.ma}</label>
                        <div class="equipment-selection">
                            <label><input type="checkbox" class="equipment-option" value="2"> ${d.fa}</label>
                            <label><input type="checkbox" class="equipment-option" value="4"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option" value="8"> ${d.U}</label>
                            <label><input type="checkbox" class="equipment-option" value="1"> ${d.X}</label>
                            <label><input type="checkbox" class="equipment-option" value="256"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option" value="512"> ${d.da}</label>
                            <label><input type="checkbox" class="equipment-option" value="48"> ${d.aa}</label>
                            <label><input type="checkbox" class="equipment-option" value="1024"> ${d.T}</label>
                            <label><input type="checkbox" class="equipment-option" value="9999"> ${d.Ha}</label>
                        </div>
                    </div>

                      <div class="setting-row" data-tooltip="${d.kk}">
                        <label for="auctionTURBO">Turbo Mode Speed >> </label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionTURBO">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctiongladiatorenable">${d.kh}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctiongladiatorenable">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row">
                        <label for="auctionmercenaryenable">${d.mh}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="auctionmercenaryenable">
                          <span class="switch"></span>
                         </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Hd}>
                        <label for="ignorePS">${d.ef}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="ignorePS">
                            <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Ta}>
                        <label for="bidFood">${d.Td}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="bidFood">
                          <span class="switch"></span>
                        </label>
                      </div>

                      <div class="setting-row" data-tooltip="${d.Gd}>
                      <label for="AuctionCover">${d.kb}</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="AuctionCover">
                        <span class="switch"></span>
                      </label>
                    </div>

                      <div class="setting-row" data-tooltip="${d.Ta}>
                        <label for="bidfood">${d.kg}</label>
                        <div class="switch-field3">
                          <input type="number" id="maximumBid" min="1" max="1000000" value="25">
                        </div>
                      </div>

                      <div class="setting-row">
                        <label for="aunctionMinQuality">${d.Aa}</label>
                         <select id="auctionMinQuality" class="input">
                          <option value="2">
                          ${d.D}
                          </option>
                          <option value="1">
                          ${d.B}
                          </option>
                          <option value="0">
                          ${d.C}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                    <div class="setting-row">
                      <label for="auctionminlevel">${d.Z}</label>
                      <div class="switch-field3">
                        <input type="number" id="auctionminlevel" min="1" max="1000" value="0">
                      </div>
                    </div>

                      <div class="setting-row">
                        <label for="bidStatus">${d.Ud}</label>
                         <select id="bidStatus" class="input">
                          <option value="4">
                          ${d.Yb}
                          </option>
                          <option value="3">
                          ${d.Ub}
                          </option>
                          <option value="2">
                          ${d.Hb}
                          </option>
                          <option value="1">
                          ${d.zb}
                          </option>
                          <option value="0">
                          ${d.Xb}
                          </option><!-- Add more options as needed -->
                        </select>
                      </div>

                      <div class="setting-row">
                        <label for="enableMercenarySearch">${d.Ui}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="enableMercenarySearch">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <div id="mercenarySearchOptions" style="display:none">
                        <div class="setting-row">
                        
                            <label for="minDexterity">Min: ${d.Dexterity}</label>
                            <div class="switch-field3">
                                <input type="number" id="minDexterity" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minAgility">Min: ${d.Agility}</label>
                            <div class="switch-field3">
                                <input type="number" id="minAgility" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <div class="setting-row">
                            <label for="minIntelligence">Min: ${d.Intelligence}</label>
                            <div class="switch-field3">
                                <input type="number" id="minIntelligence" min="1" max="10000" value="0">
                            </div>
                        </div>
                        <span class="span-new">Enter 0 to ignore stats.</span>
                    </div>
                      
                      <div class="setting-row">
                        <h4>${d.Vd}</h4>
                        <div class="table-container">
                          <table class="styled-table">
                            <tbody>
                              <tr>
                                <td>
                                  <ul class="styled-list" id="bidList"></ul>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="list-options">
                                    <input type="button" class="awesome-button" id="clearBidItemsHistory" value="${d.Xa}">
                                  </div>
                                  
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                  </div>

                <div class="popup-box" id="auto_smelt_settings">
                    <div class="settings_tab_title" style="position: relative;">
                        Auto Smelt
                        <i class="fas fa-info-circle" id="autoSmeltInfo" style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 22px; color: black;"></i>

                    
                    </div>


                    <div class="rule-container">
                    <!-- Rule Row Template -->
                    <div class="rule-row-template" style="display: none;">
                        <!-- Top row (Condition, Prefix, Scroll, Level) -->
                        <div class="rule-top-row">
     
                            <label class="rule-checkbox-wrapper">
        
                                <input type="checkbox" class="rule-checkbox">
                                <span class="checkbox-icon"></span>
                                
                            </label>

                            &nbsp

                            <!-- Condition Combo Box -->
                            <select class="rule-condition-select">
                                <option value="nameContains">${d.yg}</option>
                                <option value="isUnderworldItem">${d.isUnderworldItem}</option>
                            </select>

                            <!-- Text input appears only for 'Name contains' -->
                            <input type="text" class="rule-prefix-input" placeholder="${d.Ib}" />
                            <input type="text" class="rule-suffix-input" placeholder="${d.Vb}" />

                            <!-- Scroll Combo Box 
                            <select class="rule-scroll-select">
                                <option value="noScroll">No scroll</option>
                                <option value="anyScroll">Has any scroll</option>
                            </select>
                            -->

                            <input type="number" class="rule-level" placeholder="lvl>">
                        </div>

                        <!-- Second row (Item Types, Colors, Hammer) -->
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection">
                                <span class="color-circle white" data-color="white"></span>
                                <span class="color-circle green" data-color="green"></span>
                                <span class="color-circle blue" data-color="blue"></span>
                                <span class="color-circle purple" data-color="purple"></span>
                                 <span class="color-circle orange" data-color="orange"></span>
                                <span class="color-circle red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

                            <button class="remove-rule-btn">X</button>
                        </div>
                    </div>

                    <!-- Add Rule Button -->
                    <button class="add-rule-btn">${d.Ag}</button>
                    <hr style="border: 1px solid #c4ac70; margin: 10px 0;">
                </div>



                    <!-- Condition Selection  
                    <div class="setting-row">
                        <label for="smeltCondition">Condition:</label>
                        <select id="smeltCondition" class="styled-select" style="width:200px">
                            <option value="name_contains">Name contains</option>
                            <option value="name_word">Name contains word</option>
                            <option value="color">Item color is</option>
                            <option value="underworld_prefix_suffix">Item has underworld prefix/suffix</option>
                        </select>
                    </div>
                    
                    <div class="setting-row" id="filterNameRow">
                        <label for="filterNameInput">Filter Profile Name:</label>
                        <input type="text" id="filterNameInput" class="styled-input3" placeholder="Enter profile name" />
                    </div>

                    <div class="setting-row" id="itemNameRow" style="display: none;">
                        <label for="itemNameInput">Item Name:</label>
                        <input type="text" id="itemNameInput" class="styled-input" placeholder="Enter item name" />
                    </div>
                    
                    <div class="setting-row" id="colorRow" style="display: none;">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                

                    <div class="setting-row">
                        <h4>Added Filters</h4>
                        <div id="filtersList" class="filter-list"></div>
                    </div>


                    <div class="setting-row">
                        <h4>Saved Items</h4>
                        <div id="savedItemsList" class="filter-list"></div>
                    </div>

                    

                    <div class="setting-row">
                        <label>${d.ma}</label>
                        <div class="equipment-selection-smelt">
                            <label><input type="checkbox" class="equipment-option-smelt" value="2"> ${d.fa}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="4"> ${d.ca}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="8"> ${d.U}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1"> ${d.X}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="256"> ${d.W}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="512"> ${d.da}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="48"> ${d.aa}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="1024"> ${d.T}</label>
                            <label><input type="checkbox" class="equipment-option-smelt" value="9999"> ${d.Ha}</label>
                        </div>
                    </div>
                  

                    <div class="setting-row" id="colorRowOriginal">
                        <label>Select Color(s):</label>
                        <div class="color-selector">
                            <label class="color-circle" style="background-color: white;" data-value="white"></label>
                            <label class="color-circle" style="background-color: green;" data-value="green"></label>
                            <label class="color-circle" style="background-color: blue;" data-value="blue"></label>
                            <label class="color-circle" style="background-color: purple;" data-value="purple"></label>
                            <label class="color-circle" style="background-color: orange;" data-value="orange"></label>
                            <label class="color-circle" style="background-color: red;" data-value="red"></label>
                        </div>
                    </div>
                    

                    <div class="setting-row">
                        <label for="smeltUnderworld">Smelt only Underworld/Hell items?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="smeltUnderworld">
                        <span class="switch"></span>
                        </label>
                    </div>
                    -->

                    <div class="setting-row">
                        <label for="smeltLootbox">${d.Nj}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="smeltLootbox">
                            <span class="switch"></span>
                        </label>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltIgnorePS">${d.Mj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltIgnorePS">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->

                    <div class="setting-row">
                      <label for="smeltAnything">${d.Ch}</label>
                      
                      <label class="toggle-switch" data-tooltip="${d.Oj}">
                        <input type="checkbox" id="smeltAnything">
                        <span class="switch"></span>
                      </label>
                        <div class="rule-bottom-row">
                            <div class="item-types">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/sword.png" alt="Weapons" data-type="2">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shield.png" alt="Shields" data-type="4">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/chest.png" alt="Chest Armour" data-type="8">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/helmet.png" alt="Helmets" data-type="1">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/gloves.png" alt="Gloves" data-type="256">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/shoes.png" alt="Shoes" data-type="512">
                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/ring1.png" alt="Rings1" data-type="48">

                                <img class="item-icon2" src="https://raw.githubusercontent.com/fociisoftware/glbt/main/necklace.png" alt="Amulets" data-type="1024">
                            </div>
                            <!-- Colors -->
                            <div class="rule-color-selection2">
                                <span class="color-circle2 white" data-color="white"></span>
                                <span class="color-circle2 green" data-color="green"></span>
                                <span class="color-circle2 blue" data-color="blue"></span>
                                <span class="color-circle2 purple" data-color="purple"></span>
                                 <span class="color-circle2 orange" data-color="orange"></span>
                                <span class="color-circle2 red" data-color="red"></span>
                            </div>

                            <!-- Hammer Toggle with 3 states (bronze, silver, gold) -->
                            <div class="rule-hammer-selection2">
                                <img class="item-i-19-10" data-hammer="bronze"  />
                                <img class="item-i-19-11" data-hammer="silver"  />
                                <img class="item-i-19-12" data-hammer="gold"  />
                            </div>

        
                        </div>
                    </div>

                    <div class="setting-row" data-tooltip="${d.Pj}">
                      <label for="smelteverything3">${d.Xj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="smelteverything3">
                        <span class="switch"></span>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="RepairBeforeSmelt">${d.Fj}</label>
                      <label class="toggle-switch">
                        <input type="checkbox" id="RepairBeforeSmelt">
                        <span class="switch"></span>
                      </label>
                        <div class="setting-row">
                        <label for="repairBeforeSmeltMaxQuality">${d.Mc}</label>
                            <select id="repairBeforeSmeltMaxQuality" class="input">
                                    <option value="3">
                                    ${d.H}
                                    </option>
                                    <option value="2">
                                    ${d.D}
                                    </option>
                                    <option value="1">
                                    ${d.B}
                                    </option>
                                    <option value="0">
                                    ${d.C}
                                    </option>
                                    <option value="-1">
                                    ${d.Ea}
                                    </option>
                            </select>
                        </div>
                        <div class="setting-row">
                        <label for="PartialOrFull">${d.Gg}</label>
                            <select id="PartialOrFull" class="input">
                                    <option value="0">
                                    ${d.Hg}
                                    </option>
                                    <option value="1">
                                    ${d.Ve}
                                    </option>
                            </select>
                        </div>
                    </div>

                    <!--
                    <div class="setting-row">
                      <label for="smeltusehammers">Use Hammers?</label>
                      <span class="span-new">[Bot will look for bronze then silver.]</span>   
                      <label class="toggle-switch">
                        <input type="checkbox" id="smeltusehammers">
                        <span class="switch"></span>
                      </label>
                    </div>
                    -->
                    
                    <div class="setting-row">
                        <label for="smeltTab">${d.Dh}</label>
                        <select id="smeltTab" class="input">
                        <option value="6">
                            8
                        </option>
                            <option value="5">
                                7
                            </option>
                            <option value="4">
                                6
                            </option>
                            <option value="3">
                                5
                            </option>
                            <option value="2">
                                4
                            </option>
                            <option value="1">
                                3
                            </option>
                            <option value="0">
                                2
                            </option>
                        </select>
                    </div>

                    <!--
                    <div class="setting-row">
                        <label for="smeltLevel">Min Level</label>
                        <div class="switch-field3">
                            <input type="number" id="smeltLevel" min="1" max="100" value="${localStorage.getItem("smeltLevel")||1}">
                        </div>
                    </div>
                    
                    
                    
                    <span class="span-new">${d.Yj}</span>
-->
                    <div class="settings_tab_title">${d.Bh}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                <thead>
                                    <tr>
                                    <th>${d.Ib}</th>
                                    <th>${d.Vb}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td>
                                        <ul class="styled-list" id="IgnoredprefixList"></ul>
                                    </td>
                                    <td>
                                        <ul class="styled-list" id="IgnoredsuffixList"></ul>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredPrefixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddPrefixButton" value="${d.Oa}">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="list-options">
                                        <input type="text" class="styled-input" id="newIgnoredSuffixInput">
                                        <input type="button" class="awesome-button" id="IgnoredaddSuffixButton" value="${d.Pa}">
                                        </div>
                                    </td>
                                    </tr>
                                </tbody>
                                </table>          
                        </div>
                    </div>
                    
                    <!-- Smelted Items List -->
                  
                    <div class="settings_tab_title">${d.Wj}</div>
                        <div class="setting-row">
                            <div class="table-container">
                                <table class="styled-table">
                                    <tbody>
                                    <tr>
                                        <td>
                                        <ul class="styled-list" id="smeltedList"></ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <div class="list-options">
                                            <input type="button" class="awesome-button" id="clearSmeltedItemsHistory" value="${d.Xa}">
                                            
                                        </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>    
                        </div>
                    </div>
                </div>

                
                <div class="popup-box" id="auto_repair_settings">
                <div class="settings_tab_title">${d.Lb}</div>
                <div class="setting-row">

                    <div class="inventory gladiator-inventory">
                        <h3>Gladiator</h3>
                        <!-- Inventory Rows for Gladiator -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weapon">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmet">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armor">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shield">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="gloves">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoes">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklace">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>

                        </div>
                    </div>

                    <div class="inventory mercenary-inventory">
                        <h3>Mercenary</h3>
                        <!-- Inventory Rows for Mercenary -->
                        <div class="inventory-row">
                            <div class="inventory-item" id="weaponM">
                                <div class="sword-image" id="sword-image"></div>
                            </div>
                            <div class="inventory-item" id="helmetM">
                                <div class="helmet-image" id="helmet-image"></div>
                            </div>
                            <div class="inventory-item" id="armorM">
                                <div class="chest-image" id="chest-image" ></div>
                            </div>
                            <div class="inventory-item" id="shieldM">
                                <div class="shield-image" id="shield-image"></div>
                            </div>
                             <div class="inventory-item" id="glovesM">
                                <div class="gloves-image" id="gloves-image"></div>
                            </div>
                        </div>
                        <div class="inventory-row">
                            <div class="inventory-item" id="shoesM">
                                <div class="shoes-image" id="shoes-image"></div>
                            </div>
                            <div class="inventory-item" id="rings1M">
                                <div class="ring1-image" id="ring1-image"></div>
                            </div>
                            <div class="inventory-item" id="rings2M">
                                <div class="ring2-image" id="ring2-image"></div>
                            </div>
                            <div class="inventory-item" id="necklaceM">
                                <div class="necklace-image" id="necklace-image"></div>
                            </div>
                        </div>
                    </div>

                    <div class="instructions" style="clear: both;">
                            <span class="span-new">${d.bc}</span><br>
                            <span class="span-new">${d.bh}</span>
                        </div>
                    </div>

                    <div class="setting-row">
                        <label for="repairGladiator">${d.Da} Gladiator?</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="repairGladiator">
                            <span class="switch"></span>
                        </label>
                    </div>
                  
                    <div class="setting-row">
                        <label for="repairMercenary">${d.Da} Mercenary?</label>
                        <label class="toggle-switch">
                        <input type="checkbox" id="repairMercenary">
                        <span class="switch"></span>
                        </label>
                    </div>

                    <div class="setting-row">
                        <label for="repairPercentage">${d.vg}</label>
                        <select id="repairPercentage" class="input">
                        <option value="3">%10</option>
                        <option value="2">%20</option>
                        <option value="1">%30</option>
                        <option value="0">%40</option>
                        <option value="-1">%50</option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="repairMaxQuality">${d.Mc}</label>
                        <select id="repairMaxQuality" class="input">
                                <option value="3">
                                ${d.H}
                                </option>
                                <option value="2">
                                ${d.D}
                                </option>
                                <option value="1">
                                ${d.B}
                                </option>
                                <option value="0">
                                ${d.C}
                                </option>
                                <option value="-1">
                                ${d.Ea}
                                </option>
                        </select>
                    </div>

                    <div class="setting-row">
                        <label for="currentWorkbenchItem">${d.be}</label>
                        <span id="currentWorkbenchItem"></span> <!-- Item name will be displayed here -->
                    </div>

                    <div class="setting-row">
                        <div id="clear_repair" style="display:flex;" class="awesome-button">${d.sk}</div> <!-- Button to clear -->
                    </div>

                    <div class="setting-row" id="ignoreMaterialsSection" style="margin-top: 10px; border-top: 1px solid #b3a77a; padding-top: 10px; background: linear-gradient(to right, #e8e1c8, #dacfa1); border-radius: 8px;">
                        <h3 style="color: #5a5a5a; font-family: 'Arial', sans-serif; text-align: center; text-transform: uppercase; letter-spacing: 2px;">${d.df}</h3>
                        
                        <!-- Scrollable list of materials -->
                        <div id="ignoreMaterialsList" style="border-radius: 4px; padding: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); height: 300px; max-height: 300px; overflow-y: auto; display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                            <!-- Base Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Base Materials</h4>
                                <label><input type="checkbox" value="1"> ${d.Kc}</label><br>
                                <label><input type="checkbox" value="2"> ${d.Ac}</label><br>
                                <label><input type="checkbox" value="3"> ${d.Ec}</label><br>
                                <label><input type="checkbox" value="4"> ${d.Gc}</label><br>
                            </div>

                            <!-- Materials category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Materials</h4>
                                <label><input type="checkbox" value="13"> ${d.Lc}</label><br>
                                <label><input type="checkbox" value="14 Wool"> ${d.Bc}</label><br>
                                <label><input type="checkbox" value="15"> ${d.Dc}</label><br>
                                <label><input type="checkbox" value="16"> ${d.Cc}</label><br>
                                <label><input type="checkbox" value="17"> ${d.Hc}</label><br>
                                <label><input type="checkbox" value="18"> ${d.Fc}</label><br>
                                <label><input type="checkbox" value="19"> ${d.Jc}</label><br>
                                <label><input type="checkbox" value="20"> ${d.Ic}</label><br>
                            </div>

                            <!-- Monster Parts category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Monster Parts</h4>
                                <label><input type="checkbox" value="5"> ${d.Tc}</label><br>
                                <label><input type="checkbox" value="6"> ${d.Nc}</label><br>
                                <label><input type="checkbox" value="7"> ${d.Wc}</label><br>
                                <label><input type="checkbox" value="8"> ${d.Qc}</label><br>
                                <label><input type="checkbox" value="9"> ${d.Sc}</label><br>
                                <label><input type="checkbox" value="10> ${d.Rc}</label><br>
                                <label><input type="checkbox" value="11"> ${d.Oc}</label><br>
                                <label><input type="checkbox" value="12"> ${d.Vc}</label><br>
                                <label><input type="checkbox" value="55"> ${d.Pc}</label><br>
                                <label><input type="checkbox" value="58"> ${d.Uc}</label><br>
                                <label><input type="checkbox" value="62"> ${d.Xc}</label><br>
                                <label><input type="checkbox" value="64"> ${d.Yc}</label><br>
                            </div>

                            <!-- Gemstones category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Gemstones</h4>
                                <label><input type="checkbox" value="21"> ${d.wc}</label><br>
                                <label><input type="checkbox" value="22"> ${d.qc}</label><br>
                                <label><input type="checkbox" value="23"> ${d.pc}</label><br>
                                <label><input type="checkbox" value="24"> ${d.rc}</label><br>
                                <label><input type="checkbox" value="25"> ${d.xc}</label><br>
                                <label><input type="checkbox" value="26"> ${d.uc}</label><br>
                                <label><input type="checkbox" value="27"> ${d.tc}</label><br>
                                <label><input type="checkbox" value="28"> ${d.sc}</label><br>
                                <label><input type="checkbox" value="59"> ${d.vc}</label><br>
                                <label><input type="checkbox" value="63"> ${d.yc}</label><br>
                            </div>

                            <!-- Flasks category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Flasks</h4>
                                <label><input type="checkbox" value="37"> ${d.kc}</label><br>
                                <label><input type="checkbox" value="38"> ${d.nc}</label><br>
                                <label><input type="checkbox" value="39"> ${d.fc}</label><br>
                                <label><input type="checkbox" value="40"> ${d.ec}</label><br>
                                <label><input type="checkbox" value="41"> ${d.mc}</label><br>
                                <label><input type="checkbox" value="42"> ${d.jc}</label><br>
                                <label><input type="checkbox" value="43"> ${d.hc}</label><br>
                                <label><input type="checkbox" value="44"> ${d.ic}</label><br>
                                <label><input type="checkbox" value="53"> ${d.oc}</label><br>
                                <label><input type="checkbox" value="61"> ${d.lc}</label><br>
                            </div>

                            <!-- Runes category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Runes</h4>
                                <label><input type="checkbox" value="29"> ${d.xd}</label><br>
                                <label><input type="checkbox" value="30"> ${d.rd}</label><br>
                                <label><input type="checkbox" value="31"> ${d.pd}</label><br>
                                <label><input type="checkbox" value="32"> ${d.wd}</label><br>
                                <label><input type="checkbox" value="33"> ${d.vd}</label><br>
                                <label><input type="checkbox" value="34"> ${d.td}</label><br>
                                <label><input type="checkbox" value="35"> ${d.qd}</label><br>
                                <label><input type="checkbox" value="36"> ${d.ud}</label><br>
                                <label><input type="checkbox" value="60"> ${d.sd}</label><br>
                            </div>

                            <!-- Ores category -->
                            <div>
                                <h4 style="font-family: 'Arial', sans-serif; margin-bottom: 5px;">Ores</h4>
                                <label><input type="checkbox" value="45"> ${d.cd}</label><br>
                                <label><input type="checkbox" value="46"> ${d.bd}</label><br>
                                <label><input type="checkbox" value="47"> ${d.gd}</label><br>
                                <label><input type="checkbox" value="48"> ${d.kd}</label><br>
                                <label><input type="checkbox" value="49"> ${d.ld}</label><br>
                                <label><input type="checkbox" value="50"> ${d.ed}</label><br>
                                <label><input type="checkbox" value="51"> ${d.jd}</label><br>
                                <label><input type="checkbox" value="52"> ${d.hd}</label><br>
                                <label><input type="checkbox" value="54"> ${d.ad}</label><br>
                                <label><input type="checkbox" value="56"> ${d.dd}</label><br>
                                <label><input type="checkbox" value="57"> ${d.fd}</label><br>
                            </div>
                        </div>

                    </div>

                </div>


                <div class="popup-box" id="guild_settings">

                    <!-- Guld stuff comes here -->

                    <div class="settings_tab_title">${d.Fh}</div>

                        <span class="span-new">${d.Ti}:</span>
                        <span class="span-new">${d.pf}</span>
                  
                        <div class="setting-row">
                            <label for="doKasa">${d.v}</label>
                            <label class="toggle-switch">
                            <input type="checkbox" id="doKasa">
                            <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        <label for="AuctionItemLevel2">${d.wg}</label>
                            <div class="switch-field2">
                            <input type="number" id="minimumGoldAmount" placeholder="Amount" value="${localStorage.getItem("minimumGoldAmount")||0}">         
                            </div>
                        </div>

                        <div class="setting-row">
                            <label for="filterGM">${d.Te}</label>
                            <select id="filterGM">
                            <option value="" disabled>${d.ba}</option>
                            <option value="pd">${d.xg}</option>
                            <option value="p">${d.Zd}</option>
        
                            </select>
                        </div>

                        <div class="setting-row">
                            <label for="guildPackHour">${d.Qb}</label>
                            <select id="guildPackHour">
                            <option value="" disabled>${d.Qb}</option>
                            <option value="1">2 hr</option>
                            <option value="2">8 hr</option>
                            <option value="3">24 hr</option>
                            </select>
                        </div>

                        <div class="setting-row">
                        <label for="KasaHoldGold">${d.Y}</label>
                            <div class="switch-field3">
                            <input type="number" id="KasaHoldGold" placeholder="Amount" value="${localStorage.getItem("KasaHoldGold")||0}">       
                                </div>
                        </div>

                        <div class="setting-row">
                            <label for="itemsToResetGuild">${d.ba}</label>
                            <div id="itemsToResetGuild" class="items-reset-list">
                                <div class="item-reset"><input type="checkbox" id="GUILD_WEAPONS" value="GUILD_WEAPONS"><label for="GUILD_WEAPONS">${d.oa}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHIELD" value="GUILD_SHIELD"><label for="GUILD_SHIELD">${d.S}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_CHEST" value="GUILD_CHEST"><label for="GUILD_CHEST">${d.M}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_HELMET" value="GUILD_HELMET"><label for="GUILD_HELMET">${d.P}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_GLOVES" value="GUILD_GLOVES"><label for="GUILD_GLOVES">${d.O}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SHOES" value="GUILD_SHOES"><label for="GUILD_SHOES">${d.N}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RINGS" value="GUILD_RINGS"><label for="GUILD_RINGS">${d.na}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_AMULETS" value="GUILD_AMULETS"><label for="GUILD_AMULETS">${d.ka}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FOOD" value="GUILD_FOOD"><label for="GUILD_FOOD">${d.Ia}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_USABLES" value="GUILD_USABLES"><label for="GUILD_USABLES">${d.md}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_UPGRADES" value="GUILD_UPGRADES"><label for="GUILD_UPGRADES">${d.Na}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_RECIPES" value="GUILD_RECIPES"><label for="GUILD_RECIPES">${d.Ka}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_MERCENARY" value="GUILD_MERCENARY"><label for="GUILD_MERCENARY">${d.Ja}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_SCROLLS" value="GUILD_SCROLLS"><label for="GUILD_SCROLLS">${d.La}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_REINFORCEMENTS" value="GUILD_REINFORCEMENTS"><label for="GUILD_REINFORCEMENTS">${d.od}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_TOOLS" value="GUILD_TOOLS"><label for="GUILD_TOOLS">${d.Ma}</label></div>
                                <div class="item-reset"><input type="checkbox" id="GUILD_FORGE_RESOURCES" value="GUILD_FORGE_RESOURCES"><label for="GUILD_FORGE_RESOURCES">${d.nd}</label></div>
                            </div>
                        </div>

                    <div class="settings_tab_title">${d.Yi}</div>

                            
                            <div class="setting-row">
                                <label for="guildBattleEnable">${d.v}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleEnable">
                                    <span class="switch"></span>
                                </label>          
                            </div>

                            <div class="setting-row">
                             <label for="guildBattleRandom">${d.Xi}</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="guildBattleRandom">
                                    <span class="switch"></span>
                                </label>
                            </div>

                            <div class="setting-row">
                                ${d.Zi}
                                <div class="input-container">
                                <input type="text" id="keywordGuildInput" placeholder="${d.V}">
                                <button class="awesome-button" id="addGuildKeywordBtn">${d.I}</button>
                                </div>
                                <div id="keywordGuildList"></div>
                            </div>

                    <div class="settings_tab_title">${d.lb}</div>

                        <div class="setting-row">
                            <label for="GuildEnable">${d.v}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="GuildEnable">
                                <span class="switch"></span>
                            </label>
                        </div>

                        <div class="setting-row">
                        
                            <label for="GuildDonateAmount">${d.cf}</label>
                            <div class="switch-field3">
                                <input type="number" id="GuildDonateAmount" min="0" value="${localStorage.getItem("GuildDonateAmount")||0}">      
                            </div> 

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateMore">${d.fe}</label>
                                <div class="switch-field3">
                                    <input type="number" id="GuildDonateMore" min="0" value="${localStorage.getItem("GuildDonateMore")||0}">                         
                                </div>

                        </div>

                        <div class="setting-row">
                            <label for="GuildDonateLess">${d.qf}</label>
                            <div class="switch-field3">
                            <input type="number" id="GuildDonateLess" min="0" value="${localStorage.getItem("GuildDonateLess")||0}">       
                            </div>                  
                        </div>

                        <span class="span-new">${d.ee}</span>
                        
                    </div>

                <div class="popup-box" id="other_settings2">

                    <div class="settings_tab_title">${d.dh}</div>


                    <div class="setting-row">
                    <span class="span-new">${d.eh}</span>
                    <div class="instructionsReset">
                    
                    <span class="span-new">${d.Mb}</span>
                    </div>
                 
                    </div>
                    
                    <div class="setting-row">
                      <label for="resetExpiredItems">${d.v}</label>
                      <label class="toggle-switch">
                          <input type="checkbox" id="resetExpiredItems">
                          <span class="switch"></span>
                      </label>
                    </div>
                    <div class="setting-row">
                    <label for="resetColors">Select Colors</label>
                            <div class="rule-color-resetColors">
                                <span class="color-circle3 white" data-color="-1"></span>
                                <span class="color-circle3 green" data-color="0"></span>
                                <span class="color-circle3 blue" data-color="1"></span>
                                <span class="color-circle3 purple" data-color="2"></span>
                                <span class="color-circle3 orange" data-color="3"></span>
                                <span class="color-circle3 red" data-color="4"></span>
                            </div>
                    </div>


                    <div class="setting-row">
 
                        <label for="resetDays">${d.fh}</label>
                        <select id="resetDays" style="margin-left: 5px;">
                            <option value="1">1 day</option>
                            <option value="2">2 days</option>
                            <option value="3">3 days</option>
                            <option value="4">4 days</option>
                        </select>
                    </div>
                    
                    <div class="setting-row">
                        <label for="itemsToReset">${d.Sk}</label>
                        <button id="selectAllItems" title="Select All">
                            <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">
                                <polyline points="20 6 9 17 4 12"></polyline> <!-- This SVG represents a check mark -->
                            </svg>
                        </button>
                        <div id="itemsToReset" class="items-reset-list">
                        
                            <div class="item-reset"><input type="checkbox" id="WEAPONS" value="WEAPONS"><label for="WEAPONS">${d.oa}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHIELD" value="SHIELD"><label for="SHIELD">${d.S}</label></div>
                            <div class="item-reset"><input type="checkbox" id="CHEST" value="CHEST"><label for="CHEST">${d.M}</label></div>
                            <div class="item-reset"><input type="checkbox" id="HELMET" value="HELMET"><label for="HELMET">${d.P}</label></div>
                            <div class="item-reset"><input type="checkbox" id="GLOVES" value="GLOVES"><label for="GLOVES">${d.O}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SHOES" value="SHOES"><label for="SHOES">${d.N}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RINGS" value="RINGS"><label for="RINGS">${d.na}</label></div>
                            <div class="item-reset"><input type="checkbox" id="AMULETS" value="AMULETS"><label for="AMULETS">${d.ka}</label></div>
                            <div class="item-reset"><input type="checkbox" id="FOOD" value="FOOD"><label for="FOOD">${d.Ia}</label></div>
                            <div class="item-reset"><input type="checkbox" id="USABLES" value="USABLES"><label for="USABLES">${d.md}</label></div>
                            <div class="item-reset"><input type="checkbox" id="UPGRADES" value="UPGRADES"><label for="UPGRADES">${d.Na}</label></div>
                            <div class="item-reset"><input type="checkbox" id="RECIPES" value="RECIPES"><label for="RECIPES">${d.Ka}</label></div>
                            <div class="item-reset"><input type="checkbox" id="MERCENARY" value="MERCENARY"><label for="MERCENARY">${d.Ja}</label></div>
                            <div class="item-reset"><input type="checkbox" id="SCROLLS" value="SCROLLS"><label for="SCROLLS">${d.La}</label></div>
                            <div class="item-reset"><input type="checkbox" id="REINFORCEMENTS" value="REINFORCEMENTS"><label for="REINFORCEMENTS">${d.od}</label></div>
                            <div class="item-reset"><input type="checkbox" id="TOOLS" value="TOOLS"><label for="TOOLS">${d.Ma}</label></div>
                            
                        </div>

                        <div class="setting-row">
                            <label for="resetUnderworld">${d.Tk}</label>
                            <label class="toggle-switch">
                                <input type="checkbox" id="resetUnderworld">
                                <span class="switch"></span>
                            </label>
                        </div>
                    </div>
                    
                    <hr style="border: none; border-top: 1px solid black; margin: 10px 0px;">

                    <div class="setting-row">
                        <label for="pauseDuration">${d.Kg} </label>
                        <select id="pauseDuration">
                        <option value="0">No pause</option>
                        <option value="1">Stable Boy</option>
                        <option value="2">Farmer</option>
                        <option value="3">Butcher</option>
                        <option value="4">Fisherman</option>
                        <option value="5">Baker</option>
                        </select>
                    </div>
                     
              </div>

                <div class="popup-box" id="Timers">
                <div class="settings_tab_title">${d.Wb}</div>
                <span class="span-new">${d.Timers}</span>

                <div class="setting-row">
                    <div class="timer-list" style="display: grid; grid-template-columns: repeat(2, 5fr); gap: 10px;">

                    <div class="timer-item">
                        <label for="smelting-timer" style="font-weight: bold;">${d.bi}</label>
                        <p class="description">${d.$h}</p>
                        <input type="number" id="smelting-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Smelting||10}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-nogold" style="font-weight: bold;">${d.ai}</label>
                        <p class="description">${d.Xh}</p>
                        <input type="number" id="smelting-timer-nogold" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="smelting-timer-noitem" style="font-weight: bold;">${d.Yh}</label>
                        <p class="description">${d.Zh}</p>
                        <input type="number" id="smelting-timer-noitem" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SmeltingNoItem||15}">
                    </div>

                    <div class="timer-item">
                        <label for="repair-timer" style="font-weight: bold;">${d.Da}</label>
                        <p class="description">${d.Sh}</p>
                        <input type="number" id="repair-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Repair||10}">
                    </div>

                    <div class="timer-item">
                        <label for="guild-market-timer" style="font-weight: bold;">${d.Qh}</label>
                        <p class="description">${d.Rh}</p>
                        <input type="number" id="guild-market-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildMarket||2}">
                    </div>

                    <div class="timer-item">
                        <label for="auction-hold-timer" style="font-weight: bold;">${d.Mh}</label>
                        <p class="description">${d.Nh}</p>
                        <input type="number" id="auction-hold-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionHoldGold||5}">
                    </div>

                    <div class="timer-item">
                        <label for="arena-timer" style="font-weight: bold;">Arena:</label>
                        <p class="description">${d.Jh}</p>
                        <input type="number" id="arena-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Arena||10}">
                    </div>

                    <div class="timer-item">
                        <label for="circus-turma-timer" style="font-weight: bold;">Circus Turma:</label>
                        <p class="description">${d.Oh}</p>
                        <input type="number" id="circus-turma-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).CircusTurma||10}">
                    </div>

                    <div class="timer-item">
                        <label for="training-timer" style="font-weight: bold;">${d.ei}</label>
                        <p class="description">${d.fi}</p>
                        <input type="number" id="training-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Training||2}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-expired-timer" style="font-weight: bold;">${d.Th}</label>
                        <p class="description">${d.Uh}</p>
                        <input type="number" id="reset-expired-timer" class="timer-input" style="width: 60px;" min="3" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).ResetExpired||10}">
                    </div>

                    <div class="timer-item">
                        <label for="store-forge-timer" style="font-weight: bold;">${d.ci}</label>
                        <p class="description">${d.di}</p>
                        <input type="number" id="store-forge-timer" class="timer-input" style="width: 60px;" min="5" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).StoreForge||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-auction-timer" style="font-weight: bold;">${d.Kh}</label>
                        <p class="description">${d.Lh}</p>
                        <input type="number" id="reset-auction-timer" class="timer-input" style="width: 60px;" min="1" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).AuctionCheck||10}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-search-timer" style="font-weight: bold;">${d.Vh}</label>
                        <p class="description">${d.Wh}</p>
                        <input type="number" id="reset-search-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).SearchTimer||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guilddonate-timer" style="font-weight: bold;">${d.lb}</label>
                        <p class="description">${d.Ph}</p>
                        <input type="number" id="reset-guilddonate-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).GuildDonate||5}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-guildattack-timer" style="font-weight: bold;">Guild Attack</label>
                        <p class="description">Sets timer for guild attack</p>
                        <input type="number" id="reset-guildattack-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).guildBattleEnable||120}">
                    </div>

                    <div class="timer-item">
                        <label for="reset-buff-timer" style="font-weight: bold;">Buffs</label>
                        <p class="description">Buff timer</p>
                        <input type="number" id="reset-buff-timer" class="timer-input" style="width: 60px;" placeholder="Min" value="${JSON.parse(localStorage.getItem("Timers")).Buffs||60}">
                    </div>

                    </div>
                </div>
                </div>


                  <div class="popup-box" id="other_settings">

                <div class="settings_tab_title">${d.Bd}</div>

                <div class="setting-row">
                ${d.Cd}
                    <select id="delaySelect">
                    <option value="0">0 seconds</option>
                    <option value="1">1 second</option>
                    <option value="5">1 to 5 seconds</option>
                    <option value="10">5 to 10 seconds</option>
                    <option value="15">10 to 15 seconds</option>
                    <option value="30">15 to 30 seconds</option>
                    <option value="60">30 to 60 seconds</option>
                    <option value="120">1 to 2 minutes</option>
                    </select>
                </div>
                <div class="setting-row">
                    <label for="timeConditions">Bot Auto Start/Stop Schedule:</label>
                    <div id="timeConditions"></div>
                    <br>
                    <button id="addCondition" class="awesome-button btn">Add Condition</button>
                    <!-- Added gap using margin-top -->
                    <br><br>
                    <button id="pauseButton" class="pause-button">Pause?</button>
                </div>
                  
                <div class="settings_tab_title">${d.ik}</div>

                <div class="setting-row">
                  <label for="storeResource">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="storeResource">
                    <span class="switch"></span>
                    </label>
                </div>

                <div class="settings_tab_title">${d.ne}</div>

                <div class="setting-row">
                  <label for="HighlightUnderworldItems">${d.v}</label>
                    <label class="toggle-switch">
                    <input type="checkbox" id="HighlightUnderworldItems">
                    <span class="switch"></span>
                    </label>
                </div>
                    
                <div class="settings_tab_title">${d.gi}</div>
                <div class="setting-row">

                      <div class="setting-row">
                        <label for="trainEnable">${d.v}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainEnable">
                          <span class="switch"></span>
                          </label>
                      </div>

                      <div class="setting-row">
                        <label for="trainPickGold">${d.jk}</label>
                          <label class="toggle-switch">
                          <input type="checkbox" id="trainPickGold">
                          <span class="switch"></span>
                          </label>
                      </div>

                          ${d.ii}
                      <div class="stat-container">




                        <table id="statTable">
                        <thead>
                            <tr>
                                <th>${d.v}</th>
                                <th>${d.Eh}</th>
                                <th>${d.Lg}</th>
                                <th>${d.Ba}</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- We'll generate these rows dynamically for maintainability -->
                        </tbody>
                    </table>
                                                                                                        

                        <div class="setting-row">
                            
                            <label for="TrainingHoldGold">${d.Y}</label>

                            <div class="switch-field3">
                            <input type="number" id="TrainingHoldGold" min="0" value="${localStorage.getItem("TrainingHoldGold")||0}">                         
                            </div>  
                  
                        </div>

                                  <span class="span-new">${d.hi}</span>        

                      </div>  
                    </div>
        
                </div>

            <div class="popup-box" id="Extra">
            <div class="settings_tab_title">${d.ob}</div>

              <div class="setting-row">
                
                    <span style="color:red"class="span-new">1 Day Trial Key : </span>
                    <span id="kydt"style="color:red"></span>
                    <br>
                    <span style="color:red"class="span-new">${d.Ne} : </span>
                    <span id="kydtexp"style="color:red"></span>
                    
                    <ul>
                    <p>
                    <b>1.1.5 Update</b>
                    <div class="scrollable-list">
                        <ul>
                        <li>Please check discord for patch notes</li>
                        </ul>
                    </div>

                </div>

                <div class="settings_tab_title">Stats</div>
                    <div class="setting-row">
                        <div id="stats">
                            <p>${d.gk} <span id="items-repaired">0</span></p>
                            <p>${d.zd} <span id="items-reset">0</span></p>
                            <p>${d.fk} <span id="gold-cycled">0</span></p>
                            <p>${d.$j} <span id="arena-attacks">0</span></p>
                            <p>${d.bk} <span id="circus-attacks">0</span></p>
                            <p>${d.dk} <span id="dungeons-attacked">0</span></p>
                            <p>${d.ek} <span id="expeditions-attacked">0</span></p>
                            <p>${d.zd} <span id="items-smelted">0</span></p>
                            <p>${d.hk} <span id="underworld-attacks">0</span></p>
                            <p>${d.ak} <span id="arena-money">0</span></p>
                            <p>${d.ck} <span id="circus-money">0</span></p>
                        </div>
                        <button class="awesome-button" id="reset-stats-button">${d.Ji}</button>
                    </div>
           

            <div class="settings_tab_title">${d.ff}</div>
            
            <div class="setting-row">
              <button class="awesome-button" id="exportBtn">${d.Oe}</button>
              <input type="file" id="importBtn" style="display: none;">
              <button class="awesome-button" id="importFileBtn">${d.gf}</button>
              <p id="importStatus"></p>
              <p>
            </div>

            <div class="settings_tab_title">${d.Qd}</div>

            <div class="setting-row">
            <span class="span-new">${d.Rd}</span>
              <br></br>
              <label for="autologinenable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="autologinenable">
                <span class="switch"></span>
              </label>
            </div>

            <div class="settings_tab_title">${d.Ig}</div>
                <div class="setting-row">
                <label for="pauseBotEnable">${d.v}</label>
                <label class="toggle-switch">
                <input type="checkbox" id="pauseBotEnable">
                <span class="switch"></span>
                </label>
            </div>
            
            <div class="setting-row">
                <label for="pauseBot">${d.Jg}</label>
                <div class="switch-field3"> 
                <input type="number" id="pauseBot" placeholder="Minutes" value="${Math.round((localStorage.getItem("pauseBot.timeOut")-Date.now())/6E4)||0}">
                </div>
                </label>
            </div>

            <div class="settings_tab_title">UI Settings</div>

                <div class="setting-row">
                    <label for="disableBG">${d.Kj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableBG">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="disableLogMenu">${d.de}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="disableLogMenu">
                        <span class="switch"></span>
                    </label>
                </div>

                <div class="setting-row">
                    <label for="MoveButtons">${d.Lj}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="MoveButtons">
                        <span class="switch"></span>
                    </label>
                </div>
                
            
    
            <div class="settings_tab_title">${d.ng}</div>
                <div class="setting-row">
                    <span class="span-new">${d.og}</span>
                    <textarea id="messageInput" rows="4" cols="50" placeholder="${d.pg}" style="width: 350px; height: 50px;"></textarea>
                    <button class="awesome-button" id="messageButton">${d.rg}</button>
                    <button class="awesome-button"id="showPlayersButton">${d.sg}</button>
                    <button class="awesome-button" id="selectAllButton">${d.qg}</button>
                    <button class="awesome-button" id="unselectAllButton">${d.tg}</button>
                    <div id="messageStatus"></div>
                    <div id="playerList" style="display: none;"></div>
                    <div id="loadingContainer"></div>
                    <br>
                    ${d.ce}
                </div>        
            </div>

                  <div class="popup-box" id="Market">
                  <div class="settings_tab_title">Market Buy</div>
        
                    <span class="span-new">${d.Yf}</span>

                    <div class="setting-row">
                      <label for="enableMarketSearch">${d.oe}
                        <label class="toggle-switch">
                        <input type="checkbox" id="enableMarketSearch">
                        <span class="switch"></span>
                      </label>
                      </label>
                    </div>

                    <div class="setting-row">
                    <label>${d.Zf}</label>
                    <span style="font-weight: normal">${d.$f}</span>
                    <input type="text" id="MarketSearchInterval" placeholder="Market Search Interval - Minutes" value="${localStorage.getItem("MarketSearchInterval")||""}">

                    </div>



                    <div class="setting-row">
                    <div class="setting-row">
                        <label for="marketOnlyFood">${d.Dg}
                        <label class="toggle-switch">
                        <input type="checkbox" id="marketOnlyFood">
                        <span class="switch"></span>
                        </label>
                        </label>
                    </div>
                      <span class="span-new">${d.Eg}</span>
                      
                      <label for="MaxTotalGold">${d.Gb} : </label><input type="number" id="MarketMaxFoodPrice" placeholder="${d.Gb}" value="${localStorage.getItem("MarketMaxFoodPrice")||""}">
                    
                      <label for="MaxPerFood">${d.Fb} : </label><input type="number" id="MarketMaxPerFoodPrice" placeholder="${d.Fb}" value="${localStorage.getItem("MarketMaxPerFoodPrice")||""}">

                      <label for="MinItemLevel">${d.Z} : </label><input type="number" id="MarketMinItemLevel" placeholder="${d.Z}" value="${localStorage.getItem("MarketMinItemLevel")||""}">
                    

                    </div>

                    <div class="setting-row">
                    <label>${d.kf}</label>
                      <input type="text" id="itemToBuy" placeholder="${d.hf}">
                    </div>

                    <div class="setting-row">
                      <input type="number" id="maxPrice" placeholder="${d.G}">
                    </div>

                    <div class="setting-row">
                    
                      <label>${d.lf}</label>
                      <select id="marketItemType">
                        <option value="WEAPON">${d.oa}</option>
                        <option value="SHIELD">${d.S}</option>
                        <option value="CHEST">${d.M}</option>
                        <option value="HELMET">${d.P}</option>
                        <option value="GLOVES">${d.O}</option>
                        <option value="SHOES">${d.N}</option>
                        <option value="RINGS">${d.na}</option>
                        <option value="AMULETS">${d.ka}</option>
                        <option value="USABLES">${d.Ia}</option></option>
                        <option value="BOOSTS">${d.rj}</option></option>
                        <option value="UPGRADES">${d.Na}</option></option>
                        <option value="RECIPES">${d.Ka}</option></option>
                        <option value="MERCENARY">${d.Ja}</option></option>
                        <option value="FORGINGGOODS">${d.nd}</option></option>
                        <option value="btools">${d.Ma}</option></option>
                        <option value="SCROLLS">${d.La}</option></option>
                      </select>

                      <label>${d.jf}</label>
                      <select id="rarity">
                        <option value="White">${d.pa}</option>
                        <option value="Green">${d.C}</option>
                        <option value="Blue">${d.B}</option>
                        <option value="Purple">${d.D}</option>
                        <option value="Orange">${d.H}</option>
                        <option value="Red">${d.R}</option>
                      </select>

                      <label>${d.Yd}</label>
                      <select id="itemsoulbound">
                        <option value="BuySoulbound">${d.Ei}</option>
                        <option value="DontBuySoulbound">${d.Bg}</option>
                      </select>
                    </div>

                    <div class="setting-row">
                      <button class="awesome-button" id="addItemBtn">${d.I}</button>
                    </div>

                    <div class="setting-row">
                      <label for="itemList">${d.nf}</label>
                      <select id="itemList" size="10"></select>
                      <button class="awesome-button" id="removeItemBtn">${d.$g}</button>
                    </div>

                    <div class="setting-row">
                      <label for="usePacks">${d.mf}
                      <label class="toggle-switch">
                        <input type="checkbox" id="usePacks">
                        <span class="switch"></span>
                        </label>
                      </label>
                    </div>

                    <div class="setting-row">
                      <label for="MarketboughtItems">${d.Wd}</label>
                      <select id="MarketboughtItems" size="5"></select>
                      <button class="awesome-button" id="MarketremoveItemBtn">${d.ae}</button>
                    </div>

                    <div class="setting-row">
                    <label for="MarketHoldGold">${d.Y}</label>
                    <input type="number" id="MarketHoldGold" min="0" value="${localStorage.getItem("MarketHoldGold")||0}">
                    </div>
                  
                    </div>   
                  </div>
                </div>
              </div>
            </div>

              `;document.getElementById("header_game").insertBefore(t,document.getElementById("header_game").children[0]);t=document.createElement("div");y=document.getElementById("wrapper_game").clientHeight;t.setAttribute("id","overlayBack");t.setAttribute("style",`height: ${y}px; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 198;`);t.addEventListener("click",kc);document.getElementsByTagName("body")[0].appendChild(t);(function(){var v=localStorage.getItem("lastActiveTab");v?(v=
document.querySelector(`.popup-tab[data-target="${v}"]`))&&Sc(v):(v=document.querySelector(".popup-tab"))&&Sc(v)})();t=localStorage.getItem("we");null!==t&&(t=(new Date(t)).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),document.getElementById("kydtexp").textContent=t,t=localStorage.getItem("showTrial"),null!==t&&(document.getElementById("kydt").textContent=t));ki();(function(){document.querySelectorAll(".setting-row").forEach(function(v){v.addEventListener("mouseenter",
function(){var C=this.getAttribute("data-tooltip");if(C&&""!==C.trim()){const E=document.createElement("div");E.className="custom-tooltip";E.innerHTML=C;document.body.appendChild(E);C=this.getBoundingClientRect();E.style.left=C.left+C.width/2-E.offsetWidth/2+"px";E.style.top=C.top-E.offsetHeight+"px";this.qm=E}});v.addEventListener("mouseleave",function(){this.qm&&(document.body.removeChild(this.qm),this.qm=null)})})})();document.querySelectorAll(".popup-tab").forEach(v=>{v.addEventListener("click",
()=>{Sc(v);localStorage.setItem("lastActiveTab",v.dataset.target)})});const A=document.querySelectorAll(".popup-tab"),z=document.querySelectorAll(".popup-box"),x=document.querySelector(`#${document.querySelector(".popup-tab.active").dataset.target}`);x.classList.add("active");z.forEach(v=>{v!==x&&(v.style.display="none")});A.forEach(v=>{v.addEventListener("click",()=>{A.forEach(C=>C.classList.remove("active"));v.classList.add("active");z.forEach(C=>{C.style.display="none"});document.querySelector(`#${v.dataset.target}`).style.display=
"block"})});$("#languageGB").click(function(){b("EN")});$("#languagePL").click(function(){b("PL")});$("#languageES").click(function(){b("ES")});$("#languageTR").click(function(){b("TR")});$("#languageFR").click(function(){b("FR")});$("#languageHG").click(function(){b("HG")});$("#languageBR").click(function(){b("BR")});$("#do_expedition_true").click(function(){c(!0)});$("#do_expedition_false").click(function(){c(!1)});$("#set_monster_id_0").click(function(){e("0")});$("#set_monster_id_1").click(function(){e("1")});
$("#set_monster_id_2").click(function(){e("2")});$("#set_monster_id_3").click(function(){e("3")});$("#do_dungeon_true").click(function(){h(!0)});$("#do_dungeon_false").click(function(){h(!1)});(t=localStorage.getItem("dungeonDifficulty"))&&g(t);$("#set_dungeon_difficulty_normal").click(function(){k("normal")});$("#set_dungeon_difficulty_advanced").click(function(){k("advanced")});$("#do_arena_true").click(function(){l(!0)});$("#do_arena_false").click(function(){l(!1)});$("#do_circus_true").click(function(){q(!0)});
$("#do_circus_false").click(function(){q(!1)});$("#do_quests_true").click(function(){m(!0)});$("#do_quests_false").click(function(){m(!1)});$("#do_combat_quests").click(function(){n("combat")});$("#do_arena_quests").click(function(){n("arena")});$("#do_circus_quests").click(function(){n("circus")});$("#do_expedition_quests").click(function(){n("expedition")});$("#do_dungeon_quests").click(function(){n("dungeon")});$("#do_items_quests").click(function(){n("items")});$("#do_event_expedition_true").click(function(){r(!0)});
$("#do_event_expedition_false").click(function(){r(!1)});$(document).ready(function(){function v(B){var H=B.split(". "),N="<ol>";H.forEach(function(Q,S){""!==Q.trim()&&(S!==H.length-1||Q.endsWith(".")||(Q+="."),N+="<li>"+Q+"</li>")});return N+="</ol>"}function C(B){const H={"guild-market-timer":"GuildMarket","smelting-timer":"Smelting","smelting-timer-nogold":"SmeltingNoGold","smelting-timer-noitem":"SmeltingNoItem","repair-timer":"Repair","auction-hold-timer":"AuctionHoldGold","arena-timer":"Arena",
"circus-turma-timer":"CircusTurma","training-timer":"Training","reset-expired-timer":"ResetExpired","store-forge-timer":"StoreForge","reset-auction-timer":"AuctionCheck","reset-search-timer":"SearchTimer","reset-guilddonate-timer":"GuildDonate","reset-guildattack-timer":"guildBattleEnable","reset-buff-timer":"BuffTimer"};return H[B]?H[B]:B.replace(/-([a-z])/g,function(N){return N[1].toUpperCase()}).replace("-timer","")}function E(){$a.forEach(B=>{const H=document.getElementById(`${B}Priority`);(B=
Xa[B])?(H.textContent=`${d.Ba}: ${B}`,H.dataset.priority=B):(H.textContent=`${d.Rb}`,H.dataset.priority="None")})}function I(){sb=$a.map(B=>{const H=document.getElementById(`${B}Count`),N=document.getElementById(`${B}Enable`);return{stat:B,count:H?parseInt(H.value):0,priority:null!==Xa[B]?Xa[B]:"None",Wm:N?N.checked:!1}});localStorage.setItem("statSettings",JSON.stringify(sb))}function K(){$a.forEach(B=>{document.getElementById(`${B}Priority`).addEventListener("click",()=>{let H=Xa[B],N=H?H+1:1;N>
$a.length&&(N=1);let Q=null;for(let S of $a)if(S!==B&&Xa[S]===N){Q=S;break}Q&&(Xa[Q]=H||null);Xa[B]=N;E();I()})});document.querySelectorAll(".stat-count").forEach(B=>{B.addEventListener("change",I)});$a.forEach(B=>{document.getElementById(`${B}Enable`).addEventListener("change",I)})}function J(B,H){JSON.parse(localStorage.getItem(H)||"[]").forEach(N=>O(N,B,H))}function O(B,H,N){const Q=document.createElement("div");Q.className="keyword-item";var S=document.createElement("span");S.textContent=B;Q.appendChild(S);
S=document.createElement("span");S.className="remove-keyword";S.textContent="X";S.addEventListener("click",function(){Q.remove();let ja=JSON.parse(localStorage.getItem(N)||"[]");const V=ja.indexOf(B);-1<V&&(ja.splice(V,1),localStorage.setItem(N,JSON.stringify(ja)))});Q.appendChild(S);H.appendChild(Q)}function U(B,H){const N=JSON.parse(localStorage.getItem(H)||"[]");N.push(B);localStorage.setItem(H,JSON.stringify(N))}function Y(B,H,N){const Q=document.createElement("li");Q.textContent=B;Q.style.padding=
"10px";Q.style.border="1px solid #ccc";Q.style.borderColor="#cea429";Q.style.borderRadius="5px";Q.style.marginBottom="5px";Q.style.display="flex";Q.style.justifyContent="space-between";const S=document.createElement("button");S.textContent="X";S.style.textAlign="center";S.addEventListener("click",()=>{Q.remove();const ja=(JSON.parse(localStorage.getItem(N))||[]).filter(V=>!(V[0]===B[0]&&V[1]===B[1]));localStorage.setItem(N,JSON.stringify(ja))});Q.appendChild(S);document.getElementById(H).appendChild(Q)}
function ia(){jb=jb.map(B=>{B.Cm=!1;B.xm=null;return B})}function da(){document.getElementById("startSearchButton").innerText="Start Search";oc=!1}function aa(){const B=document.getElementById("clothCount");var H=parseInt(B.value,10);isNaN(H)&&(H=0);--H;0>=H&&(H=0);return B.value=H}function oa(){const B=document.getElementById("itemsList");B.innerHTML="";jb.forEach((H,N)=>{const Q=document.createElement("div");Q.style.display="flex";Q.style.flexDirection="column";Q.style.border="1px solid #d2b97f";
Q.style.padding="10px";Q.style.marginBottom="10px";Q.style.borderRadius="5px";Q.style.backgroundColor="#faf2dd";var S=document.createElement("div");S.style.display="flex";S.style.justifyContent="space-between";S.style.alignItems="center";const ja=document.createElement("span");ja.innerHTML=`<strong>${H.name}</strong> (${H.qualityName}) - Level: [${H.kn}]`;ja.style.color="#5d432c";const V=document.createElement("button");V.innerText="Remove";V.style.backgroundColor="#af552e";V.style.color="white";
V.style.border="none";V.style.padding="5px 10px";V.style.cursor="pointer";V.style.borderRadius="3px";V.onclick=()=>{jb.splice(N,1);oa();la()};S.appendChild(ja);S.appendChild(V);Q.appendChild(S);H.bm&&H.nm&&(S=document.createElement("div"),S.style.marginTop="5px",S.style.fontStyle="italic",S.style.color="#7d5b3e",S.innerText=`Stat: ${H.bm.toUpperCase()} - Value: ${H.nm}`,Q.appendChild(S));B.appendChild(Q)})}function la(){localStorage.setItem("itemsToSearch",JSON.stringify(jb))}function wa(B,H){const N=
document.getElementById("foundItemsContainer");N.style.display="flex";N.style.flexWrap="wrap";N.style.justifyContent="center";N.style.alignItems="center";N.style.zp="10px";const Q=document.createElement("div");Q.className="notification-item";Q.style.border="1px solid #d2b97f";Q.style.borderRadius="4px";Q.style.padding="10px";Q.style.margin="5px";Q.style.textAlign="center";Q.style.backgroundColor="#faf2dd";Q.style.boxShadow="0 2px 4px rgba(0, 0, 0, 0.1)";Q.style.boxSizing="border-box";Q.style.flex=
"0 1 calc(20% - 10px)";Q.style.display="flex";Q.style.flexDirection="column";Q.style.alignItems="center";Q.style.transition="all 0.3s ease-in-out";const S=document.createElement("span"),ja=document.createElement("span");switch(Number(B.xm.getAttribute("data-quality"))){case 0:ja.style.color="green";break;case 1:ja.style.color="blue";break;case 2:ja.style.color="purple";break;case 3:ja.style.color="orange";break;case 4:ja.style.color="red";break;default:ja.style.color="#333"}ja.innerText=B.name;ja.style.fontWeight=
"bold";ja.style.fontSize="12px";ja.style.marginBottom="5px";S.appendChild(ja);const V=document.createElement("div");V.style.marginTop="5px";V.style.padding="10px";V.style.borderRadius="5px";V.style.display="flex";V.style.justifyContent="center";V.style.alignItems="center";V.style.transition="transform 0.3s ease-in-out";V.onmouseover=()=>{V.style.transform="scale(1.1)"};V.onmouseout=()=>{V.style.transform="scale(1)"};B=B.xm.cloneNode(!0);B.style.position="static";B.style.transform="none";B.style.margin=
"0";V.appendChild(B);B=document.createElement("a");B.href=H;B.style.textDecoration="none";B.style.cursor="pointer";B.onmouseover=()=>{ja.style.textDecoration="underline"};B.onmouseout=()=>{ja.style.textDecoration="none"};B.appendChild(S);B.appendChild(V);Q.appendChild(B);N.appendChild(Q);pc.style.display="block"}async function Ja(){var B=!1;if(!oc)return!1;const H=await Lf();var N=jb.filter(V=>!V.Cm);for(let V of N)for(const Uc of H){N=Uc.querySelectorAll("#shop .ui-draggable");for(const Ua of N){var Q=
JSON.parse(Ua.getAttribute("data-tooltip").replace(/&quot;/g,'"')),S=parseInt(yb(Ua).split("-")[0],10);N=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[5].match(/\d+/)[0],10):0;let mi=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,ni=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,oi=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[11].match(/\d+/)[0],10):0,pi=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[13].match(/\d+/)[0],
10):0;S=15==S?parseInt(Ua.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],10):0;var ja=Ua.getAttribute("data-quality");Q=Q[0][0][0];const qi=Ua.getAttribute("data-level");if(Number(qi)>=Number(V.kn)&&Q.toLowerCase().includes(V.name.toLowerCase())&&(ja>=V.quality||!ja&&"0"==V.quality)){if(V.bm&&V.nm&&"none"!==V.bm&&(ja=!1,(N={str:N,dex:mi,agi:ni,cot:oi,chr:pi,"int":S}[V.bm])&&N>=V.nm&&(ja=!0),!ja))continue;V.xm=Ua.cloneNode(!0);wa(V,Uc.Jm||Uc.querySelector("a.shopLink").href);B=V.Cm=!0}}}N=
jb.filter(V=>!V.Cm);if(0===N.length||B)return da(),!0;B=aa();Ka();if(0>=B)return da(),!1;await Ab();return Ja()}async function Ab(){var B=new URL(window.location.href);const H=B.origin;B=B.searchParams.get("sh")||"";await fetch(`${H}/game/index.php?mod=inventory&sub=2&subsub=0&sh=${B}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({bestechen:"New goods"})})}function Ka(){var B=parseInt(document.getElementById("clothCount").getAttribute("data-total"),
10);const H=parseInt(document.getElementById("clothCount").value,10);B=(B-H)/B*100;document.getElementById("progressBarInner").style.width=`${isNaN(B)?100:B}%`}function Kb(){const B=[...Vc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelectionSmelt",JSON.stringify(B))}function Wc(){const B=[...Xc].filter(H=>H.checked).map(H=>H.value);localStorage.setItem("equipmentSelection",JSON.stringify(B))}function Bb(){localStorage.setItem("timeConditions",JSON.stringify(Lb))}function Mf(B=
{}){const H=document.createElement("div");H.classList.add("condition-row");H.innerHTML=`
                    <input type="time" class="awesome-button start-time" value="${B.start||""}" required> to
                    <input type="time" class="awesome-button end-time" value="${B.end||""}" required>
                    <br>
                    <select class="bot-action">
                        <option value="start" ${"start"===B.action?"selected":""}>Start Bot</option>
                        <option value="stop" ${"stop"===B.action?"selected":""}>Stop Bot</option>
                    </select>
                    <button class="awesome-button remove-condition">Remove</button>
                `;Bb();H.querySelector(".remove-condition").addEventListener("click",()=>{Nf.removeChild(H);Lb=Lb.filter(N=>N!==B);Bb()});H.querySelector(".start-time").addEventListener("change",N=>{B.start=N.target.value;Bb()});H.querySelector(".end-time").addEventListener("change",N=>{B.end=N.target.value;Bb()});H.querySelector(".bot-action").addEventListener("change",N=>{B.action=N.target.value;Bb()});Nf.appendChild(H)}function Of(){document.getElementById("mercenarySearchOptions").style.display=
qc.checked?"block":"none"}function ri(B){document.querySelectorAll('#itemsToReset input[type="checkbox"]').forEach(H=>{H.checked=B});La()}function Yc(){localStorage.setItem("marketItems",JSON.stringify(kb));Zc.innerHTML="";Pf.innerHTML="";for(var B of Mb){var H=document.createElement("option");H.textContent=B;Pf.appendChild(H)}for(B=0;B<kb.length;B++)H=document.createElement("option"),H.value=B,H.text=kb[B].gn+" (Rarity: "+kb[B].km+", Max price: "+kb[B].maxPrice+" "+kb[B].Soulbound+")",Zc.appendChild(H)}
function Qf(B,H,N){H[B.id]&&B.classList.add("active");B.addEventListener("click",function(Q){Q.preventDefault();this.classList.contains("active")?(this.classList.remove("active"),H[this.id]=!1):(this.classList.add("active"),H[this.id]=!0);localStorage.setItem(N,JSON.stringify(H))})}function Rf(B,H,N,Q){N.forEach(S=>{S in H||(H[S]=!1)});localStorage.setItem(Q,JSON.stringify(H))}function Sf(){const B=rc.checked;si.style.display=B?"block":"none";ti.style.display=B?"block":"none"}const ui=document.getElementById("doExpedition"),
vi=document.getElementById("doDungeon"),wi=document.getElementById("doArena"),xi=document.getElementById("doCircus"),yi=document.getElementById("doQuests"),zi=document.getElementById("doEventExpedition"),Ai=document.getElementById("activateAutoBid"),Bi=document.getElementById("doKasa"),sc=document.querySelector("#healPercentage"),$c=document.querySelector("#HealClothToggle"),Tf=document.querySelector("#hellEnterHP"),Uf=document.querySelector("#HellHealHP"),ad=document.querySelector("#HealRubyToggle"),
bd=document.querySelector("#storeResource"),cd=document.querySelector("#HighlightUnderworldItems");sc.value=localStorage.getItem("healPercentage")||25;$c.checked="true"===localStorage.getItem("HealClothToggle")||!1;ad.checked="true"===localStorage.getItem("HealRubyToggle")||!1;bd.checked="true"===localStorage.getItem("storeResource")||!1;cd.checked="true"===localStorage.getItem("HighlightUnderworldItems")||!1;const Vf=document.getElementById("minimumGoldAmount");Vf.addEventListener("change",()=>{localStorage.setItem("minimumGoldAmount",
Vf.value)});const Wf="true"===localStorage.getItem("useGodPowers");document.getElementById("useGodPowers").checked=Wf;document.getElementById("godPowersSection").style.display=Wf?"block":"none";const Ci=JSON.parse(localStorage.getItem("GodPowersHell"))||[];document.querySelectorAll(".god-power-checkbox").forEach(B=>{B.checked=Ci.includes(B.value)});const Di="true"===localStorage.getItem("useWeaponBuff");document.getElementById("weaponBuff").checked=Di;const Ei=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||
[];document.querySelectorAll(".armor-checkbox").forEach(B=>{B.checked=Ei.includes(B.value)});document.getElementById("useGodPowers").addEventListener("change",function(){const B=this.checked;localStorage.setItem("useGodPowers",B);document.getElementById("godPowersSection").style.display=B?"block":"none"});document.querySelectorAll(".god-power-checkbox").forEach(B=>{B.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".god-power-checkbox:checked")).map(N=>N.value);localStorage.setItem("GodPowersHell",
JSON.stringify(H))})});document.getElementById("weaponBuff").addEventListener("change",function(){localStorage.setItem("useWeaponBuff",this.checked)});document.querySelectorAll(".armor-checkbox").forEach(B=>{B.addEventListener("change",function(){const H=Array.from(document.querySelectorAll(".armor-checkbox:checked")).map(N=>N.value);localStorage.setItem("ArmorBuffsHell",JSON.stringify(H))})});const Xf=document.getElementById("autoSmeltInfo"),Cb=document.getElementById("popupSmelt");Xf.addEventListener("mouseenter",
function(){Cb.style.display="block";const B=document.querySelector(".popup-menu").getBoundingClientRect();Cb.style.position="fixed";Cb.style.width="350px";Cb.style.left=`${B.right+10}px`;Cb.style.top=`${B.top}px`});Xf.addEventListener("mouseleave",function(){Cb.style.display="none"});var dd=document.getElementById("tabA"),ed=document.getElementById("tabB"),Yf=document.getElementById("contentA"),Zf=document.getElementById("contentB"),fd=document.getElementById("tabACircus"),gd=document.getElementById("tabBCircus"),
$f=document.getElementById("contentACircus"),ag=document.getElementById("contentBCircus");dd.addEventListener("click",function(){Yf.style.display="block";Zf.style.display="none";dd.classList.add("active");ed.classList.remove("active")});ed.addEventListener("click",function(){Zf.style.display="block";Yf.style.display="none";ed.classList.add("active");dd.classList.remove("active")});fd.addEventListener("click",function(){$f.style.display="block";ag.style.display="none";fd.classList.add("active");gd.classList.remove("active")});
gd.addEventListener("click",function(){ag.style.display="block";$f.style.display="none";gd.classList.add("active");fd.classList.remove("active")});const Fi=v(d.bc),Gi=v(d.Mb);document.querySelector(".instructions .span-new").innerHTML=Fi;document.querySelector(".instructionsReset .span-new").innerHTML=Gi;const hd=document.getElementById("announcement"),jd=localStorage.getItem("globalAnnouncement")||"Ative o bot para carregar o anuncio";jd&&""!==jd?(hd.style.display="block",hd.innerHTML=jd):hd.style.display="none";const Hi=[{id:"Health",
buffs:["Gingko","Taigaroot","Hawthorn"]},{id:"Strength",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Dexterity",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Agility",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Constitution",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Charisma",buffs:["Flask","Ampulla","Flacon","Bottle"]},{id:"Intelligence",buffs:["Flask","Ampulla","Flacon","Bottle"]}];(function(){const B=JSON.parse(localStorage.getItem("buffSelections"))||{};Hi.forEach(H=>{B[H.id]=
B[H.id]||[];H.buffs.forEach((N,Q)=>{const S=document.getElementById(`${H.id}Buff${Q+1}`);S.checked=B[H.id].includes(N);S.addEventListener("change",()=>{S.checked?B[H.id].push(N):B[H.id]=B[H.id].filter(ja=>ja!==N);localStorage.setItem("buffSelections",JSON.stringify(B))})})})})();let kd=document.getElementById("BuffsEnable");kd.checked="true"===localStorage.getItem("BuffsEnable");kd.addEventListener("change",()=>{localStorage.setItem("BuffsEnable",kd.checked)});let ld=document.getElementById("BuffUnderworldOnly");
ld.checked="true"===localStorage.getItem("BuffUnderworldOnly");ld.addEventListener("change",()=>{localStorage.setItem("BuffUnderworldOnly",ld.checked)});document.querySelectorAll(".timer-input").forEach(B=>{B.addEventListener("change",function(){var H=parseInt(this.min,10);let N=parseInt(this.value,10);N<H&&(this.value=N=H);H=JSON.parse(localStorage.getItem("Timers"))||{};const Q=C(this.id);H[Q]=N;localStorage.setItem("Timers",JSON.stringify(H))})});const $a="Strength Dexterity Agility Constitution Charisma Intelligence".split(" ");
let Xa={},sb=JSON.parse(localStorage.getItem("statSettings"))||[];$a.forEach(B=>{const H=sb.find(N=>N.stat===B);Xa[B]=H?"None"!==H.priority?parseInt(H.priority):null:null});(function(){const B=document.querySelector("#statTable tbody");B.innerHTML="";$a.forEach(H=>{const N=document.createElement("tr");var Q=document.createElement("td"),S=document.createElement("input");S.type="checkbox";S.id=`${H}Enable`;S.checked=sb.find(V=>V.stat===H)?.Wm||!1;Q.appendChild(S);N.appendChild(Q);Q=document.createElement("td");
S=document.createElement("label");S.htmlFor=`${H}$`;S.textContent=d[H];Q.appendChild(S);N.appendChild(Q);Q=document.createElement("td");S=document.createElement("input");S.type="number";S.min="0";S.id=`${H}Count`;S.value=sb.find(V=>V.stat===H)?.count||0;S.classList.add("stat-count");Q.appendChild(S);N.appendChild(Q);Q=document.createElement("td");S=document.createElement("button");S.type="button";S.id=`${H}Priority`;S.classList.add("priority-btn");S.dataset.stat=H;const ja=Xa[H];S.textContent=ja?
`${d.Ba}: ${ja}`:`${d.Rb}`;S.dataset.priority=ja||"None";Q.appendChild(S);N.appendChild(Q);B.appendChild(N)});K()})();(function(){sb=JSON.parse(localStorage.getItem("statSettings"))||[];$a.forEach(B=>{const H=sb.find(N=>N.stat===B);Xa[B]=H?"None"!==H.priority?parseInt(H.priority):null:null});E()})();Array.from(document.getElementsByClassName("stat-count")).forEach(B=>{B.addEventListener("change",()=>{I()})});document.getElementById("clear_next_event_expedition_time").addEventListener("click",function(){localStorage.setItem("eventPoints_",
16);alert("Done!")});let ab=localStorage.getItem("workbenchItem");ab=ab?JSON.parse(ab):{};ab.selectedItem&&ab.selectedItem.item?document.getElementById("currentWorkbenchItem").textContent=ab.selectedItem.item.name:document.getElementById("currentWorkbenchItem").textContent="No item";document.getElementById("clear_repair").addEventListener("click",function(){ab.selectedItem&&(ab.selectedItem={},Object.assign(ab.selectedItem,{selectedItem:!1}),localStorage.removeItem("workbenchItem"),localStorage.removeItem("activeItems"),
localStorage.removeItem("activeItemsGladiator"),localStorage.removeItem("activeItemsMercenary"),document.getElementById("currentWorkbenchItem").textContent="No item")});document.getElementById("ClearAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackList",JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearOtherAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackServerList",
JSON.stringify([]));localStorage.setItem("playerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackList",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});
document.getElementById("ClearOtherCircusAttackList").addEventListener("click",function(){localStorage.setItem("autoAttackCircusServerList",JSON.stringify([]));localStorage.setItem("circusPlayerTimeouts",JSON.stringify([]));window.location.reload()});document.getElementById("ClearCircusAvoidList").addEventListener("click",function(){localStorage.setItem("avoidAttackCircusList",JSON.stringify([]));window.location.reload()});const bg=document.getElementById("keywordAcceptInput"),Ii=document.getElementById("addKeywordAcceptBtn"),
cg=document.getElementById("keywordAcceptList"),tc=document.getElementById("underworldKeywordSection"),dg=document.getElementById("underworldKeywordInput"),Ji=document.getElementById("addUnderworldKeywordBtn"),eg=document.getElementById("underworldKeywordList");let md=document.getElementById("skipTimeQuests");md.checked="true"===localStorage.getItem("skipTimeQuests");md.addEventListener("change",()=>{localStorage.setItem("skipTimeQuests",md.checked)});let nd=document.getElementById("skipTimeCircusQuests");
nd.checked="true"===localStorage.getItem("skipTimeCircusQuests");nd.addEventListener("change",()=>{localStorage.setItem("skipTimeCircusQuests",nd.checked)});let od=document.getElementById("skipTimeOtherQuests");od.checked="true"===localStorage.getItem("skipTimeOtherQuests");od.addEventListener("change",()=>{localStorage.setItem("skipTimeOtherQuests",od.checked)});"Mercury Apollo Diana Minerva Vulcan Mars".split(" ").forEach(B=>{let H=document.getElementById(`questType${B}`);H.checked="true"===localStorage.getItem(`questType${B}`);
H.addEventListener("change",()=>{localStorage.setItem(`questType${B}`,H.checked)})});let Nb=document.getElementById("UnderworldQuests");Nb.checked="true"===localStorage.getItem("UnderworldQuests");Nb.addEventListener("change",()=>{localStorage.setItem("UnderworldQuests",Nb.checked);Nb.checked||"true"===localStorage.getItem("UnderworldQuests")?tc.style.display="block":tc.style.display="none"});Nb.checked||"true"===localStorage.getItem("UnderworldQuests")?tc.style.display="block":tc.style.display="none";
let pd=document.getElementById("acceptnotfilter");pd.checked="true"===localStorage.getItem("acceptnotfilter");pd.addEventListener("change",()=>{localStorage.setItem("acceptnotfilter",pd.checked)});const qd=document.getElementById("keywordInput"),Ki=document.getElementById("addKeywordBtn"),fg=document.getElementById("keywordList"),Li=document.getElementById("keywordGuildInput"),Mi=document.getElementById("addGuildKeywordBtn"),gg=document.getElementById("keywordGuildList");J(gg,"guildKeywords");Mi.addEventListener("click",
function(){const B=Li.value.trim();""!==B&&(O(B,gg,"guildKeywords"),U(B,"guildKeywords"),qd.value="")});J(fg,"questKeywords");J(eg,"underworldQuestKeywords");Ki.addEventListener("click",function(){const B=qd.value.trim();""!==B&&(O(B,fg,"questKeywords"),U(B,"questKeywords"),qd.value="")});J(cg,"acceptQuestKeywords");Ii.addEventListener("click",function(){const B=bg.value.trim();""!==B&&(O(B,cg,"acceptQuestKeywords"),U(B,"acceptQuestKeywords"),bg.value="")});Ji.addEventListener("click",function(){const B=
dg.value.trim();""!==B&&(O(B,eg,"underworldQuestKeywords"),U(B,"underworldQuestKeywords"),dg.value="")});let rd=document.getElementById("renewEvent");rd.checked="true"===localStorage.getItem("renewEvent");rd.addEventListener("change",()=>{localStorage.setItem("renewEvent",rd.checked)});let sd=document.getElementById("throwDice");sd.checked="true"===localStorage.getItem("throwDice");sd.addEventListener("change",()=>{localStorage.setItem("throwDice",sd.checked)});let td=document.getElementById("useCostume");
td.checked="true"===localStorage.getItem("useCostume");td.addEventListener("change",()=>{localStorage.setItem("useCostume",td.checked)});let Ob=document.getElementById("wearUnderworld"),hg=document.getElementById("costumeUnderworldWrapper");Ob.checked="true"===localStorage.getItem("wearUnderworld");hg.style.display=Ob.checked?"block":"none";Ob.addEventListener("change",()=>{localStorage.setItem("wearUnderworld",Ob.checked);hg.style.display=Ob.checked?"block":"none"});document.getElementById("costumeUnderworld").addEventListener("change",
function(){localStorage.setItem("costumeUnderworld",this.value)});const Ni=document.getElementById("costumeUnderworld"),ig=localStorage.getItem("costumeUnderworld");null!==ig&&(Ni.value=ig);const Oi=document.getElementById("costumeBasic"),jg=localStorage.getItem("costumeBasic");document.getElementById("costumeBasic").addEventListener("change",function(){localStorage.setItem("costumeBasic",this.value)});null!==jg&&(Oi.value=jg);document.getElementById("costumeDungeon").addEventListener("change",function(){localStorage.setItem("costumeDungeon",
this.value)});const Pi=document.getElementById("costumeDungeon"),kg=localStorage.getItem("costumeDungeon");null!==kg&&(Pi.value=kg);const Qi=document.getElementById("search_input"),Ri=document.getElementById("search_reset"),Si=document.getElementById("search_button");let uc=JSON.parse(localStorage.getItem("searchTerms")||"[]");uc.forEach(B=>{Y(B,"search_list","searchTerms")});Si.addEventListener("click",function(){const B=Qi.value.trim();""===B||uc.includes(B)||(uc.push(B),localStorage.setItem("searchTerms",
JSON.stringify(uc)),Y(B,"search_list","searchTerms"))});const ud=document.querySelector(".equipment-search-selection");ud.addEventListener("change",()=>{const B=Array.from(ud.querySelectorAll(".equipment-search-option:checked")).map(H=>H.value);localStorage.setItem("SearchTypes",JSON.stringify(B))});JSON.parse(localStorage.getItem("SearchTypes")||"[]").forEach(B=>{if(B=ud.querySelector(`.equipment-search-option[value="${B}"]`))B.checked=!0});let jb=JSON.parse(localStorage.getItem("itemsToSearch"))||
[];document.getElementById("addItemButton").addEventListener("click",function(){const B=document.getElementById("newItem").value,H=document.getElementById("itemQuality").value,N=document.getElementById("newItemLevel").value,Q=document.getElementById("shopitemstat").value,S=document.getElementById("statValue").value;jb.push({name:B,quality:H,kn:N,qualityName:Ti[H],bm:"none"!==Q?Q:null,nm:"none"!==Q?S:null});oa();la()});document.getElementById("startSearchButton").addEventListener("click",async function(){oc=
!0;pc.style.display="none";document.getElementById("clothCount").setAttribute("data-total",document.getElementById("clothCount").value);document.getElementById("startSearchButton").innerText="Searching...";await Ja()});document.getElementById("stopSearchButton").addEventListener("click",da);document.getElementById("shopitemstat").addEventListener("change",function(){document.getElementById("statValueRow").style.display="none"===this.value?"none":"block"});const pc=document.getElementById("skipSearchButton");
pc.addEventListener("click",async function(){const B=document.getElementById("foundItemsContainer");for(;B.firstChild;)B.removeChild(B.firstChild);ia();oc=!0;pc.style.display="none";aa();Ka();await Ab();await Ja()});let oc=!0;const Ti={0:"Green",1:"Blue",2:"Purple",3:"Orange",4:"Red"};oa();hi();const Vc=document.querySelectorAll(".equipment-option-smelt");Vc.forEach(B=>{B.addEventListener("change",Kb)});(JSON.parse(localStorage.getItem("equipmentSelectionSmelt"))||[]).forEach(B=>{const H=[...Vc].find(N=>
N.value===B);H&&(H.checked=!0)});const Xc=document.querySelectorAll(".equipment-option");Xc.forEach(B=>{B.addEventListener("change",Wc)});(JSON.parse(localStorage.getItem("equipmentSelection"))||[]).forEach(B=>{const H=[...Xc].find(N=>N.value===B);H&&(H.checked=!0)});Ri.addEventListener("click",function(){localStorage.setItem("AuctionSearch.timeOut",0);localStorage.setItem("ShopSearch.timeOut",0);location.reload()});let vd=document.getElementById("trainPickGold");vd.checked="true"===localStorage.getItem("trainPickGold");
vd.addEventListener("change",()=>{localStorage.setItem("trainPickGold",vd.checked)});let wd=document.getElementById("trainEnable");wd.checked="true"===localStorage.getItem("trainEnable");wd.addEventListener("change",()=>{localStorage.setItem("trainEnable",wd.checked)});let xd=document.getElementById("EnableArenaHell");xd.checked="true"===localStorage.getItem("EnableArenaHell");xd.addEventListener("change",()=>{localStorage.setItem("EnableArenaHell",xd.checked)});let yd=document.getElementById("dungeonAB");
yd.checked="true"===localStorage.getItem("dungeonAB");yd.addEventListener("change",()=>{localStorage.setItem("dungeonAB",yd.checked)});let zd=document.getElementById("dungeonFocusQuest");zd.checked="true"===localStorage.getItem("dungeonFocusQuest");zd.addEventListener("change",()=>{localStorage.setItem("dungeonFocusQuest",zd.checked)});(function(){const B=document.getElementById("autologinenable"),H="true"===localStorage.getItem("AutoLogin");B.checked=H;xf(H);B.addEventListener("change",function(){const N=
this.checked;localStorage.setItem("AutoLogin",N);xf(N)})})();const Nf=document.getElementById("timeConditions"),Ui=document.getElementById("addCondition");let Lb=JSON.parse(localStorage.getItem("timeConditions"))||[];Lb.forEach(Mf);Ui.addEventListener("click",()=>{const B={start:"",end:"",action:"stop"};Lb.push(B);Mf(B);Bb()});const Ad=document.getElementById("pauseButton");let Pb="true"===localStorage.getItem("botPaused");Ad.textContent=Pb?"Paused":"Pause?";Ad.addEventListener("click",function(){Pb=
!Pb;Ad.textContent=Pb?"Paused":"Pause?";localStorage.setItem("botPaused",Pb.toString())});let Bd=document.getElementById("enableArenaSimulator");Bd.checked="true"===localStorage.getItem("enableArenaSimulator");Bd.addEventListener("change",()=>{localStorage.setItem("enableArenaSimulator",Bd.checked)});let Cd=document.getElementById("enableCircusSimulator");Cd.checked="true"===localStorage.getItem("enableCircusSimulator");Cd.addEventListener("change",()=>{localStorage.setItem("enableCircusSimulator",
Cd.checked)});let Dd=document.getElementById("enableCircusWithoutHeal");Dd.checked="true"===localStorage.getItem("enableCircusWithoutHeal");Dd.addEventListener("change",()=>{localStorage.setItem("enableCircusWithoutHeal",Dd.checked)});let Ed=document.getElementById("arenaAttackGM");Ed.checked="true"===localStorage.getItem("arenaAttackGM");Ed.addEventListener("change",()=>{localStorage.setItem("arenaAttackGM",Ed.checked)});let Fd=document.getElementById("onlyArena");Fd.checked="true"===localStorage.getItem("onlyArena");
Fd.addEventListener("change",()=>{localStorage.setItem("onlyArena",Fd.checked)});let Gd=document.getElementById("onlyCircus");Gd.checked="true"===localStorage.getItem("onlyCircus");Gd.addEventListener("change",()=>{localStorage.setItem("onlyCircus",Gd.checked)});let Hd=document.getElementById("attackRandomly");Hd.checked="true"===localStorage.getItem("attackRandomly");Hd.addEventListener("change",()=>{localStorage.setItem("attackRandomly",Hd.checked)});let Id=document.getElementById("attackRandomlyCircus");
Id.checked="true"===localStorage.getItem("attackRandomlyCircus");Id.addEventListener("change",()=>{localStorage.setItem("attackRandomlyCircus",Id.checked)});let Jd=document.getElementById("circusAttackGM");Jd.checked="true"===localStorage.getItem("circusAttackGM");Jd.addEventListener("change",()=>{localStorage.setItem("circusAttackGM",Jd.checked)});let Kd=document.getElementById("auctionmercenaryenable");Kd.checked="true"===localStorage.getItem("auctionmercenaryenable");Kd.addEventListener("change",
()=>{localStorage.setItem("auctionmercenaryenable",Kd.checked)});let Ld=document.getElementById("auctionTURBO");Ld.checked="true"===localStorage.getItem("auctionTURBO");Ld.addEventListener("change",()=>{localStorage.setItem("auctionTURBO",Ld.checked)});let Md=document.getElementById("auctiongladiatorenable");Md.checked="true"===localStorage.getItem("auctiongladiatorenable");Md.addEventListener("change",()=>{localStorage.setItem("auctiongladiatorenable",Md.checked)});let Nd=document.getElementById("bidFood");
Nd.checked="true"===localStorage.getItem("bidFood");Nd.addEventListener("change",()=>{localStorage.setItem("bidFood",Nd.checked)});let Od=document.getElementById("ignorePS");Od.checked="true"===localStorage.getItem("ignorePS");Od.addEventListener("change",()=>{localStorage.setItem("ignorePS",Od.checked)});let Pd=document.getElementById("auctionminlevel");Pd.value=localStorage.getItem("auctionminlevel")||"";Pd.addEventListener("input",()=>{localStorage.setItem("auctionminlevel",Pd.value)});let Qd=
document.getElementById("AuctionCover");Qd.checked="true"===localStorage.getItem("AuctionCover");Qd.addEventListener("change",()=>{localStorage.setItem("AuctionCover",Qd.checked)});let Rd=document.getElementById("AuctionGoldCover");Rd.checked="true"===localStorage.getItem("AuctionGoldCover");Rd.addEventListener("change",()=>{localStorage.setItem("AuctionGoldCover",Rd.checked)});let Sd=document.getElementById("maximumBid");Sd.value=localStorage.getItem("maximumBid")||"";Sd.addEventListener("input",
()=>{localStorage.setItem("maximumBid",Sd.value)});let Td=document.getElementById("activateAuction2");Td.checked="true"===localStorage.getItem("activateAuction2");Td.addEventListener("change",()=>{localStorage.setItem("activateAuction2",Td.checked)});let Ud=document.getElementById("AuctionItemLevel2");Ud.value=localStorage.getItem("AuctionItemLevel2")||"";Ud.addEventListener("input",()=>{localStorage.setItem("AuctionItemLevel2",Ud.value)});let qc=document.getElementById("enableMercenarySearch"),Vd=
document.getElementById("minDexterity"),Wd=document.getElementById("minAgility"),Xd=document.getElementById("minIntelligence");qc.checked="true"===localStorage.getItem("enableMercenarySearch");Vd.value=localStorage.getItem("minDexterity")||0;Wd.value=localStorage.getItem("minAgility")||0;Xd.value=localStorage.getItem("minIntelligence")||0;Of();qc.addEventListener("change",()=>{localStorage.setItem("enableMercenarySearch",qc.checked);Of()});Vd.addEventListener("input",()=>{localStorage.setItem("minDexterity",
Vd.value)});Wd.addEventListener("input",()=>{localStorage.setItem("minAgility",Wd.value)});Xd.addEventListener("input",()=>{localStorage.setItem("minIntelligence",Xd.value)});const Yd=document.getElementById("SearchQuality"),lg=localStorage.getItem("SearchQuality");lg&&(Yd.value=lg);Yd.addEventListener("change",()=>{localStorage.setItem("SearchQuality",Yd.value)});const Zd=document.getElementById("HealPickBag"),mg=localStorage.getItem("HealPickBag");mg&&(Zd.value=mg);Zd.addEventListener("change",
()=>{localStorage.setItem("HealPickBag",Zd.value)});const $d=document.getElementById("FoodAmount"),ng=localStorage.getItem("FoodAmount");ng&&($d.value=ng);$d.addEventListener("change",()=>{localStorage.setItem("FoodAmount",$d.value)});const og=document.getElementById("questrewardvalue");og.addEventListener("change",()=>{localStorage.setItem("questrewardvalue",og.value)});const ae=document.getElementById("smeltTab"),pg=localStorage.getItem("smeltTab");pg&&(ae.value=pg);ae.addEventListener("change",
()=>{localStorage.setItem("smeltTab",ae.value)});const be=document.getElementById("repairMaxQuality"),ce=document.getElementById("repairBeforeSmeltMaxQuality"),de=document.getElementById("PartialOrFull");let vc=localStorage.getItem("repairMaxQuality"),wc=localStorage.getItem("repairBeforeSmeltMaxQuality"),xc=localStorage.getItem("PartialOrFull");vc||(vc="1",localStorage.setItem("repairMaxQuality",vc));wc||(wc="1",localStorage.setItem("RSMaxQuality",wc));xc||(xc="0",localStorage.setItem("PartialOrFull",
xc));be.value=vc;ce.value=wc;be.addEventListener("change",()=>{localStorage.setItem("repairMaxQuality",be.value)});ce.addEventListener("change",()=>{localStorage.setItem("repairBeforeSmeltMaxQuality",ce.value)});de.addEventListener("change",()=>{localStorage.setItem("PartialOrFull",de.value)});de.value=xc;var yc=document.getElementById("repairPercentage");(function(){var B=localStorage.getItem("repairPercentage");if(null!==B)for(var H=0;H<yc.options.length;H++)if(yc.options[H].text.replace("%","")===
B){yc.selectedIndex=H;break}})();yc.addEventListener("change",function(){var B=this.options[this.selectedIndex].text.replace("%","");localStorage.setItem("repairPercentage",B)});const ee=document.getElementById("bidStatus"),qg=localStorage.getItem("bidStatus");qg&&(ee.value=qg);ee.addEventListener("change",()=>{localStorage.setItem("bidStatus",ee.value)});const fe=document.getElementById("auctionMinQuality"),rg=localStorage.getItem("auctionMinQuality");rg&&(fe.value=rg);fe.addEventListener("change",
()=>{localStorage.setItem("auctionMinQuality",fe.value)});const ge=document.getElementById("storeInShopQuality"),sg=localStorage.getItem("storeInShopQuality");sg&&(ge.value=sg);ge.addEventListener("change",()=>{localStorage.setItem("storeInShopQuality",ge.value)});const La=function(B,H){let N;return function(){const Q=this,S=arguments;clearTimeout(N);N=setTimeout(()=>B.apply(Q,S),H)}}(function(){const B=document.getElementById("resetExpiredItems").checked,H=document.getElementById("resetUnderworld").checked,
N=document.getElementById("resetDays").value,Q=Array.from(document.querySelectorAll('#itemsToReset input[type="checkbox"]:checked')).map(V=>V.value),S=Array.from(document.querySelectorAll('#itemsToReset2 input[type="checkbox"]:checked')).map(V=>V.value),ja=Array.from(document.querySelectorAll('#itemsToResetGuild input[type="checkbox"]:checked')).map(V=>V.value);localStorage.setItem("resetExpiredItems",B);localStorage.setItem("resetUnderworld",H);localStorage.setItem("resetDays",N);localStorage.setItem("itemsToReset",
JSON.stringify(Q));localStorage.setItem("itemsToReset2",JSON.stringify(S));localStorage.setItem("itemsToResetGuild",JSON.stringify(ja))},250);document.getElementById("resetExpiredItems").addEventListener("change",La);document.getElementById("resetUnderworld").addEventListener("change",La);document.getElementById("resetDays").addEventListener("change",La);document.getElementById("itemsToReset").addEventListener("change",La);document.getElementById("itemsToReset2").addEventListener("change",La);document.getElementById("itemsToResetGuild").addEventListener("change",
La);document.getElementById("resetExpiredItems").addEventListener("touchend",La);document.getElementById("resetUnderworld").addEventListener("touchend",La);document.getElementById("resetDays").addEventListener("touchend",La);document.getElementById("itemsToReset").addEventListener("touchend",La);document.getElementById("itemsToReset2").addEventListener("touchend",La);document.getElementById("itemsToResetGuild").addEventListener("touchend",La);document.getElementById("selectAllItems").addEventListener("click",
function(){let B="true"!==this.dataset.checked;this.innerHTML=(this.dataset.checked=B)?'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <polyline points="20 6 9 17 4 12"></polyline>\n                    </svg>':'<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1">\n                        <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line> \n                    </svg>';
ri(B)});(function(){const B="true"===localStorage.getItem("resetExpiredItems"),H="true"===localStorage.getItem("resetUnderworld"),N=localStorage.getItem("resetDays"),Q=JSON.parse(localStorage.getItem("itemsToReset")||"[]"),S=JSON.parse(localStorage.getItem("itemsToReset2")||"[]"),ja=JSON.parse(localStorage.getItem("itemsToResetGuild")||"[]");document.getElementById("resetExpiredItems").checked=B;document.getElementById("resetUnderworld").checked=H;document.getElementById("resetDays").value=N;Q.forEach(V=>
{if(V=document.getElementById(V))V.checked=!0});S.forEach(V=>{if(V=document.getElementById(V))V.checked=!0});ja.forEach(V=>{if(V=document.getElementById(V))V.checked=!0})})();const he=document.getElementById("guildPackHour"),tg=localStorage.getItem("guildPackHour");tg&&(he.value=tg);he.addEventListener("change",()=>{localStorage.setItem("guildPackHour",he.value)});const ie=document.getElementById("filterGM"),ug=localStorage.getItem("filterGM");ug&&(ie.value=ug);ie.addEventListener("change",()=>{localStorage.setItem("filterGM",
ie.value)});const tb=document.getElementById("delaySelect"),vg=localStorage.getItem("DELAY");if(vg)for(let B=0;B<tb.options.length;B++)if(tb.options[B].text===vg){tb.value=tb.options[B].value;break}tb.addEventListener("change",()=>{localStorage.setItem("DELAY",tb.options[tb.selectedIndex].text)});const je=document.getElementById("questSpeed"),wg=localStorage.getItem("questSpeed");wg&&(je.value=wg);je.addEventListener("change",()=>{localStorage.setItem("questSpeed",je.value)});let xg=document.getElementById("itemToBuy"),
yg=document.getElementById("rarity"),zg=document.getElementById("marketItemType"),Ag=document.getElementById("itemsoulbound"),Bg=document.getElementById("maxPrice"),Vi=document.getElementById("addItemBtn"),Wi=document.getElementById("removeItemBtn"),Xi=document.getElementById("MarketremoveItemBtn"),Zc=document.getElementById("itemList"),Pf=document.getElementById("MarketboughtItems"),Mb=localStorage.getItem("MarketboughtItems");Mb?Mb=JSON.parse(Mb):Mb=[];const Cg=document.getElementById("MarketSearchInterval");
Cg.addEventListener("change",()=>{localStorage.setItem("MarketSearchInterval",Cg.value)});document.getElementById("MarketSearchInterval").addEventListener("input",function(){3>parseInt(this.value,10)&&(this.value=3)});const Dg=document.getElementById("MarketMaxPerFoodPrice");Dg.addEventListener("change",()=>{localStorage.setItem("MarketMaxPerFoodPrice",Dg.value)});const Eg=document.getElementById("MarketMaxFoodPrice");Eg.addEventListener("change",()=>{localStorage.setItem("MarketMaxFoodPrice",Eg.value)});
const Fg=document.getElementById("MarketMinItemLevel");Fg.addEventListener("change",()=>{localStorage.setItem("MarketMinItemLevel",Fg.value)});let ke=document.getElementById("marketOnlyFood");ke.checked="true"===localStorage.getItem("marketOnlyFood");ke.addEventListener("change",()=>{localStorage.setItem("marketOnlyFood",ke.checked)});let kb=JSON.parse(localStorage.getItem("marketItems"))||[];Vi.onclick=function(){kb.push({gn:xg.value||1,km:yg.value||4,maxPrice:Bg.value||4,itemType:zg.value||4,Soulbound:Ag.value||
2});xg.value="";yg.value="White";Bg.value="";zg.value="WEAPONS";Ag.value="DontBuySoulbound";Yc()};Wi.onclick=function(){kb.splice(Zc.value,1);Yc()};Xi.onclick=function(){document.getElementById("MarketboughtItems").innerHTML="";localStorage.setItem("MarketboughtItems",JSON.stringify([]))};Yc();let le=document.getElementById("enableMarketSearch");le.checked="true"===localStorage.getItem("enableMarketSearch");le.addEventListener("change",()=>{localStorage.setItem("enableMarketSearch",le.checked)});
let me=document.getElementById("usePacks");me.checked="true"===localStorage.getItem("usePacks");me.addEventListener("change",()=>{localStorage.setItem("usePacks",me.checked)});const ne=document.getElementById("scoreRange"),Gg=localStorage.getItem("scoreRange");Gg&&(ne.value=Gg);ne.addEventListener("change",()=>{localStorage.setItem("scoreRange",ne.value)});const oe=document.getElementById("scoreRangeCircus"),Hg=localStorage.getItem("scoreRangeCircus");Hg&&(oe.value=Hg);oe.addEventListener("change",
()=>{localStorage.setItem("scoreRangeCircus",oe.value)});let pe=document.getElementById("scoreboardattackenable");pe.checked="true"===localStorage.getItem("scoreboardattackenable");pe.addEventListener("change",()=>{localStorage.setItem("scoreboardattackenable",pe.checked)});let qe=document.getElementById("scoreboardcircusenable");qe.checked="true"===localStorage.getItem("scoreboardcircusenable");qe.addEventListener("change",()=>{localStorage.setItem("scoreboardcircusenable",qe.checked)});let re=document.getElementById("leagueattackenable");
re.checked="true"===localStorage.getItem("leagueattackenable");re.addEventListener("change",()=>{localStorage.setItem("leagueattackenable",re.checked)});let Qb=document.getElementById("leaguerandom");Qb.checked="true"===localStorage.getItem("leaguerandom");Qb.addEventListener("change",()=>{localStorage.setItem("leaguerandom",Qb.checked);Qb.checked&&(Rb.checked=!1,localStorage.setItem("leaguelowtohigh",!1))});let Rb=document.getElementById("leaguelowtohigh");Rb.checked="true"===localStorage.getItem("leaguelowtohigh");
Rb.addEventListener("change",()=>{localStorage.setItem("leaguelowtohigh",Rb.checked);Rb.checked&&(Qb.checked=!1,localStorage.setItem("leaguerandom",!1))});let se=document.getElementById("leaguecircusattackenable");se.checked="true"===localStorage.getItem("leaguecircusattackenable");se.addEventListener("change",()=>{localStorage.setItem("leaguecircusattackenable",se.checked)});let Sb=document.getElementById("leaguecircusrandom");Sb.checked="true"===localStorage.getItem("leaguecircusrandom");Sb.addEventListener("change",
()=>{localStorage.setItem("leaguecircusrandom",Sb.checked);Sb.checked&&(Tb.checked=!1,localStorage.setItem("leaguecircuslowtohigh",!1))});let Tb=document.getElementById("leaguecircuslowtohigh");Tb.checked="true"===localStorage.getItem("leaguecircuslowtohigh");Tb.addEventListener("change",()=>{localStorage.setItem("leaguecircuslowtohigh",Tb.checked);Tb.checked&&(Sb.checked=!1,localStorage.setItem("leaguecircusrandom",!1))});let te=document.getElementById("autoAddArena");te.checked="true"===localStorage.getItem("autoAddArena");
te.addEventListener("change",()=>{localStorage.setItem("autoAddArena",te.checked)});let ue=document.getElementById("autoAvoidArena");ue.checked="true"===localStorage.getItem("autoAvoidArena");ue.addEventListener("change",()=>{localStorage.setItem("autoAvoidArena",ue.checked)});const Ig=document.getElementById("autoAddArenaAmount");Ig.addEventListener("change",()=>{localStorage.setItem("autoAddArenaAmount",Ig.value)});const Jg=document.getElementById("ArenaSimulatorAmount");Jg.addEventListener("change",
()=>{localStorage.setItem("ArenaSimulatorAmount",Jg.value)});const Kg=document.getElementById("CircusSimulatorAmount");Kg.addEventListener("change",()=>{localStorage.setItem("CircusSimulatorAmount",Kg.value)});let ve=document.getElementById("autoAddCircus");ve.checked="true"===localStorage.getItem("autoAddCircus");ve.addEventListener("change",()=>{localStorage.setItem("autoAddCircus",ve.checked)});let we=document.getElementById("autoAvoidCircus");we.checked="true"===localStorage.getItem("autoAvoidCircus");
we.addEventListener("change",()=>{localStorage.setItem("autoAvoidCircus",we.checked)});const Lg=document.getElementById("autoAddCircusAmount");Lg.addEventListener("change",()=>{localStorage.setItem("autoAddCircusAmount",Lg.value)});let xe=document.getElementById("UnderWorldUseRuby");xe.checked="true"===localStorage.getItem("UnderWorldUseRuby");xe.addEventListener("change",()=>{localStorage.setItem("UnderWorldUseRuby",xe.checked)});let ye=document.getElementById("useSacrifice");ye.checked="true"===
localStorage.getItem("useSacrifice");ye.addEventListener("change",()=>{localStorage.setItem("useSacrifice",ye.checked)});let ze=document.getElementById("usePray");ze.checked="true"===localStorage.getItem("usePray");ze.addEventListener("change",()=>{localStorage.setItem("usePray",ze.checked)});let Ae=document.getElementById("UnderworldUseMobi");Ae.checked="true"===localStorage.getItem("UnderworldUseMobi");Ae.addEventListener("change",()=>{localStorage.setItem("UnderworldUseMobi",Ae.checked)});let Be=
document.getElementById("exitUnderworld");Be.checked="true"===localStorage.getItem("exitUnderworld");Be.addEventListener("change",()=>{localStorage.setItem("exitUnderworld",Be.checked)});let Ce=document.getElementById("autoEnterHell");Ce.checked="true"===localStorage.getItem("autoEnterHell");Ce.addEventListener("change",()=>{localStorage.setItem("autoEnterHell",Ce.checked)});let De=document.getElementById("dontEnterUnderworld");De.checked="true"===localStorage.getItem("dontEnterUnderworld");De.addEventListener("change",
()=>{localStorage.setItem("dontEnterUnderworld",De.checked)});let Ee=document.getElementById("disableLogMenu");Ee.checked="true"===localStorage.getItem("disableLogMenu");Ee.addEventListener("change",()=>{localStorage.setItem("disableLogMenu",Ee.checked)});let Fe=document.getElementById("disableBG");Fe.checked="true"===localStorage.getItem("disableBG");Fe.addEventListener("change",()=>{localStorage.setItem("disableBG",Fe.checked)});let Ge=document.getElementById("MoveButtons");Ge.checked="true"===
localStorage.getItem("MoveButtons");Ge.addEventListener("change",()=>{localStorage.setItem("MoveButtons",Ge.checked)});let He=document.getElementById("pauseBotEnable");He.checked="true"===localStorage.getItem("pauseBotEnable");He.addEventListener("change",()=>{localStorage.setItem("pauseBotEnable",He.checked)});const Mg=document.getElementById("pauseBot");Mg.addEventListener("change",()=>{Z("pauseBot",Mg.value)});let Ie=document.getElementById("storeGoldinAuction");Ie.checked="true"===localStorage.getItem("storeGoldinAuction");
Ie.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuction",Ie.checked)});const Ng=document.getElementById("storeGoldinAuctionmaxGold");Ng.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuctionmaxGold",Ng.value)});const Og=document.getElementById("storeGoldinAuctionholdGold");Og.addEventListener("change",()=>{localStorage.setItem("storeGoldinAuctionholdGold",Og.value)});const Pg=document.getElementById("TrainingHoldGold");Pg.addEventListener("change",()=>{localStorage.setItem("TrainingHoldGold",
Pg.value)});const Qg=document.getElementById("MarketHoldGold");Qg.addEventListener("change",()=>{localStorage.setItem("MarketHoldGold",Qg.value)});const Rg=document.getElementById("KasaHoldGold");Rg.addEventListener("change",()=>{localStorage.setItem("KasaHoldGold",Rg.value)});let Je=document.getElementById("guildBattleEnable");Je.checked="true"===localStorage.getItem("guildBattleEnable");Je.addEventListener("change",()=>{localStorage.setItem("guildBattleEnable",Je.checked)});let Ke=document.getElementById("guildBattleRandom");
Ke.checked="true"===localStorage.getItem("guildBattleRandom");Ke.addEventListener("change",()=>{localStorage.setItem("guildBattleRandom",Ke.checked)});let Le=document.getElementById("GuildEnable");Le.checked="true"===localStorage.getItem("GuildEnable");Le.addEventListener("change",()=>{localStorage.setItem("GuildEnable",Le.checked)});const Sg=document.getElementById("GuildDonateAmount");Sg.addEventListener("change",()=>{localStorage.setItem("GuildDonateAmount",Sg.value)});const Tg=document.getElementById("GuildDonateMore");
Tg.addEventListener("change",()=>{localStorage.setItem("GuildDonateMore",Tg.value)});const Ug=document.getElementById("GuildDonateLess");Ug.addEventListener("change",()=>{localStorage.setItem("GuildDonateLess",Ug.value)});document.getElementById("hellDifficulty").addEventListener("change",function(){localStorage.setItem("hellDifficulty",this.value)});const Yi=document.getElementById("hellDifficulty"),Vg=localStorage.getItem("hellDifficulty");null!==Vg&&(Yi.value=Vg);let Me=document.getElementById("useVillaMedici");
Me.checked="true"===localStorage.getItem("useVillaMedici");Me.addEventListener("change",()=>{localStorage.setItem("useVillaMedici",Me.checked)});let Ne=document.getElementById("useHealingPotion");Ne.checked="true"===localStorage.getItem("useHealingPotion");Ne.addEventListener("change",()=>{localStorage.setItem("useHealingPotion",Ne.checked)});const Oe=document.getElementById("repairMercenary");Oe.checked="true"===localStorage.getItem("repairMercenary");Oe.addEventListener("change",()=>{localStorage.setItem("repairMercenary",
Oe.checked)});const Pe=document.getElementById("repairGladiator");Pe.checked="true"===localStorage.getItem("repairGladiator");Pe.addEventListener("change",()=>{localStorage.setItem("repairGladiator",Pe.checked)});let Qe=document.getElementById("activateRepair");Qe.checked="true"===localStorage.getItem("activateRepair");Qe.addEventListener("change",()=>{localStorage.setItem("activateRepair",Qe.checked)});const Zi=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(B=>
{B.checked=Zi.includes(B.value)});document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(B=>{B.addEventListener("change",()=>{const H=[];document.querySelectorAll('#ignoreMaterialsList input[type="checkbox"]').forEach(N=>{N.checked&&H.push(N.value)});localStorage.setItem("ignoredMaterials",JSON.stringify(H))})});const Wg=document.querySelectorAll(".gladiator-inventory .inventory-item"),Xg=document.querySelectorAll(".mercenary-inventory .inventory-item"),Yg=JSON.parse(localStorage.getItem("activeItemsGladiator"))||
{},Zg=JSON.parse(localStorage.getItem("activeItemsMercenary"))||{};Wg.forEach(B=>{Qf(B,Yg,"activeItemsGladiator")});Xg.forEach(B=>{Qf(B,Zg,"activeItemsMercenary")});Rf(Wg,Yg,"helmet necklace weapon armor shield gloves shoes rings1 rings2".split(" "),"activeItemsGladiator");Rf(Xg,Zg,"helmetM necklaceM weaponM armorM shieldM glovesM shoesM rings1M rings2M".split(" "),"activeItemsMercenary");const $g=document.getElementById("expeditionLocation");$g.addEventListener("change",()=>{localStorage.setItem("expeditionLocation",
$g.value)});const ah=document.getElementById("dungeonLocation");ah.addEventListener("change",()=>{localStorage.setItem("dungeonLocation",ah.value)});const zc=document.getElementById("autoCollectBonuses");zc.checked="true"===localStorage.getItem("autoCollectBonuses");document.getElementById("enemySelection").style.display=zc.checked?"none":"block";zc.addEventListener("change",()=>{localStorage.setItem("autoCollectBonuses",zc.checked)});const Re=document.getElementById("skipBossToggle");Re.checked=
"true"===localStorage.getItem("skipBoss");Re.addEventListener("change",()=>{localStorage.setItem("skipBoss",Re.checked)});const Se=document.getElementById("resetIfLoseToggle");Se.checked="true"===localStorage.getItem("resetIfLose");Se.addEventListener("change",()=>{localStorage.setItem("resetIfLose",Se.checked)});const Te=document.getElementById("activateSmelt");Te.checked="true"===localStorage.getItem("EnableSmelt");Te.addEventListener("change",()=>{localStorage.setItem("EnableSmelt",Te.checked)});
const Ue=document.getElementById("EnableHellLimit"),bh=document.getElementById("hellLimit").closest(".setting-row"),ch="true"===localStorage.getItem("EnableHellLimit"),dh=localStorage.getItem("hellLimit")||5;Ue.checked=ch;document.getElementById("hellLimit").value=dh;bh.style.display=ch?"block":"none";Ue.addEventListener("change",function(){const B=Ue.checked;localStorage.setItem("EnableHellLimit",B);bh.style.display=B?"block":"none"});document.getElementById("hellLimit").addEventListener("input",
function(){const B=document.getElementById("hellLimit").value;1<=B&&200>=B?localStorage.setItem("hellLimit",B):document.getElementById("hellLimit").value=dh});const rc=document.getElementById("farmEnable"),si=document.getElementById("farmLocation").closest(".setting-row"),ti=document.getElementById("farmEnemy").closest(".setting-row"),$i="true"===localStorage.getItem("farmEnable"),eh=localStorage.getItem("farmLocation"),fh=localStorage.getItem("farmEnemy");rc.checked=$i;eh&&(document.getElementById("farmLocation").value=
eh);fh&&(document.getElementById("farmEnemy").value=fh);Sf();rc.addEventListener("change",function(){localStorage.setItem("farmEnable",rc.checked);Sf()});document.getElementById("farmLocation").addEventListener("change",function(){localStorage.setItem("farmLocation",this.value)});document.getElementById("farmEnemy").addEventListener("change",function(){localStorage.setItem("farmEnemy",this.value)});const Ve=document.getElementById("doHeal");Ve.checked="true"===localStorage.getItem("HealEnabled");
Ve.addEventListener("change",()=>{localStorage.setItem("HealEnabled",Ve.checked)});const We=document.getElementById("healShopToggle");We.checked="true"===localStorage.getItem("HealShop");We.addEventListener("change",()=>{localStorage.setItem("HealShop",We.checked)});const Xe=document.getElementById("healfrompackage");Xe.checked="true"===localStorage.getItem("HealPackage");Xe.addEventListener("change",()=>{localStorage.setItem("HealPackage",Xe.checked)});const Ye=document.getElementById("healcervisia");
Ye.checked="true"===localStorage.getItem("HealCervisia");Ye.addEventListener("change",()=>{localStorage.setItem("HealCervisia",Ye.checked)});const Ze=document.getElementById("HealEggs");Ze.checked="true"===localStorage.getItem("HealEggs");Ze.addEventListener("change",()=>{localStorage.setItem("HealEggs",Ze.checked)});const $e=document.getElementById("OilEnable");$e.checked="true"===localStorage.getItem("OilEnable");$e.addEventListener("change",()=>{localStorage.setItem("OilEnable",$e.checked)});document.getElementById("enemySelect").addEventListener("change",
function(){localStorage.setItem("selectedEnemy",this.value)});const aj=document.getElementById("enemySelect"),gh=localStorage.getItem("selectedEnemy");null!==gh&&(aj.value=gh);document.getElementById("autoCollectBonuses").addEventListener("change",function(){document.getElementById("enemySelection").style.display=this.checked?"none":"block"});ui.addEventListener("change",function(){this.checked?(c(!0),Ba=!0):(c(!1),Ba=!1);localStorage.setItem("doExpedition",Ba);u()});vi.addEventListener("change",
function(){this.checked?(h(!0),Fa=!0):(h(!1),Fa=!1);localStorage.setItem("doDungeon",Fa);u()});wi.addEventListener("change",function(){this.checked?(l(!0),Ga=!0):(l(!1),Ga=!1);localStorage.setItem("doArena",Ga);u()});document.getElementById("addAutoAttack").addEventListener("click",()=>{const B=document.getElementById("autoAttackInput").value.trim();B&&jc(B,"autoAttackList","autoAttackList")});document.getElementById("addAvoidAttack").addEventListener("click",()=>{const B=document.getElementById("avoidAttackInput").value.trim();
B&&jc(B,"avoidAttackList","avoidAttackList")});document.getElementById("addAutoCircusAttack").addEventListener("click",()=>{const B=document.getElementById("autoAttackCircusInput").value.trim();B&&jc(B,"autoAttackCircusList","autoAttackCircusList")});document.getElementById("addAvoidCircusAttack").addEventListener("click",()=>{const B=document.getElementById("avoidAttackCircusInput").value.trim();B&&jc(B,"avoidAttackCircusList","avoidAttackCircusList")});li();xi.addEventListener("change",function(){this.checked?
(q(!0),Ca=!0):(q(!1),Ca=!1);localStorage.setItem("doCircus",Ca);u()});yi.addEventListener("change",function(){this.checked?(m(!0),Oa=!0):(m(!1),Oa=!1);localStorage.setItem("doQuests",Oa);u()});Bi.addEventListener("change",function(){this.checked?(ib=!0,localStorage.setItem("doKasa",!0),ib=!0):(ib=!1,localStorage.setItem("doKasa",!1),ib=!1);localStorage.setItem("doKasa",ib);u()});Ai.addEventListener("change",function(){this.checked?(Za=!0,localStorage.setItem("AutoAuction",!0),Za=!0):(Za=!1,localStorage.setItem("AutoAuction",
!1),Za=!1);localStorage.setItem("AutoAuction",Za);u()});zi.addEventListener("change",function(){this.checked?(r(!0),Da=!0):(r(!1),Da=!1);localStorage.setItem("doEventExpedition",Da);u()});sc.addEventListener("input",()=>{let B=parseInt(sc.value,10);1>B?B=1:99<B&&(B=99);sc.value=B;localStorage.setItem("healPercentage",B)});Tf.addEventListener("input",()=>{localStorage.setItem("hellEnterHP",Tf.value)});Uf.addEventListener("input",()=>{localStorage.setItem("HellHealHP",Uf.value)});$c.addEventListener("change",
()=>{localStorage.setItem("HealClothToggle",$c.checked)});ad.addEventListener("change",()=>{localStorage.setItem("HealRubyToggle",ad.checked)});bd.addEventListener("change",()=>{localStorage.setItem("storeResource",bd.checked)});cd.addEventListener("change",()=>{localStorage.setItem("HighlightUnderworldItems",cd.checked)});const af=document.querySelectorAll(".stat-checkbox"),bj=localStorage.getItem("selectedStat");for(const B of af)B.checked=B.id===bj;for(const B of af)B.addEventListener("change",
()=>{if(B.checked){for(const H of af)H!==B&&(H.checked=!1);localStorage.setItem("selectedStat",B.id);localStorage.setItem("statID",B.getAttribute("data-skill"))}else localStorage.removeItem("selectedStat")})});$("#set_event_monster_id_0").click(function(){w("0")});$("#set_event_monster_id_1").click(function(){w("1")});$("#set_event_monster_id_2").click(function(){w("2")});$("#set_event_monster_id_3").click(function(){w("3")});u()}async function cj(){if("true"===localStorage.getItem("storeResource")){var b=
new URL(window.location.href),c=b.origin;b=b.searchParams.get("sh")||"";const e=Date.now();c=`${c}/game/ajax.php?mod=forge&submod=storageIn`;const h=new FormData;h.append("inventory","1");h.append("packages","1");h.append("sell","1");h.append("a",e);h.append("sh",b);b=JSON.parse(localStorage.getItem("Timers"));Z("storeForgeResources",b.StoreForge||60);try{(await fetch(c,{method:"POST",body:h})).ok?D(`${d.Af}`):window.location.reload()}catch(k){window.location.reload()}}}async function dj(){var b=
new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=JSON.parse(localStorage.getItem("statSettings"))||[];const h=JSON.parse(localStorage.getItem("Timers"))||{},k="true"===localStorage.getItem("trainPickGold"),g={Strength:1,Dexterity:2,Agility:3,Constitution:4,Charisma:5,Intelligence:6};b.forEach(m=>{m.mm=g[m.stat]});b.sort((m,n)=>"None"===m.priority?1:"None"===n.priority?-1:parseInt(m.priority,10)-parseInt(n.priority,10));c=await (await fetch(`${c}/game/index.php?mod=training&sh=${e}`)).text();
const l=[];(new DOMParser).parseFromString(c,"text/html").querySelectorAll("#training_box .training_inner").forEach((m,n)=>{n+=1;var r=m.nextElementSibling?.querySelector(".training_link .training_button");r=r?r.getAttribute("href"):null;(m=(m=(m=m.nextElementSibling?.querySelector(".training_costs"))?m.textContent.trim():null)?parseInt(m.replace(/[^\d]/g,""),10):null)&&r?l.push({mm:n,an:m,Bn:r}):l.push({mm:n,an:m,Bn:r})});for(const m of b){c=m.stat;const n=m.mm;var q=m.priority;if(1>Number(m.count)||
"None"===q)continue;q=l.find(u=>u.mm===n);if(!q){D(`No training available for ${c}`);continue}const r=q.an;q=q.Bn;const w=parseInt(localStorage.getItem("TrainingHoldGold"),10)||0;if(ba.gold>=r+w){await fetch(q);--m.count;m.count=Math.max(0,m.count);localStorage.setItem("statSettings",JSON.stringify(b));D(`Trained ${c} for ${r} gold`);Z("Training",h.Training||2);return}if(k){q=await jQuery.get(G({mod:"packages",f:14,fq:-1,qry:"",page:1,sh:e}));let u=0,t=null;jQuery(q).find(".packageItem").each(function(y,
A){y=parseInt(jQuery(A).find(".ui-draggable").attr("data-price-gold"),10);if(y>=r+w)return u=y,t=jQuery(A),!1});if(0<u&&t)try{await mc(1,1,async(y,A)=>{const z=t.find('input[name="packages[]"]').val(),x=t.find(".ui-draggable").attr("data-position-x"),v=t.find(".ui-draggable").attr("data-position-y");await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+z,fromX:x,fromY:v,to:A,toX:y.x+1,toY:y.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:e}));D(`Moved ${u} gold to inventory for training`);ba.gold+=
u;localStorage.setItem("Training",0);window.location.reload()})}catch(y){D(`Error moving gold: ${y.message}`)}else D(`${d.Ad}: ${c}`)}else D(`${d.Ad}`)}Z("Training",h.Training||2)}function ej(){const b=JSON.parse(localStorage.getItem("statSettings"));for(let c=0;c<b.length;c++)if("0"!==b[c].count||b[c].Wm)return!0;return!1}function fj(){var b=new URL(window.location.href),c=localStorage.getItem("scoreboardattackenable"),e=localStorage.getItem("scoreboardcircusenable");if(document.querySelector(".reportWin")){var h=
document.querySelector(".report_reward");h&&(h=h.querySelector('img[src*="71e68d38f81ee6f96a618f33c672e0.gif"]'))&&(h=h.previousSibling)&&h.nodeType===Node.TEXT_NODE&&(h=h.textContent.trim().match(/(\d+(?:\.\d+)?)/))&&(h=parseFloat(h[1]),b.href.includes("&t=2")?P("arenaMoney",h):b.href.includes("&t=3")&&P("circusMoney",h))}if(b.href.includes("submod=showCombatReport")&&b.href.includes("&t=1"))(c=document.getElementById("reportHeader"))&&(c.classList.contains("reportWin")||"true"!==sessionStorage.getItem("autoGoActive")?
localStorage.setItem("loose","false"):localStorage.setItem("loose","true"));else if(b.href.includes("submod=showCombatReport")){let l=document.querySelector("p > a + img");var k=document.querySelector("#defenderAvatar11 .playername_achievement");null===k&&(k=document.querySelector("#defenderAvatar11 .playername.ellipsis "));(h=document.getElementById("reportHeader"))&&!h.classList.contains("reportWin")&&(localStorage.setItem("nextQuestTime.timeOut",0),localStorage.setItem("nextQuestTime",0));h=0;
if(k&&(k=k.innerText.trim(),!k.includes("#"))){try{var g=l.previousSibling.nodeValue.trim();g=g.split(" ").pop();g=g.replace(".","");g=g.replace(",",".");h=parseFloat(g)}catch(q){}b.href.includes("&t=2")?(e=document.getElementById("reportHeader").classList.contains("reportWin"),b=JSON.parse(localStorage.getItem("tempOpponentDetails")),g=Ef.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidArena")||e||lb("avoidAttackList",k),"true"===localStorage.getItem("autoAddArena")&&Number(h)>=Number(localStorage.getItem("autoAddArenaAmount"))&&
b&&b.serverId&&(g===b.serverId?(lb("autoAttackList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===c&&k!=b.playerName?lb("autoAttackList",k):g!==b.serverId&&lb("autoAttackServerList",b))):b.href.includes("&t=3")&&(c=document.getElementById("reportHeader").classList.contains("reportWin"),b=JSON.parse(localStorage.getItem("tempOpponentDetails")),g=Ef.split("-")[0].slice(1),"true"!==localStorage.getItem("autoAvoidCircus")||c||lb("avoidAttackCircusList",k),"true"===localStorage.getItem("autoAddCircus")&&
h>=Number(localStorage.getItem("autoAddCircusAmount"))&&b&&b.serverId&&(g===b.serverId?(lb("autoAttackCircusList",b.playerName),localStorage.removeItem("tempOpponentDetails")):"true"===e&&k!=b.playerName?lb("autoAttackCircusList",k):g!==b.serverId&&lb("autoAttackCircusServerList",b)))}}}function lb(b,c){let e=JSON.parse(localStorage.getItem(b))||[];if("object"===typeof c&&null!==c){let h=c.playerName;e.some(k=>k.playerName===h&&k.serverId===c.serverId)||e.push(c)}else"string"===typeof c&&(e.includes(c)||
e.push(c));localStorage.setItem(b,JSON.stringify(e))}async function hh(b){var c=new URL(window.location.href),e=c.origin,h=c.searchParams;c=localStorage.getItem("AuctionItemLevel2")||"";const k=h.get("itemType")||"",g=localStorage.getItem("SearchQuality")||"";h=h.get("sh")||"";e=new URL(`${e}/game/index.php?mod=auction&qry=&itemLevel=${c}&itemType=${k}&itemQuality=${g}&sh=${h}`);e.searchParams.set("mod","auction");e.searchParams.set("itemLevel",c);e.searchParams.set("itemType",k);e.searchParams.set("itemQuality",
g);e.searchParams.set("sh",h);b&&e.searchParams.set("ttype",b);b=await (await fetch(e.href)).text();return(new DOMParser).parseFromString(b,"text/html")}async function Lf(){var b=new URL(window.location.href);const c=b.origin,e=b.searchParams.get("sh")||"";b=Array.from({length:5},(k,g)=>[new URL(`${c}/game/index.php?mod=inventory&sub=${g+1}&subsub=0&sh=${e}`),new URL(`${c}/game/index.php?mod=inventory&sub=${g+1}&subsub=1&sh=${e}`)]).flat();const h=async k=>{var g=await (await fetch(k.href)).text();
g=(new DOMParser).parseFromString(g,"text/html");g.Jm=k.href;return g};return await Promise.all(b.map(k=>h(k)))}function bf(b){return JSON.parse(b.replace(/&quot;/g,'"'))[0][0][0]}async function gj(b){b=(new TextEncoder).encode(b.toString());b=await crypto.subtle.digest("SHA-256",b);return Array.from(new Uint8Array(b)).map(c=>c.toString(16).padStart(2,"0")).join("")}function hb(){(function(b){const c=setInterval(()=>{const e=document.getElementById("mainmenu");e&&(clearInterval(c),b(e))},500)})(b=>
{if(!document.querySelector(".customButtonm")){var c=document.createElement("button");c.className="customButtonm";c.innerHTML='\n            <style>\n            .customButtonm {\n                vertical-align: middle;\n                width: 179px;\n                height: 50px;\n                background-image: linear-gradient(135deg, #f29b20 0%, #b18026 100%);\n                border: 2px solid #000;\n                color: white;\n                text-align: center;\n                text-decoration: none;\n                border-radius: 5px;\n                display: inline-block;\n                font-size: 16px;\n                margin: 4px auto;\n                cursor: pointer;\n                box-shadow: 5px 2px 5px rgba(0, 0, 0, 0.3), inset 0 1px 1px rgba(255, 255, 255, 0.4), inset 0 -1px 1px rgba(0, 0, 0, 0.3);\n                padding: 18px 34px;\n                transition-duration: 0.4s;\n            }\n        \n            .customButtonm span {\n                top: 50%;\n                position: relative;\n                transform: translateY(-50%);\n                display: block;\n                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);\n            }\n            </style>\n\n            <span class="span-new">License expired or Server Error. Check Discord</span>\n\n        ';
b.insertBefore(c,b.children[0]);If(45E3)}});return!1}async function hj(b,c,e){function h(k){const g=[];for(let l=0;l<k.length;l+=2)g.push(parseInt(k.substr(l,2),16));return new Uint8Array(g)}try{if(!e)return!1;const [k,g]=e.split(":"),l=h(k),q=h(g);if(b!==va)return!1;const m=await window.crypto.subtle.importKey(String.fromCharCode(114,97,119),h("46d9ef519c1474cf8699ba24ab2a726a"),{name:String.fromCharCode(65,69,83)+"-CBC"},!1,[String.fromCharCode(100,101,99,114,121,112,116)]),n=await window.crypto.subtle.decrypt({name:String.fromCharCode(65,
69,83)+"-CBC",iv:l},m,q),r=(new TextDecoder).decode(new Uint8Array(n)),w=new Date(r);w.setHours(0,0,0,0);if(!0!==c)return!1;const u=new Date,t=new Date(u.setMonth(u.getMonth()+13));return w>t||r<u?!1:!0}catch{throw hb(),Error("supportDev");}}function Ac(b){return 36E5*Number(b.split(":")[0])+6E4*Number(b.split(":")[1])+1E3*Number(b.split(":")[2])}function ij(){function b(g,l){ub?alert("A repair process is already running."):(k.tn=l,jQuery(".gladbot-worbench-button").addClass("disabled"),k.u(),k.sn=
[],k.queue=0,jQuery(document.body).addClass("workbench-cursor"),jQuery(document.body).on("contextmenu",function(q){q.preventDefault();jQuery(document.body).removeClass("workbench-cursor");jQuery(document.body).off("contextmenu")}),jQuery("#inv .ui-draggable, #char .ui-draggable").mouseup(async q=>{q=q.target;var m=q.className.match(/item-i-(\d+)-\d+/)[1],n=document.querySelector(".charmercsel.active").getAttribute("onclick").toString().match(/doll=(\d+)/),r=k.freeSlots.shift()["forge_slots.slot"];
n=n[1];r={item:{type:m,name:ac(q),quality:wb(q),slot:r,container:q.getAttribute("data-container-number"),doll:n},spot:{bag:q.getAttribute("data-container-number"),x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")}};localStorage.setItem("workbench_itemList1",JSON.stringify(r));if(jQuery(q).parents("#char").length)if(ub)alert("A repair process is already running.");else{if(m=document.querySelector("#inventory_nav .awesome-tabs.current"))m=m.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",
m);var {spot:w,bag:u}=await mc(2,3);k.qa={bag:u,x:w.x+1,y:w.y+1};k.yn(q);k.Im(q,0,n);ub=!0}else if(jQuery(q).parents("#inv").length){if(n=document.querySelector("#inventory_nav .awesome-tabs.current"))n=n.getAttribute("data-bag-number"),localStorage.setItem("workbench_itemBag",n);k.qa={bag:q.getAttribute("data-container-number"),x:q.getAttribute("data-position-x"),y:q.getAttribute("data-position-y")};ub?alert("A repair process is already running."):(k.yn(q),q=q.getAttribute("data-item-id"),k.ij(q),
ub=!0)}else k.queue++,k.Go(q),k.Nm(m)}))}function c(g,l,q){l=jQuery("<button>").html(l).addClass(q);jQuery(g).append(l);return l}async function e(){try{const g=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});k.slots=JSON.parse(g).slots;k.spaces=k.slots.filter(l=>"closed"===l["forge_slots.state"]).length;k.freeSlots=k.slots.filter(l=>"closed"===l["forge_slots.state"])}catch(g){}}async function h(){try{const g=W("sh"),l=document.querySelectorAll("#inv .ui-draggable"),
q=[512,256,2,8,4,1,1024,48];let m=5;bb("Sending items to packages...");await e();if(0<k.spaces){for(let n of k.slots)if("closed"===n["forge_slots.state"]){m=n["forge_slots.slot"];break}for(let n of l){const r=parseInt(n.getAttribute("data-content-type"),10);if(q.includes(r)){const w=n.getAttribute("data-item-id"),u=ac(n),t=parseInt(n.getAttribute("data-amount"),10)||1,y={mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:m,iid:w,amount:t,a:Date.now(),sh:g};await jQuery.post(T({}),y);const A=
{mod:"forge",submod:"rent",mode:"workbench",slot:m,rent:2,item:w,a:Date.now(),sh:g};await jQuery.post(T({}),A);const z={mod:"forge",submod:"cancel",mode:"workbench",slot:m,a:Date.now(),sh:g};await jQuery.post(T({}),z);bb(`Item name : ${u} has been sent to the packages.`);await new Promise(x=>setTimeout(x,500))}}window.location.reload()}else bb("No available slots in the workbench.")}catch(g){}}const k={tn:"full",async start(){let {itemList1:g,itemList2:l,repairArena:q,repairTurma:m}=ua,n=ua.selectedItem;
n?this.u(()=>{switch(n.status){case "toWorkbench":k.ij(n.iid);break;case "toFillGoods":k.dc(n.slot);break;case "toPackage":k.Zc(n.slot);break;case "toBag":k.Ga();break;case "toInv":k.Zl()}}):q&&0<g.length?"mod=overview&doll=1"!=rf?Dh("mod=overview&doll=1"):this.u(()=>{0<k.spaces&&this.jm(ua.itemList1)}):m&&0<l.length&&("mod=overview&doll=2"!=rf?Dh("mod=overview&doll=2"):this.u(()=>{0<k.spaces&&this.jm(ua.itemList2)}))},u(g=!1){jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",
a:(new Date).getTime(),sh:W("sh")},l=>{k.slots=JSON.parse(l).slots;k.spaces=0;k.freeSlots=[];for(let q of k.slots)"closed"==q["forge_slots.state"]&&(k.spaces++,k.freeSlots.push(q));g&&g()})},jm(g){let l=g.shift();mc(l.hn,l.jn,(q,m)=>{jQuery.post(T({mod:"inventory",submod:"move",from:l.container,fromX:1,fromY:1,to:m,toX:q.x+1,toY:q.y+1,amount:1,doll:l.doll}),{a:(new Date).getTime(),sh:W("sh")},n=>{let r={item:l,iid:JSON.parse(n).to.data.itemId,status:"toWorkbench",spot:q,bag:m};localStorage.setItem("workbench_selectedItem",
JSON.stringify(r));this.ij(JSON.parse(n).to.data.itemId)})})},async Im(g,l=0,q){var m=[512,513,514,515];if(!(l>=m.length)){m=m[l];var n=document.getElementById("inv");if(n=of(n))try{const w=await jQuery.post(T({mod:"inventory",submod:"move",from:g.getAttribute("data-container-number"),fromX:1,fromY:1,to:m,toX:n.x+1,toY:n.y+1,amount:1,doll:q}),{a:(new Date).getTime(),sh:W("sh")}),u=JSON.parse(w);if(u.error)this.Im(g,l+1,q);else{var r={item:g,iid:u.to.data.itemId,status:"toWorkbench",spot:n,bag:m};
localStorage.setItem("workbench_selectedItem",JSON.stringify(r));localStorage.setItem("workbench_itemBag",JSON.stringify(r.bag));await this.ij(u.to.data.itemId)}}catch(w){}else this.Im(g,l+1)}},async ij(g){jj();D(`${d.yb}`);let l=5;for(let q of k.slots)"closed"==q["forge_slots.state"]&&(l=q["forge_slots.slot"]);jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:l,iid:g,amount:1,a:(new Date).getTime(),sh:W("sh")},q=>{k.needed=JSON.parse(q).slots[l].formula.needed;Fh().gold>
JSON.parse(q).slots[l].formula.rent[2]?jQuery.post(T({}),{mod:"forge",submod:"rent",mode:"workbench",slot:l,rent:2,item:g,a:(new Date).getTime(),sh:W("sh")},()=>{"full"==k.tn?(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:l,status:"toFillGoods"})),k.dc(l)):(localStorage.setItem("workbench_selectedItem",JSON.stringify({slot:l,status:"toFillPartial"})),k.Wi(l))}):bb("Not enough gold to rent the workbench")})},dc(g,l=-1,q=!0){D(`${d.Kf}`,l);jQuery.post(T({}),{mod:"forge",submod:"storageToWarehouse",
mode:"workbench",slot:g,quality:l,a:(new Date).getTime(),sh:W("sh")},()=>{l<Number(localStorage.getItem("repairMaxQuality"))?k.dc(g,++l,q):jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:g,a:(new Date).getTime(),sh:W("sh")},()=>{q?(localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"})),k.u(()=>{k.Zc(g)})):(k.queue--,0==k.queue&&window.location.reload())})})},Zc(g){let l=1E3*k.slots[g].formula.duration||1E4;D(`${d.Xf}`,l);1==k.cancel?this.u(()=>{setTimeout(()=>
{jQuery.post(T({}),{mod:"forge",submod:"cancel",mode:"workbench",slot:g,a:(new Date).getTime(),sh:W("sh")},q=>{if("document.location.href=document.location.href;"==q)return window.location.reload();localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));k.Ga()})},l)}):this.u(()=>{setTimeout(()=>{jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:g,a:(new Date).getTime(),sh:W("sh")},q=>{if("document.location.href=document.location.href;"==q)return window.location.reload();
localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toBag"}));k.Ga()})},l)})},async Ga(g=1){var l=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");({item:l}=l);let q=!1;var m=new URL(window.location.href),n=m.origin;m=m.searchParams.get("sh")||"";n=new URL(`${n}/game/index.php?mod=packages&qry=&f=${l.type}&page=${g}&sh=${m}`);n.searchParams.set("mod","packages");n.searchParams.set("f",l.type);n.searchParams.set("page",g);n.searchParams.set("sh",
m);n=await (await fetch(n.href)).text();n=(new DOMParser).parseFromString(n,"text/html");var r=n.querySelector(".ui-draggable");m=xb(r);wb(r);r=ac(r);l.name==r&&l.type==m&&(q=!0,jQuery.post(T({mod:"inventory",submod:"move",from:n.querySelector("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:k.qa.bag,toX:k.qa.x,toY:k.qa.y,amount:1}),{a:(new Date).getTime(),sh:W("sh")},()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));k.Zl()}));
q||this.Ga(++g)},Zl(){JSON.parse(localStorage.getItem("workbench_selectedItem"));var g=JSON.parse(localStorage.getItem("workbench_itemList1"));localStorage.getItem("workbench_itemBag");({item:g}=g);jQuery.post(T({mod:"inventory",submod:"move",from:k.qa.bag,fromX:k.qa.x,fromY:k.qa.y,to:g.container,toX:1,toY:1,amount:1,doll:g.doll}),{a:(new Date).getTime(),sh:W("sh")},()=>{localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toInv"}));D(`${d.Nf}`);ub=!1;window.location.reload()})},
pn(g){g=jQuery(g);g=jQuery("<div>").addClass("gbot-overlay").width(g.width()).height(g.height()).offset(g.offset()).append(jQuery('<div class="gbot-spinner"></div>'));jQuery(document.body).append(g)},rm(g,l,q){l=jQuery("<button>").html(l).addClass(q);jQuery(g).append(l);return l},Xp(){let g=0;for(let l of k.slots)"finished-succeeded"==l["forge_slots.state"]&&(g++,jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:l["forge_slots.slot"],a:(new Date).getTime(),sh:W("sh")},q=>{g--;
if("document.location.href=document.location.href;"==q||0==g)return window.location.reload()}))},Go(g){cc(g)&&(k.pn(g),k.sn.push(g))},yn(g){cc(g)&&k.pn(g)},Nm(g,l,q){let m=k.freeSlots.shift()["forge_slots.slot"],n=k.sn.shift(),r=null!==l?l:n.getAttribute("data-item-id"),w=null!==q?q:{bag:n.getAttribute("data-container-number"),x:n.getAttribute("data-position-x"),y:n.getAttribute("data-position-y")};jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:m,iid:r,amount:1,
a:(new Date).getTime(),sh:W("sh")},u=>{let t=JSON.parse(u).slots[m].formula.needed;Fh().gold>JSON.parse(u).slots[m].formula.rent[2]&&jQuery.post(T({}),{mod:"forge",submod:"rent",mode:"workbench",slot:m,rent:2,item:r,a:(new Date).getTime(),sh:W("sh")},()=>{"full"==g?k.dc(m,w,!0):"partial"==g&&k.Wi(m,w,t)})})},Wi(g,l,q){let m=[];q=k.needed;for(let n in q)0<q[n].amount&&m.push(n-18E3);k.Bl(m,(n,r)=>{n&&r?k.Cl(l,n,r,w=>{w||console.warn("pickMaterialFromPack did not return an iid. Skipping material picking.");
jQuery.post(T({}),{mod:"forge",submod:"toWarehouse",mode:"workbench",slot:g,iid:w||"defaultIid",amount:1,a:(new Date).getTime(),sh:W("sh")},()=>{jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:g,a:(new Date).getTime(),sh:W("sh")},()=>{k.queue--;localStorage.setItem("workbench_selectedItem",JSON.stringify({status:"toPackage"}));k.u(()=>{k.Zc(g)});0==k.queue&&window.location.reload()})})}):(k.cancel=!0,k.u(()=>{k.Zc(g)}))})},Bl(g,l=!1,q=0,m=-1){if(q==g.length)if(1>m)q=0,m++;else return l&&
l(null,null);jQuery.post(T({mod:"forge",submod:"storageOut"}),{type:g[q],quality:m,amount:1,a:(new Date).getTime(),sh:W("sh")}).done(()=>l&&l(g[q],m)).fail(()=>k.Bl(g,l,++q,m))},Cl(g,l,q,m=!1,n=1){let r=!1;jQuery.get(G({mod:"packages",f:18,fq:q,qry:"",page:1,sh:W("sh")}),w=>{jQuery(w).find(".packageItem").each((u,t)=>{var y=jQuery(t).find(".ui-draggable");u=y.context.querySelector("input").getAttribute("value");t=yb(y[0]).split("-")[1];y=wb(y[0]);l==t&&q==y&&(r=!0,jQuery.post(T({mod:"inventory",submod:"move",
from:"-"+u,fromX:1,fromY:1,to:k.qa.bag,toX:k.qa.x,toY:k.qa.y,amount:1}),{a:(new Date).getTime(),sh:W("sh")},A=>{m&&m(JSON.parse(A).to.data.itemId)}))});r||k.Cl(g,l,q,m,++n)})}};jQuery("#inv").after('\n              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n    \n                <fieldset id="gladbot-workbench" style="\n                  padding: 10px;\n                  margin: 10px 20px;\n                  text-align: center;\n                  display: flex;\n                  flex-direction: row;\n                  flex-wrap: wrap;\n                  align-items: center;\n                  justify-content: space-around;\n                  border: 2px solid darkred;\n                  border-radius: 8px;\n                  width: 235px;">\n                  <legend style="\n                    padding: 0 10px;\n                    color: darkred;\n                    font-weight: bold;">GLDbot Workbench Area</legend>\n                    <span class="span-new">Make sure last workbench slot is available, and make sure there\'s 3x3 space available. Repair only works for the equipments on the character. If you dont see the inventory, install Crazy-Addon.</span>\n                </fieldset>');
c("#gladbot-workbench",'<i class="fa fa-wrench"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for full repair. You can only repair one item at a time.").mouseup(g=>{b(g,"full")});c("#gladbot-workbench",'<i class="fa fa-hammer"></i>',"gladbot-button gladbot-worbench-button-full gladbot-stylish-button").attr("title","Use this for partial repair. You can only repair one item at a time.").mouseup(g=>{b(g,"partial")});c("#gladbot-workbench",'<i class="fa fa-undo"></i>',
"gladbot-button gladbot-worbench-button-reset gladbot-stylish-button").attr("title","If an item is stuck and not repairing, click this button to reset.").mouseup(()=>{ub=!1});c("#gladbot-workbench","Send items in the current inventory to packages","gladbot-button gladbot-inventory-send-button gladbot-stylish-button").attr("title","Click this button to send items from the current inventory to packages.").mouseup(async()=>{await h()})}function bb(b){const c=document.createElement("div");c.className=
"notification-popup";c.innerText=b;c.style.position="fixed";c.style.bottom="20px";c.style.right="20px";c.style.padding="10px 20px";c.style.backgroundColor="rgba(0, 0, 0, 0.8)";c.style.color="white";c.style.borderRadius="5px";c.style.fontSize="14px";c.style.zIndex="9999";document.body.appendChild(c);setTimeout(()=>{c.remove()},3E3)}function ih(b,c,e,h,k,g){const l=document.createElement("span");l.className=c;l.innerHTML=b;l.title=g;l.style.cursor=e;l.style.fontSize=h;l.style.top="70px";l.style.position=
"absolute";l.style.right=k;return l}function jh(b,c){try{var e=JSON.parse(b.replace(/&quot;/g,'"'))}catch(l){return{}}b=e[0]?e[0][0]:null;e=b[0];e="string"!==typeof e?"":e.split(" ")[0];const h=ec(b[0]),k=c.getAttribute("data-quality"),g=c.getAttribute("data-content-type");c=c.getAttribute("data-level");return{itemName:b,dn:e,en:h,itemColor:{"-1":"white",0:"green",1:"blue",2:"purple",3:"orange",4:"red"}[k]||"white",itemType:g,itemLevel:c}}async function jj(){const b=G({mod:"packages",submod:"sort",
page:"1",sh:W("sh")});return await jQuery.post(b,{packageSorting:"in_desc"})}async function kj(){var b=localStorage.getItem("PackageSort")||"in_desc",c=await ha.gm();let e=[];var h=Math.min(10,c);if("del_asc"===b||"in_asc"===b)for(c=1;c<=h;c++)e.push(c);else for(b=c;b>c-h;b--)e.push(b);h=[];for(const k of e)try{const g=await jQuery.get(G({mod:"packages",f:"0",fq:"-1",qry:"",page:k.toString(),sh:W("sh")}));h.push(g)}catch(g){D(`Error fetching pages ${k}: ${g.message}`)}return h.flat()}async function lj(b,
c){if("mod=guildMarket"!=rf)Dh("mod=guildMarket");else{D(`${d.tf}`);var e={TOOLS:["2097152","1048576","8388608","4194304"],WEAPONS:["2"],SHIELD:["4"],CHEST:["8"],HELMET:["1"],GLOVES:["256"],SHOES:["512"],RINGS:["48"],AMULETS:["1024"],USABLES:["4096","32768"],FOOD:["64"],UPGRADES:["4096"],RECIPES:["8192"],MERCENARY:["16384"],SCROLLS:["64"],REINFORCEMENTS:["4096"]},h=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]},k="true"===localStorage.getItem("resetUnderworld"),g=(await kj()).map(t=>
jQuery(t).find(".packageItem").toArray()).flat();b=24*b;var l=!1;for(const t of g){g=t.querySelector("span[data-ticker-type]");if(!g)continue;g=g.getAttribute("data-ticker-time-left");if(!g)continue;g=g/1E3/60/60;var q=t.querySelector("div[data-content-type]");const y=q?q.getAttribute("data-content-type"):null;q=(q=t.querySelector(".ui-draggable"))?q.getAttribute("data-basis"):null;if(("64"!==y||!q||c.includes("SCROLLS")&&q.startsWith("20")||c.includes("FOOD")&&q.startsWith("7")||c.includes("REINFORCEMENTS")&&
q.startsWith("11"))&&g<=b&&(c.some(A=>e[A].includes(y))||k)){q=t.querySelector("div[data-container-number]");var m=void 0,n=void 0;g=(n=t.querySelector("div[data-amount]"))?n.getAttribute("data-amount"):null;var r=n?n.getAttribute("data-quality"):null;k&&(m=n?n.getAttribute("data-basis"):null,n=n?n.getAttribute("data-hash"):null,m=Zb(m,n));if(!k||m)if(!(null!==r&&0<h.colors.length)||h.colors.includes(r)){q=q?q.getAttribute("data-container-number"):null;r=t.querySelector("div[data-measurement-x]").getAttribute("data-measurement-x");
n=t.querySelector("div[data-measurement-y]").getAttribute("data-measurement-y");l=t.querySelector("div[data-tooltip]").getAttribute("data-tooltip");var w=bf(l);l=!0;await mj(t,q,w,g,r,n);g=W("sh");g=`${window.location.origin}/game/index.php?mod=guildMarket&fl=0&fq=-1&f=0&qry=&seller=&s=p&p=1&&sh=${g}`;q=await (await fetch(g)).text();q=(new DOMParser).parseFromString(q,"text/html").querySelectorAll("#market_table tr");if((r=document.querySelector('input[type="submit"][name="anbieten"][value="Offer"]'))&&
r.disabled)g=JSON.parse(localStorage.getItem("Timers")),Z("resetExpired",g.ResetExpired||10),D(`${d.Bf}`);else for(r=1;r<q.length;r++){var u=q[r];n=u.querySelectorAll("td")[2];w=u.querySelector('input[name="cancel"]');u=(u=u.querySelector("div[data-item-id]"))?u.getAttribute("data-item-id"):null;w&&Number(n.textContent.replace(/\./g,""))===Number(kh)&&(await fetch(g,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({buyid:u,qry:"",seller:"",f:0,fl:0,
fq:-1,s:"",p:1,cancel:"Cancel"})}),D(`${d.uf}`),P("itemReset",0))}}}}if(!l||l)c=JSON.parse(localStorage.getItem("Timers")),Z("resetExpired",c.ResetExpired||10),window.location.reload()}}async function mj(b,c,e,h,k,g){let {spot:l,bag:q}=await mc(k,g);try{const m=await jQuery.post(T({mod:"inventory",submod:"move",from:c,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+1,amount:h}),{a:(new Date).getTime(),sh:W("sh")});if(m){const n=Math.floor(41*Math.random())+10;kh=n;const r=JSON.parse(m).to.data.itemId;await nj(c,
n,r)}}catch(m){D(`${d.vf}`),b=JSON.parse(localStorage.getItem("Timers")),Z("resetExpired",b.ResetExpired||10),window.location.reload()}}async function nj(b,c,e){await jQuery.post(G({mod:"guildMarket",sh:W("sh")}),{sellid:e,preis:c,dauer:1,sell_mode:0,anbieten:"Offer"})}async function oj(){if(!1!==JSON.parse(localStorage.getItem("underworld")||"{}").isUnderworld||"true"!==localStorage.getItem("BuffUnderworldOnly")){"mod=overview&doll=1"!=rf&&Dh("mod=overview&doll=1");var b={"11-23":{type:"Health",
item:"Gingko"},"11-22":{type:"Health",item:"Taigaroot"},"11-21":{type:"Health",item:"Hawthorn"},"11-1":{type:"Strength",item:"Flask"},"11-2":{type:"Strength",item:"Ampulla"},"11-3":{type:"Strength",item:"Flacon"},"11-4":{type:"Strength",item:"Bottle"},"11-13":{type:"Constitution",item:"Flask"},"11-14":{type:"Constitution",item:"Ampulla"},"11-15":{type:"Constitution",item:"Flacon"},"11-16":{type:"Constitution",item:"Bottle"},"11-9":{type:"Agility",item:"Flask"},"11-10":{type:"Agility",item:"Ampulla"},
"11-11":{type:"Agility",item:"Flacon"},"11-12":{type:"Agility",item:"Bottle"},"11-17":{type:"Charisma",item:"Flask"},"11-18":{type:"Charisma",item:"Ampulla"},"11-19":{type:"Charisma",item:"Flacon"},"11-20":{type:"Charisma",item:"Bottle"},"11-24":{type:"Intelligence",item:"Flask"},"11-25":{type:"Intelligence",item:"Ampulla"},"11-26":{type:"Intelligence",item:"Flacon"},"11-27":{type:"Intelligence",item:"Bottle"},"11-5":{type:"Dexterity",item:"Flask"},"11-6":{type:"Dexterity",item:"Ampulla"},"11-7":{type:"Dexterity",
item:"Flacon"},"11-8":{type:"Dexterity",item:"Bottle"}},c=JSON.parse(localStorage.getItem("buffs"))||{},e=JSON.parse(localStorage.getItem("Timers")),h=JSON.parse(localStorage.getItem("buffSelections"))||{};for(const g in h){var k=h[g];let l=null;if(0<k.length)for(let q of k)if(Object.entries(b).find(([,m])=>m.type===g&&m.item===q)&&!Object.keys(c).find(m=>m.includes(g)&&m.includes(q)&&0<c[m].timeLeft))try{let m=!1,n=null;for(k=1;3>=k;k++){const r=await jQuery.get(G({mod:"packages",f:11,fq:-1,qry:"",
page:k,sh:W("sh")}));jQuery(r).find(".packageItem").each(function(w,u){w=jQuery(u).find(".ui-draggable").attr("data-basis");if((w=b[w])&&w.type===g&&w.item===q){const t=w.item;l=t;if(Object.keys(c).some(y=>y.includes(g)&&y.includes(t)))return!0;m=!0;n=jQuery(u);return!1}});if(m)break}if(m&&n)try{await mc(1,1,async(r,w)=>{const u=n.find('input[name="packages[]"]').val(),t=n.find(".ui-draggable").attr("data-position-x"),y=n.find(".ui-draggable").attr("data-position-y");await new Promise(A=>setTimeout(A,
250));await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+u,fromX:t,fromY:y,to:w,toX:r.x+1,toY:r.y+1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")}));D(`${g} buff (${q}) has been moved to the inventory.`);await new Promise(A=>setTimeout(A,250));await jQuery.post(T({mod:"inventory",submod:"move",from:w,fromX:r.x+1,fromY:r.y+1,to:8,toX:1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")}));c[`${g} - ${l}`]={timeLeft:n.find(".ticker").attr("data-ticker-time-left")/6E4};localStorage.setItem("buffs",
JSON.stringify(c))})}catch(r){Z("BuffCheck",e.BuffTimer||60),D(`Error moving or using ${g} buff (${q}):`,r)}else Z("BuffCheck",e.BuffTimer||60),D(`No ${g} buff found for ${q}.`)}catch(m){Z("BuffCheck",e.BuffTimer||60),D("Error fetching buffs from packages:",m)}}}}function pj(){const b=Date.now(),c=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),e=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),h=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),k=JSON.parse(localStorage.getItem("disabledTimeMercenary")||
"{}");Object.entries(e).forEach(([g,l])=>{3E5<b-l&&(c[g]=!0,delete e[g])});Object.entries(k).forEach(([g,l])=>{3E5<b-l&&(h[g]=!0,delete k[g])});localStorage.setItem("activeItemsGladiator",JSON.stringify(c));localStorage.setItem("disabledTimeGladiator",JSON.stringify(e));localStorage.setItem("activeItemsMercenary",JSON.stringify(h));localStorage.setItem("disabledTimeMercenary",JSON.stringify(k))}function cf(){const b=localStorage.getItem("healPercentage")||25;var c=(new Date).getTime();let e=!1;let z4=localStorage.getItem("we");we=new Date(z4);if(ea<
new Date||we<new Date)throw hb(),Error("SupportDevs");const h=[];if(!0===Ba&&ca==va){var k=Ac(document.getElementById("cooldown_bar_text_expedition").innerText);h.push({name:"expedition",time:k,index:0})}!0===Fa&&ca==va&&(k=Ac(document.getElementById("cooldown_bar_text_dungeon").innerText),h.push({name:"dungeon",time:k,index:1}));!0===Ga&&(k=Ac(document.getElementById("cooldown_bar_text_arena").innerText),h.push({name:"arena",time:k,index:2}));!0===Ca&&(k=Ac(document.getElementById("cooldown_bar_text_ct").innerText),
h.push({name:"circusTurma",time:k,index:3}));!0===Da&&(c=localStorage.getItem("eventPoints.timeOut")-c,h.push({name:"eventExpedition",time:c,index:4}));"true"===sessionStorage.getItem("autoGoActive")&&!1===Ca&&!1===Ga&&!1===Ba&&!1===Fa&&"true"===localStorage.getItem("activateAuction2")&&If(2E4);const g=function(u){let t=0;for(;t<u.length&&!u[t];)t++;if(t===u.length)return null;let y=u[t].time;for(let A=t+1;A<u.length;A++)u[A]&&u[A].time<y&&(y=u[A].time,t=A);return u[t]}(h);function l(u){if(1E3>u)return"0:00:00";
u=Math.round(u/1E3);let t=u%60;10>t&&(t="0"+t);u=(u-t)/60;let y=u%60;10>y&&(y="0"+y);return(u-y)/60+":"+y+":"+t}let q=document.getElementById("nextActionWindow");const m=(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld;q||(q=document.createElement("div"),q.setAttribute("id","nextActionWindow"),q.setAttribute("style","\n                display: block;\n                align-items: center;\n                justify-content: center;\n                position: absolute;\n                top: -3px;\n                left: 50%;\n                transform: translateX(-50%);\n                height: 50px;\n                width: 190px;\n                color: black;\n                background: rgba(196, 172, 112, 0.9);\n                border-radius: 10px;\n                font-size: 16px;\n                font-family: 'Open Sans', sans-serif;\n                letter-spacing: 0.5px;\n                border: 1px solid black;\n                z-index: 1999;\n                \n                  "),
g&&g.time&&!String(g.time).includes("NaN")?q.innerHTML=`
                              <span class="span-new" style="color: black;">${d.$c}: </span>
                              <span class="span-new">${d[g.name]}</span></br>
                              <span class="span-new" style="color: black;">${d.zc}: </span>
                              <span class="span-new">${l(g.time)}</span>`:q.innerHTML='\n                              <span class="span-new">Please select an action. [Exp|Dungeon|Arena|Circus]</span></br>',document.getElementById("header_game").insertBefore(q,document.getElementById("header_game").children[0]));function n(u){if(!0===m){if(!0===(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld)switch(u){case "expedition":return"cooldown_bar_expedition";case "circusTurma":if(Ca)return"cooldown_bar_ct";
default:return null}}else switch(u){case "expedition":if(Ba)return"cooldown_bar_expedition";break;case "dungeon":if(Fa)return"cooldown_bar_dungeon";break;case "arena":if(Ga)return"cooldown_bar_arena";break;case "circusTurma":if(Ca)return"cooldown_bar_ct";break;case "eventExpedition":if(Da)return null;break;default:return null}}function r(u){if("eventExpedition"!==u){if("circusTurma"===u&&(u="ct"),(u=document.getElementById("cooldown_bar_"+u))&&"none"!==u.style.display)return!u.querySelector(".cooldown_bar_text").classList.contains("ticker")}else if(Da)return Array.from(document.getElementsByClassName("cooldown_bar_link")).some(t=>
(t=t.closest(".cooldown_bar"))&&"none"!==t.style.display?!t.querySelector(".cooldown_bar_text").classList.contains("ticker"):!1);return!1}function w(u){try{if("eventExpedition"===u&&X("eventPoints")&&1==Da&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(b):1))try{const t=document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0];return t?(t.click(),e=!0):!1}catch(t){return D("Error performing eventExpedition action: "+t),!1}else{const t=n(u);if(t){const y=document.getElementById(t);
if(y){const A=y.querySelector(".cooldown_bar_link");if(m&&r(u)&&!Ba)return!1;if(A&&r(u))return A.click(),!0}}}}catch(t){return window.location.reload(),!1}}if("true"===sessionStorage.getItem("autoGoActive")){const u=["expedition","dungeon","arena","circusTurma","eventExpedition"];let t=0;function y(){let x=Date.now();if(400>x-t)requestAnimationFrame(y);else{for(const v of u)if(r(v)&&(e=w(v))){t=x;return}e||requestAnimationFrame(y)}}y();setInterval(()=>{if(g){g.time-=1E3;if(g&&(A!==g.name||z!==g.time)){var x=
!g||isNaN(g.time)||String(g.time).includes("NaN")?`<span class="span-new">${d.ba}</span></br>`:`
                            <span class="span-new" style="color: black;">${d.$c}: </span>
                            <span class="span-new">${d[g.name]}</span></br>
                            <span class="span-new" style="color: black;">${d.zc}: </span>
                            <span class="span-new">${l(g.time)}</span>`;q.innerHTML=x;A=g.name;z=g.time;ra&&!0===Oa&&M()&&"mod=quests"!=rf&&Dh("mod=quests")}(0>=g.time||r(g.name))&&w(g.name)}},1E3);let A=null,z=-1}}(function(){if("true"===localStorage.getItem("disableBG")){var b=document.getElementById("wrapper_game");b&&(b.style.backgroundImage="none",b.style.backgroundColor="black")}let c=setTimeout(()=>{chrome.runtime.sendMessage({Pp:!0})},1E4);window.onload=function(){clearTimeout(c);chrome.runtime.sendMessage({Qp:!0})};
let e=!1;document.addEventListener("touchstart",function(h){function k(l){setTimeout(function(){var q=new MouseEvent("click",{bubbles:!0,cancelable:!0,view:window});l.dispatchEvent(q)},150)}var g=h.target;try{if("AuctionaddPrefixButton"==g.id||"AuctionaddSuffixButton"==g.id||"Strength"==g.htmlFor||"Dexterity"==g.htmlFor||"Agility"==g.htmlFor||"Constitution"==g.htmlFor||"Charisma"==g.htmlFor||"Intelligence"==g.htmlFor||"costumes_button_left"===g.offsetParent.id||"costumes_button_right"===g.offsetParent.id||
"buy_rubies_link"===g.offsetParent.id||"footer_inner"===g.offsetParent.id||"footer_logos"===g.offsetParent.id||"content"===g.id||"sidebar"===g.id||"char"===g.id||"a.menuitem.advanced_menu_link"==g.className||"a.menuitem.advanced_menu_link active"==g.className||"a.menuitem.advanced_menu_link active"==g.className||"menuitem"==g.className||"menuitem "==g.className||"menuitem advanced_menu_link"==g.className||"menuitem active advanced_menu_link_active"==g.className||"set_dungeon_difficulty_normal"!=g.id&&
"set_dungeon_difficulty_advanced"!=g.id&&"set_event_monster_id_0"!=g.id&&"set_event_monster_id_1"!=g.id&&"set_event_monster_id_2"!=g.id&&"set_event_monster_id_3"!=g.id&&"do_combat_quests"!=g.id&&"do_arena_quests"!=g.id&&"do_circus_quests"!=g.id&&"do_expedition_quests"!=g.id&&"do_dungeon_quests"!=g.id&&"do_items_quests"!=g.id&&"ConstitutionPriority"!=g.id&&"CharismaPriority"!=g.id&&"IntelligencePriority"!=g.id&&"StrengthPriority"!=g.id&&"DexterityPriority"!=g.id&&"AgilityPriority"!=g.id&&"shoes-image"!=
g.className&&"ring1-image"!=g.className&&"ring2-image"!=g.className&&"helmet-image"!=g.className&&"necklace-image"!=g.className&&"sword-image"!=g.className&&"chest-image"!=g.className&&"shield-image"!=g.className&&"gloves-image"!=g.className&&("div"==g.localName&&"overlayBack"!==g.id||"div"==g.localName&&"licotok"!==g.id))return}catch{}e||"checkbox"===g.type&&"switch"===g.className||(e=!0,k(g),"submit"!==g.type&&"checkbox"!==g.type&&"switch"!==g.className||h.preventDefault());e=!1},{passive:!1});
try{chrome&&chrome.runtime&&chrome.runtime.sendMessage&&"true"===sessionStorage.getItem("autoGoActive")&&(chrome.runtime.sendMessage({qn:!0,tm:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"}),chrome.runtime.sendMessage({keepAlive:!0},()=>{}));let h=localStorage.getItem("activeItemsMercenary"),k=localStorage.getItem("activeItemsGladiator");null!==h&&h!==JSON.stringify([])||localStorage.setItem("activeItemsMercenary",JSON.stringify({}));null!==k&&k!==JSON.stringify([])||localStorage.setItem("activeItemsGladiator",
JSON.stringify({}));chrome.runtime.onMessage.addListener(g=>{g.qn&&g.tm&&"true"===sessionStorage.getItem("autoGoActive")&&(g=new Audio(g.tm),g.loop=!0,g.volume=0,g.play().catch(()=>{}))})}catch{console.log("Could not play the audio")}(b=JSON.parse(localStorage.getItem("timeConditions"))||[],1>b.length)&&!window.location.href.includes("/index.php?mod=hermit&submod=travel")&&!window.location.href.includes("/index.php?mod=packages")&&!window.location.href.includes("/index.php?mod=forge")?setTimeout(function(){window.location.reload()},
36E4):window.location.href.includes("/index.php?mod=hermit&submod=travel")||window.location.href.includes("/index.php?mod=packages")||window.location.href.includes("/index.php?mod=forge")||setTimeout(function(){window.location.reload()},18E4)})();const qj={start(){const b=async()=>{const h=qb("gf-token-production");console.log("GF Token:",h);return h?{"Content-Type":"application/json",headers:{ip:`Bearer ${h}`}}:{}},c=async()=>{try{chrome.runtime.sendMessage({queryButtonClickedState:!0},async h=>
{if(!h.state){h=(h=document.cookie.split("; ").find(m=>m.startsWith("gllastusername=")))?h.split("=")[1]:null;let l=null,q=null;h&&([l,q]=h.split("-"));h=[];try{var k=await (await fetch("/api/users/me/accounts",await b())).json();h=Array.isArray(k)?k:[]}catch(m){}h=h.sort((m,n)=>new Date(n.vo)-new Date(m.vo));k=null;l&&q&&(k=h.find(m=>m.name===l&&String(m.id)===q));!k&&0<h.length&&(k=h[0]);if(k){if(h=document.getElementById("accountlist")){h=h.getElementsByClassName("rt-tr");for(var g of h){h=g.querySelector(".player-cell");
const m=g.querySelector(".btn.btn-primary");if(h&&m&&h.textContent.trim()===k.name){m.click();sessionStorage.setItem("loggedIn","true");return}}}}else if(g=document.getElementById("accountlist"))if(g=g.getElementsByClassName("btn btn-primary"),g[0]){g[0].click();sessionStorage.setItem("loggedIn","true");return}sessionStorage.setItem("loggedIn","false")}})}catch(h){sessionStorage.setItem("loggedIn","false")}},e=async()=>{chrome.runtime.sendMessage({action:"ctab"},h=>{h&&h.gr||(window.location.href.includes("/accounts")?
c():window.location.href="https://lobby.gladiatus.gameforge.com/en_GB/accounts")})};(()=>{if(!window.location.href.includes("game/index.php")){const h=document.cookie.split("; ").find(g=>g.startsWith("glautologin=")),k=h?h.split("=")[1]:null;chrome.runtime.sendMessage({action:"ctab"},g=>{g.gr||window.location.href.includes("forum.gladiatus")||!window.location.href.includes("lobby")||"true"!==k||setTimeout(e,3500)})}})();(()=>{var h=document.querySelectorAll('h1, h2, .error-code, h1[jstcache="0"], #main-frame-error');
let k=!1;for(const g of h){h=g.textContent||"";if(h.includes("503")||h.includes("500")){k=!0;break}if("main-frame-error"===g.id||g.hasAttribute("jstcache")){k=!0;break}}k&&(console.warn("Error detected on page. Reloading..."),setTimeout(()=>{location.reload()},3E3))})()}};window.location.href.includes("index.php?mod=overview&submod=achievements")||window.location.href.includes("index.php?mod=overview&submod=stats")||qj.start();const lh=localStorage.getItem("underworld"),zb=lh?JSON.parse(lh):null,
mh=document.querySelector('input[name="cancelTravel"]');try{document.querySelector("#header_LoginBonus")&&!mh&&zb&&!window.location.href.includes("/index.php?mod=hermit")&&!1===zb.isUnderworld&&document.querySelector("#linkLoginBonus").click()}catch{}let nh=document.getElementById("wrapper_game");if(nh&&"underworld"===nh.className){const b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else{const b=JSON.parse(localStorage.getItem("underworld")||
"{}");b.isUnderworld=!1;localStorage.setItem("underworld",JSON.stringify(b))}try{if((window.location.href.includes("/index.php?mod=hermit&submod=travel")||mh||window.location.href.includes("/index.php?mod=hermit&submod=enterUnderworld"))&&"true"===sessionStorage.getItem("autoGoActive")&&"true"===localStorage.getItem("autoEnterHell")){const b=document.querySelector('span[data-ticker-type="countdown"]');if(b){const c=parseInt(b.getAttribute("data-ticker-time-left"),10);await new Promise(e=>setTimeout(e,
c-7E3||358E3))}else await new Promise(c=>setTimeout(c,3E5));Dh("mod=overview")}}catch(b){D(`Error in underworld wait: ${b.message}`)}setTimeout(()=>{F()},250);let df=!0;const cb=new URL(window.location.href);let oh=document.createElement("style");oh.innerHTML="\n    #logMenu {\n      resize: vertical;\n      overflow: auto;\n      max-height: 500px;\n    }\n  ";document.head.appendChild(oh);let uf=null,vf=0;null===localStorage.getItem("HealClothToggle")&&localStorage.setItem("HealClothToggle","false");
window.location.href.includes("mod=auction")&&L();const ka=JSON.parse(localStorage.getItem("userStats"))||{Fm:0,Gm:0,Dm:0,sm:0,vm:0,ym:0,Am:0,Hm:0,Om:0,dm:0,em:0};let gb;localStorage.getItem("playerId")&&ya((localStorage.getItem("playerId")|0)%100|0);(function(){var b="true"===localStorage.getItem("MoveButtons");let c=document.createElement("button");c.className="menuitem breathing-light";c.innerHTML="GLDbot License";c.setAttribute("id","lico");c.addEventListener("click",Rh);b?((b=document.getElementById("lico"))&&
b.remove(),c.style.position="fixed",c.style.left="13px",c.style.bottom="60px",c.style.zIndex="1000",document.body.appendChild(c)):(b=document.getElementById("mainmenu"))&&b.children[0]&&b.insertBefore(c,b.children[0]);c=document.createElement("style");c.innerHTML = "\n        @keyframes breathing-light {\n            0%, 100% {\n                box-shadow: 0 0 11px 5px rgba(255, 255, 0, 0.7);\n            }\n            50% {\n                box-shadow: 0 0 11px 10px rgba(255, 255, 0, 0.5);\n            }\n        }\n    \n        .breathing-light {\n            animation: breathing-light 2s ease-in-out infinite;\n        }";document.head.appendChild(c)})();if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll")){var ef=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),
vb=ef.textContent.trim();if(2<vb.length){var ff=document.getElementById("char");function b(e,h,k,g){if(null!==document.getElementById("container_start")){var l=window.location.href.split("p=")[1].split("&")[0],q=window.location.href.match(/s(\d+)-\w\w/),m=window.location.href.match(/s\d+-(\w\w)/);h={playerName:h,aType:g,opponentId:l,serverId:q?q[1]:null,country:m?m[1]:null};k=2===g?"arenacrosslist":"circuscrosslist";var n=2===g?"removeArenaList":"removeCircusList";q=JSON.parse(qb(k)||"[]");var r=
JSON.parse(qb(n)||"[]");m=q.findIndex(u=>u.opponentId===l);var w=r.findIndex(u=>u.opponentId===l);-1!==m?(q.splice(m,1),-1===w&&(r.push(h),pb(n,JSON.stringify(r),7)),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+(2===g?"Arena":"Circus"))):(q.push(h),-1!==w&&(r.splice(w,1),pb(n,JSON.stringify(r),7)),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+(2===g?"Arena":"Circus")));pb(k,JSON.stringify(q),7)}else q=JSON.parse(localStorage.getItem(k))||[],m=q.indexOf(h),
-1!==m?(q.splice(m,1),e.classList.remove("added"),e.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(q.push(h),e.classList.add("added"),e.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus"))),localStorage.setItem(k,JSON.stringify(q))}function c(e,h,k,g,l){var q=document.createElement("a");q.className="gladbot-button gladbot-"+e;q.textContent=h;q.setAttribute("data-tooltip",k);ff.appendChild(q);(JSON.parse(localStorage.getItem(g))||[]).includes(vb)&&
(q.classList.add("added"),q.setAttribute("data-tooltip","Remove from "+("autoAttackList"===g?"Arena":"Circus")));q.addEventListener("click",function(){b(q,vb,g,l)})}c("arena","A","GladB: Add to Arena List","autoAttackList",2);c("circus","C","GladB: Add to Circus List","autoAttackCircusList",3)}}const rj=localStorage.getItem("Username"),va=localStorage.getItem("pid"),idkps=localStorage.getItem("idkps");let sj=localStorage.getItem("tkz_lcr");const tj=localStorage.getItem("tkn"),gc=await ma(sj,tj,va,rj);window.location.href.includes("/index.php?mod")&&
sessionStorage.setItem("loggedIn","false");if(window.location.href.includes("/index.php?mod=overview")){const b=[3,4,5,2,9,10,6,7,11],c=[1,2,4,8,48,256,512,1024];Sh();(function(){const k={dbfa266e60c28ce109de4d9c216a2a:"Health - Gingko Leaves","25925f7ce7c04483a3b4527846c04b":"Health - Taigaroot","79e62e1e04445d354bcc955bb8baeb":"Health - Hawthorn",b306d3f65b14cb91c0f0c9de871e0a:"Strength - Flask",ee80ae69b48ebbeb81e52c20113709:"Constitution - Flask","887d1152e2f7cba339a0a4675b3b5e":"Agility - Flask",
"93820f465cb02d5d8828ee9a14f5fe":"Charisma - Flask","2bf8795edae428b4646f8d6fd6dc4c":"Intelligence - Flask","43ac2597d30a099dd7033273ac29c1":"Dexterity - Flask","5368deb7929c8853843b420fb439ac":"Constitution - Bottle","967321edb226ea075ac63acc701eea":"Dexterity - Bottle","1c344cf484e5a87731eaf906ffd993":"Strength - Bottle","8971734256abbbe0fea2bb40721953":"Intelligence - Bottle",d2df53b4e64ad33dc301b6bf125fd2:"Agility - Bottle","37fc8feb4ead7f2e59c026af4228b3":"Charisma - Bottle",ce03a66b17f81394722a3fc2335a1d:"Constitution - Flacon",
"352a093dc497a9ec659f217dc7d374":"Dexterity - Flacon",b5e7e6f2cd2ea3d86143894e5f9ade:"Charisma - Flacon","2e8f9fc0f9b101f7ba49152cbe9779":"Strength - Flacon","3b52078b78637bd54fed2e4cfb951b":"Agility - Flacon",a2ef931eff7cce75e07baa9ae2ac97:"Intelligence - Flacon","48331278d1b0391f74ba54b4cac6d4":"Intelligence - Ampulla","453199ebfb25d62f83af27b0187088":"Agility - Ampulla","00ef972a002dc3040447e5cc0eb77d":"Dexterity - Ampulla",ce6fe5171b946cd26d5b21e87efb5d:"Strength - Ampulla",ddd6bc43a13d444409087b99b9f142:"Charisma - Ampulla",
bd48bef94e6d066a8bfef716dd959a:"Constitution - Ampulla"},g=document.querySelectorAll("#buffbar_old .buff_inner");let l=JSON.parse(localStorage.getItem("buffs"))||{},q=new Set;g.forEach(m=>{var n=m.querySelector("img");n=(n=n?n.getAttribute("src"):null)?n.split("/").pop().split(".")[0]:null;if(n=k[n])if(m=(m=m.parentElement.querySelector(".ticker"))?m.getAttribute("data-ticker-time-left"):null)l[n]={timeLeft:Math.round(Number(m)/6E4)},q.add(n)});Object.keys(l).forEach(m=>{q.has(m)||delete l[m]});localStorage.setItem("buffs",
JSON.stringify(l))})();const e=document.getElementById("char");if(e){const k=document.createElement("button"),g=document.createElement("span");k.textContent="\u21d3";k.className="put-down awesome-button";k.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 170px; font-size: 12px; cursor: pointer;";k.classList.add("tooltip");k.appendChild(g);k.onclick=async function(){let m=Array.from(document.querySelectorAll("#char .ui-droppable")).filter(n=>b.includes(parseInt(n.dataset.containerNumber,
10)||"0"));for(let n=0;n<m.length;n++)await new Promise(r=>setTimeout(r,100)),Ha(m[n],"inv");await new Promise(n=>setTimeout(n,500))};e.appendChild(k);const l=document.createElement("button"),q=document.createElement("span");l.textContent="\u21d1";l.className="put-up awesome-button";l.style="padding: 2.5px 5px; position: absolute; top: 235px; left: 192px; font-size: 12px; cursor: pointer;";l.classList.add("tooltip");l.appendChild(q);l.onclick=async function(){let m=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(n=>
c.includes(parseInt(n.dataset.contentType,10)));for(let n=0;n<m.length;n++)await new Promise(r=>setTimeout(r,100)),Ha(m[n],"char");await new Promise(n=>setTimeout(n,500))};e.appendChild(l)}if(document.getElementById("inv")){async function k(m,n,r,w,u,t){await jQuery.post(T({mod:"inventory",submod:"move",from:t,fromX:n+1,fromY:r+1,to:t,toX:w+1,toY:u+1,amount:m.dataset.amount||1,doll:1,a:(new Date).getTime(),sh:W("sh")}))}const g=document.createElement("button");g.id="sort-button";g.textContent="Sort Inventory";
g.className="sort-button awesome-button";g.style="padding: 5px; margin: 5px; cursor: pointer;";const l=document.createElement("span");l.id="loading-indicator";l.style="margin-left: 10px; display: none;";const q=document.querySelector(".contentItem");q&&(q.insertAdjacentElement("afterend",g),g.insertAdjacentElement("afterend",l));g.addEventListener("click",async function(){function m(z,x,v){for(let C=0;5>C;C++)for(let E=0;8>E;E++)if(!u[C][E]){let I=!0;for(let K=C;K<C+x&&I;K++)for(let J=E;J<E+z;J++)if(5<=
K||8<=J||u[K][J])I=!1;if(I){if(v){z=[{x:E-1,y:C},{x:E+z,y:C},{x:E,y:C-1},{x:E,y:C+x}];for(const K of z)if(0<=K.x&&8>K.x&&0<=K.y&&5>K.y&&w.find(J=>{const O=parseInt(J.style.top,10)/32;return parseInt(J.style.left,10)/32===K.x&&O===K.y&&J.dataset.basis.split("-")[0]===v}))break}return{x:E,y:C}}}return null}var n=document.getElementById("inv");document.getElementById("sort-button");var r=document.getElementById("loading-indicator");r.textContent="Sorting...";r.style.display="inline-block";const w=Array.from(n.getElementsByClassName("ui-draggable"));
w.sort((z,x)=>{const v=parseInt(z.dataset.basis.split("-")[0],10)||0,C=parseInt(x.dataset.basis.split("-")[0],10)||0;return v!==C?v-C:(parseInt(z.dataset.measurementX,10)*parseInt(z.dataset.measurementY,10)||1)-(parseInt(x.dataset.measurementX,10)*parseInt(x.dataset.measurementY,10)||1)});const u=Array.from({length:5},()=>Array(8).fill(!1));w.forEach(z=>{const x=parseInt(z.style.left,10)/32,v=parseInt(z.style.top,10)/32,C=parseInt(z.dataset.measurementX,10);z=parseInt(z.dataset.measurementY,10);for(let E=
v;E<v+z;E++)for(let I=x;I<x+C;I++)u[E][I]=!0});for(n=0;n<w.length;n++){var t=w[n];r=parseInt(t.dataset.measurementX,10);const z=parseInt(t.dataset.measurementY,10);var y=t.dataset.basis.split("-")[0];const x=parseInt(t.style.left,10)/32,v=parseInt(t.style.top,10)/32;var A=m(r,z,y);if(A&&(y=A.x,A=A.y,x!==y||v!==A)){await k(t,x,v,y,A,t.dataset.containerNumber);for(t=A;t<A+z;t++)for(let C=y;C<y+r;C++)u[t][C]=!0;for(y=v;y<v+z;y++)for(t=x;t<x+r;t++)u[y][t]=!1}}window.location.reload()})}const h=JSON.parse(localStorage.getItem("underworld"))||
{};try{const k=document.querySelector("#avatar .ui-droppable");if(k){const g=k.getAttribute("data-tooltip");g&&g.toLowerCase().includes("dis pater")?(h.hj=!0,localStorage.setItem("underworld",JSON.stringify(h)),Z("CheckDolls",15)):(h.hj=!1,localStorage.setItem("underworld",JSON.stringify(h)))}}catch{}}let Mc=localStorage.getItem("playerId");fc();let ub=!1,ra="true"===sessionStorage.getItem("autoGoActive")?!0:!1,ba;try{ba={level:parseInt(document.getElementById("header_values_level").innerText,10)||
50,o:parseInt($("#header_values_hp_percent")[0].innerText,10),gold:Number($("#sstat_gold_val")[0].innerHTML.replace(/\./g,""))}}catch(b){ba={level:50}}const db=document.createElement("div");db.style.position="fixed";db.style.right="10px";db.style.top="50px";db.style.zIndex="99999";document.body.appendChild(db);const pa=document.createElement("div");pa.id="logMenu";pa.style.width="190px";pa.style.height="210px";pa.style.overflowY="hidden";pa.style.backgroundColor="rgba(221, 213, 180, 0.8)";pa.style.border=
"1px solid #c4ac70";pa.style.borderRadius="10px";pa.style.fontFamily="Arial, sans-serif";pa.style.color="#333";db.appendChild(pa);const eb=document.createElement("h2");eb.textContent="Log Menu";eb.style.backgroundColor="rgba(196, 172, 112, 0.8)";eb.style.color="#333";eb.style.margin="0";eb.style.padding="10px 20px";eb.style.borderTopLeftRadius="10px";eb.style.borderTopRightRadius="10px";pa.appendChild(eb);const Db=document.createElement("div");Db.id="logEntriesContainer";Db.style.color="#bfae54";Db.style.background="url(//gf2.geo.gfsrv.net/cdn78/c22a8b33d6e837288acdf4ac202d85.jpg) 50%";Db.style.overflowY="scroll";
Db.style.height="calc(100% - 60px)";Db.style.padding="10px 20px";pa.appendChild(Db);const Qa=document.createElement("div");Qa.style.display="flex";Qa.style.justifyContent="space-between";Qa.style.marginTop="10px";Qa.style.top="calc(300px + 10px)";Qa.style.width="155px";Qa.style.padding="0 10px";Qa.style.zIndex="99999";Qa.style.left="0";db.appendChild(Qa);const Ma=document.createElement("button");Ma.id="clearLogsButton";Ma.textContent="Clear Logs";Nc(Ma,"rgba(221, 213, 180, 0.8)");Qa.appendChild(Ma);
Ma.addEventListener("click",function(){const b=document.querySelector("#logMenu");if(b){for(;b.firstChild;)b.removeChild(b.firstChild);localStorage.removeItem("savedLogs")}});const Ub=document.createElement("button");Ub.id="resetBOT";Ub.textContent="Reset Bot";Nc(Ub,"rgba(221, 213, 180, 0.8)");Qa.appendChild(Ub);Ub.addEventListener("click",function(){fa()});const Ra=document.createElement("button");Ra.textContent="Sort Logs";Nc(Ra,"rgba(221, 213, 180, 0.8)");Qa.appendChild(Ra);Ra.addEventListener("click",
function(){let b=localStorage.getItem("savedLogs");if(b){b=JSON.parse(b);b.sort((e,h)=>{e=e.split(" ")[0];h=h.split(" ")[0];return df?e.localeCompare(h):h.localeCompare(e)});df=!df;for(var c=document.querySelector("#logMenu");c.firstChild;)c.removeChild(c.firstChild);for(let e of b){const h=document.createElement("p");h.style.margin="0";h.style.padding="0";h.style.fontSize="12px";h.textContent=e;c.appendChild(h)}localStorage.setItem("savedLogs",JSON.stringify(b))}});pa.style.transition="height 0.1s ease";
const ph=localStorage.getItem("logMenuVisible"),qh="true"===localStorage.getItem("disableLogMenu");null===ph?localStorage.setItem("logMenuVisible","true"):1==qh?(pa.style.display="none;",pa.style.height="0px",pa.style.width="0px",pa.style.border="0px",Ma.style.display="none",Ma.style.height="0px",Ma.style.width="0px",Ma.style.border="0px",Ra.style.display="none",Ra.style.height="0px",Ra.style.width="0px",Ra.style.border="0px"):"true"===ph?localStorage.getItem("logMenuHeight"):pa.style.height="38px";
window.location.href.includes("/hub")&&(pa.style.display="none;",pa.style.height="0px",pa.style.width="0px",pa.style.border="0px",Ma.style.display="none",Ma.style.height="0px",Ma.style.width="0px",Ma.style.border="0px",Ra.style.display="none",Ra.style.height="0px",Ra.style.width="0px",Ra.style.border="0px");eb.addEventListener("click",function(){if("38px"!==pa.style.height)pa.style.height="38px",localStorage.setItem("logMenuVisible","false");else{const b=localStorage.getItem("logMenuHeight")||"210px";
pa.style.height=b;localStorage.setItem("logMenuVisible","true")}});pa.addEventListener("resize",yf);"38px"!==pa.style.height&&yf();if(Lc()){const b="true"===localStorage.getItem("MoveButtons");let c=document.getElementById("mainmenu"),e=document.createElement("button");e.id="autoGoButton";e.className="customButton";e.innerHTML=`<span style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;">${ra?"&#9724;":"&#9658;"}</span>`;e.addEventListener("click",ra?Cf:pt);
let h=document.createElement("button");h.className="customButton2";h.innerHTML='<span style="position: relative; top: -12px;">&#9881;</span>';h.addEventListener("click",lc);b?(h.style.position="fixed",h.style.bottom="10px",h.style.left="10px",h.style.zIndex="1000",e.style.position="fixed",e.style.bottom="10px",e.style.left="105px",e.style.zIndex="1000",document.body.appendChild(h),document.body.appendChild(e)):c&&(c.insertBefore(h,c.children[0]),c.insertBefore(e,c.children[1]))}else return hb(),!1;
(function(){try{if("mod=arena&submod=serverArena&aType=2"==rf||"mod=arena&submod=serverArena&aType=3"==rf){let l=JSON.parse(localStorage.getItem("autoAttackList"))||[],q=JSON.parse(localStorage.getItem("autoAttackServerList"))||[],m=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[],n=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||[],r=[...l,...q,...m,...n].map(w=>w.playerName);Array.from(document.querySelectorAll("#own2 tr")).forEach(w=>{(w=w.querySelector("a"))&&r.includes(w.innerText)&&
(w.style.color="orange",w.style.fontWeight="bold",w.style.textShadow="1px 1px 2px #000000")})}var b=JSON.parse(qb("arenacrosslist")||"[]"),c=JSON.parse(qb("circuscrosslist")||"[]"),e=JSON.parse(qb("removeArenaList")||"[]"),h=JSON.parse(qb("removeCircusList")||"[]"),k=JSON.parse(localStorage.getItem("autoAttackServerList")||"[]"),g=JSON.parse(localStorage.getItem("autoAttackCircusServerList")||"[]");0<b.length&&(b.forEach(l=>{k.some(q=>q.opponentId===l.opponentId)||k.push(l)}),localStorage.setItem("autoAttackServerList",
JSON.stringify(k)),pb("arenacrosslist",JSON.stringify([]),7));0<c.length&&(c.forEach(l=>{g.some(q=>q.opponentId===l.opponentId)||g.push(l)}),localStorage.setItem("autoAttackCircusServerList",JSON.stringify(g)),pb("circuscrosslist",JSON.stringify([]),7));if(0<e.length||0<h.length)k=k.filter(l=>!e.some(q=>q.opponentId===l.opponentId)),g=g.filter(l=>!h.some(q=>q.opponentId===l.opponentId)),localStorage.setItem("autoAttackServerList",JSON.stringify(k)),localStorage.setItem("autoAttackCircusServerList",
JSON.stringify(g)),pb("removeArenaList",JSON.stringify([]),7),pb("removeCircusList",JSON.stringify([]),7)}catch{D("Something is wrong with HandlePlayers")}})();"mod=overview"==rf&&Th();if("mod=location"!==rf&&"mod=arena"!==rf&&0==localStorage.getItem("eventPoints_")){const b=document.getElementById("ServerQuestTime");if(b){const c=b.querySelector("span");c&&localStorage.setItem("eventPoints_",c.textContent)}}let Oa=!0;localStorage.getItem("doQuests")&&(Oa="true"===localStorage.getItem("doQuests")?
!0:!1);let Pa={combat:!0,arena:!0,circus:!0,expedition:!0,dungeon:!0,items:!0};localStorage.getItem("questTypes")&&(Pa=JSON.parse(localStorage.getItem("questTypes")));let Vb=0;localStorage.getItem("nextQuestTime")&&(Vb=Number(localStorage.getItem("nextQuestTime")));let Ba=!0;localStorage.getItem("doExpedition")&&(Ba="true"===localStorage.getItem("doExpedition")?!0:!1);let Tc=0;localStorage.getItem("monsterId")&&(Tc=Number(localStorage.getItem("monsterId")));let Fa=!0;localStorage.getItem("doDungeon")&&
(Fa="true"===localStorage.getItem("doDungeon")?!0:!1);10>ba.level&&(Fa=!1);let Jb="advanced"===localStorage.getItem("dungeonDifficulty")?"advanced":"normal",Ga=!0;localStorage.getItem("doArena")&&(Ga="true"===localStorage.getItem("doArena")?!0:!1);2>ba.level&&(Ga=!1);let Jf="min";localStorage.getItem("arenaOpponentLevel")&&(Jf=localStorage.getItem("arenaOpponentLevel"));let Ca=!0;localStorage.getItem("doCircus")&&(Ca="true"===localStorage.getItem("doCircus")?!0:!1);10>ba.level&&(Ca=!1);let Kf="min";
localStorage.getItem("circusOpponentLevel")&&(Kf=localStorage.getItem("circusOpponentLevel"));let Da=!0;localStorage.getItem("doEventExpedition")&&(Da="true"===localStorage.getItem("doEventExpedition")?!0:!1);try{document.getElementById("submenu2").getElementsByClassName("menuitem glow")[0]||(Da=!1)}catch{}let nc=0;localStorage.getItem("eventMonsterId")&&(nc=Number(localStorage.getItem("eventMonsterId")));let Za=!1;localStorage.getItem("AutoAuction")&&(Za="true"===localStorage.getItem("AutoAuction")?
!0:!1);localStorage.getItem("DoOther")&&localStorage.getItem("DoOther");let ib=!1;localStorage.getItem("doKasa")&&(ib="true"===localStorage.getItem("doKasa")?!0:!1);let d;switch(localStorage.getItem("settings.language")){case "EN":d={...Ih};break;case "PL":d={...Jh};break;case "ES":d={...Kh};break;case "TR":d={...Lh};break;case "FR":d={...Mh};break;case "HG":d={...Nh};break;case "BR":d={...Oh};break;default:d={...Ih}}let z1=localStorage.getItem("we");we=new Date(z1);if(!window.location.href.includes("lobby")&&ea<new Date&&we<new Date)sessionStorage.setItem("autoGoActive",
"false"),hb();else{if("true"===localStorage.getItem("activateAuction2")){function b(m){m.style.position="flex";m.style.width="150px";m.style.marginLeft="8px";m.style.marginTop="10px";m.style.height="16px";m.style.backgroundColor="rgba(221, 213, 180, 0.8)";m.style.border="1px solid #c4ac70";m.style.padding="10px";m.style.borderRadius="10px";m.style.fontFamily="Arial, sans-serif";m.style.color="#333";m.style.textAlign="center";m.style.zIndex="1000"}const c=document.createElement("div");c.id="auctionMPopup";
b(c,"calc(55px + 200px + 100px + 10px + 10px + -5px)");c.addEventListener("click",async()=>{Dh("mod=auction&ttype=3")});const e=document.createElement("div");e.id="auctionPopup";b(e,"calc(100px + 200px + 100px + 10px)");e.addEventListener("click",async()=>{Dh("mod=auction")});function h(m,n){return`${n}: ${[d.Xb,d.zb,d.Hb,d.Ub,d.Yb][m]||"Unknown"}`}const k=document.createElement("h3"),g=document.createElement("h3");db.appendChild(e);db.appendChild(c);const l=localStorage.getItem("auctionStatus"),
q=localStorage.getItem("auctionMStatus");null!==l?(k.textContent=h(parseInt(l,10),"Gladiator"),e.appendChild(k),e.style.display="block"):e.style.display="none";null!==q?(g.textContent=h(parseInt(q,10),"Mercenary"),c.appendChild(g),c.style.display="block"):c.style.display="none";qh&&(e.style.display="none",e.style.height="0px",c.style.display="none",c.style.height="0px")}var Bc=localStorage.getItem("savedLogs");Bc&&(Bc=JSON.parse(Bc),Bc.forEach(b=>{const c=document.createElement("p");c.style.margin=
"0";c.style.padding="0";c.style.fontSize="12px";c.textContent=b;Db.appendChild(c)}));var za={async start(){return new Promise(()=>{za.kl=Fh().gold;za.form=document.querySelectorAll("#auction_table form");za.L=[];const b=localStorage.getItem("auctiongladiatorenable"),c=localStorage.getItem("auctionmercenaryenable"),e=localStorage.getItem("bidFood"),h=localStorage.getItem("bidStatus"),k=localStorage.getItem("auctionStatus"),g=localStorage.getItem("auctionMStatus"),l=localStorage.getItem("auctionminlevel")||
0;let q="true"===localStorage.getItem("enableMercenarySearch");const m=JSON.parse(localStorage.getItem("Timers")),n=async(w,u)=>{try{D(`${d.rf}`);const t=await (await fetch(w)).text(),y=(new DOMParser).parseFromString(t,"text/html");await za.Sn(y);0<za.L.length?(D(`${d.sf}`),"auction"===u?za.Tm(2,za.L.length):za.Tm(3,za.L.length)):("auction"===u?Z("auction",m.AuctionCheck||10):Z("auctionM",m.AuctionCheck||10),window.location.reload());1!=localStorage.getItem("AuctionTurbo")&&Z("AuctionEmpty",1)}catch(t){window.location.reload()}},
r=async()=>{var w=JSON.parse(localStorage.getItem("auctionPrefixes"))||[];let u=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],t;var y=(new URL(window.location.href)).origin;try{1===w.length?t=ec(w[0]):1===u.length&&(t=ec(u[0]))}catch(A){t=""}if(q&&Number(k)>=Number(h)&&X("auction")||"true"==e&&Number(k)>=Number(h)&&X("auction"))rf!=`mod=auction&itemType=0&itemLevel=${l}`&&(y=`${y}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,n(y,"auction"));else if((1==w.length||1==
u.length)&&"true"==b&&Number(k)>=Number(h)&&"false"==e&&X("auction"))w=`mod=auction&qry=${encodeURIComponent(t)}&itemType=0&itemLevel=${l}`,rf!==w&&(y=`${y}/game/index.php?${w}&sh=${W("sh")}`,n(y,"auction"));else if(q&&Number(k)>=Number(h)&&"true"==e&&X("auction"))rf!=`mod=auction&itemType=0&itemLevel=${l}`&&(y=`${y}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,n(y,"auction"));else if((1==w.length||1==u.length)&&"true"==c&&Number(g)>=Number(h)&&"false"==e&&X("auctionM"))rf!=
`mod=auction&qry=${encodeURIComponent(t)}&itemType=0&ttype=3&itemLevel=${l}`&&(y=`${y}/game/index.php?mod=auction&qry=${t}&itemType=0&ttype=3&itemLevel=${l}&sh=${W("sh")}`,n(y,"auctionM"));else if(("true"===b||"true"===e)&&!q&&Number(k)>=Number(h)&&X("auction"))if("true"===e&&1>w.length&&1>u.length)rf!=`mod=auction&itemType=7&itemLevel=${l}`&&(y=`${y}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${W("sh")}`,n(y,"auction"));else{if(("true"===b||"true"===e)&&!q&&Number(k)>=Number(h)&&X("auction"))if("true"===
e&&"false"===b&&(0<w.length||0<u.length))rf!=`mod=auction&itemType=7&itemLevel=${l}`&&(y=`${y}/game/index.php?mod=auction&itemType=7&itemLevel=${l}&sh=${W("sh")}`,n(y,"auction"));else if("true"===e&&(0<w.length||0<u.length))rf!=`mod=auction&itemType=0&itemLevel=${l}`&&(y=`${y}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,n(y,"auction"));else if(rf!=`mod=auction&itemType=0&itemLevel=${l}`&&0<w.length||rf!=`mod=auction&itemType=0&itemLevel=${l}`&&0<u.length)y=`${y}/game/index.php?mod=auction&itemType=0&itemLevel=${l}&sh=${W("sh")}`,
n(y,"auction")}else if("true"==c&&Number(g)>=Number(h)&&(0<w.length||0<u.length)&&X("auctionM")){if(rf!=`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&0<w.length||rf!=`mod=auction&itemType=0&ttype=3&itemLevel=${l}`&&0<u.length)y=`${y}/game/index.php?mod=auction&itemType=0&ttype=3&itemLevel=${l}&sh=${W("sh")}`,n(y,"auctionM")}else q?rf!=`mod=auction&itemType=15&itemLevel=${l}`&&(y=`${y}/game/index.php?mod=auction&itemType=15&itemLevel=${l}&sh=${W("sh")}`,n(y,"auction")):setTimeout(r,3E3)};r()})},
Rn(b){const c="true"===localStorage.getItem("AuctionCover");b=b.querySelector("span");if(!b||!b.getAttribute("style"))return!0;b=b.getAttribute("style");return c&&b.includes("green")?!1:!c&&b.includes("green")?!0:b.includes("blue")?!1:!0},async Sn(b){this.form=b.querySelectorAll("#auction_table form");for(let e of this.form){var c=e.querySelector(".auction_bid_div");b=e.querySelector(".ui-draggable");let h=c.querySelector("input").value;c=this.Rn(c);let k=ac(b),g=Hb(b),l=JSON.parse(localStorage.getItem("equipmentSelection")||
"[]"),q=localStorage.getItem("maximumBid"),m=localStorage.getItem("auctiongladiatorenable"),n=localStorage.getItem("auctionmercenaryenable"),r=wb(b),w=localStorage.getItem("auctionMinQuality")||0,u=localStorage.getItem("bidFood"),t=parseInt(yb(b).split("-")[0],10),y=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[7].match(/\d+/)[0],10):0,A=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[9].match(/\d+/)[0],10):0,z=15==t?parseInt(b.getAttribute("data-tooltip").split(",")[15].match(/\d+/)[0],
10):0,x=!1,v="true"===localStorage.getItem("enableMercenarySearch"),C=parseInt(localStorage.getItem("minDexterity"),10)||0,E=parseInt(localStorage.getItem("minAgility"),10)||0,I=parseInt(localStorage.getItem("minIntelligence"),10)||0,K=!1,J=!1,O,U,Y;Y=localStorage.getItem("ignorePS")||"false";O=JSON.parse(localStorage.getItem("auctionPrefixes")||"[]");U=JSON.parse(localStorage.getItem("auctionSuffixes")||"[]");O.some(ia=>k.toLowerCase().includes(ia.toLowerCase())?K=!0:!1);U.some(ia=>{let da=k.toLowerCase();
ia=ia.toLowerCase();return da.endsWith(" "+ia)||da===ia?J=!0:!1});if("true"===Y){if(K||J)x=!0}else if(K&&J||K&&0===U.length||J&&0===O.length)x=!0;"string"===typeof g&&(g=[g]);null==w&&(w=5);x=x&&0===l.length||x&&l.includes("9999")||x&&l.some(ia=>g.includes(ia))?!0:!1;"true"===u&&7==t&&h<ba.gold&&(x=!0);Number(r)<w&&("true"!==u||7!=t)&&(x=!1);"false"!==m||"false"!==n||"true"===u&&7==t||(x=!1);1E3>ba.gold&&(Z("AuctionEmpty",1),Z("AuctionMEmpty",1));c&&v&&15==t&&Number(h)<Number(q)&&(0==C||y>=C)&&(0==
E||A>=E)&&(0==I||z>=I)&&(x=!0);x&&c&&Number(h)<Number(q)&&this.L.push([{itemLevel:Ib(b),itemName:k,basis:yb(b),quality:wb(b),price:h},h,e.getAttribute("action"),{auctionid:e.querySelector("input[name=auctionid]").value,qry:e.querySelector("input[name=qry]").value,itemType:e.querySelector("input[name=itemType]").value,itemLevel:e.querySelector("input[name=itemLevel]").value,itemQuality:e.querySelector("input[name=itemQuality]").value,buyouthd:e.querySelector("input[name=buyouthd]").value,bid_amount:h,
bid:e.querySelector("input[name=bid]").value}])}},Tm(b){function c(k){if("string"===typeof k)return k;let g=[];for(let l in k)k.hasOwnProperty(l)&&g.push(encodeURIComponent(l)+"="+encodeURIComponent(k[l]));return g.join("&")}localStorage.getItem("auctionStatus");localStorage.getItem("auctionMStatus");const e=JSON.parse(localStorage.getItem("Timers")),h=()=>{if(0===za.L.length)Z("AuctionEmpty",1),Z("AuctionMEmpty",1),window.location.reload();else{var k=[];for(let g=0;3>g&&0!==za.L.length;g++){let l=
za.L.pop(),q=new Promise((m,n)=>{try{if(Number(l[1])<za.kl){za.kl-=l[1];let r=new XMLHttpRequest;r.open("POST",l[2],!0);r.onreadystatechange=function(){if(r.readyState===XMLHttpRequest.HEADERS_RECEIVED){if(200===r.status){let u=JSON.parse(localStorage.getItem("bidList"))||[];u.push(l[0].itemName);localStorage.setItem("bidList",JSON.stringify(u))}else console.error("Error placing bid:",r.status);m();r.abort()}};r.setRequestHeader("Content-Type","application/x-www-form-urlencoded");const w=c(l[3]);
r.send(w)}else 2==b?(Z("AuctionEmpty",1),Z("auction",e.AuctionCheck||10)):(Z("AuctionMEmpty",1),Z("auctionM",e.AuctionCheck||10)),window.location.reload(),n("Not enough gold")}catch(r){n(r)}});k.push(q)}Promise.all(k).then(()=>{setTimeout(()=>{h()},250)}).catch(()=>{setTimeout(()=>{h()},250)})}};h()}},ha={bag:null,g:null,Rp:null,Zp:localStorage.getItem("smeltIgnorePS"),async start(){const b="true"===localStorage.getItem("RepairBeforeSmelt");var c="513";c=(c=localStorage.getItem("smeltTab"))?(513+
parseInt(c,10)).toString():"513";c=document.querySelector(`[data-bag-number="${c}"]`);if("mod=forge&submod=smeltery"!=rf)Dh("mod=forge&submod=smeltery");else if(c.classList.contains("current")&&tf()){this.slots=await this.u();const e=this.slots.filter(g=>"closed"===g["forge_slots.state"]);this.Lm(this.slots);await this.um(this.slots);const h=JSON.parse(localStorage.getItem("Timers")),k="true"===localStorage.getItem("smelteverything3");c="true"===localStorage.getItem("smeltAnything")?this.qo():"true"===
localStorage.getItem("smelteverything3")?this.ro():this.po();if(0<c.length){for(let {id:g,slot:l,hammerState:q}of c)try{if(b){const m=await uj.Jo(g);if(m&&0!=m)try{await ha.lm(l,m,q,g)}catch{await ha.lm(l,g,q,g)}else await ha.lm(l,g,q,g)}else await ha.lm(l,g,q,g)}catch(m){}window.location.reload()}else 1>c.length&&1==k?(Z("smelt",h.SmeltingNoItem||10),window.location.reload()):0<e.length?await this.pickItems():0<e.length&&"true"===localStorage.getItem("smelteverything3")?ha.move():(Z("smelt",h.SmeltingNoItem||
10),window.location.reload())}else c.click(),tf(()=>this.start())},Ho(b,c){b=JSON.parse(localStorage.getItem("smeltedItems"))||[];b.push(c);localStorage.setItem("smeltedItems",JSON.stringify(b))},po(){const b=this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>h["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let h of c){if(c=this.hm(h)){let k=b.shift();void 0!==k&&e.push({id:h.getAttribute("data-item-id"),slot:k,hammerState:c.hammerState||
"none",matchingRule:c})}if(0===b.length)break}return e},qo(){const b=this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>h["forge_slots.slot"]);var c=Array.from(document.querySelectorAll("#inv .ui-draggable"));let e=[];for(let h of c){if(c=this.hm(h)){let k=b.shift();void 0!==k&&e.push({id:h.getAttribute("data-item-id"),slot:k,hammerState:c.hammerState||"none",matchingRule:c})}if(0===b.length)break}return e},ro(){const b=[2,4,8,1,256,512,48,1024],c=this.slots.filter(e=>"closed"===e["forge_slots.state"]).map(e=>
e["forge_slots.slot"]);return Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(e=>{if(!cc(e))return!1;e=e.getAttribute("data-content-type");return b.includes(Number(e))}).map(e=>({id:e.getAttribute("data-item-id"),slot:c.shift()})).filter(({slot:e})=>void 0!==e)},async lm(b,c,e,h){try{var k=await jQuery.post(T({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:W("sh")});let q;try{var g=JSON.parse(k);if(g.slots[b]&&g.slots[b].formula&&
g.slots[b].formula.rent[2])q=g.slots[b].formula.rent[2];else{for(k=0;k<g.slots.length;k++)if(g.slots[k].formula&&g.slots[k].formula.rent[2]){q=g.slots[k].formula.rent[2];break}q||=3E3}}catch(n){q=3E3}const m=ac(document.querySelector(`[data-item-id='${h}']`));try{if(e&&"none"!==e){const n={bronze:"19-10",silver:"19-11",gold:"19-12"}[e];if(n){var l=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));const r=l.findIndex(u=>u.classList.contains("current")),w=l.slice(r).concat(l.slice(0,
r));h=!1;g=null;for(l=0;l<w.length;l++){let u=w[l];if("false"===u.getAttribute("data-available"))continue;u.click();await new Promise(y=>setTimeout(y,250));const t=document.querySelector(`.item-i-${n}`);if(t){h=!0;g=t;break}}if(h&&g){const u=g.getAttribute("data-container-number"),t=g.getAttribute("data-position-x"),y=g.getAttribute("data-position-y");await jQuery.post(T({mod:"inventory",submod:"move",from:u,fromX:t,fromY:y,to:773,toX:b+1,toY:1,amount:1,doll:1,a:(new Date).getTime(),sh:W("sh")}));
D(`Hammer (${e}) moved to inventory.`)}else D(`Hammer (${e}) not found in any inventory bag.`),D("Proceeding to smelt without a hammer.")}else D("Proceeding to smelt without a hammer.")}}catch(n){}if(q<Fh().gold)await jQuery.post(T({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")})),this.Ho(c,m),P("itemSmelted",0),D(`${d.Pf}`+m),await new Promise(n=>setTimeout(n,250));else{const n=JSON.parse(localStorage.getItem("Timers"));Z("smelt",n.Smelting||10);
window.location.reload()}}catch(q){location.reload()}},async Lo(b,c){var e=await jQuery.post(T({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",slot:b,iid:c,amount:1,a:(new Date).getTime(),sh:W("sh")});e=JSON.parse(e).slots[b].formula.rent[2];e<Fh().gold?jQuery.post(T({mod:"forge",submod:"rent",mode:"smelting",slot:b,rent:2,item:c,a:(new Date).getTime(),sh:W("sh")})).done(function(){var h=JSON.parse(localStorage.getItem("smeltery_itemList1"));({item:h}=h);D(`${d.Qf}`+h.name);window.location.reload()}).fail(function(){D("Problem with smelting, maybe there is not enough space.");
window.location.reload()}):(D(`${d.Rf}`+e),b=JSON.parse(localStorage.getItem("Timers")),Z("smelt",b.SmeltingNoGold||5),window.location.reload())},init:function(){jQuery("#inv").after('\n                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">\n\n                        <fieldset id="gladbot-workbench" style="\n                        padding: 10px;\n                        margin: 10px 20px;\n                        text-align: center;\n                        display: flex;\n                        flex-direction: row;\n                        flex-wrap: wrap;\n                        align-items: center;\n                        justify-content: space-around;\n                        border: 2px solid darkred;\n                        border-radius: 8px;\n                        width: 235px;">\n                        <legend style="\n                            padding: 0 10px;\n                            color: darkred;\n                            font-weight: bold;">GLDbot Smeltery Area</legend>\n                        </fieldset>');
ha.rm("#gladbot-workbench",'<i class="fa fa-fire"></i>',"gladbot-button gladbot-smelter-button-smelt gladbot-stylish-button").mouseup(b=>{ha.Rm(b)});ha.rm("#gladbot-workbench","RESET","gladbot-button gladbot-smelter-button-reset gladbot-stylish-button").mouseup(()=>{localStorage.setItem("activateSmeltMode",!1)});jQuery("#gladbot-workbench").append('<p style="font-size: 0.8em; color: darkred;">Right click to reset smelt mode.</p>')},Rm:async function(){jQuery(document.body).addClass("fire-smelt-cursor");
jQuery(document.body).on("contextmenu",function(b){b.preventDefault();jQuery(document.body).removeClass("fire-smelt-cursor");jQuery(document.body).off("contextmenu");localStorage.setItem("activateSmeltMode",!1)});this.slots=await this.u();localStorage.setItem("activateSmeltMode",!0);jQuery("#inv .ui-draggable, #char .ui-draggable").off("mouseup.smelt").on("mouseup.smelt",async b=>{var c=b.target,e=c.className.match(/item-i-(\d+)-\d+/)[1];(b=this.slots.filter(h=>"closed"===h["forge_slots.state"])[0])?
(e={item:{type:e,name:ac(c),quality:wb(c),slot:b,container:c.getAttribute("data-container-number")},spot:{bag:c.getAttribute("data-container-number"),x:c.getAttribute("data-position-x"),y:c.getAttribute("data-position-y")}},localStorage.setItem("smeltery_itemList1",JSON.stringify(e)),jQuery(c).parents("#char").length?setTimeout(()=>{},1E3):(this.slots=await this.u(),await this.um(this.slots),this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>h["forge_slots.slot"]),c=c.getAttribute("data-item-id"),
e&&await ha.Lo(b["forge_slots.slot"],c))):console.log("No free slot available")})},async u(){try{const b=await jQuery.post(T({}),{mod:"forge",submod:"getSmeltingPreview",mode:"smelting",a:(new Date).getTime(),sh:W("sh")});return JSON.parse(b).slots}catch(b){console.log(b)}},async Lm(b){if("undefined"!==typeof b){let e=[];for(var c=0;c<b.length;c++)if("undefined"!==typeof b[c]["forge_slots.uend"]){let h=1E3*b[c]["forge_slots.uend"];"finished-succeeded"===b[c]["forge_slots.state"]&&(h=0);e.push([h,
b[c].item.name])}localStorage.setItem("smelt.timer",JSON.stringify(e))}},async um(b){const c="true"===localStorage.getItem("smeltLootbox");Array.isArray(b)&&(b=b.filter(e=>"finished-succeeded"===e.state).map(e=>e["forge_slots.slot"]),0<b.length&&!c?(await Promise.all(b.map(e=>ha.Co(e))),await this.u()):0<b.length&&c&&(await Promise.all(b.map(e=>ha.Do(e))),await this.u()))},async Do(b){return jQuery.post("ajax.php",{mod:"forge",submod:"lootbox",mode:"smelting",slot:b,a:(new Date).getTime(),sh:W("sh")})},
async Co(b){return jQuery.post("ajax.php",{mod:"forge",submod:"storeSmelted",mode:"smelting",slot:b,a:(new Date).getTime(),sh:W("sh")})},Vm(){var b=localStorage.getItem("smelt.timer");if(!b)return!0;b=JSON.parse(b).sort((c,e)=>c[0]-e[0]);return 6>b.length||b[0][0]+6E4<(new Date).getTime()},async pickItems(){D(`${d.Sf}`);ha.bag=document.getElementById("inv");ha.g=[];var b=JSON.parse(localStorage.getItem("smeltingSettings"))||[],c=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{},e=new Set(JSON.parse(localStorage.getItem("playerEquipmentIDs")||
"[]")),h=new Set(JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]")),k=!1;for(var g of b){if(!g.isEnabled)continue;if("isUnderworldItem"!==g.condition&&2>g.prefix.length&&2>g.suffix.length)continue;let u=[];var l="";"nameContains"===g.condition&&2<g.prefix.length&&""!==g.prefix.trim()?l=g.prefix.trim():!g.prefix&&"nameContains"===g.condition&&2<g.suffix.length&&""!==g.suffix.trim()&&(l=g.suffix.trim());const t={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};g.colors&&0<
g.colors.length?g.colors.forEach(y=>{y=t[y];void 0!==y&&u.push(y)}):u=Object.values(t);var q=0,m=[];if(2<l.length){for(var n=1;2>=n;n++)m.push(this.$m(n,u[0],l));l=await Promise.all(m);l=[].concat(...l);if(5<=q)break;for(let y of l){if(5<=q)break;l=y.item;m=ac(y.item);ha.g.some(A=>A.id===y.id)||e.has(m)||h.has(m)||!this.hm(l,g,b,c)||(ha.g.push({item:l,id:y.id,hammerState:g.hammerState||"none",matchingRule:g}),q++,k=!0)}if(5<=q)break}else if("isUnderworldItem"===g.condition){D("Looking for underworld items...");
q=0;for(let y of u){if(5<=q)break;m=await this.gm(y);l=[];for(n=1;n<=Math.min(m,10);n++)l.push(n);for(m=0;m<l.length&&!(5<=q);m+=3){n=l.slice(m,m+3).map(async A=>{try{return await this.$m(A,y)}catch(z){return console.error(`Error fetching page ${A}:`,z),[]}});n=await Promise.all(n);for(var r of n){if(5<=q)break;for(var w of r){n=w.item;let A=this.hm(n,g);if(A&&(ha.g.push({item:n,id:w.id,hammerState:A.hammerState||"none",matchingRule:A}),q++,5<=q))break}}}}}}if(!k&&"true"===localStorage.getItem("smeltAnything")){b=
c.itemTypes||[];e=c.hammerState||"none";const u={white:"-1",green:"0",blue:"1",purple:"2",orange:"3",red:"4"};c=(c.colors||[]).map(t=>u[t]);0===c.length&&(c=Object.values(u));h=0;g=await this.gm(c[0]);for(r=1;r<=g&&!(5<=h);r++){w=await this.no(r,c[0]);for(let t of w){if(5<=h)break;w=t.item;q=ac(w);const y=parseInt(wb(w),10);l=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]");m=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");if(!l.includes(q)&&!m.includes(q)){if(Ea.colors&&
0<Ea.colors.length){const A={white:-1,green:0,blue:1,purple:2,orange:3,red:4};q=Object.keys(A).find(z=>A[z]===y);if(!Ea.colors.includes(q))continue}b.includes(w.getAttribute("data-content-type"))&&(ha.g.push({item:w,id:t.id,hammerState:e}),h++,k=!0)}}if(5<=h)break}}k&&0<ha.g.length?await ha.move(ha.g):(D("No items found for smelting."),k=JSON.parse(localStorage.getItem("Timers")),Z("smelt",k.SmeltingNoItem||15),window.location.reload())},async Ap(b,c){b=await jQuery.get(G({mod:"packages",f:"0",fq:c,
qry:"",page:b,sh:W("sh")}));const e=[];jQuery(b).find(".packageItem").each((h,k)=>{h=k.querySelector("input").value;(k=jQuery(k).find(".ui-draggable")[0])&&e.push({id:h,item:k})});return e},lo(b){return b.getAttribute("data-hammer-state")||"none"},async $m(b,c=null,e=""){b={mod:"packages",f:"0",page:b,sh:W("sh")};null!==c&&(b.fq=c);e&&""!==e.trim()&&(b.qry=e.trim());c=await jQuery.get(G(b));const h=[];jQuery(c).find(".packageItem").each((k,g)=>{k=g.querySelector("input").value;(g=jQuery(g).find(".ui-draggable")[0])&&
h.push({id:k,item:g})});return h},async no(b,c=null,e=""){b={mod:"packages",f:"0",fq:null!==c?c:-1,page:b,sh:W("sh")};e&&""!==e.trim()&&(b.qry=e.trim());e=await jQuery.get(G(b));e=jQuery(e).find(".packageItem");const h=[],k=(JSON.parse(localStorage.getItem("smeltRandomlySettings"))||{}).itemTypes||[],g=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]"),l=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");e.each((q,m)=>{const n=m.querySelector("input").value;if(q=jQuery(m).find(".ui-draggable")[0]){m=
ac(q);var r=q.getAttribute("data-content-type");h.some(w=>w.id===n)||g.includes(m)||l.includes(m)||k.includes(r)&&h.push({item:q,id:n})}});return h},async gm(b=null,c="",e="0"){b={mod:"packages",f:e,fq:b||-1,qry:"",page:1,sh:W("sh")};c&&""!==c.trim()&&(b.qry=c.trim());c=await jQuery.get(G(b));b=jQuery(c).find(".paging_right_full");c=1;0<b.length&&(b=b.last().attr("href"))&&(b=b.match(/page=(\d+)(?!.*page=)/))&&b[1]&&(c=parseInt(b[1],10));return c},hm(b){const c="true"===localStorage.getItem("smeltAnything"),
e=JSON.parse(localStorage.getItem("smeltingSettings"))||[],h=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||[];if(!c&&!c&&0===e.length)return!1;const k=ac(b),g=parseInt(b.getAttribute("data-level"),10),l=Hb(b),q=parseInt(wb(b),10);var m=this.lo(b),n=b.getAttribute("data-basis");m=b.getAttribute("data-hash");b.getAttribute("data-level");n=Zb(n,m);m=JSON.parse(localStorage.getItem("playerEquipmentIDs")||"[]");const r=JSON.parse(localStorage.getItem("mercenaryEquipmentIDs")||"[]");if(m.includes(k)||
r.includes(k))return!1;for(let w of e)if(m=w.hammerState||"none",w.isEnabled&&this.Zn(b,w,{itemName:k,itemLevel:g,itemType:l,itemQuality:q,itemHammerState:m,isUnderworldItem:n}))return w;if(c){if(h.itemTypes&&0<h.itemTypes.length&&!h.itemTypes.map(w=>parseInt(w,10)).includes(parseInt(l,10)))return!1;if(h.colors&&0<h.colors.length){const w={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(w).find(u=>w[u]===q);if(!h.colors.includes(b))return!1}return h}return null},Zn(b,c,e){b=e.itemName;
const h=e.itemLevel,k=e.itemType,g=e.itemQuality;e=e.isUnderworldItem;if("nameContains"===c.condition){e=!0;if(0===c.prefix.length&&0===c.suffix.length)return!1;c.prefix&&0<c.prefix.length&&b&&0<b.length&&!b.toLowerCase().includes(c.prefix.toLowerCase())&&(e=!1);c.suffix&&0<c.suffix.length&&b&&0<b.length&&!b.toLowerCase().includes(c.suffix.toLowerCase())&&(e=!1);c.prefix&&0<c.prefix.length&&c.suffix&&0<c.suffix.length&&(!(b&&0<b.length)||b.toLowerCase().includes(c.prefix.toLowerCase())&&b.toLowerCase().includes(c.suffix.toLowerCase())||
(e=!1));if(!e)return!1}else if("isUnderworldItem"===c.condition&&!e)return!1;if(!(h<(c.level?parseInt(c.level,10):0))&&c.itemTypes&&0<c.itemTypes.length){if(!c.itemTypes.includes("9999")&&!c.itemTypes.map(l=>parseInt(l)).includes(parseInt(k,10)))return!1}else return!1;if(c.colors&&0<c.colors.length){const l={white:-1,green:0,blue:1,purple:2,orange:3,red:4};b=Object.keys(l).find(q=>l[q]===g);if(!c.colors.includes(b))return!1}else return!1;return c},rm:function(b,c,e){c=jQuery("<button>").html(c).addClass(e);
jQuery(b).append(c);return c},async move(){var b="513";b=(b=localStorage.getItem("smeltTab"))?(513+parseInt(b,10)).toString():"513";this.slots.filter(h=>"closed"===h["forge_slots.state"]).map(h=>h["forge_slots.slot"]).shift();try{let h=ha.g.pop();var c=Hc(ha.bag);let k=Ic(5,8,c),g=parseInt(h.item.getAttribute("data-measurement-x")),l=parseInt(h.item.getAttribute("data-measurement-y")),q=Jc(l,g,k);c=b;if(q){await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+h.id,fromX:"1",fromY:"1",to:c,toX:q.x+
1,toY:q.y+1,amount:"1"}),{a:(new Date).getTime(),sh:W("sh")});var e=jQuery(h.item).css({left:32*q.x,top:32*q.y});ha.bag.appendChild(e[0]);0<ha.g.length||h?(localStorage.setItem("smeltCheck.timeOut",0),await new Promise(m=>setTimeout(m,500)),await this.move()):window.location.reload()}else if(0<ha.g.length&&!q){D("Not enough space in inventory to smelt.");await new Promise(n=>setTimeout(n,500));await this.move();const m=JSON.parse(localStorage.getItem("Timers"));Z("smelt",m.SmeltingNoItem||15)}else window.location.reload()}catch(h){e=
JSON.parse(localStorage.getItem("Timers")),Z("smelt",e.SmeltingNoItem||15),window.location.reload()}}};window.location.href.includes("index.php?mod=mysterybox")&&(Vh(),Wh());window.location.href.includes("/index.php?mod=forge&submod=smeltery")&&(ha.init(),ha.slots=await ha.u(),await ha.Lm(ha.slots),"true"==localStorage.getItem("activateSmeltMode")&&ha.Rm());try{window.location.href.includes("/index.php?mod=location&submod=serverQuest")&&(window.location.href.includes("submod=serverQuestHighscore&loc=hadrians_wall")||
localStorage.setItem("eventPoints_",parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10)))}catch{localStorage.setItem("doEventExpedition",!1);Dh("mod=overview");return}try{if(window.location.href.includes("/index.php?mod=work")){let b=document.querySelector('span[data-ticker-type="countdown"]');if(b){let c=b.innerText.split(":"),e=6E4*(60*parseInt(c[0],10)+parseInt(c[1],10));await new Promise(h=>setTimeout(h,e))}}}catch{Dh("mod=overview");return}var vj={async start(){const b=
await Promise.all([new Promise(c=>{jQuery.get(G({mod:"overview",doll:"1",sh:W("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");c(!e)})}),new Promise(c=>{jQuery.get(G({mod:"overview",doll:"2",sh:W("sh")}),e=>{e=jQuery(e).find(".avatar")[0].classList.contains("avatar_costume_part");c(!e)})})]);b[0]&&Z("CheckDolls",1);b[1]&&Z("CheckDolls",1)}},gf={async check(b=!1){return new Promise(async c=>{await new Promise(e=>{jQuery.get(G({mod:"overview",doll:"1",sh:W("sh")}),
h=>{localStorage.setItem("arenaCostumeEquiped",jQuery(h).find(".avatar")[0].classList.contains("avatar_costume_part"));e()})});b&&await b();c()})},async start(){if("mod=costumes"!=rf)Dh("mod=costumes");else{let e=localStorage.getItem("costumeUnderworld"),h=localStorage.getItem("costumeUnderworld");const k="true"===localStorage.getItem("wearUnderworld");var b=!1;let g=document.querySelectorAll(".costumes_box"),l=!1,q;const m=localStorage.getItem("costumeUnderworld");b=["9","10","11"];const n=JSON.parse(localStorage.getItem("underworld"));
for(var c of b)try{const r=g[Number(c)-1].querySelector(".costumes_button_single").getAttribute("onclick");if(r&&!r.includes("dropCostume")){l=!0;break}}catch(r){}0<g.length&&null!==m&&(c=Number(m)-1,0<=c&&c<g.length&&(c=g[c].querySelector(".costumes_button_single")||g[c].querySelector(".costumes_button_active_single"))&&(q=c.getAttribute("onclick")));["9","10","11"].includes(e)&&q&&q.includes("dropCostume")?(b=!0,n.hj=!0,localStorage.setItem("underworld",JSON.stringify(n)),Z("CheckDolls",15)):(b=
!1,n.hj=!1,localStorage.setItem("underworld",JSON.stringify(n)));b?(Z("CheckDolls",30),window.location.reload()):await this.check(async()=>{let r=[];if(k){let w=0;const u=["9","10","11"];for(let t of u)try{const y=g[Number(t)-1].querySelector(".costumes_button_single")?.getAttribute("onclick");if(y&&!y.includes("dropCostume")){l=!0;const A=Number(m)-1;0<=A&&A<g.length&&(l=g[A].querySelector(".costumes_button_single")||g[A].querySelector(".costumes_button_active_single")?!0:!1);if(l&&"9"===h&&2>=Number(Fh().Fa)){r.push({doll:1,
setId:Number(h)+2});break}if(l&&"10"===h&&2>=Number(Fh().$n)){r.push({doll:1,setId:Number(h)+2});break}if(l&&"11"===h){r.push({doll:1,setId:Number(h)+2});break}}}catch(y){w++}w===u.length&&D(`${d.xf}`)}try{if(!l){const w=g[Number(localStorage.getItem("costumeBasic")-1)].querySelector("#costumes_button_left input"),u=w.getAttribute("onclick");w.classList.contains("disabled")||u.includes("dropCostume")||r.push({doll:1,setId:localStorage.getItem("costumeBasic")});if(8>=Number(localStorage.getItem("costumeDungeon"))){const t=
g[Number(localStorage.getItem("costumeDungeon")-1)].querySelector("#costumes_button_right input"),y=t.getAttribute("onclick");t.classList.contains("disabled")||y.includes("dropCostume")||r.push({doll:2,setId:localStorage.getItem("costumeDungeon")})}}if(0<r.length){let {doll:w,setId:u}={...r.pop()};(await fetch(G({mod:"costumes",submod:"changeCostume",doll:w,setId:u,sh:W("sh")}))).ok&&0<r.length&&9>Number(u)&&await gf.Ym(r);Z("CheckDolls",30)}else Z("CheckDolls",15);window.location.reload()}catch{Z("CheckDolls",
15),window.location.reload(),D("Problem occurred while wearing a costume.")}})}},async Ym(b,c=!1){let {doll:e,setId:h}={...b.pop()};await new Promise(k=>{jQuery.get(G({mod:"costumes",submod:"changeCostume",doll:e,setId:h,sh:W("sh")}),()=>{0<b.length?gf.Ym(b,c):(Z("CheckDolls",15),k())})})}};let z2=localStorage.getItem("we");we=new Date(z2);ea<new Date&&we<new Date&&ca!=va&&hb();if(ra&&"true"===localStorage.getItem("guildBattleEnable")&&X("guildBattleEnable"))try{const b="true"===localStorage.getItem("guildBattleRandom"),c=JSON.parse(localStorage.getItem("guildKeywords"))||
[],e=await jQuery.get(G({mod:"guild_warcamp",sh:W("sh")})),h=(new DOMParser).parseFromString(e,"text/html"),k=h.querySelectorAll('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]'),g=h.querySelectorAll("table.section-like tr:not(:first-child)");let l=null;0<g.length&&0<c.length?g.forEach(q=>{const m=q.querySelector('td a[href*="mod=guild"]');q=q.querySelector('a[href*="mod=guild_warcamp&submod=guild_combat&gid="]');if(m&&q){const n=m.textContent.trim().toLowerCase();c.some(r=>n.includes(r.toLowerCase()))&&
(l=q.getAttribute("href"))}}):b&&(l=k[Math.floor(Math.random()*k.length)].getAttribute("href"));if(l){const q=new URLSearchParams(l),m=q.get("gid"),n=q.get("sh");try{await jQuery.post(G({mod:"guild_warcamp",submod:"guild_combat",gid:m,sh:n}),{combat:"Attack!"});D(`Guild attack initiated against guild ID: ${m}`);const r=JSON.parse(localStorage.getItem("Timers"))||{};Z("guildBattleEnable",r.guildBattleEnable||120)}catch(r){D("Error initiating guild attack")}}else D("No matching guilds found for the provided guild names.")}catch(b){D("Error loading guild warcamp page")}if(ra&&
"true"===localStorage.getItem("GuildEnable")&&X("GuildDonate")){const b=parseInt(localStorage.getItem("GuildDonateMore")||0,10),c=parseInt(localStorage.getItem("GuildDonateLess")||0,10),e=parseInt(localStorage.getItem("GuildDonateAmount")||0,10);if(ba.gold>=b&&ba.gold<=c){await jQuery.post(G({mod:"guildBankingHouse",submod:"donate",sh:W("sh")}),{donation:e,doDonation:"Donate"});D(`${d.zf} ${e}.`);const h=JSON.parse(localStorage.getItem("Timers"));Z("GuildDonate",h.GuildDonate||5)}}"true"===localStorage.getItem("throwDice")&&
X("throwDice")&&"true"==sessionStorage.getItem("autoGoActive")&&(jQuery.post(window.location.protocol+"//"+window.location.host+"/game/ajax/craps.php",{type:"1",a:(new Date).getTime(),sh:W("sh")}),D(`${d.yf}`),Z("throwDice",10));if(X("sortSettings")&&"true"==sessionStorage.getItem("autoGoActive")){const b=await jQuery.get(G({mod:"settings",submod:"gameSettings",sh:W("sh")})),c=(new DOMParser).parseFromString(b,"text/html").querySelector('select[name="packageSorting"]');let e="in_desc";if(c){const h=
c.querySelector("option[selected]");e=h?h.value:"in_desc"}Z("sortSettings",30);localStorage.setItem("PackageSort",e)}if(window.location.href.includes("index.php?mod=location&loc=")){let b=0,c=!1;const e=()=>{fetch(window.location.href).then(m=>m.text()).then(m=>{m=(new DOMParser).parseFromString(m,"text/html");if(m=Array.from(m.querySelectorAll("img[data-tooltip]")).find(n=>{const r=n.getAttribute("data-tooltip").toLowerCase();return["owned","sahip","propri","posiad","posees"].some(w=>r.includes(w))}))m=
(m=m.getAttribute("data-tooltip").match(/(Owned|Sahip[^:]*|Propri[^:]*|Posiad[^:]*|Posees[^:]*): (\d+)/i))?parseInt(m[2],10):100,document.getElementById("hourglassesLeft").textContent=m,localStorage.setItem("hourglassesLeft",m)}).catch(()=>{D("No hourglass left")})},h=(m,n,r,w,u,t)=>{function y(E){return new Promise((I,K)=>{fetch(`${z}/game/index.php?mod=premium&submod=inventory&sh=${x}`).then(J=>J.text()).then(J=>{if(J=(new DOMParser).parseFromString(J,"text/html").querySelector(`div.premiumfeature_picture > img[src*="${E}"] + .premiumfeature_tokencount`))return J.textContent.trim();
throw Error("Token value not found!");}).then(J=>fetch(`${z}/game/index.php?mod=premium&submod=inventoryActivate&feature=${"5fd403b4efa8ea7bc3ca5a852bfce9"===E?18:5}&token=${J}&sh=${x}`)).then(()=>{I()}).catch(J=>{K(J)})})}if(!c||b>=t)g();else{var A=new URL(window.location.href),z=A.origin,x=A.searchParams.get("sh")||"",v=document.getElementById("useLifePotion").checked;w=document.getElementById("useMobilizationExp2").checked;var C=parseInt(document.getElementById("healPercentage2").value,10);A=new URLSearchParams({mod:"location",
submod:"attack",location:m,stage:n,premium:r?1:0,a:Date.now(),sh:x});fetch(`${z}/game/ajax.php?${A.toString()}`).then(E=>E.text()).then(()=>{(v||w)&&fetch(window.location.href).then(E=>E.text()).then(async E=>{E=(new DOMParser).parseFromString(E,"text/html");if(v){const I=parseInt(E.getElementById("header_values_hp_percent").textContent,10);if(Number(I)<Number(C))return await y("5fd403b4efa8ea7bc3ca5a852bfce9")}if(w&&(E=E.getElementById("expeditionpoints_value_point").innerText,0===Number(parseInt(E.replace("%",
""),10))))return await y("c9ce614bbc67a9e85aa0ee87cf2bb7")}).then(async()=>{b++;b>=Number(t)?(g(),window.location.reload()):(document.getElementById("attacksPerformed").textContent=b,localStorage.setItem("attackCount",b),await e(),setTimeout(async()=>{await h(m,n,r,w,u,t)},1E3*u))}).catch(()=>{})})}},k=async()=>{c=!0;document.getElementById("startExpedition").style.display="none";document.getElementById("stopExpedition").style.display="block";const m=(new URLSearchParams(window.location.search)).get("loc"),
n=document.getElementById("monsterSelection").value,r=document.getElementById("useHourglass").checked,w=document.getElementById("attackInterval").value,u=document.getElementById("numberOfAttacks").value;await h(m,n,r,useMobilizationExp2,w,u)},g=()=>{c=!1;document.getElementById("startExpedition").style.display="block";document.getElementById("stopExpedition").style.display="none"},l=()=>{var m=document.createElement("div");m.innerHTML=`
    <div class="expedition-settings">
      <h2 class="section-header">${d.Le}</h2>
      <div class="expedition-settings-content">
        <div>
            <label>${d.Ie}: </label>
            <select id="monsterSelection">
            <option value="1">${d.Ae}</option>
            <option value="2">${d.Be}</option>
            <option value="3">${d.Ce}</option>
            <option value="4">${d.De}</option>
            </select>
            <br>
            <label>${d.we}: </label>
            <input type="checkbox" id="useHourglass">
            <br>
            <label>${d.ze}: </label>
            <input type="checkbox" id="useMobilizationExp2">
            <br>
            <label>${d.ye}: </label>
            <input type="checkbox" id="useLifePotion">
            <br>
            <label>${d.ve}: </label>
            <input type="number" id="healPercentage2" value="25" min="1" max="99">
            <br>
            <label>${d.Ge}: </label>
            <input type="number" id="numberOfAttacks" value="${document.getElementById("expeditionpoints_value_point").textContent||"0"}" min="1" max="36">
            <br>
            <label>${d.xe}: </label>
            <input type="number" id="attackInterval" value="5" min="1" max="60">
            <br>
            <button id="startExpedition" class="expedition-button">${d.Je}</button>
            <button id="resetAttacks" class="expedition-button reset-button">${d.He}</button>
            <button id="stopExpedition" class="expedition-button" style="display: none;">${d.Ke}</button>
            <div id="attackLog"></div>
        </div>
      </div>
    </div>
  `;var n=document.querySelector(".section-header");n.parentNode.insertBefore(m,n);m.querySelector(".section-header").addEventListener("click",()=>{const r=document.querySelector(".expedition-settings-content"),w="none"===r.style.display;r.style.display=w?"block":"none";localStorage.setItem("expeditionSettingsHidden",w?"false":"true")});m=m.querySelector(".expedition-settings-content");n="true"===localStorage.getItem("expeditionSettingsHidden");m.style.display=n?"none":"block";document.getElementById("resetAttacks").addEventListener("click",
()=>{b=0;localStorage.removeItem("attackCount");document.getElementById("attacksPerformed").textContent=b});document.getElementById("startExpedition").addEventListener("click",k);document.getElementById("stopExpedition").addEventListener("click",g);b=parseInt(localStorage.getItem("attackCount")||"0");document.getElementById("attackLog").innerHTML=`
            ${d.te}: <span id="attacksPerformed">${b}</span><br>
            ${d.ue}: <span id="hourglassesLeft">${localStorage.getItem("hourglassesLeft")||"0"}</span><br>
            <span class="span-new">${d.Ee}</span><br>
            <span class="span-new">${d.Fe}</span>

            `};if(window.location.href.includes("index.php?mod=location&loc=")&&!window.location.href.includes("location&loc=nile_bank")&&!window.location.href.includes("index.php?mod=location&loc=false")&&!window.location.href.includes("location&loc=desert")){const m=document.querySelector("#wrapper_game.underworld");(JSON.parse(localStorage.getItem("underworld"))||{}).isUnderworld||m||l()}const q=document.createElement("style");q.innerHTML="\n  .expedition-settings {\n    border: 2px solid #4CAF50;\n    padding: 10px;\n    margin: 10px 0;\n    background-color: #d3c195;\n    border-radius: 5px;\n  }\n  .expedition-button {\n    border: none;\n    padding: 10px 20px;\n    text-align: center;\n    text-decoration: none;\n    display: inline-block;\n    font-size: 16px;\n    margin: 10px;\n    background-color: #a09270;\n    cursor: pointer;\n    border-radius: 5px;\n  }\n\n  .reset-button {\n    background-color: #f44336; /* Red color */\n  }\n\n  .expedition-button:disabled {\n    background-color: #ccc;\n    cursor: not-allowed;\n  }\n";
document.head.appendChild(q)}if(window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&submod=showDungeons")||window.location.href.includes("index.php?mod=reports&submod=showArena")||window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")){let b=document.createElement("div");b.id="ReportSearchUI";b.innerHTML='\n        <div class="setting-row">\n            <h5>GLDbot - Search in Reports</h5>\n            <span>Searches for reports containing the specified keyword and gold amount. Limit 15 pages.</span>\n            <br>\n            <div class="input-container">\n                <input type="text" id="searchReports" placeholder="Enter keyword">\n                <input type="number" id="goldFilter" placeholder="Minimum gold">\n                <button class="awesome-button" id="searchReportsButton">Search</button>\n            </div>\n        </div>\n    ';
const c=document.querySelector("#content");c.insertBefore(b,c.firstChild);document.getElementById("searchReportsButton").addEventListener("click",async()=>{const g=document.getElementById("searchReports").value,l=parseInt(document.getElementById("goldFilter").value,10)||0,q=document.getElementById("searchReportsButton");q.disabled=!0;try{await e(g,l)}finally{q.disabled=!1}});async function e(g,l){let q=1;var m=await jQuery.get(window.location.href);m=jQuery(m).find(".paging_right_full");0<m.length&&
(m=m.last().attr("href"))&&(m=m.match(/page=(\d+)(?!.*page=)/))&&m[1]&&(q=parseInt(m[1],10));m=[];for(let r=1;r<=q&&15>=r;r++){var n=await h(r);n=k(n,g,l);0<n.length&&(m=m.concat(n))}if(0<m.length){const r=document.querySelector(".table-container tbody");r.innerHTML="";m.forEach(w=>{r.appendChild(w)})}}async function h(g){let l="";window.location.href.includes("index.php?mod=reports&submod=showArena")?l="showArena":window.location.href.includes("index.php?mod=reports&submod=showCircusTurma")?l="showCircusTurma":
window.location.href.includes("index.php?mod=reports&submod=showDungeons")?l="showDungeons":window.location.href.includes("index.php?mod=reports&showExpeditions")&&(l="showExpeditions");g=G({mod:"reports",submod:l,page:g,sh:W("sh")});return await jQuery.get(g)}function k(g,l,q){let m=[];jQuery(g).find(".table-container tr").each((n,r)=>{var w=jQuery(r);n=window.location.href.includes("index.php?mod=reports&showExpeditions")||window.location.href.includes("index.php?mod=reports&showDungeons")?w.find("td").eq(1).text().trim():
w.find("td").eq(1).find("a").first().text().trim();w=w.find("td").eq(2).text().trim().replace(/[.,]/g,"");w=parseInt(w,10)||0;n.toLowerCase().includes(l.toLowerCase())&&w>=q&&m.push(r)});return m}}if(window.location.href.includes("/index.php?mod=overview&doll=2")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(c=>ac(c));localStorage.setItem("mercenaryEquipmentIDs",JSON.stringify(b))}else if(window.location.href.includes("/index.php?mod=overview")){const b=Array.from(document.querySelectorAll("#char [data-soulbound-to]")).map(c=>
ac(c));localStorage.setItem("playerEquipmentIDs",JSON.stringify(b))}if(window.location.href.includes("/index.php?mod=inventory&sub")&&document.querySelector('td[valign="top"]')){let b=!0;async function c(){var n=document.getElementById("sortCriteria");let r=Array.from(n.selectedOptions).map(y=>y.value),w=document.getElementById("shop");n=Array.from(w.querySelectorAll(".ui-draggable")).map(y=>{let A=ac(y),z=parseInt(y.getAttribute("data-level"),10)||0,x=y.getAttribute("data-basis")||"",v=parseInt(x.split("-")[1],
10)||0,C=parseInt(y.getAttribute("data-quality"),10)||0,E=parseInt(y.getAttribute("data-content-type"),10)||0,I=parseInt(y.getAttribute("data-measurement-x"),10)||1,K=parseInt(y.getAttribute("data-measurement-y"),10)||1;return{element:y,name:A,level:z,cc:x,type:E,Xm:v,quality:C,measurementX:I,measurementY:K,Np:parseInt(y.getAttribute("data-position-x"),10),Op:parseInt(y.getAttribute("data-position-y"),10)}});n.sort((y,A)=>{for(let z of r){let x;switch(z){case "name":x=y.name.localeCompare(A.name);
break;case "level":x=y.level-A.level;break;case "data-basis":x=y.Xm-A.Xm;break;case "quality":x=y.quality-A.quality;break;case "type":x=y.type-A.type;break;default:x=0}if(0!==x)return x}return 0});let u=0,t=0;for(let y of n)y.element.setAttribute("data-position-x",u+1),y.element.setAttribute("data-position-y",t+1),y.element.style.left=`${32*u}px`,y.element.style.top=`${32*t}px`,u+=y.measurementX,6<=u&&(u=0,t+=1);w.innerHTML="";n.forEach(y=>{w.appendChild(y.element)})}(function(){let n=`
                <section class="merchant-settings" style="display: block;">
                    <div class="sorting-options">
                        <label for="sortCriteria">Sort Items By:</label>
                        <select id="sortCriteria">
                            <option value="name">Name</option>
                            <option value="level">Level</option>
                            <option value="data-basis">Base</option>
                            <option value="type">Type</option>
                            <option value="quality">Quality</option>
                        </select>
                        <button class="awesome-button" type="button" id="sortItemsButton">Sort Items</button>
                        
                    </div>
                    <p>
                    <div class="actions">
                        <button class="awesome-button" type="button">${d.Hj}</button>
                        <button class="awesome-button" type="button">${d.Ij}</button>
                        <button class="awesome-button" type="button">Buy All</button>
                        <button class="awesome-button" type="button">Buy 10</button>
                    </div>
                    <ul class="compact-list">
                        <li><input type="checkbox" id="chkWeapons"><label for="chkWeapons">${d.fa}</label></li>
                        <li><input type="checkbox" id="chkShields"><label for="chkShields">${d.ca}</label></li>
                        <li><input type="checkbox" id="chkChestArmour"><label for="chkChestArmour">${d.U}</label></li>
                        <li><input type="checkbox" id="chkHelmets"><label for="chkHelmets">${d.X}</label></li>
                        <li><input type="checkbox" id="chkGloves"><label for="chkGloves">${d.W}</label></li>
                        <li><input type="checkbox" id="chkShoes"><label for="chkShoes">${d.da}</label></li>
                        <li><input type="checkbox" id="chkRings"><label for="chkRings">${d.aa}</label></li>
                        <li><input type="checkbox" id="chkAmulets"><label for="chkAmulets">${d.T}</label></li>
                        <li><input type="checkbox" id="chkUsable"><label for="chkUsable">${d.wi}</label></li>
                        <li><input type="checkbox" id="chkUpgrades"><label for="chkUpgrades">${d.vi}</label></li>
                        <li><input type="checkbox" id="chkRecipes"><label for="chkRecipes">${d.Xg}</label></li>
                        <li><input type="checkbox" id="chkMercenary"><label for="chkMercenary">${d.mg}</label></li>
                        <li><input type="checkbox" id="chkScroll"><label for="chkScroll">Scroll</label></li>
                        <li><input type="checkbox" id="chkReinforcements"><label for="chkReinforcements">${d.Zg}</label></li>
                    </ul>
                </section>
                `;document.getElementById("inv").insertAdjacentHTML("afterend",n)})();async function e(){if(b){var n=Array.from(document.querySelectorAll("#inv .ui-draggable")).filter(r=>{r=r.getAttribute("data-content-type");if(document.getElementById("chkWeapons").checked&&"2"==r||document.getElementById("chkShields").checked&&"4"==r||document.getElementById("chkChestArmour").checked&&"8"==r||document.getElementById("chkHelmets").checked&&"1"==r||document.getElementById("chkGloves").checked&&"256"==
r||document.getElementById("chkShoes").checked&&"512"==r||document.getElementById("chkRings").checked&&"48"==r||document.getElementById("chkAmulets").checked&&"1024"==r||document.getElementById("chkUsable").checked&&"4096"==r||document.getElementById("chkUpgrades").checked&&"4096"==r||document.getElementById("chkRecipes").checked&&"8192"==r||document.getElementById("chkMercenary").checked&&"16384"==r||document.getElementById("chkScroll").checked&&"64"==r||document.getElementById("chkReinforcements").checked&&
"4096"==r)return!0;if(b)return!1});for(let r=0;r<n.length&&b;r++)await new Promise(w=>setTimeout(w,200)),Ha(n[r],"shop")}}async function h(){if(b){var n=document.querySelectorAll("#inv .ui-draggable");for(let r=0;r<n.length;r++)await new Promise(w=>setTimeout(w,200)),Ha(n[r],"shop")}}async function k(){if(b){var n=document.querySelectorAll("#shop .ui-draggable");for(let r=0;r<n.length;r++)await new Promise(w=>setTimeout(w,200)),Ha(n[r],"inv")}}async function g(){if(b){var n=document.querySelectorAll("#shop .ui-draggable");
for(let r=0;10>r;r++)await new Promise(w=>setTimeout(w,200)),Ha(n[r],"inv")}}let l=document.querySelector(".actions .awesome-button:nth-child(2)"),q=document.querySelector(".actions .awesome-button:nth-child(3)"),m=document.querySelector(".actions .awesome-button:nth-child(4");document.querySelector(".actions .awesome-button:nth-child(1)").addEventListener("click",async()=>{b=!0;await new Promise(n=>setTimeout(n,500));h()});l.addEventListener("click",async()=>{b=!0;await new Promise(n=>setTimeout(n,
500));e()});q.addEventListener("click",async()=>{await new Promise(n=>setTimeout(n,500));k()});m.addEventListener("click",async()=>{await new Promise(n=>setTimeout(n,500));g()});document.getElementById("sortItemsButton").addEventListener("click",async()=>{await new Promise(n=>setTimeout(n,500));await c()})}if(window.location.href.includes("/index.php?mod=player&p")||window.location.href.includes("/index.php?mod=player&doll"))if(ef=document.querySelector(".playername.ellipsis")||document.querySelector(".playername_achievement.ellipsis"),
vb=ef.textContent.trim(),2<vb.length){ff=document.getElementById("char");function b(c,e,h,k){var g=document.createElement("a");g.className="gladbot-button gladbot-"+c;g.textContent=e;g.setAttribute("data-tooltip",h);ff.appendChild(g);(JSON.parse(localStorage.getItem(k))||[]).includes(vb)&&(g.classList.add("added"),g.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));g.addEventListener("click",function(){var l=vb,q=JSON.parse(localStorage.getItem(k))||[],m=q.indexOf(l);
-1!==m?(q.splice(m,1),g.classList.remove("added"),g.setAttribute("data-tooltip","Add to "+("autoAttackList"===k?"Arena":"Circus"))):(q.push(l),g.classList.add("added"),g.setAttribute("data-tooltip","Remove from "+("autoAttackList"===k?"Arena":"Circus")));localStorage.setItem(k,JSON.stringify(q))})}b("arena","A","GladB: Add to Arena List","autoAttackList");b("circus","C","GladB: Add to Circus List","autoAttackCircusList")}var Qc=JSON.parse(localStorage.getItem("smeltingSettings"))||[],Ea=JSON.parse(localStorage.getItem("smeltRandomlySettings"))||
{itemTypes:[],colors:[],hammerState:"none",enabled:!1},ic=JSON.parse(localStorage.getItem("resetColors"))||{colors:[]};"true"==localStorage.getItem("pauseBotEnable")&&X("pauseBot")&&(sessionStorage.setItem("autoGoActive","false"),localStorage.setItem("pauseBotEnable","false"),alert("Bot has been paused!"),window.location.reload());1==ra&&X("storeForgeResources")&&cj();!0===ra&&X("Training")&&"true"==localStorage.getItem("trainEnable")&&ej()&&await dj();"true"===sessionStorage.getItem("autoGoActive")&&
cb.href.includes("submod=showCombatReport")&&fj();if("true"===localStorage.getItem("HighlightUnderworldItems")){function b(e){e.querySelectorAll("div[data-basis]").forEach(h=>{const k=h.getAttribute("data-basis"),g=h.getAttribute("data-hash");h.getAttribute("data-level");null!=k&&Zb(k,g)&&(h.style.boxShadow="0 0 0.1px 2px red")})}b(document);const c=new MutationObserver(e=>{e.forEach(h=>{h.addedNodes&&h.addedNodes.forEach(k=>{1===k.nodeType&&b(k)})});c.disconnect()});c.observe(document.body,{childList:!0,
subtree:!0});document.querySelectorAll(".awesome-tabs").forEach(e=>{e.addEventListener("click",()=>{setTimeout(()=>{b(document)},500)})})}if("true"==localStorage.getItem("AutoAuction")){const b=JSON.parse(localStorage.getItem("searchTerms")||"[]"),c=JSON.parse(localStorage.getItem("SearchTypes")||"[]"),e=JSON.parse(localStorage.getItem("Timers")),h=new DOMParser;function k(m,n,r){let w=[],u=[];Array.from(m).forEach(t=>{const y=t.getAttribute("data-tooltip");var A=t.getAttribute("data-content-type");
const z=t.getAttribute("data-quality"),x=n.some(v=>{const C=bf(y);return C?C.toLowerCase().split(/\s+/).includes(v.toLowerCase()):!1});A=r.includes("9999")||r.includes(A);"2"==z||"3"==z?u.push(t):x&&A&&w.push(t)});return{zn:w,Cn:u}}if(X("ShopSearch")){const m=await Lf();let n=[],r=[];for(const t of m){const y=k(t.querySelectorAll("#shop .ui-draggable"),b,c);y.zn.forEach(A=>{A.setAttribute("data-original-url",t.Jm)});y.Cn.forEach(A=>{A.setAttribute("data-original-url",t.Jm)});n=n.concat(y.zn);r=r.concat(y.Cn)}const w=
n.map(t=>t.outerHTML);localStorage.setItem("MatchingShopItems",JSON.stringify(w));const u=r.map(t=>t.outerHTML);localStorage.setItem("UniqueShopResults",JSON.stringify(u));Z("ShopSearch",e.SearchTimer||5)}if(X("AuctionSearch")){const m=await hh(),n=await hh(3),r=t=>Array.from(t.querySelectorAll('#auction_table [class^="item-i-"]')).filter(y=>{const A=y.getAttribute("data-tooltip");var z=y.getAttribute("data-content-type");y=b.some(x=>{const v=bf(A);return v?v.toLowerCase().split(/\s+/).includes(x.toLowerCase()):
!1});z=c.includes("9999")||c.includes(z);return y&&z}),w=r(m);localStorage.setItem("MatchingAuctionItems",JSON.stringify(w.map(t=>t.outerHTML)));const u=r(n);localStorage.setItem("MatchingMercAuctionItems",JSON.stringify(u.map(t=>t.outerHTML)));Z("AuctionSearch",e.SearchTimer||5)}function g(m,n,r){const w=document.createElement("div");w.setAttribute("id",r);w.classList.add("search_results_panel");var u=document.createElement("div");u.classList.add("panel-header");u.innerHTML=`<h2>${m}</h2>`;w.appendChild(u);
w.style.cssText="\n                position: fixed;\n                left: 0;\n                top: 0;\n                width: 300px;\n                height: 400px; /* Set a default height */\n                overflow-y: auto; /* Allow both vertical and horizontal scrolling if needed */\n                overflow-x: hidden;\n                z-index: 500;\n                box-shadow: 0px 0px 15px 2px rgba(0, 0, 0, 0.3);\n                font-family: 'Arial', sans-serif;\n                background: rgba(221, 213, 180, 0.95);\n                background-size: cover;\n                border-radius: 8px;\n            ";
m=w.querySelector(".panel-header");m.style.cssText=`
                background-color: ${"auction_items_panel"===r?"#bead79":"#8b6a45"};
                padding: 10px;
                cursor: move; /* Set cursor to move only on the header */
                user-select: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            `;m.querySelector("h2").style.cssText="\n                margin: 0;\n                font-size: 16px;\n                color: #fff;\n            ";m=localStorage.getItem(`${r}_top`);u=localStorage.getItem(`${r}_left`);let t=localStorage.getItem(`${r}_width`),y=localStorage.getItem(`${r}_height`);m&&u?(w.style.top=m+"px",w.style.left=u+"px"):"auction_items_panel"===r?(w.style.top="50px",w.style.left="20px"):"shop_items_panel"===r&&(w.style.top="50px",w.style.left="350px");t&&(w.style.width=
t+"px");y&&(w.style.height=y+"px");q(w,r);n=l(n);w.appendChild(n);document.body.appendChild(w);w.style.maxHeight=`${window.innerHeight-100}px`}function l(m){const n=document.createElement("div");n.classList.add("items-container");m.forEach(({key:r,label:w})=>{const u=document.createElement("div");u.classList.add("section-header");u.textContent=w;n.appendChild(u);const t=document.createElement("div");t.classList.add("grid-container");t.style.display="grid";t.style.gridTemplateColumns="repeat(auto-fill, minmax(50px, 1fr))";
t.style.Bp="5px";t.style.padding="10px";w=localStorage.getItem(r);(JSON.parse(w)||[]).forEach(y=>{const A=h.parseFromString(y,"text/html").body.firstChild.cloneNode(!0);A.style.left="";A.style.top="";A.style.position="relative";y=A.getAttribute("data-tooltip");var z=JSON.parse(y.replace(/&quot;/g,'"'));y=z[0][0][1].split(";")[0];const x=encodeURIComponent(z[0][0][0].split(" ")[0]);z=new URL(window.location.href);const v=z.origin,C=z.searchParams.get("sh")||"";z=document.createElement("div");z.classList.add("auction_item_div");
z.appendChild(A);z.style.border="2px solid "+y;z.style.borderRadius="4px";z.style.padding="2px";z.style.boxSizing="border-box";z.style.cursor="pointer";z.style.transform="scale(0.8)";z.addEventListener("click",()=>{var E=A.getAttribute("data-hash");localStorage.setItem("highlightedItemHash",E);if(["UniqueShopResults","MatchingShopItems"].includes(r)){if(E=A.getAttribute("data-original-url"))location.href=E}else E=`${v}/game/index.php?mod=auction&qry=${x}&itemLevel=1&itemType=0&itemQuality=-1&sh=${C}`,
"MatchingMercAuctionItems"===r&&(E+="&ttype=3"),location.href=E});t.appendChild(z)});n.appendChild(u);n.appendChild(t)});return n}function q(m,n){const r=m.querySelector(".panel-header");$(m).draggable({handle:r,op:"window",stop:function(w,u){localStorage.setItem(`${n}_top`,u.position.top);localStorage.setItem(`${n}_left`,u.position.left)}});$(m).resizable({Cp:"n, e, s, w, ne, se, sw, nw",stop:function(w,u){localStorage.setItem(`${n}_width`,u.size.width);localStorage.setItem(`${n}_height`,u.size.height)}})}
(function(){document.querySelectorAll(".search_results_panel").forEach(m=>m.remove());g(`${d.Ua}`,[{key:"MatchingAuctionItems",label:`${d.Ua}`},{key:"MatchingMercAuctionItems",label:`${d.lg}`}],"auction_items_panel");g(`${d.Tb}`,[{key:"MatchingShopItems",label:`${d.Tb}`},{key:"UniqueShopResults",label:`${d.ui}`}],"shop_items_panel")})()}if(document.hidden)try{chrome.runtime.sendMessage({qn:!0,tm:"https://raw.githubusercontent.com/fociisoftware/glbt/main/aud.mp3"})}catch(b){}var wj=btoa("autoGoActive"),
xj=btoa("false");await async function(){"1053ee3c3765c56873cec9b5a19ff900d5100b930657ec8adf6a1fc859e8ae22"!==await gj(ma)&&sessionStorage.setItem(atob(wj),atob(xj))}();setInterval(()=>{const b=JSON.parse(localStorage.getItem("timeConditions"))||[];var c="true"===localStorage.getItem("botPaused");if(b&&0<b.length&&!c&&Lc()){c=new Date;const e=`${String(c.getHours()).padStart(2,"0")}:${String(c.getMinutes()).padStart(2,"0")}`;b.forEach(h=>{h.start&&h.end&&(h.start>h.end?e>=h.start||e<=h.end:e>=h.start&&
e<=h.end)&&("stop"===h.action?sessionStorage.setItem("autoGoActive","false"):"start"===h.action&&"false"===sessionStorage.getItem("autoGoActive")&&(sessionStorage.setItem("autoGoActive","true"),cf()))})}},15E3);var Wb=(new Date).getTime();if(!va!==Mc){"true"===localStorage.getItem("activateAuction2")&&qf();var hf={Sm(b){let c=localStorage.getItem("MarketboughtItems");c?c=JSON.parse(c):c=[];c.push(b);localStorage.setItem("MarketboughtItems",JSON.stringify(c))},gq(){var b=localStorage.getItem("boughtItems");
b?b=JSON.parse(b):b=[];let c=document.getElementById("boughtItems");for(;c.firstChild;)c.removeChild(c.firstChild);for(let e of b)b=document.createElement("option"),b.textContent=e,c.appendChild(b)},async Tn(){var b=new URL(window.location.href),c=b.origin;const e=b.searchParams.get("sh")||"";b=parseInt(localStorage.getItem("MarketHoldGold"))||0;let h=localStorage.getItem("marketItems");h=h?JSON.parse(h):[];const k={ep:"1",$o:"2",So:"3",Vo:"4",Uo:"5",ap:"8",Yo:"6",Qo:"9",cp:"7",Ro:"11",bp:"12",Xo:"13",
Wo:"15",To:"18",mp:"19",Zo:"20"},g={Ln:"-1",Fn:"0",Dn:"1",Hn:"2",Gn:"3",In:"4"};D(`${d.wf}`);const l={};if("true"===localStorage.getItem("marketOnlyFood"))c=await this.Zm(c,e,"-1"),await this.rn([],7,1,c,b);else{for(var q of h){const m=`${k[q.itemType]||"0"}-${g[q.km]||"0"}`;l[m]||(l[m]=[]);l[m].push(q)}q=h.map(m=>g[m.km]||"0");q=Math.min(...q);c=await this.Zm(c,e,q);for(const [m,n]of Object.entries(l)){const [r,w]=m.split("-");await this.rn(n,r,w,c,b)}}},async Zm(b,c,e){const h="true"===localStorage.getItem("marketOnlyFood");
let k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=0&fq=${e}`;h&&(k=`${b}/game/index.php?mod=market&sh=${c}&qry=&seller=&fl=0&f=7&fq=${e}`);c=await fetch(k).then(z=>z.text());b=new DOMParser;e=b.parseFromString(c,"text/html").querySelector(".standalone");c=1;e&&(c=parseInt(e.textContent.split("/")[1],10));e=[];const g=localStorage.getItem("MarketMaxFoodPrice")||1E5,l=localStorage.getItem("MarketMaxPerFoodPrice")||1E3,q=localStorage.getItem("MarketMinItemLevel")||1;let m=0;for(let z=
1;z<=c;z++){var n=`${k}&p=${z}`;await new Promise(x=>setTimeout(x,250));n=await (await fetch(n)).text();await new Promise(x=>setTimeout(x,250));n=b.parseFromString(n,"text/html").querySelectorAll("#market_item_table tr");for(let x of n){var r=x.querySelectorAll("td");if(r&&0<r.length&&(n=r[0].querySelector("div"))){var w=Hb(n),u=wb(n),t=ac(n),y=Ib(n);let v=n.getAttribute("data-item-id"),C=n.getAttribute("data-soulbound-to");r=parseInt(r[2].innerText.replace(/\./g,""),10);var A=parseInt(n.getAttribute("data-amount"),
10)||1;A=r/A;if(h&&"64"===w&&r<=l&&(!C||null===C)&&Number(y)>=Number(q)){if(m+r>g)break;m+=r;e.push({itemRarity:u,itemName:t,itemDataId:v,itemSoulbound:C,itemPrice:r,pricePerItem:A,page:z})}else h||(w=wb(n),u=ac(n),t=n.getAttribute("data-item-id"),y=n.getAttribute("data-soulbound-to"),n=parseInt(n.getAttribute("data-amount"),10)||1,e.push({itemRarity:w,itemName:u,itemDataId:t,itemSoulbound:y,itemPrice:r,pricePerItem:r/n,page:z}))}}if(h&&m>=g)break}return e},async rn(b,c,e,h,k){for(const g of h){const l=
g.itemName;h=g.itemDataId;const q=g.itemSoulbound,m=g.itemPrice,n=g.pricePerItem,r=g.page,w={Ln:"-1",Fn:"0",Dn:"1",Hn:"2",Gn:"3",In:"4"},u=localStorage.getItem("usePacks")||"false";"true"===localStorage.getItem("marketOnlyFood")?ba.gold>=m+k&&(!q||null===q)&&await jQuery.get(G({}),{mod:"market",buyid:h,sh:W("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}).then(t=>{t=(new DOMParser).parseFromString(t,"text/html").getElementById("sstat_gold_val").innerText;t=parseInt(t.replace(/\./g,""),10);
if(document.getElementById("sstat_gold_val").innerText=t)ba.gold=t;hf.Sm(l);D(`Bought ${l} for ${m} gold`)}):b.some(t=>{const y=w[t.km]||"0";return l.trim().toLowerCase().includes(t.gn.trim().toLowerCase())&&e==y&&ba.gold>=m+k&&(!q||null===q||"BuySoulbound"===t.Soulbound&&q||"DontBuySoulbound"===t.Soulbound&&!q)&&(Number(t.maxPrice)>=m||"true"==u&&Number(t.maxPrice)>=n&&ba.gold>=m)})&&await jQuery.get(G({}),{mod:"market",buyid:h,sh:W("sh"),qry:"",seller:"",f:c,fl:12,fq:e,s:"",p:r,buy:"Buy"}).then(t=>
{t=(new DOMParser).parseFromString(t,"text/html").getElementById("sstat_gold_val").innerText;t=parseInt(t.replace(/\./g,""),10);if(document.getElementById("sstat_gold_val").innerText=t)ba.gold=t;hf.Sm(l);D(`Bought ${l} for ${m} gold`)})}D(`${d.wb} in Market`)}};(window.location.href.includes("/index.php?mod=forge&submod=workbench")||window.location.href.includes("/index.php?mod=forge&doll=1&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=2&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=3&submod=workbench")||
window.location.href.includes("index.php?mod=forge&doll=4&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=5&submod=workbench")||window.location.href.includes("index.php?mod=forge&doll=6&submod=workbench"))&&ij();var yj={async start(){try{const b=ua.repairArena,c=ua.repairTurma;let e=this.F(),h=this.ko(e),k=this.ln("itemList1"),g=this.ln("itemList2");const l=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];h?(await this.u(),await this.Fo(h,l)):b&&0<k.length?await this.bn("mod=overview&doll=1",
ua.itemList1):c&&0<g.length&&await this.bn("mod=overview&doll=2",ua.itemList2)}catch(b){this.handleError()}},F(){let b=localStorage.getItem("workbenchItem");return b?JSON.parse(b):{selectedItem:{}}},ko(b){try{return b.selectedItem&&0<Object.keys(b.selectedItem).length?b.selectedItem:!1}catch(c){return null}},ln(b){return(b=localStorage.getItem(b))?this.Ko(b):[]},Ko(b){try{let c=JSON.parse(b);return Array.isArray(c)&&c.every(e=>void 0===e)?[]:c}catch(c){return[]}},async bn(b,c){rf!==b?Dh(b):(await this.u(),
0<this.F().spaces?await this.jm(c):this.wn("workbench"))},wn(b){"space"===b?D("Not enough inventory space for repair. Retrying in 10 minutes."):"workbench"===b?D("Not enough empty slots in workbench. Retrying in 10 minutes."):"material"===b?D(`${d.ta}`):D("Repair: Retrying in 10 minutes.");b=JSON.parse(localStorage.getItem("Timers"));Z("repair",b.Repair||10);window.location.reload()},async Fo(b,c,e){switch(b.status){case "toWorkbench":await this.ij(b.iid);break;case "toFillGoods":0<c.length&&e.workbenchneededitems?
await this.Wi(b.slot,-1,e.workbenchneededitems):await this.dc(b.slot);break;case "toPackage":await this.Zc(b.slot);break;case "toBag":await this.Ga();break;case "toInv":await this.Zl();break;case "workbenchToBag":await this.mn(b.slot)}},handleError(){localStorage.removeItem("workbenchItem");const b=JSON.parse(localStorage.getItem("Timers"));Z("repair",b.Repair||10);window.location.reload()},async u(){try{const b=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),
sh:W("sh")});let c=this.F();c.slots=JSON.parse(b).slots;c.spaces=c.slots.filter(e=>"closed"===e["forge_slots.state"]).length;c.freeSlots=c.slots.filter(e=>"closed"===e["forge_slots.state"]);localStorage.setItem("workbenchItem",JSON.stringify(c))}catch(b){}},async jm(b){try{let c=b.shift();D(`${d.Mf}${c.name}`);D(`${d.va}`);let {spot:e,bag:h}=await mc(c.hn,c.jn);const k=await jQuery.post(T({}),{mod:"inventory",submod:"move",from:c.container,fromX:1,fromY:1,to:h,toX:e.x+1,toY:e.y+1,amount:1,doll:c.doll,
a:(new Date).getTime(),sh:W("sh")});let g=this.F();g.selectedItem||(g.selectedItem={});Object.assign(g.selectedItem,{item:c,iid:JSON.parse(k).to.data.itemId,status:"toWorkbench",spot:e,bag:h});localStorage.setItem("workbenchItem",JSON.stringify(g));await this.ij(JSON.parse(k).to.data.itemId)}catch{D("Error repairing the item."),localStorage.setItem("workbenchItem",JSON.stringify({})),window.location.reload()}},async ij(b){try{D(`${d.yb}`);let c=this.F(),e=0;for(let k of c.slots||[])if("closed"===
k["forge_slots.state"]){e=k["forge_slots.slot"];break}const h=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:e,iid:b,amount:1,a:(new Date).getTime(),sh:W("sh")});c.slots=JSON.parse(h).slots;c.spaces=0;c.freeSlots=[];for(let k of c.slots)"closed"===k["forge_slots.state"]&&(c.spaces++,c.freeSlots.push(k));e=c.freeSlots.shift()["forge_slots.slot"];c.workbenchneededitems=JSON.parse(h).slots[e].formula.needed;c.workbenchneededitems?(Object.assign(c.selectedItem,
{slot:e,status:"toFillGoods"}),localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.Io(e,b)):(D(`${d.ta}`),Object.assign(c.selectedItem,{status:"toBag"}),D("Error moving the item to the workbench."),localStorage.setItem("workbenchItem",JSON.stringify(c)),window.location.reload())}catch(c){D("Error moving the item to the workbench."+c),window.location.reload()}},async Io(b,c){await jQuery.post(T({}),{mod:"forge",submod:"rent",mode:"workbench",slot:b,rent:2,item:c,a:(new Date).getTime(),
sh:W("sh")});c=this.F();Object.assign(c.selectedItem,{slot:b,status:"toFillGoods"});localStorage.setItem("workbenchItem",JSON.stringify(c));0<(JSON.parse(localStorage.getItem("ignoredMaterials"))||[]).length?await this.Wi(b,-1,c.workbenchneededitems):await this.dc(b)},async Wi(b,c,e){c=[];const h=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let k in e){const g=parseInt(k,10);0<e[k].amount&&!h.some(l=>parseInt(l,10)+18E3===g)&&c.push({type:g,amount:e[k].amount})}await this.Bl(c,-1,
b);await jQuery.post(T({mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}));e=this.F();e.selectedItem.status="toPackage";localStorage.setItem("workbenchItem",JSON.stringify(e));await this.Zc(b)},async Bl(b,c=-1,e){let h=!0;for(let g=0;g<b.length;g++){let l=c,q=!1,m=b[g].amount;b[g].type=b[g].type-18E3;await new Promise(w=>setTimeout(w,800));let n=await this.mo(b[g].type);const r=Number(localStorage.getItem("repairMaxQuality"));for(;l<=r;){var k=n[l]||0;if(0===k)l++;
else{k=Math.min(m,k);m-=k;try{if(await jQuery.post(T({mod:"forge",submod:"storageOut",type:b[g].type,quality:l,amount:k,a:(new Date).getTime(),sh:W("sh")})),await this.Cl(b[g].type,l,e,k),q=!0,0>=m)break}catch(w){if(l++,l>r){h=!1;break}}}}if(!q||0<m)h=!1}return h},async mo(b){let c={};try{const e=await jQuery.get(G({mod:"forge",submod:"storage",sh:W("sh")})),h=jQuery("<div>").append(e).find("#resource-amount").attr("data-max");if(h){const k=JSON.parse(h.replace(/&quot;/g,'"'));k[b]&&(c=k[b])}console.log("Quantities for type",
b,":",c)}catch(e){console.error("Failed to fetch material quantities:",e)}return c},async Cl(b,c,e,h){let k=1,g=!1,l=this.F(),{bag:q,spot:m}=l.selectedItem||{};for(await new Promise(n=>setTimeout(n,800));!g&&5>=k;)try{const n=await jQuery.get(G({mod:"packages",f:18,fq:c,qry:"",page:k,sh:W("sh")})),r=jQuery(n).find(".packageItem");0===r.length?k++:(r.each(async(w,u)=>{try{let t=jQuery(u).find(".ui-draggable"),y=yb(t[0]).split("-")[1],A=wb(t[0]),z=t.context.querySelector("input").getAttribute("value");
if(Number(y)==Number(b)&&Number(A)==Number(c)){g=!0;try{const x=await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+z,fromX:1,fromY:1,to:q,toX:m.x+1,toY:m.y+1,amount:h}),{a:(new Date).getTime(),sh:W("sh")}),v=JSON.parse(x).to.data.itemId;try{await jQuery.post(T({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:v,amount:h,a:(new Date).getTime(),sh:W("sh")}))}catch(C){D(`Error moving material to workbench: ${C}`)}}catch(x){D(`Error moving material from package to bag: ${x}`)}return!1}}catch(t){D(`Error processing package item: ${t}`)}}),
g||k++)}catch(n){D(`Error fetching materials from the package on page ${k}: ${n}`),k++}g||D(`Material of type ${b} and quality ${c} not found in packages.`)},async dc(b,c=-1){let e=this.F();await jQuery.post(T({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:W("sh")});c<Number(localStorage.getItem("repairMaxQuality"))?await this.dc(b,++c):(await jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}),
e.selectedItem.status="toPackage",localStorage.setItem("workbenchItem",JSON.stringify(e)),await this.Zc(b))},async Zc(b){D(`${d.Lf}`);let c=this.F();c.selectedItem.status="workbenchToBag";localStorage.setItem("workbenchItem",JSON.stringify(c));let e;try{(e=1100*c.slots[b].formula.duration)||(e=12E3)}catch(h){e=12E3}await new Promise(h=>setTimeout(h,e));await this.mn(b)},async mn(b){let c=this.F();(await jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),
sh:W("sh")})).includes("document.location.href=document.location.href")?(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c))):(Object.assign(c.selectedItem,{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(c)),await jQuery.post(T({}),{mod:"forge",submod:"cancel",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")}));await this.Ga()},async Kp(b=1){D(`${d.va}`);let c=await this.F(),{item:e,bag:h,spot:k}=c.selectedItem,g=!1;
try{const u=await jQuery.get(G({}),{mod:"packages",f:-1,fq:e.quality,qry:e.name,page:b,sh:W("sh")});let t=jQuery(u).find(".packageItem").toArray();0===t.length&&D(`No package items found on page: ${b}`);for(let y of t){let A=y.querySelector(".ui-draggable");xb(A);var l=wb(A),q=ac(A);y.getAttribute("data-soulbound-to");var m=A.getAttribute("data-measurement-x"),n=A.getAttribute("data-measurement-y"),r=y.querySelector("[data-container-number]").getAttribute("data-container-number"),w=y.querySelector('input[name="packages[]"]').value;
if(q===e.name&&e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===l)g=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.nn(y,h,k,r,m,n)}3<b?this.handleError():g||await this.Ga(++b,!0)}catch(u){D(`Error repairing the item. ${u}`),this.un(),window.location.reload()}},async Ga(b=1){D(`${d.va}`);let c=await this.F(),{item:e,bag:h,spot:k}=c.selectedItem,g=!1;e.quality=e?.quality??0;try{const u=await jQuery.get(G({}),{mod:"packages",
f:-1,fq:e.quality,qry:e.name,page:b,sh:W("sh")});let t=jQuery(u).find(".packageItem").toArray();0===t.length&&D(`No package items found on page: ${b}`);for(let y of t){let A=y.querySelector(".ui-draggable");xb(A);var l=wb(A)??0,q=ac(A);y.getAttribute("data-soulbound-to");var m=A.getAttribute("data-measurement-x"),n=A.getAttribute("data-measurement-y"),r=y.querySelector("[data-container-number]").getAttribute("data-container-number"),w=y.querySelector('input[name="packages[]"]').value;if(q===e.name&&
e.container===w||q===e.name&&r.includes(e.container)||q===e.name&&e.quality===l)g=!0,c.selectedItem.status="toInv",localStorage.setItem("workbenchItem",JSON.stringify(c)),await this.nn(y,h,k,r,m,n)}3<b?this.handleError():g||await this.Ga(++b,!0)}catch(u){D(`Error repairing the item. ${u}`),this.un(),window.location.reload()}},async nn(b,c,e,h,k,g){await mc(k,g,async(l,q)=>{await jQuery.post(T({}),{mod:"inventory",submod:"move",from:h,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+1,amount:1,a:(new Date).getTime(),
sh:W("sh")});await this.Zl(h,l,q)})},async Zl(b,c,e){D("Trying to move repaired item to the equpiment.");b=this.F();let {item:h}=b.selectedItem;c=await jQuery.post(T({}),{mod:"inventory",submod:"move",from:e,fromX:c.x+1,fromY:c.y+1,to:h.container,toX:1,toY:1,amount:1,doll:h.doll,a:(new Date).getTime(),sh:W("sh")});c.includes(`"data":{"containerNumber":${h.container}`)?(Object.assign(b.selectedItem,{status:"toInv"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),await this.io(c,h)):(Object.assign(b.selectedItem,
{status:"toBag"}),localStorage.setItem("workbenchItem",JSON.stringify(b)),window.location.reload())},async io(b,c){let e,h,k=localStorage.getItem("repairPercentage")||10;try{e=JSON.parse(b).to.data.tooltip.pop().pop()[0].match(/\d+/g),h=Number(e[0])/Number(e[1])*100}catch(g){location.reload()}h<parseInt(k,10)?(this.No(c.container,2===c.doll),D(`${d.ta}`)):(D(`${d.Of}`),P("itemRepaired",0));b=this.F();delete b.selectedItem;localStorage.setItem("workbenchItem",JSON.stringify(b));window.location.reload()},
No(b,c=!1){const e=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),h=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),k=JSON.parse(localStorage.getItem("disabledTimeGladiator")||"{}"),g=JSON.parse(localStorage.getItem("disabledTimeMercenary")||"{}"),l={2:"helmet",11:"necklace",3:"weapon",5:"armor",4:"shield",9:"gloves",10:"shoes",6:"rings1",7:"rings2"},q={2:"helmetM",11:"necklaceM",3:"weaponM",5:"armorM",4:"shieldM",9:"glovesM",10:"shoesM",6:"rings1M",7:"rings2M"};b=c?
q[b]:l[b];c?h[b]&&(h[b]=!1,g[b]=Date.now(),localStorage.setItem("activeItemsMercenary",JSON.stringify(h)),localStorage.setItem("disabledTimeMercenary",JSON.stringify(g))):e[b]&&(e[b]=!1,k[b]=Date.now(),localStorage.setItem("activeItemsGladiator",JSON.stringify(e)),localStorage.setItem("disabledTimeGladiator",JSON.stringify(k)))},un(){this.wn()}},uj={am:[],async Jo(b){try{let e;const h=parseInt(localStorage.getItem("smeltTab"),10)||1;D("Repairing before smelting, please wait...");1===h?e=514:2===h?
e=515:3===h?e=516:4===h?e=517:5===h?e=518:6===h&&(e=519);const k=await this.ho(b);if(k){var c=await this.Ao(b);if(null===c)console.error("Failed to move item to workbench.");else return await this.Nm(c),await this.Po(c),await this.Vn(c,e,k)}else console.error(`Item with ID ${b} not found in inventory.`)}catch(e){}},async ho(b){let c=null;document.querySelectorAll("#inv .ui-draggable").forEach(e=>{if(e.getAttribute("data-item-id")===b){const h=parseInt(e.getAttribute("data-position-x"),10)+1,k=parseInt(e.getAttribute("data-position-y"),
10)+1,g=wb(e);e=ac(e).toLowerCase();c={container:"inv",x:h,y:k,quality:g,name:e};return!1}});return c},async Ao(b){const c=await this.jo();if(null===c)return D("No available workbench slots. Continuing without repair."),!1;const e=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",slot:c,iid:b,amount:1,a:(new Date).getTime(),sh:W("sh")});if("0"===(localStorage.getItem("PartialOrFull")||"0"))try{this.am=JSON.parse(e).slots[c].formula.needed}catch{D("Error getting needed items for repair.")}await jQuery.post(T({}),
{mod:"forge",submod:"rent",mode:"workbench",slot:c,rent:2,item:b,a:(new Date).getTime(),sh:W("sh")});return c},async jo(){var b=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});b=JSON.parse(b).slots;let c=null;for(let e of b)if("closed"===e["forge_slots.state"]){c=e["forge_slots.slot"];break}return c},async Nm(b){"0"===(localStorage.getItem("PartialOrFull")||"0")&&0<Object.keys(this.am).length?await this.Wi(b):await this.fo(b);
await jQuery.post(T({}),{mod:"forge",submod:"start",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")})},async fo(b){const c=localStorage.getItem("repairBeforeSmeltMaxQuality")||1;await jQuery.post(T({}),{mod:"forge",submod:"storageToWarehouse",mode:"workbench",slot:b,quality:c,a:(new Date).getTime(),sh:W("sh")})},async Wi(b){let c=[];const e=JSON.parse(localStorage.getItem("ignoredMaterials"))||[];for(let h in this.am){const k=parseInt(h,10);0<this.am[h].amount&&!e.some(g=>parseInt(g,10)+
18E3===k)&&c.push({type:k,amount:this.am[h].amount})}await this.Bl(c,-1,b)},async Bl(b,c=-1,e){for(let h=0;h<b.length;h++){let k=c,g=0,l=1;2>=b[h].amount&&(l=1);for(b[h].type=b[h].type-18E3;k<=Number(localStorage.getItem("repairMaxQuality"))&&g<l;)try{if(await jQuery.post(T({mod:"forge",submod:"storageOut",type:b[h].type,quality:k,amount:1,a:(new Date).getTime(),sh:W("sh")})),await this.Cl(b[h].type,k,e,1),g++,g<=l)break}catch(q){if(k++,k>Number(localStorage.getItem("repairMaxQuality")))break}}},
async Cl(b,c,e,h){let k=1,g=!1,{spot:l,bag:q}=await mc(1,1);for(;!g&&5>=k;)try{const m=await jQuery.get(G({mod:"packages",f:18,fq:c,qry:"",page:k,sh:W("sh")})),n=jQuery(m).find(".packageItem");if(0===n.length){k++;continue}let r=!1;n.each((w,u)=>{try{let t=jQuery(u).find(".ui-draggable"),y=yb(t[0]).split("-")[1],A=wb(t[0]),z=t.context.querySelector("input").getAttribute("value");if(y==b&&A==c)return r=g=!0,jQuery.post(T({mod:"inventory",submod:"move",from:"-"+z,fromX:1,fromY:1,to:q,toX:l.x+1,toY:l.y+
1,amount:h}),{a:(new Date).getTime(),sh:W("sh")}).then(x=>{try{const v=JSON.parse(x).to.data.itemId;jQuery.post(T({mod:"forge",submod:"toWarehouse",mode:"workbench",slot:e,iid:v,amount:h,a:(new Date).getTime(),sh:W("sh")})).catch(()=>{})}catch(v){}}).catch(()=>{}),!1}catch(t){}});r||k++}catch(m){D(`Error fetching materials from the package on page ${k}: ${m}`),k++}g||D(`Material of type ${b} and quality ${c} not found in packages.`)},async Po(b){let c=1E3,e=await this.oo(b);if(null===e||void 0===
e)e=6;c=1E3;await new Promise(h=>setTimeout(h,1100*e+c))},async oo(b){var c=await jQuery.post(T({}),{mod:"forge",submod:"getWorkbenchPreview",mode:"workbench",a:(new Date).getTime(),sh:W("sh")});return(c=JSON.parse(c).slots.find(e=>e["forge_slots.slot"]===b))&&c.formula&&c.formula.duration?c.formula.duration:6},async Vn(b,c,e){await jQuery.post(T({}),{mod:"forge",submod:"lootbox",mode:"workbench",slot:b,a:(new Date).getTime(),sh:W("sh")});return await this.Bo(c,e)},async Bo(b,c){let e=1;var h=!1;
let k;for(;!h&&5>=e;){var g=await jQuery.get(G({mod:"packages",f:0,fq:c.quality,qry:c.name,page:e,sh:W("sh")}));g=jQuery(g).find(".packageItem").toArray();for(let l of g){jQuery(l).find(".ui-draggable");h=l.querySelector("input").value;k=(await jQuery.post(T({}),{mod:"inventory",submod:"move",from:"-"+h,fromX:1,fromY:1,to:b,toX:c.x-1,toY:c.y-1,amount:1,a:(new Date).getTime(),sh:W("sh")},null,"json")).to.data.itemId;h=!0;break}h||e++}if(!h)throw Error("Repaired item not found in packages.");return k}},
R={wm:!1,Bm:!0,spot:1,bag:512,start(){this.pack=function(b,c,e){if(!e)return e;var h=0,k=b+c.slice([e.split("^")[1]]);for(b=0;b<k.length;b++)c=k.charCodeAt(b),h=(h<<5)-h+c,h|=0;return e.split("^")[0]==h};this.storage=JSON.parse(localStorage.getItem("packages"))||{packages:{}};this.createFunctions()},createFunctions(){document.getElementById("ConfirmGetGold").addEventListener("click",async function(){async function b(m,n){n=await jQuery.post(T({mod:"inventory",submod:"move",from:m[0].closest("[data-container-number]").getAttribute("data-container-number"),
fromX:1,fromY:1,to:512,toX:21+n,toY:21,amount:1}),{a:(new Date).getTime(),sh:h});m[0].closest(".packageItem").remove();m=JSON.parse(n).header.gold.text||"0";m=parseInt(m.replace(/[^0-9]/g,""),10);l+=m-g;g=m;document.getElementById("goldMovedIndicator").textContent=`Gold moved: ${l.toLocaleString()}`}async function c(){var m=await jQuery.get(G({mod:"packages",f:"14",fq:-1,qry:"",page:k,sh:h}));let n=jQuery(m).find(".ui-draggable").filter((r,w)=>(r=parseInt(jQuery(w).attr("data-price-gold"),10))&&r<=
q-g).get();for(let [r,w]of n.entries())if(await b(jQuery(w),r),g>=q){document.getElementById("goldMovedIndicator").textContent+=" - Completed";return}k++;m=(m=jQuery(m).find(".paging_right_full")[0])?parseInt(m.href.match(/\d+$/)[0],10):1;k<m?await c():document.getElementById("goldMovedIndicator").textContent=`Not enough gold found. Only ${l.toLocaleString()} moved.`}let e=parseInt(document.getElementById("getGold").value.replace(/[^0-9]/g,""),10);if(isNaN(e)||0>=e)alert("Please enter a valid amount greater than 0.");
else{var h=W("sh"),k=0,g=0,l=0;g=parseInt(document.getElementById("sstat_gold_val").textContent.replace(/[^0-9]/g,""),10);var q=g+e;document.getElementById("goldMovedIndicator").textContent="Starting...";await c()}});document.querySelector("h2").addEventListener("click",()=>{jQuery(".custom_packages").toggle();let b=jQuery(".custom_packages").is(":hidden");localStorage.setItem("packages_hidden",b)});jQuery(".custom_packages").mouseup(async b=>{var c=b.target;b=c.getAttribute("data-button");var e=
JSON.parse(localStorage.getItem("packages")),h=e.quality;const k=e.type;if(!c.getAttribute("disabled")){switch(b){case "pickAll":confirm("Pick all?")&&this.pickItems(!0);break;case "pickAllSelected":-1<xa.type.indexOf(14)&&confirm("Pick gold");this.pickItems(!1);break;case "sellThisPage":if(!e||!e.quality||!e.type){Ya("Please select a valid package with both quality and type.");break}0<h.length&&0<k.length?this.Mo():(this.zm=!0,Ya("Please select both quality and type to sell."));break;case "SARTH":this.sarth();
break;case "SASTM":if(!e||!e.quality||!e.type){Ya("Please select a valid package with both quality and type.");break}0<h.length&&0<k.length?this.sastm():(this.zm=!0,Ya("Please select both quality and type to sell."));break;case "stop":this.stop=!0;break;case "switch":c=document.querySelector('input[data-name="useSmeltFilter"]');e=document.querySelector('input[data-name="sellUnderworld"]');h=document.querySelector('input[data-name="UCOTH"]');c.checked="true"===localStorage.getItem("useTriggerSmeltFilter");
e.checked="true"===localStorage.getItem("packageSellUnderworld");h.checked="true"===localStorage.getItem("useTriggerCloths");c.addEventListener("change",function(){localStorage.setItem("useTriggerSmeltFilter",this.checked)});e.addEventListener("change",function(){localStorage.setItem("packageSellUnderworld",this.checked)});h.addEventListener("change",function(){localStorage.setItem("useTriggerCloths",this.checked)});break;default:return}"stop"!=b&&"switch"!=b&&(this.zm?this.zm=!1:(this.stop=!1,jQuery("[pakageCmd]").attr("disabled",
"")))}});document.querySelector(".custom_packages").addEventListener("click",b=>{var c=b.target.closest(".item-checkbox");if(c){var e=c.getAttribute("data-button");b=c.getAttribute("data-name");if(e&&b){var h=Array.from(document.querySelectorAll(`[data-name="${b}"][data-button="package"]`)),k=document.querySelector(`[data-name="${b}"][data-button="packageAll"]`),g=c.classList.toggle("selected");"packageAll"===e?h.forEach(l=>l.classList.toggle("selected",g)):"package"===e&&(!g&&k&&k.classList.remove("selected"),
h.every(l=>l.classList.contains("selected"))&&k&&k.classList.add("selected"));c=h.filter(l=>l.classList.contains("selected")).map(l=>l.getAttribute("data-value"));e=JSON.parse(localStorage.getItem("packages")||"{}");e[b]=c;localStorage.setItem("packages",JSON.stringify(e))}}});document.querySelectorAll(".color-box").forEach(b=>{b.addEventListener("click",()=>{var c=b.getAttribute("data-button");const e=b.getAttribute("data-name");b.getAttribute("data-value");const h=b.classList.toggle("selected");
"packageAll"===c?document.querySelectorAll(`.color-box[data-name="${e}"]`).forEach(g=>{g!==b&&g.classList.toggle("selected",h)}):(h||document.querySelector(`.color-box.select-all[data-name="${e}"]`)?.classList.remove("selected"),Array.from(document.querySelectorAll(`.color-box[data-name="${e}"]`)).filter(g=>g!==b&&"packageAll"!==g.getAttribute("data-button")).every(g=>g.classList.contains("selected"))&&document.querySelector(`.color-box.select-all[data-name="${e}"]`)?.classList.add("selected"));c=
Array.from(document.querySelectorAll(`.color-box.selected[data-name="${e}"]`)).map(g=>g.getAttribute("data-value"));const k=JSON.parse(localStorage.getItem("packages")||"{}");k[e]=c;localStorage.setItem("packages",JSON.stringify(k))})});document.querySelectorAll(".item-checkbox img").forEach(b=>{var c=window.getComputedStyle(b);const e=parseInt(c.width,10);c=parseInt(c.height,10);if(64<=e&&96<=c)b.style.transform="scale(0.5)",b.style.width="64px",b.style.height="64px",b.style.transformOrigin="top left";
else if(32<e||32<c)b.style.width="64px",b.style.height="64px",b.style.transform="scale(0.5)",b.style.transformOrigin="top left";else if(32==e||32==c)b.style.transform="scale(1)",b.style.transformOrigin="top left"});(()=>{var b=JSON.parse(localStorage.getItem("packages")||"{}");for(const [h,k]of Object.entries(b))k.forEach(g=>{(g=document.querySelector(`[data-name="${h}"][data-value="${g}"]`))&&g.classList.add("selected")}),(b=document.querySelector(`[data-name="${h}"][data-button="packageAll"]`))&&
Array.from(document.querySelectorAll(`[data-name="${h}"][data-button="package"]`)).every(g=>g.classList.contains("selected"))&&b.classList.add("selected");var c=document.querySelector('input[data-name="useSmeltFilter"]');b=document.querySelector('input[data-name="sellUnderworld"]');const e=document.querySelector('input[data-name="UCOTH"]');if(c){const h="true"===localStorage.getItem("useTriggerSmeltFilter");c.checked=h}b&&(c="true"===localStorage.getItem("packageSellUnderworld"),b.checked=c);e&&(e.checked=
"true"===localStorage.getItem("useTriggerCloths"))})()},enableButtons(){jQuery("[pakageCmd]").removeAttr("disabled")},pickItems(b,c){xa=JSON.parse(localStorage.getItem("packages")||"{}");const e=xa.type,h=xa.quality;if(b||0!=e.length&&0!=h.length){var k=["12"];this.arr=Array.from(document.querySelectorAll("#packages .ui-draggable")).filter(g=>{const l=yb(g),[q,m]=l.split("-").map(Number);var n=parseInt(wb(g),10);if(b)return!0;g=e.some(r=>k.includes(String(q))?r===l||r===String(q)&&!m:r===l||r===String(q)||
l.startsWith(`${r}-`));n=h.map(Number).includes(Number(n));return g&&n}).sort((g,l)=>$b(l)-$b(g));R.move();c&&c()}else Ya("No package types or qualities selected")},async moveGold(b,c){c=await jQuery.post(T({mod:"inventory",submod:"move",from:b.closest("[data-container-number]").getAttribute("data-container-number"),fromX:1,fromY:1,to:512,toX:21+c,toY:21,amount:1}),{a:(new Date).getTime(),sh:W("sh")});b.closest(".packageItem").remove();document.getElementById("sstat_gold_val").innerText=JSON.parse(c).header.gold.text||
0},move(){var b=document.getElementById("inv"),c=Hc(b);let e=Math.min(40-dc(c),this.arr.length);b=this.arr.shift();0<e&&!R.stop?((c=pf(b,c))?fb(b,c):Ha(b,"inv"),setTimeout(()=>{R.move()},500)):setTimeout(R.enableButtons,500)},sarth:function(){jQuery.post(T({mod:"forge",submod:"storageIn"}),{Fp:0,packages:1,Mm:1,a:(new Date).getTime()+"",sh:W("sh")},()=>{window.location.reload(!0)})},async sastm(){R.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),this.cm=
{},this.pack&&this.Em(this.Pm))},async Mo(){R.stop?window.location.reload():(document.getElementById("sellspinner").classList.remove("hidden"),R.wm=!0,this.cm={},this.pack&&this.Em(this.Pm))},async Pm(b){if(R.stop)window.location.reload();else if(R.cm=b,b=Object.values(b).every(c=>c.items.length>=c.pm),R.Kn=document.querySelector('input[data-name="UCOTH"]'),b&&!R.Kn.checked){if(b=document.getElementById("sellspinner"),b.classList.add("hidden"),!document.getElementById("shops-full-message")){const c=
document.createElement("div");c.id="shops-full-message";c.classList.add("message-container");c.textContent="Shops are full! Please refresh the shops or select refresh shops automatically.";b.insertAdjacentElement("afterend",c);R.enableButtons()}}else mc(2,3,R.En)},async En(b,c){if(R.stop)window.location.reload();else{try{R.Pn=Object.assign(b,{b:c})}catch(r){Ya("Please empty your inventory to have 3x3 space")}document.querySelectorAll("#inventory_nav a")[c-512].click();R.inv=document.getElementById("inv");
var e=JSON.parse(localStorage.getItem("packages"))||{};b=(new URL(window.location.href)).searchParams;b.get("f");b.get("fq");var h={mod:"packages",f:"0",fq:e.quality[0]||-1,qry:"",page:1,sh:W("sh")};b=await jQuery.get(G(h));b=jQuery(b).find(".paging_right_full")[0]?.href.match(/\d+$/)?.[0]||1;console.log(`Max page determined: ${b}`);R.g=[];R.la=[];var k="true"===localStorage.getItem("useTriggerSmeltFilter"),g="true"===localStorage.getItem("packageSellUnderworld"),l=JSON.parse(localStorage.getItem("smeltingSettings"))||
[],q=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],m=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];if(R.wm)R.wm&&(R.stop?window.location.reload():(n=document.querySelectorAll("#packages .packageItem"),b=document.getElementById("sellspinner"),b.classList.remove("hidden"),c=document.getElementById("statusMessage"),c||(c=document.createElement("div"),c.id="statusMessage",c.classList.add("status-message"),b.insertAdjacentElement("afterend",c)),0<n.length?(c.textContent=`Processing ${n.length} items from the current page...`,
n=Array.from(n).map(async r=>{var w=r.querySelector("input").value,u=r.querySelector(".ui-draggable");const t=u.getAttribute("data-basis");var y=u.getAttribute("data-hash"),A=yb(u).split("-");const z=parseInt(A[0]),x=A[1]?parseInt(A[1]):null;A=Zb(t,y);y=14===z;var v=$b(u);const C=ac(u);var E=Gb(u);const I=["12"].includes(String(z));r={p:r,ql:u,s:v,id:w,q:E,Nn:z,On:x,name:C,so:t};w=e.type.some(J=>I?J===t||J===String(z)&&!x:J===t||J===String(z)||t.startsWith(`${J}-`));u=e.quality.map(Number).includes(Number(wb(u)));
A=!g&&A;var K=l.some(J=>{var O=J.prefix&&2<J.prefix.length?J.prefix.toLowerCase():null;J=J.suffix&&2<J.suffix.length?J.suffix.toLowerCase():null;const U=C.toLowerCase();O=O&&U.includes(O);J=J&&U.includes(J);return O||J});v=q.some(J=>C.toLowerCase().includes(J.toLowerCase()));E=m.some(J=>C.toLowerCase().includes(J.toLowerCase()));K=k&&K;k?!w||!u||K||v||E||A?w&&y&&!A&&R.g.push(r):R.g.push(r):w&&u&&!A?R.g.push(r):w&&y&&!A&&R.g.push(r)}),await Promise.all(n),0<R.g.length?(c.textContent=`Selling ${R.g.length} items...`,
await R.Jn()):(c.textContent="No items to sell. Please refresh the page.",b.classList.add("hidden"),R.enableButtons()),R.g=[]):(c.textContent="No items found in the current page.",b.classList.add("hidden"))));else{c=document.getElementById("sellspinner");c.classList.remove("hidden");var n=document.getElementById("statusMessage");n||(n=document.createElement("div"),n.id="statusMessage",n.classList.add("status-message"),c.insertAdjacentElement("afterend",n));let r=0;for(let w=1;w<=b;w+=10){const u=
Array.from({length:Math.min(10,b-w+1)},(t,y)=>w+y);console.log(`Fetching batch pages: ${u.join(", ")}`);n.textContent=`Reading pages ${u[0]} to ${u[u.length-1]}...`;await Promise.all(u.map(async t=>{h.page=t;try{const y=await jQuery.get(G(h)),A=jQuery(y).find(".packageItem");0<A.length&&(r+=A.length,A.each((z,x)=>{var v=jQuery(x).find("input").val(),C=jQuery(x).find(".ui-draggable")[0];const E=C.getAttribute("data-basis");z=C.getAttribute("data-hash");var I=yb(C).split("-");const K=parseInt(I[0]),
J=I[1]?parseInt(I[1]):null;I=Zb(E,z);z=14===K;var O=$b(C),U=Gb(C);const Y=ac(C).toLowerCase(),ia=["12"].includes(String(K));x={p:x,ql:C,s:O,id:v,q:U,Nn:K,On:J,name:Y,so:E};v=e.type.some(aa=>ia?aa===E||aa===String(K)&&!J:aa===E||aa===String(K)||E.startsWith(`${aa}-`));C=e.quality.map(Number).includes(Number(wb(C)));I=!g&&I;var da=l.some(aa=>{var oa=aa.prefix&&2<aa.prefix.length?aa.prefix.toLowerCase():null;aa=aa.suffix&&2<aa.suffix.length?aa.suffix.toLowerCase():null;const la=Y.toLowerCase();oa=oa&&
la.includes(oa);aa=aa&&la.includes(aa);return oa||aa});O=q.some(aa=>Y.toLowerCase().includes(aa.toLowerCase()));U=m.some(aa=>Y.toLowerCase().includes(aa.toLowerCase()));da=k&&da;k?!v||!C||da||O||U||I?v&&z&&!I&&R.g.push(x):R.g.push(x):v&&C&&!I?R.g.push(x):v&&z&&!I&&R.g.push(x)}),console.log(`Items added from page ${t}: ${A.length}`))}catch(y){}}));await new Promise(t=>setTimeout(t,1E3))}n.textContent=0<r?`Found ${r} items. Preparing to sell...`:"No items found. Please adjust your filters.";0<R.g.length?
(n.textContent=`Selling ${R.g.length} items...`,R.sellItems()):(c.classList.add("hidden"),n.textContent="No items to sell. Please change your selections and refresh the page.")}}},sellItems(){if(R.stop)window.location.reload();else{var b=document.getElementById("sellspinner");b.classList.remove("hidden");var c=document.getElementById("statusMessage");c||(c=document.createElement("div"),c.id="statusMessage",c.classList.add("status-message"),b.insertAdjacentElement("afterend",c));var e=document.getElementById("itemPreview");
e||(e=document.createElement("div"),e.id="itemPreview",e.classList.add("item-preview"),c.insertAdjacentElement("afterend",e));try{var h=R.g.shift();var k=R.Pn;var g=R.Qm(h.ql)}catch{0<R.la.length&&!g?R.useCloths():(b.classList.add("hidden"),c.textContent="All items sold. Reloading...",setTimeout(()=>window.location.reload(),2E3));return}if(g){let l=ac(h.ql);c.textContent=`Selling: ${l} (${R.g.length} items left)`;e.innerHTML="";e.appendChild(h.p.cloneNode(!0));jQuery.post(T({mod:"inventory",submod:"move",
from:"-"+h.id,fromX:"1",fromY:"1",to:k.b,toX:k.x+1,toY:k.y+1,amount:h.q}),{a:(new Date).getTime(),sh:W("sh")},()=>{var q=jQuery(h.ql).css({left:32*k.x,top:32*k.y});R.inv.appendChild(q[0]);jQuery.post(T({mod:"inventory",submod:"move",from:k.b,fromX:k.x+1,fromY:k.y+1,to:g.xn,toX:g.spot.x+1,toY:g.spot.y+1,amount:h.q,doll:"1"}),{a:(new Date).getTime(),sh:W("sh")},m=>{jQuery(h.ql).remove();try{document.getElementById("sstat_gold_val").innerText=JSON.parse(m).header.gold.text}catch{}0<R.g.length?R.sellItems():
(b.classList.add("hidden"),c.textContent="All items sold successfully!",setTimeout(()=>0<R.la.length?R.useCloths():window.location.reload(),2E3))})})}else 0<R.g.length?(R.la.push(h),R.sellItems()):(b.classList.add("hidden"),c.textContent="All items sold. Reloading...",setTimeout(()=>0<R.la.length?R.useCloths():window.location.reload(),2E3))}},async useCloths(){if("true"===localStorage.getItem("useTriggerCloths")&&0<R.la.length){R.g=R.la;R.la=[];var b=await jQuery.get(G({mod:"inventory",sub:"1",subsub:"2",
sh:W("sh")}));b=jQuery(b);b.find("#content form img")[0].src.includes("91e0372cccc24f52758be611a10a3b.png")?(b=b.find("#content form input")[0],await jQuery.post(G({mod:"inventory",sub:"1",subsub:"2",sh:W("sh")}),{[b.name]:b.value}),await new Promise((c,e)=>{R.Em(h=>{(R.cm=h)&&0<Object.keys(h).length?c():e("Failed to load shop grid data.")})}),R.sellItems()):window.location.reload()}else window.location.reload()},async Jn(){if(!R.stop){for(;0<R.g.length;){if(R.Bm){var b=await mc(2,3);R.spot=b.spot;
R.bag=b.bag;R.Bm=!1}await new Promise(c=>setTimeout(c,10));b=R.g.splice(0,1).map(async c=>{var e=R.Qm(c.ql);if(e){const h=await jQuery.post(T({mod:"inventory",submod:"move",from:"-"+c.id,fromX:"1",fromY:"1",to:R.bag,toX:R.spot.x+1,toY:R.spot.y+1,amount:c.q}),{a:(new Date).getTime(),sh:W("sh")});if(h.includes("Not possible")||h.includes("error"))R.Bm=!0;else if(e=await jQuery.post(T({mod:"inventory",submod:"move",from:R.bag,fromX:R.spot.x+1,fromY:R.spot.y+1,to:e.xn,toX:e.spot.x+1,toY:e.spot.y+1,amount:c.q,
doll:"1"}),{a:(new Date).getTime(),sh:W("sh")})){jQuery(c.element).remove();try{const k=JSON.parse(e).header.gold.text;document.getElementById("sstat_gold_val").innerText=k||""}catch(k){}}}else 0<R.g.length?R.la.push(c):0<R.la.length?await R.useCloths():window.location.reload()});await Promise.all(b);R.g=R.g.filter(c=>!R.la.includes(c));await new Promise(c=>setTimeout(c,10))}0===R.g.length&&window.location.reload()}},Qm(b){var c=parseInt(b.getAttribute("data-measurement-x"),10);b=parseInt(b.getAttribute("data-measurement-y"),
10);for(var e in R.cm){var h=R.cm[e];if(!(isNaN(parseInt(e,10))||1>h.pm)){var k=Jc(b,c,h.grid);if(k)return h.pm-=c*b,h.items.push({y:k.y,x:k.x,ml:b,w:c}),h.grid=Ic(8,6,h.items),{spot:k,xn:e}}}},Em(b){const c=[{sub:1,subsub:2},{sub:2,subsub:2},{sub:3,subsub:1},{sub:3,subsub:2},{sub:4,subsub:0},{sub:4,subsub:1},{sub:4,subsub:2},{sub:5,subsub:0},{sub:5,subsub:1},{sub:5,subsub:2},{sub:6,subsub:0},{sub:6,subsub:1},{sub:6,subsub:2}].map(h=>G({mod:"inventory",sh:W("sh"),...h})),e={};Promise.all(c.map((h,
k)=>new Promise((g,l)=>{jQuery.get(h,q=>{try{const m=jQuery(q).find("#shop")[0],n=m.getAttribute("data-container-number"),r=Hc(m);e[n]={pm:48-dc(r),grid:Ic(8,6,r),items:r};g()}catch(m){l(m)}}).fail((q,m,n)=>{l(Error(`Error loading shop grid ${k}: ${m} - ${n}`))})}))).then(()=>{0<Object.keys(e).length&&b(e)}).catch(h=>console.error("Error in gsgriz:",h))}};if(window.location.href.includes("/index.php?mod=market")){let b=[];const c=document.querySelector("#market_filter");if(c){const z=document.createElement("div");
z.innerHTML=`
    <div class="custom-market-section">
        <div class="custom-market-header">${d.Cb}</div>
        <div class="custom-market-content">
            <!-- Item Sell Form -->
            <div class="item-sell-form" id="item-sell-form">
                <span class="custom-market-footer">${d.eg}</span>
                <span class="custom-market-footer">${d.dg}</span>
    
                <div>
                    <label>${d.ea}:</label>
                    <input type="text" id="item-name" placeholder="${d.ea}">
                </div>
                <div>
                    <label>${d.Ab}:</label>
                    <select id="item-color">
                        <option value="-1">${d.pa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.H}</option>
                        <option value="4">${d.R}</option>
                    </select>
                </div>
                <div>
                    <label>${d.J}:</label>
                    <input type="text" id="item-howmany" placeholder="${d.J}?">
                </div>
                <div>
                    <label>${d.K}:</label>
                    <input type="number" id="price-min" placeholder="${d.K}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="time-2h" value="1">2h</button>
                    <button id="time-8h" value="2">8h</button>
                    <button id="time-24h" value="3">24h</button>
                    <button id="time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Bb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="search-inventory"> &nbsp;${d.ag}</label>&nbsp;
                    <label><input type="checkbox" id="search-packages"> &nbsp;${d.fg}</label>&nbsp;
                </div>
    
                <button id="sell-item-btn">${d.Cb}</button>
                <div class="spinner3 hidden" id="loadingSpinner3"></div>
            </div>
    
            <!-- Material Sell Form -->
            <div class="material-sell-form hidden" id="material-sell-form">
                <div>
                    <label>Select Material:</label>
                        <select id="material-select">
                            <!-- Base Materials -->
                            <option value="1">${d.Kc}</option>
                            <option value="2">${d.Ac}</option>
                            <option value="4">${d.Ec}</option>
                            <option value="3">${d.Gc}</option>

                            <!-- Materials -->
                            <option value="13">${d.Lc}</option>
                            <option value="14">${d.Bc}</option>
                            <option value="15">${d.Dc}</option>
                            <option value="16">${d.Cc}</option>
                            <option value="17">${d.Hc}</option>
                            <option value="18">${d.Fc}</option>
                            <option value="19">${d.Jc}</option>
                            <option value="20">${d.Ic}</option>

                            <!-- Monster Parts -->
                            <option value="5">${d.Tc}</option>
                            <option value="6">${d.Nc}</option>
                            <option value="7">${d.Wc}</option>
                            <option value="8">${d.Qc}</option>
                            <option value="9">${d.Sc}</option>
                            <option value="10">${d.Rc}</option>
                            <option value="11">${d.Oc}</option>
                            <option value="12">${d.Vc}</option>
                            <option value="55">${d.Pc}</option>
                            <option value="58">${d.Uc}</option>
                            <option value="62">${d.Xc}</option>
                            <option value="64">${d.Yc}</option>

                            <!-- Gemstones -->
                            <option value="21">${d.wc}</option>
                            <option value="22">${d.qc}</option>
                            <option value="23">${d.pc}</option>
                            <option value="24">${d.rc}</option>
                            <option value="25">${d.xc}</option>
                            <option value="26">${d.uc}</option>
                            <option value="27">${d.tc}</option>
                            <option value="28">${d.sc}</option>
                            <option value="59">${d.vc}</option>
                            <option value="63">${d.yc}</option>

                            <!-- Flasks -->
                            <option value="37">${d.kc}</option>
                            <option value="38">${d.nc}</option>
                            <option value="39">${d.fc}</option>
                            <option value="40">${d.ec}</option>
                            <option value="41">${d.mc}</option>
                            <option value="42">${d.jc}</option>
                            <option value="43">${d.hc}</option>
                            <option value="44">${d.ic}</option>
                            <option value="53">${d.oc}</option>
                            <option value="61">${d.lc}</option>

                            <!-- Runes -->
                            <option value="29">${d.xd}</option>
                            <option value="30">${d.rd}</option>
                            <option value="31">${d.pd}</option>
                            <option value="32">${d.wd}</option>
                            <option value="33">${d.vd}</option>
                            <option value="34">${d.td}</option>
                            <option value="35">${d.qd}</option>
                            <option value="36">${d.ud}</option>
                            <option value="60">${d.sd}</option>

                            <!-- Ores -->
                            <option value="45">${d.cd}</option>
                            <option value="46">${d.bd}</option>
                            <option value="47">${d.gd}</option>
                            <option value="48">${d.kd}</option>
                            <option value="49">${d.ld}</option>
                            <option value="50">${d.ed}</option>
                            <option value="51">${d.jd}</option>
                            <option value="52">${d.hd}</option>
                            <option value="54">${d.ad}</option>
                            <option value="56">${d.dd}</option>
                            <option value="57">${d.fd}</option>
                        </select>
                </div>
                <div>
                    <label>${d.bg}:</label>
                    <select id="material-color">
                        <option value="-1">${d.pa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.H}</option>
                        <option value="4">${d.R}</option>
                    </select>
                </div>
                <div>
                    <label>${d.J}:</label>
                    <input type="text" id="mat-item-howmany" placeholder="${d.J}?">
                </div>
                <div>
                    <label>${d.K}:</label>
                    <input type="number" id="material-price-min" placeholder="${d.K}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="material-price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="material-time-2h" value="1">2h</button>
                    <button id="material-time-8h" value="2">8h</button>
                    <button id="material-time-24h" value="3">24h</button>
                    <button id="material-time-48h" value="4">48h</button>
                </div>
    
                <div class="search-options">
                    <label class="search-options-title">${d.Bb}:&nbsp;</label>&nbsp;
                    <label><input type="checkbox" id="material-search-warehouse"> &nbsp;${d.ig}</label>&nbsp;
                </div>
    
                <button id="sell-material-btn">${d.hg}</button>
                <div class="spinner2 hidden" id="loadingSpinner2"></div>
            </div>
    
            <!-- Food Sell Form -->
            <div class="food-sell-form hidden" id="food-sell-form">
                <label>Level Range:</label>
                <div style="display: flex; gap: 5px;">
                    <input type="number" id="food-level-min" placeholder="Min Level" style="width: 100%;">
                    <input type="number" id="food-level-max" placeholder="Max Level" style="width: 100%;">
                </div>
                <div>
                    <label>${d.Ab}:</label>
                    <select id="food-quality">
                        <option value="-1">${d.pa}</option>
                        <option value="0">${d.C}</option>
                        <option value="1">${d.B}</option>
                        <option value="2">${d.D}</option>
                        <option value="3">${d.H}</option>
                        <option value="4">${d.R}</option>
                    </select>
                </div>
                <div>
                    <label>${d.J}:</label>
                    <input type="text" id="food-howmany" placeholder="${d.J}?">
                </div>
                <div>
                    <label>${d.K}:</label>
                    <input type="number" id="food-price-min" placeholder="${d.K}">
                </div>
                <div>
                    <label>${d.G}:</label>
                    <input type="number" id="food-price-max" placeholder="${d.G}">
                </div>
    
                <div class="time-selection">
                    <button id="food-time-2h" value="1">2h</button>
                    <button id="food-time-8h" value="2">8h</button>
                    <button id="food-time-24h" value="3">24h</button>
                    <button id="food-time-48h" value="4">48h</button>
                </div>
    
                <button id="sell-food-btn">${d.gg}</button>
                <div class="spinner3 hidden" id="loadingSpinner4"></div>
            </div>
    
            <div class="switch-section">${d.za}</div>
        </div>
    </div>
            `;c.insertAdjacentElement("afterend",z);document.getElementById("sell-item-btn").addEventListener("click",t);document.getElementById("sell-material-btn").addEventListener("click",y);document.getElementById("sell-food-btn").addEventListener("click",w);document.querySelector(".custom-market-header").addEventListener("click",k);document.querySelector(".switch-section").addEventListener("click",l);document.querySelectorAll(".time-selection button").forEach(x=>{x.addEventListener("click",function(){g(x,
x.textContent)})})}let e=["item-sell-form","material-sell-form","food-sell-form"],h=0;function k(){const z=document.querySelector(".custom-market-content"),x=document.querySelector(".custom-market-header");x.classList.toggle("collapsed");z.style.display=x.classList.contains("collapsed")?"none":"block";localStorage.setItem("sellItemsSectionCollapsed",x.classList.contains("collapsed"))}function g(z,x){z.parentElement.querySelectorAll("button").forEach(v=>{v.classList.remove("selected")});z.classList.add("selected");
localStorage.setItem("selectedTime_"+z.closest("div").parentElement.id,x)}function l(){e.forEach(x=>{document.getElementById(x).classList.add("hidden")});h=(h+1)%e.length;document.getElementById(e[h]).classList.remove("hidden");const z=document.querySelector(".switch-section");"item-sell-form"===e[h]?z.textContent=`${d.za}`:"material-sell-form"===e[h]?z.textContent=`${d.Db}`:"food-sell-form"===e[h]&&(z.textContent=`${d.Eb}`);localStorage.setItem("currentSection",e[h])}async function q(z,x,v){return new Promise(async C=>
{let E=!1;const I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));let K=0;for(let O=0;O<I.length&&!(K>=parseInt(v,10));O++){var J=I[O];if("false"!==J.getAttribute("data-available")){J.click();await new Promise(U=>setTimeout(U,175));J=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let U of J){if(K>=parseInt(v))break;U.getAttribute("data-basis");J=ac(U);const Y=U.getAttribute("data-item-id"),ia=wb(U);if(J.toLowerCase()===z.toLowerCase()&&x===ia){b.push(Y);E=!0;
K++;break}}if(E)break}}C(E)})}async function m(z,x,v,C,E){try{let I=1,K=parseInt(v,10);for(v=!1;1<=I&&2>=I&&!(0>=K);){const J=await jQuery.get(G({mod:"packages",f:C?"18":"0",fq:x,qry:C?"":z,page:I.toString(),sh:W("sh")})),O=Array.from(jQuery(J).find(".packageItem"));for(let U of O){if(0>=K)break;const Y=U.querySelector("[data-content-type]"),ia=U.querySelector("[data-container-number]"),da=Y.getAttribute("data-measurement-x"),aa=Y.getAttribute("data-measurement-y");let oa=Y.getAttribute("data-quality");
const la=Y.getAttribute("data-tooltip"),wa=ia.getAttribute("data-container-number"),Ja=ac(Y).toLowerCase();oa||(la.includes("white")&&(oa="-1"),la.includes("lime")&&(oa="0"));const Ab=Ja===z.toLowerCase()&&x===oa;if(C){const Ka=Y.getAttribute("data-basis"),Kb=Ka.startsWith("18")&&Ka.split("-")[1]===E.toString();x===oa&&Kb&&(await u(wa,da,aa),v=!0,K--)}else Ab&&(await u(wa,da,aa),v=!0,K--)}I++}return v}catch(I){return!1}}async function n(z,x=-1,v){try{let C=!0,E=0;for(let I=0;I<parseInt(v,10)&&!(E>=
v);I++){for(;E<parseInt(v,10);)try{if(await jQuery.post(T({mod:"forge",submod:"storageOut",type:z,quality:x,amount:1,a:(new Date).getTime(),sh:W("sh")})),await m(z,x,1,!0,z),E++,E>=parseInt(v,10))break}catch(K){E++}C=!0}return C}catch(C){return!1}}async function r(z,x,v,C){try{let E=1,I=parseInt(C,10);for(C=!1;1<=E&&10>=E&&!(0>=I);){const K=await jQuery.get(G({mod:"packages",f:"7",fq:v,qry:"",page:E.toString(),sh:W("sh")})),J=Array.from(jQuery(K).find(".packageItem"));for(let O of J){if(0>=I)break;
const U=O.querySelector("[data-content-type]"),Y=O.querySelector("[data-container-number]"),ia=U.getAttribute("data-measurement-x"),da=U.getAttribute("data-measurement-y"),aa=Ib(U),oa=wb(U);if(parseInt(aa)>=z&&parseInt(aa)<=x&&oa===v){const la=Y.getAttribute("data-container-number");await u(la,ia,da);C=!0;I--}}E++}return C}catch(E){return!1}}async function w(){var z=parseInt(document.getElementById("food-level-min").value,10);const x=parseInt(document.getElementById("food-level-max").value,10),v=
document.getElementById("food-quality").value,C=parseInt(document.getElementById("food-howmany").value,10),E=parseInt(document.getElementById("food-price-min").value,10),I=parseInt(document.getElementById("food-price-max").value,10),K=document.getElementById("loadingSpinner4");if(isNaN(z)||isNaN(x)||z>x||isNaN(E)||isNaN(I)||E>I||1>C)alert(`${d.wa}`);else{K.style.display="block";try{let ia=!1;if(ia=await r(z,x,v,C)){var J=document.querySelector("#food-sell-form .time-selection button.selected"),O=
J?parseInt(J.value,10):2,U=document.querySelector('input[name="anbieten"]'),Y=U?U.value:"Offer";for(z=0;z<b.length;z++){const da=b[z],aa=E===I?E:Math.floor(Math.random()*(I-E+1))+E,oa=G({mod:"market",sh:W("sh")});await jQuery.post(oa,{sellid:da,preis:aa,dauer:O,anbieten:Y})}b=[];alert(`${d.ya}`);await new Promise(da=>setTimeout(da,250));Dh("mod=market&f=7")}else alert(`${d.xa}`)}catch(ia){}finally{K.style.display="none"}}}async function u(z,x,v){try{let {spot:C,bag:E}=await mc(x,v);const I=await jQuery.post(T({mod:"inventory",
submod:"move",from:z,fromX:1,fromY:1,to:E,toX:C.x+1,toY:C.y+1,amount:1,a:(new Date).getTime(),sh:W("sh")})),K=JSON.parse(I).to.data.itemId;b.push(K);return!0}catch(C){return!1}}async function t(){const z=document.getElementById("item-name").value;var x=document.getElementById("item-color").value;const v=document.getElementById("item-howmany").value,C=parseInt(document.getElementById("price-min").value,10),E=parseInt(document.getElementById("price-max").value,10),I=document.getElementById("loadingSpinner3"),
K=document.getElementById("search-inventory").checked,J=document.getElementById("search-packages").checked;if(!z||isNaN(C)||isNaN(E)||C>E||1>v)alert(`${d.wa}`);else{I.style.display="block";try{let da=!1;K&&(da=await q(z,x,v));!da&&J&&(da=await m(z,x,v));if(da){var O=document.querySelector(".time-selection button.selected"),U=O?parseInt(O.value,10):2,Y=document.querySelector('input[name="anbieten"]'),ia=Y?Y.value:"Offer";for(x=0;x<b.length;x++){const aa=b[x],oa=C===E?C:Math.floor(Math.random()*(E-
C+1))+C,la=G({mod:"market",sh:W("sh")});jQuery.post(la,{sellid:aa,preis:oa,dauer:U,anbieten:ia})}b=[];alert(`${d.ya}`);await new Promise(aa=>setTimeout(aa,250));Dh("mod=market&qry="+z)}else alert(`${d.xa}`)}catch(da){}finally{I.style.display="none"}}}async function y(){var z=document.getElementById("material-select").value,x=document.getElementById("material-select");x=x.options[x.selectedIndex].textContent;const v=document.getElementById("material-color").value,C=document.getElementById("mat-item-howmany").value,
E=parseInt(document.getElementById("material-price-min").value,10),I=parseInt(document.getElementById("material-price-max").value,10),K=document.getElementById("loadingSpinner2"),J=document.getElementById("material-search-warehouse").checked;if(!z||isNaN(E)||isNaN(I)||E>I||1>C)alert(`${d.wa}`);else{K.style.display="block";try{let da=!1;J&&(da=await n(z,v,C));if(da){var O=document.querySelector("#material-sell-form .time-selection button.selected"),U=O?parseInt(O.value,10):2,Y=document.querySelector('input[name="anbieten"]'),
ia=Y?Y.value:"Offer";for(z=0;z<b.length;z++){const aa=b[z],oa=E===I?E:Math.floor(Math.random()*(I-E+1))+E,la=G({mod:"market",sh:W("sh")});jQuery.post(la,{sellid:aa,preis:oa,dauer:U,anbieten:ia})}b=[];alert(`${d.ya}`);await new Promise(aa=>setTimeout(aa,250));Dh("mod=market&qry="+x)}else alert(`${d.xa}`)}catch(da){}finally{K.style.display="none"}}}const A=localStorage.getItem("currentSection");if(A&&e.includes(A)){e.forEach(x=>{document.getElementById(x).classList.add("hidden")});document.getElementById(A).classList.remove("hidden");
h=e.indexOf(A);const z=document.querySelector(".switch-section");"item-sell-form"===e[h]?z.textContent=`${d.za}`:"material-sell-form"===e[h]?z.textContent=`${d.Db}`:"food-sell-form"===e[h]&&(z.textContent=`${d.Eb}`)}else document.getElementById("item-sell-form").classList.remove("hidden"),h=0;e.forEach(z=>{const x=localStorage.getItem("selectedTime_"+z);x&&document.querySelectorAll("#"+z+" .time-selection button").forEach(v=>{v.textContent===x&&v.classList.add("selected")})});"true"===localStorage.getItem("sellItemsSectionCollapsed")&&
(document.querySelector(".custom-market-header").classList.add("collapsed"),document.querySelector(".custom-market-content").style.display="none")}if(window.location.href.includes("/index.php?mod=guild")){const b=document.querySelectorAll("form");for(const c of b){const e=c.getAttribute("action");e&&e.includes("submod=create")&&localStorage.setItem("resetExpiredItems","false")}}if(window.location.href.includes("/index.php?mod=packages&")){let b=jQuery(".section-header").first();b&&(function(){var c=
"true"===localStorage.getItem("packages_hidden");let e=`

<section class="custom_packages" style="display: block; box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
<div style="text-align: center">
    <button class="awesome-button" packageCmd data-button="pickAll">
    ${d.tj}
    </button>
    <button class="awesome-button" packageCmd data-button="pickAllSelected">
    ${d.uj}
    </button>
    <button class="awesome-button" pakageCmd data-button="sellThisPage">
    ${d.xj}
    </button>
    <button
    class="awesome-button" data-button="SASTM" pakageCmd data-name="SASTM"
>
${d.vj}
</button>
    <button class="awesome-button" data-button="stop">${d.zj}</button>
    <button class="awesome-button" packageCmd data-button="SARTH">
    ${d.yj}
    </button>
</div>

<style>

    .awesome-button:hover {
        background-color: #444;
        color: #fff; 
    }

    .progress-container {
      width: 100%;
      height: 20px;
      background-color: #f3f3f3;
      position: relative;
      border-radius: 15px;
      margin: 10px 0;
    }
  
    .progress-bar {
      width: 0;
      height: 100%;
      background-color: #4caf50;
      position: absolute;
      border-radius: 15px;
      transition: width 0.4s ease-in-out;
    }
  
    .page-indicator {
      text-align: center;
      position: absolute;
      width: 100%;
      top: 50%;
      transform: translateY(-50%);
      font-size: 12px;
    }

</style>

    <fieldset style="box-shadow: 0px 0px 10px rgba(0,0,0,0.15);">
        <legend>${d.wj}</legend>
        <table style="width: 100%; text-align: center">
            <tbody>
                <tr>
                    <td>
                    </td>
                    

                    <div id="sellspinner" class="spinnerNew hidden"></div>
                    <div id="statusMessage" class="status-message">Status</div>
                    <div id="itemPreview" class="item-preview">
                        <div class="item"></div>
                    </div>
                    <!--
                    <div class="progress-container">
                    <div class="progress-bar" id="progressBar"></div>
                    <div class="page-indicator">${d.sj} <span id="currentPageIndicator">0</span></div>
                    </div>
                    -->
                    
                    <td>
                        <input
                            type="checkbox"
                            data-button="switch"
                            data-name-ek="packages"
                            data-name="UCOTH"
                            style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                        /><span class="span-new">${d.Ej}</span>
                        <hr>
                        <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="useSmeltFilter"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       /><span class="span-new">${d.ie}</span>
                       <hr>
                       <input
                        type="checkbox"
                        data-button="switch"
                        data-name-ek="packages"
                        data-name="sellUnderworld"
                        style="box-shadow: 0px 5px 10px rgba(0,0,0,0.15);"
                       />
                       <span class="span-new">${d.Jj}</span>
                       <hr>
                        <div class="setting-row">
                        <label for="getGold">${d.Mi}</label>
                        <div class="switch-field3">
                          
                          <input type="number" id="getGold" min="1000" max="200000000" placeholder="Amount">
                          <button id="ConfirmGetGold" class="awesome-button">OK</button>
                          <span class="span-new" id="goldMovedIndicator">${d.We}: 0</span>
                        </div>
                      </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </fieldset>
    <fieldset>
        <legend>${d.ma}</legend>
    <table>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="1" title="Weapons">
      <img class="item-i-1-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="2" title="Shields">
      <img class="item-i-2-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="3" title="Armor">
      <img class="item-i-3-3">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="4" title="Helmets">
      <img class="item-i-4-7">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="5" title="Gloves">
      <img class="item-i-5-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="8" title="Boots">
      <img class="item-i-8-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="6" title="Rings">
      <img class="item-i-6-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="9" title="Necklaces">
      <img class="item-i-9-1">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="7" title="Food">
      <img class="item-i-7-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12" title="Upgrades">
      <img class="item-i-12-2">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="13" title="Recipes">
      <img class="item-i-13-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="15" title="Mercenaries">
      <img class="item-i-15-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="19" title="Tools">
      <img class="item-i-19-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="20" title="Scrolls">
      <img class="item-i-20-1">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="11" title="Reinforcements">
      <img class="item-i-11-17">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="21" title="Event Items">
      <img class="item-i-21-1">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="18" title="Forging Goods">
      <img class="item-i-18-1">
    </td>

    <!-- Powders -->
    
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-10" title="Green Powder">
      <img class="item-i-12-10">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-6" title="Blue Powder">
      <img class="item-i-12-6">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-17" title="Red Powder">
      <img class="item-i-12-17">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-14" title="Purple Powder">
      <img class="item-i-12-14">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-8" title="Yellow Powder">
      <img class="item-i-12-8">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-12" title="Orange Powder">
      <img class="item-i-12-12">
    </td>

    <!-- Dust -->
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-7" title="Yellow Powder">
      <img class="item-i-12-7">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-5" title="Blue Powder">
      <img class="item-i-12-5">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-16" title="Red Powder">
      <img class="item-i-12-16">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-9" title="Green Powder">
      <img class="item-i-12-9">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-11" title="Orange Powder">
      <img class="item-i-12-11">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-13" title="Purple Powder">
      <img class="item-i-12-13">
    </td>

    <!-- Oils -->
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-18" title="Purple Oil">
      <img class="item-i-12-18">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-19" title="Yellow Oil">
      <img class="item-i-12-19">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-20" title="Orange Oil">
      <img class="item-i-12-20">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-21" title="Green Oil">
      <img class="item-i-12-21">
    </td>
        <td class="item-checkbox" data-button="package" data-name="type" data-value="12-22" title="Blue Oil">
      <img class="item-i-12-22">
    </td>
    <td class="item-checkbox" data-button="package" data-name="type" data-value="12-23" title="Red Oil">
      <img class="item-i-12-23">
    </td>

    <td class="item-checkbox" data-button="package" data-name="type" data-value="14" title="Gold">
      <img class="item-i-14-1">
    </td>

      <td class="item-checkbox select-all" data-button="packageAll" data-name="type" title="Select All">
        <div class="select-all-content">
          <span class="select-all-text">ALL</span>
        </div>
      </td>

</table>

    </fieldset>
    <fieldset>
        <legend>Quality</legend>
        <table style="width: 100% box-shadow: 0px 5px 10px rgba(0,0,0,0.15);">
            <tbody>
              <tr>
  <td style="width: 14.28%">
    <div class="color-box" data-button="package" data-name="quality" data-value="-1" title="White" style="background-color: white; "></div>
  </td>
  <td style="width: 14.28%">
    <div class="color-box" data-button="package" data-name="quality" data-value="0" title="Green" style="background-color: green;"></div>
  </td>
  <td style="width: 14.28%">
    <div class="color-box" data-button="package" data-name="quality" data-value="1" title="Blue" style="background-color: blue;"></div>
  </td>
  <td style="width: 14.28%">
    <div class="color-box" data-button="package" data-name="quality" data-value="2" title="Purple" style="background-color: purple;"></div>
  </td>
  <td style="width: 14.28%">
    <div class="color-box" data-button="package" data-name="quality" data-value="3" title="Orange" style="background-color: orange;"></div>
  </td>
  <td style="width: 14.28%">
    <div class="color-box" data-button="package" data-name="quality" data-value="4" title="Red" style="background-color: red;"></div>
  </td>
  <td style="width: 14.28%">
    <div class="color-box select-all" data-button="packageAll" data-name="quality" data-value="99" title="All" style="background: linear-gradient(45deg, red, orange, yellow, green, blue, purple); border: 1px solid #ccc;"></div>
  </td>
</tr>

                <!-- Additional tr elements for Quality -->
            </tbody>
        </table>
    </fieldset>
</section>
`;b.before(`
                <h2 class="section-header" style="cursor: pointer" id="hidePackges">
                ${d.Aj}
                </h2>`);b.before(e);c&&(c=document.querySelector(".custom_packages"),c.style.display="none"===c.style.display?"block":"none")}(),$(".custom-button:contains('sell all selected to merchants')").click(async function(){await R.sastm()}));R.start()}if(window.location.href.includes("mod=auction")){localStorage.getItem("auctionPrefixes")||localStorage.setItem("auctionPrefixes",JSON.stringify([]));localStorage.getItem("prefixes")||localStorage.setItem("prefixes",JSON.stringify([]));localStorage.getItem("searchTerms")||
localStorage.setItem("searchTerms",JSON.stringify([]));const b=document.getElementById("auction_table");let c;b&&(c=b.querySelectorAll(".auction_item_div"));const e=localStorage.getItem("highlightedItemHash");if(e){const h=document.querySelector(`form:has(div[data-hash="${e}"])`);h&&(h.style.outline="3px solid red",h.style.outlineOffset="4px",h.style.boxShadow="0 0 10px rgba(0, 0, 0, 0.5)",h.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"}),localStorage.removeItem("highlightedItemHash"))}if(!c||
0===c.length)return;c.forEach(h=>{h.style.position="relative";h.style.height="106px";const k=document.createElement("span");k.className="auction-icon";k.innerHTML="\ud83d\udd28";k.title="Add to Auction List";k.style.cursor="pointer";k.style.fontSize="16px";k.style.marginTop="88px";k.style.display="inline-block";k.style.marginRight="-25px";const g=document.createElement("span");g.className="smelt-icon";g.innerHTML="\ud83d\udd25";g.title="Add to Smelting List";g.style.cursor="pointer";g.style.fontSize=
"16px";g.style.marginTop="88px";g.style.display="inline-block";let l=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],q=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],m=JSON.parse(localStorage.getItem("smeltingSettings"))||[];const n=h.querySelector("[data-tooltip]"),r=n?n.getAttribute("data-tooltip"):null;if(r){var {itemName:w,dn:u,en:t,itemColor:y,itemType:A,itemLevel:z}=jh(r,n);try{JSON.parse(r.replace(/&quot;/g,'"'))}catch(x){return}w&&(l.includes(u)&&q.includes(t)&&(k.innerHTML=
"\u2705"),m.some(x=>{const v=""!=x.prefix&&u.includes(x.prefix)||""!=x.suffix&&t.includes(x.suffix);x="white"==y||x.colors.includes(y);return v&&x})&&(g.innerHTML="\u2705"),k.addEventListener("click",()=>{let x=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],v=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];JSON.parse(localStorage.getItem("searchTerms"));x.includes(u)||(x.push(u),localStorage.setItem("auctionPrefixes",JSON.stringify(x)));v.includes(t)||(v.push(t),localStorage.setItem("auctionSuffixes",
JSON.stringify(v)));bb(`Item "${w[0]}" added to the auction list!`);k.innerHTML="\u2705";setTimeout(()=>{k.innerHTML="\ud83d\udd28"},1E3)}),g.addEventListener("click",()=>{var x="white";switch(itemQuality){case "0":x="green";break;case "1":x="blue";break;case "2":x="purple";break;case "3":x="orange";break;case "4":x="red";break;default:x="white"}x={condition:"nameContains",prefix:u,suffix:t,colors:"white"===x?["white","green"]:[x],itemTypes:[A],hammerState:"none",level:z,enabled:!0};let v=JSON.parse(localStorage.getItem("smeltingSettings"))||
[];v.push(x);localStorage.setItem("smeltingSettings",JSON.stringify(v));bb(`Item "${w[0]}" added to the smelting list!`);g.innerHTML="\u2705";setTimeout(()=>{g.innerHTML="\ud83d\udd25"},1E3)}),h.appendChild(g),h.appendChild(k))}})}if(window.location.href.includes("mod=packages")){await new Promise(e=>setTimeout(e,1E3));["auctionPrefixes","prefixes","searchTerms"].forEach(e=>{localStorage.getItem(e)||localStorage.setItem(e,JSON.stringify([]))});const b=document.getElementById("packages");if(!b)return;
const c=b.querySelectorAll(".packageItem");if(!c||0===c.length)return;c.forEach(e=>{const h=ih("\ud83d\udd28","auction-icon","pointer","16px","1px",`${d.Hi}`),k=ih("\ud83d\udd25","smelt-icon","pointer","16px","40px",`${d.Zj}`),g=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],l=JSON.parse(localStorage.getItem("auctionSuffixes"))||[],q=JSON.parse(localStorage.getItem("smeltingSettings"))||[],m=e.querySelector("[data-tooltip]"),n=m?m.getAttribute("data-tooltip"):null;if(n){var {itemName:r,dn:w,
en:u,itemColor:t,itemType:y,itemLevel:A}=jh(n,m);r&&(g.includes(w)&&l.includes(u)&&(h.innerHTML="\u2705"),q.some(z=>{const x=""!=z.prefix&&w.includes(z.prefix)||""!=z.suffix&&u.includes(z.suffix);z="white"==t||z.colors.includes(t);return x&&z})&&(k.innerHTML="\u2705"),h.addEventListener("click",()=>{let z=JSON.parse(localStorage.getItem("auctionPrefixes"))||[],x=JSON.parse(localStorage.getItem("auctionSuffixes"))||[];z.includes(w)||(z.push(w),localStorage.setItem("auctionPrefixes",JSON.stringify(z)));
x.includes(u)||(x.push(u),localStorage.setItem("auctionSuffixes",JSON.stringify(x)));bb(`Item "${r[0]}" added to the auction list!`);h.innerHTML="\u2705"}),k.addEventListener("click",()=>{const z={condition:"nameContains",prefix:w,suffix:u,colors:"white"===t?["white","green"]:[t],itemTypes:[y],hammerState:"none",level:A||1,enabled:!0},x=JSON.parse(localStorage.getItem("smeltingSettings"))||[];x.push(z);localStorage.setItem("smeltingSettings",JSON.stringify(x));bb(`Item "${r[0]}" added to the smelting list!`);
k.innerHTML="\u2705"}),e=e.querySelector('[data-no-combine="true"]'))&&(e.appendChild(h),e.appendChild(k))}})}var mb={A:{async start(){const b=JSON.parse(localStorage.getItem("Timers"));if(!W("mod")||"auction"!==W("mod")){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(h=>c[h]).filter(h=>void 0!==h);if(0<e.length){Dh(`mod=auction&itemType=${e[0]}`);return}}mb.A.L=[];mb.A.kl=Math.floor(Fh().gold-
Number(localStorage.getItem("storeGoldinAuctionholdGold")));mb.A.form=document.querySelectorAll("#auction_table form");mb.A.kl&&await this.list(async()=>{0<this.L.length?await this.buy():this.Eo(b)})},async Eo(b){const c={WEAPONS2:1,SHIELD2:2,CHEST2:3,HELMET2:4,GLOVES2:5,SHOES2:8,RINGS2:6,AMULETS2:9};let e=JSON.parse(localStorage.getItem("itemsToReset2")||"[]").map(q=>c[q]).filter(q=>void 0!==q);0===e.length&&(D("Auction Store: No valid auction types selected."),Z("enableHideGold",b.AuctionHoldGold||
5),window.location.reload());const h=parseInt(W("itemType"),10),k=W("ttype"),g=e.indexOf(h),l=g===e.length-1;"3"===k?l?(D("Auction Store: Last type reached, reloading and setting timeout for next cycle."),Z("enableHideGold",b.AuctionHoldGold||5),window.location.reload()):Dh(`mod=auction&itemType=${e[g+1]}`):-1!==g&&(D("Auction Store: Toggling to mercenary mode for current type:",h),Dh(`mod=auction&itemType=${h}&ttype=3`))},async list(b=!1){D(`${d.Hf}`);var c=this.kl;const e="true"===localStorage.getItem("AuctionGoldCover");
let h=[];const k=localStorage.getItem("storeInShopQuality")||-1;for(let q=0;q<this.form.length;q++){let m=this.form[q];var g=m.querySelector(".ui-draggable"),l=m.querySelector(".auction_bid_div");l=(l=l?l.querySelector('input[type="text"], input[type="number"]'):null)?Number(l.value):0;g=g?bc(g):0;l<=g&&l<=c&&h.push({ja:m,price:parseInt(l,10),value:g})}h.sort((q,m)=>m.price-q.price);for(let q of h)if(c=q.ja.querySelector(".ui-draggable").getAttribute("data-quality"),!(Number(c)<Number(k))){if(c=(c=
(c=q.ja.querySelector(".auction_bid_div"))?c.querySelector("div > a"):null)?c.querySelector("span"):null){c=c.getAttribute("style");if(e&&c&&c.includes("green"))continue;if(!e&&c&&c.includes("green"))return!0;if(c&&c.includes("blue"))continue}mb.A.L.push([q.ja.getAttribute("action"),{auctionid:q.ja.querySelector('input[name="auctionid"]').value,qry:q.ja.querySelector('input[name="qry"]').value,itemType:q.ja.querySelector('input[name="itemType"]').value,itemLevel:q.ja.querySelector('input[name="itemLevel"]').value,
itemQuality:q.ja.querySelector('input[name="itemQuality"]').value,buyouthd:q.ja.querySelector('input[name="buyouthd"]').value,bid_amount:q.price,bid:q.ja.querySelector('input[name="bid"]').value}])}b&&await b()},async buy(){let b=mb.A.L.pop();await jQuery.ajax({type:"POST",url:b[0],data:b[1]});0<mb.A.L.length?(await new Promise(c=>setTimeout(c,100)),await this.buy()):window.location.reload()}}},rh=localStorage.getItem("OillastRan"),th=Date.now(),Va={$l:"minerva diana vulcanus mars apollo merkur".split(" "),
Wn:[20,60,150,0],Um:[],async start(){"mod=gods"!=rf?Dh("mod=gods"):Va.Km(0)},Un(){let b=(new Date).getTime(),c=Aa.An?Aa.An:[1];if(5>c.length)return!0;for(let e=0;e<c.length;e++){if(c[e]&&c[e]<b||!c[e]&&(0==Aa[Va.$l[e]]&&!Aa.cn||1==Aa[Va.$l[e]]||2==Aa[Va.$l[e]]))return!0;!c[e]&&Aa.cn&&Sa.isUnderworld()}return!1},async eo(){var b=cb.origin;const c=cb.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);return(new DOMParser).parseFromString(await b.text(),"text/html")},async Km(b,
c){if(c){var e=JSON.parse(localStorage.getItem("gods")),h=this.$l[b],k=c.getElementById(h);k&&(c=parseInt(k.querySelector(".god_points").innerText.match(/\d+/)[0],10),k=k.querySelector(".god_cooldown span")?parseInt(k.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0,e=e[h],h=this.Wn[e],c>=h&&0==k&&0<h&&0<=e&&(Va.Um.push(!1),jQuery.get(G({mod:"gods",submod:"activateBlessing",god:b+1,rank:e+1,sh:W("sh")}),()=>{Va.Um.push(!1);5>b&&Va.Km(++b)})))}},async np(){var b=cb.origin,
c=cb.searchParams.get("sh")||"";b=await fetch(`${b}/game/index.php?mod=gods&sh=${c}`);c=new DOMParser;await new Promise(e=>setTimeout(e,800));b=c.parseFromString(await b.text(),"text/html");c=JSON.parse(localStorage.getItem("gods"));for(let e in c)if((c=b.getElementById(e))&&0===(c.querySelector(".god_cooldown span")?parseInt(c.querySelector(".god_cooldown span").getAttribute("data-ticker-time-left"),10):0))return!0;return!1}},kh,zj={async start(){const b=localStorage.getItem("healPercentage")||25;
var c=JSON.parse(localStorage.getItem("underworld")).isUnderworld;const e=localStorage.getItem("HealEnabled"),h=localStorage.getItem("HellHealHP")||15,k=localStorage.getItem("useVillaMedici"),g=localStorage.getItem("useHealingPotion"),l="true"===localStorage.getItem("usePray");if("true"==e&&ba.o<=Number(b)||"true"==e&&ba.o<=parseInt(h)||"true"==k&&ca==va&&ba.o<=b&&1==c||e&&"true"==g&&ba.o<=b&&1==c||e&&!c&&3>=Number(Fh().Fa)&&localStorage.getItem("autoEnterHell")&&ba.o<=localStorage.getItem("hellEnterHP")){c=
document.createElement("div");c.setAttribute("id","lowHealth");c.setAttribute("style","\n                display: block;\n                position: absolute;\n                top: 140px;\n                left: 50%;\n                transform: translateX(-30%);\n                width: 115px;\n                color: rgba(234, 20, 20, 0.9);\n                background-color: rgba(0, 0, 0, 0.8);\n                font-size: 20px;\n                border-radius: 5px;\n                border-left: 10px solid rgba(234, 20, 20, 0.9);\n                border-right: 10px solid rgba(234, 20, 20, 0.9);\n                will-change: transform, opacity;\n                z-index: 999;\n            ");
c.innerHTML='<span class="span-new">Low Health!</span>';document.getElementById("header_game").insertBefore(c,document.getElementById("header_game").children[0]);async function q(){if("inventoryPage"!==document.body.id)Dh("mod=inventory&sub=3&subsub=1");else{await new Promise(O=>setTimeout(O,500));var A=Array.from(document.querySelectorAll("#shop .ui-draggable"));const x=ba.gold,v=cb.searchParams.get("doll")||"";let C=!1,E=0,I=!1,K;var z=localStorage.getItem("HealPickBag");z&&(K=511+Number(z)||512);
for(const O of A){if(E>=Number(localStorage.getItem("FoodAmount")))break;A=parseInt(O.getAttribute("data-price-gold"),10);(z=(z=O.getAttribute("data-basis"))&&"7"===z.split("-")[0])&&(C=!0);if(x>=A&&z){C=!0;localStorage.removeItem("healingStateX");A=Array.from(document.querySelectorAll('#inventory_nav a.awesome-tabs[data-available="true"]'));if(K&&(z=document.querySelector(`#inventory_nav a.awesome-tabs[data-bag-number="${K}"]`)))if(z.click(),await new Promise(U=>setTimeout(U,370)),z=document.getElementById("inv"),
nf(z,O)){Ha(O,"inv");E++;await new Promise(U=>setTimeout(U,370));if(E>=Number(localStorage.getItem("FoodAmount"))&&"1"!==v){Dh("mod=overview&doll=1");return}continue}else I=!0;if(I||!K)for(const U of A){if(E>=Number(localStorage.getItem("FoodAmount")))break;U.click();await new Promise(Y=>setTimeout(Y,500));A=document.getElementById("inv");if(nf(A,O)&&(Ha(O,"inv"),E++,await new Promise(Y=>setTimeout(Y,370)),E>=Number(localStorage.getItem("FoodAmount"))&&"1"!==v)){Dh("mod=overview&doll=1");return}}}}C?
(D(`${d.sb}`),localStorage.removeItem("healingStateX"),await new Promise(O=>setTimeout(O,3E4)),window.location.reload()):"true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")?await J():(D(`${d.sb}`),localStorage.removeItem("healingStateX"),await new Promise(O=>setTimeout(O,3E4)),window.location.reload());async function J(){if("true"===localStorage.getItem("HealClothToggle")||"true"===localStorage.getItem("HealRubyToggle")){if(document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')){var O=
jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),U=O.attr("action");O=O.find('input[name="bestechen"]')[0];var Y=W("sh");await jQuery.post(`${U}?mod=inventory&sub=3&subsub=1&sh=${Y}`,{bestechen:O.value})?D(`${d.ub}`):D(`${d.vb}`)}else 0<Fh().vn&&"true"===localStorage.getItem("HealRubyToggle")&&!document.querySelector('img[src*="91e0372cccc24f52758be611a10a3b"]')?(O=jQuery('form[action*="index.php?mod=inventory&sub=3&subsub=1"]'),U=O.attr("action"),O=O.find('input[name="bestechen"]')[0],
Y=W("sh"),await jQuery.post(`${U}?mod=inventory&sub=3&subsub=1&sh=${Y}`,{bestechen:O.value})?D(`${d.ub}`):D(`${d.vb}`)):(D(`${d.Ef}`),localStorage.setItem("HealClothToggle","false"),localStorage.setItem("HealRubyToggle","false"));window.location.reload()}else localStorage.removeItem("healingStateX"),setTimeout(()=>{window.location.reload()},6E4)}return!1}}async function m(){if("guild"==W("mod"))localStorage.setItem("useVillaMedici","false"),Dh("mod=overview");else if("guild_medic"!=W("mod"))Dh("mod=guild_medic");
else{var A=Array.from(document.querySelectorAll("#content a")).filter(({href:z})=>z.includes("mod=guild_medic"));0<A.length?window.location.href=A[0].href:(A=Math.min(...Array.from(document.querySelectorAll("span[data-ticker-time-left]")).map(z=>parseInt(z.getAttribute("data-ticker-time-left"),10))),isFinite(A)&&Z("VillaMedici",Math.ceil(A/6E4)),l?(D(`${d.ua}`),Dh("mod=underworld&submod=prayStart")):window.location.reload())}}async function n(){let A=!1;if("mod=premium&submod=inventory"!=rf)Dh("mod=premium&submod=inventory");
else{await new Promise(z=>setTimeout(z,500));for(let z=0,x=document.querySelectorAll(".contentboard_paper_repeat");z<x.length;z++)if(x[z].querySelector("img").src&&x[z].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")||x[z].querySelector("img").src&&x[z].querySelector("img").src.includes("token/18")||x[z].querySelector("img").src.includes("5fd403b4efa8ea7bc3ca5a852bfce9")){A=!0;x[z].querySelector("input").click();If(1E3);return}A||(localStorage.setItem("useHealingPotion","false"),
l?(D(`${d.ua}`),Dh("mod=underworld&submod=prayStart")):If(1E3))}}async function r(){try{let E=document.getElementById("inv"),I=0,K;var A=localStorage.getItem("HealPickBag"),z=localStorage.getItem("PackageSort");K=A?511+Number(A)||512:512;var x=Array.from(document.querySelectorAll(`#inventory_nav a.awesome-tabs[data-bag-number="${K}"]`));0<x.length&&x[0].click();x=1;let J=0,O=!1;A=[];const U=Number(localStorage.getItem("FoodAmount"))||1;let Y=!1;if(z&&"del_asc"===z||z&&"in_asc"===z)x=await ha.gm(-1,
"",7),Y=!0;for(;!O&&5>J;){var v=await jQuery.get(G({mod:"packages",f:"7",fq:"-1",qry:"",page:x.toString(),sh:W("sh")})),C=jQuery(v).find(".packageItem");if(0===C.length)J++,Y?x--:x++;else{A=[];for(z=0;z<C.length;z++){const da=C[z],aa=da.querySelector("[data-content-type]"),oa=parseInt(aa.getAttribute("data-soulbound-to"),10),la=parseInt(aa.getAttribute("data-basis").split("-")[1],10);(![30,35].includes(la)&&isNaN(oa)||![30,35].includes(la)&&oa===Number(idkps))&&A.push(da)}0<A.length?O=!0:(D(`${d.wb} (Page ${x})`),
J++,Y?x--:x++)}}if(!O)return localStorage.setItem("healingStateX","true"),D(`${d.xb}`),!1;v=[5,8];const ia=Hc(E);for(C=0;I<U&&C<A.length;){const da=A[C],aa=da.querySelector("[data-content-type]"),oa=da.querySelector("input").getAttribute("value"),la=parseInt(aa.getAttribute("data-measurement-x"),10),wa=parseInt(aa.getAttribute("data-measurement-y"),10),Ja=parseInt(aa.getAttribute("data-amount"),10),Ab=Ic(v[0],v[1],ia),Ka=Jc(wa,la,Ab);if(Ka){ia.push({x:Ka.x,y:Ka.y,ml:wa,w:la});await jQuery.post(T({mod:"inventory",
submod:"move",from:"-"+oa,fromX:1,fromY:1,to:K,toX:Ka.x+1,toY:Ka.y+1,amount:Ja}),{a:(new Date).getTime(),sh:W("sh")});I++;const Kb=jQuery(aa).css({left:32*Ka.x,top:32*Ka.y});E.appendChild(Kb[0]);D(`${d.Cf}`);await new Promise(Wc=>setTimeout(Wc,500))}else{D(`${d.Df}`);break}C++}if(0<I)return I>=U?D(`${d.Ff}`):D(`${d.Gf}`),!0;D(`${d.xb}`);return!1}catch(E){return D(`Error in pickFood(): ${E}`),!1}}async function w(){var A=document.querySelector("#header_values_hp_bar");const z=parseInt(A.getAttribute("data-value"),
10);A=parseInt(A.getAttribute("data-max-value"),10);return{Xn:z,xo:A}}async function u(){var A=JSON.parse(localStorage.getItem("underworld")).isUnderworld,z="true"===localStorage.getItem("useSacrifice");const x="true"===localStorage.getItem("HealShop"),v=localStorage.getItem("HellHealHP")||15,C="true"===localStorage.getItem("healingStateX"),E="true"===localStorage.getItem("HealPackage"),I=document.getElementById("sstat_ruby_val");let K=0;I&&(K=I.textContent.trim().replace(/\./g,""),K=parseInt(K,10));
if(C&&x)await q()?await u():(localStorage.removeItem("healingStateX"),await y());else if(!0===A||"true"===g&&!0===A||!0===z&&!0===A)"true"===localStorage.getItem("useVillaMedici")&&X("VillaMedici")?m():"true"===localStorage.getItem("useHealingPotion")?await n():z&&5<=Number(K)?(D("Sacrificing for heal."),Dh("mod=underworld&submod=offering")):l&&"mod=underworld&submod=pray"!=rf&&("true"===localStorage.getItem("HealEnabled")?ba.o<=Number(v):1)?(D(`${d.ua}`),Dh("mod=underworld&submod=prayStart")):l&&
"mod=underworld&submod=pray"==rf&&("true"===localStorage.getItem("HealEnabled")?ba.o<=Number(v):1)?(await new Promise(J=>setTimeout(J,6E4)),D(`${d.Tf}`),window.location.reload()):(D(`${d.Uf}`),If(6E4));else if(0==A)if("1"!==((new URL(window.location.href)).searchParams.get("doll")||""))"mod=overview&doll=1"!=rf&&Dh("mod=overview&doll=1");else if(z=await y(),!z&&ba.o<=Number(b)||!z&&!A&&3>=Number(Fh().Fa)&&localStorage.getItem("autoEnterHell")&&ba.o<=localStorage.getItem("hellEnterHP"))E?(A=await r(),
!A&&x?(localStorage.setItem("healingStateX","true"),q()):(A||(D(`${d.tb}`),await new Promise(J=>setTimeout(J,3E4))),window.location.reload())):x?(localStorage.setItem("healingStateX","true"),q()):(D(`${d.tb}`),await new Promise(J=>setTimeout(J,3E4)),window.location.reload())}async function t(A,z,x){let v=null,C=0,E=Infinity;const I=localStorage.getItem("idkps")||0,K="true"===localStorage.getItem("HealCervisia"),J="true"===localStorage.getItem("HealEggs");let O=!1;K&&(O=await wf());A.forEach(U=>
{var Y=U.getAttribute("data-basis");const ia=parseInt(U.getAttribute("data-soulbound-to"),10);var da=(da=U.getAttribute("data-tooltip").match(/Heals ([\d,\.]+) of life/))?parseInt(da[1].replace(/\./g,""),10):0;const aa=x-(z+da);if(!ia||ia===parseInt(I,10)){if(Y.startsWith("7-")){Y=parseInt(Y.split("-")[1],10);if(!J&&23<=Y&&34>=Y||!K&&35===Y)return;if(K&&35===Y&&O)O=!0;else if(35===Y&&K&&!O)return}0<=aa&&aa<E?(v=U,E=aa):0>aa&&da>C&&(C=da,v=U)}});return v}async function y(){return new Promise(async A=>
{let z=!1;const {Xn:x,xo:v}=await w();var C=new URL(window.location.href);const E=C.origin;C=C.searchParams.get("sh");if("mod=overview&doll=1"!=rf)Dh("mod=overview&doll=1");else{const Y="true"===localStorage.getItem("HealPackage"),ia="true"===localStorage.getItem("HealShop"),da="true"===localStorage.getItem("HealCervisia"),aa="true"===localStorage.getItem("HealEggs");let oa=!1;da&&(oa=await wf());var I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs")),K=I.findIndex(la=>la.classList.contains("current"));
I=I.slice(K).concat(I.slice(0,K));for(K=0;K<I.length;K++){var J=I[K];if("false"!==J.getAttribute("data-available")&&(await new Promise(la=>setTimeout(la,175)),J.click(),J.classList.contains("current"))){J=document.querySelectorAll("#inv .ui-draggable");J=Array.from(J).filter(la=>{const wa=la.getAttribute("data-basis");la=parseInt(la.getAttribute("data-soulbound-to"),10);const Ja=parseInt(wa.split("-")[1],10);if(!la||la===parseInt(idkps,10)){if(wa.startsWith("7-")){if(!aa&&23<=Ja&&34>=Ja||!da&&35===Ja)return;
if(oa&&da&&35===Ja)oa=!0;else if(35===Ja&&da&&!oa)return}return wa&&"7"===wa.split("-")[0]}});var O=void 0,U=!1;if(Sa.cooldown()&&"true"==localStorage.getItem("autoEnterHell")){O=await (await fetch(`${E}/game/index.php?mod=hermit&sh=${C}`)).text();O=(new DOMParser).parseFromString(O,"text/html");O=Array.from(O.querySelectorAll('div[style="margin:20px"]'));for(let la of O)if(la.querySelector('a[href^="index.php?mod=hermit&submod=underworld&sh="]')){U=!0;break}}if(U){U=0;O=localStorage.getItem("idkps");
for(const la of J)if(J=parseInt(la.getAttribute("data-soulbound-to"),10),(!J||J===parseInt(O,10))&&"true"===localStorage.getItem("autoEnterHell"))if(la){if(await new Promise(wa=>setTimeout(wa,250)),await Ha(la,"avatar"),await new Promise(wa=>setTimeout(wa,450)),D(`${d.rb}`),U++,2<=U){window.location.reload();return}}else{J=!1;Y&&(J=await r());if(!J&&ia)return localStorage.setItem("healingStateX","true"),q(),!0;window.location.reload()}}else for(const la of J){z=!0;if(U=await t(J,x,v)){await new Promise(wa=>
setTimeout(wa,250));await Ha(U,"avatar");await new Promise(wa=>setTimeout(wa,450));D(`${d.rb}`);window.location.reload();return}U=!1;Y&&(U=await r());if(!U&&ia){localStorage.setItem("healingStateX","true");q();return}window.location.reload()}}}A(z)}})}await u()}}},Sa={isUnderworld(){if("underworld"==document.getElementById("wrapper_game").className){var b=JSON.parse(localStorage.getItem("underworld")||"{}");b.isUnderworld=!0;localStorage.setItem("underworld",JSON.stringify(b))}else b=JSON.parse(localStorage.getItem("underworld")||
"{}"),b.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(b));return(b=document.querySelector("#submenu2 a"))&&b.href.match(/mod=.*&sh/)&&"mod=underworld&submod=leave"===b.href.match(/mod=.*&sh/)[0].slice(0,-3)?!0:!1},hj(){return!0!==(JSON.parse(localStorage.getItem("underworld"))||{}).hj},cooldown(){var b=(new Date).getTime();let c=JSON.parse(localStorage.getItem("underworld"))||{};c.cooldown=b;localStorage.setItem("underworld",JSON.stringify(c));let e=document.getElementById("submenu2");
e&&e.innerHTML.includes("index.php?mod=underworld")?c.isUnderworld=!0:c.isUnderworld=!1;if(sa.cooldown&&sa.cooldown>b)return!1;if(b=document.querySelectorAll(".buff-clickable"))for(let h of b)if(h.getAttribute("data-link")=="index.php?mod=location&sh="+W("sh"))return!1;return!0},async start(){function b(){var v=`expedition_info${parseInt(localStorage.getItem("farmEnemy"),10)||1}`,C=document.getElementById(v);if(!C)return!1;v=C.querySelector(".expedition_picture img");C=C.querySelector(".expedition_picture .avatar_costume_animation");
if(!v&&!C)return!1;if(v){var E=v.getAttribute("src");if(!E)return!1;E=!E.includes("904194973d21066c96cb414d04d676")}C&&(E=C.style.backgroundImage.match(/url\("(.+?)"\)/),v=null,E&&E[1]&&(v=E[1]),E=!v.includes("904194973d21066c96cb414d04d676"));return E}async function c(v=!1){if(Sa.isUnderworld||!t){0<(JSON.parse(localStorage.getItem("GodPowersHell"))||[]).length&&0==v&&await e();Z("underworldArmorBuffs",15);var C="true"===localStorage.getItem("useWeaponBuff"),E=JSON.parse(localStorage.getItem("ArmorBuffsHell"))||
[];v=[];C&&v.push({type:"weapon",cc:"12-1",Yl:[3]});if(0<E.length){const I={Helmet:2,Armor:5,Shield:4,Boots:10,Gloves:9};C=E.map(K=>I[K]).filter(K=>K);0<C.length&&v.push({type:"armor",cc:"12-3",Yl:C})}0<v.length&&await h(v);localStorage.setItem("usedGodPowers","true")}}async function e(){if("true"===localStorage.getItem("useGodPowersHell")){var v=JSON.parse(localStorage.getItem("GodPowersHell"))||[],C="Minerva Diana Vulcan Mars Apollo Mercury".split(" ");for(let E of v)if(v=C.indexOf(E),-1<v)try{await jQuery.get(G({mod:"gods",
submod:"activateBlessing",god:v+1,rank:1,sh:W("sh")})),D(`${E} power activated`)}catch(I){}}}async function h(v){var C=v.map(I=>I.cc);const E={};C=await k(C);Object.assign(E,C);for(let I of v.slice())if(C=E[I.cc])await q(C,I.Yl),v=v.filter(K=>K.cc!==I.cc),D(`${I.type.charAt(0).toUpperCase()+I.type.slice(1)} buff equipped on slots ${I.Yl.join(", ")}`);0<v.length&&await g(v)}async function k(v){return new Promise(async C=>{const E={};var I=Array.from(document.querySelectorAll("#inventory_nav a.awesome-tabs"));
for(let K of I)if("false"!==K.getAttribute("data-available")){K.click();await new Promise(J=>setTimeout(J,200));I=Array.from(document.querySelectorAll("#inv .ui-draggable"));for(let J of I)if(I=J.getAttribute("data-basis"),v.includes(I)&&!E[I]){const O=parseInt(J.getAttribute("data-position-x"),10),U=parseInt(J.getAttribute("data-position-y"),10),Y=parseInt(J.getAttribute("data-container-number"),10);E[I]={fromX:O,fromY:U,from:Y};if(Object.keys(E).length===v.length){C(E);return}}}C(E)})}async function g(v){try{let C=
1;for(;1<=C&&7>=C&&0<v.length;){const E=await jQuery.get(G({mod:"packages",f:"12",page:C.toString(),sh:W("sh")})),I=Array.from(jQuery(E).find(".packageItem"));for(let K of I){const J=K.querySelector("[data-content-type]"),O=K.querySelector("[data-container-number]");J.getAttribute("data-measurement-x");J.getAttribute("data-measurement-y");const U=J.getAttribute("data-basis");O.getAttribute("data-container-number");const Y=O.getAttribute("data-container-number"),ia=v.find(da=>da.cc===U);if(ia&&await l(Y,
ia.Yl)&&(D(`${ia.type.charAt(0).toUpperCase()+ia.type.slice(1)} buff equipped on slots ${ia.Yl.join(", ")}`),v=v.filter(da=>da.cc!==U),0===v.length))return}C++}if(0<v.length)for(let E of v)D(`Could not find ${E.type} buff to equip.`)}catch(C){}}async function l(v,C){return new Promise((E,I)=>{mc(1,1,async(K,J)=>{try{await jQuery.post(T({}),{mod:"inventory",submod:"move",from:v,fromX:1,fromY:1,to:J,toX:K.x+1,toY:K.y+1,amount:1,a:(new Date).getTime(),sh:W("sh")});const O={fromX:K.x+1,fromY:K.y+1,from:J};
await q(O,C);E(O)}catch(O){console.error("Error moving item to inventory and equipping:",O),I(O)}})})}async function q(v,C){for(let E of C)await m(v.from,v.fromX,v.fromY,E,1,1,!0),await new Promise(I=>setTimeout(I,200))}async function m(v,C,E,I,K,J,O=!1){v={mod:"inventory",submod:"move",from:v,fromX:C,fromY:E,to:I,toX:K,toY:J,amount:1,a:(new Date).getTime(),sh:W("sh")};O&&(v.doll=1);await jQuery.post(T({}),v)}this.location=Array.from(document.querySelectorAll("#submenu2 a")).pop().href;var n="true"===
localStorage.getItem("farmEnable"),r=localStorage.getItem("farmLocation")||1;const w=localStorage.getItem("farmEnemy")||1;var u="true"===localStorage.getItem("useGodPowersHell");const t="true"===localStorage.getItem("usedGodPowers");var y=localStorage.getItem("hellLimit")||0;const A="true"===localStorage.getItem("EnableHellLimit");if(u&&!t){if("mod=overview&doll=1"!=rf){Dh("mod=overview&doll=1");return}await c()}if(X("underworldArmorBuffs")){if("mod=overview&doll=1"!=rf){Dh("mod=overview&doll=1");
return}await c(!0)}let z;n&&(z=b());u=localStorage.getItem("HellHealHP")||15;ba.o>=Number(u)&&await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:W("sh")}));if("true"==localStorage.getItem("exitUnderworld")&&0==Number(Fh().Fa))y=JSON.parse(localStorage.getItem("underworld")),y.isUnderworld=!1,localStorage.setItem("underworld",JSON.stringify(y)),await jQuery.get(G({mod:"underworld",submod:"exit",sh:W("sh")})),D(`${d.Vf}`),location.reload();else{if(0==Number(Fh().Fa)&&"true"==localStorage.getItem("UnderworldUseMobi")){if("mod=premium&submod=inventory"!==
rf){Dh("mod=premium&submod=inventory");return}u=document.querySelectorAll(".contentboard_paper_repeat");for(var x=0;x<u.length;){u[x].querySelector("img").src&&(u[x].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7")||u[x].querySelector("img").src.includes("c9ce614bbc67a9e85aa0ee87cf2bb7"))?u[x].querySelector("input").click():localStorage.setItem("UnderworldUseMobi","false");If(500);return}}x=document.querySelector("#submenu2");u=x.querySelector(`#location_inactive_${r}`);x=x.querySelector(`a[href*="loc=${r}"]`);
u=u&&u.classList.contains("inactive");if(!n||u&&!x||rf===`mod=location&loc=${r}`)if(n&&rf==`mod=location&loc=${r}`&&z&&(!A||A&&0<y))n=parseInt(w,10),r=document.getElementsByClassName("expedition_button"),A&&(y--,localStorage.setItem("hellLimit",y)),r[n-1].click(),If(5E3);else if(window.location.href!=this.location)window.location.href=this.location;else{await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:W("sh")}));let v=0;Array.from(document.querySelectorAll(".expedition_box")).forEach(C=>{C.querySelector(".expedition_picture img")&&
C.querySelector("img").src.includes("904194973d21066c96cb414d04d676")&&v++});document.querySelector("#content .icon_expeditionpoints")&&0<Number(Fh().Fa)||"true"==localStorage.getItem("UnderWorldUseRuby")&&"0"==Fh().Fa?(P("underworldAttacks",0),document.querySelectorAll(".expedition_button")[Math.floor(3-v)].click()):(D(`${d.Wf}`),await new Promise(C=>setTimeout(C,6E4)),If())}else Dh(`mod=location&loc=${r}`)}},async bo(){let b=0;const c=["normal","medium","hard"][parseInt(localStorage.getItem("hellDifficulty"),
10)||0],e=G({mod:"hermit",submod:"enterUnderworld",sh:W("sh")}),h={};h[`difficulty_${c}`]=c.charAt(0).toUpperCase()+c.slice(1);try{jQuery.post(e,h),localStorage.setItem("usedGodPowers","false"),await new Promise(k=>{const g=++b;var l=!document.hidden;let q=1;var m=jQuery("#server-time");0<m.length&&(m=m.next().html())&&(m=m.match(/x(\d+)$/)||["0","1"],m=parseInt(m[1],10),0<m&&(q=5/m));l=l?400:400*q;if("undefined"!==typeof Worker){const n=URL.createObjectURL(new Blob(["\n                            const timers = {};\n                            self.onmessage = function(event) {\n                                const { type, id, delay } = event.data;\n                                if (type === 'setTimeout') {\n                                    timers[id] = setTimeout(() => {\n                                        self.postMessage({ type: 'timeout', id });\n                                        delete timers[id];\n                                    }, delay);\n                                }\n                                if (type === 'clearTimeout') {\n                                    if (timers[id]) {\n                                        clearTimeout(timers[id]);\n                                        delete timers[id];\n                                    }\n                                }\n                            };\n                        "],
{type:"application/javascript"})),r=new Worker(n),w=u=>{"timeout"===u.data.type&&u.data.id===g&&(k(),r.removeEventListener("message",w),r.terminate(),URL.revokeObjectURL(n))};r.addEventListener("message",w);r.postMessage({type:"setTimeout",id:g,delay:l})}else setTimeout(()=>{k()},l)}),window.location.reload()}catch(k){}}};null===localStorage.getItem("DELAY")&&localStorage.setItem("DELAY","0 seconds");var Cc=localStorage.getItem("DELAY");if(Cc.includes("to")){const b=Cc.split(" "),c=parseInt(b[0],
10);var Xb=Math.floor(Math.random()*(parseInt(b[2],10)-c+1))+c}else Xb=parseInt(Cc.split(" ")[0],10);Cc.includes("minute")&&(Xb*=60);var Yb=1E3*Xb,Aj=localStorage.getItem("costumeUnderworld"),Bj=["9","10","11"],Dc="true"===localStorage.getItem("activateAuction2"),uh="true"===localStorage.getItem("auctionTURBO"),Ec="true"===localStorage.getItem("bidFood"),vh=9<ba.level,wh="true"===localStorage.getItem("enableCircusWithoutHeal"),Cj="true"===localStorage.getItem("resetUnderworld"),xh="true"===localStorage.getItem("auctiongladiatorenable"),
yh="true"===localStorage.getItem("auctionmercenaryenable"),Fc="true"===localStorage.getItem("enableMercenarySearch"),jf="true"===localStorage.getItem("EnableArenaHell"),Dj="true"===localStorage.getItem("dontEnterUnderworld"),Gc=0<JSON.parse(localStorage.getItem("auctionPrefixes")).length||0<JSON.parse(localStorage.getItem("auctionSuffixes")).length,Eb=localStorage.getItem("auctionStatus")>=localStorage.getItem("bidStatus"),zh=localStorage.getItem("auctionMStatus")>=localStorage.getItem("bidStatus"),
nb=JSON.parse(localStorage.getItem("underworld")),Fb=X("auction"),Ah=X("auctionM"),Bh=localStorage.getItem("MarketlastRan"),Ej=localStorage.getItem("MarketSearchInterval")||5,Fj=JSON.parse(localStorage.getItem("activeItemsGladiator")||"{}"),Gj=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}"),Ch=JSON.parse(localStorage.getItem("itemsToReset")||"[]");ra&&"true"===localStorage.getItem("activateRepair")&&pj();0<Yb&&11E3>Yb&&(D(`Waiting for ${Xb} seconds...`),await new Promise(b=>setTimeout(b,
Yb)));if(ra&&(0<Object.keys(Fj).length||0<Object.keys(Gj).length)&&"true"===localStorage.getItem("activateRepair")&&X("repair")&&!window.location.href.includes("/index.php?mod=hermit&submod=underworld")&&ca==va&&2E3<Fh().gold&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)){const b="true"===localStorage.getItem("repairGladiator"),c="true"===localStorage.getItem("repairMercenary");let e=[],h=[];const k=JSON.parse(localStorage.getItem("activeItemsGladiator")||
"{}"),g=JSON.parse(localStorage.getItem("activeItemsMercenary")||"{}");async function l(u,t,y){const A=localStorage.getItem("repairPercentage"),z=null!==A?parseInt(A,10)/100:.1;u=await (await fetch(`${u}/game/index.php?mod=overview&doll=${t}&sh=${y}`)).text();u=(new DOMParser).parseFromString(u,"text/html").getElementById("char").querySelectorAll("div[data-tooltip]");y=(y=localStorage.getItem("workbenchItem"))?JSON.parse(y):{};y.selectedItem=y.selectedItem||{};let x=[];u.forEach(v=>{if(v.classList.contains("ui-draggable")){let C=
ac(v),E=v.getAttribute("data-container-number"),I=v.getAttribute("data-measurement-x"),K=v.getAttribute("data-measurement-y"),J=JSON.parse(v.getAttribute("data-tooltip")).pop().pop()[0].match(/\d+/g);null!=J&&J[0]/J[1]<z&&x.push({type:xb(v),quality:wb(v),name:C,doll:t,container:E,hn:I,jn:K})}});return x}const q=cb.origin,m=cb.searchParams.get("sh")||"";let n=localStorage.getItem("workbenchItem");n=n?JSON.parse(n):{};b&&(e=await l(q,1,m),localStorage.setItem("itemList1",JSON.stringify(e)),ua.itemList1=
e);c&&(h=await l(q,2,m),localStorage.setItem("itemList2",JSON.stringify(h)),ua.itemList2=h);const r=JSON.parse(localStorage.getItem("Timers"));n.selectedItem||(b&&c?0===e.length&&0===h.length&&Z("repair",r.Repair||10):b?0===e.length&&Z("repair",r.Repair||10):c?0===h.length&&Z("repair",r.Repair||10):Z("repair",r.Repair||10));function w(u,t,y){return Array.isArray(u)&&0!==u.length?u.filter(A=>{const z=Object.keys(t).find(x=>t[x]===A.container);return z?!1!==y[z]:!0}):u}e=w(e,{helmet:"2",necklace:"11",
weapon:"3",armor:"5",shield:"4",gloves:"9",shoes:"10",rings1:"6",rings2:"7"},k);h=w(h,{helmetM:"2",necklaceM:"11",weaponM:"3",armorM:"5",shieldM:"4",glovesM:"9",shoesM:"10",rings1M:"6",rings2M:"7"},g);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(h));ua.itemList1=e;ua.itemList2=h;if(n.selectedItem&&!0===n.selectedItem.enable){let u=e.findIndex(t=>t.name===n.selectedItem.item.name);-1!==u&&e.splice(u,1);u=h.findIndex(t=>t.name===n.selectedItem.item.name);
-1!==u&&h.splice(u,1);localStorage.setItem("itemList1",JSON.stringify(e));localStorage.setItem("itemList2",JSON.stringify(h))}if(b&&0<e.length||c&&0<h.length||n.selectedItem&&0<Object.keys(n.selectedItem).length)await yj.start();else{const u=JSON.parse(localStorage.getItem("Timers"));Z("repair",u.Repair||10);window.location.reload()}}else if(0==await hj(va,gc,qa))hb();else if((Dc||Ec||Fc)&&uh&&Dc&&ra&&vh&&(xh&&Gc&&Eb&&Fb&&X("AuctionEmpty")||Ec&&Eb&&Fb&&X("AuctionEmpty")||Fc&&Eb&&Fb&&X("AuctionMEmpty")||
yh&&Gc&&zh&&Ah&&X("AuctionMEmpty")))await za.start();else if(ra&&3>=Number(Fh().Fa)&&!0===Ba&&"true"===localStorage.getItem("autoEnterHell")&&100<=ba.level&&8E3<=ba.gold&&ba.o>Number(localStorage.getItem("hellEnterHP"))&&Sa.cooldown()&&(Dj?Sa.hj():1))await Sa.bo();else if(1==ra&&"true"===localStorage.getItem("OilEnable")&&Va.Un()&&(!rh||36E5<=th-rh)){D(`${d.If}`);localStorage.setItem("OillastRan",th.toString());const b=await Va.eo();for(let c=0;c<Va.$l.length;c++)await Va.Km(c,b);D(`${d.Jf}`);cf()}else if(ra&&
(ba.o<=Number(localStorage.getItem("healPercentage"))&&"true"===localStorage.getItem("HealEnabled")&&!Sa.isUnderworld()||3>=Number(Fh().Fa)&&!Sa.isUnderworld()&&Sa.cooldown()&&"true"===localStorage.getItem("autoEnterHell")&&ba.o<=Number(localStorage.getItem("hellEnterHP"))||Sa.isUnderworld()&&"true"===localStorage.getItem("autoEnterHell")&&ba.o<=Number(localStorage.getItem("HellHealHP"))))await zj.start();else if(ra&&Ba&&"true"===localStorage.getItem("autoEnterHell")&&Sa.isUnderworld()&&Fh().co)await Sa.start();
else if(ra&&"true"==localStorage.getItem("useCostume")&&(!window.location.href.includes("/index.php?mod=hermit")&&X("CheckDolls")&&Bj.some(b=>Aj.includes(b))||!window.location.href.includes("/index.php?mod=hermit")&&X("CheckDolls")))await gf.start();else if(ra&&(!0===Oa&&M()&&ca==va||!0===Oa&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&Vb<Wb&&ca==va)){localStorage.setItem("nextQuestTime.timeOut",0);localStorage.setItem("nextQuestTime",0);function b(k){const g=
{Diana:"026bb622a42b4d00abc74c67f28d63",Apollo:"bb75bf0df76de3ec421bbfb0eac3c5",Vulcan:"6fbd05e43d699e65fc40cc92a17c51",Minerva:"72919cc6b457bf475fb81cc7de8863",Mercury:"5e272e2aade20b4a266e48663421ce",Mars:"5fd915f85b3e5e71b64632af0c6543"};k=k.querySelectorAll(".quest_slot_reward img");for(const l of k){k=l.getAttribute("src");for(const [q,m]of Object.entries(g))if(k.includes(m)&&"true"===localStorage.getItem(`questType${q}`))return!0}}function c(k){var g=JSON.parse(localStorage.getItem("acceptQuestKeywords")||
"[]").map(q=>q.toLowerCase());const l=parseInt(localStorage.getItem("questrewardvalue"),10);if(k=$(k).find(".quest_slot_reward_item")[0]){const q=k.outerHTML.toLowerCase();if(g.some(m=>q.includes(m))&&(g=q.match(/(\d+\.\d+)/))&&parseFloat(g[0].replace(".",""))>=l)return!0}return!1}async function e(){var k=cb.origin,g=$("#content .contentboard_slot a.quest_slot_button_accept"),l="true"===localStorage.getItem("skipTimeQuests");const q="true"===localStorage.getItem("skipTimeCircusQuests"),m="true"===
localStorage.getItem("skipTimeOtherQuests"),n="true"===localStorage.getItem("acceptnotfilter"),r="true"===localStorage.getItem("UnderworldQuests"),w=JSON.parse(localStorage.getItem("questKeywords")||"[]"),u=JSON.parse(localStorage.getItem("acceptQuestKeywords")||"[]"),t=JSON.parse(localStorage.getItem("underworldQuestKeywords")||"[]"),y=JSON.parse(localStorage.getItem("underworld")||"{}");var A=$("#content .contentboard_slot_inactive").toArray();if(g.length){function z(x){return x.includes("8aada67d4c5601e009b9d2a88f478c")?
"combat":x.includes("00f1a594723515a77dcd6d66c918fb")?"arena":x.includes("586768e942030301c484347698bc5e")?"circus":x.includes("4e41ab43222200aa024ee177efef8f")?"expedition":x.includes("dc366909fdfe69897d583583f6e446")?"dungeon":x.includes("5a358e0a030d8551a5a65d284c8730")?"items":null}g=!1;for(const x of A){let v=x.getElementsByClassName("quest_slot_title")[0].innerText;A=z(x.getElementsByClassName("quest_slot_icon")[0].style.backgroundImage);if(!(l&&0<x.getElementsByClassName("quest_slot_time").length&&
"arena"==A||q&&0<x.getElementsByClassName("quest_slot_time").length&&"circus"==A||m&&0<x.getElementsByClassName("quest_slot_time").length&&"circus"!==A&&"arena"!==A)){if(1==y.isUnderworld&&r&&!g&&0<t.length&&Pa[A]&&r){const C=$(x).find(".quest_slot_reward_item img[data-tooltip]")[0];if(C){A=C.getAttribute("data-tooltip");const E=JSON.parse(A.replace(/&quot;/g,'"'))[0][0][0].toLowerCase();if(t.some(I=>E.includes(I.toLowerCase()))){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");
await jQuery.get(l).done();g=!0;break}else continue}}if(!w.some(C=>v.includes(C))){if(Pa[A]&&b(x)){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();g=!0;break}if(Pa[A]&&c(x)&&!n){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();g=!0;break}if(Pa[A]&&u.some(C=>v.includes(C))){l=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href");await jQuery.get(l).done();g=!0;break}!g&&
Pa[A]&&n||g||!Pa[A]||n||0!==u.length||(g=x.getElementsByClassName("quest_slot_button_accept")[0].getAttribute("href"),await jQuery.get(g).done(),g=!0)}}}if(g)return;k=`${k}/game/index.php?mod=quests&submod=resetQuests&sh=${W("sh")}`;await jQuery.get(k).done();window.location.reload()}h()}async function h(){var k=$("#quest_header_cooldown");let g;switch(localStorage.getItem("questSpeed")){case "0":g=15E4;break;case "1":g=2E5;break;case "2":g=25E4;break;case "3":g=3E5;break;case "4":g=4E5;break;default:g=
3E5}k.length?(k=Number($("#quest_header_cooldown b span").attr("data-ticker-time-left")),Vb=Wb+k):Vb=Wb+g;localStorage.setItem("nextQuestTime",Vb);window.location.reload()}await async function(){if("mod=quests"!=rf)Dh("mod=quests");else{let k=[];const g=[],l=[];document.querySelectorAll("a.quest_slot_button_finish").forEach(n=>{n.href&&k.push(n.href)});document.querySelectorAll(".quest_slot_button_restart").forEach(n=>{n.href&&g.push(n.href)});document.querySelectorAll(".quest_slot_button_accept").forEach(n=>
{n.href&&l.push(n.href)});async function q(n){try{n<k.length&&(await jQuery.get(k[n]),await q(n+1))}catch(r){}}async function m(n){try{n<g.length&&(await jQuery.get(g[n]),await m(n+1))}catch(r){}}await async function(){0<k.length&&await q(0);0<g.length&&await m(0);0<l.length&&await e();await h()}()}}()}else if(ra&&Lc()&&!0===Ba&&0==nb.isUnderworld&&ca==va&&0==zb.isUnderworld&&ea>=new Date&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&!0===document.getElementById("cooldown_bar_fill_expedition").classList.contains("cooldown_bar_fill_ready"))await async function(){function b(){const l=
document.getElementById("errorText");"false"===localStorage.getItem("HealEnabled")?(Ya("Your expedition/dungeon settings are incorrect!"),localStorage.setItem("HealEnabled","true"),If(5E3)):l&&""!==l.innerText.trim()&&location.reload()}var c=localStorage.getItem("expeditionLocation");if(rf!=`mod=location&loc=${c}`)Dh(`mod=location&loc=${c}`);else if("true"===localStorage.getItem("nana_lcn")&&gc){var e="true"===localStorage.getItem("autoCollectBonuses"),h=localStorage.getItem("selectedEnemy")||0;c=
document.getElementsByClassName("expedition_button");var k=document.querySelectorAll(".expedition_button.disabled");try{if(document.querySelector(".expedition_cooldown_reduce"))bb("Your expedition settings are incorrect or there is an unexpected page data!"),window.location.reload();else if(P("expeditionAttacks",0),e){await new Promise(l=>setTimeout(l,800));for(var g=0;g<c.length;g++){if(4>c[g].closest(".expedition_box").querySelectorAll(".expedition_bonus.active").length||3===g){c[g].click();break}if(4<=
k.length){window.location.reload();break}else setTimeout(b,800)}}else g=c[parseInt(h,10)],g.classList.contains("disabled")?Ya("Your expedition setting is incorrect! You set it to disabled monster which is wrong."):(g.click(),Array.from(c).every(l=>l.classList.contains("disabled"))?(console.log("All buttons are disabled. Reloading..."),window.location.reload()):setTimeout(b,800))}catch{D("There's a problem with the expedition, refreshing the page."),window.location.reload()}}}();else if(ra&&!0===Fa&&
!nb.isUnderworld&&ca==va&&9<ba.level&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&Fh().ao&&"none"!==document.getElementById("cooldown_bar_dungeon").style.display&&!0===document.getElementById("cooldown_bar_fill_dungeon").classList.contains("cooldown_bar_fill_ready"))await async function(){if("true"===localStorage.getItem("nana_lcn")&&gc){var b=localStorage.getItem("dungeonLocation")||"1",c="true"===localStorage.getItem("skipBoss"),e="true"===
localStorage.getItem("resetIfLose"),h="true"===localStorage.getItem("loose"),k="true"===localStorage.getItem("dungeonFocusQuest"),g="chefe Chefe \u0161\u00e9f chef chef juht boss Boss jefe jefe jefe patron capo vad\u012bt\u0101js vadovas f\u0151n\u00f6k patron Patron \u0428\u0435\u0444 baas sjef szef chefe \u0219ef \u0161\u00e9f \u0161ef pomo chef patron \u0645\u062f\u064a\u0631 \u03b1\u03c6\u03b5\u03bd\u03c4\u03b9\u03ba\u03cc \u0448\u0435\u0444 \u0431\u043e\u0441\u0441 \u8001\u677f".split(" ");if(rf!=
`mod=dungeon&loc=${b}`)Dh(`mod=dungeon&loc=${b}`);else{b=!document.getElementById("content").getElementsByTagName("area")[0];const m=document.getElementById("content").getElementsByClassName("button1");if(2<=m.length){c=m[0].getAttribute("name");e=m[1].getAttribute("name");try{if(b){const n=(new URLSearchParams(window.location.search)).get("loc");"normal"===Jb&&"dif1"===c?(jQuery.post(G({mod:"dungeon",loc:n,sh:W("sh")}),{dif1:Jb}),m[0].click(),window.location.reload()):"dif2"===e?(jQuery.post(G({mod:"dungeon",
loc:n,sh:W("sh")}),{dif2:Jb}),m[1].click(),window.location.reload()):(Ya("Incorrect dungeon/expedition settings"),setTimeout(()=>{If()},1E4))}}catch(n){location.reload()}}else if(b)window.location.reload();else try{const n=document.querySelector("#content .map_label"),r=n&&n.textContent.toLowerCase(),w=Array.from(document.querySelectorAll("#content .map_label")).find(u=>g.some(t=>t===u.textContent));P("dungeonAttacks",0);if(e&&h)localStorage.setItem("loose","false"),document.querySelectorAll("#content .button1")[0].click();
else if(c&&r&&w)document.querySelectorAll("#content .button1")[0].click();else if(r&&w&&"true"===localStorage.getItem("dungeonAB"))w.click();else if(k){var l=0,q=null;document.querySelectorAll('[onclick*="startFight"]').forEach(function(u){var t=u.getAttribute("onclick").match(/startFight\('(\d+)',/);t&&t[1]&&(t=parseInt(t[1],10),t>l&&(l=t,q=u))});q?q.click():window.location.reload()}else document.querySelector("#content area").click()}catch{window.location.reload()}}}}();else if(ra&&(!0===Ga||nb.isUnderworld&&
jf)&&(!nb.isUnderworld||nb.isUnderworld&&jf)&&ca==va&&va===Mc&&ea>=new Date&&(nb.isUnderworld||"true"!==localStorage.getItem("HealEnabled")||ba.o>Number(localStorage.getItem("healPercentage"))||nb.isUnderworld&&ba.o>Number(localStorage.getItem("HellHealHP")))&&!0===document.getElementById("cooldown_bar_fill_arena").classList.contains("cooldown_bar_fill_ready")){async function b(){var k=new URL(window.location.href),g=k.origin;k=k.searchParams.get("sh")||"";var l=localStorage.getItem("scoreRange"),
q=[];g=await (await fetch(`${g}/game/index.php?mod=highscore&sh=${k}&a=${l}`)).text();g=(new DOMParser).parseFromString(g,"text/html");g=Array.from(g.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(m=>(m=m.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===m.style.color||"blue"===m.style.color):null===m);q=[...q,...g];if(0===q.length)return console.log("No players available to attack"),!1;g=JSON.parse(localStorage.getItem("avoidAttackList"))||
[];l=function(m){for(var n=m.length,r,w;0!==n;)w=Math.floor(Math.random()*n),--n,r=m[n],m[n]=m[w],m[w]=r;return m}(q);q=0;for(let m of l)if(l=m.textContent.toLowerCase(),!g.map(n=>n.toLowerCase()).includes(l)){l=await c(m.textContent,k);if(l.includes("index.php?mod=reports")){k=(new URLSearchParams(l)).get("reportId");D(`${d.ra}`+m.textContent);Dh(`mod=reports&submod=showCombatReport&t=2&reportId=${k}`);await new Promise(n=>setTimeout(n,500));return}q++;if(3<=q)break}return!1}async function c(k,g){try{const l=
(new URL(window.location.href)).origin;return await (await fetch(`${l}/game/ajax/doArenaFight.php?dname=${k}&a=${(new Date).getTime()}&sh=${g}`,{method:"POST"})).text()}catch{If(1E3)}}async function e(k){var g=k.opponentId;const l=k.serverId;k=k.country;var q=(new URL(window.location.href)).origin;q=new URL(`${q}/game/ajax.php`);g={mod:"arena",submod:"doCombat",aType:2,opponentId:g,serverId:l,country:k.toString(),a:(new Date).getTime(),sh:W("sh")};q.search=(new URLSearchParams(g)).toString();return await (await fetch(q,
{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function h(){function k(u){const t=null!==u.querySelector("span[style*='color:green;']");return Array.from(u.querySelectorAll("a, span")).find(y=>"green"===y.style.color||"bold"===y.style.fontWeight)||t}var g=new URL(window.location.href);const l=g.origin;var q=await (await fetch(`${l}/game/index.php?mod=arena&sh=${W("sh")}`)).text();q=(new DOMParser).parseFromString(q,"text/html");
var m=Array.from(q.querySelectorAll('table[width="80%"] tbody tr')).filter(u=>u.querySelector(".attack"));if(m.length&&1!==m.length){var n=null;q=JSON.parse(localStorage.getItem("avoidAttackList"))||[];if("true"===localStorage.getItem("leaguerandom")){m=m.sort(()=>Math.random()-.5);for(var r of m){var w=r.querySelector("a");w=w?w.innerText:null;if(!k(r)&&!q.includes(w)){n=r;break}}}else if("true"===localStorage.getItem("leaguelowtohigh")){m=m.sort((u,t)=>parseInt(u.querySelector("th")?u.querySelector("th").textContent:
"0",10)-parseInt(t.querySelector("th")?t.querySelector("th").textContent:"0",10));r=null;n=-1;for(w of m)m=(m=w.querySelector("a"))?m.innerText:null,k(w)||q.includes(m)||(m=parseInt(w?.querySelector("th")?.textContent,10),m>n&&(n=m,r=w));n=r}if(null===n)localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","false"),localStorage.setItem("leagueattackenable","false"),If(500);else if(n)if(q=n.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],w=(new Date).getTime(),
g=g.searchParams.get("sh")||"",await new Promise(u=>setTimeout(u,250)),g=await (await fetch(`${l}/game/ajax/doArenaFight.php?did=${q}&a=${w}&sh=${g}`)).text(),(q=g.match(/document\.location\.href\s*=\s*'([^']+)'/))&&q[1])window.location=`${l}/game/${q[1]}`;else{g.includes("5")&&("true"===localStorage.getItem("leaguelowtohigh")?(localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leaguerandom","true")):"true"===localStorage.getItem("leaguerandom")&&(localStorage.setItem("leaguerandom",
"false"),localStorage.setItem("leaguelowtohigh","false"),localStorage.setItem("leagueattackenable","false")),location.reload());if(g.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leagueattackenable","false"),location.reload()}nb.isUnderworld&&jf&&await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:W("sh")}));await async function(){function k(A){const z=Date.now(),x=u.findIndex(v=>v.playerName===A);-1<x?u[x].timeout=z:u.push({playerName:A,timeout:z});localStorage.setItem("playerTimeouts",
JSON.stringify(u))}function g(A,z){const x=Date.now();if(Array.isArray(u)){const v=u.find(C=>C.playerName===A);return!v||x-v.timeout>z}return!u[A]||x-u[A]>z}function l(A){for(var z=A.length-1;0<z;z--){const x=Math.floor(Math.random()*(z+1));[A[z],A[x]]=[A[x],A[z]]}2<A.length&&(z=A.splice(0,2),A.push(...z));return A}async function q(A,z,x){try{const v=z.match(/\d+/)[0],C=z.match(/\w+/g)[2],E=(new URLSearchParams(z)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:x,aType:A,
opponentId:E,serverId:v,country:C}));const I=await jQuery.get(T({mod:"arena",submod:"confirmDoCombat",aType:A,opponentId:E,serverId:v,country:C,a:(new Date).getTime(),sh:W("sh")})),K=(new URLSearchParams(I)).get("reportId");K||window.location.reload();Dh(`mod=reports&submod=showCombatReport&t=${A}&reportId=${K}`)}catch(v){document.getElementById("content").querySelector("form > input").click(),If(1E3)}}"true"===localStorage.getItem("leagueattackenable")&&await h();"true"===localStorage.getItem("scoreboardattackenable")&&
await b();var m=(new URL(window.location.href)).searchParams.get("sh")||"",n=JSON.parse(localStorage.getItem("autoAttackList"))||[];let r=JSON.parse(localStorage.getItem("autoAttackServerList"))||[];const w=JSON.parse(localStorage.getItem("avoidAttackList"))||[];let u=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const t="true"===localStorage.getItem("onlyArena");if(X("arena")&&0<n.length||X("arena")&&0<r.length||t)try{l(n);localStorage.setItem("autoAttackList",JSON.stringify(n));l(r);localStorage.setItem("autoAttackServerList",
JSON.stringify(r));let A=0,z=2,x=0,v=0;for(t&&(z=10);A<z&&(x<n.length||v<r.length);){let C,E,I;(I=x<n.length&&v<r.length?.5>Math.random():v<r.length)?(E=r[v],C=E.playerName,v++):(C=n[x],x++);if(!w.includes(C)&&(g(C,6E4*(10+Math.floor(36*Math.random())))||t)){let K;K=I?await e(E):await c(C,m);P("arenaAttacks",0);if(K.includes("index.php?mod=reports")&&!K.includes("errorRow")){k(C);D(`${d.ra}`+C);window.location.reload();break}}A++}if(A===z){const C=JSON.parse(localStorage.getItem("Timers"));Z("arena",
C.Arena||5)}}catch(A){window.location.reload()}if("mod=arena&submod=serverArena&aType=2"!=rf)Dh("mod=arena&submod=serverArena&aType=2");else try{let A=[...n,...r].map(v=>v.playerName);var y=Array.from(document.querySelectorAll("#own2 tr")).slice(1);const z="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),x="true"===localStorage.getItem("attackRandomly");m=null;n=Infinity;localStorage.getItem("Username");localStorage.getItem("enableArenaSimulator");localStorage.getItem("ArenaSimulatorAmount");
for(let v of y){const C=v.querySelector("a");y=2;x&&(y=Math.floor(5*Math.random())+2);const E=v.querySelector(`td:nth-child(${y})`);if(C&&E){const I=C.innerText,K=parseInt(E.textContent.trim(),10),J=w.includes(I),O=null!==C.querySelector("span[style*='color:green;']"),U="green"===C.style.color;if(!(J||!z&&O&&U)){if(A.includes(I)){D(`${d.ra}`+I);m=C;break}!m&&K<n&&(n=K,m=C)}}}if(m)await q(2,m.href,m.outerText),P("arenaAttacks",0);else{const v=document.querySelector('form[name="filterForm"] input[type="submit"]');
v&&v.click()}}catch{window.location.reload()}}()}else if(ra&&!0===Ca&&9<ba.level&&ca==va&&!0===document.getElementById("cooldown_bar_fill_ct").classList.contains("cooldown_bar_fill_ready")){async function b(){var g=new URL(window.location.href),l=g.origin;g=g.searchParams.get("sh")||"";var q=localStorage.getItem("scoreRangeCircus"),m=[];l=await (await fetch(`${l}/game/index.php?mod=highscore&sh=${g}&a=${q}`)).text();l=(new DOMParser).parseFromString(l,"text/html");l=Array.from(l.querySelectorAll(".section-like.narrow tr.alt span[data-tooltip] div a")).filter(n=>
(n=n.parentNode.querySelector('span[style="color:green;font-weight:bold;"]'))?!("green"===n.style.color||"blue"===n.style.color):null===n);m=[...m,...l];if(0===m.length)return console.log("No players available to attack"),!1;l=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];q=function(n){for(var r=n.length,w,u;0!==r;)u=Math.floor(Math.random()*r),--r,w=n[r],n[r]=n[u],n[u]=w;return n}(m);m=0;for(let n of q)if(q=n.textContent.toLowerCase(),!l.map(r=>r.toLowerCase()).includes(q)){q=await c(n.textContent,
g);if(q.includes("index.php?mod=reports")){g=(new URLSearchParams(q)).get("reportId");D(`${d.sa}`+n.textContent);Dh(`mod=reports&submod=showCombatReport&t=3&reportId=${g}`);await new Promise(r=>setTimeout(r,500));return}m++;if(3<=m)break}return!1}async function c(g,l){try{const q=(new URL(window.location.href)).origin;return await (await fetch(`${q}/game/ajax/doGroupFight.php?dname=${g}&a=${Date.now()}&sh=${l}`,{method:"POST"})).text()}catch{If(1E3)}}async function e(g){var l=g.opponentId;const q=
g.serverId;g=g.country;var m=(new URL(window.location.href)).origin;m=new URL(`${m}/game/ajax.php`);l={mod:"arena",submod:"doCombat",aType:3,opponentId:l,serverId:q,country:g.toString(),a:(new Date).getTime(),sh:W("sh")};m.search=(new URLSearchParams(l)).toString();return await (await fetch(m,{method:"GET",credentials:"include",headers:new Headers({"Content-Type":"application/x-www-form-urlencoded"})})).text()}async function h(){function g(t){const y=null!==t.querySelector("span[style*='color:green;']");
return Array.from(t.querySelectorAll("a, span")).find(A=>"green"===A.style.color||"bold"===A.style.fontWeight)||y}var l=new URL(window.location.href);const q=l.origin;var m=await (await fetch(`${q}/game/index.php?mod=arena&submod=grouparena&sh=&sh=${W("sh")}`)).text();m=(new DOMParser).parseFromString(m,"text/html");var n=Array.from(m.querySelectorAll('table[width="80%"] tbody tr')).filter(t=>t.querySelector(".attack"));if(n.length&&1!==n.length){var r=null;m=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||
[];if("true"===localStorage.getItem("leaguecircusrandom")){n=n.sort(()=>Math.random()-.5);for(var w of n){var u=w.querySelector("a");u=u?u.innerText:null;if(!g(w)&&!m.includes(u)){r=w;break}}}else if("true"===localStorage.getItem("leaguecircuslowtohigh")){n=n.sort((t,y)=>parseInt(t.querySelector("th")?t.querySelector("th").textContent:"0",10)-parseInt(y.querySelector("th")?y.querySelector("th").textContent:"0",10));w=null;r=-1;for(u of n)n=(n=u.querySelector("a"))?n.innerText:null,g(u)||m.includes(n)||
(n=parseInt(u?.querySelector("th")?.textContent,10),n>r&&(r=n,w=u));r=w}if(null===r)localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircusattackenable","false"),If(500);else if(r)if(m=r.querySelector(".attack").getAttribute("onclick").match(/\d+/)[0],u=(new Date).getTime(),l=l.searchParams.get("sh")||"",await new Promise(t=>setTimeout(t,250)),l=await (await fetch(`${q}/game/ajax/doGroupFight.php?did=${m}&a=${u}&sh=${l}`)).text(),
(m=l.match(/document\.location\.href\s*=\s*'([^']+)'/))&&m[1])window.location=`${q}/game/${m[1]}`;else{l.includes("5")&&("true"===localStorage.getItem("leaguecircuslowtohigh")?(localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusrandom","true")):"true"===localStorage.getItem("leaguecircusrandom")&&(localStorage.setItem("leaguecircusrandom","false"),localStorage.setItem("leaguecircuslowtohigh","false"),localStorage.setItem("leaguecircusattackenable","false")),location.reload());
if(l.includes("errorRow"))return!1;window.location.reload()}}else localStorage.setItem("leaguecircusattackenable","false"),location.reload()}async function k(){function g(z){const x=Date.now(),v=t.findIndex(C=>C.playerName===z);-1<v?t[v].timeout=x:t.push({playerName:z,timeout:x});localStorage.setItem("playerTimeouts",JSON.stringify(t))}function l(z,x){const v=Date.now();if(Array.isArray(t)){const C=t.find(E=>E.playerName===z);return!C||v-C.timeout>x}return!t[z]||v-t[z]>x}function q(z){for(var x=z.length-
1;0<x;x--){const v=Math.floor(Math.random()*(x+1));[z[x],z[v]]=[z[v],z[x]]}2<z.length&&(x=z.splice(0,2),z.push(...x));return z}async function m(z,x,v){try{const C=x.match(/\d+/)[0],E=x.match(/\w+/g)[2],I=(new URLSearchParams(x)).get("p");localStorage.setItem("tempOpponentDetails",JSON.stringify({playerName:v,aType:z,opponentId:I,serverId:C,country:E}));const K=await jQuery.get(T({mod:"arena",submod:"confirmDoCombat",aType:z,opponentId:I,serverId:C,country:E,a:(new Date).getTime(),sh:W("sh")})),J=
(new URLSearchParams(K)).get("reportId");J||window.location.reload();Dh(`mod=reports&submod=showCombatReport&t=${z}&reportId=${J}`)}catch(C){document.getElementById("content").querySelector("form > input").click(),If(1E3)}}"true"===localStorage.getItem("leaguecircusattackenable")&&await h();"true"===localStorage.getItem("scoreboardcircusenable")&&await b();var n=(new URL(window.location.href)).searchParams.get("sh")||"",r=JSON.parse(localStorage.getItem("autoAttackCircusList"))||[];let w=JSON.parse(localStorage.getItem("autoAttackCircusServerList"))||
[];const u=JSON.parse(localStorage.getItem("avoidAttackCircusList"))||[];let t=JSON.parse(localStorage.getItem("playerTimeouts"))||[];const y="true"===localStorage.getItem("onlyCircus");localStorage.getItem("CircusSimulatorAmount");if(X("circus")&&0<r.length||X("circus")&&0<w.length||y)try{q(r);localStorage.setItem("autoAttackCircusList",JSON.stringify(r));q(w);localStorage.setItem("autoAttackCircusServerList",JSON.stringify(w));let z=0,x=2,v=0,C=0;for(y&&(x=10);z<x&&(v<r.length||C<w.length);){let E,
I,K;(K=v<r.length&&C<w.length?.5>Math.random():C<w.length)?(I=w[C],E=I.playerName,C++):(E=r[v],v++);if(!u.includes(E)&&(l(E,6E4*(10+Math.floor(36*Math.random())))||y)){let J;J=K?await e(I):await c(E,n);P("circusAttacks",0);if(J.includes("index.php?mod=reports")&&!J.includes("errorRow")){g(E);D(`${d.sa}`+E);window.location.reload();break}}z++}if(z===x){const E=JSON.parse(localStorage.getItem("Timers"));Z("circus",E.CircusTurma||5)}}catch(z){window.location.reload()}if("mod=arena&submod=serverArena&aType=3"!=
rf)Dh("mod=arena&submod=serverArena&aType=3");else try{if(document.querySelector(".messages .message.fail"))localStorage.setItem("doCircus",!1),window.location.reload();else{let z=[...r,...w].map(C=>C.playerName);var A=Array.from(document.querySelectorAll("#own3 tr")).slice(1);const x="true"===localStorage.getItem("circusAttackGM")||"true"===localStorage.getItem("arenaAttackGM"),v="true"===localStorage.getItem("attackRandomly");n=null;r=Infinity;localStorage.getItem("Username");localStorage.getItem("enableCircusSimulator");
for(let C of A){const E=C.querySelector("a");A=2;v&&(A=Math.floor(5*Math.random())+2);const I=C.querySelector(`td:nth-child(${A})`);if(E&&I){const K=E.innerText,J=parseInt(I.textContent.trim(),10),O=u.includes(K),U=null!==E.querySelector("span[style*='color:green;']"),Y="green"===E.style.color;if(!(O||!x&&U&&Y)){if(z.includes(K)){D(`${d.sa}`+K);n=E;break}!n&&J<r&&(r=J,n=E)}}}if(n)await m(3,n.href,n.outerText),P("circusAttacks",0);else{const C=document.querySelector('form[name="filterForm"] input[type="submit"]');
C&&C.click()}}}catch{window.location.reload()}}1==zb.isUnderworld?(await jQuery.get(G({mod:"underworld",submod:"prayEnd",sh:W("sh")})),await k()):wh?await k():!wh&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&await k()}else if(ra&&!0===Da&&X("eventPoints")&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&0<jQuery("#submenu2 a").filter(".glow").length)await async function(){var b=jQuery("#submenu2 a").filter(".glow")?
jQuery("#submenu2 a").filter(".glow")[0].href.match(/mod=.*&sh/)[0].slice(0,-3):null;if(rf!=b)Dh(b);else{b=document.querySelector("#content .ticker");let c=parseInt(document.querySelectorAll(".section-header p")[1].innerText.match(/\d+/g)[0],10),e=nc;localStorage.setItem("eventPoints_",c);if(b){b=document.querySelector('[data-ticker-type="countdown"]').textContent.trim().split(" ").pop();let [h,k,g]=b.split(":").map(Number);(b=(new Date).getTime()+1E3*(3600*h+60*k+g)+1)?localStorage.setItem("eventPoints.timeOut",
b):Z("eventPoints",5);setTimeout(Dh,1E3,"mod=overview")}else!b&&0<c?(3==e&&1==c&&(e=2),setTimeout(Eh,1E3,document.querySelectorAll(".expedition_button")[e])):!c&&"true"===localStorage.getItem("renewEvent")&&0<Fh().vn?((new URL(window.location.href)).searchParams.get("loc"),setTimeout(Eh,1E3,document.querySelectorAll(".expedition_button")[e])):0==c&&"false"===localStorage.getItem("renewEvent")?(Z("eventPoints",5),location.reload()):0==c&&setTimeout(Dh,5E3,"mod=overview")}}();else if((Dc||Ec||Fc)&&
!uh&&Dc&&ra&&vh&&(xh&&Gc&&Eb&&Fb&&X("AuctionEmpty")||Ec&&Eb&&Fb&&X("AuctionEmpty")||Fc&&Eb&&Fb&&X("AuctionMEmpty")||yh&&Gc&&zh&&Ah&&X("AuctionMEmpty")))await za.start();else if(ra&&5<ba.level&&"true"==localStorage.getItem("storeGoldinAuction")&&Number(Fh().gold)>Math.floor(Number(localStorage.getItem("storeGoldinAuctionmaxGold")))&&X("enableHideGold"))await mb.A.start();else if(ra&&"true"===localStorage.getItem("resetExpiredItems")&&(0<Ch.length||Cj)&&5E3<=ba.gold&&X("resetExpired"))await lj(localStorage.getItem("resetDays"),
Ch);else if(ra&&("true"===localStorage.getItem("HealEnabled")?ba.o>Number(localStorage.getItem("healPercentage")):1)&&Gh()&&"true"===localStorage.getItem("doKasa")&&X("gold")&&Fh().gold>Math.floor(localStorage.getItem("KasaHoldGold")))await Uh();else if(ra&&"true"===localStorage.getItem("EnableSmelt")&&ha.Vm()&&1E3<ba.gold&&X("smelt"))X("smeltCheck")&&(ha.slots=await ha.u(),await ha.um(ha.slots),await ha.Lm(ha.slots),"true"===localStorage.getItem("EnableSmelt")&&1E3<ba.gold&ha.Vm()&&X("smelt")&&await ha.start());
else if(ra){if("true"==localStorage.getItem("useCostume")&&X("CheckDolls"))await vj.start();else if("true"===localStorage.getItem("HealEnabled")&&"true"==localStorage.getItem("BuffsEnable")&&X("BuffCheck"))await oj();else if(!Bh||Wb-Bh>=6E4*Ej)localStorage.setItem("MarketlastRan",Wb.toString()),"true"==localStorage.getItem("enableMarketSearch")&&ca==va&&"true"==sessionStorage.getItem("autoGoActive")&&await hf.Tn();11001<Yb&&(D(`Waiting for ${Xb} seconds...`),await new Promise(b=>setTimeout(b,Yb)));
cf()}let z3=localStorage.getItem("we");we=new Date(z3);ea<new Date&&we<new Date&&ca!=va&&hb()}}})();const Ih={Fk:"Your expedition settings are incorrect or there is an unexpected page data!",Gk:"Your expedition setting is incorrect! You set it to disabled monster which is wrong.",Tk:"Reset only all underworld items with selected color?",Ba:"Priority",Rb:"Set Priority",Lg:"Points",Eh:"Stat",Mi:"Collect Gold",Jj:"Sell Underworld Items?",nj:"Bot will look for nest in every action, not just expeditions.",lj:"Nest Search Type",jj:"Nothing",kj:"Quick",mj:"Thorough",Bj:"After expedition points are consumed, travel to Germania to consume Dungeon points",
sk:"Use this if the bot gets stuck in the repair!",Hk:"When HP is below, use heal",Hg:"Partial Repair",Ve:"Full Repair",Gg:"Partial or Full Repair",me:"Enable Limit",ej:"Limit",fj:"If you want to limit the number of times you want to attack to the enemy, enable this option and set the limit. Bot will continue to attack rest of the enemies after it finishes attacking to the selected monster.",he:"Do not enter underworld with underworld costume?",ge:"If you dont want to enter underworld while you have underworld costume on, enable this option",
si:"Underworld",ji:"Underworld Buffs",li:"Use god powers after entering the underworld?",mi:"Select gods to use powers from:",ni:"Use Weapon Buff on the weapon?",oi:"Use Armor Buff on the following equipment:",Ck:"Cooldown is 30 minutes. If you dont have a costume on you, bot will reset cooldown to 0.",Uk:"Select Colors",Ya:"Vulcanus Forge",bb:"Feronia`s Earthen Shield",cb:"Neptune`s Fluid Might",eb:"Aelous` Aerial Freedom",fb:"Pluto`s Deadly Mist",gb:"Juno`s Breath of Life",hb:"Wrath Mountain`s Scale Armour",
ib:"Eagle Eyes",jb:"Saturn`s Winter Garment",Za:"Bubona` Bull Armour",$a:"Mercerius` Robber`s Garments",ab:"Ra` Light Robe",fg:"Packages",ag:"Inventory",K:"Min Price",J:"How Many",Cb:"Sell Items",Bb:"Search in",bg:"Material Color",Ab:"Item Color",ig:"Warehouse",za:"Switch to Materials",Eb:"Switch to Items",hg:"Sell Materials",wa:"Please enter a valid item name and price range and how many.",xa:"No suitable items found in the selected search locations.",ya:"All items listed successfully!",Nk:"All materials listed successfully!",
dg:"If you want to sell items for fixed price, you can enter the same value for both min and max price.",eg:"This feature is still experimental, use with caution. If you dont put fixed price, it will list items randomly between min and max price you enter.",Fj:"Repair Before Smelt",Qj:"Select the item types you want to smelt.",Rj:"Select the colors you want to smelt.",Sj:"Select the level of the items you want to smelt.",Tj:"Select the hammer you want to use",Uj:"Note that Green and Red circle next to the first box are for enabling/disabling the rule.",
Vj:"If you want to use smelt randomly any colors or types, you can enable `Smelt randomly if no conditions met? (Last enabled option in the tutorial video)",yk:"Sets the max gold that the bot will spend per cycle.",Ta:"Bot will start bidding on any food items, if enabled. You do not require to enable gladiator/mercenary toggles",Gd:"Bot will not bid on allies` bids.",Hd:"Ignore Prefix/Suffix Combination when looking for an item in the auction.",Ie:"Select Monster",we:"Use Hourglass/Ruby?",Ek:"Use Ruby?",
ze:"Use Mobilization?",ye:"Use Life Potion?",ve:"Heal Percentage (%)",Ge:"Number of Attacks",xe:"Attack Interval (in seconds)",te:"Attacks Performed",ue:"Hourglass Left",Ee:"Note: It uses lifepotions to heal, not food.",Fe:"Note: If attacks stop prematurely, try 'Reset Attacks'.",Je:"Start",He:"Reset",Ke:"Stop",Le:"Expedition Settings (Click to minimize)",Ae:"Monster 1",Be:"Monster 2",Ce:"Monster 3",De:"Monster 4",Qk:"Repair Before Smelt",Ki:"This option will use cervisia when your premium expires.",
qj:"This option will enables and picks oils from god rewards. It can use number 1 and number 3 oils on the character but number 2 will only be picked to packages.",Ii:"This option will use buffs at the time you set. It will find buffs in packages and apply it to the character.",gj:"This option will enter you to the underworld when your expedition points are below 3. Dont forget to enable Auto Login from Extras tab, otherwise you might get logged out upon entering underworld[Game Bug]",Zb:"Bot normally picks random 3 to 6 tries to attack arena list. If you enable this option, it will go through your list until it can attack someone. This might take some time.",
Cj:"This option is only for premium licenses. It simulates the attack before attacking a user for %75 win rate.",Jd:"You do not need to enable main auction toggle to enable this option.",kk:"This option will refresh the page every second when auction is in -Very Short- state to bid constantly to win the auction.",Oj:"If none of the smelt conditions are met, it will smelt randomly. Make sure to select item type and color.",Pj:"This option will only smelt items from inventory. It will ignore items in packages.",
Ua:"Auction Items",lg:"Mercenary Items",Tb:"Shop Items",ui:"Unique Items",Kj:"Set background to black [Increases performance]",Lj:"Move GLDbot buttons to bottom left?",Li:"Attack Circus Without Heal",jk:"Pick gold from packages if needed?",Tl:"Gold has been picked from packages for training",Ad:"No gold has been found in packages for training",wl:'GLDbot: Use the dices to refresh the mystery box and find valuable items before opening them (Etc. Costumes). Click "Start" open chests.',gk:"Items Repaired",
$j:"Arena Attacks",bk:"Circus Attacks",zd:"Items Reset",ek:"Expedition Attacks",dk:"Dungeon Attacks",hk:"Underworld Attacks",ak:"Money Earned from Arena",ck:"Money Earned from Circus",Rl:"Items Smelted",fk:"Gold Cycled",Yi:"Guild Battle",$i:"Guild Settings",ll:"Will attack guilds randomly.",Xi:"Attack Random Guilds?",Zi:"Guild Name",Ji:"Reset Stats",Kc:"Wood",Ac:"Copper",Ec:"Iron",Gc:"Leather",Lc:"Wool",Bc:"Cotton Wool",Dc:"Hemp",Cc:"Gauze Strip",Hc:"Linen Strip",Fc:"Jute Patch",Jc:"Velvet",Ic:"Silk Thread",
Tc:"Fur",Nc:"Bone Splinter",Wc:"Scale",Qc:"Claw",Sc:"Fang",Rc:"Dragon Scale",Oc:"Bull`s Horn",Vc:"Poison Gland",Pc:"Cerberus` Pelt",Uc:"Hydra Scale",Xc:"Sphinx Feather",Yc:"Typhon Leather",wc:"Lapis Lazuli",qc:"Amethyst",pc:"Amber",rc:"Aquamarine",xc:"Sapphire",uc:"Garnet",tc:"Emerald",sc:"Diamond",vc:"Jasper",yc:"Sugilite",kc:"Scorpion Poison",nc:"Tincture of Stamina",fc:"Antidote",ec:"Adrenaline",mc:"Tincture of Enlightenment",jc:"Potion of Perception",hc:"Essence of Reaction",ic:"Phial of Charisma",
oc:"Waters of Oblivion",lc:"Soul Essence",xd:"Water Seal",rd:"Protection Rune",pd:"Earth Mark",wd:"Totem of Healing",vd:"Talisman of Power",td:"Stone of Fortune",qd:"Flintstone",ud:"Storm Rune",sd:"Shadow Rune",cd:"Crystal",bd:"Bronze",gd:"Obsidian",kd:"Silver",ld:"Sulphur",ed:"Gold Ore",jd:"Quartz",hd:"Platinum",ad:"Almandin",dd:"Cuprit",fd:"Hellstone",Fi:"Attack Randomly in Provinciarum?",Gi:'Also disable "Sort players in arena by level" setting in crazy-addon.',Ug:"Only accept quests based on god type.",
Va:"Auto Buff",Xd:"Use it in hell only?",Ag:"New Rule",yg:"Name Contains",isUnderworldItem:"Is Underworld Item",df:"Ignore Materials",rk:"Use Pray?",ri:"When in underworld only accept underworld related quests?",pi:"If enabled, you need to enter underworld item names. If the bot finds these items in the underworld, it will accept the quest.",Yk:"Underworld Quest Item",il:"Enter Material Name",Bk:"The bot loves dice! They help find clothes in chests. But if there are no dice, the bot opens chests anyway, hoping for some cool clothes (but it might not find any!).",
Nj:"Send smelted materials to package?",le:"Enable Arena",Mg:"Prioritize arena list?",Ng:"Prioritize circus list?",de:"Disable Log Menu",ih:"Reward Min. Gold Value",Vg:"Focus Quest, if enabled, will follow the shortest path to finish the dungeon.",Hh:"Throw Dice Automatically?",Ih:"Use throw dice cautiously, it will keep using the first dice until you disable the option.",nh:"Search Progress",bh:"Cooldown for repair by default is 10 minutes.",vg:"Minimum Condition",be:"Current item on workbench [Clear if bot pauses unexpectedly]",
Af:"Forge Resources stored to horreum successfully.",wf:"Checking marketplace for items...",yb:"Item moved to workbench.",Nf:"Item successfully repaired and equipped.",Of:"Item successfully repaired.",Lk:"Repair failed. Page will be refreshed.",Kf:"Picking up materials...",Xf:"Waiting for repair...",Mf:"Repair has started for .",va:"Repair: Moving the item from inventory to bag",Lf:"Repair: Moving the item from workbench to package.",ta:"Could not find enough materials. Disabling the repair slot for 5 minutes ",
Hf:"Looking for items to buy to hide gold in Auction...",tf:"Checking for expired items in packages...",uf:"Item successfully reset.",vf:"No Empty Space or Gold to Reset.",Bf:"Make sure you have sell rights in guild market!",sb:"Not enough gold/or no item to buy. Waiting for 30sec to refresh.",ub:"Store has been refreshed.",vb:"Error while healing.",Ef:"No Ruby or Cloth, disabling the options.",Kk:"No healing item found in packages.",wb:"No suitable items found",Ff:"Foods have been picked. Ending the process.",
Gf:"At least one food has been picked. Ending process.",xb:"No suitable space found in bag to pick food.",Cf:"Getting food from packages.",Df:"No suitable space found in bag to pick food.",tb:"No more heal items. Waiting for 30 seconds.",rb:"HP Recovered.",ua:"Nothing to do so I am going to pray!",Tf:"Im going to refresh in 60 seconds to check for my health and villa medici.",Uf:"Waiting for Villa Medici, refreshing in 60 seconds.",Vf:"Left underworld.",Wf:"Im going to refresh in 60 seconds to check for my health.",
If:"Checking for god oils...",Jf:"God oils have been picked.",ra:"Successfully attacked player in ARENA: ",sa:"Successfully attacked player in CIRCUS: ",rf:"Checking auction! Please wait...",sf:"Bidding to items. Please wait...",Pf:"Auto Smelted Item: ",Qf:"Smelting Item: ",Rf:"Not enough gold to smelt. Required Gold: ",Sf:"SMELT: Looking for items to smelt...",Mk:"Looking for items to smelt...",xf:"Checking costume availability...",zf:"Donated : ",yf:"Throwing dice...",Re:"Underworld Farm [Manual, Beta]",
Se:"Be aware: Turn on this feature after unlocking the creature you want to attack, it will not automatically attack to unlock the monster.",Qe:"Farm Location",Pe:"Farm Enemy",Qd:"Auto Login",Rd:"You need to allow pop-ups from the lobby screen for GameForge. See documentation on how to do it.",Ig:"Pause Bot",Jg:"Pause Bot in (Minutes)",Ne:"Expiration Date",Dg:"Only buy food?",Eg:"If you enable this, it will ignore your selections and buy food automatically without entering anything.",Gb:"Max total gold to spend",
Fb:"Max gold per food to spend",Cg:"Bot will check oils every 60 minutes",$h:"Sets a timer to check smelting times.",Xh:"Sets a timer to check smelting after you dont have gold.",Zh:"Sets a timer to check smelting if you dont have available item.",Sh:"Sets a timer for repair to check your items.",Rh:"Sets a timer to check guild market hold gold.",Nh:"Sets a timer for auction hold gold option.",Jh:"Sets a timer to check the arena pvp list to attack.",Oh:"Sets a timer to check the circus pvp list to attack.",
fi:"Sets a timer for training to train your stats.",Uh:"Sets a timer to reset expired items.",di:"Sets a timer to store forge materials to horreum.",Lh:"Sets a timer to check gladiatos & mercenary auction.",Wh:"Sets a timer to search for items in auction&shop.",Ph:"Sets the timer of sending donation to the guild.",We:"Gold Moved",ie:"Don't sell smelt & auction list items",oh:"Shop Automation",qh:"Item Search Settings",ph:"Use this tool to search for items in shops. Simply add the items to the list, specify the cloth amount, and start the search.",
rh:"Cloths to use:",th:"How many cloths to use?",ea:"Enter Full Item Name",Sb:"Enter Item Level",vh:"Item Quality",uh:"Item Name Here",wh:"Start Searching",xh:"Skip and Continue",yh:"Stop Searching",Te:"Buy cheapest or expensive?",xg:"Most Expensive",Zd:"Cheapest",ba:"Select an option",ne:"Highlight Underworld Items",Ue:"Focus on the quest?",Vl:"Use ruby if there isnt cloth?",Wa:"Add cross-server players: Find profile, use A & C buttons. Play nice: Avoid targeting same players to dodge reports/bans.",
Kl:"Smelt Green?",Pg:"Do not accept random quests if entered any filters?",Mc:"Max Material Quality to use",Ui:"Enable Mercenary Search",sl:"Click \u2018Sell All Selected\u2019 to sell all items. Make sure to have 2x3 empty space in your first (1) bag and select quality. To mass collect Gold, use `USE GOLD` panel below or filter gold and use the `Pick Selected or Pick All`",Zj:"\ud83d\udd25 : Adds item to smelting list.",Hi:"\ud83d\udd28 : Adds item to auction list.",Ej:"Refresh shop automatically with cloth when its full.",
sj:"Page:",zj:"Stop",xj:"Sell This Page",uj:"Pick Selected",tj:"Pick All",Aj:"Auto Package Settings",yj:"Send Resources",vj:"Sell All Selected",ma:"Item Type",oa:"Weapons",S:"Shields",M:"Armour",P:"Helmets",O:"Gloves",N:"Boots",na:"Rings",ka:"Amulets",Ia:"Usables (Foods)",Na:"Upgrades",rj:"Boosts",Ka:"Recipes",Ja:"Mercenary",Ma:"Forging Tools",La:"Scrolls",od:"Reinforcements",md:"Event Items",nd:"Forging Goods",zl:"Gold",Ha:"All",Al:"Quality",pa:"White",C:"Green",B:"Blue",D:"Purple",H:"Orange",R:"Red",
wj:"Sell All Options",Mj:"Ignore Prefix/Suffix Combination?",aj:"How many food to buy/pick?",Pi:"Normal",Oi:"Middle",Ni:"Hard",Ea:"Standard",Dl:"Repair Stuck Fix",Ik:"Underworld mode will automatically disable Dungeon/Arena/Circus, and enable all of them after underworld. Disable Enter Underworld if you want to disable Dungeon/Circus/Arena. If you entered underworld manually, you need to enable underworld Mode.",ii:"Set how many times you want to train the stats and their priorities. The bot wont train unless you set a priority. If there is no more stat left but priority is set, it will continue with checked stat.",
el:"Quest",Il:"Smelt",Ol:"Smelt Settings",Wj:"Smelted Items",Pl:"Add Prefix or Suffix, once it finds it in the packages it will smelt automatically. If you only want to look for all the items listed without checking their combination, enable Ignore combination option.",Nl:"Smelting Item:",bc:"Click on the item you want to repair and choose the highest quality materials to use. You need to have at least 10,000 gold for the repair to start. Ensure you have a 3x3 space available in your first inventory bag and make sure a food item or any small item is not in the first inventory space otherwise, it might get stuck!. The bot will start the repair once the item has the condition you have chosen. Repair now should be able to continue from where it was left off. Items that have a Hint tooltip might cause a problem.",
Zk:"Apply only to Mercenary",bl:"Auction will only bid when market is close to the end.",al:"Smelting will prioritize starting from the first item to search. You can drag and drop to change priority. Smelt will start when you have over 7k gold. ",dj:"Heal & Buffs",El:"Not enough gold to smelt. Required Gold:",Hl:"Skipping bid: Guild member has already bid for item ",Gl:"Skipping bid: Already bid for item ",advanced:"Advanced",arena:"Arena",ia:"Auto Attack",$b:"Avoid Attack",ga:"Add Player",ha:"Add Player Name (Same Server)",
nl:"Stop Bot if run out of food?",circusTurma:"Circus Turma",Qi:"Difficulty",dungeon:"Dungeon",Ri:"Dungeon Settings",eventExpedition:"Event Expedition",expedition:"Expedition",Vi:"Expedition Settings",Gj:"Select Monster",pl:"Highest",ol:"Put your heal stuff in first page of your inventory",zc:"In",Fh:"Store Gold in Guild Market",Gh:"Store Gold in Auction",lh:"Use Clothes to renew Shop?",Sk:"Select Items to Reset",eh:"Reset Expired Items",Mb:"Note: By enabling this option, the bot will sell upcoming expired items from Packages to Guild Market then cancels to reset expiration time. Guild is required. Make sure you have empty 3x3 space in your bags. It checks last 7 pages per cycle. This might slow down the bot while it is checking for the pages to reset. If it doesnt work, set display expiry date as Date in game settings.",
Kg:"Pause bot randomly to work as [Testing Phase]:",Y:"Hold Gold: Bot will keep this gold in the bag:",jg:"Max Gold: Bot will spend when the gold is greater than",jh:"Bot will bid on random items.",Bd:"Add Random Delay",Cd:"You can add a delay to bot here.",Lb:"Repair",Jl:"Smelt Blue?",Ml:"Smelt Purple?",Ll:"Smelt Orange?",Xj:"Smelt Everything Only From Inventory?",Yj:"`Smelt Tab` works only for `Smelt Everything Only From Inventory` option. Rest of the options will use selected smelt tab. This will ignore color and ignore list items. Tab 1 is reserved for repair.",
Ah:"Smelt",Kd:"Auto Search",zg:"Auto Auction",Ld:"Excess use of Auction might result in ban. If you enabled auction on Crazy-Addon please disable before using this. Note that, if you put only one item to PREFIX section, bot will try to filter by the items name for faster bidding. Although you need to disable bidding food for this.",kh:"Search in Gladiators Auction",mh:"Search in Mercenary Auction",Td:"Bid Food?",kg:"Maximum Bid",Ud:"Bid if the status is less than",Vd:"Bidded Items",wk:"Auction Language",
xk:"Please set the language according to your ingame language, otherwise auction wont work.",Fd:"You can add items to look for items in market and auction. It will also show purple items in the market once you add an item into the list.",uk:"Use auction with caution!",vk:"Auto bid makes too many requests to the server causing white page error and can cause a ban if you use it often!!",ah:"Renew Event Points with Ruby?",pe:"Enable Auto Oil",zk:"Auto Get Holy Oils",Ok:"Quest Check Speed",Sa:"Attack Guild Members?",
Qa:'Auto add people to the "Attack" list when X GOLD is stolen:',Ra:'Automatically add people to the "Avoid Attack" list when you lose to them:',Pb:"Scoreboard Attacks",Xb:"Very Long",zb:"Long",Hb:"Middle",Ub:"Short",Yb:"Very Short",qe:"Enter Underworld if HP >",Wg:"Quest Check Speed",Og:'Default is "3x". If bot causes problems with quests, change quest speed according to your server speed.',Xe:"Heal Pick Bag",re:'If you are renewing points manually, you need to click the button above "Refresh Event Expedition if stuck!',
Dk:"You must enable at least one of the following: expedition, dungeon, arena, or circus to start the Event Expedition.",Yg:"Refresh Event Expedition if stuck!",kb:"Dont bid on Allies` Bids?",Vk:"Leave all settings disabled if you wish to smelt using packages that contain the items in the list. However, you still need to choose colors.",Ak:"Character(Off) / Mercenary(On)",Rk:"Repair Both?",Wk:"Timers",Timers:"Enter the number of minutes for each timer below or leave it default. Be aware! If you enter very low numbers, bot might get stuck in loop!",
Tg:"Quest Filter Ignore",Sg:"Enter keywords to filter out quests you do not want to take",V:"Enter Keyword",I:"Add",$g:"Remove",ae:"Clear",Qg:"Quest Filter Accept",Rg:"Enter keywords to choose which quests to take. You can also use this to accept quests by their reward using keyword. Using this will ignore Quest Types",Ca:"Skip Time Quests?",Pk:"Quests",Nd:"Auto Costume",xi:"Use Costume?",Sd:"Basic Battle",je:"Dungeon Battle & Event",$d:"Choose underworld costume",Di:"Wear Underworld costume when available?",
Od:'To ensure the bot doesnt override your Underworld costume, make sure to select "Wear Underworld costume when available?" and "Choose Underworld costume." The bot will only switch to Dis Pater Normal and Medium costumes if your expedition or dungeon points are at 0.',Ze:"Underworld Heal Settings",Ed:"Attack Boss When Available?",qb:"League attack will disable itself after 5 unsuccessful attack.",bf:"Holy Oils",ug:"Item Name",Z:"Min. Item Level",Aa:"Min. Item Quality",Dd:"Apply/Reset Timer",ef:"Ignore Prefix/Suffix Combination",
Ei:"Yes",Bg:"No",Oa:"Add Prefix",Pa:"Add Suffix",Xa:"Clear History",Bh:"Ignore List",Ib:"Prefix",Vb:"Suffix",gh:"Reset Expiring Items",Ch:"Smelt randomly if no conditions met?",Dh:"Smelt Tab",ob:"Extras",Id:"Auction",cg:"Market",Wb:"Timers",bi:"Smelting",ai:"Smelting if not enough gold",Yh:"Smelt if no item",Da:"Repair",Qh:"Guild Market Hold Gold",Mh:"Auction Hold Gold",ei:"Training",Th:"Reset Expired",ci:"Store Forge",Kh:"Auction Check",Vh:"Search",v:"Enable",wg:"Minimum Gold",Qb:"Select Hour",lb:"Donate Gold to Guild",
ee:"Donates every 5 minutes. You can change the interval from timers tab",cf:"How much to donate?",fe:"Donate when you have more than >",qf:"Less than <",dh:"Reset Expired and Other settings",fh:"Reset in:",Jk:"Hold Ctrl (Cmd on Mac) to select multiple items",ff:"Import/Export Settings",Oe:"Export Settings",gf:"Import Settings",ng:"Message All Players",og:"[Requires Ultra Premium Key, message on Discord to get the key.]",pg:"Enter message to send",ce:"For custom scripts contact us on Discord",rg:"Send",
sg:"Show Players",qg:"SelectAll",tg:"UnselectAll",pf:"Make sure your inventory has enough space. Cooldown is 2 minutes.",nb:"Enable Scoreboard Attack:",Nb:"Select Range to Attack",Ob:"Bot will randomly attack from the scoreboard list.",pb:"League Attack",mb:"Enable League Attack:",Jb:"Randomly Attack",Kb:"Attack lowest to highest",tk:"Bot will avoid attacking guild members by default.",Me:"Expedition Location:",Md:"Auto Collect Bonuses:",zh:"Skip Boss",ke:"Dungeon Location:",hh:"Reset if lose?",$e:"Underworld Settings",
af:"Underworld: Runs from start to finish! Set your heal % in the Heal tab (activate it first). Underworld Mode uses Underworld Heal %, so expect more food consumption. Enable Auto-login in Extras if logout occurs.",Ye:"Underworld Difficulty:",Pd:"Auto Enter Underworld / Underworld Mode:",yi:"Use Mobilization if points = 0",Ci:"Use rubies?",Ai:"Use Sacrifice to heal?",mk:"Use Cloth to enter underworld?",se:"Exit underworld if no points?",ki:"The bot will try to use Villa Medici first and disable itself if there is no available Villa Medici; if thats the case, it will use a healing potion. Dont forget to enable Heal toggle.",
ti:"Auto enter Underworld will disable dungeon/arena/circus upon entering underworld.",Xk:"Underworld Heal Settings",Bi:"Use Villa Medici?",zi:"Use Healing Potion?",Yf:"INFO: The bot will search for market items every selected minutes, which may pause attacking during the search.",oe:"Enable Market Search:",Zf:"Market Search Interval in Minutes:",$f:"Suggested 10 minutes.",kf:"Item Settings:",hf:"Item Name Includes",G:"Max Price",lf:"Item Type",jf:"Item Rarity",Yd:"Buy Soulbound?",nf:"Items to Buy",
mf:"Buy packs if any of them match the maximum price entered?",Wd:"Bought Items:",bj:"Heal Percentage",pk:"Buy Food from Shop?",qk:"Use Heal from Package?",lk:"Use Cervisia? (packages included)",nk:"Use Eggs? (packages included)",tl:"Last Used",location:"Location",Strength:"Strength",Dexterity:"Dexterity",Agility:"Agility",Constitution:"Constitution",Charisma:"Charisma",Intelligence:"Intelligence",gi:"Train Settings",hi:"Select the attributes you want to train. It will train once you have enough gold.",
$c:"Next action",oj:"No",pj:"Normal",xl:"Opponent",yl:"Opponent Level",Dj:"Quests",random:"Random",Fl:"Settings",Ql:"Soon...",type:"Click on icons to activate quest types. Select first 3 if you want to focus on Circus & Arena",Xl:"Yes",A:"Search",yd:"Add item",ik:"Store Forge Resources automatically",Sl:"Submit",rl:"Interval : ",gl:"Enable Auto Bid",hl:"Cover Allies` Bids",Ul:"Tutorial",ac:"More users will slow down the bot.",$k:"Begin by adding an items full name to the list. Once added, the tool will display search results on the left. This also aids in auto-auction searches. With auto-bid enabled, the tool will periodically search based on your set interval. If the item is found and you have sufficient funds, it will bid automatically. Note: To search for unique items in shops, you must add at least one item to the search list..",
jl:"The creature number can be selected from the buttons above. Number 1 represents the leftmost creature. Make sure you select the correct location otherwise bot might pause.",Si:"Choose the difficulty of the dungeon from the options above. Ensure you select the correct location, as otherwise, the bot might pause.",cj:"Heal Settings",Ti:"Store excess gold in Guild by buying guild market items. -> Min. Gold. Leave some empty space in first inventory.",ul:"Move All",vl:"Move Selected",cl:"Auto Heal",
dl:"Auto Heal Percentage",Wl:"Ruby",Fg:"General Settings",Hj:"Sell All",Ij:"Sell Selected",fa:"Weapons",ca:"Shields",U:"Chest Armour",X:"Helmets",W:"Gloves",da:"Shoes",aa:"Rings",T:"Amulets",wi:"Usable",vi:"Upgrades",Xg:"Recipes",mg:"Mercenary Scroll",Zg:"Reinforcements",gg:"Sell Food",Db:"Switch to Food"},Lh={Fk:"Sefer ayarlar\u0131n\u0131z yanl\u0131\u015f veya beklenmedik bir sayfa verisi var!",Gk:"Sefer ayar\u0131n\u0131z yanl\u0131\u015f! Devre d\u0131\u015f\u0131 b\u0131rak\u0131lm\u0131\u015f bir canavara ayarlad\u0131n\u0131z, bu yanl\u0131\u015f.",
Tk:"Sadece se\u00e7ilen renge sahip t\u00fcm yeralt\u0131 \u00f6\u011felerini s\u0131f\u0131rla?",Ba:"\u00d6ncelik",Rb:"\u00d6ncelik Ayarla",Lg:"Puanlar",Eh:"Stat Ad\u0131",Mi:"Alt\u0131n Topla",Jj:"Yeralt\u0131 itemleri satilsin mi?",nj:"Bot her eylemde yuva arayacak, sadece ke\u015fiflerde de\u011fil.",lj:"Yuva arama t\u00fcr\u00fc",jj:"Bir Sey Yapma",kj:"Hizli Ara",mj:"Kapsamli Ara",Bj:"Expedition Sonras\u0131 Eylem",sk:"Tamir takilirsa TIKLA",Hk:"Kaca dustugunde iyilestirsin?",Hg:"K\u0131smi Onar\u0131m",
Ve:"Tam Onar\u0131m",Gg:"K\u0131smi veya Tam Onar\u0131m",me:"Limiti Etkinle\u015ftir",ej:"Limit",fj:"D\u00fc\u015fmana sald\u0131rmak istedi\u011finiz kez say\u0131s\u0131n\u0131 s\u0131n\u0131rlamak istiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin ve limiti ayarlay\u0131n. Bot, se\u00e7ilen canavara sald\u0131rmay\u0131 bitirdikten sonra di\u011fer d\u00fc\u015fmanlara sald\u0131rmaya devam edecek.",he:"Yeralt\u0131 kost\u00fcm\u00fc ile yeralt\u0131na girmeyin",ge:"Yeralt\u0131 kost\u00fcm\u00fc varken yeralt\u0131na girmek istemiyorsan\u0131z, bu se\u00e7ene\u011fi etkinle\u015ftirin",
si:"Yeralt\u0131 D\u00fcnyas\u0131",ji:"Yeralt\u0131 D\u00fcnyas\u0131 G\u00fc\u00e7lendirmeleri",li:"Yeralt\u0131 d\u00fcnyas\u0131na girdikten sonra tanr\u0131 g\u00fc\u00e7lerini kullan?",mi:"G\u00fc\u00e7lerini kullanmak istedi\u011fin tanr\u0131lar\u0131 se\u00e7:",ni:"Silaha Silah G\u00fc\u00e7lendirmesi kullan?",oi:"A\u015fa\u011f\u0131daki ekipmana Z\u0131rh G\u00fc\u00e7lendirmesi kullan:",Ck:"Bekleme s\u00fcresi 30 dakikad\u0131r. \u00dczerinde kost\u00fcm yoksa, bot bekleme s\u00fcresini s\u0131f\u0131rlar.",
Uk:"Renkleri Se\u00e7",Ya:"Vulcano`nun Demirci Atesi",bb:"Feronia`nin Toprak Kalkani",cb:"Neptune`un sivi gucu",eb:"Aelous`un havali ozgurlugu",fb:"Pluto`nun olumcul nefesi",gb:"Juno`nun Hayat Solugu",hb:"Ofkeli Dag Ejderhasi Pul Zirhi",ib:"Kartal Bakisi",jb:"Saturn`un kisi giysisi",Za:"Bubona`nin okuz zirhi",$a:"Mercerius`un Hirsiz Kaftani",ab:"Ra`nin isikli esvabi",fg:"Paketler",ag:"Envanter",K:"Min. Fiyat",J:"Ka\u00e7 Tane",Cb:"E\u015fya Sat",Bb:"\u015eurada Ara",bg:"Malzeme Rengi",Ab:"E\u015fya Rengi",
ig:"Depo",za:"Malzemelere Ge\u00e7",Eb:"E\u015fyalara Ge\u00e7",hg:"Malzeme Sat",wa:"L\u00fctfen ge\u00e7erli bir e\u015fya ad\u0131, fiyat aral\u0131\u011f\u0131 ve miktar girin.",xa:"Se\u00e7ilen arama konumlar\u0131nda uygun e\u015fya bulunamad\u0131.",ya:"T\u00fcm e\u015fyalar ba\u015far\u0131yla listelendi!",Nk:"T\u00fcm malzemeler ba\u015far\u0131yla listelendi!",dg:"Sabit fiyata e\u015fya satmak istiyorsan\u0131z, min ve maks fiyat i\u00e7in ayn\u0131 de\u011feri girebilirsiniz.",eg:"Bu \u00f6zellik hala deneyseldir, dikkatli kullan\u0131n. Sabit fiyat koymazsan\u0131z, girdi\u011finiz minimum ve maksimum fiyat aras\u0131nda rastgele \u00f6\u011feler listeleyecektir.",
Qj:"Eritmek istedi\u011finiz e\u015fya t\u00fcrlerini se\u00e7in.",Rj:"Eritmek istedi\u011finiz renkleri se\u00e7in.",Sj:"Eritmek istedi\u011finiz e\u015fyalar\u0131n seviyesini se\u00e7in.",Tj:"Kullanmak istedi\u011finiz \u00e7ekici se\u00e7in.",Uj:"\u0130lk kutunun yan\u0131ndaki Ye\u015fil ve K\u0131rm\u0131z\u0131 \u00e7emberin kural\u0131 etkinle\u015ftirme/devre d\u0131\u015f\u0131 b\u0131rakma i\u00e7in oldu\u011funa dikkat edin.",Vj:"E\u011fer rastgele herhangi bir renk veya t\u00fcr\u00fc ergitmek istiyorsan\u0131z, Ko\u015fullar sa\u011flanmazsa rastgele eritilsin mi? (E\u011fitim videosundaki son etkinle\u015ftirilen se\u00e7enek) se\u00e7ene\u011fini etkinle\u015ftirebilirsiniz.",
yk:"Bot`un her d\u00f6ng\u00fcde harcayaca\u011f\u0131 maksimum alt\u0131n\u0131 belirler.",Ta:"Etkinle\u015ftirilirse, bot herhangi bir yiyecek \u00f6\u011fesi i\u00e7in teklif vermeye ba\u015flar. Gladyat\u00f6r/asker ayar\u0131n\u0131 etkinle\u015ftirmeniz gerekmez.",Gd:"Bot, m\u00fcttefiklerin tekliflerine teklif vermez.",Hd:"A\u00e7\u0131k art\u0131rmada bir \u00f6\u011fe ararken \u00d6nek/Son ek kombinasyonunu g\u00f6rmezden gelir.",Fj:"Eritmeden \u00f6nce tamir et?",Ie:"Canavar Se\u00e7",we:"Kum Saati/Rub kullan?",
Ek:"Rub kullan?",ze:"Mobilizasyon Kullan?",ye:"Ya\u015fam \u0130ksiri Kullan?",ve:"\u0130yile\u015ftirme Y\u00fczdesi (%)",Ge:"Sald\u0131r\u0131 Say\u0131s\u0131",xe:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131 (saniye cinsinden)",te:"Yap\u0131lan Sald\u0131r\u0131lar",ue:"Kalan Kum Saati",Ee:"Not: \u0130yile\u015ftirmek i\u00e7in yiyecek de\u011fil, ya\u015fam iksiri kullan\u0131r.",Fe:"Not: Sald\u0131r\u0131lar erken durursa, 'Sald\u0131r\u0131lar\u0131 S\u0131f\u0131rla' deneyin.",Je:"Ba\u015flat",
He:"S\u0131f\u0131rla",Ke:"Durdur",Le:"Ke\u015fif Ayarlar\u0131 (K\u00fc\u00e7\u00fcltmek i\u00e7in t\u0131klay\u0131n)",Ae:"Canavar 1",Be:"Canavar 2",Ce:"Canavar 3",De:"Canavar 4",Qk:"Eritmeden \u00f6nce tamir et?",Ki:"Bu se\u00e7enek, premium \u00fcyeli\u011finiz sona erdi\u011finde cervisia kullanacak.",qj:"Bu se\u00e7enek, tanr\u0131 \u00f6d\u00fcllerinden ya\u011flar\u0131 etkinle\u015ftirir ve se\u00e7er. Karakter \u00fczerinde 1 numara ve 3 numara ya\u011flar\u0131 kullanabilir ancak 2 numara sadece paketlere al\u0131n\u0131r.",
Ii:"Bu se\u00e7enek, belirledi\u011finiz zamanda buff kullan\u0131r. Paketlerdeki bufflar\u0131 bulur ve karaktere uygular.",gj:"Bu se\u00e7enek sizi kesif seferleriniz 2 ve altina geldiginde yeralt\u0131 d\u00fcnyas\u0131na sokar. Ekstralar sekmesinden Otomatik Giri\u015fi etkinle\u015ftirmeyi unutmay\u0131n, yoksa yeralt\u0131na girerken \u00e7\u0131k\u0131\u015f yapabilirsiniz [Oyun Hatas\u0131]",Zb:"Bot normalde rastgele 3 ila 6 deneme ile arena listesine sald\u0131r\u0131r. Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, sald\u0131rabilece\u011fi birini bulana kadar listenizde ilerler. Bu biraz zaman alabilir.",
Cj:"Bu se\u00e7enek sadece premium lisanslar i\u00e7indir. Kullan\u0131c\u0131ya sald\u0131rmadan \u00f6nce %75 kazanma oran\u0131 ile sald\u0131r\u0131y\u0131 sim\u00fcle eder.",Jd:"Bu se\u00e7ene\u011fi etkinle\u015ftirmek i\u00e7in ana m\u00fczayede ge\u00e7i\u015fini etkinle\u015ftirmenize gerek yoktur.",kk:"Bu se\u00e7enek, m\u00fczayede -\u00c7ok K\u0131sa- durumundayken sayfay\u0131 her saniye yeniler ve s\u00fcrekli teklif vererek m\u00fczayede kazanmay\u0131 ama\u00e7lar.",Oj:"E\u011fer eritme ko\u015fullar\u0131ndan hi\u00e7biri kar\u015f\u0131lanmazsa rastgele eritir. L\u00fctfen e\u015fya tipini ve rengini se\u00e7in.",
Pj:"Bu se\u00e7enek sadece envanterdeki e\u015fyalar\u0131 eritir. Paketlerdeki e\u015fyalar\u0131 g\u00f6rmezden gelecektir.",Kj:"Arkaplan\u0131 Siyah yap",Lj:"Bot butonlarini sol alta koy?",Li:"Iyilestirme olmadan Sirke Sald\u0131r?",jk:"Gerekirse paketlerden alt\u0131n al\u0131ns\u0131n?",Tl:"E\u011fitim i\u00e7in paketlerden alt\u0131n al\u0131nd\u0131",Ad:"E\u011fitim i\u00e7in paketlerde alt\u0131n bulunamad\u0131",wl:'GLDbot: Gizem kutusunu yenilemek ve de\u011ferli e\u015fyalar\u0131 (Vb. Kost\u00fcmler) a\u00e7madan \u00f6nce bulmak i\u00e7in zarlar\u0131 kullan. Sand\u0131klar\u0131 a\u00e7mak i\u00e7in "Ba\u015flat"a t\u0131kla.',
Ua:"Muzayede Esyalari",lg:"Mersaneri Esyalari",Tb:"Dukkan Esyalari",ui:"Degerli Dukkan Esyalari",gk:"E\u015fyalar Tamir Edildi",$j:"Arena Sald\u0131r\u0131lar\u0131",bk:"Sirk Sald\u0131r\u0131lar\u0131",zd:"E\u015fyalar S\u0131f\u0131rland\u0131",ek:"Sefer Sald\u0131r\u0131lar\u0131",dk:"Zindan Sald\u0131r\u0131lar\u0131",hk:"Yeralt\u0131 Sald\u0131r\u0131lar\u0131",ak:"Arenadan Kazan\u0131lan Para",ck:"Sirkten Kazan\u0131lan Para",Rl:"E\u015fyalar Eritildi",fk:"D\u00f6n\u00fc\u015ft\u00fcr\u00fclen Alt\u0131n",
Yi:"Lonca Sava\u015f\u0131",$i:"Lonca Ayarlar\u0131",ll:"Loncalara rastgele sald\u0131racak.",Zi:"Lonca Ismi",Xi:"Rastgele Sald\u0131r",Ji:"\u0130statistikleri S\u0131f\u0131rla",Kc:"Ah\u015fap",Ac:"Bak\u0131r",Ec:"Demir",Gc:"Deri",Lc:"Y\u00fcn \u0130plik",Bc:"Y\u00fcn Yuma\u011f\u0131",Dc:"Kenevir",Cc:"Gaze \u015eeridi",Hc:"Keten Par\u00e7as\u0131",Fc:"J\u00fct Dikimi",Jc:"Kadife \u015eerit",Ic:"\u0130pek \u0130plik",Tc:"Post Par\u00e7as\u0131",Nc:"Kemik Par\u00e7as\u0131",Wc:"Kepek",Qc:"Pen\u00e7e",
Sc:"K\u00f6pek Di\u015fi",Rc:"Ejderha Kepe\u011fi",Oc:"Bo\u011fa Boynuzu",Vc:"Zehir Bezesi",Pc:"Cerberus`un post par\u00e7as\u0131",Uc:"Hidra pulu",Xc:"Sfenks t\u00fcy\u00fc",Yc:"Tifon derisi",wc:"Lacivert Tasi",qc:"Ametist",pc:"Kehribar",rc:"Akuamarin",xc:"Safir",uc:"Grena Ta\u015f\u0131",tc:"Z\u00fcmr\u00fct",sc:"Elmas",vc:"Jaspis",yc:"Sugilith",kc:"Akrep Zehri",nc:"Dayan\u0131kl\u0131l\u0131k Tent\u00fcr\u00fc",fc:"Antidot",ec:"Adrenalin",mc:"Ayd\u0131nl\u0131k Tent\u00fcr\u00fc",jc:"Alg\u0131 Tent\u00fcr\u00fc",
hc:"Refleks Esans\u0131",ic:"Karizma Flakonu",oc:"Unutman\u0131n Suyu",lc:"Ruh esans\u0131",xd:"Su M\u00fchr\u00fc",rd:"Koruyucu Runik",pd:"D\u00fcnya Grav\u00fcr\u00fc",wd:"\u015eifa Totemi",vd:"G\u00fc\u00e7 T\u0131ls\u0131m\u0131",td:"\u015eans Ta\u015f\u0131",qd:"Ate\u015f Ta\u015f\u0131",ud:"F\u0131rt\u0131na Runi\u011fi",sd:"G\u00f6lge runi\u011fi",cd:"Kristal",bd:"Bronz",gd:"Obsidyen",kd:"G\u00fcm\u00fc\u015f",ld:"K\u00fck\u00fcrt",ed:"Alt\u0131n Madeni",jd:"Kuvars",hd:"Platin",ad:"Almandin",
dd:"Cuprit",fd:"Cehennem ta\u015f\u0131",Fi:"Provinciarum'da Rastgele Sald\u0131r?",Gi:'Crazy-addon\'da "Arena oyuncular\u0131n\u0131 seviyeye g\u00f6re s\u0131rala" se\u00e7ene\u011fini de devre d\u0131\u015f\u0131 b\u0131rak\u0131n.',Ug:"Sadece tanr\u0131 t\u00fcr\u00fcne g\u00f6re g\u00f6rev kabul et.",Va:"Oto Buff",Xd:"Sadece cehennemde kullan?",Ag:"Yeni Kural",yg:"\u0130sim \u0130\u00e7erir",isUnderworldItem:"Yeralt\u0131 item mi?",df:"Malzemeleri Yoksay",rk:"Dua Kullan?",Ai:"\u015eifalanmak i\u00e7in Kurban Kullan?",
mk:"Yeralt\u0131na girmek i\u00e7in kuma\u015f kullan?",ri:"Yeralt\u0131nda sadece yeralt\u0131 ile ilgili g\u00f6revleri kabul et?",pi:"Etkinle\u015ftirilirse, yeralt\u0131 item adlar\u0131n\u0131 girmeniz gerekir. Bot, bu itemlari yeralt\u0131nda bulursa g\u00f6revi kabul eder.",Yk:"Yeralt\u0131 G\u00f6rev Itemi",il:"Malzeme Ad\u0131n\u0131 Girin",Bk:"Bot zarlar\u0131 sever! Zarlar, sand\u0131klarda k\u0131yafet bulmaya yard\u0131mc\u0131 olur. Ancak zar yoksa, bot yine de sand\u0131klar\u0131 a\u00e7ar ve k\u0131yafetler bulmay\u0131 umar (ama bulamayabilir!).",
Nj:"Ertilen malzemeleri pakete g\u00f6nder?",le:"Arena'y\u0131 Etkinle\u015ftir",Mg:"Arena listesini \u00f6nceliklendir?",Ng:"Sirk listesini \u00f6nceliklendir?",de:"Log Men\u00fcs\u00fcn\u00fc Devre D\u0131\u015f\u0131 B\u0131rak",ih:"\u00d6d\u00fcl Min. Alt\u0131n De\u011feri",Vg:"Odaklanm\u0131\u015f G\u00f6rev, etkinle\u015ftirilirse, zindan\u0131 bitirmek i\u00e7in en k\u0131sa yolu izler.",Hh:"Zar\u0131 Otomatik At?",Ih:"Zar\u0131 dikkatli kullan\u0131n, ilk zar\u0131 se\u00e7ene\u011fi devre d\u0131\u015f\u0131 b\u0131rakana kadar kullanmaya devam eder.",
nh:"Arama \u0130lerlemesi",bh:"Onar\u0131m\u0131n varsay\u0131lan bekleme s\u00fcresi 10 dakikad\u0131r.",vg:"Minimum Durum",be:"\u0130\u015f tezgah\u0131ndaki mevcut \u00f6\u011fe [Bot beklenmedik \u015fekilde durursa Temizle]",Af:"D\u00f6k\u00fcm Kaynaklar\u0131 ba\u015far\u0131yla horreuma depoland\u0131.",wf:"Pazar yerindeki \u00f6\u011feleri kontrol ediyor...",yb:"\u00d6\u011fe i\u015f tezgah\u0131na ta\u015f\u0131nd\u0131.",Nf:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131 ve donat\u0131ld\u0131.",
Of:"\u00d6\u011fe ba\u015far\u0131yla onar\u0131ld\u0131.",Lk:"Onar\u0131m ba\u015far\u0131s\u0131z oldu. Sayfa yenilenecek.",Kf:"Malzemeler toplan\u0131yor...",Xf:"Onar\u0131m bekleniyor...",Mf:"Onar\u0131m ba\u015flad\u0131.",va:"Onar\u0131m: \u00d6\u011feyi envanterden \u00e7antaya ta\u015f\u0131ma",Lf:"Onar\u0131m: \u00d6\u011feyi i\u015f tezgah\u0131ndan pakete ta\u015f\u0131ma.",ta:"Yeterli malzeme bulunamad\u0131. Onar\u0131m slotunu 5 dakikaligina devre disi birakiyorum. ",Hf:"Alt\u0131n\u0131 saklamak i\u00e7in a\u00e7\u0131k art\u0131rmadan sat\u0131n al\u0131nacak \u00f6\u011feler aran\u0131yor...",
tf:"Paketlerdeki s\u00fcresi dolmu\u015f \u00f6\u011feler kontrol ediliyor...",uf:"\u00d6\u011fe ba\u015far\u0131yla s\u0131f\u0131rland\u0131.",vf:"Bo\u015f Alan veya S\u0131f\u0131rlanacak Alt\u0131n Yok.",Bf:"Klan pazar\u0131nda sat\u0131\u015f haklar\u0131n\u0131z oldu\u011fundan emin olun!",sb:"Yeterli alt\u0131n ve/veya sat\u0131n al\u0131nacak \u00f6\u011fe yok. Yenilemek i\u00e7in 30sn bekliyor.",ub:"Ma\u011faza yenilendi.",vb:"\u0130yile\u015ftirme s\u0131ras\u0131nda hata.",Ef:"Ruby veya Kuma\u015f yok, se\u00e7enekleri devre d\u0131\u015f\u0131 b\u0131rak.",
Kk:"Paketlerde yiyecek bulunamad\u0131.",wb:"Uygun yiyecek bulunamad\u0131",Ff:"Yiyecekler topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",Gf:"En az bir yiyecek topland\u0131. \u0130\u015flem sonland\u0131r\u0131l\u0131yor.",xb:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",Cf:"Paketlerden yiyecek al\u0131n\u0131yor.",Df:"\u00c7antada yiyecek almak i\u00e7in uygun alan bulunamad\u0131.",tb:"Daha fazla iyile\u015ftirme \u00f6\u011fesi yok. 30 saniye bekliyor.",rb:"HP Kurtar\u0131ld\u0131.",
ua:"Yapacak bir \u015fey yok, bu y\u00fczden dua edece\u011fim!",Tf:"Sa\u011fl\u0131\u011f\u0131m\u0131 ve villa medicimi kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",Uf:"Villa Medici bekleniyor, 60 saniye i\u00e7inde yenileniyor.",Vf:"Underworld terk edildi.",Wf:"Sa\u011fl\u0131\u011f\u0131m\u0131 kontrol etmek i\u00e7in 60 saniye i\u00e7inde yenileyece\u011fim.",If:"Tanr\u0131 ya\u011flar\u0131 kontrol ediliyor...",Jf:"Tanr\u0131 ya\u011flar\u0131 topland\u0131.",ra:"ARENADA ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",
sa:"CIRCUS'ta ba\u015far\u0131yla oyuncuya sald\u0131r\u0131ld\u0131: ",rf:"A\u00e7\u0131k art\u0131rma kontrol ediliyor! L\u00fctfen bekleyin...",sf:"\u00d6\u011felere teklif veriliyor. L\u00fctfen bekleyin...",Pf:"Otomatik Eritilen Item: ",Qf:"Eritme \u00d6\u011fesi: ",Rf:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n: ",Sf:"ER\u0130T: Eritilecek \u00f6\u011feler aran\u0131yor...",Mk:"Eritilecek \u00f6\u011feler aran\u0131yor...",xf:"Kost\u00fcm mevcudiyeti kontrol ediliyor...",zf:"Ba\u011f\u0131\u015fland\u0131 : ",
yf:"Zar at\u0131l\u0131yor...",Re:"Yeralti Farmla [Manuel, BETA]",Se:"Bu ozelligi saldirmak istediginiz yaratigi actiktan sonra acin, otomatik olarak yaratigi acana kadar saldirmayacaktir. Dikkat edin.",Qe:"Farm Lokasyonu",Pe:"Farm Dusmani",Qd:"Otomatik Giri\u015f",Rd:"GameForge lobisinden a\u00e7\u0131l\u0131r pencere izinlerini vermeniz gerekmektedir. Nas\u0131l yap\u0131laca\u011f\u0131na dair dok\u00fcmantasyona bak\u0131n.",Ig:"Bot'u Durdur",Jg:"Bot'u ka\u00e7 dakika bitince durdurmak istersiniz? (Dakika)",
Ne:"Son Kullanma Tarihi",Dg:"Sadece yemek sat\u0131n al?",Eg:"Bunu etkinle\u015ftirirseniz, se\u00e7imlerinizi g\u00f6rmezden gelir ve herhangi bir \u015fey girmeden otomatik olarak yemek sat\u0131n al\u0131r.",Gb:"Harcamak i\u00e7in maksimum toplam alt\u0131n",Fb:"Harcamak i\u00e7in maksimum alt\u0131n miktar\u0131",Cg:"Bot, ya\u011flar\u0131 her 60 dakikada bir kontrol edecek",$h:"Eritme s\u00fcrelerini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Xh:"Alt\u0131n\u0131n\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Zh:"Kullan\u0131labilir e\u015fyan\u0131z olmad\u0131\u011f\u0131nda erimeyi kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Sh:"E\u015fyalar\u0131n\u0131z\u0131 kontrol etmek i\u00e7in bir tamir zamanlay\u0131c\u0131 ayarlar.",Rh:"Ittifak pazar\u0131ndaki alt\u0131n\u0131 kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Nh:"M\u00fczayede tutma alt\u0131n\u0131 se\u00e7ene\u011fi i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Jh:"Arenadaki PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Oh:"Sirk PvP listesini kontrol etmek i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",fi:"\u0130statistiklerinizi e\u011fitmek i\u00e7in bir e\u011fitim zamanlay\u0131c\u0131 ayarlar.",Uh:"S\u00fcresi dolmu\u015f e\u015fyalar\u0131 s\u0131f\u0131rlamak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",di:"D\u00f6vme malzemelerini horreum'a koymak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Lh:"Gladyat\u00f6rler ve paral\u0131 askerler m\u00fczayede kontrol\u00fc i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",
Wh:"M\u00fczayede ve market i\u00e7in e\u015fya aramak i\u00e7in bir zamanlay\u0131c\u0131 ayarlar.",Ph:"Ittifaga ba\u011f\u0131\u015f g\u00f6nderme zamanlay\u0131c\u0131s\u0131n\u0131 ayarlar.",We:"Alt\u0131n Ta\u015f\u0131nd\u0131",ie:"Eritme ve Muzayede listesi e\u015fyalar\u0131n\u0131 satma",oh:"Market Otomasyonu",qh:"E\u015fya Arama Ayarlar\u0131",ph:"Bu ozellik, dukkanlarda e\u015fya aramak i\u00e7in kullanilir. Sadece e\u015fyalar\u0131 listeye ekleyin, kuma\u015f miktar\u0131n\u0131 belirtin ve aramay\u0131 ba\u015flat\u0131n. Ornegin mor samnit, mor samnit i bulana kadar arar.",
rh:"Kullan\u0131lacak Kuma\u015flar:",th:"Ka\u00e7 kuma\u015f kullan\u0131lacak?",ea:"Full E\u015fya Ad\u0131n\u0131 Girin",Sb:"E\u015fya Seviyesini Girin",vh:"E\u015fya Kalitesi",uh:"E\u015fya Ad\u0131 Buraya",wh:"Aramaya Ba\u015fla",xh:"Atla ve Devam Et",yh:"Aramay\u0131 Durdur",Te:"En ucuz mu, en pahal\u0131 m\u0131 alay\u0131m?",xg:"En Pahal\u0131",Zd:"En Ucuz",ba:"Bir se\u00e7enek se\u00e7in",ne:"Yeralt\u0131 D\u00fcnyas\u0131 Itemlarini Goster",Ue:"G\u00f6reve odaklan\u0131ls\u0131n m\u0131?",
Vl:"Elbise yoksa yakut kullan?",Wa:"Diger serverlarda sald\u0131rmak icin, oyuncunun sayfasini acin ve A & C butonlariyla ekleyin. Not: Rapor edilmemek i\u00e7in ayn\u0131 ki\u015filere sald\u0131rmaktan ka\u00e7\u0131n\u0131n. Rapor edilmek, banlanma \u015fans\u0131n\u0131z\u0131 art\u0131r\u0131r.",Kl:"Yesil Eritilsin mi?",Pg:"Herhangi bir filtre girildiyse rastgele g\u00f6revleri kabul etme?",Mc:"Maksimum materyal kalitesi?",Ui:"Mersaneri Ara?",sl:"T\u00fcm Se\u00e7ilenleri Sat\u2019\u0131 t\u0131klay\u0131n ve t\u00fcm e\u015fyalar\u0131 sat\u0131n. \u0130lk (1) \u00e7antan\u0131zda 2x3 bo\u015f alan oldu\u011fundan emin olun ve kalite secmeyi unutmayin. Alt\u0131n toplamak i\u00e7in, alt\u0131n\u0131 filtreleyin ve `Se\u00e7ilenleri Al veya T\u00fcm\u00fcn\u00fc Al`\u0131 kullan\u0131n",
Zj:"\ud83d\udd25 : E\u015fyay\u0131 eritme listesine ekler.",Hi:"\ud83d\udd28 : E\u015fyay\u0131 a\u00e7\u0131k art\u0131rma listesine ekler.",Ej:"D\u00fckkan dolu oldu\u011funda d\u00fckkan\u0131 kuma\u015fla yenileyin",sj:"Sayfa:",zj:"Durdur",xj:"Bu Sayfay\u0131 Sat",uj:"Se\u00e7ilenleri Al",tj:"T\u00fcm\u00fcn\u00fc Al",Aj:"Paket Ayarlar\u0131",yj:"Kaynaklar\u0131 G\u00f6nder",vj:"T\u00fcm Se\u00e7ilenleri Sat",ma:"E\u015fya T\u00fcr\u00fc",oa:"Silahlar",S:"Kalkanlar",M:"Z\u0131rhlar",P:"Kasklar",
O:"Eldivenler",N:"Ayakkabilar",na:"Y\u00fcz\u00fckler",ka:"Nazarliklar",Ia:"Malzemeler (Yiyecekler)",Na:"G\u00fc\u00e7lendirmeler",rj:"Yukseltmeler",Ka:"Receteler",Ja:"Mersaneri Askerler",Ma:"Demirhane Mallari",La:"Persomenler",od:"Takviyeler",md:"Etkinlik E\u015fyalar\u0131",nd:"D\u00f6vme Malzemeleri",zl:"Alt\u0131n",Ha:"Hepsi",Al:"Kalite",pa:"Beyaz",C:"Ye\u015fil",B:"Mavi",D:"Mor",H:"Turuncu",R:"K\u0131rm\u0131z\u0131",wj:"T\u00fcm Sat\u0131\u015f Se\u00e7enekleri",Mj:"\u00d6nek/Sonek Kombinasyonunu Yoksay?",
aj:"Ka\u00e7 yiyecek sat\u0131n almak/al\u0131nmal\u0131?",Pi:"Normal",Oi:"Orta",Ni:"Zor",Ea:"Standart",Dl:"S\u0131k\u0131\u015fma Onar\u0131m\u0131",Ik:"Dungeon/Circus/Arena\u2019y\u0131 devre d\u0131\u015f\u0131 b\u0131rakmak istiyorsan\u0131z Cehenneme Giri\u015fi Devre D\u0131\u015f\u0131 B\u0131rakin. Cehenneme manuel olarak girdiyseniz, Cehennem Modu\u2019nu etkinle\u015ftirmeniz gerekecektir.",ii:"Egitimleri ka\u00e7 kez e\u011fitmek istedi\u011finizi ve onlar\u0131n \u00f6nceliklerini belirleyin. Bot, bir \u00f6ncelik belirlemedik\u00e7e e\u011fitim yapmayacakt\u0131r. E\u011fer \u00f6ncelik belirlenmi\u015fse ancak ba\u015fka bir egitim kalmam\u0131\u015fsa, secilen egitim devam edecektir.",
el:"Gorev",Il:"Erit",Ol:"Eritme Ayarlar\u0131",Wj:"Eritilen Nesneler",Pl:"\u00d6nek veya Sonek Ekle, paketlerde bulunursa otomatik olarak eritilecektir.:",Nl:"Eritilen Nesne:",bc:"Onarmak istedi\u011finiz nesneyi t\u0131klay\u0131n. Onar\u0131ma ba\u015flamak i\u00e7in en az 10,000 alt\u0131n\u0131z\u0131n olmas\u0131 gerekmektedir. Yeni repair sistemi refresh atilsa bile kaldigi yerden devam edecektir. Sorun cikarsa clear a basip workbench itemini temizleyebilirsiniz. Ayr\u0131ca envanterinizde yer a\u00e7mayi unutmayin. Bot, kondisyon seciminize gore aktif olacaktir.",
Zk:"Sadece S\u00f6zle\u015fmeliye Uygula",bl:"M\u00fczayede yaln\u0131zca piyasa sona yakla\u015ft\u0131\u011f\u0131nda teklif verecektir.",al:"Envanterde bos yer acmayi ve en az 7K alt\u0131n\u0131n\u0131z\u0131n oldu\u011fundan emin olun. Bot 1. koydugunuz prefixden baslayip sona dogru bakacaktir, bu siralamayi uzerine gelip tasiyarak degistirebilirsiniz. Bot, sectiginiz sekmeye gore itemlari tasiyacak ve eritecektir. Eritme i\u015flemi her ayarlanan zamana gore kontrol edilir. Bu ayari Zamanlayici sekmesinden degistirebilirsiniz. Eger kombinasyon olarak bakmak istemiyorsaniz, onek sonek kombinasyonunu yoksay`i aktiflestirin.",
dj:"\u0130yile\u015ftirme/Buff",El:"Eritmek i\u00e7in yeterli alt\u0131n yok. Gerekli Alt\u0131n:",Hl:"Teklifi Atla: ittifak \u00fcyesi zaten nesne i\u00e7in teklif verdi ",Gl:"Teklifi Atla: Zaten nesne i\u00e7in teklif verildi ",advanced:"Geli\u015fmi\u015f",arena:"Arena",ia:"Otomatik sald\u0131r\u0131 listesi",$b:"Bu listedekilere sald\u0131rma",ga:"Oyuncu Ekle",ha:"Oyuncu Ad\u0131 Gir (Ayni Server)",nl:"Yiyecek t\u00fckenirse Botu Durdur?",circusTurma:"Sirkin Turma",Qi:"Zorluk",dungeon:"Zindan",
Ri:"Zindan Ayarlar\u0131",eventExpedition:"Etkinlik Seferi",expedition:"Sefer",Vi:"Sefer Ayarlar\u0131",Gj:"Yarat\u0131k Se\u00e7",pl:"En Y\u00fcksek",ol:"\u0130yile\u015ftirme e\u015fyalar\u0131n\u0131z\u0131 envanterinizin ilk sayfas\u0131na koyun",zc:"\u0130\u00e7inde",$d:"Yeralti kostumu secin",Di:"Yeralti kostumu hazir oldugunda giy?",Fh:"Alt\u0131n\u0131 Depola",Gh:"Alt\u0131n\u0131 M\u00fczayedede Depola?",lh:"D\u00fckk\u00e2n\u0131 yenilemek i\u00e7in \u0130\u015f K\u0131yafetleri kullan\u0131ls\u0131n m\u0131?",
Sk:"S\u0131f\u0131rlanacak Nesneleri Se\u00e7in",eh:"S\u00fcresi Dolan Nesneleri S\u0131f\u0131rla",Mb:"Not: Bu se\u00e7ene\u011fi etkinle\u015ftirirseniz, bot paketlerden gelecek s\u00fcresi dolan nesneleri ittifak marketine satar ve s\u00fcrelerini s\u0131f\u0131rlar. Ittifak gereklidir. \u00c7antalar\u0131n\u0131zda bo\u015f 3x3 alan\u0131n\u0131z oldu\u011fundan emin olun, ozellikle birinci canta. Her basladiginda son 7 sayfaya bakar. Eger calismazsa oyun ayarlarindan sure bitimini tarih olarak ayarlayin.",
Kg:"Bota Rastgele Ara Vermesini Sa\u011fla [Test A\u015famas\u0131]:",Y:"Alt\u0131n\u0131 Tut: Bot bu alt\u0131n\u0131 \u00e7antada saklayacak:",jg:"Maksimum Alt\u0131n",jh:"Gereksiz itemlar i\u00e7in teklif verilecek",Bd:"Rastgele Gecikme Ekle",Cd:"Bot i\u00e7in rastgele gecikme ekleyebilirsiniz.",Lb:"Onar\u0131m",Jl:"Mavi Eritilsin mi?",Ml:"Mor Eritilsin mi?",Ll:"Turuncu Eritilsin mi?",Xj:"Sadece envantere koyulanlari mi eritsin?",Yj:"Bu renk se\u00e7imlerini yok sayacakt\u0131r",Oa:"\u00d6nek Ekle",
Pa:"Sonek Ekle",Ah:"Erit",Kd:"Otomatik Arama",zg:"Otomatik M\u00fczayede",Ld:"Bu ozelligi fazla kullanmak banlanmaniza sebep olabilir. Eger Crazy Addon`da muzayedeyi zamanlarini gosteren ozelligi aktif ettiyseniz bu ozelligi kullanmadan once onu iptal edin, yoksa yavaslama olacaktir.",kh:"Gladyat\u00f6rler M\u00fczayedesinde Ara",mh:"Mersaneriler M\u00fczayedesinde Ara",Td:"Yiyecek \u0130\u00e7in Teklif Verilsin mi?",kg:"Maksimum Teklif",Ud:"Durum daha azsa teklif ver",Vd:"Teklif Edilen Nesneler",
wk:"M\u00fczayede Dili",xk:"L\u00fctfen dil ayarlarini oyunun diline gore tekrar ayarlay\u0131n.. Hepsi do\u011fru oldu\u011fundan emin olun, aksi takdirde teklif vermeyebilir.",Fd:"Piyasada aranacak nesneleri ekleyebilirsiniz. Bir nesneyi listede ekledi\u011finizde, nesneyi arayacak ve sonu\u00e7lar\u0131 sol tarafta g\u00f6sterecektir. Otomatik m\u00fczayedeyi aramak i\u00e7in de arayacakt\u0131r. Otomatik teklifi etkinle\u015ftirirseniz, belirledi\u011finiz aral\u0131klarla nesneyi arayacak ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: Tekil nesneleri d\u00fckkanlarda aramak i\u00e7in, en az\u0131ndan bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
uk:"M\u00fczayedeyi dikkatli kullan\u0131n!",vk:"Otomatik teklif, sunucuya \u00e7ok fazla istek g\u00f6nderir ve s\u00fcrekli kullan\u0131rsan\u0131z yasa\u011fa neden olabilir!",ah:"Etkinlik Puanlar\u0131n\u0131 Yakut ile Yenile?",pe:"Otomatik Ya\u011f Topla",zk:"Kutsal Ya\u011flar\u0131 Otomatik Al",Ok:"G\u00f6rev Kontrol H\u0131z\u0131",Sa:"Ittifak \u00dcyelerine Sald\u0131r\u0131ls\u0131n m\u0131?",Qa:"Oto Sald\u0131r\u0131 listesine cal\u0131nan Alt\u0131n X ALTINI a\u015ft\u0131\u011f\u0131nda > eklensin mi? ",
Ra:"Yenildi\u011finizde otomatik olarak eklensin mi?:",Pb:"Skor Tablosu Sald\u0131r\u0131lar\u0131",Xb:"\u00c7ok Uzun",zb:"Uzun",Hb:"Orta",Ub:"K\u0131sa",Yb:"\u00c7ok K\u0131sa",qe:"HP > ise Yeralt\u0131 D\u00fcnyas\u0131'na Gir",Wg:"G\u00f6rev Kontrol H\u0131z\u0131",Og:'Varsay\u0131lan olarak "3x" ayarl\u0131d\u0131r. Bot g\u00f6revlerle sorun \u00e7\u0131kar\u0131yorsa, g\u00f6rev h\u0131z\u0131n\u0131 sunucu h\u0131z\u0131n\u0131za g\u00f6re ayarlay\u0131n.',Xe:"\u0130yile\u015ftirme \u00c7anta Se\u00e7imi",
re:'Puanlar\u0131 manuel olarak yeniliyorsan\u0131z, s\u0131k\u0131\u015f\u0131rsa "Yeniden Etkinlik Seferi Yenile" d\u00fc\u011fmesine t\u0131klaman\u0131z gerekmektedir!',Dk:"Etkinlik Seferi'ni ba\u015flatmak i\u00e7in en az birini etkinle\u015ftirmeniz gerekmektedir: sefer, zindan, arena veya sirk.",Yg:"E\u011fer s\u0131k\u0131\u015f\u0131rsa Etkinlik Seferi'ni Yenile!",kb:"\u0130ttifak \u00fcyesi teklif verdiyse atlas\u0131n m\u0131?",Vk:"E\u011fer paketlerde bulunan \u00f6\u011feleri kullanarak eritmek istiyorsan\u0131z, t\u00fcm ayarlar\u0131 devre d\u0131\u015f\u0131 b\u0131rak\u0131n. Ancak hala renkleri se\u00e7ebilirsiniz.",
Ak:"Karakter(Kapal\u0131) / S\u00f6zle\u015fmeli(A\u00e7\u0131k)",Rk:"Ana/Sirk her iki karakteri de tamir etsin mi?",Wk:"Zamanlar",Timers:"Her zamanlay\u0131c\u0131 i\u00e7in a\u015fa\u011f\u0131daki dakika cinsinden say\u0131lar\u0131 girin veya varsay\u0131lan b\u0131rak\u0131n. Dikkat edin! eger cok kisa sureler girerseniz baz\u0131 ozellikler botu donguye sokayabilir.",nb:"Skor Tablosu Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Nb:"Sald\u0131r\u0131 Aral\u0131\u011f\u0131n\u0131 Se\u00e7",
Ob:"Bot, skor tablosu listesinden rastgele sald\u0131r\u0131 yapacakt\u0131r.",pb:"Lig Sald\u0131r\u0131s\u0131",mb:"Lig Sald\u0131r\u0131s\u0131n\u0131 Etkinle\u015ftir:",Jb:"Rastgele Sald\u0131r",Kb:"En d\u00fc\u015f\u00fckten en y\u00fckse\u011fe sald\u0131r",tk:"Bot, varsay\u0131lan olarak ittifak \u00fcyelerine sald\u0131rmaktan ka\u00e7\u0131nacakt\u0131r.",Me:"Sefer Yeri:",Md:"Bonuslar\u0131 Otomatik Al:",zh:"Boss`a sald\u0131rma",ke:"Zindan Yeri:",hh:"Kaybederseniz S\u0131f\u0131rlans\u0131n m\u0131?",
$e:"Cehennem Ayarlar\u0131",af:"Bu mod birden sona kadar saldirarak cehennemi bitirir. \u0130yile\u015ftirme y\u00fczde ayarlar\u0131n\u0131z\u0131 iyile\u015ftirme sekmesinden yap\u0131land\u0131r\u0131n ve iyile\u015ftirme sekmesini etkinle\u015ftirdi\u011finizden emin olun. Cehennem modu aktif oldugunda bot cehennem iyilestirme oranina gore karakterinize yemek yedirecektir. Cehenneme giri\u015f sizi oturumdan \u00e7\u0131kar\u0131yorsa, extralar tabini ziyaret edin ve otomatik giri\u015f kutusunu i\u015faretleyin.",
Ye:"Cehennem Zorlu\u011fu",Pd:"Otomatik Cehennem Giri\u015fi / Cehennem Modu:",yi:"Puan = 0 ise Mobilizasyon Kullan?",Ci:"Yakut Kullan?",se:"Puan Yoksa Cehennemden \u00c7\u0131k\u0131ls\u0131n m\u0131?",ki:"Bot, \u00f6nce villa mediciyi kullanmaya \u00e7al\u0131\u015facakt\u0131r, e\u011fer yoksa iyile\u015ftirme iksiri kullanacakt\u0131r. \u0130yile\u015ftirme anahtar\u0131n\u0131 etkinle\u015ftirdi\u011finizden emin olmay\u0131 unutmay\u0131n.",ti:"Otomatik cehennem giri\u015fi, cehenneme girdi\u011finizde zindan/arena/sirk otomatik olarak devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",
Xk:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",Bi:"Villa Medici Kullan?",zi:"\u0130yile\u015ftirme \u0130ksiri Kullan?",Yf:"Bu ozellik genel marketten esya almaya yarar. Satin alma suresi biraz surebilir.",oe:"Pazar Aramas\u0131n\u0131 Etkinle\u015ftir:",Zf:"Dakika cinsinden Pazar Arama Aral\u0131\u011f\u0131:",$f:"\u00d6nerilen 10 dakika.",kf:"Nesne Ayarlar\u0131:",hf:"Nesne Ad\u0131 \u0130\u00e7erir",G:"Maksimum Fiyat",lf:"Nesne T\u00fcr\u00fc",jf:"Nesne Nadirli\u011fi",Yd:"Ruh Ba\u011fl\u0131 Al\u0131ns\u0131n m\u0131?",
nf:"Al\u0131nacak Nesneler",mf:"Herhangi biri maksimum fiyat\u0131 a\u015f\u0131yorsa \u00f6\u011feleri almay\u0131 deneyin.:",Wd:"Sat\u0131n Al\u0131nan Nesneler:",bj:"\u0130yile\u015ftirme Y\u00fczdesi",pk:"D\u00fckkandan Yiyecek Sat\u0131n Al\u0131ns\u0131n m\u0131?",qk:"Paketten \u0130yile\u015ftirme Kullan\u0131ls\u0131n m\u0131?",lk:"Cervisia Kullan\u0131ls\u0131n m\u0131?",nk:"Yumurta Kullan\u0131ls\u0131n m\u0131?",tl:"Son Kullan\u0131ld\u0131",location:"Konum",Strength:"G\u00fc\u00e7",Dexterity:"Beceri",
Agility:"\u00c7eviklik",Constitution:"Dayaniklilik",Charisma:"Karizma",Intelligence:"Zeka",gi:"E\u011fitim Ayarlar\u0131",hi:"E\u011fitim yapmak istedi\u011finiz nitelikleri se\u00e7in. Yeterli alt\u0131n\u0131z oldu\u011funda e\u011fitim yapacakt\u0131r.",$c:"Sonraki ad\u0131m",oj:"Hay\u0131r",pj:"Normal",xl:"Rakip",yl:"Rakip Seviyesi",Dj:"G\u00f6revler",random:"Rastgele",Fl:"Ayarlar",Ql:"Yak\u0131nda...",type:"G\u00f6rev t\u00fcrlerini etkinle\u015ftirmek i\u00e7in simgeleri t\u0131klay\u0131n.",
Xl:"Evet",A:"Arama",yd:"\u00d6\u011feleri ekle",ik:"Demircilik Kaynaklar\u0131n\u0131 Otomatik Olarak Sakla",Sl:"G\u00f6nder",rl:"Aral\u0131k : ",gl:"Otomatik Teklif Etkinle\u015ftir",hl:"Bir ittifak \u00fcyesi zaten teklif verdiyse teklif vermeyin",Ul:"\u00d6\u011fretici",ac:"Arena'da en d\u00fc\u015f\u00fck veya en y\u00fcksek seviyeli rakiple y\u00fczle\u015fmek isteyip istemedi\u011finizi yukar\u0131daki d\u00fc\u011fmelerden se\u00e7in. Daha fazla kullan\u0131c\u0131, botun h\u0131z\u0131n\u0131 yava\u015flatabilir.",
$k:"Ba\u015flamak i\u00e7in bir \u00f6\u011feyi listeyle ekleyin (\u00f6r. `Lucius`). Ekledikten sonra, arama sonu\u00e7lar\u0131n\u0131 sol tarafta g\u00f6r\u00fcnt\u00fclemek i\u00e7in arama sonu\u00e7lar\u0131n\u0131 g\u00f6sterir. Ayn\u0131 zamanda otomatik m\u00fczayede ama\u00e7lar\u0131 i\u00e7in de arar. Otomatik teklifi etkinle\u015ftirirseniz, belirli aral\u0131klarla \u00f6\u011feyi arar ve yeterli paran\u0131z varsa otomatik olarak teklif verecektir. *Not*: D\u00fckkanlarda benzersiz \u00f6\u011feleri aramak i\u00e7in, en az bir rastgele \u00f6\u011feyi arama listesine eklemeniz gerekmektedir.",
jl:"Yarat\u0131k numaras\u0131n\u0131 yukar\u0131daki d\u00fc\u011fmelerden se\u00e7ebilirsiniz. Numara 1, en soldaki yarat\u0131\u011f\u0131 temsil eder. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",Si:"Zindan\u0131n zorlu\u011funu yukar\u0131dakilerden se\u00e7in. Do\u011fru konumu se\u00e7ti\u011finizden emin olun; aksi takdirde bot durabilir.",cj:"\u0130yile\u015ftirme Ayarlar\u0131",Ti:"Ittifak Piyasas\u0131ndan al\u0131\u015fveri\u015f yaparak fazla alt\u0131n\u0131 depola -> Min. Alt\u0131n. 1. Envanterde bos yer birakmaya calisin.",
ul:"T\u00fcm\u00fcn\u00fc Ta\u015f\u0131",vl:"Se\u00e7ilenleri Ta\u015f\u0131",cl:"Otomatik \u0130yile\u015ftirme",dl:"Otomatik \u0130yile\u015ftirme Y\u00fczdesi",Wl:"Yakut",Fg:"Genel Ayarlar",Hj:"Hepsini Sat",Ij:"Se\u00e7ilenleri Sat",fa:"Silahlar",ca:"Kalkanlar",U:"G\u00f6\u011f\u00fcs Z\u0131rhlar\u0131",X:"Kasklar",W:"Eldivenler",da:"Ayakkab\u0131lar",aa:"Y\u00fcz\u00fckler",T:"Kolyeler",wi:"Kullan\u0131labilir",vi:"G\u00fc\u00e7lendirmeler",Xg:"Re\u00e7eteler",mg:"S\u00f6zle\u015fmeli Scrollar",
Zg:"Takviyeler",Tg:"G\u00f6rev Filtre \u0130gnore",Sg:"Almak istemedi\u011finiz g\u00f6revleri filtrelemek i\u00e7in anahtar kelimeleri girin",V:"Anahtar Kelime Girin",I:"Ekle",$g:"Kald\u0131r",ae:"Temizle",Qg:"G\u00f6rev Filtre Kabul",Rg:"Almak istedi\u011finiz g\u00f6revleri se\u00e7mek i\u00e7in anahtar kelimeleri girin. Odule gore secmek isterseniz odulun icinde gecen bir kelimeyi girin.",Ca:"Zamanl\u0131 G\u00f6revleri Atla?",Pk:"G\u00f6revler",Nd:"Oto Kost\u00fcm",xi:"Kost\u00fcm Kullan?",Sd:"Ana Sava\u015f",
je:"Dungeon Sava\u015f ve Etkinlik",Od:"Bot yaln\u0131zca ke\u015fif/zindan puanlar\u0131n\u0131z 0 ise Dis Pater Normal ve Medium giyecektir.",Ze:"Cehennem \u0130yile\u015ftirme Ayarlar\u0131",Ed:"Boss Mevcut Oldu\u011funda Sald\u0131r?",qb:"5 ba\u015far\u0131s\u0131z sald\u0131r\u0131dan sonra Lig sald\u0131r\u0131s\u0131n\u0131 devre d\u0131\u015f\u0131 b\u0131rakacakt\u0131r.",bf:"Kutsal Ya\u011flar",ug:"\u00dcr\u00fcn Ad\u0131",Z:"Min. Item Seviyesi",Aa:"Min. \u00dcr\u00fcn Kalitesi",Dd:"Zamanlay\u0131c\u0131y\u0131 Uygula/S\u0131f\u0131rla",
ef:"\u00d6nek/Soneki Yok Say",Ei:"Evet",Bg:"Hay\u0131r",Xa:"Ge\u00e7mi\u015fi Temizle",Bh:"Yok Sayma Listesi",Ib:"\u00d6nek",Vb:"Sonek",gh:"S\u00fcresi Dolan \u00dcr\u00fcnleri S\u0131f\u0131rla",Ch:"Kondisyonlar disinda rastgele erit",Dh:"Eritme Sekmesi",ob:"Ekstralar",Id:"M\u00fczayede",cg:"Pazar",Wb:"Zamanlar",bi:"Eritme",ai:"Alt\u0131n Yoksa Eritme",Yh:"\u00dcr\u00fcn Yoksa Eritme",Da:"Tamir",Qh:"Ittifak Pazar\u0131 Alt\u0131n Tutma",Mh:"M\u00fczayede Alt\u0131n Tutma",ei:"E\u011fitim",Th:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla",
ci:"Hammadde Depola",Kh:"M\u00fczayede Kontrol",Vh:"Arama",v:"Etkinle\u015ftir",wg:"Min. Alt\u0131n",Qb:"Saat Se\u00e7in",lb:"Ittifaga Alt\u0131n Ba\u011f\u0131\u015fla",ee:"Her 5 dakikada bir ba\u011f\u0131\u015f yapacakt\u0131r. Zamanlay\u0131c\u0131lar sekmesinden aral\u0131\u011f\u0131 de\u011fi\u015ftirebilirsiniz",cf:"Ne kadar ba\u011f\u0131\u015f yap\u0131lmal\u0131?",fe:"Ne zaman ba\u011f\u0131\u015f yap\u0131lmal\u0131 >",qf:"Daha az <",dh:"S\u00fcresi Dolanlar\u0131 S\u0131f\u0131rla ve Di\u011fer Ayarlar\u0131",
fh:"S\u0131f\u0131rla in:",Jk:"Birden fazla \u00f6\u011feyi se\u00e7mek i\u00e7in Ctrl (Mac'de Cmd) tu\u015funu bas\u0131l\u0131 tutun",ff:"Ayarlar\u0131 Kaydet / Yukle",Oe:"Ayarlar\u0131 Indir",gf:"Ayarlar\u0131 Yukle",ng:"T\u00fcm Oyunculara Mesaj G\u00f6nder",og:"[Ultra Premium Anahtar\u0131 gerektirir, anahtar i\u00e7in Discord \u00fczerinden ileti\u015fime ge\u00e7in.]",pg:"G\u00f6nderilecek mesaj\u0131 girin",ce:"\u00d6zel scriptler i\u00e7in Discord \u00fczerinden bize ula\u015f\u0131n",rg:"G\u00f6nder",
sg:"Oyuncular\u0131 G\u00f6ster",qg:"T\u00fcm\u00fcn\u00fc Se\u00e7",tg:"T\u00fcm Se\u00e7imleri Kald\u0131r",pf:"Envanterinizin yeterli alan\u0131 oldu\u011fundan emin olun. Geri say\u0131m 2 dakikad\u0131r.",gg:"Yiyecek Sat",Db:"Yiyeceklere Ge\u00e7"},Oh={Fk:"Suas configura\u00e7\u00f5es de expedi\u00e7\u00e3o est\u00e3o incorretas ou h\u00e1 dados de p\u00e1gina inesperados!",Gk:"Sua configura\u00e7\u00e3o de expedi\u00e7\u00e3o est\u00e1 incorreta! Voc\u00ea definiu um monstro desabilitado, o que est\u00e1 errado.",
Tk:"Redefinir apenas todos os itens do submundo com a cor selecionada?",Ba:"Prioridade",Rb:"Definir Prioridade",Lg:"Pontos",Eh:"Stat",Mi:"Coletar Ouro",Jj:"Vender itens do Submundo?",nj:"O bot procurar\u00e1 pelo ninho em cada a\u00e7\u00e3o, n\u00e3o apenas em expedi\u00e7\u00f5es.",lj:"Tipo de busca de ninho",jj:"N\u00e3o fazer nada",kj:"Busca r\u00e1pida",mj:"Busca detalhada",Bj:"A\u00e7\u00e3o p\u00f3s expedi\u00e7\u00e3o",sk:"Clique aqui se o reparo ficar travado",Hk:"Quando HP estiver baixo, use cura",
Hg:"Reparo Parcial",Ve:"Reparo Completo",Gg:"Reparo Parcial ou Completo",me:"Habilitar Limite",ej:"Limite",fj:"Se voc\u00ea deseja limitar o n\u00famero de vezes que quer atacar o inimigo, habilite esta op\u00e7\u00e3o e defina o limite. O bot continuar\u00e1 atacando o resto dos inimigos ap\u00f3s terminar de atacar o monstro selecionado.",he:"N\u00e3o entre no submundo com a fantasia do submundo",ge:"Se voc\u00ea n\u00e3o quiser entrar no submundo enquanto estiver usando a fantasia do submundo, ative esta op\u00e7\u00e3o",
si:"Submundo",ji:"Melhorias do Submundo",li:"Usar os poderes dos deuses ap\u00f3s entrar no submundo?",mi:"Selecione os deuses para usar seus poderes:",ni:"Usar Buff de Arma na arma?",oi:"Usar Buff de Armadura no seguinte equipamento:",Ck:"O tempo de espera \u00e9 de 30 minutos. Se voc\u00ea n\u00e3o estiver com um traje, o bot redefinir\u00e1 o tempo de espera para 0.",Uk:"Selecionar Cores",Ya:"Forja de Vulcano",bb:"Escudo Terrestre de Feronia",cb:"Poder Fluido de Netuno",eb:"Liberdade A\u00e9rea de Aelous",
fb:"N\u00e9voa Mortal de Plut\u00e3o",gb:"Sopro de Vida de Juno",hb:"Armadura de Escamas das Montanhas da Ira",ib:"Olhos de \u00c1guia",jb:"Vestimenta de Inverno de Saturno",Za:"Armadura de Touro de Bubona",$a:"Trajes de Ladr\u00e3o de Merc\u00fario",ab:"T\u00fanica de Luz de R\u00e1",fg:"Pacotes",ag:"Invent\u00e1rio",K:"Pre\u00e7o M\u00edn.",J:"Quantos",Cb:"Vender Itens",Bb:"Procurar em",bg:"Cor do Material",Ab:"Cor do Item",ig:"Armaz\u00e9m",za:"Mudar para Materiais",Eb:"Mudar para Itens",hg:"Vender Materiais",
wa:"Por favor, insira um nome de item v\u00e1lido, faixa de pre\u00e7o e quantidade.",xa:"Nenhum item adequado encontrado nos locais de busca selecionados.",ya:"Todos os itens foram listados com sucesso!",Nk:"Todos os materiais foram listados com sucesso!",dg:"Se voc\u00ea quiser vender itens por um pre\u00e7o fixo, voc\u00ea pode inserir o mesmo valor para o pre\u00e7o m\u00ednimo e m\u00e1ximo.",eg:"Este recurso ainda \u00e9 experimental, use com cautela. Se voc\u00ea n\u00e3o colocar um pre\u00e7o fixo, os itens ser\u00e3o listados aleatoriamente entre o pre\u00e7o m\u00ednimo e m\u00e1ximo que voc\u00ea inserir.",
yk:"Define o m\u00e1ximo de ouro que o bot gastar\u00e1 por ciclo.",Ta:"O bot come\u00e7ar\u00e1 a fazer lances em itens de comida, se habilitado. Voc\u00ea n\u00e3o precisa habilitar os interruptores de gladiador/mercen\u00e1rio.",Gd:"O bot n\u00e3o far\u00e1 lances sobre os lances dos aliados.",Hd:"Ignorar combina\u00e7\u00e3o de Prefixo/Sufixo ao procurar por um item no leil\u00e3o.",Qj:"Selecione os tipos de item que voc\u00ea deseja fundir.",Rj:"Selecione as cores que voc\u00ea deseja fundir.",
Sj:"Selecione o n\u00edvel dos itens que voc\u00ea deseja fundir.",Tj:"Selecione o martelo que voc\u00ea deseja usar.",Uj:"Note que o c\u00edrculo Verde e Vermelho ao lado da primeira caixa s\u00e3o para ativar/desativar a regra.",Vj:"Se voc\u00ea quiser fundir aleatoriamente quaisquer cores ou tipos, voc\u00ea pode ativar `Fundir aleatoriamente se nenhuma condi\u00e7\u00e3o for atendida? (\u00daltima op\u00e7\u00e3o habilitada no v\u00eddeo tutorial)",Fj:"Reparar antes de fundir?",Ie:"Selecionar Monstro",
we:"Usar Ampulheta/Rubi?",Ek:"Usar Rubi?",ze:"Usar Mobiliza\u00e7\u00e3o?",ye:"Usar Po\u00e7\u00e3o de Vida?",ve:"Percentual de Cura (%)",Ge:"N\u00famero de Ataques",xe:"Intervalo de Ataque (em segundos)",te:"Ataques Realizados",ue:"Ampulhetas Restantes",Ee:"Nota: Usa po\u00e7\u00f5es de vida para curar, n\u00e3o comida.",Fe:"Nota: Se os ataques pararem prematuramente, tente 'Resetar Ataques'.",Je:"Iniciar",He:"Resetar",Ke:"Parar",Le:"Configura\u00e7\u00f5es de Expedi\u00e7\u00e3o (Clique para minimizar)",
Ae:"Monstro 1",Be:"Monstro 2",Ce:"Monstro 3",De:"Monstro 4",Qk:"Reparar antes de fundir?",Ki:"Esta op\u00e7\u00e3o usar\u00e1 cervisia quando seu premium expirar.",qj:"Esta op\u00e7\u00e3o ativa e seleciona \u00f3leos das recompensas divinas. Pode usar \u00f3leos n\u00famero 1 e 3 no personagem, mas o n\u00famero 2 s\u00f3 ser\u00e1 pego para pacotes.",Ii:"Esta op\u00e7\u00e3o usar\u00e1 buffs no hor\u00e1rio que voc\u00ea definir. Encontrar\u00e1 buffs nos pacotes e os aplicar\u00e1 ao personagem.",
gj:"Esta op\u00e7\u00e3o te levar\u00e1 ao submundo. N\u00e3o esque\u00e7a de habilitar o Login Autom\u00e1tico na aba Extras, caso contr\u00e1rio, voc\u00ea pode ser desconectado ao entrar no submundo [Bug do Jogo]",Zb:"O bot normalmente escolhe de 3 a 6 tentativas aleat\u00f3rias para atacar na lista de arena. Se voc\u00ea habilitar esta op\u00e7\u00e3o, ele passar\u00e1 pela sua lista at\u00e9 que possa atacar algu\u00e9m. Isso pode levar algum tempo.",Cj:"Esta op\u00e7\u00e3o \u00e9 apenas para licen\u00e7as premium. Simula o ataque antes de atacar um usu\u00e1rio para uma taxa de vit\u00f3ria de 75%.",
Jd:"Voc\u00ea n\u00e3o precisa habilitar a togglede leil\u00e3o principal para habilitar esta op\u00e7\u00e3o.",kk:"Esta op\u00e7\u00e3o atualizar\u00e1 a p\u00e1gina a cada segundo quando o leil\u00e3o estiver no estado -Muito Curto- para dar lances constantemente e vencer o leil\u00e3o.",Oj:"Se nenhuma das condi\u00e7\u00f5es de fus\u00e3o for atendida, ele fundir\u00e1 aleatoriamente. Certifique-se de selecionar o tipo e a cor do item.",Pj:"Esta op\u00e7\u00e3o fundir\u00e1 apenas itens do invent\u00e1rio. Ignorar\u00e1 itens nos pacotes.",
Ua:"Itens de Leil\u00e3o",lg:"Itens de Mercen\u00e1rio",Tb:"Itens da Loja",ui:"Itens \u00danicos",Kj:"Definir fundo para preto [Aumenta o desempenho]",Lj:"Mover bot\u00f5es do GLDbot para o canto inferior esquerdo?",Li:"Atacar o Circo Sem Curar",jk:"Pegar ouro dos pacotes se necess\u00e1rio?",Tl:"Ouro foi pego dos pacotes para treinamento",Ad:"Nenhum ouro foi encontrado nos pacotes para treinamento",gk:"Itens Reparados",$j:"Ataques na Arena",bk:"Ataques no Circo",zd:"Itens Reiniciados",ek:"Ataques em Expedi\u00e7\u00f5es",
dk:"Ataques em Masmorras",hk:"Ataques no Submundo",ak:"Dinheiro Ganhado na Arena",ck:"Dinheiro Ganhado no Circo",Rl:"Itens Fundidos",fk:"Ouro Reciclado",Yi:"Batalha de Guilda",$i:"Configura\u00e7\u00f5es da Guilda",ll:"Atacar\u00e1 guildas aleatoriamente.",Zi:"Nome da Guilda",Ji:"Redefinir Estat\u00edsticas",Xi:"Atacar Guildas Aleatoriamente",wl:'GLDbot: Use os dados para atualizar a caixa misteriosa e encontrar itens valiosos antes de abri-los (Etc. Trajes). Clique em "Iniciar" para abrir ba\u00fas.',
Kc:"Madeira",Ac:"Cobre",Ec:"Ferro",Gc:"Couro",Lc:"Fio de L\u00e3",Bc:"Bolas de Algod\u00e3o",Dc:"Hemp",Cc:"Tiras de Gaze",Hc:"Fios de Linho",Fc:"Remendo",Jc:"Veludo",Ic:"Fio de Seda",Tc:"Pelo",Nc:"Lasca de Osso",Wc:"Escama",Qc:"Garra",Sc:"Presas",Rc:"Escama de Drag\u00e3o",Oc:"Corno de Touro",Vc:"Gl\u00e2ndula Venenosa",Pc:"Casaco de Pele de Cerberus",Uc:"Escama de Hydra",Xc:"Pena de Esfinge",Yc:"Pele de Typhon",wc:"Lapis Lazuli",qc:"Ametista",pc:"Ambar",rc:"Agua-Marinha",xc:"Safira",uc:"Granada",
tc:"Esmeralda",sc:"Diamante",vc:"Jasper",yc:"Sugilite",kc:"Veneno de Escorpi\u00e3o",nc:"Tintura de Resist\u00eancia",fc:"Antidoto",ec:"Adrenalina",mc:"Tintura Esclarecedora",jc:"Po\u00e7\u00e3o de Perce\u00e7\u00e3o",hc:"Ess\u00eancia de Rea\u00e7\u00e3o",ic:"Frasco de Carisma",oc:"\u00c0guas de Oblivion",lc:"Ess\u00eancia de Alma",xd:"Selo Aqu\u00e1tico",rd:"Runa Protetora",pd:"Marca da Terra",wd:"Totem de Cura",vd:"Talism\u00e3 do Poder",td:"Pedra da Fortuna",qd:"Pedernal",ud:"Runa da Tempestade",
sd:"Runa das Sombras",cd:"Cristal",bd:"Bronze",gd:"Obsidiana",kd:"Prata",ld:"Enxofre",ed:"Mina de Ouro",jd:"Quartzo",hd:"Platina",ad:"Almandin",dd:"Cuprit",fd:"Pedra do Inferno",Fi:"Atacar Aleatoriamente em Provinciarum?",Gi:'Tamb\u00e9m desative a configura\u00e7\u00e3o "Classificar jogadores na arena por n\u00edvel" no crazy-addon.',Ug:"Aceitar apenas miss\u00f5es com base no tipo de deus.",Va:"Auto Buff",Xd:"Usar apenas no inferno?",Ag:"Nova Regra",yg:"Nome Cont\u00e9m",isUnderworldItem:"\u00c9 Item do Submundo",
df:"Ignorar Materiais",rk:"Usar Ora\u00e7\u00e3o?",Ai:"Usar Sacrif\u00edcio?",mk:"Usar Roupas para Entrar no Submundo?",ri:"Miss\u00f5es do Submundo",pi:"Se habilitado, voc\u00ea precisa digitar nomes de itens do submundo. Se o bot encontrar esses itens no submundo, ele aceitar\u00e1 a miss\u00e3o.",Yk:"Item da Miss\u00e3o do Submundo",il:"Digite o nome do material",Bk:"O bot adora dados! Eles ajudam a encontrar roupas nos ba\u00fas. Mas se n\u00e3o houver dados, o bot abre os ba\u00fas mesmo assim, na esperan\u00e7a de encontrar roupas legais (mas pode n\u00e3o encontrar nenhuma!)",
Nj:"Enviar os materiais derretidos para os pacotes?",le:"Ativar Arena?",Mg:"Priorizar lista de arena?",Ng:"Priorizar lista de circo?",de:"Desativar Menu de Log",ih:"Recompensa Min. Valor em Ouro",Vg:"Miss\u00e3o Focada, se ativada, seguir\u00e1 o caminho mais curto para terminar a masmorra.",Hh:"Jogar Dados Automaticamente?",Ih:"Use jogar dados com cautela, ele continuar\u00e1 usando o primeiro dado at\u00e9 voc\u00ea desativar a op\u00e7\u00e3o.",nh:"Progresso da Pesquisa",bh:"O tempo de espera para reparo por padr\u00e3o \u00e9 de 10 minutos.",
vg:"Condi\u00e7\u00e3o M\u00ednima",be:"Item atual na bancada [Limpar se o bot pausar inesperadamente]",Af:"Recursos da Forja armazenados com sucesso no horreum.",wf:"Verificando itens no mercado...",yb:"Item movido para a bancada.",Nf:"Item reparado e equipado com sucesso.",Of:"Item reparado com sucesso.",Lk:"Reparo falhou. A p\u00e1gina ser\u00e1 atualizada.",Kf:"Pegando materiais...",Xf:"Aguardando reparo...",Mf:"Reparo iniciado para .",va:"Reparo: Movendo o item do invent\u00e1rio para a bolsa",
Lf:"Reparo: Movendo o item da bancada para o pacote.",ta:"N\u00e3o foi poss\u00edvel encontrar materiais suficientes. Desativando o slot de reparo ",Hf:"Procurando itens para comprar para esconder ouro no Leil\u00e3o...",tf:"Verificando itens expirados nos pacotes...",uf:"Item redefinido com sucesso.",vf:"Sem Espa\u00e7o Vazio ou Ouro para Redefinir.",Bf:"Certifique-se de que voc\u00ea tem direitos de venda no mercado da guilda!",sb:"Ouro insuficiente e/ou nenhum item para comprar. Aguardando 30s para atualizar.",
ub:"Loja foi atualizada.",vb:"Erro durante a cura.",Ef:"Sem Rubi ou Pano, desativando as op\u00e7\u00f5es.",Kk:"Nenhum item de cura encontrado nos pacotes.",wb:"Nenhum item adequado encontrado",Ff:"Alimentos foram pegos. Finalizando o processo.",Gf:"Pelo menos um alimento foi pego. Finalizando processo.",xb:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",Cf:"Pegando comida dos pacotes.",Df:"Nenhum espa\u00e7o adequado encontrado na bolsa para pegar comida.",tb:"Sem mais itens de cura. Aguardando 30 segundos.",
rb:"HP Recuperado.",ua:"Nada para fazer ent\u00e3o vou rezar!",Tf:"Vou atualizar em 60 segundos para verificar minha sa\u00fade e villa medici.",Uf:"Aguardando Villa Medici, atualizando em 60 segundos.",Vf:"Saiu do submundo.",Wf:"Vou atualizar em 60 segundos para verificar minha sa\u00fade.",If:"Verificando \u00f3leos de deus...",Jf:"\u00d3leos de deus foram pegos.",ra:"Atacou com sucesso o jogador na ARENA: ",sa:"Atacou com sucesso o jogador no CIRCO: ",rf:"Verificando leil\u00e3o! Por favor, aguarde...",
sf:"Dando lances em itens. Por favor, aguarde...",Pf:"Item Derretido Automaticamente: ",Qf:"Derretendo Item: ",Rf:"Ouro insuficiente para derreter. Ouro Necess\u00e1rio: ",Sf:"DERRETER: Procurando itens para derreter...",Mk:"Procurando itens para derreter...",xf:"Verificando disponibilidade de traje...",zf:"Doado : ",yf:"Jogando dados...",Re:"Underworld Farm [Manual, Beta]",Se:"Esteja ciente: ative este recurso ap\u00f3s desbloquear a criatura que deseja atacar, ela n\u00e3o atacar\u00e1 automaticamente para desbloquear o monstro.",
Qe:"Farm Location",Pe:"Farm Enemy",Qd:"Login Autom\u00e1tico",Rd:"Voc\u00ea precisa permitir pop-ups da tela do lobby do GameForge. Veja a documenta\u00e7\u00e3o sobre como fazer isso.",Ig:"Pausar Bot",Jg:"Pausar Bot em (Minutos)",Ne:"Data de Expira\u00e7\u00e3o",Dg:"Comprar apenas comida?",Eg:"Se voc\u00ea habilitar isso, o bot ignorar\u00e1 suas sele\u00e7\u00f5es e comprar\u00e1 comida automaticamente sem inserir nada.",Gb:"M\u00e1ximo de ouro total para gastar",Fb:"M\u00e1ximo de ouro por comida para gastar",
Cg:"O bot verificar\u00e1 \u00f3leos a cada 60 minutos",$h:"Define um temporizador para verificar os tempos de fus\u00e3o.",Xh:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver ouro.",Zh:"Define um temporizador para verificar a fus\u00e3o quando n\u00e3o tiver o item dispon\u00edvel.",Sh:"Define um temporizador para reparar e verificar seus itens.",Rh:"Define um temporizador para verificar o ouro mantido no mercado da guilda.",Nh:"Define um temporizador para a op\u00e7\u00e3o de reten\u00e7\u00e3o de ouro em leil\u00e3o.",
Jh:"Define um temporizador para verificar a lista de PvP na arena para atacar.",Oh:"Define um temporizador para verificar a lista de PvP no circo para atacar.",fi:"Define um temporizador para treinar suas estat\u00edsticas.",Uh:"Define um temporizador para redefinir itens expirados.",di:"Define um temporizador para armazenar materiais de forja no horreum.",Lh:"Define um temporizador para verificar o leil\u00e3o de gladiadores e mercen\u00e1rios.",Wh:"Define um temporizador para buscar itens em leil\u00e3o e loja.",
Ph:"Define o temporizador para enviar doa\u00e7\u00f5es \u00e0 guilda.",We:"Ouro Movido",ie:"N\u00e3o venda itens da lista de fundi\u00e7\u00e3o e leil\u00e3oo",oh:"Automa\u00e7\u00e3o da Loja",qh:"Configura\u00e7\u00f5es de Busca de Item",ph:"Use esta ferramenta para buscar itens. Basta adicionar os itens \u00e0 lista, especificar a quantidade de pano e iniciar a busca.",rh:"Panos a Usar:",th:"Quantos panos usar?",ea:"Full Digite o Nome do Item",Sb:"Digite o N\u00edvel do Item",vh:"Qualidade do Item",
uh:"Nome do Item Aqui",wh:"Iniciar Busca",xh:"Pular e Continuar",yh:"Parar Busca",Te:"Comprar o mais barato ou o mais caro?",xg:"Mais Caro",Zd:"Mais Barato",ba:"Selecionar uma op\u00e7\u00e3o",ne:"Destacar itens do submundo",Ue:"Foco na miss\u00e3o?",Vl:"Usar Ruby se n\u00e3o houver pano?",Wa:"Evite atacar as mesmas pessoas para n\u00e3o ser reportado. Ser reportado aumenta as chances de ser banido.",Kl:"Queimar verde?",Pg:"N\u00e3o aceitar miss\u00f5es aleat\u00f3rias se algum filtro for inserido?",
Mc:"Qualidade m\u00e1xima do material a ser usado",Ui:"Ativar a busca mercen\u00e1ria",sl:"Clique em `Vender Todos Selecionados` para vender todos os itens. Certifique-se de ter um espa\u00e7o vazio de 2x3 em sua primeira (1) bolsa. Para coletar ouro em massa, filtre ouro e use `Selecionar Todos ou Selecionar`",Zj:"\ud83d\udd25 : Adiciona item \u00e0 lista de fundi\u00e7\u00e3o.",Hi:"\ud83d\udd28 : Adiciona item \u00e0 lista de leil\u00e3o.",Ej:"Atualize a loja com pano quando estiver cheia",sj:"P\u00e1gina:",
zj:"Parar",xj:"Vender Esta P\u00e1gina",uj:"Selecionar Selecionados",tj:"Selecionar Tudo",Aj:"Configura\u00e7\u00f5es de Empacotamento Autom\u00e1tico",yj:"Enviar Recursos",vj:"Vender Todos Selecionados",ma:"Tipo de Item",oa:"Armas",S:"Escudos",M:"Armaduras",P:"Capacetes",O:"Luvas",N:"Botas",na:"An\u00e9is",ka:"Amuletos",Ia:"Utiliz\u00e1veis (Alimentos)",Na:"Melhorias",rj:"Potencializadores",Ka:"Receitas",Ja:"Mercen\u00e1rios",Ma:"Ferramentas de Forja",La:"Pergaminhos",od:"Refor\u00e7os",md:"Itens de Evento",
nd:"Materiais de Forja",zl:"Ouro",Ha:"Todos",Al:"Qualidade",pa:"Branco",C:"Verde",B:"Azul",D:"Roxo",H:"Laranja",R:"Vermelho",wj:"Op\u00e7\u00f5es de Venda",Mj:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo?",aj:"Quantos alimentos comprar/pegar?",Pi:"Normal",Oi:"Intermedi\u00e1rio",Ni:"Dif\u00edcil",Ea:"Padr\u00e3o",Dl:"Reparar Corre\u00e7\u00e3o de Travamento",Ik:"Desative a entrada no Inferno se voc\u00ea quiser desabilitar a Dungeon/Circo/Arena. Se voc\u00ea entrar no Inferno manualmente, ser\u00e1 necess\u00e1rio ativar o Modo Inferno.",
$d:"Escolher traje do submundo",Di:"Vestir traje do submundo quando dispon\u00edvel?",ii:"Define quantas vezes quer treinar as estat\u00edsticas e suas prioridades. O bot n\u00e3o treinar\u00e1 a menos que defina uma prioridade. Se n\u00e3o houver mais estat\u00edsticas ele continuar\u00e1 com as estat\u00edsticas Defenidas.",el:"Aventura",Il:"Derreter",Ol:"Defini\u00e7\u00f5es de Derreter",Wj:"Itens Derretidos",Pl:"Adicione um Prefixo ou Sufixo, uma vez encontrado nos pacotes Ser\u00e1 Derretido automaticamente.:",
Nl:"Derreter Item:",bc:"Clique no item que voc\u00ea deseja consertar. Isto utilizar\u00e1 apenas materiais Padr\u00e3o, Verde e Azul. Voc\u00ea precisa ter pelo menos 10.000 ouro para iniciar o reparo. Abra espa\u00e7o 3x3 em sua PRIMEIRA Bolsa do invent\u00e1rio. Caso contr\u00e1rio, ele poder\u00e1 ficar preso! O bot iniciar\u00e1 o reparo assim que o item tiver durabilidade de %0.",Zk:"Aplicar apenas no Mercenario.",bl:"O leil\u00e3o s\u00f3 dar\u00e1  o lance quando o mercado estiver no Fim..",
al:"Certifique-se de que a SEGUNDA PAGINA DO INVENT\u00c1RIO est\u00e1 vazia e tem 10K de ouro. O bot encontrar\u00e1 e colocar\u00e1 o item na segunda pagina e na pr\u00f3xima vez, a p\u00e1gina, atualiza-se Derrentendo o item. A fundi\u00e7\u00e3o acontecer\u00e1 novamente a cada 5-10 minutos. ",dj:"Cura & Buffs",El:"Sem ouro suficiente para fundir. Ouro necess\u00e1rio!:",Hl:"Skipping bid: Membro da galian\u00e7a j\u00e1 deu lance no item ",Gl:"Skipping bid: J\u00e1 licitei o item ",advanced:"Avan\u00e7ado",
arena:"Arena",ia:"Ataque autom\u00e1tico",$b:"Evitar Atacar",ga:"Adicionar Jogador",ha:"Adicionar Nome do Jogador (Same Server)",nl:"Parar o Bot se ficar sem comida?",circusTurma:"Circus Turma",Qi:"Dificuldade",dungeon:"Masmorra",Ri:"Configura\u00e7\u00e1o da Masmorra",eventExpedition:"Expedi\u00e7\u00e3o de evento",expedition:"Expedi\u00e7\u00f5es",Vi:"Configura\u00e7\u00e1o de Expedi\u00e7\u00f5es",Gj:"Selecionar Monstro",pl:"Maior",ol:"Coloque as curas na primeira p\u00e1gina do invent\u00e1rio",
zc:"No",Fh:"Guardar Ouro",Gh:"Guardar ouro no Leil\u00e3o?",Qb:"Selecionar Horas",lh:"Utilizar Roupas para Renovar Iventario?",Sk:"Selecione itens para serem redefinidos",eh:"Redefinir itens expirados\t",Mb:"Nota: Ao ativar esta op\u00e7\u00e3o, o bot vender\u00e1 os  itens expirados nos Pacotes para o Mercado da Guilda e cancelar\u00e1 para redefinir o tempo de expira\u00e7\u00e3o. Guilda \u00e9 necess\u00e1ria. Certifique-se que tem espa\u00e7o 3x3 vazio no iventario. Nota: Tamb\u00e9m ir\u00e1 coletar as Moedas de Ouro se elas estiverem prestes a expirar!!!",
Kg:"Parar o Bot Aleatoriamente para trabalhar como [Fase de Teste]:",Y:"Ficar com o Ouro: Bot vai guardar esse ouro na bolsa:",jg:"maximo de Ouro: O bot gastar\u00e1 o ouro quando for Superior a",jh:"Ofertas ser\u00e3o aceitas por itens desnecess\u00e1rios",Bd:"Adicionar atraso aleat\u00f3rio",Cd:"Podes adicionar um atraso para o bot aqui.",Lb:"Reparar",Jl:"Derreter apenas Azul?",Ml:"Derreter apenas Roxo?",Ll:"Derreter apenas Laranja?",Xj:"Derreter apenas itens do inventário?",Yj:"Isto ir\u00e1 ignorar a cor e os itens da lista. A pagina 1 est\u00e1 reservada a repara\u00e7\u00e3o..",
Ah:"Derreter",Kd:"Pesquisa autom\u00e1tica",zg:"Leil\u00e3o Autom\u00e1tico",Ld:"O uso excessivo do Leil\u00e3o pode resultar em banimento. Esse recurso tamb\u00e9m pode desacelerar o bot, pois ele verifica os leil\u00f5es a cada atualiza\u00e7\u00e3o. As licita\u00e7\u00f5es s\u00e3o feitas a cada 5 minutos, a menos que o leil\u00e3o esteja no estado \u201cmuito curto\u201d. Observe que, se voc\u00ea colocar apenas um item na se\u00e7\u00e3o PREFIX, o bot tentar\u00e1 filtrar pelo nome dos itens para licitar mais rapidamente. Embora voc\u00ea precise desativar a licita\u00e7\u00e3o de alimentos para isso.",
kh:"Pesquisar no leil\u00e3o dos gladiadores",mh:"Pesquisar no leil\u00e3o dos mercen\u00e1rios",Td:"Licitar Comida?",kg:"Lance m\u00e1ximo",Ud:"Licitar se o Tempo for inferior a",Vd:"Itens licitados",wk:"Linguagem do Leil\u00e3o",xk:"De acordo com a atualiza\u00e7\u00e3o 2.5.6, defina o idioma novamente.",Fd:"Poder\u00e1 adicionar itens para procurar no mercado e no leil\u00e3o. Tamb\u00e9m mostrar\u00e1 itens roxos no mercado assim que voc\u00ea adicionar um item \u00e0 lista.",uk:"Utilize o leil\u00e3o com cuidado!",
vk:"O lance autom\u00e1tico faz muitas solicita\u00e7\u00f5es ao servidor, causando erro de p\u00e1gina em branco e pode causar banimento se for utilizado com frequ\u00eancia!!",ah:"Renovar pontos de evento com Rubis?",pe:"Ativar \u00f3leo autom\u00e1tico",zk:"Obter os \u00f3leos sagrados automaticamente",Ok:"Velocidade de verifica\u00e7\u00e3o das miss\u00f5es",Sa:"Atacar membros da alian\u00e7a?",Qa:'Adicionar Jogador automaticamente \u00e0 lista de "Ataque" quando X OURO for roubado:',Ra:'Adicione Jogadores automaticamente \u00e0 lista "Evitar Ataque" quando perder:',
Pb:"Placar De Ataques",Xb:"Muito Longo",zb:"Longo",Hb:"M\u00e9dio",Ub:"Curto",Yb:"Bastante Curto",nb:"Aceitar Ataques ao Placar:",Nb:"Selecionar Posi\u00e7\u00e3o do ataque",Ob:"O bot ira atacar aleatoriamente jogadores no placar.",pb:"Ataque da Liga",mb:"Ativar ataque da liga:",Jb:"Ataque aleat\u00f3rio",Kb:"Atacar do Menor para o maior",tk:"Bot N\u00e3o atacara menbros da alian\u00e7a.",Me:"Local da Expedi\u00e7\u00e3o:",Md:"Coletar Bonus automaticamente:",zh:"Ignorar Chefe",ke:"Local da Masmorra:",
hh:"Recome\u00e7ar se perder?",$e:"Defeni\u00e7\u00f5es do Inferno",af:" A Personagem entrar\u00e1 no submundo apenas quando o HP for> 90%. Por favor, defina as configura\u00e7\u00f5es de porcentagem de cura na Aba de cura e certifique-se de que a Aba de cura est\u00e1 ativada. Se ao entrar no submundo fizer logout, v\u00e1 para o lobby e ative a caixa de sele\u00e7\u00e3o de login autom\u00e1tico.",Ye:"Dificuldade Do inferno:",Pd:"Entrar automaticamente no inferno / Inferno Mode",yi:"Utilizar Mobiliza\u00e7\u00e3o se pontos = 0",
Ci:"Usar Rubies?",se:"Deixar Inferno se nao tiver pontos?",ki:"O bot tentar\u00e1 usar a Villa Medici primeiro, se voc\u00ea n\u00e3o tiver, ele usar\u00e1 a po\u00e7\u00e3o de cura. N\u00e3o se esque\u00e7a de ativar o bot\u00e3o de Cura!.",ti:"Entrar automaticamente no Inferno ira desabilitar masmorras/arena/Circus.",Xk:"Defeni\u00e7oes de cura no Inferno",Bi:"Usar Villa Medici?",zi:"Usar Po\u00e7\u00e3o de Vida?",Yf:"INFO: O bot ir\u00e1 procurar itens no mercado a cada minuto selecionado, o que pode parar o ataque durante a busca.",
oe:"Ativar pesquisa de mercado:",Zf:"Intervalo de pesquisa no mercado:",$f:"Sugest\u00e3o 10 minutos.",kf:"Defini\u00e7\u00f5es de itens:",hf:"Nome do item inclui",G:"Pre\u00e7o Maximo",lf:"Estilo do Item",jf:"Raridade do Item",Yd:"Comprar Soulbound?",nf:"Itens para comprar",mf:"Tentar comprar itens com pacotes se algum deles corresponde ao pre\u00e7o m\u00e1ximo Defenido.:",Wd:"Itens Comprados:",bj:"Percentagem de Cura",pk:"Comprar comida da Loja?",qk:"Usar cura dos pacotes?",lk:"Usar Cervisia?",
nk:"Usar Ovos?",tl:"Usado por \u00faltimo",location:"Localiza\u00e7\u00e3o",Strength:"For\u00e7a",Dexterity:"Destreza",Agility:"Agilidade",Constitution:"Constitui\u00e7\u00e3o",Charisma:"Carisma",Intelligence:"Inteligencia",gi:"Defini\u00e7\u00f5es de Treino",hi:"Selecione os atributos que deseja treinar. ir\u00e1 treinar assim que houver ouro suficiente.",$c:"Proxima A\u00e7\u00e3o",oj:"N\u00e3o",pj:"Normal",xl:"Oponente",yl:"Nivel do Oponente",Dj:"Miss\u00f5es",random:"aleat\u00f3rio",Fl:"Defini\u00e7\u00f5es",
Ql:"Brevemente...",type:"Clique nos \u00edcones para ativar os tipos de miss\u00f5es. Selecione os 3 primeiros se quiser se concentrar em Circus & Arena",Xl:"Sim",A:"Procura",yd:"Adicionar item [NOME COMPLETO]",ik:"Guardar recursos da Forja automaticamente",Sl:"Enviar",rl:"Intervalo : ",gl:"Ativar lance autom\u00e1tico",hl:"Cobrir aliados",Ul:"Tutorial",ac:"MMais jogadores ir\u00e3o por o bot mais lento.",$k:"Comece adicionando o nome completo dos itens \u00e0 lista. Uma vez adicionado, a ferramenta exibir\u00e1 os resultados da pesquisa \u00e0 esquerda. Isso tamb\u00e9m auxilia nas pesquisas de leil\u00e3o autom\u00e1tico. Com o lance autom\u00e1tico ativado, a ferramenta far\u00e1 pesquisas peri\u00f3dicas com base no intervalo definido. Se o item for encontrado e voc\u00ea tiver fundos suficientes, ele far\u00e1 um lance automaticamente. Nota: Para pesquisar itens exclusivos em lojas, voc\u00ea deve adicionar pelo menos um item \u00e0 lista de pesquisa...",
jl:"O n\u00famero da criatura pode ser escolhido nos bot\u00f5es acima. O n\u00famero 1 representa a criatura \u00e0 esquerda. Certifique-se de selecionar o local correto, caso contr\u00e1rio o bot poder\u00e1 fazer uma pausa.",Si:"Escolha a dificuldade da masmorra nas op\u00e7\u00f5es acima. Certifique-se de selecionar o local correto, caso contr\u00e1rio, o bot poder\u00e1 fazer uma pausa.",cj:"Defini\u00e7\u00f5es de cura",Ti:"Armazene o excesso de ouro na Guilda comprando itens do mercado da Guilda. -> Min. Gold",
ul:"Mover tudo",vl:"Mover o Selecionado",cl:"Curar autom\u00e1ticamente",dl:"Percentagem da cura",Wl:"Rubi",Fg:"Defini\u00e7\u00f5es Gerais",Hj:"Vender tudo",Ij:"Vender Selecionados",fa:"Armas",ca:"Escudos",U:"Armaduras",X:"Capacetes",W:"Luvas",da:"Sapatos",aa:"Aneis",T:"Amuletos",wi:"Usaveis",vi:"Atualiza\u00e7\u00f5es",Xg:"Receitas",mg:"Mercen\u00e1rios",Zg:"Refor\u00e7os",qe:"Entrar no Submundo se HP >",Wg:"Velocidade de Verifica\u00e7\u00e3o de Miss\u00e3o",Og:'O padr\u00e3o \u00e9 "3x". Se o bot causar problemas com miss\u00f5es, altere a velocidade da miss\u00e3o de acordo com a velocidade do seu servidor.',
Xe:"Saco de Cura",re:'Se voc\u00ea est\u00e1 renovando pontos manualmente, voc\u00ea precisa clicar no bot\u00e3o acima "Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!',Dk:"Voc\u00ea deve ativar pelo menos uma das seguintes op\u00e7\u00f5es: expedi\u00e7\u00e3o, masmorra, arena ou circo para iniciar a Expedi\u00e7\u00e3o de Evento.",Yg:"Atualizar Expedi\u00e7\u00e3o de Evento se estiver preso!",kb:"Não cobrir Aliados?",Vk:"Deixe todas as configura\u00e7\u00f5es desativadas se desejar fundir usando pacotes que cont\u00eam os itens da lista. No entanto, voc\u00ea ainda pode escolher cores.",
Ak:"Personagem(Desligado) / Mercen\u00e1rio(Ligado)",Rk:"Reparar Ambos?",Wk:"Cron\u00f4metros",Timers:"Insira o n\u00famero de minutos para cada cron\u00f4metro abaixo ou deixe-o padr\u00e3o.",Tg:"Ignorar Filtro de Miss\u00e3o",Sg:"Digite palavras-chave para filtrar miss\u00f5es que voc\u00ea n\u00e3o deseja aceitar",V:"Inserir Palavra-chave",I:"Adicionar",$g:"Remover",ae:"Limpar",Qg:"Aceitar Filtro de Miss\u00e3o",Rg:"Digite palavras-chave para escolher quais miss\u00f5es aceitar. Usar isso ignorar\u00e1 os tipos de miss\u00e3o",
Ca:"Pular Miss\u00f5es de Tempo?",Pk:"Miss\u00f5es",Nd:"Auto Traje",xi:"Usar Traje?",Sd:"Batalha B\u00e1sica",je:"Batalha em Masmorra",Od:"O bot s\u00f3 usar\u00e1 Dis Pater Normal e M\u00e9dio se seus pontos de expedi\u00e7\u00e3o/masmorra forem 0.",Ze:"Configura\u00e7\u00f5es de Cura no Inferno",Ed:"Atacar Chefe Quando Dispon\u00edvel?",qb:"O ataque \u00e0 Liga ser\u00e1 desativado ap\u00f3s 5 ataques malsucedidos.",bf:"\u00d3leos Sagrados",ug:"Nome do Item",Z:"N\u00edvel M\u00edn. do Item",Aa:"Qualidade M\u00edn. do Item",
Dd:"Aplicar/Reiniciar Temporizador",ef:"Ignorar Combina\u00e7\u00e3o de Prefixo/Sufixo",Ei:"Sim",Bg:"N\u00e3o",Oa:"Adicionar Prefixo",Pa:"Adicionar Sufixo",Xa:"Limpar Hist\u00f3rico",Bh:"Lista de Ignora\u00e7\u00e3o de Fundi\u00e7\u00e3o",Ib:"Prefixo",Vb:"Sufixo",gh:"Redefinir Itens Expirados",Ch:"Fundir Aleatoriamente de Pacotes?",Dh:"Aba de Fundi\u00e7\u00e3o",ob:"Extras",Id:"Leil\u00e3o",cg:"Mercado",Wb:"Temporizadores",bi:"Fundi\u00e7\u00e3o",ai:"Fundi\u00e7\u00e3o se n\u00e3o houver ouro suficiente",
Yh:"Fundir se n\u00e3o houver item",Da:"Reparo",Qh:"Manter Ouro no Mercado da Guilda",Mh:"Manter Ouro no Leil\u00e3o",ei:"Treinamento",Th:"Redefinir Expirados",ci:"Loja de Forja",Kh:"Verifica\u00e7\u00e3o de Leil\u00e3o",Vh:"Pesquisa",v:"Habilitar",wg:"Ouro M\u00ednimo",lb:"Doar Ouro para a Guilda",ee:"Isso doar\u00e1 a cada 5 minutos. Voc\u00ea pode alterar o intervalo na guia de temporizadores",cf:"Quanto deseja doar?",fe:"Doar quando tiver mais que >",qf:"Menos que <",dh:"Redefinir Expirados e Outras Configura\u00e7\u00f5es",
fh:"Redefinir em:",Jk:"Mantenha Ctrl (Cmd no Mac) pressionado para selecionar v\u00e1rios itens",ff:"Importar/Exportar Configura\u00e7\u00f5es",Oe:"Exportar Configura\u00e7\u00f5es",gf:"Importar Configura\u00e7\u00f5es",ng:"Mensagem para Todos os Jogadores",og:"[Requer Chave Ultra Premium, mensagem no Discord para obter a chave.]",pg:"Digite a mensagem a ser enviada",ce:"Para scripts personalizados, entre em contato conosco no Discord",rg:"Enviar",sg:"Mostrar Jogadores",qg:"Selecionar Todos",tg:"Desmarcar Todos",
pf:"Certifique-se de que seu invent\u00e1rio tenha espa\u00e7o suficiente. O tempo de recarga \u00e9 de 2 minutos.",gg:"Vender Comida",Db:"Mudar para Comida"},Jh={Fk:"Twoje ustawienia ekspedycji s\u0105 nieprawid\u0142owe lub wyst\u0105pi\u0142y nieoczekiwane dane strony!",Gk:"Twoje ustawienie ekspedycji jest nieprawid\u0142owe! Ustawi\u0142e\u015b wy\u0142\u0105czonego potwora, co jest b\u0142\u0119dne.",Tk:"Zresetowa\u0107 tylko wszystkie przedmioty z podziemi o wybranym kolorze?",Ba:"Priorytet",
Rb:"Ustaw Priorytet",Lg:"Punkty",Eh:"Stat",Mi:"Zbieranie Z\u0142ota",Jj:"Sprzedaj przedmioty z podziemia?",nj:"Bot b\u0119dzie szuka\u0142 gniazda w ka\u017cdej akcji, nie tylko na wyprawach.",lj:"Typ wyszukiwania gniazda",jj:"Nic nie r\u00f3b",kj:"Szybkie wyszukiwanie",mj:"Dok\u0142adne wyszukiwanie",Bj:"After expedition points are consumed, travel to Germania to consume Dungeon points",sk:"Kliknij tutaj, je\u015bli naprawa si\u0119 zacina",Hk:"Gdy HP spadnie poni\u017cej, u\u017cyj leczenia",Hg:"Cz\u0119\u015bciowa Naprawa",
Ve:"Pe\u0142na Naprawa",Gg:"Cz\u0119\u015bciowa lub Pe\u0142na Naprawa",me:"W\u0142\u0105cz Limit",ej:"Limit",fj:"Je\u015bli chcesz ograniczy\u0107 liczb\u0119 atak\u00f3w na przeciwnika, w\u0142\u0105cz t\u0119 opcj\u0119 i ustaw limit. Bot b\u0119dzie kontynuowa\u0142 atakowanie reszty przeciwnik\u00f3w po zako\u0144czeniu atak\u00f3w na wybranego potwora.",he:"Nie wchod\u017a do podziemia w kostiumie podziemia",ge:"Je\u015bli nie chcesz wchodzi\u0107 do podziemia, maj\u0105c na sobie kostium podziemia, w\u0142\u0105cz t\u0119 opcj\u0119",
si:"Podziemia",ji:"Wzmocnienia Podziemi",li:"U\u017cy\u0107 mocy bog\u00f3w po wej\u015bciu do podziemi?",mi:"Wybierz bog\u00f3w, kt\u00f3rych moce chcesz wykorzysta\u0107:",ni:"U\u017cy\u0107 Wzmocnienia Broni na broni?",oi:"U\u017cy\u0107 Wzmocnienia Zbroi na nast\u0119puj\u0105cym ekwipunku?",Ck:"Czas odnowienia wynosi 30 minut. Je\u015bli nie masz kostiumu, bot zresetuje czas odnowienia do 0.",Uk:"Wybierz Kolory",Ya:"Kowad\u0142o Wulkana",bb:"Ziemna Tarcza Feronii",cb:"P\u0142ynna Moc Neptuna",
eb:"Powietrzna Wolno\u015b\u0107 Aelousa",fb:"Zab\u00f3jcza Mg\u0142a Plutona",gb:"Oddech \u017bycia Junony",hb:"Pancerz \u0141usek G\u00f3r Gniewu",ib:"Orle Oczy",jb:"Zimowy Str\u00f3j Saturna",Za:"Bycza Zbroja Bubony",$a:"Szaty Z\u0142odzieja Merceriusa",ab:"Szata \u015awiat\u0142a Ra",fg:"Paczki",ag:"Inwentarz",K:"Min. Cena",J:"Ile",Cb:"Sprzedaj Przedmioty",Bb:"Szukaj w",bg:"Kolor Materia\u0142u",Ab:"Kolor Przedmiotu",ig:"Magazyn",za:"Prze\u0142\u0105cz na Materia\u0142y",Eb:"Prze\u0142\u0105cz na Przedmioty",
hg:"Sprzedaj Materia\u0142y",wa:"Prosz\u0119 wprowadzi\u0107 poprawn\u0105 nazw\u0119 przedmiotu, zakres cen oraz ilo\u015b\u0107.",xa:"Nie znaleziono odpowiednich przedmiot\u00f3w w wybranych miejscach wyszukiwania.",ya:"Wszystkie przedmioty zosta\u0142y pomy\u015blnie wystawione!",Nk:"Wszystkie materia\u0142y zosta\u0142y pomy\u015blnie wystawione!",dg:"Je\u015bli chcesz sprzeda\u0107 przedmioty za sta\u0142\u0105 cen\u0119, mo\u017cesz wpisa\u0107 t\u0119 sam\u0105 warto\u015b\u0107 dla minimalnej i maksymalnej ceny.",
eg:"Ta funkcja jest nadal eksperymentalna, u\u017cywaj ostro\u017cnie. Je\u015bli nie ustawisz sta\u0142ej ceny, przedmioty b\u0119d\u0105 wy\u015bwietlane losowo mi\u0119dzy minimaln\u0105 a maksymaln\u0105 cen\u0105, kt\u00f3r\u0105 wpiszesz.",yk:"Ustawia maksymaln\u0105 ilo\u015b\u0107 z\u0142ota, kt\u00f3r\u0105 bot wyda w jednym cyklu.",Ta:"Bot zacznie licytowa\u0107 wszelkie przedmioty \u017cywno\u015bciowe, je\u015bli opcja jest w\u0142\u0105czona. Nie musisz w\u0142\u0105cza\u0107 prze\u0142\u0105cznik\u00f3w gladiatora/najemnika.",
Gd:"Bot nie b\u0119dzie licytowa\u0142 ofert sojusznik\u00f3w.",Hd:"Ignoruj kombinacj\u0119 Prefixu/Sufiksu podczas szukania przedmiotu na aukcji.",Qj:"Wybierz typy przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Rj:"Wybierz kolory, kt\u00f3re chcesz przetopi\u0107.",Sj:"Wybierz poziom przedmiot\u00f3w, kt\u00f3re chcesz przetopi\u0107.",Tj:"Wybierz m\u0142ot, kt\u00f3rego chcesz u\u017cy\u0107.",Uj:"Zwr\u00f3\u0107 uwag\u0119, \u017ce zielone i czerwone k\u00f3\u0142ko obok pierwszego pola s\u0142u\u017cy do w\u0142\u0105czania/wy\u0142\u0105czania regu\u0142y.",
Vj:"Je\u015bli chcesz przetapia\u0107 losowo jakiekolwiek kolory lub typy, mo\u017cesz w\u0142\u0105czy\u0107 `Czy przetapia\u0107 losowo, je\u015bli \u017cadne warunki nie s\u0105 spe\u0142nione? (Ostatnia w\u0142\u0105czona opcja w filmie instrukta\u017cowym)",Fj:"Napraw przed przetopieniem",Ie:"Wybierz Potwora",we:"U\u017cy\u0107 Klepsydry/Rubinu?",Ek:"U\u017cy\u0107 Rubinu?",ze:"U\u017cy\u0107 Mobilizacji?",ye:"U\u017cy\u0107 Mikstury \u017bycia?",ve:"Procent Leczenia (%)",Ge:"Liczba Atak\u00f3w",
xe:"Interwa\u0142 Ataku (w sekundach)",te:"Wykonane Ataki",ue:"Pozosta\u0142e Klepsydry",Ee:"Uwaga: U\u017cywa mikstur \u017cycia do leczenia, nie jedzenia.",Fe:"Uwaga: Je\u015bli ataki zatrzymaj\u0105 si\u0119 przedwcze\u015bnie, spr\u00f3buj 'Zresetuj Ataki'.",Je:"Rozpocznij",He:"Resetuj",Ke:"Zatrzymaj",Le:"Ustawienia Ekspedycji (Kliknij, aby zminimalizowa\u0107)",Ae:"Potw\u00f3r 1",Be:"Potw\u00f3r 2",Ce:"Potw\u00f3r 3",De:"Potw\u00f3r 4",Qk:"Napraw przed przetopieniem",Ki:"Ta opcja u\u017cyje cervisia, gdy twoja subskrypcja premium wyga\u015bnie.",
qj:"Ta opcja w\u0142\u0105cza i wybiera oleje z nagr\u00f3d boskich. Mo\u017ce u\u017cywa\u0107 olej\u00f3w numer 1 i 3 na postaci, ale numer 2 b\u0119dzie tylko zbierany do paczek.",Ii:"Ta opcja u\u017cyje buff\u00f3w o ustawionym przez ciebie czasie. Znajdzie buffy w paczkach i zastosuje je na postaci.",gj:"Ta opcja wprowadzi ci\u0119 do podziemia. Nie zapomnij w\u0142\u0105czy\u0107 Automatycznego Logowania z zak\u0142adki Dodatki, inaczej mo\u017cesz zosta\u0107 wylogowany przy wej\u015bciu do podziemia [B\u0142\u0105d Gry]",
Zb:"Bot zazwyczaj wybiera losowo od 3 do 6 pr\u00f3b ataku na list\u0119 areny. Je\u015bli w\u0142\u0105czysz t\u0119 opcj\u0119, przejdzie przez twoj\u0105 list\u0119, dop\u00f3ki nie b\u0119dzie m\u00f3g\u0142 kogo\u015b zaatakowa\u0107. To mo\u017ce zaj\u0105\u0107 troch\u0119 czasu.",Cj:"Ta opcja jest tylko dla licencji premium. Symuluje atak przed zaatakowaniem u\u017cytkownika dla 75% szansy na wygran\u0105.",Jd:"Nie musisz w\u0142\u0105cza\u0107 g\u0142\u00f3wnego prze\u0142\u0105cznika aukcji, aby w\u0142\u0105czy\u0107 t\u0119 opcj\u0119.",
kk:"Ta opcja od\u015bwie\u017cy stron\u0119 co sekund\u0119, gdy aukcja jest w stanie -Bardzo Kr\u00f3tki-, aby nieustannie licytowa\u0107 i wygra\u0107 aukcj\u0119.",Oj:"Je\u015bli \u017caden z warunk\u00f3w wytopu nie zostanie spe\u0142niony, b\u0119dzie wybiera\u0107 losowo. Upewnij si\u0119, \u017ce wybra\u0142e\u015b typ i kolor przedmiotu.",Pj:"Ta opcja b\u0119dzie tylko wytopi\u0107 przedmioty z inwentarza. Zignoruje przedmioty w paczkach.",Ua:"Przedmioty na Aukcji",lg:"Przedmioty Najemnika",
Tb:"Przedmioty w Sklepie",ui:"Unikalne Przedmioty",Kj:"Ustaw t\u0142o na czarne [Zwi\u0119ksza wydajno\u015b\u0107]",Lj:"Przenie\u015b przyciski GLDbot do lewego dolnego rogu?",Li:"Atakuj Cyrk Bez Leczenia",jk:"Czy pobra\u0107 z\u0142oto z paczek, je\u015bli to konieczne?",Tl:"Z\u0142oto zosta\u0142o pobrane z paczek do treningu",Ad:"Nie znaleziono z\u0142ota w paczkach do treningu",gk:"Naprawione Przedmioty",$j:"Ataki na Arenie",bk:"Ataki w Cyrku",zd:"Zresetowane Przedmioty",ek:"Ataki na Wyprawach",
dk:"Ataki w Lochach",hk:"Ataki w Podziemiach",ak:"Pieni\u0105dze Zarobione na Arenie",ck:"Pieni\u0105dze Zarobione w Cyrku",Rl:"Przedmioty Przetopione",fk:"Przetopione Z\u0142oto",Yi:"Bitwa Gildii",$i:"Ustawienia Gildii",ll:"B\u0119dzie atakowa\u0107 gildie losowo.",Zi:"Nazwa Gildii",Ji:"Zresetuj Statystyki",Xi:"Atakuj losowo?",wl:"GLDbot: U\u017cyj kostek, aby od\u015bwie\u017cy\u0107 tajemnicze pude\u0142ko i znale\u017a\u0107 cenne przedmioty przed ich otwarciem (itp. Kostiumy). Kliknij \u201eStart\u201d otw\u00f3rz skrzynie.",
Kc:"Drewno",Ac:"Mied\u017a",Ec:"\u017belazo",Gc:"Sk\u00f3ra",Lc:"We\u0142niana nitka",Bc:"Bawe\u0142na",Dc:"Konopie",Cc:"Kawa\u0142ek tkaniny",Hc:"Kawa\u0142ek w\u0142\u00f3kna lnianego",Fc:"\u0141ata z juty",Jc:"Pasek aksamitu",Ic:"Jedwabna nitka",Tc:"Futro",Nc:"Od\u0142amek ko\u015bci",Wc:"\u0141uska",Qc:"Pazur",Sc:"Kie\u0142",Rc:"Smocza \u0142uska",Oc:"R\u00f3g byka",Vc:"Gruczo\u0142 jadowy",Pc:"Kawa\u0142ek futra Cerbera",Uc:"\u0141uska Hydry",Xc:"Pi\u00f3ro Sfinksa",Yc:"Sk\u00f3ra Tyfona",wc:"Lazuryt",
qc:"Ametyst",pc:"Bursztyn",rc:"Akwamaryn",xc:"Szafir",uc:"Granat",tc:"Szmaragd",sc:"Diament",vc:"Jaspis",yc:"Sugilit",kc:"Jad skorpiona",nc:"Eliksir wytrwa\u0142o\u015bci",fc:"Antidotum",ec:"Adrenalina",mc:"Eliksir o\u015bwiecenia",jc:"Nap\u00f3j postrzegania",hc:"Esencja refleksu",ic:"Fiolka Charyzmy",oc:"Woda zapomnienia",lc:"Esencja duszy",xd:"Wodna piecz\u0119\u0107",rd:"Runa ochrony",pd:"Ziemny grawerunek",wd:"\u015awi\u0119ty totem",vd:"Talizman mocy",td:"Kamie\u0144 szcz\u0119\u015bcia",qd:"Krzemie\u0144",
ud:"Runa wichury",sd:"Runa cienia",cd:"Kryszta\u0142",bd:"Br\u0105z",gd:"Obsydian",kd:"Srebro",ld:"Siarka",ed:"Ruda z\u0142ota",jd:"Kwarc",hd:"Platina",ad:"Almandyn",dd:"Kupryt",fd:"Piekielny kamie\u0144",Fi:"Atakuj losowo?",Gi:'Wy\u0142\u0105cz r\u00f3wnie\u017c ustawienie "Sortuj graczy na arenie wed\u0142ug poziomu" w crazy-addon.',Ug:"Akceptuj tylko misje na podstawie typu boga.",Va:"Automatyczny Buff",Xd:"U\u017cywaj tylko w piekle?",Ag:"Nowa Zasada",yg:"Nazwa Zawiera",isUnderworldItem:"Czy to przedmiot z Podziemi",
df:"Ignoruj Materia\u0142y",rk:"U\u017cyj modlitwy",Ai:"U\u017cyj ofiary",mk:"U\u017cyj tkaniny, aby wej\u015b\u0107 do podziemia",ri:"Czy w podziemiach akceptowa\u0107 tylko zadania zwi\u0105zane z podziemiami?",pi:"Je\u015bli w\u0142\u0105czone, musisz wprowadzi\u0107 nazwy przedmiot\u00f3w z podziemi. Je\u015bli bot znajdzie te przedmioty w podziemiach, zaakceptuje zadanie.",Yk:"Przedmiot zadania z podziemi",il:"Wprowad\u017a nazw\u0119 materia\u0142u",Bk:"Bot uwielbia ko\u015bci! Pomagaj\u0105 znale\u017a\u0107 ubrania w skrzyniach. Ale je\u015bli nie ma ko\u015bci, bot i tak otwiera skrzynie, licz\u0105c na fajne ciuchy (ale mo\u017ce ich nie znale\u017a\u0107!)",
Nj:"Czy chcesz przetopi\u0107 skrzynki?",le:"W\u0142\u0105cz automatyczne ataki na arenie?",Mg:"Priorytetowa lista aren?",Ng:"Priorytetowa lista cyrk\u00f3w?",de:"Wy\u0142\u0105cz menu dziennika",ih:"Minimalna warto\u015b\u0107 nagrody z\u0142ota",Vg:"Je\u015bli w\u0142\u0105czone, Fokus na zadaniach b\u0119dzie pod\u0105\u017ca\u0142 najkr\u00f3tsz\u0105 drog\u0105 do uko\u0144czenia lochu.",Hh:"Automatyczne rzucanie kostk\u0105?",Ih:"U\u017cywaj rzucania kostk\u0105 ostro\u017cnie, b\u0119dzie ono nadal u\u017cywa\u0107 pierwszej kostki, dop\u00f3ki nie wy\u0142\u0105czysz opcji.",
nh:"Post\u0119p w wyszukiwaniu",bh:"Czas odnowienia naprawy domy\u015blnie wynosi 10 minut.",vg:"Minimalny stan",be:"Obecny przedmiot na warsztacie [Wyczy\u015b\u0107, je\u015bli bot nagle zostanie zatrzymany]",Af:"Pomy\u015blnie przechowywano zasoby do horreum.",wf:"Sprawdzanie rynku na przedmioty...",yb:"Przedmiot przeniesiony na warsztat.",Nf:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony i za\u0142o\u017cony.",Of:"Przedmiot zosta\u0142 pomy\u015blnie naprawiony.",Lk:"Naprawa nie powiod\u0142a si\u0119. Strona zostanie od\u015bwie\u017cona.",
Kf:"Podnoszenie materia\u0142\u00f3w...",Xf:"Oczekiwanie na napraw\u0119...",Mf:"Naprawa rozpocz\u0119\u0142a si\u0119 dla .",va:"Naprawa: Przenoszenie przedmiotu z inwentarza do torby",Lf:"Naprawa: Przenoszenie przedmiotu z warsztatu do paczki.",ta:"Nie uda\u0142o si\u0119 znale\u017a\u0107 wystarczaj\u0105cej ilo\u015bci materia\u0142\u00f3w. Wy\u0142\u0105czanie slotu naprawy ",Hf:"Szukanie przedmiot\u00f3w do kupienia w celu ukrycia z\u0142ota na Aukcji...",tf:"Sprawdzanie wygas\u0142ych przedmiot\u00f3w w paczkach...",
uf:"Przedmiot zosta\u0142 pomy\u015blnie zresetowany.",vf:"Brak pustej przestrzeni lub z\u0142ota do zresetowania.",Bf:"Upewnij si\u0119, \u017ce masz prawa do sprzeda\u017cy na rynku gildii!",sb:"Brak wystarczaj\u0105cej ilo\u015bci z\u0142ota/lub brak przedmiotu do kupienia. Oczekiwanie 30 sekund na od\u015bwie\u017cenie.",ub:"Sklep zosta\u0142 od\u015bwie\u017cony.",vb:"B\u0142\u0105d podczas leczenia.",Ef:"Brak Rubina lub Materia\u0142u, wy\u0142\u0105czanie opcji.",Kk:"Brak przedmiotu do leczenia w paczkach.",
wb:"Nie znaleziono odpowiednich przedmiot\u00f3w",Ff:"\u017bywno\u015b\u0107 zosta\u0142a wybrana. Zako\u0144czenie procesu.",Gf:"Wybrano przynajmniej jedzenie. Proces zako\u0144czony.",xb:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",Cf:"Pobieranie jedzenia z paczek.",Df:"Nie znaleziono odpowiedniej przestrzeni w torbie, aby zebra\u0107 jedzenie.",tb:"Brak wi\u0119cej przedmiot\u00f3w do leczenia. Oczekiwanie 30 sekund.",rb:"Odzyskano punkty \u017cycia.",ua:"Nie ma nic do roboty, wi\u0119c id\u0119 si\u0119 pomodli\u0107!",
Tf:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie i Vill\u0119 Medici.",Uf:"Oczekiwanie na Vill\u0119 Medici, od\u015bwie\u017canie za 60 sekund.",Vf:"Opuszczono za\u015bwiaty.",Wf:"Zamierzam od\u015bwie\u017cy\u0107 za 60 sekund, aby sprawdzi\u0107 moje zdrowie.",If:"Sprawdzanie olejk\u00f3w bo\u017cych...",Jf:"Olejki bo\u017ce zosta\u0142y podniesione.",ra:"Pomy\u015blnie zaatakowano gracza na ARENIE: ",sa:"Pomy\u015blnie zaatakowano gracza w CIRKUSIE: ",rf:"Sprawdzanie aukcji! Prosz\u0119 czeka\u0107...",
sf:"Licytacja przedmiot\u00f3w. Prosz\u0119 czeka\u0107...",Pf:"Automatycznie przetopiony przedmiot: ",Qf:"Przetapiany przedmiot: ",Rf:"Nie ma wystarczaj\u0105cej ilo\u015bci z\u0142ota do przetopienia. Wymagane z\u0142oto: ",Sf:"PRZETAP: Szukanie przedmiot\u00f3w do przetopienia...",Mk:"Szukanie przedmiot\u00f3w do przetopienia...",xf:"Sprawdzanie dost\u0119pno\u015bci kostium\u00f3w...",zf:"Wys\u0142ano datek: ",yf:"Rzucanie kostk\u0105...",Re:"Underworld Farm [Manual, Beta]",Qe:"Farm Location",
Se:"Uwaga: w\u0142\u0105cz t\u0119 funkcj\u0119 po odblokowaniu stworzenia, kt\u00f3re chcesz zaatakowa\u0107, nie b\u0119dzie ono automatycznie atakowa\u0107, aby odblokowa\u0107 potwora.",Pe:"Farm Enemy",Qd:"Automatyczne Logowanie",Rd:"Musisz zezwoli\u0107 na wyskakuj\u0105ce okienka z ekranu lobby GameForge. Zobacz dokumentacj\u0119, jak to zrobi\u0107.",Ig:"Wstrzymaj Bota",Jg:"Wstrzymaj Bota na (Minuty)",Ne:"Data Wyga\u015bni\u0119cia",Dg:"Tylko kupowa\u0107 jedzenie?",Eg:"Je\u015bli to w\u0142\u0105czysz, zignoruje twoje wybory i b\u0119dzie automatycznie kupowa\u0107 jedzenie, nie wprowadzaj\u0105c niczego.",
Gb:"Maksymalna \u0142\u0105czna ilo\u015b\u0107 z\u0142ota do wydania",Fb:"Maksymalna ilo\u015b\u0107 z\u0142ota na jedzenie do wydania",Cg:"Bot b\u0119dzie sprawdza\u0107 oleje co 60 minut",$h:"Ustawia timer do sprawdzania czas\u00f3w topienia.",Xh:"Ustawia timer do sprawdzania topienia, gdy nie masz z\u0142ota.",Zh:"Ustawia timer do sprawdzania topienia, gdy nie masz dost\u0119pnego przedmiotu.",Sh:"Ustawia timer do naprawy i sprawdzania twoich przedmiot\u00f3w.",Rh:"Ustawia timer do sprawdzania ilo\u015bci z\u0142ota w gildijnym rynku.",
Nh:"Ustawia timer dla opcji zatrzymania z\u0142ota na aukcji.",Jh:"Ustawia timer do sprawdzania listy PvP na arenie do ataku.",Oh:"Ustawia timer do sprawdzania listy PvP w cyrku do ataku.",fi:"Ustawia timer treningowy do trenowania statystyk.",Uh:"Ustawia timer do resetowania wygas\u0142ych przedmiot\u00f3w.",di:"Ustawia timer do przechowywania materia\u0142\u00f3w do kucia w horreum.",Lh:"Ustawia timer do sprawdzania aukcji gladiator\u00f3w i najemnik\u00f3w.",Wh:"Ustawia timer do wyszukiwania przedmiot\u00f3w na aukcji i w sklepie.",
Ph:"Ustawia timer do wysy\u0142ania darowizn do gildii.",We:"Z\u0142oto Przeniesione",ie:"Nie sprzedawaj przedmiot\u00f3w z listy hutniczej i aukcyjnej",oh:"Automatyzacja Sklepu",qh:"Ustawienia Wyszukiwania Przedmiotu",ph:"U\u017cyj tego narz\u0119dzia do wyszukiwania przedmiot\u00f3w. Po prostu dodaj przedmioty do listy, okre\u015bl ilo\u015b\u0107 tkaniny i rozpocznij wyszukiwanie.",rh:"Ilo\u015b\u0107 Tkaniny do U\u017cycia:",th:"Ile tkaniny u\u017cy\u0107?",ea:"Full Wprowad\u017a Nazw\u0119 Przedmiotu",
Sb:"Wprowad\u017a Poziom Przedmiotu",vh:"Jako\u015b\u0107 Przedmiotu",uh:"Wprowad\u017a Nazw\u0119 Przedmiotu Tutaj",wh:"Rozpocznij Wyszukiwanie",xh:"Pomi\u0144 i Kontynuuj",yh:"Zatrzymaj Wyszukiwanie",Te:"Kupi\u0107 najta\u0144sze czy najdro\u017csze?",xg:"Najdro\u017csze",Zd:"Najta\u0144sze",ba:"Wybierz Opcj\u0119",ne:"Pod\u015bwietl przedmioty z Podziemia",Ue:"Skoncentruj si\u0119 na zadaniu?",Vl:"U\u017cyj rubinu, je\u015bli nie ma tkaniny?",Wa:"Unikaj atakowania tych samych os\u00f3b, aby unikn\u0105\u0107 zg\u0142osze\u0144. Zg\u0142oszenia zwi\u0119kszaj\u0105 szans\u0119 na zablokowanie konta.",
Kl:"Roztopi\u0107 zielone?",Pg:"Nie akceptuj losowych zada\u0144, je\u015bli wprowadzono jakiekolwiek filtry?",Mc:"Maksymalna jako\u015b\u0107 materia\u0142u do u\u017cycia",Ui:"W\u0142\u0105czy\u0107 wyszukiwanie najemnik\u00f3w",sl:"Kliknij \u201eSprzedaj Wszystkie Wybrane\u201d, aby sprzeda\u0107 wszystkie przedmioty. Upewnij si\u0119, \u017ce masz 2x3 puste miejsce w swojej pierwszej (1) torbie. Aby zbiera\u0107 z\u0142oto masowo, u\u017cyj filtra na z\u0142oto i opcji \u201eWybierz Wybrane lub Wybierz Wszystkie\u201d.",
Zj:"\ud83d\udd25 : Dodaje przedmiot do listy przetapiania.",Hi:"\ud83d\udd28 : Dodaje przedmiot do listy aukcyjnej.",Ej:"Od\u015bwie\u017c sklep tkanin\u0105, gdy jest pe\u0142ny",sj:"Strona:",zj:"Zatrzymaj",xj:"Sprzedaj T\u0119 Stron\u0119",uj:"Wybierz Wybrane",tj:"Wybierz Wszystko",Aj:"Ustawienia Automatycznego Pakowania",yj:"Wy\u015blij Zasoby",vj:"Sprzedaj Wszystkie Wybrane",ma:"Rodzaj Przedmiotu",oa:"Bronie",S:"Tarcze",M:"Zbroje",P:"He\u0142my",O:"R\u0119kawice",N:"Buty",na:"Pier\u015bcienie",
ka:"Amulety",Ia:"U\u017cytkowe (\u017bywno\u015b\u0107)",Na:"Ulepszenia",rj:"Wzmacniacze",Ka:"Receptury",Ja:"Najemnicy",Ma:"Narz\u0119dzia Kowalskie",La:"Zwoje",od:"Wzmocnienia",md:"Przedmioty Eventowe",nd:"Materia\u0142y Kowalskie",zl:"Z\u0142oto",Ha:"Wszystko",Al:"Jako\u015b\u0107",pa:"Bia\u0142y",C:"Zielony",B:"Niebieski",D:"Fioletowy",H:"Pomara\u0144czowy",R:"Czerwony",wj:"Opcje Sprzeda\u017cy",Mj:"Ignorowa\u0107 Kombinacje Przedrostk\u00f3w/Sufiks\u00f3w?",aj:"Ile jedzenia kupi\u0107/wybiera\u0107?",
Pi:"Normalny",Oi:"\u015aredni",Ni:"Trudny",Ea:"Standardowy",Dl:"Naprawa Utkni\u0119\u0107",Ik:"Wy\u0142\u0105cz Wej\u015bcie do Piek\u0142a, je\u015bli chcesz wy\u0142\u0105czy\u0107 Lochy/Cyrk/Aren\u0119. Je\u015bli wszed\u0142e\u015b do Piek\u0142a r\u0119cznie, musisz w\u0142\u0105czy\u0107 Tryb Piek\u0142a.",ii:"Okre\u015bl, ile razy chcesz przeprowadzi\u0107 szkolenia dla statystyk oraz ich priorytety. Bot nie b\u0119dzie przeprowadza\u0142 szkole\u0144, dop\u00f3ki nie zostanie ustalony priorytet. Je\u015bli priorytet zosta\u0142 ustawiony, ale nie ma ju\u017c wi\u0119cej statystyk do szkolenia, bot kontynuowa\u0107 b\u0119dzie z priorytetowym szkoleniem.",
el:"Quest",$d:"Wybierz kostium z Za\u015bwiat\u00f3w",Di:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",Il:"Przetapianie",Ol:"Ustawienia Topienia",Wj:"Topione Przedmioty",Pl:"Dodaj Prefiks lub Sufiks, gdy bot znajdzie go w paczkach, automatycznie przeprowadzi przetapianie.:",Nl:"Topiony Przedmiot:",bc:"Kliknij na przedmiot, kt\u00f3ry chcesz naprawi\u0107. Ten system naprawi twoje dwie postacie, g\u0142\u00f3wn\u0105 oraz pierwsz\u0105 posta\u0107 cyrku. Musisz mie\u0107 co najmniej 10000 z\u0142ota, aby naprawa mog\u0142a si\u0119 rozpocz\u0105\u0107. Je\u015bli utkn\u0105\u0142 na jednym przedmiocie, oznacza to, \u017ce nie masz materia\u0142u do naprawy. Spr\u00f3buj r\u00f3wnie\u017c zrobi\u0107 troch\u0119 miejsca w swoim inwentarzu. Bot rozpocznie napraw\u0119, gdy trwa\u0142o\u015b\u0107 przedmiotu wynosi 0%.",
Zk:"Zastosuj tylko do Najemnik\u00f3w",bl:"Licytacja b\u0119dzie licytowa\u0107 tylko wtedy, gdy rynek zbli\u017cy si\u0119 do ko\u0144ca.",al:"Upewnij si\u0119, \u017ce DRUGA KARTA INWENTARZA jest pusta i masz 10 000 z\u0142ota. Bot znajdzie i umie\u015bci przedmiot na drugiej karcie, a nast\u0119pnie, gdy strona zostanie od\u015bwie\u017cona, przeprowadzi przetapianie przedmiotu. przetapianie b\u0119dzie ponownie sprawdzane co 5-10 minut.",dj:"Leczenie & Buffs",El:"Za ma\u0142o z\u0142ota na przetapianie. Wymagane Z\u0142oto:",
Hl:"Pomijanie licytacji: Cz\u0142onek gildii ju\u017c licytowa\u0142 przedmiot ",Gl:"Pomijanie licytacji: Ju\u017c licytowa\u0142e\u015b przedmiot ",advanced:"Zaawansowane",arena:"Arena",ia:"Auto Atak",$b:"Unikaj Ataku",ga:"Dodaj Gracza",ha:"Wpisz Nazw\u0119 Gracza (Same Server)",nl:"Zatrzymaj Bota, je\u015bli brakuje jedzenia?",circusTurma:"Cyrk Turma",Qi:"Trudno\u015b\u0107",dungeon:"Loch",Ri:"Ustawienia Lochu",eventExpedition:"Ekspedycja Wydarzenia",expedition:"Wyprawa",Vi:"Ustawienia Wyprawy",
Gj:"Wybierz Potwora",pl:"Najwy\u017cszy",ol:"Umie\u015b\u0107 swoje przedmioty uzdrawiaj\u0105ce na pierwszej stronie swojego inwentarza",zc:"W",Fh:"Przechowuj Z\u0142oto",Gh:"Przechowuj Z\u0142oto w Licytacji?",Qb:"Wybierz Godzin\u0119",lh:"U\u017cyj Roboczych Ubran, aby odnowi\u0107 Sklep?",Sk:"Wybierz Przedmioty do Zresetowania",eh:"Zresetuj Wygas\u0142e Przedmioty",Mb:"Uwaga: W\u0142\u0105czaj\u0105c t\u0119 opcj\u0119, bot b\u0119dzie sprzedawa\u0142 nadchodz\u0105ce wygas\u0142e przedmioty z Paczek na Rynek Gildii, a nast\u0119pnie anuluje, aby zresetowa\u0107 czas wyga\u015bni\u0119cia. Wymagana jest gildia. Upewnij si\u0119, \u017ce masz puste miejsce 3x3 w swoich torbach.",
Kg:"Losowe Zatrzymywanie Bota [Faza Testowa]:",Y:"Zachowaj Z\u0142oto: Bot b\u0119dzie trzyma\u0142 to z\u0142oto w torbie:",jg:"Max Gold: Bot b\u0119dzie wydawa\u0142, gdy z\u0142oto b\u0119dzie wi\u0119ksze ni\u017c",jh:"Bot b\u0119dzie sk\u0142ada\u0142 oferty na losowe przedmioty.",Bd:"Dodaj Losowe Op\u00f3\u017anienie",Cd:"Mo\u017cesz tutaj doda\u0107 op\u00f3\u017anienie do bota.",Lb:"Naprawa",Jl:"Top Tylko Niebieskie?",Ml:"Top Tylko Fioletowe?",Ll:"Top Tylko Pomara\u0144czowe?",Xj:"Top Wszystko na 2. karcie?",
Yj:"To zignoruje wyb\u00f3r kolor\u00f3w",Xa:"Wyczy\u015b\u0107 Histori\u0119",Ah:"Przetapianie",Kd:"Search",zg:"Auto Licytacja",Ld:"Nadmierne korzystanie z aukcji mo\u017ce skutkowa\u0107 banem. Zaleca si\u0119 wy\u0142\u0105czenie innych funkcji okre\u015blania stawek, aby unikn\u0105\u0107 potencjalnych konflikt\u00f3w. Ta funkcja spowolni bota.",kh:"Szukaj w Licytacji Gladiator\u00f3w",mh:"Szukaj w Licytacji Najemnik\u00f3w",Td:"Licytuj Po\u017cywienie?",kg:"Maksymalna Licytacja",Ud:"Licytuj, je\u015bli status jest mniejszy ni\u017c",
Vd:"Wystawione Przedmioty",wk:"J\u0119zyk Licytacji",xk:"Zgodnie z aktualizacj\u0105 2.9.4, prosz\u0119 ponownie ustawi\u0107 j\u0119zyk lub ZRESETOWA\u0106 BOTA. Upewnij si\u0119, \u017ce wszystko jest poprawne, w przeciwnym razie bot nie b\u0119dzie licytowa\u0107.",Fd:"Mo\u017cesz doda\u0107 przedmioty do wyszukiwania na rynku i w licytacji. Poka\u017ce tak\u017ce fioletowe przedmioty na rynku, gdy dodasz przedmiot do listy. Je\u015bli chcesz w\u0142\u0105czy\u0107 auto licytacj\u0119, u\u017cyj opcji poni\u017cej",
uk:"U\u017cywaj licytacji z rozwag\u0105!",vk:"Automatyczna licytacja generuje zbyt wiele \u017c\u0105da\u0144 do serwera i mo\u017ce spowodowa\u0107 ban, je\u015bli u\u017cywasz jej ca\u0142y czas!",ah:"Odnowi\u0107 Punkty Wydarzenia Rubinem?",pe:"W\u0142\u0105cz Auto Olej",zk:"Auto Pobieraj \u015awi\u0119te Oleje",Ok:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Sa:"Atakowa\u0107 Cz\u0142onk\u00f3w Gildii?",Qa:'Automatycznie dodawaj osoby do listy "Atak", gdy wi\u0119cej ni\u017c X z\u0142ota zostanie skradzione.:',
Ra:'Automatycznie dodawaj osoby do listy "Unikaj Atak", gdy przegrasz z nimi.:',Pb:"Ataki na Tablicy Wynik\u00f3w",Xb:"Bardzo D\u0142ugo",zb:"D\u0142ugo",Hb:"\u015arednio",Ub:"Kr\u00f3tko",Yb:"Bardzo Kr\u00f3tko",qe:"Wejd\u017a do Podziemia je\u015bli HP >",Wg:"Szybko\u015b\u0107 Sprawdzania Zada\u0144",Og:'Domy\u015blnie to "3x". Je\u015bli bot sprawia problemy z zadaniami, zmie\u0144 szybko\u015b\u0107 zada\u0144 zgodnie ze szybko\u015bci\u0105 serwera.',Xe:"Wyb\u00f3r Worka z Lecznicami",re:'Je\u015bli r\u0119cznie odnawiasz punkty, musisz klikn\u0105\u0107 przycisk powy\u017cej: "Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!"',
Dk:"Musisz w\u0142\u0105czy\u0107 co najmniej jedn\u0105 z opcji: ekspedycja, loch, arena lub cyrk, aby rozpocz\u0105\u0107 Ekspedycj\u0119 Eventow\u0105.",Yg:"Od\u015bwie\u017c Ekspedycj\u0119 Eventow\u0105, je\u015bli utkn\u0119\u0142o!",kb:"Nie przebijaj gildii?",Vk:"Pozostaw wszystkie ustawienia wy\u0142\u0105czone, je\u015bli chcesz przetapia\u0107 za pomoc\u0105 paczek zawieraj\u0105cych przedmioty z listy. Jednak nadal mo\u017cesz wybiera\u0107 kolory.",Ak:"Posta\u0107(Wy\u0142\u0105czona) / Najemnik(W\u0142\u0105czony)",
Rk:"Naprawi\u0107 Obie?",Wk:"Timery",Timers:"Wprowad\u017a liczb\u0119 minut dla ka\u017cdego timera poni\u017cej lub pozostaw domy\u015blnie.",Tg:"Ignoruj Filtr Zada\u0144",Sg:"Wprowad\u017a s\u0142owa kluczowe, aby odfiltrowa\u0107 zadania, kt\u00f3rych nie chcesz przyj\u0105\u0107. You can also use this to accept quests by their reward using keywords.",V:"Wprowad\u017a S\u0142owo Kluczowe",I:"Dodaj",$g:"Usu\u0144",ae:"Wyczy\u015b\u0107",Qg:"Akceptuj Filtr Zada\u0144",Rg:"Wprowad\u017a s\u0142owa kluczowe, aby wybra\u0107 zadania do przyj\u0119cia. U\u017cycie tego spowoduje ignorowanie rodzaj\u00f3w zada\u0144",
Ca:"Pomi\u0144 Zadania Czasowe?",Pk:"Zadania",Nd:"Automatyczny Kostium",xi:"U\u017cywa\u0107 Kostiumu?",Sd:"Podstawowa Bitwa",je:"Bitwa w Lochach",Od:"Bot b\u0119dzie nosi\u0142 Dis Pater Normal i Medium tylko wtedy, gdy Twoje punkty ekspedycji/podziemi wynosz\u0105 0.",Ze:"Ustawienia Piekielnego Leczenia",Ed:"Atakuj Bossa, Gdy Dost\u0119pny?",qb:"Atak na Lig\u0119 zostanie wy\u0142\u0105czony po 5 nieudanych atakach.",bf:"\u015awi\u0119te Oleje",ug:"Nazwa Przedmiotu",Z:"Minimalny Poziom Przedmiotu",
Aa:"Minimalna Jako\u015b\u0107 Przedmiotu",Dd:"Zastosuj/Resetuj Licznik",ef:"Ignoruj Prefiks/Sufiks",Ei:"Tak",Bg:"Nie",Oa:"Dodaj Prefiks",Pa:"Dodaj Sufiks",Bh:"Lista Ignorowanych Przedmiot\u00f3w do Topienia",Ib:"Prefiks",Vb:"Sufiks",gh:"Resetuj Wygas\u0142e Przedmioty",Ch:"Losowe Topienie z Paczek?",Dh:"Karta Topienia",ob:"Dodatki",Id:"Aukcja",cg:"Rynek",Wb:"Zegary",bi:"Topienie",ai:"Topienie, je\u015bli brakuje z\u0142ota",Yh:"Topienie, je\u015bli brakuje przedmiotu",Da:"Naprawa",Qh:"Przechowuj Z\u0142oto na Rynku Gildii",
Mh:"Przechowuj Z\u0142oto na Aukcji",ei:"Trening",Th:"Resetuj Wygas\u0142e",ci:"Przechowuj W Ku\u017ani",Kh:"Sprawd\u017a Aukcj\u0119",Vh:"Szukaj",v:"W\u0142\u0105cz",wg:"Minimalne Z\u0142oto",lb:"Wp\u0142acaj Z\u0142oto do Gildii",ee:"B\u0119dzie wp\u0142aca\u0107 co 5 minut. Mo\u017cesz zmieni\u0107 interwa\u0142 w zak\u0142adce zegar\u00f3w",cf:"Ile chcesz wp\u0142aci\u0107?",fe:"Wp\u0142aca\u0107, gdy masz wi\u0119cej ni\u017c >",qf:"Mniej ni\u017c <",dh:"Resetuj Wygas\u0142e i Inne Ustawienia",
fh:"Reset za:",Jk:"Naci\u015bnij Ctrl (Cmd na Macu), aby zaznaczy\u0107 wiele przedmiot\u00f3w",ff:"Importuj/Eksportuj Ustawienia",Oe:"Eksportuj Ustawienia",gf:"Importuj Ustawienia",ng:"Wiadomo\u015b\u0107 do Wszystkich Graczy",og:"[Wymaga Klucza Ultra Premium, wiadomo\u015b\u0107 na Discordzie, aby go otrzyma\u0107.]",pg:"Wprowad\u017a wiadomo\u015b\u0107 do wys\u0142ania",ce:"Aby uzyska\u0107 niestandardowe skrypty, skontaktuj si\u0119 z nami na Discordzie",rg:"Wy\u015blij",sg:"Poka\u017c Graczy",
qg:"Zaznacz Wszystkie",tg:"Odznacz Wszystkie",pf:"Upewnij si\u0119, \u017ce tw\u00f3j inwentarz ma wystarczaj\u0105co du\u017co miejsca. Czas odnowienia wynosi 2 minuty.",nb:"W\u0142\u0105cz Atak na Tablicy Wynik\u00f3w:",Nb:"Wybierz Zakres Ataku",Ob:"Bot losowo atakuje z listy tablicy wynik\u00f3w.",pb:"Atak Ligi",mb:"W\u0142\u0105cz Atak Ligi:",Jb:"Losowo Atakuj",Kb:"Atakuj od najs\u0142abszego do najsilniejszego",tk:"Domy\u015blnie bot unika atakowania cz\u0142onk\u00f3w gildii.",Me:"Lokalizacja Wyprawy:",
Md:"Auto Zbieraj Bonusy:",zh:"Pomi\u0144 Bossa",ke:"Lokalizacja Lochu:",hh:"Zresetowa\u0107, je\u015bli przegrasz?",$e:"Ustawienia Piek\u0142a",af:"Skonfiguruj ustawienia procentu leczenia w zak\u0142adce leczenia i upewnij si\u0119, \u017ce zak\u0142adka leczenia jest aktywowana. Je\u015bli wej\u015bcie do podziemi wyrzuca ci\u0119 z gry, przejd\u017a do lobby i zaznacz pole wyboru automatycznego logowania.",Ye:"Trudno\u015b\u0107 Piek\u0142a",Pd:"Auto Wej\u015bcie do Piek\u0142a: / Piek\u0142a Mode",
yi:"U\u017cyj Mobilizacji, je\u015bli punkty = 0",Ci:"U\u017cyj rubin\u00f3w?",se:"Wyj\u015b\u0107 z podziemi, je\u015bli nie ma punkt\u00f3w?",ki:"Bot b\u0119dzie pr\u00f3bowa\u0142 u\u017cy\u0107 willi medici najpierw, je\u015bli jej nie masz, u\u017cyje mikstury uzdrawiania. Nie zapomnij w\u0142\u0105czy\u0107 prze\u0142\u0105cznika uzdrawiania.",ti:"Automatyczne wej\u015bcie do piek\u0142a wy\u0142\u0105czy loch/aren\u0119/cyrk po wej\u015bciu do piek\u0142a.",Xk:"Ustawienia Leczenia Piek\u0142a",
Bi:"U\u017cyj Willi Medici?",zi:"U\u017cyj Mikstury Uzdrawiania?",Yf:"INFORMACJA: Bot b\u0119dzie wyszukiwa\u0142 przedmioty na rynku co wybran\u0105 liczb\u0119 minut, co mo\u017ce spowodowa\u0107 zatrzymanie atakowania podczas wyszukiwania.",oe:"W\u0142\u0105cz Wyszukiwanie na Rynku:",Zf:"Interwa\u0142 Wyszukiwania na Rynku w Minutach:",$f:"Sugerowane 10 minut.",kf:"Ustawienia Przedmiotu:",hf:"Nazwa Przedmiotu Zawiera",G:"Maksymalna Cena",lf:"Rodzaj Przedmiotu",jf:"Rzadko\u015b\u0107 Przedmiotu",
Yd:"Kup Przedmiot Uwi\u0105zany?",nf:"Przedmioty do Kupienia",mf:"Pr\u00f3buj kupowa\u0107 przedmioty z paczek, je\u015bli kt\u00f3rykolwiek z nich pasuje do maksymalnej ceny wprowadzonej.:",Wd:"Zakupione Przedmioty:",bj:"Procent Leczenia",pk:"Kupuj Jedzenie ze Sklepu?",qk:"U\u017cyj Leczenia z Paczki?",lk:"U\u017cyj Cervisia?",nk:"U\u017cyj Jajka?",tl:"Ostatnio U\u017cyty",location:"Lokalizacja",Strength:"Si\u0142a",Dexterity:"W\u0142adanie broni\u0105",Agility:"Zr\u0119czno\u015b\u0107",Constitution:"Budowa fizyczna",
Charisma:"Charyzma",Intelligence:"Inteligencja",gi:"Ustawienia Treningu",hi:"Wybierz atrybuty, kt\u00f3re chcesz trenowa\u0107. Bot przeprowadzi trening, gdy b\u0119dziesz mia\u0142 wystarczaj\u0105co du\u017co z\u0142ota.",$c:"Nast\u0119pna akcja",oj:"Nie",pj:"Normalnie",xl:"Przeciwnik",yl:"Poziom Przeciwnika",Dj:"Zadania",random:"Losowo",Fl:"Ustawienia",Ql:"Wkr\u00f3tce...",type:"Kliknij na ikony, aby aktywowa\u0107 rodzaje zada\u0144.",Xl:"Tak",A:"Licytacja/Szukaj",yd:"Dodaj przedmioty",ik:"Automatycznie Przechowuj Zasoby W\u0142asne",
Sl:"Zatwierd\u017a",rl:"Interwa\u0142 : ",gl:"W\u0142\u0105cz Automatyczn\u0105 Licytacj\u0119",hl:"Nie licytuj, je\u015bli cz\u0142onek gildii ju\u017c licytowa\u0142",Ul:"Samouczek",ac:"Wybierz przyciski powy\u017cej, aby wybra\u0107, czy chcesz stawi\u0107 czo\u0142a najni\u017cszemu przeciwnikowi na arenie, czy przeciwnikowi najwy\u017cszego poziomu. Wi\u0119cej u\u017cytkownik\u00f3w spowolni dzia\u0142anie bota.",$k:'Aby rozpocz\u0105\u0107, dodaj przedmiot do listy (np. "Lucius"). Po dodaniu narz\u0119dzie b\u0119dzie szuka\u0107 przedmiotu i wy\u015bwietla\u0107 wyniki wyszukiwania po lewej stronie ekranu. B\u0119dzie r\u00f3wnie\u017c szuka\u0107 przedmiotu w celu automatycznej licytacji. Je\u015bli w\u0142\u0105czysz automatyczn\u0105 licytacj\u0119, narz\u0119dzie b\u0119dzie regularnie szuka\u0107 przedmiotu w okre\u015blonych odst\u0119pach czasu, zgodnie z liczb\u0105 wpisan\u0105 w polu interwa\u0142u. Je\u015bli narz\u0119dzie znajdzie przedmiot i b\u0119dziesz mie\u0107 wystarczaj\u0105co du\u017co pieni\u0119dzy, automatycznie z\u0142o\u017cy za ciebie licytacj\u0119. *Uwaga* aby szuka\u0107 unikalnych przedmiot\u00f3w w sklepach, musisz doda\u0107 przynajmniej 1 losowy przedmiot do listy wyszukiwania.',
jl:"Numer potwora mo\u017cna wybra\u0107 z przycisk\u00f3w powy\u017cej. Numer 1 reprezentuje potwora najbardziej na lewo. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",Si:"Wybierz trudno\u015b\u0107 lochu z powy\u017cszych opcji. Upewnij si\u0119, \u017ce wybierasz w\u0142a\u015bciw\u0105 lokalizacj\u0119, inaczej bot mo\u017ce si\u0119 zatrzyma\u0107.",cj:"Ustawienia Leczenia",Ti:"Przechowuj nadmiar z\u0142ota w Gildii, kupuj\u0105c przedmioty z rynku gildii. -> Min. Z\u0142oto",
ul:"Przenie\u015b Wszystko",vl:"Przenie\u015b Wybrane",cl:"Auto Uzdrawianie",dl:"Procent Auto Uzdrawiania",Wl:"Ruby",Fg:"Og\u00f3lne Ustawienia",Hj:"Sprzedaj Wszystko",Ij:"Sprzedaj Wybrane",fa:"Bronie",ca:"Tarcze",U:"Zbroje Piersiowe",X:"He\u0142my",W:"R\u0119kawice",da:"Buty",aa:"Pier\u015bcienie",T:"Amulety",wi:"U\u017cywalne",vi:"Ulepszenia",Xg:"Receptury",mg:"Zwoje Najemnik\u00f3w",Zg:"Wzmocnienia",gg:"Sprzedaj \u017bywno\u015b\u0107",Db:"Prze\u0142\u0105cz na \u017bywno\u015b\u0107"},Kh={Fk:"\u00a1Tus configuraciones de expedici\u00f3n son incorrectas o hay datos de p\u00e1gina inesperados!",
Gk:"\u00a1Tu configuraci\u00f3n de expedici\u00f3n es incorrecta! Has establecido un monstruo deshabilitado, lo cual est\u00e1 mal.",Ba:"Prioridad",Rb:"Establecer Prioridad",Lg:"Puntos",Eh:"Stat",Mi:"Recolectar Oro",Jj:"Vender en el Inframundo?",nj:"El bot buscar\u00e1 el nido en cada acci\u00f3n, no solo en expediciones.",lj:"Tipo de b\u00fasqueda de nido",jj:"No hacer nada",kj:"B\u00fasqueda r\u00e1pida",mj:"B\u00fasqueda exhaustiva",Bj:"After expedition points are consumed, travel to Germania to consume Dungeon points",
sk:"Haz clic aqu\u00ed si la reparaci\u00f3n se atasca",Hk:"Cuando los HP est\u00e9n bajos, usa curar",Hg:"Reparaci\u00f3n Parcial",Ve:"Reparaci\u00f3n Completa",Gg:"Reparaci\u00f3n Parcial o Completa",me:"Habilitar L\u00edmite",ej:"L\u00edmite",fj:"Si deseas limitar el n\u00famero de veces que quieres atacar al enemigo, habilita esta opci\u00f3n y establece el l\u00edmite. El bot continuar\u00e1 atacando al resto de los enemigos despu\u00e9s de terminar de atacar al monstruo seleccionado.",he:"No entres al inframundo con el traje del inframundo",
ge:"Si no quieres entrar al inframundo mientras llevas el traje del inframundo puesto, activa esta opci\u00f3n",si:"Inframundo",ji:"Mejoras del Inframundo",li:"\u00bfUsar los poderes de los dioses despu\u00e9s de entrar al inframundo?",mi:"Selecciona a los dioses para usar sus poderes:",ni:"\u00bfUsar Buff de Arma en el arma?",oi:"\u00bfUsar Buff de Armadura en el siguiente equipo?",Ck:"El tiempo de enfriamiento es de 30 minutos. Si no llevas un disfraz, el bot restablecer\u00e1 el tiempo de enfriamiento a 0.",
Uk:"Seleccionar Colores",Ya:"Forja de Vulcano",bb:"Escudo Terrestre de Feronia",cb:"Poder Fluido de Neptuno",eb:"Libertad A\u00e9rea de Aelous",fb:"Niebla Mortal de Plut\u00f3n",gb:"Aliento de Vida de Juno",hb:"Armadura de Escamas de las Monta\u00f1as de la Ira",ib:"Ojos de \u00c1guila",jb:"Vestidura Invernal de Saturno",Za:"Armadura de Toro de Bubona",$a:"Vestiduras de Ladr\u00f3n de Mercurio",ab:"T\u00fanica de Luz de Ra",fg:"Paquetes",ag:"Inventario",K:"Precio M\u00edn.",J:"Cantidad",Cb:"Vender Art\u00edculos",
Bb:"Buscar en",bg:"Color del Material",Ab:"Color del Art\u00edculo",ig:"Almac\u00e9n",za:"Cambiar a Materiales",Eb:"Cambiar a Art\u00edculos",hg:"Vender Materiales",wa:"Por favor, introduce un nombre de art\u00edculo v\u00e1lido, rango de precio y cantidad.",xa:"No se han encontrado art\u00edculos adecuados en las ubicaciones de b\u00fasqueda seleccionadas.",ya:"\u00a1Todos los art\u00edculos fueron listados con \u00e9xito!",Nk:"\u00a1Todos los materiales fueron listados con \u00e9xito!",dg:"Si quieres vender art\u00edculos a un precio fijo, puedes ingresar el mismo valor para el precio m\u00ednimo y m\u00e1ximo.",
eg:"Esta caracter\u00edstica todav\u00eda es experimental, \u00fasala con precauci\u00f3n. Si no pones un precio fijo, los art\u00edculos se listar\u00e1n aleatoriamente entre el precio m\u00ednimo y m\u00e1ximo que ingreses.",yk:"Establece el m\u00e1ximo de oro que el bot gastar\u00e1 por ciclo.",Ta:"El bot comenzar\u00e1 a pujar por cualquier art\u00edculo de comida, si est\u00e1 habilitado. No necesitas habilitar los interruptores de gladiador/mercenario.",Gd:"El bot no pujar\u00e1 sobre las ofertas de los aliados.",
Hd:"Ignorar la combinaci\u00f3n de Prefijo/Sufijo al buscar un art\u00edculo en la subasta.",Qj:"Selecciona los tipos de art\u00edculos que quieres fundir.",Rj:"Selecciona los colores que quieres fundir.",Sj:"Selecciona el nivel de los art\u00edculos que quieres fundir.",Tj:"Selecciona el martillo que quieres usar.",Uj:"Nota que el c\u00edrculo verde y rojo junto a la primera caja son para habilitar/deshabilitar la regla.",Vj:"Si quieres fundir aleatoriamente cualquier color o tipo, puedes habilitar `\u00bfFundir aleatoriamente si no se cumplen condiciones? (\u00daltima opci\u00f3n habilitada en el video tutorial)",
Fj:"Reparar antes de fundir?",Ie:"Seleccionar Monstruo",we:"\u00bfUsar Reloj de Arena/Rub\u00ed?",Ek:"\u00bfUsar Rub\u00ed?",ze:"\u00bfUsar Movilizaci\u00f3n?",ye:"\u00bfUsar Poci\u00f3n de Vida?",ve:"Porcentaje de Curaci\u00f3n (%)",Ge:"N\u00famero de Ataques",xe:"Intervalo de Ataque (en segundos)",te:"Ataques Realizados",ue:"Reloj de Arena Restante",Ee:"Nota: Usa pociones de vida para curar, no comida.",Fe:"Nota: Si los ataques se detienen prematuramente, intenta 'Reiniciar Ataques'.",Je:"Comenzar",
He:"Reiniciar",Ke:"Detener",Le:"Configuraci\u00f3n de Expedici\u00f3n (Clic para minimizar)",Ae:"Monstruo 1",Be:"Monstruo 2",Ce:"Monstruo 3",De:"Monstruo 4",Qk:"Reparar antes de fundir?",Ki:"Esta opci\u00f3n usar\u00e1 cervisia cuando tu premium expire.",qj:"Esta opci\u00f3n activa y selecciona aceites de las recompensas de los dioses. Puede usar los aceites n\u00famero 1 y n\u00famero 3 en el personaje, pero el n\u00famero 2 solo ser\u00e1 recogido para los paquetes.",Ii:"Esta opci\u00f3n usar\u00e1 buffs en el momento que establezcas. Encontrar\u00e1 buffs en los paquetes y los aplicar\u00e1 al personaje.",
gj:"Esta opci\u00f3n te llevar\u00e1 al inframundo. No olvides activar el Inicio de Sesi\u00f3n Autom\u00e1tico desde la pesta\u00f1a de Extras, de lo contrario podr\u00edas desconectarte al entrar al inframundo [Error del Juego]",Zb:"Normalmente, el bot elige de 3 a 6 intentos aleatorios para atacar en la lista de arena. Si activas esta opci\u00f3n, recorrer\u00e1 tu lista hasta que pueda atacar a alguien. Esto puede llevar algo de tiempo.",Cj:"Esta opci\u00f3n es solo para licencias premium. Simula el ataque antes de atacar a un usuario para un ratio de victoria del 75%.",
Jd:"No necesitas activar el interruptor principal de subastas para habilitar esta opci\u00f3n.",kk:"Esta opci\u00f3n refrescar\u00e1 la p\u00e1gina cada segundo cuando la subasta est\u00e9 en estado -Muy Corto- para ofertar constantemente y ganar la subasta.",Oj:"Si ninguna de las condiciones de fundici\u00f3n se cumple, fundir\u00e1 aleatoriamente. Aseg\u00farate de seleccionar tipo de objeto y color.",Pj:"Esta opci\u00f3n solo fundir\u00e1 art\u00edculos del inventario. Ignorar\u00e1 los art\u00edculos en los paquetes.",
Ua:"Art\u00edculos de Subasta",lg:"Art\u00edculos de Mercenario",Tb:"Art\u00edculos de la Tienda",ui:"Art\u00edculos \u00danicos",Kj:"Establecer fondo en negro [Aumenta el rendimiento]",Lj:"Mover los botones de GLDbot a la parte inferior izquierda?",Li:"Atacar al circo sin sanar",jk:"\u00bfRecoger oro de los paquetes si es necesario?",Tl:"Se ha recogido oro de los paquetes para entrenamiento",Ad:"No se ha encontrado oro en los paquetes para entrenamiento",gk:"Objetos Reparados",$j:"Ataques en la Arena",
bk:"Ataques en el Circo",zd:"Objetos Reiniciados",ek:"Ataques en Expediciones",dk:"Ataques en Mazmorras",hk:"Ataques en el Inframundo",ak:"Dinero Ganado en la Arena",ck:"Dinero Ganado en el Circo",Rl:"Objetos Fundidos",fk:"Oro Reciclado",Yi:"Batalla de Gremio",$i:"Configuraci\u00f3n del Gremio",ll:"Atacar\u00e1 gremios al azar.",Zi:"Nombre del Gremio",Xi:"Atacar Guilds Aleatoriamente",Ji:"Restablecer Estad\u00edsticas",wl:'GLDbot: usa los dados para actualizar la caja misteriosa y encontrar objetos valiosos antes de abrirla (por ejemplo, disfraces). Haz clic en "Iniciar" para abrir los cofres.',
Kc:"Madera",Ac:"Cobre",Ec:"Hierro",Gc:"Cuero",Lc:"Hilo de lana",Bc:"Bolas de algod\u00f3n",Dc:"C\u00e1\u00f1amo",Cc:"Tiras de gasa",Hc:"Lino",Fc:"Yute",Jc:"Tiras de terciopelo",Ic:"Hilo de seda",Tc:"Pelaje",Nc:"Astilla \u00f3sea",Wc:"Escama",Qc:"Garra",Sc:"Colmillo",Rc:"Escama de drag\u00f3n",Oc:"Cuerno de toro",Vc:"Gl\u00e1ndula venenosa",Pc:"Pelaje de Cerbero",Uc:"Escama de Hidra",Xc:"Pluma de Esfinge",Yc:"Piel de Tif\u00f3n",wc:"Lapisl\u00e1zuli",qc:"Amatista",pc:"\u00c1mbar",rc:"Aguamarina",xc:"Safiro",
uc:"Granate",tc:"Esmeralda",sc:"Diamante",vc:"Jaspe",yc:"Sugilita",kc:"Veneno de escorpi\u00f3n",nc:"Tintura de la resistencia",fc:"Ant\u00eddoto",ec:"Adrenalina",mc:"Tintura de la inspiraci\u00f3n",jc:"Poci\u00f3n de percepci\u00f3n",hc:"Esencia de reflejos",ic:"Frasco de carisma",oc:"Agua del olvido",lc:"Esencia de alma",xd:"Sello acu\u00e1tico",rd:"Runa protectora",pd:"Grabado terrestre",wd:"T\u00f3tem curativo",vd:"Talism\u00e1n de poder",td:"Piedra de la fortuna",qd:"Pedernal",ud:"Runa de la tormenta",
sd:"Runa de las sombras",cd:"Cristal",bd:"Bronce",gd:"Obsidiana",kd:"Plata",ld:"Azufre",ed:"Mena de oro",jd:"Cuarzo",hd:"Platino",ad:"Almandino",dd:"Cuprita",fd:"Piedra infernal",Fi:"\u00bfAtacar aleatoriamente?",Gi:'Tambi\u00e9n desactiva la configuraci\u00f3n "Ordenar jugadores en la arena por nivel" en crazy-addon.',Ug:"Aceptar solo misiones basadas en el tipo de dios.",Va:"Auto Buff",Xd:"\u00bfUsar solo en el infierno?",Ag:"Nueva Regla",yg:"Nombre Contiene",isUnderworldItem:"\u00bfEs un objeto del inframundo?",
df:"Ignorar Materiales",rk:"\u00bfUsar Oraci\u00f3n?",Ai:"Usar Sacrificio",mk:"Usar Tela para entrar en el Inframundo",ri:"\u00bfCuando est\u00e9s en el inframundo, solo aceptar misiones relacionadas con el inframundo?",pi:"Si est\u00e1 habilitado, necesitas ingresar los nombres de los objetos del inframundo. Si el bot encuentra estos objetos en el inframundo, aceptar\u00e1 la misi\u00f3n.",Yk:"Objeto de Misi\u00f3n del Inframundo",il:"Introduzca el nombre del material",Bk:"\u00a1El robot adora los dados! Le ayudan a encontrar ropa en los cofres. Pero si no hay dados, el robot abre los cofres de todos modos, con la esperanza de encontrar ropa genial (\u00a1pero puede que no encuentre nada!)",
Nj:"\u00bfFusionar Cajas de Bot\u00edn?",le:"Habilitar Arena",Mg:"\u00bfPriorizar lista de arenas?",Ng:"\u00bfPriorizar lista de circos?",de:"Desactivar men\u00fa de registro",ih:"Valor m\u00ednimo de recompensa en oro",Vg:"Si est\u00e1 habilitado, el Enfoque en misiones seguir\u00e1 el camino m\u00e1s corto para terminar el calabozo.",Hh:"\u00bfLanzar dados autom\u00e1ticamente?",Ih:"Usa el lanzamiento de dados con cautela, seguir\u00e1 usando el primer dado hasta que desactives la opci\u00f3n.",
nh:"Progreso de b\u00fasqueda",bh:"El tiempo de enfriamiento para la reparaci\u00f3n por defecto es de 10 minutos.",vg:"Condici\u00f3n m\u00ednima",be:"Art\u00edculo actual en el banco de trabajo [Borrar si el bot se detiene inesperadamente]",Af:"Recursos de forja almacenados en el horreum con \u00e9xito.",wf:"Comprobando el mercado para art\u00edculos...",yb:"Art\u00edculo movido al banco de trabajo.",Nf:"Art\u00edculo reparado y equipado con \u00e9xito.",Of:"Art\u00edculo reparado con \u00e9xito.",
Lk:"La reparaci\u00f3n fall\u00f3. La p\u00e1gina se actualizar\u00e1.",Kf:"Recogiendo materiales...",Xf:"Esperando reparaci\u00f3n...",Mf:"La reparaci\u00f3n ha comenzado para .",va:"Reparaci\u00f3n: Moviendo el art\u00edculo del inventario a la bolsa",Lf:"Reparaci\u00f3n: Moviendo el art\u00edculo del banco de trabajo al paquete.",ta:"No se pudieron encontrar suficientes materiales. Desactivando la ranura de reparaci\u00f3n ",Hf:"Buscando art\u00edculos para comprar y ocultar oro en la subasta...",
tf:"Comprobando los art\u00edculos caducados en los paquetes...",uf:"Art\u00edculo reseteado con \u00e9xito.",vf:"Sin espacio vac\u00edo o oro para resetear.",Bf:"\u00a1Aseg\u00farate de tener derechos de venta en el mercado de la guild!",sb:"No hay suficiente oro o ning\u00fan art\u00edculo para comprar. Esperando 30 segundos para actualizar.",ub:"La tienda ha sido actualizada.",vb:"Error durante la curaci\u00f3n.",Ef:"Sin Rub\u00ed o Tela, desactivando las opciones.",Kk:"No se encontr\u00f3 ning\u00fan art\u00edculo de curaci\u00f3n en los paquetes.",
wb:"No se encontraron art\u00edculos adecuados",Ff:"Se han recogido alimentos. Finalizando el proceso.",Gf:"Se ha recogido al menos un alimento. Finalizando el proceso.",xb:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",Cf:"Obteniendo alimentos de los paquetes.",Df:"No se encontr\u00f3 espacio adecuado en la bolsa para recoger comida.",tb:"No hay m\u00e1s art\u00edculos de curaci\u00f3n. Esperando 30 segundos.",rb:"Puntos de vida recuperados.",ua:"\u00a1No hay nada que hacer, as\u00ed que voy a rezar!",
Tf:"Voy a actualizar en 60 segundos para revisar mi salud y Villa Medici.",Uf:"Esperando Villa Medici, actualizando en 60 segundos.",Vf:"Sal\u00ed del inframundo.",Wf:"Voy a actualizar en 60 segundos para revisar mi salud.",If:"Comprobando aceites divinos...",Jf:"Los aceites divinos han sido recogidos.",ra:"Atacado con \u00e9xito al jugador en la ARENA: ",sa:"Atacado con \u00e9xito al jugador en el CIRCO: ",rf:"\u00a1Comprobando subasta! Por favor, espere...",sf:"Pujando por art\u00edculos. Por favor, espere...",
Pf:"Art\u00edculo fundido autom\u00e1ticamente: ",Qf:"Fundiendo art\u00edculo: ",Rf:"No hay suficiente oro para fundir. Oro requerido: ",Sf:"FUNDIR: Buscando art\u00edculos para fundir...",Mk:"Buscando art\u00edculos para fundir...",xf:"Comprobando disponibilidad de disfraces...",zf:"Donado : ",yf:"Lanzando dados...",Re:"Underworld Farm [Manual, Beta]",Qe:"Farm Location",Se:"Tenga en cuenta: active esta funci\u00f3n despu\u00e9s de desbloquear la criatura que desea atacar, no atacar\u00e1 autom\u00e1ticamente para desbloquear el monstruo.",
Pe:"Farm Enemy",Qd:"Inicio Autom\u00e1tico",Rd:"Necesitas permitir las ventanas emergentes desde la pantalla del lobby de GameForge. Consulta la documentaci\u00f3n sobre c\u00f3mo hacerlo.",Ig:"Pausar Bot",Jg:"Pausar Bot en (Minutos)",Ne:"Fecha de Expiraci\u00f3n",Dg:"\u00bfComprar solo comida?",Eg:"Si activas esto, el bot ignorar\u00e1 tus selecciones y comprar\u00e1 comida autom\u00e1ticamente sin ingresar nada.",Gb:"M\u00e1ximo de oro total para gastar",Fb:"M\u00e1ximo de oro por comida para gastar",
Cg:"El bot verificar\u00e1 los aceites cada 60 minutos",$h:"Establece un temporizador para verificar los tiempos de fundici\u00f3n.",Xh:"Establece un temporizador para verificar la fundici\u00f3n cuando no tengas oro.",Zh:"Establece un temporizador para verificar la fundici\u00f3n si no tienes el art\u00edculo disponible.",Sh:"Establece un temporizador para reparar y verificar tus objetos.",Rh:"Establece un temporizador para verificar el oro en el mercado de la hermandad.",Nh:"Establece un temporizador para la opci\u00f3n de retenci\u00f3n de oro en la subasta.",
Jh:"Establece un temporizador para verificar la lista de PVP en la arena para atacar.",Oh:"Establece un temporizador para verificar la lista de PVP en el circo para atacar.",fi:"Establece un temporizador para entrenar tus estad\u00edsticas.",Uh:"Establece un temporizador para reiniciar los objetos caducados.",di:"Establece un temporizador para almacenar los materiales de forja en el horreo.",Lh:"Establece un temporizador para verificar la subasta de gladiadores y mercenarios.",Wh:"Establece un temporizador para buscar objetos en la subasta y la tienda.",
Ph:"Establece el temporizador para enviar donaciones a la hermandad.",We:"Oro Movido",ie:"No vender art\u00edculos de la lista de fundici\u00f3n y subasta.",oh:"Automatizaci\u00f3n de la Tienda",qh:"Configuraci\u00f3n de B\u00fasqueda de Objetos",ph:"Utiliza esta herramienta para buscar objetos. Simplemente agrega los objetos a la lista, especifica la cantidad de tela y comienza la b\u00fasqueda.",rh:"Telas a Usar:",th:"\u00bfCu\u00e1ntas telas usar?",ea:"Full Ingresa el Nombre del Objeto",Sb:"Ingresa el Nivel del Objeto",
vh:"Calidad del Objeto",uh:"Nombre del Objeto Aqu\u00ed",wh:"Comenzar B\u00fasqueda",xh:"Saltar y Continuar",yh:"Detener B\u00fasqueda",Te:"\u00bfComprar lo m\u00e1s barato o lo m\u00e1s caro?",xg:"M\u00e1s Caros",Zd:"M\u00e1s Baratos",ba:"Selecciona una Opci\u00f3n",ne:"Pod\u015bwietl przedmioty z Podziemia",Ue:"\u00bfCentrarse en la b\u00fasqueda",Vl:"\u00bfUsar Ruby si no hay tela",Wa:"Evita atacar a las mismas personas para no ser reportado. Ser reportado aumenta las posibilidades de ser baneado.",
Kl:"\u00bfDerretir verde?",Pg:"\u00bfNo aceptar misiones aleatorias si se han introducido filtros?",Mc:"Calidad m\u00e1xima del material a utilizar",Ui:"Habilitar la b\u00fasqueda de mercenarios",sl:"Haz clic en `Vender Todo Seleccionado` para vender todos los elementos. Aseg\u00farate de tener espacio vac\u00edo de 2x3 en tu primera (1) bolsa. Para recoger oro en masa, filtra el oro y usa `Seleccionar Seleccionados o Seleccionar Todo`.",Zj:"\ud83d\udd25 : A\u00f1ade elemento a la lista de fundici\u00f3n.",
Hi:"\ud83d\udd28 : A\u00f1ade elemento a la lista de subastas.",Ej:"Actualiza la tienda con tela cuando est\u00e9 llena",sj:"P\u00e1gina:",zj:"Detener",xj:"Vender Esta P\u00e1gina",uj:"Seleccionar Seleccionados",tj:"Seleccionar Todo",Aj:"Configuraci\u00f3n de Empaquetado Autom\u00e1tico",yj:"Enviar Recursos",vj:"Vender Todo Seleccionado",ma:"Tipo de Objeto",oa:"Armas",S:"Escudos",M:"Armaduras",P:"Cascos",O:"Guantes",N:"Botas",na:"Anillos",ka:"Amuletos",Ia:"Utilizables (Comida)",Na:"Mejoras",rj:"Potenciadores",
Ka:"Recetas",Ja:"Mercenarios",Ma:"Herramientas de Forja",La:"Pergaminos",od:"Refuerzos",md:"Objetos de Evento",nd:"Materiales de Forja",zl:"Oro",Ha:"Todo",Al:"Calidad",pa:"Blanco",C:"Verde",B:"Azul",D:"Morado",H:"Naranja",R:"Rojo",wj:"Opciones de Venta",Mj:"\u00bfIgnorar Combinaci\u00f3n de Prefijo/Sufijo?",aj:"\u00bfCu\u00e1nta comida comprar/recoger?",Pi:"Normal",Oi:"Intermedio",Ni:"Dif\u00edcil",Ea:"Est\u00e1ndar",Dl:"Reparar Correcci\u00f3n de Atascos",Ik:"Desactiva la entrada al Infierno si deseas desactivar la Mazmorra/Circo/Arena. Si entraste al Infierno manualmente, deber\u00e1s activar el Modo Infierno.",
$d:"Wybierz kostium z Za\u015bwiat\u00f3w",Di:"Nosi\u0107 kostium z Za\u015bwiat\u00f3w, gdy jest dost\u0119pny?",ii:"Indica cu\u00e1ntas veces deseas entrenar las estad\u00edsticas y establece sus prioridades. El bot no entrenar\u00e1 a menos que se establezca una prioridad. Si hay una prioridad configurada pero no quedan m\u00e1s estad\u00edsticas por entrenar, el bot continuar\u00e1 con la estad\u00edstica seleccionada.",el:"Quest",Il:"Fundir",Ol:"Configuraci\u00f3n de Fundici\u00f3n",Wj:"Objetos Fundidos",
Pl:"Agrega Prefijos o Sufijos, una vez que los encuentre en los paquetes, se fundir\u00e1n autom\u00e1ticamente:",Nl:"Objeto en Fundici\u00f3n:",bc:"Haz clic en el objeto que deseas reparar. Este sistema reparar\u00e1 a tus dos personajes, el principal y el primer personaje de circo. Debes tener al menos 10000 de oro para que comience la reparaci\u00f3n. Si se queda atascado en un objeto, significa que no tienes material para arreglarlo. Tambi\u00e9n trata de hacer espacio en tu inventario. El bot iniciar\u00e1 la reparaci\u00f3n una vez que el objeto tenga un %0 de durabilidad.",
Zk:"Aplicar solo a Mercenarios",bl:"La subasta solo pujar\u00e1 cuando el mercado est\u00e9 cerca del final.",al:"Aseg\u00farate de que la SEGUNDA PESTA\u00d1A DEL INVENTARIO est\u00e9 vac\u00eda y tenga 10K de oro. El bot encontrar\u00e1 y colocar\u00e1 el objeto en la segunda pesta\u00f1a y luego, la pr\u00f3xima vez que se actualice la p\u00e1gina, fundir\u00e1 el objeto. La fundici\u00f3n se revisar\u00e1 cada 5-10 minutos.",dj:"Curar & Buffs",El:"No hay suficiente oro para fundir. Oro requerido:",
Hl:"Saltando puja: El miembro del gremio ya ha pujado por el objeto ",Gl:"Saltando puja: Ya has pujado por el objeto ",advanced:"Avanzado",arena:"Arena",ia:"Auto Ataque",$b:"Evitar Ataque",ga:"Agregar Jugador",ha:"Agregar Nombre de Jugador (Same Server)",nl:"\u00bfDetener el bot si se queda sin comida?",circusTurma:"Circo Turma",Qi:"Dificultad",dungeon:"Mazmorra",Ri:"Configuraci\u00f3n de Mazmorra",eventExpedition:"Expedici\u00f3n de Evento",expedition:"Expedici\u00f3n",Vi:"Configuraci\u00f3n de Expedici\u00f3n",
Gj:"Seleccionar Monstruo",pl:"M\u00e1s Alto",ol:"Coloca tus objetos de curaci\u00f3n en la primera p\u00e1gina de tu inventario",zc:"En",Fh:"Almacenar Oro",Gh:"\u00bfAlmacenar Oro en Subasta?",lh:"\u00bfUsar Ropa de Trabajo para renovar la Tienda?",Sk:"Seleccionar Objetos para Reiniciar",eh:"Reiniciar Objetos Expirados",Mb:"Nota: Al habilitar esta opci\u00f3n, el bot vender\u00e1 los objetos pr\u00f3ximos a expirar de los Paquetes al Mercado del Gremio y luego los cancelar\u00e1 para reiniciar el tiempo de vencimiento. Se requiere el Gremio. Aseg\u00farate de tener un espacio vac\u00edo de 3x3 en tus bolsas.",
Kg:"Pausar el bot aleatoriamente para funcionar como [Fase de Pruebas]:",Y:"Mantener Oro: El bot mantendr\u00e1 este oro en la bolsa:",jg:"Oro M\u00e1ximo: El bot gastar\u00e1 cuando el oro sea mayor que",jh:"El bot pujar\u00e1 por art\u00edculos aleatorios",Bd:"Agregar Retraso Aleatorio",Cd:"Puedes agregar un retraso al bot aqu\u00ed.",Lb:"Reparar",Jl:"\u00bfFundir solo Azules?",Ml:"\u00bfFundir solo P\u00farpuras?",Ll:"\u00bfFundir solo Naranjas?",Xj:"\u00bfFundir Todo en la 2da pesta\u00f1a?",
Yj:"Esto ignorar\u00e1 las selecciones de colores",Xa:"Limpiar Historial",Ah:"Fundir",Kd:"Search",zg:"Subasta Autom\u00e1tica",Ld:"El uso excesivo de la Subasta podr\u00eda resultar en una prohibici\u00f3n. Se recomienda desactivar otras funciones de oferta para evitar posibles conflictos. Esta caracter\u00edstica ralentizar\u00e1 el bot.",kh:"Buscar en la Subasta de Gladiadores",mh:"Buscar en la Subasta de Mercenarios",Td:"\u00bfPujar por Comida?",kg:"Puja M\u00e1xima",Ud:"Pujar si el estado es menor que",
Vd:"Objetos Pujados",wk:"Idioma de Subasta",xk:"Seg\u00fan la actualizaci\u00f3n 2.9.4, establece el idioma nuevamente o REINICIA EL BOT. Aseg\u00farate de que todos sean correctos, de lo contrario, no pujar\u00e1.",Fd:"Puedes agregar objetos para buscar en el mercado y en la subasta. Tambi\u00e9n mostrar\u00e1 objetos p\u00farpuras en el mercado una vez que agregues un objeto a la lista. Si deseas habilitar la puja autom\u00e1tica, usa las opciones a continuaci\u00f3n",uk:"\u00a1Usa la subasta con precauci\u00f3n!",
vk:"La puja autom\u00e1tica realiza demasiadas solicitudes al servidor y puede causar una prohibici\u00f3n si se usa todo el tiempo.",ah:"\u00bfRenovar Puntos de Evento con Rub\u00edes?",pe:"\u00bfHabilitar Aceite Autom\u00e1tico?",zk:"\u00bfObtener Aceites Sagrados Autom\u00e1ticamente?",Ok:"Velocidad de Verificaci\u00f3n de Misiones",Sa:"\u00bfAtacar a Miembros del Gremio?",Qa:'Agregar autom\u00e1ticamente a las personas a la lista de "Ataque" cuando se roban m\u00e1s de X ORO.:',Ra:'Agregar autom\u00e1ticamente a las personas a la lista de "Evitar Ataque" cuando pierdas contra ellas.:',
Pb:"Ataques en el Marcador",Xb:"Muy Largo",zb:"Largo",Hb:"Medio",Ub:"Corto",Yb:"Muy Corto",qe:"Entrar al Inframundo si HP >",Wg:"Velocidad de Verificaci\u00f3n de Misiones",Og:'El valor predeterminado es "3x". Si el bot causa problemas con las misiones, cambia la velocidad de las misiones seg\u00fan la velocidad de tu servidor.',Xe:"Selecci\u00f3n de Bolsa de Curaci\u00f3n",re:'Si est\u00e1s renovando puntos manualmente, debes hacer clic en el bot\u00f3n de arriba "Actualizar expedici\u00f3n de evento si est\u00e1 atascada".',
Dk:"Debes habilitar al menos una de las siguientes opciones: expedici\u00f3n, mazmorra, arena o circo para comenzar la Expedici\u00f3n de Evento.",Yg:"\u00a1Actualiza la Expedici\u00f3n de Evento si est\u00e1 atascada!",kb:"\u00bfCubrir a los Aliados?",Vk:"Deja todas las configuraciones desactivadas si deseas fundir usando paquetes que contienen los elementos de la lista. Sin embargo, a\u00fan puedes elegir colores.",Ak:"Personaje(Desactivado) / Mercenario(Activado)",Rk:"\u00bfReparar Ambos?",Wk:"Temporizadores",
Timers:"Ingresa el n\u00famero de minutos para cada temporizador a continuaci\u00f3n o d\u00e9jalo en su valor predeterminado.",Tg:"Ignorar Filtro de Misiones",Sg:"Ingresa palabras clave para filtrar las misiones que no deseas tomar. You can also use this to accept quests by their reward using keywords.",V:"Ingresar Palabra Clave",I:"Agregar",$g:"Eliminar",ae:"Limpiar",Qg:"Aceptar Filtro de Misiones",Rg:"Ingresa palabras clave para seleccionar qu\u00e9 misiones tomar. Usar esto ignorar\u00e1 los tipos de misiones",
Ca:"\u00bfSaltar Misiones Temporales?",Pk:"Misiones",Nd:"Auto Traje",xi:"\u00bfUsar Traje?",Sd:"Batalla B\u00e1sica",je:"Batalla en Mazmorra",Od:"Bot solo usar\u00e1 Dis Pater Normal y Medium si tus puntos de expedici\u00f3n/mazmorra son 0.",Ze:"Configuraci\u00f3n de Sanaci\u00f3n Infernal",Ed:"\u00bfAtacar al Jefe cuando est\u00e9 disponible?",qb:"La opci\u00f3n de ataque a la Liga se desactivar\u00e1 despu\u00e9s de 5 intentos fallidos.",bf:"Aceites Sagrados",ug:"Nombre del Objeto",Z:"Nivel M\u00ednimo del Objeto",
Aa:"Calidad M\u00ednima del Objeto",Dd:"Aplicar/Restablecer Temporizador",ef:"Ignorar Combinaci\u00f3n de Prefijo/Sufijo",Ei:"S\u00ed",Bg:"No",Oa:"Agregar Prefijo",Pa:"Agregar Sufijo",Bh:"Lista de Objetos a Ignorar al Fundir",Ib:"Prefijo",Vb:"Sufijo",gh:"Restablecer Objetos Expirados",Ch:"\u00bfFundir al Azar desde los Paquetes?",Dh:"Pesta\u00f1a de Fundici\u00f3n",ob:"Extras",Id:"Subasta",cg:"Mercado",Wb:"Temporizadores",bi:"Fundici\u00f3n",ai:"Fundici\u00f3n si no hay suficiente oro",Yh:"Fundir si no hay objeto",
Da:"Reparaci\u00f3n",Qh:"Mantener Oro en el Mercado de Gremio",Mh:"Mantener Oro en la Subasta",ei:"Entrenamiento",Th:"Restablecer Expirados",ci:"Almacenar en la Forja",Kh:"Comprobar Subasta",Vh:"Buscar",v:"Habilitar",wg:"Oro M\u00ednimo",Qb:"Seleccionar Hora",lb:"Donar Oro al Gremio",ee:"Donar\u00e1 cada 5 minutos. Puedes cambiar el intervalo desde la pesta\u00f1a de temporizadores",cf:"\u00bfCu\u00e1nto deseas donar?",fe:"Donar cuando tengas m\u00e1s de >",qf:"Menos de <",dh:"Restablecer Objetos Expirados y Otras Configuraciones",
fh:"Restablecer en:",Jk:"Mant\u00e9n presionada la tecla Ctrl (Cmd en Mac) para seleccionar varios objetos",ff:"Importar/Exportar Configuraciones",Oe:"Exportar Configuraciones",gf:"Importar Configuraciones",ng:"Mensaje a Todos los Jugadores",og:"[Requiere Clave Ultra Premium, mensaje en Discord para obtenerla.]",pg:"Ingresar mensaje para enviar",ce:"Para scripts personalizados, cont\u00e1ctanos en Discord",rg:"Enviar",sg:"Mostrar Jugadores",qg:"Seleccionar Todos",tg:"Deseleccionar Todos",pf:"Aseg\u00farate de que tu inventario tenga suficiente espacio. El tiempo de reutilizaci\u00f3n es de 2 minutos.",
nb:"Habilitar Ataque en el Marcador:",Nb:"Seleccionar Rango para Atacar",Ob:"El bot atacar\u00e1 aleatoriamente desde la lista del marcador.",pb:"Ataque de Liga",mb:"Habilitar Ataque de Liga:",Jb:"Ataque Aleatorio",Kb:"Atacar desde el m\u00e1s bajo al m\u00e1s alto",tk:"El bot evitar\u00e1 atacar a los miembros del gremio por defecto.",Me:"Ubicaci\u00f3n de Expedici\u00f3n:",Md:"\u00bfRecoger Bonos Autom\u00e1ticamente?",zh:"\u00bfSaltar al Jefe?",ke:"Ubicaci\u00f3n de Mazmorra:",hh:"\u00bfReiniciar si pierdes?",
$e:"Configuraci\u00f3n de Inframundo",af:"Configura tus ajustes de porcentaje de curaci\u00f3n desde la pesta\u00f1a de curaci\u00f3n y aseg\u00farate de que est\u00e9 activada. Si ingresar al inframundo te desconecta, ve al lobby y activa la casilla de inicio de sesi\u00f3n autom\u00e1tico.",Ye:"Dificultad del Inframundo",Pd:"Entrar Autom\u00e1ticamente al Inframundo: / Inframundo Mode",yi:"\u00bfUsar Movilizaci\u00f3n si los puntos = 0",Ci:"\u00bfUsar Rub\u00edes?",se:"\u00bfSalir del inframundo si no hay puntos?",
ki:"El bot intentar\u00e1 usar villa medici primero, si no la tienes, usar\u00e1 poci\u00f3n de curaci\u00f3n. No olvides activar el interruptor de Curar.",ti:"El ingreso autom\u00e1tico al inframundo deshabilitar\u00e1 la mazmorra/arena/circo al ingresar al inframundo.",Xk:"Ajustes de Curaci\u00f3n del Inframundo",Bi:"\u00bfUsar Villa Medici?",zi:"\u00bfUsar Poci\u00f3n de Curaci\u00f3n?",Yf:"INFO: El bot buscar\u00e1 objetos en el mercado cada ciertos minutos, lo que puede detener los ataques durante la b\u00fasqueda.",
oe:"Habilitar B\u00fasqueda en el Mercado:",Zf:"Intervalo de B\u00fasqueda en el Mercado en Minutos:",$f:"Se sugieren 10 minutos.",kf:"Ajustes de Objetos:",hf:"Nombre del Objeto Incluye",G:"Precio M\u00e1ximo",lf:"Tipo de Objeto",jf:"Rareza del Objeto",Yd:"\u00bfComprar con V\u00ednculo Espiritual?",nf:"Objetos para Comprar",mf:"Intentar comprar objetos con paquetes si alguno coincide con el precio m\u00e1ximo ingresado:",Wd:"Objetos Comprados:",bj:"Porcentaje de Curaci\u00f3n",pk:"\u00bfComprar Comida en la Tienda?",
qk:"\u00bfUsar Curaci\u00f3n de Paquete?",lk:"\u00bfUsar Cervisia?",nk:"\u00bfUsar Huevos?",tl:"\u00daltima Vez Usado",location:"Ubicaci\u00f3n",Strength:"Fuerza",Dexterity:"Destreza",Agility:"Agilidad",Constitution:"Constituci\u00f3n",Charisma:"Carisma",Intelligence:"Inteligencia",gi:"Ajustes de Entrenamiento",hi:"Selecciona los atributos que deseas entrenar. Se entrenar\u00e1 una vez que tengas suficiente oro.",$c:"Siguiente acci\u00f3n",oj:"No",pj:"Normal",xl:"Oponente",yl:"Nivel del Oponente",
Dj:"Misiones",random:"Aleatorio",Fl:"Ajustes",Ql:"Pronto...",type:"Haz clic en los \u00edconos para activar los tipos de misiones.",Xl:"S\u00ed",A:"Subasta/B\u00fasqueda",yd:"Agregar objetos",ik:"Almacenar Recursos Forjados autom\u00e1ticamente",Sl:"Enviar",rl:"Intervalo : ",gl:"Habilitar Puja Autom\u00e1tica",hl:"No pujar si el miembro del gremio ya ha pujado",Ul:"Tutorial",ac:"Selecciona entre los botones de arriba si deseas enfrentar al oponente de nivel m\u00e1s bajo en la arena o al oponente de nivel m\u00e1s alto. M\u00e1s usuarios ralentizar\u00e1n el bot.",
$k:"Para empezar, agrega un objeto a la lista (p. ej., `Lucius`). Una vez agregado, la herramienta buscar\u00e1 el objeto y mostrar\u00e1 los resultados de la b\u00fasqueda en el lado izquierdo de la pantalla. Tambi\u00e9n se buscar\u00e1 para fines de subasta autom\u00e1tica. Si habilitas la puja autom\u00e1tica, la herramienta buscar\u00e1 el objeto a intervalos regulares seg\u00fan el n\u00famero que ingreses en el cuadro de intervalo. Si la herramienta encuentra el objeto y tienes suficiente dinero, pujar\u00e1 autom\u00e1ticamente por ti. *Nota* para buscar objetos \u00fanicos en las tiendas, debes agregar al menos 1 objeto aleatorio en la lista de b\u00fasqueda.",
jl:"El n\u00famero de criatura se puede seleccionar desde los botones de arriba. El n\u00famero 1 representa la criatura m\u00e1s a la izquierda. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",Si:"Selecciona la dificultad de la mazmorra de arriba. Aseg\u00farate de seleccionar la ubicaci\u00f3n correcta, de lo contrario, el bot podr\u00eda detenerse.",cj:"Ajustes de Curaci\u00f3n",Ti:"Almacena el oro excedente en el Gremio comprando objetos del mercado del gremio. -> M\u00edn. Oro",
ul:"Mover Todo",vl:"Mover Seleccionados",cl:"Curaci\u00f3n Autom\u00e1tica",dl:"Porcentaje de Curaci\u00f3n Autom\u00e1tica",Wl:"Ruby",Fg:"Ajustes Generales",Hj:"Vender Todo",Ij:"Vender Seleccionados",fa:"Armas",ca:"Escudos",U:"Armadura de Pecho",X:"Cascos",W:"Guantes",da:"Zapatos",aa:"Anillos",T:"Amuletos",wi:"Usables",vi:"Mejoras",Xg:"Recetas",mg:"Pergamino de Mercenario",Zg:"Refuerzos",gg:"Vender Comida",Db:"Cambiar a Comida"},Mh={Fk:"Vos param\u00e8tres d'exp\u00e9dition sont incorrects ou il y a des donn\u00e9es de page inattendues !",
Gk:"Votre param\u00e8tre d'exp\u00e9dition est incorrect ! Vous avez s\u00e9lectionn\u00e9 un monstre d\u00e9sactiv\u00e9, ce qui est incorrect.",Tk:"R\u00e9initialiser uniquement tous les \u00e9l\u00e9ments du monde souterrain avec la couleur s\u00e9lectionn\u00e9e?",Ba:"Priorit\u00e9",Rb:"D\u00e9finir la priorit\u00e9",Lg:"Points",Eh:"Stat",Mi:"Collecter de l`or",Jj:"Vendre des objets des Enfers?",nj:"Le bot cherchera le nid dans chaque action, pas seulement lors des exp\u00e9ditions.",lj:"Type de recherche de nid",
jj:"Ne rien faire",kj:"Recherche rapide",mj:"Recherche approfondie",Bj:"After expedition points are consumed, travel to Germania to consume Dungeon points",sk:"Cliquez ici si la r\u00e9paration se bloque",Hk:"Quand les PV sont en dessous, utilisez soin",Hg:"R\u00e9paration Partielle",Ve:"R\u00e9paration Compl\u00e8te",Gg:"R\u00e9paration Partielle ou Compl\u00e8te",me:"Activer la Limite",ej:"Limite",fj:"Si vous voulez limiter le nombre de fois que vous souhaitez attaquer l'ennemi, activez cette option et d\u00e9finissez la limite. Le bot continuera \u00e0 attaquer le reste des ennemis apr\u00e8s avoir fini d'attaquer le monstre s\u00e9lectionn\u00e9.",
si:"Monde Souterrain",ji:"Am\u00e9liorations du Monde Souterrain",li:"Utiliser les pouvoirs des dieux apr\u00e8s \u00eatre entr\u00e9 dans le monde souterrain?",mi:"S\u00e9lectionnez les dieux pour utiliser leurs pouvoirs:",ni:"Utiliser un Buff d'Arme sur l'arme?",oi:"Utiliser un Buff d'Armure sur l'\u00e9quipement suivant:",Ck:"Le temps de recharge est de 30 minutes. Si vous n'avez pas de costume, le bot r\u00e9initialisera le temps de recharge \u00e0 0.",Uk:"S\u00e9lectionner les Couleurs",Ya:"Forge de Vulcain",
bb:"Bouclier de Terre de Feronia",cb:"Puissance Fluide de Neptune",eb:"Libert\u00e9 A\u00e9rienne d'Aelous",fb:"Brouillard Mortel de Pluton",gb:"Souffle de Vie de Junon",hb:"Armure d'\u00c9cailles des Montagnes de Col\u00e8re",ib:"Yeux d'Aigle",jb:"V\u00eatement d'Hiver de Saturne",Za:"Armure de Taureau de Bubona",$a:"V\u00eatements de Voleur de Mercure",ab:"Robe de Lumi\u00e8re de R\u00e2",he:"N`entrez pas dans le monde souterrain avec le costume des enfers",ge:"Si vous ne voulez pas entrer dans le monde souterrain en portant le costume des enfers, activez cette option",
fg:"Paquets",ag:"Inventaire",K:"Prix Min.",J:"Combien",Cb:"Vendre des Articles",Bb:"Rechercher dans",bg:"Couleur du Mat\u00e9riau",Ab:"Couleur de l`Article",ig:"Entrep\u00f4t",za:"Basculer vers Mat\u00e9riaux",Eb:"Basculer vers Articles",hg:"Vendre des Mat\u00e9riaux",wa:"Veuillez entrer un nom d`article valide, une fourchette de prix et une quantit\u00e9.",xa:"Aucun article correspondant trouv\u00e9 dans les emplacements de recherche s\u00e9lectionn\u00e9s.",ya:"Tous les articles ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",
Nk:"Tous les mat\u00e9riaux ont \u00e9t\u00e9 list\u00e9s avec succ\u00e8s !",dg:"Si vous souhaitez vendre des articles \u00e0 un prix fixe, vous pouvez entrer la m\u00eame valeur pour le prix minimum et maximum.",eg:"Cette fonctionnalit\u00e9 est encore exp\u00e9rimentale, utilisez-la avec prudence. Si vous ne fixez pas un prix, les articles seront list\u00e9s al\u00e9atoirement entre le prix minimum et maximum que vous entrez.",yk:"D\u00e9finit le maximum d`or que le bot d\u00e9pensera par cycle.",
Ta:"Le bot commencera \u00e0 faire des offres sur tout article de nourriture, si activ\u00e9. Vous n`avez pas besoin d`activer les bascules gladiateur/mercenaire.",Gd:"Le bot ne fera pas d`offres sur les ench\u00e8res des alli\u00e9s.",Hd:"Ignorer la combinaison Pr\u00e9fixe/Suffixe lors de la recherche d`un objet \u00e0 la vente aux ench\u00e8res.",Qj:"S\u00e9lectionnez les types d\u2019objets que vous souhaitez fondre.",Rj:"S\u00e9lectionnez les couleurs que vous souhaitez fondre.",Sj:"S\u00e9lectionnez le niveau des objets que vous souhaitez fondre.",
Tj:"S\u00e9lectionnez le marteau que vous voulez utiliser.",Uj:"Notez que le cercle vert et rouge \u00e0 c\u00f4t\u00e9 de la premi\u00e8re case sert \u00e0 activer/d\u00e9sactiver la r\u00e8gle.",Vj:"Si vous voulez fondre al\u00e9atoirement n\u2019importe quelle couleur ou type, vous pouvez activer `Fondre al\u00e9atoirement si aucune condition n\u2019est remplie? (Derni\u00e8re option activ\u00e9e dans la vid\u00e9o du tutoriel)",Fj:"R\u00e9parer avant de fondre",Ie:"S\u00e9lectionner Monstre",
we:"Utiliser Sablier/Rubis?",Ek:"Utiliser Rubis?",ze:"Utiliser Mobilisation?",ye:"Utiliser Potion de Vie?",ve:"Pourcentage de Soin (%)",Ge:"Nombre d'Attaques",xe:"Intervalle d'Attaque (en secondes)",te:"Attaques Effectu\u00e9es",ue:"Sabliers Restants",Ee:"Note : Utilise des potions de vie pour gu\u00e9rir, pas de nourriture.",Fe:"Note : Si les attaques s'arr\u00eatent pr\u00e9matur\u00e9ment, essayez 'R\u00e9initialiser les Attaques'.",Je:"D\u00e9marrer",He:"R\u00e9initialiser",Ke:"Arr\u00eater",
Le:"Param\u00e8tres d'Exp\u00e9dition (Cliquez pour minimiser)",Ae:"Monstre 1",Be:"Monstre 2",Ce:"Monstre 3",De:"Monstre 4",Qk:"R\u00e9parer avant de fondre",Ki:"Cette option utilisera cervisia lorsque votre premium expirera.",qj:"Cette option permet d'activer et de choisir les huiles parmi les r\u00e9compenses des dieux. Elle peut utiliser les huiles num\u00e9ro 1 et 3 sur le personnage, mais la num\u00e9ro 2 ne sera prise que pour les paquets.",Ii:"Cette option utilisera des buffs au moment que vous avez fix\u00e9. Elle trouvera les buffs dans les paquets et les appliquera au personnage.",
gj:"Cette option vous m\u00e8nera aux enfers. N'oubliez pas d'activer la Connexion Automatique depuis l'onglet Extras, sinon vous pourriez \u00eatre d\u00e9connect\u00e9 en entrant aux enfers [Bug du Jeu]",Zb:"Le bot choisit normalement entre 3 et 6 essais al\u00e9atoires pour attaquer la liste d'ar\u00e8ne. Si vous activez cette option, il parcourra votre liste jusqu'\u00e0 ce qu'il puisse attaquer quelqu'un. Cela peut prendre du temps.",Cj:"Cette option est uniquement pour les licences premium. Elle simule l'attaque avant d'attaquer un utilisateur pour un taux de victoire de 75%.",
Jd:"Vous n'avez pas besoin d'activer l'interrupteur principal de l'ench\u00e8re pour activer cette option.",kk:"Cette option rafra\u00eechira la page chaque seconde quand l'ench\u00e8re est en \u00e9tat -Tr\u00e8s Court- pour ench\u00e9rir constamment et gagner l'ench\u00e8re.",Oj:"Si aucune des conditions de fusion n'est remplie, il fusionnera al\u00e9atoirement. Assurez-vous de s\u00e9lectionner le type et la couleur de l'objet.",Pj:"Cette option ne fusionnera que les objets de l'inventaire. Elle ignorera les objets dans les paquets.",
Ua:"Articles aux Ench\u00e8res",lg:"Articles de Mercenaire",Tb:"Articles de Boutique",ui:"Articles Uniques",Kj:"D\u00e9finir le fond en noir [Augmente les performances]",Lj:"D\u00e9placer les boutons GLDbot en bas \u00e0 gauche?",Li:"Attaquer le cirque sans soigner",jk:"Prendre l'or des paquets si n\u00e9cessaire?",Tl:"L'or a \u00e9t\u00e9 pris des paquets pour l'entra\u00eenement",Ad:"Aucun or n'a \u00e9t\u00e9 trouv\u00e9 dans les paquets pour l'entra\u00eenement",gk:"Objets R\u00e9par\u00e9s",
$j:"Attaques en Ar\u00e8ne",bk:"Attaques au Cirque",zd:"Objets R\u00e9initialis\u00e9s",ek:"Attaques en Exp\u00e9dition",dk:"Attaques en Donjon",hk:"Attaques dans l'Underworld",ak:"Argent Gagn\u00e9 en Ar\u00e8ne",ck:"Argent Gagn\u00e9 au Cirque",Rl:"Objets Fondus",fk:"Or Recycl\u00e9",Yi:"Bataille de Guilde",$i:"Param\u00e8tres de Guilde",Zi:"Guild Name",ll:"Attaquera les guildes au hasard.",Ji:"R\u00e9initialiser les Statistiques",Fh:"Stockage de l'Or",Xi:"Attaquer une Guilde Al\u00e9atoire",wl:"GLDbot\u00a0: utilisez les d\u00e9s pour rafra\u00eechir la bo\u00eete myst\u00e8re et trouver des objets de valeur avant de les ouvrir (etc. Costumes). Cliquez sur \u00ab\u00a0D\u00e9marrer\u00a0\u00bb pour ouvrir les coffres.\u00a0",
Kc:"Bois",Ac:"Cuivre",Ec:"Fer",Gc:"Cuir",Lc:"Fil de laine",Bc:"Boule de coton",Dc:"Chanvre",Cc:"Bande de gaze",Hc:"Toile de lin",Fc:"Jute",Jc:"Bande de velours",Ic:"Fil de soie",Tc:"Fourrure",Nc:"\u00c9clat osseux",Wc:"\u00c9caille",Qc:"Griffe",Sc:"Canine",Rc:"\u00c9caille de dragon",Oc:"Corne de taureau",Vc:"Glande \u00e0 venin",Pc:"Touffe de poils de Cerb\u00e8re",Uc:"\u00c9caille d`Hydre",Xc:"Plume du Sphinx",Yc:"Cuir de Typhon",wc:"Lapis-lazuli",qc:"Am\u00e9thyste",pc:"Ambre jaune",rc:"Aigue-marine",
xc:"Safir",uc:"Grenat",tc:"\u00c9meraude",sc:"Diamant",vc:"Jaspe",yc:"Sugilith",kc:"Venin de scorpion",nc:"Teinture d`endurance",fc:"Antidote",ec:"Adr\u00e9naline",mc:"Teinture de r\u00e9v\u00e9lation",jc:"Potion de perception",hc:"Essence de reflet",ic:"Flacon du rayonnement",oc:"Eau de l`oubli",lc:"Essence d`\u00e2me",xd:"Sceau aquatique",rd:"Rune protectrice",pd:"Gravure terrestre",wd:"Totem gu\u00e9risseur",vd:"Talism\u00e1n de puissance",td:"Pierre de fortune",qd:"Pierre du feu",ud:"Rune temp\u00e9tueuse",
sd:"Rune t\u00e9n\u00e9breuse",cd:"Cristal",bd:"Bronze",gd:"Obsidienne",kd:"Argent",ld:"Soufre",ed:"Minerai d`or",jd:"Quartz",hd:"Platine",ad:"Almandin",dd:"Cuprit",fd:"Pierre infernale",Fi:"Attaquer al\u00e9atoirement?",Gi:'D\u00e9sactivez \u00e9galement le param\u00e8tre "Trier les joueurs dans l\'ar\u00e8ne par niveau" dans crazy-addon.',Ug:"Accepter uniquement les qu\u00eates bas\u00e9es sur le type de dieu.",Va:"Buff Automatique",Xd:"Utiliser uniquement en enfer?",Ag:"Nouvelle R\u00e8gle",yg:"Le Nom Contient",
isUnderworldItem:"Est-ce un objet du monde souterrain?",df:"Ignorer les Mat\u00e9riaux",rk:"Utiliser la pri\u00e8re",Ai:"Utiliser le sacrifice",mk:"Utiliser des v\u00eatements pour entrer dans le monde souterrain",ri:"Lorsque vous \u00eates dans le monde souterrain, n`acceptez que les qu\u00eates li\u00e9es au monde souterrain ?",pi:"Si activ\u00e9, vous devez entrer les noms des objets du monde souterrain. Si le bot trouve ces objets dans le monde souterrain, il acceptera la qu\u00eate.",Yk:"Objet de Qu\u00eate du Monde Souterrain",
il:"Entrez le nom du mat\u00e9riau",Bk:"Le robot adore les d\u00e9s ! Ils l'aident \u00e0 trouver des v\u00eatements dans les coffres. Mais s'il n'y a pas de d\u00e9s, le robot ouvre quand m\u00eame les coffres, en esp\u00e9rant trouver des v\u00eatements cool (mais il pourrait ne rien trouver !)",Nj:"Fondre les coffres",le:"Activer l'ar\u00e8ne",Mg:"Prioriser la liste des ar\u00e8nes ?",Ng:"Prioriser la liste des cirques ?",de:"D\u00e9sactiver le menu de journalisation",ih:"Valeur minimale de r\u00e9compense en or",
jh:"Le robot ench\u00e9rira sur des articles al\u00e9atoires.",Vg:"Si activ\u00e9, le Focus sur les qu\u00eates suivra le chemin le plus court pour terminer le donjon.",Hh:"Lancer les d\u00e9s automatiquement ?",Ih:"Utilisez le lancer de d\u00e9s avec prudence, il continuera \u00e0 utiliser le premier d\u00e9 jusqu'\u00e0 ce que vous d\u00e9sactiviez l'option.",nh:"Progression de la recherche",bh:"Le temps de recharge pour la r\u00e9paration par d\u00e9faut est de 10 minutes.",vg:"Condition minimale",
be:"Article actuel sur l'\u00e9tabli [Effacer si le bot se met en pause de mani\u00e8re inattendue]",Af:"Ressources de forge stock\u00e9es avec succ\u00e8s dans l'horreum.",wf:"V\u00e9rification du march\u00e9 pour les articles...",yb:"Article d\u00e9plac\u00e9 sur l'\u00e9tabli.",Nf:"Article r\u00e9par\u00e9 et \u00e9quip\u00e9 avec succ\u00e8s.",Of:"Article r\u00e9par\u00e9 avec succ\u00e8s.",Lk:"La r\u00e9paration a \u00e9chou\u00e9. La page sera rafra\u00eechie.",Kf:"Ramassage des mat\u00e9riaux...",
Xf:"En attente de r\u00e9paration...",Mf:"La r\u00e9paration a commenc\u00e9 pour .",va:"R\u00e9paration : D\u00e9placement de l'article de l'inventaire vers le sac",Lf:"R\u00e9paration : D\u00e9placement de l'article de l'\u00e9tabli vers le paquet.",ta:"Impossible de trouver suffisamment de mat\u00e9riaux. D\u00e9sactivation de l'emplacement de r\u00e9paration ",Hf:"Recherche d'articles \u00e0 acheter pour cacher de l'or aux ench\u00e8res...",tf:"V\u00e9rification des articles expir\u00e9s dans les paquets...",
uf:"R\u00e9initialisation de l'article r\u00e9ussie.",vf:"Aucun espace vide ou or pour r\u00e9initialiser.",Bf:"Assurez-vous d'avoir les droits de vente sur le march\u00e9 de guilde !",sb:"Pas assez d'or ou aucun article \u00e0 acheter. Attente de 30 secondes pour rafra\u00eechir.",ub:"Le magasin a \u00e9t\u00e9 rafra\u00eechi.",vb:"Erreur lors de la gu\u00e9rison.",Ef:"Pas de Rubis ou de Tissu, d\u00e9sactivation des options.",Kk:"Aucun article de gu\u00e9rison trouv\u00e9 dans les paquets.",wb:"Aucun article appropri\u00e9 trouv\u00e9",
Ff:"Les aliments ont \u00e9t\u00e9 ramass\u00e9s. Fin du processus.",Gf:"Au moins un aliment a \u00e9t\u00e9 ramass\u00e9. Fin du processus.",xb:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",Cf:"Obtention de la nourriture des paquets.",Df:"Aucun espace appropri\u00e9 trouv\u00e9 dans le sac pour ramasser de la nourriture.",tb:"Plus d'articles de gu\u00e9rison. Attente de 30 secondes.",rb:"Points de vie r\u00e9cup\u00e9r\u00e9s.",ua:"Rien \u00e0 faire alors je vais prier !",
Tf:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9 et Villa Medici.",Uf:"En attente de Villa Medici, actualisation dans 60 secondes.",Vf:"Quitt\u00e9 les Enfers.",Wf:"Je vais actualiser dans 60 secondes pour v\u00e9rifier ma sant\u00e9.",If:"V\u00e9rification des huiles divines...",Jf:"Les huiles divines ont \u00e9t\u00e9 ramass\u00e9es.",ra:"Attaque r\u00e9ussie du joueur dans l'AR\u00c8NE : ",sa:"Attaque r\u00e9ussie du joueur dans le CIRQUE : ",rf:"V\u00e9rification des ench\u00e8res ! Veuillez patienter...",
sf:"Mise aux ench\u00e8res d'articles. Veuillez patienter...",Pf:"Article fondu automatiquement : ",Qf:"Fusion de l'article : ",Rf:"Pas assez d'or pour fondre. Or requis : ",Sf:"FONDRE : Recherche d'articles \u00e0 fondre...",Mk:"Recherche d'articles \u00e0 fondre...",xf:"V\u00e9rification de la disponibilit\u00e9 des costumes...",zf:"Donn\u00e9 : ",yf:"Lancer des d\u00e9s...",Re:"Underworld Farm [Manual, Beta]",Qe:"Farm Location",Se:"Attention\u00a0: activez cette fonctionnalit\u00e9 apr\u00e8s avoir d\u00e9verrouill\u00e9 la cr\u00e9ature que vous souhaitez attaquer, elle n'attaquera pas automatiquement pour d\u00e9bloquer le monstre.",
Pe:"Farm Enemy",Qd:"Connexion Automatique",Rd:"Vous devez autoriser les pop-ups depuis l'\u00e9cran du lobby de GameForge. Consultez la documentation pour savoir comment faire.",Ig:"Mettre le Bot en Pause",Jg:"Mettre le Bot en pause (Minutes)",Ne:"Date d'Expiration",Dg:"Acheter uniquement de la nourriture ?",Eg:"Si vous activez cette option, le bot ignorera vos s\u00e9lections et ach\u00e8tera automatiquement de la nourriture sans rien saisir.",Gb:"Montant total maximal d'or \u00e0 d\u00e9penser",
Fb:"Montant maximal d'or par aliment \u00e0 d\u00e9penser",Cg:"Le bot v\u00e9rifiera les huiles toutes les 60 minutes",$h:"D\u00e9finit une minuterie pour v\u00e9rifier les temps de fusion.",Xh:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion lorsque vous n'avez pas d'or.",Zh:"D\u00e9finit une minuterie pour v\u00e9rifier la fusion si vous n'avez pas l'objet disponible.",Sh:"D\u00e9finit une minuterie pour r\u00e9parer et v\u00e9rifier vos objets.",Rh:"D\u00e9finit une minuterie pour v\u00e9rifier l'or retenu sur le march\u00e9 de la guilde.",
Nh:"D\u00e9finit une minuterie pour l'option de retenue d'or aux ench\u00e8res.",Jh:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans l'ar\u00e8ne pour attaquer.",Oh:"D\u00e9finit une minuterie pour v\u00e9rifier la liste PvP dans le cirque pour attaquer.",fi:"D\u00e9finit une minuterie pour entra\u00eener vos statistiques.",Uh:"D\u00e9finit une minuterie pour r\u00e9initialiser les objets expir\u00e9s.",di:"D\u00e9finit une minuterie pour stocker les mat\u00e9riaux de forge dans l'horreum.",
Lh:"D\u00e9finit une minuterie pour v\u00e9rifier les ench\u00e8res des gladiateurs et des mercenaires.",Wh:"D\u00e9finit une minuterie pour rechercher des objets aux ench\u00e8res et en boutique.",Ph:"D\u00e9finit la minuterie d'envoi de dons \u00e0 la guilde.",We:"Or D\u00e9plac\u00e9",ie:"Ne vendez pas d'articles de la fonderie et de la liste des ench\u00e8res",oh:"Automatisation de la Boutique",qh:"Param\u00e8tres de Recherche d'Objets",ph:"Utilisez cet outil pour rechercher des objets. Ajoutez simplement les objets \u00e0 la liste, sp\u00e9cifiez la quantit\u00e9 de tissu et lancez la recherche.",
rh:"Tissus \u00e0 Utiliser :",th:"Combien de tissus utiliser ?",ea:"Full Entrez le Nom de l'Objet",Sb:"Entrez le Niveau de l'Objet",vh:"Qualit\u00e9 de l'Objet",uh:"Nom de l'Objet Ici",wh:"Commencer la Recherche",xh:"Sauter et Continuer",yh:"Arr\u00eater la Recherche",Te:"Acheter le moins cher ou le plus cher?",xg:"Le Plus Cher",Zd:"Le Moins Cher",ba:"S\u00e9lectionnez une Option",ne:"Mettre en surbrillance les objets du monde souterrain",Ue:"Concentrez-vous sur la qu\u00eate\u00a0?",Vl:"Utiliser Ruby s'il n'y a pas de tissu ?",
Wa:"\u00c9vitez d'attaquer les m\u00eames personnes pour ne pas \u00eatre signal\u00e9. \u00catre signal\u00e9 augmente les chances d'\u00eatre banni.",Kl:"Fondre Green ?",Pg:"Ne pas accepter les qu\u00eates al\u00e9atoires si des filtres sont entr\u00e9s ?",Mc:"Qualit\u00e9 maximale des mat\u00e9riaux \u00e0 utiliser",Ui:"Activer la recherche de mercenaires",sl:"Cliquez sur `Vendre Tout S\u00e9lectionn\u00e9` pour vendre tous les objets. Assurez-vous d`avoir de l`espace vide de 2x3 dans votre premi\u00e8re (1) sac. Pour collecter de l`or en masse, filtrez l`or et utilisez `S\u00e9lectionner S\u00e9lectionn\u00e9s ou Tout S\u00e9lectionner`.",
Zj:"\ud83d\udd25 : Ajoute l`objet \u00e0 la liste de fusion.",Hi:"\ud83d\udd28 : Ajoute l`objet \u00e0 la liste des ench\u00e8res.",Ej:"Actualisez la boutique avec du tissu lorsqu`elle est pleine",sj:"Page:",zj:"Arr\u00eater",xj:"Vendre Cette Page",uj:"S\u00e9lectionner S\u00e9lectionn\u00e9s",tj:"Tout S\u00e9lectionner",Aj:"Param\u00e8tres d`Emballage Automatique",yj:"Envoyer les Ressources",vj:"Vendre Tout S\u00e9lectionn\u00e9",ma:"Type d`Objet",oa:"Armes",S:"Boucliers",M:"Armures",P:"Casques",
O:"Gants",N:"Bottes",na:"Anneaux",ka:"Amulettes",Ia:"Utilisables (Nourriture)",Na:"Am\u00e9liorations",rj:"Boosts",Ka:"Recettes",Ja:"Mercenaires",Ma:"Outils de Forge",La:"Parchemins",od:"Renforcements",md:"Objets d`\u00c9v\u00e9nement",nd:"Mat\u00e9riaux de Forge",zl:"Or",Ha:"Tout",Al:"Qualit\u00e9",pa:"Blanc",C:"Vert",B:"Bleu",D:"Violet",H:"Orange",R:"Rouge",wj:"Options de Vente",Mj:"Ignorer la Combinaison Pr\u00e9fixe/Suffixe ?",aj:"Combien de nourriture acheter/cueillir ?",Pi:"Normal",Oi:"Interm\u00e9diaire",
Ni:"Difficile",Ea:"Standard",Dl:"R\u00e9paration Correction d`Enlisement",Ik:"D\u00e9sactivez l`Entr\u00e9e en Enfer si vous souhaitez d\u00e9sactiver le Donjon/Cirque/Arenas. Si vous \u00eates entr\u00e9 en Enfer manuellement, vous devrez activer le Mode Enfer.",$d:"Choisir le costume des Enfers",Di:"Porter le costume des Enfers quand il est disponible ?",ii:"Tutoriel dentra\u00eenement : Indiquez combien de fois vous souhaitez entra\u00eener les statistiques et d\u00e9finissez leurs priorit\u00e9s. Le bot nentra\u00eenera pas sans quune priorit\u00e9 soit d\u00e9finie. Si une priorit\u00e9 est configur\u00e9e mais quil ne reste plus de statistiques \u00e0 entra\u00eener, le bot continuera avec la statistique s\u00e9lectionn\u00e9e.",
el:"Quest",Gh:"Conserver l'Or aux Ench\u00e8res ?",Kg:"Mettre en Pause le Bot Al\u00e9atoirement pour travailler comme [Phase de Test] :",eh:"R\u00e9initialiser les Objets Expir\u00e9s",Mb:"Remarque : En activant cette option, le bot vendra les objets expir\u00e9s \u00e0 venir des paquets sur le march\u00e9 de la guilde, puis annulera pour r\u00e9initialiser le temps d'expiration. La guilde est requise. Assurez-vous d'avoir un espace vide de 3x3 dans vos sacs.",Y:"Conserver l'Or : Le bot conservera cet or dans le sac :",
jg:"Or Maximum : Le bot d\u00e9pensera lorsque l'or sera sup\u00e9rieur \u00e0",Il:"Fonderie",Ol:"Fonderie Param\u00e8tres",Wj:"Fonderie Liste",Pl:"Ajouter un pr\u00e9fixe ou un suffixe, une fois qu`il l`aura trouv\u00e9 dans les paquets, il le fondera automatiquement:",Nl:"Fusion d'item:",bc:"Cliquez sur l`\u00e9l\u00e9ment que vous souhaitez r\u00e9parer. Essayez de faire de la place dans votre inventaire",Zk:"S`applique-t-il uniquement aux mercenaires ?",bl:"L'ench\u00e8re ach\u00e8te que lorsque le march\u00e9 est proche de la fin.",
al:"Assurez-vous que le SECOND ONGLET D'INVENTAIRE est vide. Le bot trouvera et mettra l'objet dans le deuxi\u00e8me onglet puis la prochaine fois que la page est actualis\u00e9e, il fondra l'objet.",dj:"Gu\u00e9risseur & Buffs",El:"Pas assez d'or pour fondre. Or requis:",Hl:"Ench\u00e8re ignor\u00e9e: un membre de la guilde a d\u00e9j\u00e0 mis\u00e9 pour l'objet ",Gl:"Ench\u00e8re ignor\u00e9e: Vous avez d\u00e9j\u00e0 mis\u00e9 pour cet objet ",advanced:"Avanc\u00e9e",arena:"Ar\u00e8ne",ia:"Attaque automatique",
$b:"Eviter l'attaque",ga:"Ajouter un joueur",ha:"Entrez le nom du joueur (Same Server)",nl:"Arr\u00eater le bot en cas de manque de nourriture?",circusTurma:"Circus Turma",Qi:"Difficult\u00e9",dungeon:"Donjon",Ri:"Param\u00e8tres du donjon",eventExpedition:"Event Exp\u00e9dition",expedition:"Expedition",Vi:"Param\u00e8tres d'expedition",Gj:"S\u00e9lectionner un monstre",pl:"Plus haut",ol:"Mettez vos objets de soin dans la premi\u00e8re page de votre inventaire",zc:"Dans",lh:"Utiliser les v\u00eatements de travail pour renouveler la boutique?",
bj:"Pourcentage de gu\u00e9rison",pk:"Acheter de la nourriture dans la boutique?",qk:"Utiliser la gu\u00e9rison \u00e0 partir du paquet?",lk:"Utiliser Cervisia?",nk:"Utiliser des oeufs?",tl:"Dernier utilis\u00e9",location:"Emplacement",Strength:"Force",Dexterity:"Adresse",Agility:"Agilit\u00e9",Constitution:"Constitution",Charisma:"Charisme",Intelligence:"Intelligence",gi:"Param\u00e8tres d'entrainement",hi:"S\u00e9lectionnez les states que vous souhaitez entra\u00eener. L'entra\u00eenement commencera une fois que vous aurez assez d'or.",
$c:"Action suivante",oj:"Non",pj:"Normal",xl:"Adversaire",yl:"Niveau de l'adversaire",Dj:"Qu\u00eates",random:"Al\u00e9atoire",Fl:"Param\u00e8tres",Ql:"Bient\u00f4t...",type:"Cliquez sur les ic\u00f4nes pour activer les types de qu\u00eate.",Xl:"Oui",A:"Ench\u00e8re",yd:"Ajouter des objets",ik:"Stocker automatiquement les ressources de la forge",Sl:"Soumettre",rl:"Intervalle : ",gl:"Activer l'ench\u00e8re automatique",hl:"Ne pas ench\u00e9rir si un membre de la guilde a d\u00e9j\u00e0 ench\u00e9ri",
Ul:"Tutoriel",ac:"S\u00e9lectionnez \u00e0 partir des boutons ci-dessus pour choisir si vous souhaitez affronter l'adversaire le plus faible de l'ar\u00e8ne ou l'adversaire de niveau le plus \u00e9lev\u00e9.",$k:"Pour commencer, ajoutez un article \u00e0 la liste (par exemple, `Lucius`). Une fois ajout\u00e9, l'outil recherchera l'article et affichera les r\u00e9sultats de la recherche sur le c\u00f4t\u00e9 gauche de l'\u00e9cran. Il sera \u00e9galement recherch\u00e9 \u00e0 des fins d'ench\u00e8re automatique. Si vous activez l'ench\u00e8re automatique, l'outil recherchera l'article \u00e0 des intervalles r\u00e9guliers en fonction du nombre que vous mettez dans la case d'intervalle. Si l'outil trouve l'article et que vous avez assez d'argent, il ench\u00e9rira automatiquement pour vous. *Note* pour rechercher des articles uniques dans les boutiques, vous devez ajouter au moins 1 article al\u00e9atoire \u00e0 la liste de recherche.",
jl:"Le num\u00e9ro de la cr\u00e9ature peut \u00eatre s\u00e9lectionn\u00e9 \u00e0 partir des boutons ci-dessus. Le num\u00e9ro 1 repr\u00e9sente la cr\u00e9ature la plus \u00e0 gauche. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",Si:"S\u00e9lectionnez la difficult\u00e9 du donjon depuis le dessus. Assurez-vous de s\u00e9lectionner le bon emplacement, sinon le bot pourrait se mettre en pause.",cj:"Param\u00e8tres de gu\u00e9rison",Ti:"Stocker l'or exc\u00e9dentaire dans la guilde en achetant des objets du march\u00e9 de la guilde. -> Or Min.",
ul:"D\u00e9placer tout",vl:"D\u00e9placer les s\u00e9lectionn\u00e9s",cl:"Auto gu\u00e9rison",dl:"Pourcentage de gu\u00e9rison automatique",Wl:"Ruby",Fg:"Param\u00e8tres g\u00e9n\u00e9raux",Hj:"Tout vendre",Ij:"Vendre s\u00e9lectionn\u00e9s",fa:"Armes",ca:"Boucliers",U:"Armure de poitrine",X:"Casques",W:"Gants",da:"Chaussures",aa:"Anneaux",T:"Amulettes",wi:"Utilisable",vi:"Am\u00e9liorations",Xg:"Nourriture",mg:"Parchemin de mercenaire",Zg:"Renforts",Bd:"Ajouter un D\u00e9lai Al\u00e9atoire",Cd:"Vous pouvez ajouter un d\u00e9lai al\u00e9atoire au bot ici.",
Lb:"R\u00e9parer",Jl:"Fonder uniquement les Bleus?",Ml:"Fonder uniquement les Violets?",Ll:"Fonder uniquement les Oranges?",Xj:"Tout Fondre dans le 2e Onglet?",Yj:"Cela ignorera les s\u00e9lections de couleur",Xa:"Effacer l'Historique",Ah:"Fondre",Kd:"Search",zg:"Ench\u00e8re Automatique",Ld:"Une utilisation excessive des ench\u00e8res peut entra\u00eener un bannissement. Il est recommand\u00e9 de d\u00e9sactiver les autres fonctionnalit\u00e9s d ench\u00e8res pour \u00e9viter les conflits potentiels. Cette fonctionnalit\u00e9 ralentira le bot..",
kh:"Rechercher dans l'Ench\u00e8re des Gladiateurs",mh:"Rechercher dans l'Ench\u00e8re des Mercenaires",Td:"Miser de la Nourriture?",kg:"Mise Maximale",Ud:"Miser si le statut est inf\u00e9rieur \u00e0",Vd:"Objets Mis\u00e9s",wk:"Langue de l'Ench\u00e8re",xk:"\u00c0 partir de la mise \u00e0 jour 2.9.4, veuillez r\u00e9initialiser la langue ou R\u00c9INITIALISER LE BOT. Assurez-vous que toutes les informations sont correctes, sinon les ench\u00e8res ne fonctionneront pas.",Fd:"Vous pouvez ajouter des objets pour les rechercher dans le march\u00e9 et les ench\u00e8res. Il montrera \u00e9galement les objets violets dans le march\u00e9 une fois que vous aurez ajout\u00e9 un objet \u00e0 la liste. Si vous souhaitez activer les ench\u00e8res automatiques, utilisez les options ci-dessous.",
uk:"Utilisez les ench\u00e8res avec prudence!",vk:"Les ench\u00e8res automatiques font trop de requ\u00eates au serveur et peuvent entra\u00eener un bannissement si elles sont utilis\u00e9es en permanence!",ah:"Renouveler les Points d'\u00c9v\u00e9nement avec des Rubis?",pe:"Activer l'Huile Automatique",zk:"R\u00e9cup\u00e9rer Automatiquement les Huiles Sacr\u00e9es",Ok:"Vitesse de V\u00e9rification des Qu\u00eates",Sa:"Attaquer les Membres du Gremio ?",Qa:'Ajouter automatiquement les personnes \u00e0 la liste "Attaque" lorsque plus de X OR est vol\u00e9.:',
Ra:'Ajouter automatiquement les personnes \u00e0 la liste "\u00c9viter l\'Attaque" lorsque vous perdez contre elles.:',Pb:"Attaques au Tableau des Scores",Xb:"Tr\u00e8s Long",zb:"Long",Hb:"Moyen",Ub:"Court",Yb:"Tr\u00e8s Court",qe:"Entrer dans le Monde Souterrain si HP >",Wg:"Vitesse de V\u00e9rification des Qu\u00eates",Og:'Par d\u00e9faut, c\'est "3x". Si le bot pose des probl\u00e8mes avec les qu\u00eates, changez la vitesse des qu\u00eates en fonction de la vitesse de votre serveur.',Xe:"S\u00e9lection du Sac de Soins",
re:"Si vous renouvelez manuellement les points, vous devez cliquer sur le bouton ci-dessus \"Actualiser l'exp\u00e9dition d'\u00e9v\u00e9nement si bloqu\u00e9e !",Dk:"Vous devez activer au moins l'une des options suivantes : exp\u00e9dition, donjon, ar\u00e8ne ou cirque pour commencer l'exp\u00e9dition d'\u00e9v\u00e9nement.",Yg:"Actualisez l'exp\u00e9dition d'\u00e9v\u00e9nement en cas de blocage !",kb:"Prot\u00e9ger les Alli\u00e9s ?",Vk:"Laissez tous les param\u00e8tres d\u00e9sactiv\u00e9s si vous souhaitez fondre en utilisant les paquets contenant les objets de la liste. Cependant, vous pouvez toujours choisir les couleurs.",
Ak:"Personnage(D\u00e9sactiv\u00e9) / Mercenaire(Activ\u00e9)",Rk:"R\u00e9parer les Deux ?",Wk:"Minuteries",Timers:"Entrez le nombre de minutes pour chaque minuteur ci-dessous ou laissez-le par d\u00e9faut.",nb:"Activer l'Attaque au Tableau des Scores:",Nb:"S\u00e9lectionner la Fourchette pour Attaquer",Ob:"Le bot attaquera al\u00e9atoirement depuis la liste du tableau des scores.",pb:"Attaque de Ligue",mb:"Activer l'Attaque de Ligue:",Jb:"Attaquer Al\u00e9atoirement",Kb:"Attaquer du plus bas au plus haut",
tk:"Le bot \u00e9vitera par d\u00e9faut d'attaquer les membres du gremio.",Me:"Lieu d'Exp\u00e9dition:",Md:"Collecter Automatiquement les Bonus:",zh:"Passer le Boss",ke:"Lieu de Donjon:",hh:"R\u00e9initialiser en cas de perte?",$e:"Param\u00e8tres de l'Enfer",af:"Configurez vos param\u00e8tres de pourcentage de gu\u00e9rison depuis l'onglet Gu\u00e9rison, et assurez-vous que l'interrupteur Gu\u00e9rison est activ\u00e9. Si l'entr\u00e9e dans le monde souterrain vous d\u00e9connecte, allez au lobby et activez la case \u00e0 cocher Connexion Automatique.",
Ye:"Difficult\u00e9 de l'Enfer",Pd:"Entrer Automatiquement dans l'Enfer: / Enfer Mode",yi:"Utiliser Mobilisation si les points = 0",Ci:"Utiliser les Rubis?",se:"Sortir du monde souterrain s'il n'y a plus de points?",ki:"Le bot essaiera d'abord d'utiliser Villa Medici, si vous ne l'avez pas, il utilisera la potion de gu\u00e9rison. N'oubliez pas d'activer l'interrupteur de Gu\u00e9rison.",ti:"L'entr\u00e9e automatique dans le monde souterrain d\u00e9sactivera le donjon/l'ar\u00e8ne/le cirque lors de l'entr\u00e9e dans le monde souterrain.",
Xk:"Param\u00e8tres de Gu\u00e9rison du Monde Souterrain",Bi:"Utiliser Villa Medici?",zi:"Utiliser la Potion de Gu\u00e9rison?",Yf:"INFO: Le bot recherchera les objets sur le march\u00e9 toutes les minutes s\u00e9lectionn\u00e9es, ce qui peut interrompre les attaques pendant la recherche.",oe:"Activer la Recherche sur le March\u00e9:",Zf:"Intervalle de Recherche sur le March\u00e9 en Minutes:",$f:"Sugg\u00e9r\u00e9: 10 minutes.",kf:"Param\u00e8tres de l'Objet:",hf:"Le Nom de l'Objet Inclut",G:"Prix Max",
lf:"Type d'Objet",jf:"Raret\u00e9 de l'Objet",Yd:"Acheter avec Lien d'\u00c2me?",nf:"Objets \u00e0 Acheter",mf:"Tentative d'achat d'objets avec des packs si l'un d'eux correspond au prix maximum indiqu\u00e9.:",Wd:"Objets Achet\u00e9s:",Tg:"Ignorer le Filtre de Qu\u00eates",Sg:"Saisissez des mots-cl\u00e9s pour filtrer les qu\u00eates que vous ne souhaitez pas accepter. You can also use this to accept quests by their reward using keywords.",V:"Saisir un Mot-cl\u00e9",I:"Ajouter",$g:"Supprimer",ae:"Effacer",
Qg:"Accepter le Filtre de Qu\u00eates",Rg:"Saisissez des mots-cl\u00e9s pour choisir les qu\u00eates \u00e0 accepter. Cela ignorera les types de qu\u00eates",Ca:"Ignorer les Qu\u00eates Temporelles ?",Pk:"Qu\u00eates",Nd:"Costume Automatique",xi:"Utiliser le Costume ?",Sd:"Combat de Base",je:"Combat en Donjon",Od:"Le bot ne portera Dis Pater Normal et Medium que si vos points d'exp\u00e9dition/donjon sont de 0.",Ze:"Param\u00e8tres de Gu\u00e9rison en Enfer",Ed:"Attaquer le Boss quand disponible ?",
qb:"L'attaque en Ligue se d\u00e9sactivera apr\u00e8s 5 attaques infructueuses.",bf:"Huiles Sacr\u00e9es",ug:"Nom de l'Objet",Z:"Niveau Minimum de l'Objet",Aa:"Qualit\u00e9 Minimum de l'Objet",Dd:"Appliquer/R\u00e9initialiser la Minuterie",ef:"Ignorer la Combinaison de Pr\u00e9fixe/Suffixe",Ei:"Oui",Bg:"Non",Oa:"Ajouter un Pr\u00e9fixe",Pa:"Ajouter un Suffixe",Bh:"Liste des Objets \u00e0 Ignorer pour la Fusion",Ib:"Pr\u00e9fixe",Vb:"Suffixe",gh:"R\u00e9initialiser les Objets Expir\u00e9s",Ch:"Fusionner au Hasard depuis les Paquets ?",
Dh:"Onglet Fusion",ob:"Extras",Id:"Ench\u00e8res",cg:"March\u00e9",Wb:"Minuteries",bi:"Fusion",ai:"Fusionner s'il n'y a pas assez d'or",Yh:"Fusionner s'il n'y a pas d'objet",Da:"R\u00e9paration",Qh:"Garder de l'Or sur le March\u00e9 de Guilde",Mh:"Garder de l'Or aux Ench\u00e8res",ei:"Entra\u00eenement",Th:"R\u00e9initialiser les Expir\u00e9s",ci:"Stockage \u00e0 la Forge",Kh:"V\u00e9rification des Ench\u00e8res",Vh:"Recherche",v:"Activer",wg:"Or Minimum",Qb:"S\u00e9lectionner une Heure",lb:"Donner de l'Or \u00e0 la Guilde",
ee:"Il donnera toutes les 5 minutes. Vous pouvez changer l'intervalle depuis l'onglet des minuteries",cf:"Combien souhaitez-vous donner ?",fe:"Donner lorsque vous avez plus de >",qf:"Moins de <",dh:"R\u00e9initialiser les Objets Expir\u00e9s et les Autres Param\u00e8tres",fh:"R\u00e9initialiser dans :",Jk:"Maintenez Ctrl (Cmd sur Mac) enfonc\u00e9 pour s\u00e9lectionner plusieurs objets",ff:"Import/Export des Param\u00e8tres",Oe:"Exporter les Param\u00e8tres",gf:"Importer les Param\u00e8tres",ng:"Message \u00e0 Tous les Joueurs",
og:"[N\u00e9cessite une Cl\u00e9 Ultra Premium, message sur Discord pour l'obtenir.]",pg:"Saisir le message \u00e0 envoyer",ce:"Pour des scripts personnalis\u00e9s, contactez-nous sur Discord",rg:"Envoyer",sg:"Afficher les Joueurs",qg:"Tout S\u00e9lectionner",tg:"Tout D\u00e9s\u00e9lectionner",pf:"Assurez-vous que votre inventaire ait suffisamment d'espace. Le temps de recharge est de 2 minutes.",gg:"Vendre de la Nourriture",Db:"Vendre de la Nourriture"},Nh={Fk:"Az exped\u00edci\u00f3s be\u00e1ll\u00edt\u00e1said helytelenek vagy v\u00e1ratlan oldaladatok vannak!",
Gk:"Az exped\u00edci\u00f3s be\u00e1ll\u00edt\u00e1sod helytelen! Letiltott sz\u00f6rnyet \u00e1ll\u00edtott\u00e1l be, ami helytelen.",Tk:"Csak az \u00f6sszes kiv\u00e1lasztott sz\u00edn\u0171 alvil\u00e1gi elemet \u00e1ll\u00edtsa vissza?",Ba:"Priorit\u00e9",Rb:"D\u00e9finir la Priorit\u00e9",Lg:"Points",Eh:"Stat",Mi:"Collect Gold",Jj:"Alvil\u00e1gi t\u00e1rgyakat eladni?",nj:"A bot minden m\u0171veletben f\u00e9szket keres, nem csak exped\u00edci\u00f3k sor\u00e1n.",lj:"F\u00e9szek keres\u00e9si t\u00edpus",
jj:"Ne csin\u00e1lj semmit",kj:"Gyors keres\u00e9s",mj:"Alapos keres\u00e9s",Bj:"After expedition points are consumed, travel to Germania to consume Dungeon points",sk:"Kattintson ide, ha a jav\u00edt\u00e1s beragad",Hg:"R\u00e9szleges Jav\u00edt\u00e1s",Ve:"Teljes Jav\u00edt\u00e1s",Gg:"R\u00e9szleges vagy Teljes Jav\u00edt\u00e1s",me:"Korl\u00e1t Enged\u00e9lyez\u00e9se",ej:"Korl\u00e1toz\u00e1s",fj:"Ha korl\u00e1tozni szeretn\u00e9d a t\u00e1mad\u00e1sok sz\u00e1m\u00e1t az ellens\u00e9gre, enged\u00e9lyezd ezt az opci\u00f3t \u00e9s \u00e1ll\u00edtsd be a korl\u00e1tot. A bot folytatja a t\u00e1mad\u00e1st a t\u00f6bbi ellens\u00e9ggel, miut\u00e1n befejezte a kiv\u00e1lasztott sz\u00f6rny elleni t\u00e1mad\u00e1sokat.",
he:"Ne l\u00e9pj be az alvil\u00e1gba alvil\u00e1gi jelmezben",ge:"Ha nem akarsz alvil\u00e1gi jelmezben az alvil\u00e1gba l\u00e9pni, enged\u00e9lyezd ezt az opci\u00f3t",si:"Alvil\u00e1g",ji:"Alvil\u00e1gi Buffok",li:"Haszn\u00e1ld az istenek erej\u00e9t az alvil\u00e1gba l\u00e9p\u00e9s ut\u00e1n?",mi:"V\u00e1laszd ki az isteneket, akikt\u0151l er\u0151t szeretn\u00e9l nyerni:",ni:"Haszn\u00e1lj fegyver er\u0151s\u00edt\u00e9st a fegyveren?",oi:"Haszn\u00e1lj p\u00e1nc\u00e9l er\u0151s\u00edt\u00e9st a k\u00f6vetkez\u0151 felszerel\u00e9sen:",
Ck:"A leh\u0171l\u00e9si id\u0151 30 perc. Ha nincs rajtad jelmez, a bot null\u00e1zza a leh\u0171l\u00e9si id\u0151t.",Uk:"Sz\u00ednek kiv\u00e1laszt\u00e1sa",Ya:"Vulcanus Kov\u00e1csm\u0171helye",bb:"Feronia F\u00f6ldi Pajzsa",cb:"Neptunusz Foly\u00e9kony Ereje",eb:"Aelous L\u00e9gies Szabads\u00e1ga",fb:"Pl\u00fat\u00f3 Hal\u00e1los K\u00f6de",gb:"Juno \u00c9let Lehelete",hb:"Harag Hegyeinek Pikkelyes P\u00e1nc\u00e9lja",ib:"Sas Szemei",jb:"Saturnusz T\u00e9li \u00d6lt\u00f6z\u00e9ke",Za:"Bubona Bikap\u00e1nc\u00e9lja",
$a:"Mercerius Rabl\u00f3ruh\u00e1i",ab:"Ra F\u00e9nyk\u00f6nt\u00f6se",fg:"Csomagok",ag:"K\u00e9szlet",K:"Min. \u00c1r",J:"H\u00e1ny darab",Cb:"T\u00e1rgyak Elad\u00e1sa",Bb:"Keres\u00e9s ebben",bg:"Anyag Sz\u00edne",Ab:"T\u00e1rgy Sz\u00edne",ig:"Rakt\u00e1r",za:"V\u00e1lt\u00e1s Anyagokra",Eb:"V\u00e1lt\u00e1s T\u00e1rgyakra",hg:"Anyagok Elad\u00e1sa",wa:"K\u00e9rj\u00fck, adjon meg \u00e9rv\u00e9nyes t\u00e1rgyn\u00e9v, \u00e1rfekv\u00e9s \u00e9s mennyis\u00e9get.",xa:"Nincsenek megfelel\u0151 t\u00e1rgyak a kiv\u00e1lasztott keres\u00e9si helyeken.",
ya:"Minden t\u00e1rgy sikeresen list\u00e1zva!",Nk:"Minden anyag sikeresen list\u00e1zva!",dg:"Ha fix \u00e1ron szeretne t\u00e1rgyakat eladni, ugyanazt az \u00e9rt\u00e9ket adja meg a min \u00e9s max \u00e1rra.",eg:"Ez a funkci\u00f3 m\u00e9g k\u00eds\u00e9rleti, \u00f3vatosan haszn\u00e1lja. Ha nem ad meg fix \u00e1rat, az elemek v\u00e9letlenszer\u0171en ker\u00fclnek list\u00e1z\u00e1sra a megadott minimum \u00e9s maximum \u00e1r k\u00f6z\u00f6tt.",yk:"Be\u00e1ll\u00edtja a maxim\u00e1lis aranyat, amit a bot egy ciklusban elk\u00f6lt.",
Ta:"A bot licit\u00e1lni kezd minden \u00e9tel t\u00e1rgyra, ha enged\u00e9lyezve van. Nem kell enged\u00e9lyezned a gladi\u00e1tor/zsoldos kapcsol\u00f3kat.",Gd:"A bot nem licit\u00e1l az sz\u00f6vets\u00e9gesei licitjeire.",Hd:"Figyelmen k\u00edv\u00fcl hagyja az El\u0151tag/Ut\u00f3tag kombin\u00e1ci\u00f3t t\u00e1rgy keres\u00e9sekor az aukci\u00f3n.",Qj:"V\u00e1laszd ki azokat a t\u00e1rgyt\u00edpusokat, amelyeket be akarsz olvasztani.",Rj:"V\u00e1laszd ki azokat a sz\u00edneket, amelyeket be akarsz olvasztani.",
Sj:"V\u00e1laszd ki az t\u00e1rgyak szintj\u00e9t, amelyeket be akarsz olvasztani.",Tj:"V\u00e1laszd ki a kalap\u00e1csot, amit haszn\u00e1lni szeretn\u00e9l.",Uj:"Figyelj arra, hogy az els\u0151 mez\u0151 melletti z\u00f6ld \u00e9s piros k\u00f6r a szab\u00e1ly enged\u00e9lyez\u00e9s\u00e9hez/letilt\u00e1s\u00e1hoz van.",Vj:"Ha v\u00e9letlenszer\u0171en szeretn\u00e9l beolvasztani b\u00e1rmilyen sz\u00ednt vagy t\u00edpust, enged\u00e9lyezheted a `V\u00e9letlenszer\u0171en beolvasztani, ha nincsenek felt\u00e9telek teljes\u00edtve? (A tutorial vide\u00f3ban utolj\u00e1ra enged\u00e9lyezett opci\u00f3)",
Fj:"R\u00e9parer avant la Fusion",Ie:"Sz\u00f6rny Kiv\u00e1laszt\u00e1sa",we:"Homok\u00f3ra/Rubin Haszn\u00e1lata?",Ek:"Rubin Haszn\u00e1lata?",ze:"Mozg\u00f3s\u00edt\u00e1s Haszn\u00e1lata?",ye:"\u00c9letital Haszn\u00e1lata?",ve:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9ka (%)",Ge:"T\u00e1mad\u00e1sok Sz\u00e1ma",xe:"T\u00e1mad\u00e1si Id\u0151k\u00f6z (m\u00e1sodpercben)",te:"V\u00e9grehajtott T\u00e1mad\u00e1sok",ue:"H\u00e1tral\u00e9v\u0151 Homok\u00f3ra",Ee:"Megjegyz\u00e9s: \u00c9leter\u0151-p\u00f3ci\u00f3kat haszn\u00e1l gy\u00f3gy\u00edt\u00e1sra, nem \u00e9telt.",
Fe:"Megjegyz\u00e9s: Ha a t\u00e1mad\u00e1sok id\u0151 el\u0151tt meg\u00e1llnak, pr\u00f3b\u00e1lja meg az 'T\u00e1mad\u00e1sok Vissza\u00e1ll\u00edt\u00e1sa' opci\u00f3t.",Je:"Ind\u00edt\u00e1s",He:"Vissza\u00e1ll\u00edt\u00e1s",Ke:"Le\u00e1ll\u00edt\u00e1s",Le:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sai (Kattintson minimaliz\u00e1l\u00e1shoz)",Ae:"Sz\u00f6rny 1",Be:"Sz\u00f6rny 2",Ce:"Sz\u00f6rny 3",De:"Sz\u00f6rny 4",Qk:"R\u00e9parer avant la Fusion",Ki:"Ez az opci\u00f3 haszn\u00e1lja a cervisia-t, amikor lej\u00e1r a pr\u00e9mium tags\u00e1god.",
qj:"Ez az opci\u00f3 aktiv\u00e1lja \u00e9s v\u00e1laszt olajokat az istenek jutalmai k\u00f6z\u00fcl. Haszn\u00e1lhatja az 1. \u00e9s 3. sz\u00e1m\u00fa olajokat a karakteren, de a 2. sz\u00e1m\u00fa csak csomagokba ker\u00fcl.",Ii:"Ez az opci\u00f3 a be\u00e1ll\u00edtott id\u0151ben haszn\u00e1lja a buffokat. Megkeresi a csomagokban l\u00e9v\u0151 buffokat \u00e9s alkalmazza \u0151ket a karakteren.",gj:"Ez az opci\u00f3 bevisz az alvil\u00e1gba. Ne felejtsd el enged\u00e9lyezni az Auto Bejelentkez\u00e9st az Extra f\u00fcl\u00f6n, k\u00fcl\u00f6nben kijelentkezhetsz az alvil\u00e1gba l\u00e9p\u00e9skor [J\u00e1t\u00e9k Hiba]",
Zb:"A bot norm\u00e1lis esetben v\u00e9letlenszer\u0171en v\u00e1laszt 3-6 pr\u00f3b\u00e1t az ar\u00e9nalista megt\u00e1mad\u00e1s\u00e1ra. Ha enged\u00e9lyezed ezt az opci\u00f3t, v\u00e9gigmegy a list\u00e1don, am\u00edg meg nem t\u00e1madhat valakit. Ez eltarthat egy kis id\u0151t.",Cj:"Ez az opci\u00f3 csak pr\u00e9mium licencek sz\u00e1m\u00e1ra van. Szimul\u00e1l egy t\u00e1mad\u00e1st egy felhaszn\u00e1l\u00f3 ellen 75%-os gy\u0151zelmi r\u00e1t\u00e1val, miel\u0151tt megt\u00e1madn\u00e1.",
Jd:"Nem kell enged\u00e9lyezned a f\u0151 aukci\u00f3 kapcsol\u00f3t, hogy ezt az opci\u00f3t haszn\u00e1lhasd.",kk:"Ez az opci\u00f3 m\u00e1sodpercenk\u00e9nt friss\u00edti az oldalt, amikor az aukci\u00f3 -Nagyon R\u00f6vid- \u00e1llapotban van, hogy folyamatosan licit\u00e1ljon \u00e9s megnyerje az aukci\u00f3t.",Oj:"Ha egyik olvaszt\u00e1si felt\u00e9tel sem teljes\u00fcl, akkor v\u00e9letlenszer\u0171en olvaszt. Gy\u0151z\u0151dj meg r\u00f3la, hogy v\u00e1lasztott\u00e1l t\u00e1rgyt\u00edpust \u00e9s sz\u00ednt.",
Pj:"Ez az opci\u00f3 csak a lelt\u00e1rban l\u00e9v\u0151 t\u00e1rgyakat olvasztja. A csomagokban l\u00e9v\u0151 t\u00e1rgyakat figyelmen k\u00edv\u00fcl hagyja.",Ua:"Aukci\u00f3s T\u00e1rgyak",lg:"Zsoldos T\u00e1rgyak",Tb:"Bolt T\u00e1rgyak",ui:"Egyedi T\u00e1rgyak",Kj:"H\u00e1tt\u00e9r be\u00e1ll\u00edt\u00e1sa feket\u00e9re [N\u00f6veli a teljes\u00edtm\u00e9nyt]",Lj:"GLDbot gombok \u00e1thelyez\u00e9se a bal als\u00f3 sarokba?",Li:"Cirkusz T\u00e1mad\u00e1s Gy\u00f3gy\u00edt\u00e1s N\u00e9lk\u00fcl",
jk:"Sz\u00fcks\u00e9g eset\u00e9n vegy\u00fcnk ki aranyat a csomagokb\u00f3l?",Tl:"Az edz\u00e9shez aranyat vettek a csomagokb\u00f3l",Ad:"Nem tal\u00e1ltak aranyat a csomagokban az edz\u00e9shez",gk:"Jav\u00edtott T\u00e1rgyak",$j:"Ar\u00e9na T\u00e1mad\u00e1sok",bk:"Cirkusz T\u00e1mad\u00e1sok",zd:"T\u00e1rgyak Vissza\u00e1ll\u00edtva",ek:"Exped\u00edci\u00f3s T\u00e1mad\u00e1sok",dk:"Kazamata T\u00e1mad\u00e1sok",hk:"Alvil\u00e1gi T\u00e1mad\u00e1sok",ak:"Ar\u00e9n\u00e1ban Szerzett P\u00e9nz",
ck:"Cirkuszban Szerzett P\u00e9nz",Rl:"Olvasztott T\u00e1rgyak",fk:"\u00dajrahasznos\u00edtott Arany",Yi:"C\u00e9h Csata",$i:"C\u00e9h Be\u00e1ll\u00edt\u00e1sok",Zi:"C\u00e9h N\u00e9v",Xi:"V\u00e9letlenszer\u0171 C\u00e9h T\u00e1mad\u00e1s",ll:"V\u00e9letlenszer\u0171en t\u00e1madja a c\u00e9heket.",Ji:"Statisztik\u00e1k Vissza\u00e1ll\u00edt\u00e1sa",wl:'GLDbot: A kock\u00e1k seg\u00edts\u00e9g\u00e9vel friss\u00edtse a rejt\u00e9lydobozt, \u00e9s tal\u00e1ljon \u00e9rt\u00e9kes t\u00e1rgyakat, miel\u0151tt kinyitn\u00e1 azokat (stb. jelmezek). Kattintson a "Start" gombra, nyissa meg a l\u00e1d\u00e1kat.',
Kc:"Wood",Ac:"Copper",Ec:"Iron",Gc:"Leather",Lc:"Wool",Bc:"Cotton Wool",Dc:"Hemp",Cc:"Gauze Strip",Hc:"Linen Strip",Fc:"Jute Patch",Jc:"Velvet",Ic:"Silk Thread",Tc:"Fur",Nc:"Bone Splinter",Wc:"Scale",Qc:"Claw",Sc:"Fang",Rc:"Dragon Scale",Oc:"Bull`s Horn",Vc:"Poison Gland",Pc:"Cerberus` Pelt",Uc:"Hydra Scale",Xc:"Sphinx Feather",Yc:"Typhon Leather",wc:"Lapis Lazuli",qc:"Amethyst",pc:"Amber",rc:"Aquamarine",xc:"Sapphire",uc:"Garnet",tc:"Emerald",sc:"Diamond",vc:"Jasper",yc:"Sugilite",kc:"Scorpion Poison",
nc:"Tincture of Stamina",fc:"Antidote",ec:"Adrenaline",mc:"Tincture of Enlightenment",jc:"Potion of Perception",hc:"Essence of Reaction",ic:"Phial of Charisma",oc:"Waters of Oblivion",lc:"Soul Essence",xd:"Water Seal",rd:"Protection Rune",pd:"Earth Mark",wd:"Totem of Healing",vd:"Talisman of Power",td:"Stone of Fortune",qd:"Flintstone",ud:"Storm Rune",sd:"Shadow Rune",cd:"Crystal",bd:"Bronze",gd:"Obsidian",kd:"Silver",ld:"Sulphur",ed:"Gold Ore",jd:"Quartz",hd:"Platinum",ad:"Almandin",dd:"Cuprit",
fd:"Hellstone",Fi:"T\u00e1mad\u00e1s v\u00e9letlenszer\u0171en?",Gi:'Kapcsold ki a "J\u00e1t\u00e9kosok rendez\u00e9se az ar\u00e9n\u00e1ban szint szerint" be\u00e1ll\u00edt\u00e1st a crazy-addonban is.',Ug:"Csak az isten t\u00edpus\u00e1n alapul\u00f3 k\u00fcldet\u00e9seket fogadja el.",Va:"Automatikus Buff",Xd:"Csak a pokolban haszn\u00e1lja?",Ag:"\u00daj Szab\u00e1ly",yg:"N\u00e9v Tartalmazza",isUnderworldItem:"Ez egy alvil\u00e1gi t\u00e1rgy?",df:"Anyagok Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
rk:"Utiliser la Pri\u00e8re ?",Ai:"Utiliser le Sacrifice ?",mk:"Utiliser le tissu pour entrer dans le monde souterrain ?",ri:"A m\u00e9lyvil\u00e1gban csak a m\u00e9lyvil\u00e1ggal kapcsolatos k\u00fcldet\u00e9seket fogadja el?",pi:"Ha enged\u00e9lyezve van, meg kell adnia a m\u00e9lyvil\u00e1gi t\u00e1rgyak nev\u00e9t. Ha a bot megtal\u00e1lja ezeket a t\u00e1rgyakat a m\u00e9lyvil\u00e1gban, elfogadja a k\u00fcldet\u00e9st.",Yk:"M\u00e9lyvil\u00e1gi K\u00fcldet\u00e9s T\u00e1rgy",il:"Entrez le Nom du Mat\u00e9riel",
Bk:"A robot im\u00e1dja a kock\u00e1kat! Seg\u00edtenek ruh\u00e1t tal\u00e1lni a l\u00e1d\u00e1kban. De ha nincs kocka, a robot akkor is kinyitja a l\u00e1d\u00e1kat, rem\u00e9lve, hogy tal\u00e1l valami men\u0151 ruh\u00e1t (de lehet, hogy semmit sem tal\u00e1l!)",Nj:"Fusionner les Bo\u00eetes de Butin ?",le:"Enable Arena",Mg:"Prioriz\u00e1lja az ar\u00e9na list\u00e1t?",Ng:"Prioriz\u00e1lja a cirkusz list\u00e1t?",de:"Napl\u00f3 men\u00fc letilt\u00e1sa",ih:"Jutalom Min. Arany \u00c9rt\u00e9k",
Vg:"Ha enged\u00e9lyezve van, a K\u00fcldet\u00e9s F\u00f3kusz a legr\u00f6videbb utat k\u00f6veti a dungeon befejez\u00e9s\u00e9hez.",Hh:"Dobja a kock\u00e1t automatikusan?",Ih:"Vigy\u00e1zva haszn\u00e1lja a dob\u00f3 kock\u00e1t, folyamatosan az els\u0151 kock\u00e1t fogja haszn\u00e1lni, am\u00edg ki nem kapcsolja az opci\u00f3t.",nh:"Keres\u00e9s folyamatban",bh:"A jav\u00edt\u00e1s alap\u00e9rtelmezett leh\u0171l\u00e9se 10 perc.",vg:"Minim\u00e1lis \u00c1llapot",be:"Aktu\u00e1lis t\u00e9tel a munkapadon [T\u00f6r\u00f6lje, ha a bot v\u00e1ratlanul sz\u00fcnetelt]",
Af:"Kov\u00e1csolt er\u0151forr\u00e1sok sikeresen elmentve a horreumhoz.",wf:"Piac ellen\u0151rz\u00e9se t\u00e1rgyak sz\u00e1m\u00e1ra...",yb:"T\u00e9tel \u00e1thelyezve a munkapadra.",Nf:"T\u00e9tel sikeresen jav\u00edtva \u00e9s felszerelve.",Of:"T\u00e9tel sikeresen jav\u00edtva.",Lk:"A jav\u00edt\u00e1s sikertelen. Az oldal friss\u00edt\u00e9sre ker\u00fcl.",Kf:"Anyagok felv\u00e9tele...",Xf:"V\u00e1rakoz\u00e1s a jav\u00edt\u00e1sra...",Mf:"Jav\u00edt\u00e1s elindult: .",va:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa az invent\u00e1riumb\u00f3l a t\u00e1sk\u00e1ba",
Lf:"Jav\u00edt\u00e1s: T\u00e9tel mozgat\u00e1sa a munkapadra a csomagol\u00f3ba.",ta:"Nem tal\u00e1lhat\u00f3 elegend\u0151 anyag. A jav\u00edt\u00e1si hely le lesz tiltva ",Hf:"T\u00e1rgyak keres\u00e9se arany elrejt\u00e9s\u00e9re az aukci\u00f3ban...",tf:"Lej\u00e1rt t\u00e1rgyak ellen\u0151rz\u00e9se a csomagokban...",uf:"T\u00e9tel sikeresen vissza\u00e1ll\u00edtva.",vf:"Nincs \u00fcres hely vagy arany a vissza\u00e1ll\u00edt\u00e1shoz.",Bf:"Gy\u0151z\u0151dj\u00f6n meg arr\u00f3l, hogy van elad\u00e1si joga a c\u00e9hes piacon!",
sb:"Nincs el\u00e9g arany/vagy nincs meg a v\u00e1s\u00e1rl\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s a friss\u00edt\u00e9shez.",ub:"A bolt friss\u00edtve lett.",vb:"Hiba t\u00f6rt\u00e9nt a gy\u00f3gyul\u00e1s k\u00f6zben.",Ef:"Nincs Ruby vagy Cloth, letilt\u00e1sa az opci\u00f3knak.",Kk:"Nincs gy\u00f3gy\u00edt\u00f3 t\u00e1rgy a csomagokban.",wb:"Nem tal\u00e1lhat\u00f3 megfelel\u0151 t\u00e1rgy",Ff:"Az \u00e9lelmiszereket felvett\u00e9k. A folyamat v\u00e9get \u00e9rt.",Gf:"Legal\u00e1bb egy \u00e9tel felv\u00e9telre ker\u00fclt. A folyamat v\u00e9get \u00e9rt.",
xb:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",Cf:"\u00c9telek felv\u00e9tele a csomagokb\u00f3l.",Df:"Nincs megfelel\u0151 hely a t\u00e1sk\u00e1ban az \u00e9tel felv\u00e9tel\u00e9hez.",tb:"Nincs t\u00f6bb gy\u00f3gy\u00edt\u00f3 t\u00e1rgy. 30 m\u00e1sodperc v\u00e1rakoz\u00e1s.",rb:"\u00c9P helyre\u00e1ll\u00edtva.",ua:"Nincs teend\u0151, ez\u00e9rt im\u00e1dkozom!",Tf:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem \u00e9s a Villa Medici ellen\u0151rz\u00e9s\u00e9re.",
Uf:"V\u00e1rakoz\u00e1s a Villa Medici-re, friss\u00edt\u00e9s 60 m\u00e1sodperc m\u00falva.",Vf:"Elhagytam az alvil\u00e1got.",Wf:"Friss\u00edt\u00e9s indul 60 m\u00e1sodperc m\u00falva az \u00e9n eg\u00e9szs\u00e9gem ellen\u0151rz\u00e9s\u00e9re.",If:"Isteni olajok ellen\u0151rz\u00e9se...",Jf:"Isteni olajok felv\u00e9ve.",ra:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen AZ AR\u00c9N\u00c1BAN: ",sa:"Sikeres t\u00e1mad\u00e1s a j\u00e1t\u00e9kos ellen A CIRKUSZBAN: ",rf:"Aukci\u00f3 ellen\u0151rz\u00e9se! K\u00e9rem v\u00e1rjon...",
sf:"T\u00e1rgyak licit\u00e1l\u00e1sa. K\u00e9rem v\u00e1rjon...",Pf:"Automatikus olvasztott t\u00e9tel: ",Qf:"Olvaszt\u00e1s alatt \u00e1ll\u00f3 t\u00e9tel: ",Rf:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges arany: ",Sf:"OLVASZT\u00c1S: T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",Mk:"T\u00e1rgyak keres\u00e9se az olvaszt\u00e1shoz...",xf:"Koszt\u00fcm\u00f6k el\u00e9rhet\u0151s\u00e9g\u00e9nek ellen\u0151rz\u00e9se...",zf:"Adom\u00e1nyozva: ",yf:"Kocka dob\u00e1sa...",
Re:"Underworld Farm [Manual, Beta]",Qe:"Farm Location",Se:"Figyelem: Kapcsolja be ezt a funkci\u00f3t a t\u00e1madni k\u00edv\u00e1nt l\u00e9ny felold\u00e1sa ut\u00e1n, nem fog automatikusan t\u00e1madni, hogy feloldja a sz\u00f6rnyet.",Pe:"Farm Enemy",Qd:"Automatikus Bejelentkez\u00e9s",Rd:"Enged\u00e9lyezned kell a felugr\u00f3 ablakokat a GameForge el\u0151csarnok k\u00e9perny\u0151j\u00e9r\u0151l. N\u00e9zd meg a dokument\u00e1ci\u00f3t, hogy hogyan tedd meg.",Ig:"Bot Sz\u00fcneteltet\u00e9se",
Jg:"Bot sz\u00fcneteltet\u00e9se ennyi id\u0151re: (Perc)",Ne:"Lej\u00e1rati D\u00e1tum",Dg:"Csak \u00e9telt v\u00e1s\u00e1rolj?",Eg:"Ha ezt enged\u00e9lyezed, a bot figyelmen k\u00edv\u00fcl hagyja a kiv\u00e1laszt\u00e1saidat, \u00e9s automatikusan v\u00e1s\u00e1rol \u00e9telt an\u00e9lk\u00fcl, hogy b\u00e1rmit be\u00edrn\u00e1l.",Gb:"Maxim\u00e1lis \u00f6sszes arany kiad\u00e1s",Fb:"Maxim\u00e1lis arany \u00e9telenk\u00e9nti kiad\u00e1s",Cg:"A bot 60 percenk\u00e9nt ellen\u0151rzi az olajokat",
$h:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a olvaszt\u00e1si id\u0151k ellen\u0151rz\u00e9s\u00e9hez.",Xh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs aranyad.",Zh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az olvaszt\u00e1s ellen\u0151rz\u00e9s\u00e9hez, ha nincs el\u00e9rhet\u0151 t\u00e1rgyad.",Sh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a t\u00e1rgyak jav\u00edt\u00e1s\u00e1hoz \u00e9s ellen\u0151rz\u00e9s\u00e9hez.",
Rh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a guild piac\u00e1nak arany\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Nh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az aukci\u00f3 arany tart\u00e1si lehet\u0151s\u00e9g\u00e9hez.",Jh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t az ar\u00e9na PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",Oh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a cirkusz PvP lista ellen\u0151rz\u00e9s\u00e9hez t\u00e1mad\u00e1s c\u00e9lj\u00e1b\u00f3l.",
fi:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a statisztik\u00e1k tr\u00e9ningez\u00e9s\u00e9hez.",Uh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a lej\u00e1rt t\u00e1rgyak vissza\u00e1ll\u00edt\u00e1s\u00e1hoz.",di:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a kov\u00e1csol\u00f3 anyagok t\u00e1rol\u00e1s\u00e1hoz a horreum-ban.",Lh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t a gladi\u00e1torok \u00e9s zsoldosok aukci\u00f3j\u00e1nak ellen\u0151rz\u00e9s\u00e9hez.",Wh:"Be\u00e1ll\u00edt egy id\u0151z\u00edt\u0151t t\u00e1rgyak keres\u00e9s\u00e9hez az aukci\u00f3ban \u00e9s a boltban.",
Ph:"Be\u00e1ll\u00edtja a guild adom\u00e1ny k\u00fcld\u00e9s\u00e9nek id\u0151z\u00edt\u0151j\u00e9t.",We:"Arany Mozgatva",ie:"Ne adjon el az \u00f6sszeoml\u00e1si \u00e9s aukci\u00f3s list\u00e1n szerepl\u0151 t\u00e9teleket",oh:"Bolt Automatiz\u00e1l\u00e1s",qh:"T\u00e1rgy Keres\u00e9s Be\u00e1ll\u00edt\u00e1sok",ph:"Haszn\u00e1lja ezt az eszk\u00f6zt t\u00e1rgyak keres\u00e9s\u00e9hez. Egyszer\u0171en adjon hozz\u00e1 t\u00e1rgyakat a list\u00e1hoz, hat\u00e1rozza meg a ruha mennyis\u00e9g\u00e9t, majd ind\u00edtsa el a keres\u00e9st.",
rh:"Haszn\u00e1lni k\u00edv\u00e1nt Ruha:",th:"H\u00e1ny ruh\u00e1t haszn\u00e1ljon?",ea:"Full Adja meg a T\u00e1rgy Nev\u00e9t",Sb:"Adja meg a T\u00e1rgy Szintj\u00e9t",vh:"T\u00e1rgy Min\u0151s\u00e9ge",uh:"T\u00e1rgy Neve Itt",wh:"Keres\u00e9s Ind\u00edt\u00e1sa",xh:"\u00c1tugr\u00e1s \u00e9s Folytat\u00e1s",yh:"Keres\u00e9s Le\u00e1ll\u00edt\u00e1sa",Te:"Guild Piac Rendez\u00e9se",xg:"Legdr\u00e1g\u00e1bb",Zd:"Legolcs\u00f3bb",ba:"V\u00e1lasszon egy lehet\u0151s\u00e9get",ne:"Mettre en surbrillance les objets du monde souterrain",
Ue:"F\u00f3kuszban a k\u00fcldet\u00e9sre?",jq:"Haszn\u00e1ljon rubint, ha nincs ruha?",Wa:"Ker\u00fclje azonos szem\u00e9lyek megt\u00e1mad\u00e1s\u00e1t, hogy elker\u00fclje a jelent\u00e9st\u00e9tel\u00e9t. A jelent\u00e9s megn\u00f6veli a kitilt\u00e1s es\u00e9ly\u00e9t.",Kl:"Olvad a z\u00f6ld?",Pg:"Ne fogadja el a v\u00e9letlenszer\u0171 k\u00fcldet\u00e9seket, ha b\u00e1rmilyen sz\u0171r\u0151t megadott?",Mc:"Maxim\u00e1lis haszn\u00e1lhat\u00f3 anyagmin\u0151s\u00e9g",Ui:"Enged\u00e9lyezze a zsoldos keres\u00e9st",
sl:'Kattints a "Minden Kiv\u00e1lasztott Elad\u00e1sa" gombra az \u00f6sszes t\u00e9tel elad\u00e1s\u00e1hoz. Gy\u0151z\u0151dj meg r\u00f3la, hogy az els\u0151 (1) t\u00e1sk\u00e1dban van el\u00e9g 2x3 \u00fcres hely. Az arany t\u00f6meges gy\u0171jt\u00e9s\u00e9hez sz\u0171rd ki az aranyat, \u00e9s haszn\u00e1ld a "Kiv\u00e1lasztott vagy Mindet Kiv\u00e1laszt" lehet\u0151s\u00e9get.',Zj:"\ud83d\udd25 : Hozz\u00e1adja az elemet a koh\u00e1szati list\u00e1hoz.",Hi:"\ud83d\udd28 : Hozz\u00e1adja az elemet az \u00e1rver\u00e9si list\u00e1hoz.",
Ej:"Friss\u00edtsd a boltot anyaggal, amikor tele van",sj:"Oldal:",zj:"Meg\u00e1ll\u00edt",xj:"Elad\u00e1s Ezen az Oldalon",uj:"Kiv\u00e1lasztott Kiv\u00e1laszt\u00e1sa",tj:"Mindent Kiv\u00e1laszt",Aj:"Automatikus Csomagol\u00e1si Be\u00e1ll\u00edt\u00e1sok",yj:"Er\u0151forr\u00e1sok K\u00fcld\u00e9se",vj:"Minden Kiv\u00e1lasztott Elad\u00e1sa",ma:"T\u00e9tel T\u00edpusa",oa:"Fegyverek",S:"Pajzsok",M:"P\u00e1nc\u00e9lok",P:"Sisakok",O:"Keszty\u0171k",N:"Csizm\u00e1k",na:"Gy\u0171r\u0171k",ka:"Amulettek",
Ia:"Haszn\u00e1lati T\u00e1rgyak (\u00c9telek)",Na:"Fejleszt\u00e9sek",rj:"Er\u0151s\u00edt\u00e9sek",Ka:"Receptek",Ja:"Zsoldosok",Ma:"Kov\u00e1csol\u00f3 Eszk\u00f6z\u00f6k",La:"Pergamenek",od:"Er\u0151s\u00edt\u00e9sek",md:"Esem\u00e9ny T\u00e1rgyak",nd:"Kov\u00e1csol\u00e1shoz Val\u00f3 T\u00e1rgyak",zl:"Arany",Ha:"Minden",Al:"Min\u0151s\u00e9g",pa:"Feh\u00e9r",C:"Z\u00f6ld",B:"K\u00e9k",D:"Lila",H:"Narancss\u00e1rga",R:"Piros",wj:"Az \u00d6sszes Elad\u00e1si Be\u00e1ll\u00edt\u00e1s",Mj:"Elhanyagolja a El\u0151tag / Ut\u00f3tag Kombin\u00e1ci\u00f3t?",
aj:"H\u00e1ny \u00e9telt vegy\u00e9l/fogj fel?",Pi:"Norm\u00e1l",Oi:"K\u00f6zepes",Ni:"Neh\u00e9z",Ea:"Alap",Dl:"Ragadt Megjav\u00edt\u00e1s",Ik:"Kapcsold ki a Pokol Bel\u00e9p\u00e9s\u00e9t, ha letiltan\u00e1d a Dungeon/Circus/Arena-t. Ha k\u00e9zzel l\u00e9pt\u00e9l be a Pokolba, akkor enged\u00e9lyezned kell a Pokol M\u00f3dot.",$d:"V\u00e1lassz alvil\u00e1gi jelmezt",Di:"Viselj alvil\u00e1gi jelmezt, ha el\u00e9rhet\u0151?",ii:"K\u00e9pz\u00e9si \u00fatmutat\u00f3: Hat\u00e1rozza meg, h\u00e1nyszor szeretn\u00e9 edzeni a statisztik\u00e1kat, \u00e9s \u00e1ll\u00edtsa be priorit\u00e1saikat. A bot nem fog edzeni, hacsak nincs be\u00e1ll\u00edtva egy priorit\u00e1s. Ha van be\u00e1ll\u00edtott priorit\u00e1s, de nincs t\u00f6bb k\u00e9pzend\u0151 statisztika, a bot a kiv\u00e1lasztott statisztik\u00e1val folytatja.",
el:"Quest",Il:"Olvaszt\u00e1s",Ol:"Olvaszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Wj:"Olvasztott T\u00e1rgyak",Pl:"Adj hozz\u00e1 el\u0151tagot vagy ut\u00f3tagot, amint megtal\u00e1lja a csomagokban, aut\u00f3matikusan olvasztani fogja.:",Nl:"Olvasztand\u00f3 T\u00e1rgy:",bc:"Kattints a t\u00e1rgyra, amelyet meg akarsz jav\u00edtani. Ez a rendszer megjav\u00edtja a k\u00e9t f\u0151 karaktered t\u00e1rgyait ( AR\u00c9NA/CT). Legal\u00e1bb 10000 aranyra van sz\u00fcks\u00e9g a jav\u00edt\u00e1s elind\u00edt\u00e1s\u00e1hoz. Ha egy t\u00e1rgy beragad, az azt jelenti, hogy nincs anyagod a jav\u00edt\u00e1shoz. Pr\u00f3b\u00e1lj szabad helyet k\u00e9sz\u00edteni a t\u00e1sk\u00e1dban. A bot akkor kezdi meg a jav\u00edt\u00e1st, amikor a t\u00e9tel tart\u00f3ss\u00e1ga %0.",
Zk:"Csak Zsoldosra alkalmaz",bl:"Aukci\u00f3 csak akkor licit\u00e1l, ha a lej\u00e1rati id\u0151 k\u00f6zel van a v\u00e9g\u00e9hez.",al:"Gy\u0151z\u0151dj meg arr\u00f3l, hogy a 2. lelt\u00e1r f\u00fcl \u00fcres \u00e9s rendelkezik 10K arannyal. A bot megtal\u00e1lja \u00e9s a m\u00e1sodik f\u00fclre helyezi a t\u00e1rgyat, majd legk\u00f6zelebb az oldal friss\u00edt\u00e9se ut\u00e1n olvasztja a t\u00e1rgyat. Az olvaszt\u00e1st minden 5-10 percen bel\u00fcl \u00fajraellen\u0151rzi.",dj:"Gy\u00f3gy\u00edt\u00e1s & Buffs",
El:"Nincs el\u00e9g arany az olvaszt\u00e1shoz. Sz\u00fcks\u00e9ges Arany:",Hl:"Licit kihagy\u00e1sa: Egyes\u00fclet tag m\u00e1r licit\u00e1lt a t\u00e1rgyra ",Gl:"Licit kihagy\u00e1sa: M\u00e1r licit\u00e1lt a t\u00e1rgyra ",advanced:"Halad\u00f3",arena:"Ar\u00e9na",ia:"Aut\u00f3matikus T\u00e1mad\u00e1s",$b:"T\u00e1mad\u00e1s Elker\u00fcl\u00e9se",ga:"J\u00e1t\u00e9kos Hozz\u00e1ad\u00e1sa",ha:"Add hozz\u00e1 a j\u00e1t\u00e9kos nev\u00e9t (Same Server)",nl:"Meg\u00e1ll\u00edtja a bot, ha elfogyott az \u00e9tel?",
circusTurma:"Circus Turma",Qi:"Neh\u00e9zs\u00e9g",dungeon:"Kazamata",Ri:"Kazamata Be\u00e1ll\u00edt\u00e1sok",eventExpedition:"Esem\u00e9ny Exped\u00edci\u00f3",expedition:"Exped\u00edci\u00f3",Vi:"Exped\u00edci\u00f3 Be\u00e1ll\u00edt\u00e1sok",Gj:"V\u00e1lassz Sz\u00f6rnyet",pl:"Legmagasabb",ol:"Tedd be a gy\u00f3gy\u00edt\u00f3 t\u00e1rgyaid az els\u0151 oldalra a lelt\u00e1rodon bel\u00fcl",zc:"Bent",Fh:"Arany T\u00e1rol\u00e1sa",Gh:"Arany T\u00e1rol\u00e1sa az Aukci\u00f3ban?",lh:"Haszn\u00e1ld a Munk\u00e1sruh\u00e1t a Bolt Felt\u00f6lt\u00e9s\u00e9hez?",
Sk:"V\u00e1lassz T\u00e9teleket a Vissza\u00e1ll\u00edt\u00e1shoz",eh:"Lej\u00e1rt T\u00e9telek Vissza\u00e1ll\u00edt\u00e1sa",Mb:"Megjegyz\u00e9s: Az opci\u00f3 enged\u00e9lyez\u00e9s\u00e9vel a bot eladja a k\u00f6zelg\u0151 lej\u00e1rat\u00fa t\u00e1rgyakat a Csomagokb\u00f3l az Egyes\u00fcleti Piacon majd megszak\u00edtja a lej\u00e1rati id\u0151 vissza\u00e1ll\u00edt\u00e1s\u00e1t. Egyes\u00fclet sz\u00fcks\u00e9ges. Gy\u0151z\u0151dj meg r\u00f3la, hogy a t\u00e1sk\u00e1dban van \u00fcres 3x3-as hely.",
Kg:"Bot v\u00e9letlenszer\u0171 sz\u00fcneteltet\u00e9se m\u0171k\u00f6d\u00e9si [Teszt F\u00e1zis]:",Y:"Arany T\u00e1rol\u00e1sa: A bot megtartja ezt az aranyat a karakteren:",jg:"Max Arany: A bot elk\u00f6lti, ha az arany nagyobb, mint",jh:"A bot v\u00e9letlenszer\u0171 t\u00e1rgyakra fog licit\u00e1lni.",Bd:"V\u00e9letlenszer\u0171 k\u00e9sleltet\u00e9s hozz\u00e1ad\u00e1sa",Cd:"Itt adhatsz hozz\u00e1 k\u00e9sleltet\u00e9st a bothoz.",Lb:"Jav\u00edt\u00e1s",Jl:"Csak K\u00e9k t\u00e1rgy Olvaszt\u00e1s?",
Ml:"Csak Lila t\u00e1rgy Olvaszt\u00e1s?",Ll:"Csak Narancss\u00e1rga t\u00e1rgy Olvaszt\u00e1s?",Xj:"Mindent Olvassz be a 2. f\u00fclben?",Yj:"Ez figyelmen k\u00edv\u00fcl hagyja a sz\u00ednv\u00e1laszt\u00e1sokat",Xa:"El\u0151zm\u00e9nyek T\u00f6rl\u00e9se",Ah:"Olvaszt\u00e1s",Kd:"Search",zg:"Aut\u00f3matikus Aukci\u00f3",Ld:"Az aukci\u00f3 t\u00falzott haszn\u00e1lata kitilt\u00e1st vonhat maga ut\u00e1n. Az esetleges \u00fctk\u00f6z\u00e9sek elker\u00fcl\u00e9se \u00e9rdek\u00e9ben aj\u00e1nlatos letiltani az egy\u00e9b aj\u00e1nlatt\u00e9teli funkci\u00f3kat. Ez a funkci\u00f3 lelass\u00edtja a botot.",
kh:"Keres\u00e9s a Gladi\u00e1torok Aukci\u00f3j\u00e1ban",mh:"Keres\u00e9s a Zsoldosok Aukci\u00f3j\u00e1ban",Td:"Licit\u00e1l\u00e1s \u00c9telekre?",kg:"Maxim\u00e1lis Licit",Ud:"Licit\u00e1l\u00e1s, ha az \u00e1llapot kevesebb, mint",Vd:"Licit\u00e1lt T\u00e1rgyak",wk:"Aukci\u00f3 Nyelve",xk:"2.9.4-es friss\u00edt\u00e9ssel kapcsolatban k\u00e9rlek \u00e1ll\u00edtsd be \u00fajra a nyelvet, vagy ALAP\u00c9RTELMEZET BE\u00c1LL\u00cdT\u00c1SOK. Gy\u0151z\u0151dj meg r\u00f3la, hogy minden helyesen van be\u00e1ll\u00edtva, k\u00fcl\u00f6nben a licit\u00e1l\u00e1s nem m\u0171k\u00f6dik.",
Fd:"Hozz\u00e1adhatsz t\u00e9teleket a piac keres\u00e9s\u00e9hez \u00e9s az aukci\u00f3hoz. Amikor egy t\u00e9telt hozz\u00e1ad a list\u00e1hoz, a piac lila t\u00e9teleket is megjelen\u00edti. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, az al\u00e1bbi opci\u00f3kat haszn\u00e1lhatod",uk:"\u00d3vatosan haszn\u00e1ld az aukci\u00f3t!",vk:"Az aut\u00f3matikus licit\u00e1l\u00e1s t\u00fal sok k\u00e9r\u00e9st k\u00fcldhet a szerverre, \u00e9s kitilthatj\u00e1k, ha folyamatosan haszn\u00e1lod!",
ah:"\u00dajra Aktiv\u00e1lja az Esem\u00e9nypontokat Rubinokkal?",pe:"Aut\u00f3matikus Olaj Enged\u00e9lyez\u00e9se",zk:"Aut\u00f3matikus Szent Olajok Beszerz\u00e9se",Ok:"K\u00fcldet\u00e9s ellen\u0151rz\u00e9si Sebess\u00e9g",Sa:"T\u00e1madj Egyes\u00fcleti Tagokat?",Qa:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "T\u00e1mad\u00e1s" list\u00e1hoz, amikor t\u00f6bb, mint X ARANYAT rabolsz.:',Ra:'Aut\u00f3matikusan hozz\u00e1adja az embereket az "Elker\u00fclend\u0151 T\u00e1mad\u00e1s" list\u00e1hoz, ha vesz\u00edtesz ellen\u00fck.:',
Pb:"T\u00e1mad\u00e1sok Statisztik\u00e1i",Xb:"Nagyon Hossz\u00fa",zb:"Hossz\u00fa",Hb:"K\u00f6zepes",Ub:"R\u00f6vid",Yb:"Nagyon R\u00f6vid",qe:"Bel\u00e9p\u00e9s az Alvil\u00e1gba, ha az \u00c9P >",Wg:"K\u00fcldet\u00e9s Ellen\u0151rz\u00e9si Sebess\u00e9g",Og:'Az alap\u00e9rtelmezett "3x". Ha a bot probl\u00e9m\u00e1kat okoz a k\u00fcldet\u00e9sekkel, \u00e1ll\u00edtsd \u00e1t a k\u00fcldet\u00e9s sebess\u00e9g\u00e9t a szerver sebess\u00e9g\u00e9nek megfelel\u0151en.',Xe:"Gy\u00f3gy\u00edt\u00f3 Kiv\u00e1laszt\u00f3 T\u00e1ska",
re:'Ha manu\u00e1lisan friss\u00edted a pontokat, akkor kattints a fent l\u00e9v\u0151 gombra: "Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!"',Dk:"Legal\u00e1bb az egyiket enged\u00e9lyezned kell a k\u00f6vetkez\u0151k k\u00f6z\u00fcl: exped\u00edci\u00f3, dungeont, ar\u00e9n\u00e1t vagy cirkuszt, hogy elind\u00edtsd az Esem\u00e9ny Exped\u00edci\u00f3t.",Yg:"Esem\u00e9ny K\u00fcldet\u00e9s Friss\u00edt\u00e9se, ha beragadt!",kb:"Fedezze a T\u00e1rsakat?",Vk:"Hagyd minden be\u00e1ll\u00edt\u00e1st letiltva, ha a csomagokban szerepl\u0151 elemekkel szeretn\u00e9l olvasztani. Azonban m\u00e9g mindig v\u00e1laszthatsz sz\u00edneket.",
Ak:"Karakter(Ki) / Zsoldos(Be)",Rk:"Mindkett\u0151t Jav\u00edtani?",Wk:"Id\u0151z\u00edt\u0151k",Timers:"\u00cdrd be az egyes id\u0151z\u00edt\u0151kh\u00f6z a percek sz\u00e1m\u00e1t lent vagy hagyd az alap\u00e9rtelmezetten.",nb:"T\u00e1mad\u00e1s Statisztik\u00e1i Enged\u00e9lyez\u00e9se:",Nb:"V\u00e1lassz tartom\u00e1nyt a t\u00e1mad\u00e1shoz",Ob:"A bot v\u00e9letlenszer\u0171en t\u00e1mad a t\u00e1bl\u00e1zatban szerepl\u0151 j\u00e1t\u00e9kosok k\u00f6z\u00fcl.",pb:"Ligat\u00e1mad\u00e1sok",
mb:"Ligat\u00e1mad\u00e1s Enged\u00e9lyez\u00e9se:",Jb:"V\u00e9letlenszer\u0171 T\u00e1mad\u00e1s",Kb:"T\u00e1mad\u00e1s alacsonyt\u00f3l a magas szint\u0171 j\u00e1t\u00e9kosokig",tk:"A bot alap\u00e9rtelmezetten elker\u00fcli az Egyes\u00fcleti tagok t\u00e1mad\u00e1s\u00e1t.",Me:"Exped\u00edci\u00f3 Helysz\u00edne:",Md:"Aut\u00f3matikus B\u00f3nuszok Begy\u0171jt\u00e9se:",zh:"Boss Kihagy\u00e1sa",ke:"Kazamata Helysz\u00edne:",hh:"Kazamata \u00fajrakezd\u00e9se veres\u00e9g eset\u00e9n?",$e:"Alvil\u00e1g Be\u00e1ll\u00edt\u00e1sok",
af:"K\u00e9rlek konfigur\u00e1ld a gy\u00f3gy\u00edt\u00e1s sz\u00e1zal\u00e9kos be\u00e1ll\u00edt\u00e1sait a gy\u00f3gy\u00edt\u00e1s f\u00fcl\u00f6n, \u00e9s gy\u0151z\u0151dj meg r\u00f3la, hogy a gy\u00f3gy\u00edt\u00e1s f\u00fcl be van kapcsolva. Ha az alvil\u00e1g bel\u00e9p\u00e9se kijelentkeztet, l\u00e9pj a lobbyba, \u00e9s kapcsold be az aut\u00f3mata bejelentkez\u00e9s jel\u00f6l\u0151n\u00e9gyzetet.",Ye:"Alvil\u00e1g Neh\u00e9zs\u00e9g",Pd:"Aut\u00f3matikus Alvil\u00e1g Bel\u00e9p\u00e9s: / Alvil\u00e1g Mode",
yi:"Mobiliz\u00e1ci\u00f3 haszn\u00e1lata, ha pontok = 0",Ci:"Rubinok haszn\u00e1lata?",se:"Kil\u00e9p\u00e9s az alvil\u00e1gb\u00f3l, ha nincsenek pontok?",ki:"A bot megpr\u00f3b\u00e1lja el\u0151sz\u00f6r a Villa Medici-t haszn\u00e1lni, ha nincs, akkor gy\u00f3gy\u00edt\u00f3 italt haszn\u00e1l. Ne felejtsd el bekapcsolni a Gy\u00f3gy\u00edt\u00e1s kapcsol\u00f3t.",ti:"Az aut\u00f3matikus alvil\u00e1g bel\u00e9p\u00e9s letiltja a kazamata/ar\u00e9na/circus be\u00e1ll\u00edt\u00e1sokat az alvil\u00e1g bel\u00e9p\u00e9sekor.",
Xk:"Alvil\u00e1g Gy\u00f3gy\u00edt\u00e1si Be\u00e1ll\u00edt\u00e1sok",Bi:"Villa Medici Haszn\u00e1lata?",zi:"Gy\u00f3gy\u00edt\u00f3 Ital Haszn\u00e1lata?",Yf:"INF\u00d3: A bot minden kiv\u00e1lasztott percben keresni fog piaci t\u00e9teleket, ami meg\u00e1ll\u00edthatja a t\u00e1mad\u00e1st a keres\u00e9s alatt.",oe:"Piaci Keres\u00e9s Enged\u00e9lyez\u00e9se:",Zf:"Piaci Keres\u00e9s Id\u0151k\u00f6z Percekben:",$f:"Javasolt 10 perc.",kf:"T\u00e9tel Be\u00e1ll\u00edt\u00e1sok:",hf:"T\u00e9tel N\u00e9v Tartalmazza",
G:"Max \u00c1r",lf:"T\u00e9tel T\u00edpus",jf:"T\u00e9tel Ritkas\u00e1g",Yd:"L\u00e9lekhez k\u00f6t\u00f6ttet v\u00e1s\u00e1roljon?",nf:"V\u00e1s\u00e1roland\u00f3 T\u00e9telek",mf:"Megpr\u00f3b\u00e1lja megvenni a t\u00e1sk\u00e1ban l\u00e9v\u0151 legnagyobb \u00e1ron tal\u00e1lhat\u00f3 t\u00e9telt, ha b\u00e1rmelyik megegyezik a maxim\u00e1lis \u00e1r be\u00e1ll\u00edt\u00e1ssal.:",Wd:"Megv\u00e1s\u00e1rolt T\u00e9telek:",bj:"Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",pk:"\u00c9tel V\u00e1s\u00e1rl\u00e1sa a Boltb\u00f3l?",
qk:"Gy\u00f3gy\u00edt\u00f3 eszk\u00f6z haszn\u00e1lata a Csomagb\u00f3l?",lk:"Cervisia haszn\u00e1lata?",nk:"Toj\u00e1sok haszn\u00e1lata?",tl:"Utols\u00f3 Haszn\u00e1lat",location:"Helysz\u00edn",Strength:"Er\u0151",Dexterity:"\u00dcgyess\u00e9g",Agility:"F\u00fcrges\u00e9g",Constitution:"Alkat",Charisma:"Karizma",Intelligence:"Intelligencia",gi:"Gyakorl\u00e1s Be\u00e1ll\u00edt\u00e1sok",hi:"V\u00e1laszd ki az attrib\u00fatumokat, amiket szeretn\u00e9l edzeni. Akkor fogja elkezdeni az edz\u00e9st, ha van el\u00e9g aranyad.",
$c:"K\u00f6vetkez\u0151 l\u00e9p\u00e9s",oj:"Nem",pj:"Norm\u00e1l",xl:"Ellens\u00e9g",yl:"Ellens\u00e9g Szintje",Dj:"K\u00e9rd\u00e9sek",random:"V\u00e9letlenszer\u0171",Fl:"Be\u00e1ll\u00edt\u00e1sok",Ql:"Hamarosan...",type:"Kattints az ikonokra a k\u00e9rd\u00e9s t\u00edpus\u00e1nak kiv\u00e1laszt\u00e1s\u00e1hoz.",Xl:"Igen",A:"Aukci\u00f3/Keres\u00e9s",yd:"T\u00e9telek Hozz\u00e1ad\u00e1sa",ik:"Fejleszt\u0151t\u00e1rgyak Aut\u00f3matikus T\u00e1rol\u00e1sa",Sl:"Elk\u00fcld\u00e9s",rl:"Id\u0151k\u00f6z : ",
gl:"Aut\u00f3matikus Licit Enged\u00e9lyez\u00e9se",hl:"Ne licit\u00e1ljon, ha az Egyes\u00fcleti tag m\u00e1r licit\u00e1lt",Ul:"\u00datmutat\u00f3",ac:"V\u00e1lassz a fenti gombok k\u00f6z\u00fcl, hogy akarod-e az ar\u00e9n\u00e1ban a legkisebb vagy a legmagasabb szint\u0171 ellenfelet. T\u00f6bb felhaszn\u00e1l\u00f3 lass\u00edthatja a bot m\u0171k\u00f6d\u00e9s\u00e9t.",$k:"Kezdetnek adj hozz\u00e1 egy t\u00e9telt a list\u00e1hoz (pl. `Lucius`). Miut\u00e1n hozz\u00e1adtad, a bot keresni fogja a t\u00e1rgyakat \u00e9s megjelen\u00edti a keres\u00e9si eredm\u00e9nyeket a k\u00e9perny\u0151 bal oldal\u00e1n. Az aut\u00f3matikus aukci\u00f3 c\u00e9lj\u00e1b\u00f3l is keressen r\u00e1 a t\u00e1rgyra. Ha enged\u00e9lyezed az aut\u00f3matikus licit\u00e1l\u00e1st, a bot rendszeres id\u0151k\u00f6z\u00f6nk\u00e9nt keresni fogja a t\u00e9teleket a megadott id\u0151szak alapj\u00e1n. Ha a bot megtal\u00e1lja a t\u00e1rgyat \u00e9s van el\u00e9g p\u00e9nzed, aut\u00f3matikusan licit\u00e1l majd helyetted. *Megjegyz\u00e9s*: egyedi t\u00e1rgyak keres\u00e9s\u00e9hez a boltban legal\u00e1bb 1 v\u00e9letlenszer\u0171 t\u00e1rgyat hozz\u00e1 kell adnod a keres\u00e9si list\u00e1hoz.",
jl:"A sz\u00f6rny sz\u00e1m\u00e1t a fenti gombok k\u00f6z\u00fcl v\u00e1laszthatod ki. A 1 a legbaloldali sz\u00f6rnyet k\u00e9pviseli. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",Si:"V\u00e1lassz nehezs\u00e9get a kazamat\u00e1hoz a fentiek k\u00f6z\u00fcl. Gy\u0151z\u0151dj meg r\u00f3la, hogy megfelel\u0151 helyet v\u00e1lasztasz, k\u00fcl\u00f6nben a bot sz\u00fcnetelhet.",cj:"Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sok",
Ti:"Felesleges arany t\u00e1rol\u00e1sa az egyes\u00fcletben az egyes\u00fcleti piacon t\u00e1rgyak v\u00e1s\u00e1rl\u00e1s\u00e1val. -> Min. Arany",ul:"Mindent Mozgat",vl:"Kijel\u00f6ltek Mozgat\u00e1sa",cl:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s",dl:"Aut\u00f3matikus Gy\u00f3gy\u00edt\u00e1s Sz\u00e1zal\u00e9k",Wl:"Rubin",Fg:"\u00c1ltal\u00e1nos Be\u00e1ll\u00edt\u00e1sok",Hj:"Mindent Elad",Ij:"Kijel\u00f6ltek Elad\u00e1sa",fa:"Fegyverek",ca:"Pajzsok",U:"Mellv\u00e9rtek",X:"Sisakok",W:"Keszty\u0171k",
da:"Cip\u0151k",aa:"Gy\u0171r\u0171k",T:"Amulettek",wi:"\u00c9telek",vi:"Fejleszt\u00e9sek",Xg:"Receptek",mg:"Tekercsek",Zg:"Er\u0151s\u00edt\u00e9sek",Tg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",Sg:"\u00cdrja be a sz\u0171rend\u0151 kulcsszavakat, hogy kisz\u0171rje azokat a k\u00fcldet\u00e9seket, amelyeket nem szeretne v\u00e1llalni. You can also use this to accept quests by their reward using keywords.",V:"Adjon meg kulcssz\u00f3t",I:"Hozz\u00e1ad\u00e1s",$g:"Elt\u00e1vol\u00edt\u00e1s",
ae:"T\u00f6rl\u00e9s",Qg:"K\u00fcldet\u00e9s Sz\u0171r\u0151 Elfogad\u00e1sa",Rg:"\u00cdrja be a kulcsszavakat, hogy kiv\u00e1lassza, melyik k\u00fcldet\u00e9seket szeretn\u00e9 v\u00e1llalni. Ez figyelmen k\u00edv\u00fcl hagyja a k\u00fcldet\u00e9st\u00edpusokat",Ca:"Id\u0151 Sz\u0171r\u00e9s\u0171 K\u00fcldet\u00e9sek Kihagy\u00e1sa?",Pk:"K\u00fcldet\u00e9sek",Nd:"Automatikus Kost\u00fcm",xi:"Kost\u00fcm Haszn\u00e1lata?",Sd:"Alap Harc",je:"Dungeoni Harc",Od:"A Bot csak akkor viseli a Dis Pater Normal \u00e9s Medium form\u00e1tumot, ha az exped\u00edci\u00f3/kazamata pontja 0.",
Ze:"Pokoli Gy\u00f3gy\u00edt\u00e1s Be\u00e1ll\u00edt\u00e1sai",Ed:"T\u00e1mad\u00e1s a F\u0151ellens\u00e9g el\u00e9rhet\u0151v\u00e9 v\u00e1l\u00e1sakor?",qb:"Az Ligat\u00e1mad\u00e1s \u00f6nmag\u00e1t letiltja 5 sikertelen t\u00e1mad\u00e1s ut\u00e1n.",bf:"Szent Olajok",ug:"T\u00e1rgy Neve",Z:"Minim\u00e1lis T\u00e1rgyszint",Aa:"Minim\u00e1lis T\u00e1rgymin\u0151s\u00e9g",Dd:"Alkalmaz/T\u00f6r\u00f6l Minut\u00e9ri\u00e1t",ef:"El\u0151tag/Ut\u00f3tag Kombin\u00e1ci\u00f3 Figyelmen K\u00edv\u00fcl Hagy\u00e1sa",
Ei:"Igen",Bg:"Nem",Oa:"El\u0151tag Hozz\u00e1ad\u00e1sa",Pa:"Ut\u00f3tag Hozz\u00e1ad\u00e1sa",Bh:"Olvasd el a List\u00e1t",Ib:"El\u0151tag",Vb:"Ut\u00f3tag",gh:"Lej\u00e1r\u00f3 T\u00e1rgyak Vissza\u00e1ll\u00edt\u00e1sa",Ch:"V\u00e9letlenszer\u0171 Olvasd el a Csomagokat?",Dh:"Olvasd el a Lapon",ob:"Extr\u00e1k",Id:"\u00c1rver\u00e9s",cg:"Piac",Wb:"Id\u0151z\u00edt\u0151k",bi:"Olvasd el a Minut\u00e9ri\u00e1t",ai:"Olvasd el, ha nincs el\u00e9g arany",Yh:"Olvasd el, ha nincs t\u00e1rgy",Da:"Jav\u00edt\u00e1s",
Qh:"Gilda Piac Aranytartalma",Mh:"\u00c1rver\u00e9s Aranytartalma",ei:"Edz\u00e9s",Th:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa",ci:"\u00dczletek a Kov\u00e1cshoz",Kh:"\u00c1rver\u00e9s Ellen\u0151rz\u00e9se",Vh:"Keres\u00e9s",v:"Enged\u00e9lyez\u00e9s",wg:"Minim\u00e1lis Arany",Qb:"\u00d3ra Kiv\u00e1laszt\u00e1sa",lb:"Arany Adom\u00e1nyoz\u00e1sa a Gildinek",ee:"Minden 5 percenk\u00e9nt adom\u00e1nyoz. Az id\u0151z\u00edt\u0151k lapr\u00f3l m\u00f3dos\u00edthatja az id\u0151k\u00f6zt",cf:"Mennyit szeretne adom\u00e1nyozni?",
fe:"Adom\u00e1nyozni, amikor t\u00f6bb van, mint >",qf:"Kevesebb, mint <",dh:"Lej\u00e1rtak Vissza\u00e1ll\u00edt\u00e1sa \u00e9s Egy\u00e9b Be\u00e1ll\u00edt\u00e1sok",fh:"Vissza\u00e1ll\u00edt\u00e1s ideje:",Jk:"Tartsa lenyomva a Ctrl (Cmd a Mac-en) billenty\u0171t a t\u00f6bb t\u00e1rgy kiv\u00e1laszt\u00e1s\u00e1hoz",ff:"Be-/Kiv\u00e1laszt\u00e1s Be\u00e1ll\u00edt\u00e1sok",Oe:"Be\u00e1ll\u00edt\u00e1sok Export\u00e1l\u00e1sa",gf:"Be\u00e1ll\u00edt\u00e1sok Import\u00e1l\u00e1sa",ng:"\u00dczenet Minden J\u00e1t\u00e9kosnak",
og:"[Ultra Pr\u00e9mium Kulcs sz\u00fcks\u00e9ges, \u00fczenet a Discordon az kulcs megszerz\u00e9s\u00e9hez.]",pg:"Adja meg az elk\u00fcldend\u0151 \u00fczenetet",ce:"Egyedi szkriptek\u00e9rt vegye fel a kapcsolatot vel\u00fcnk a Discordon",rg:"K\u00fcld\u00e9s",sg:"J\u00e1t\u00e9kosok Megjelen\u00edt\u00e9se",qg:"Mindet Kiv\u00e1laszt",tg:"\u00d6sszes Kiv\u00e1laszt\u00e1s Visszavon\u00e1sa",pf:"Gy\u0151z\u0151dj\u00f6n meg r\u00f3la, hogy van el\u00e9g hely a t\u00e1sk\u00e1j\u00e1ban. A leh\u0171l\u00e9si id\u0151 2 perc.",
gg:"\u00c9tel Elad\u00e1sa a Piacon?",Db:"\u00c9telre V\u00e1lt\u00e1s a Piacon?"};if("true"!==localStorage.getItem("isInitialized")){const F={Timers:JSON.stringify({Smelting:10,SmeltingNoGold:5,SmeltingNoItem:15,Repair:10,GuildMarket:2,AuctionHoldGold:15,Arena:10,CircusTurma:10,Training:2,ResetExpired:30,SearchTimer:5,StoreForge:30,AuctionCheck:10,GuildDonate:15,guildBattleEnable:120,BuffTimer:5}),packagesPurchased:"[]",questKeywords:"[]",activeItems:'{"gloves":false,"shoes":false,"rings1":false,"rings2":false,"shield":false,"armor":false,"weapon":false,"helmet":false,"necklace":false}',
auctionPrefixes:"[]",auctionSuffixes:"[]",prefixes:"[]",suffixes:"[]",underworldQuestKeywords:"[]",UnderworldQuests:"false",statSettings:JSON.stringify([{stat:"Strength",count:"0",priority:null,continueTraining:!1},{stat:"Dexterity",count:"0",priority:null,continueTraining:!1},{stat:"Agility",count:"0",priority:null,continueTraining:!1},{stat:"Constitution",count:"0",priority:null,continueTraining:!1},{stat:"Charisma",count:"0",priority:null,continueTraining:!1},{stat:"Intelligence",count:"0",priority:null,
continueTraining:!1}]),farmEnable:"false",farmEnemy:"1",farmLocation:"0",HealPickBag:"1",AutoBidInterval:"5",AuctionItemLevel2:"0",HealShop:"false",noItemsLastCheck:"false",dungeonFocusQuest:"false",smeltBlue:"false",smeltGreen:"false",HealClothToggle:"false",questrewardvalue:"2000",smeltOrange:"false",smeltRed:"false",auctionTURBO:"false",smeltusehammers:"false",BuffsEnable:"false",repairPercentage:"10",HealRubyToggle:"false",dungeonLocation:"0",costumeBasic:"1",costumeDungeon:"2",smeltAnything:"false",
skipTimeQuests:"false",skipTimeCircusQuests:"false",costumeUnderworld:"9",wearUnderworld:"false",hellDifficulty:"1",repairMaxQuality:"1",FoodAmount:"3",smeltIgnorePS:"false",EnableSmelt:"false",filterGM:"p","AuctionEmpty.timeOut":"0","BuffCheck.timeOut":"0","CheckDolls.timeOut":"0","AuctionMEmpty.timeOut":"0",expeditionLocation:"0",auctionMinQuality:"0",doQuests:"false",unique_shop_results_height:"124",unique_shop_results_width:"184",unique_shop_results_top:"452",unique_shop_results_left:"368",search_results_top:"112",
search_results_width:"179",search_results_height:"284",search_results_left:"410",itemBought:"false",itemMovedToInventory:"false",AucTab:"true",patmp:"false",arenaPlayer:"true",repairInitiated:"true",doKasa:"false",packages:JSON.stringify({quality:[],type:[1,2,3,4,5,8,6,9,7,12,13,15,19,20,11,21,18,14,99]}),delaySelect:"0",autoAttackList:"[]",avoidAttackList:"[]",autoAttackCircusList:"[]",avoidAttackCircusList:"[]",autoAttackServerList:"[]",removeCircusList:"[]",removeArenaList:"[]",arenacrosslist:"[]",
circuscrosslist:"[]",autoAttackCircusServerList:"[]",doArena:"false",doCircus:"false","gladBotChecks.timeOut":"0","repair.timeOut":"0","storeForgeResources.timeOut":"0",HealCervisia:"false",dungeonAB:"false",bidStatus:"4",doDungeon:"false",doExpedition:"false",arenaAttackGM:"false",circusAttackGM:"false",AutoAuction:"false",auctionminlevel:"0",storeGoldinAuctionmaxGold:"0",storeGoldinAuction:"false",autoAddArenaAmount:"0",autoAddCircusAmount:"0",eventPoints_:"16",storeGoldinAuctionholdGold:"0",TrainingHoldGold:"0",
smeltLevel:"1",MarketHoldGold:"0",KasaHoldGold:"0",HealPackage:"false",smeltPurple:"false",guildPackHour:"3",smeltEverything3:"false",questSpeed:"2","enableHideGold.timeOut":"0",bidFood:"false",auctionmercenaryenable:"false",auctiongladiatorenable:"false",maximumBid:"100000",activateAuction2:"false",scoreboardattackenable:"false",scoreRange:"5",auctionlanguagesettings:JSON.stringify(["Very long","Long","Middle","Short","Very short"]),scoreboardcircusenable:"false",healPercentage:"25",hellEnterHP:"75",
questTypes:JSON.stringify({combat:!0,arena:!0,circus:!0,expedition:!1,dungeon:!1,items:!1}),scoreRangeCircus:"5",underworld:JSON.stringify({cooldown:"",wins:0,isUnderworld:!1,hj:!1}),enableMarketSearch:"false",smeltTab:"1",UnderWorldUseRuby:"false",renewEvent:"false","arena.timeOut":"0","circus.timeOut":"0",AuctionCover:"false",AuctionGoldCover:"false",UnderworldUseMobi:"false",MarketSearchInterval:"5",useVillaMedici:"false",autoEnterHell:"false",useHealingPotion:"false",repairMercenary:"false",repairALL:"false",
AutoBidButton:"false",healstopbot:"false",HealEnabled:"false",minimumGoldAmount:"100000",doEventExpedition:"false",GuildMemberBid:"false",autoCollectBonuses:"false",exitUnderworld:"false",workbench_selectedItem:JSON.stringify({})};Object.keys(F).forEach(L=>{null===localStorage.getItem(L)&&localStorage.setItem(L,F[L])});["license_playerId","eventPoints","playerTimeouts"].forEach(L=>{null!==localStorage.getItem(L)&&localStorage.removeItem(L)});localStorage.setItem("isInitialized","true")};
