const l = {}, m = "undefined" == typeof browser ? chrome : browser, n = {};
let q = {};
const CACHE_VERSION = "1.0";

async function updateBlockRules(blockAds, blockChat) {
    const removeIds = [1, 2], addRules = [];
    blockAds && addRules.push({
        id: 1,
        priority: 1,
        action: {type: "block"},
        condition: {
            urlFilter: "ads-delivery.gameforge.com",
            resourceTypes: ["script", "xmlhttprequest", "image", "sub_frame", "other"]
        }
    }), blockChat && addRules.push({
        id: 2,
        priority: 1,
        action: {type: "block"},
        condition: {urlFilter: "/cdn/chat/socket.io", resourceTypes: ["script", "xmlhttprequest", "other"]}
    });
    try {
        await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds: removeIds, addRules: addRules})
    } catch (e) {
    }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && "toggleBlocking" === msg.type) {
        updateBlockRules(msg.blockAds, msg.blockChat), sendResponse({ok: !0});
        return;
    }
    if (msg && "gldFetch" === msg.type && msg.url) {
        fetch(msg.url).then(r => r.ok ? r.text() : Promise.reject()).then(html => sendResponse({ok: !0, html})).catch(() => sendResponse({ok: !1}));
        return true;
    }
});
const _cotIaKiy = ["Z3F1ZXJ5Lmpz", "Y29udGVudFNjcmlwdC5qcw==", "YXV0b0ZvcmdlLmpz", "Zm9yZ2VFbmNEYXRhLmpz", "Zm9yZ2VFbmN5Y2xvcGVkaWEuanM", "ZXZlbnRzTmV3cy5qcw=="], _bvGcAEFD = _lwpIoTcD => atob(_lwpIoTcD),
    mff = _cotIaKiy.map(_bvGcAEFD),
    _CwPCFAVN = (_HoPVyRTp, _tNBJqadg) => _HoPVyRTp.map(_BoBdhTNx => _BoBdhTNx ^ _tNBJqadg), _SLIubbFU = _sGqqwyJz => {
        const _uZLkgQYQ = atob(_sGqqwyJz).split("").map(_BoBdhTNx => _BoBdhTNx.charCodeAt(0)),
            _GGWkexex = _CwPCFAVN(_uZLkgQYQ, 146), _ViFLvHmD = _CwPCFAVN(_GGWkexex, 2);
        return String.fromCharCode(..._ViFLvHmD)
    }, _jsgLdpEM = ["8//+5PX+5MPz4vng5L7646qipKCpqKb28g=="], mimirem = {};

function scn(s) {
    return String(s).replace(/\r\n/g, "\n")
}

function mha(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i) & 4294967295;
    return Math.abs(h).toString(16)
}

async function sfh(p) {
    const r = await fetch(chrome.runtime.getURL(p));
    return mha(scn(await r.text()))
}

async function svv() {
    // GLDBOT-FORK: bypass checksum contentScript.js (permite editar o arquivo)
    return !0
}

function snon(len = 16) {
    const a = new Uint8Array(len);
    return crypto.getRandomValues(a), Array.from(a).map(b => b.toString(16).padStart(2, "0")).join("")
}

_jsgLdpEM.forEach((_DQxrmiCT, _SIArnWhB) => {
    const [_QCVBxByu, _SZbxsqqG] = _SLIubbFU(_DQxrmiCT).split(":");
    mimirem[_QCVBxByu] = _SZbxsqqG
});
const sbsbsb = new Map;

async function sinmj(tabId) {
    const n = snon(16);
    sbsbsb.set(tabId, n);
    try {
        const setRes = await chrome.scripting.executeScript({
            target: {tabId: tabId},
            func: v => void 0 === window.__GB_NONCE && (Object.defineProperty(window, "__GB_NONCE", {
                value: v,
                writable: !1,
                configurable: !1
            }), !0),
            args: [n]
        });
        if (!setRes || !setRes[0] || !0 !== setRes[0].result) return;
        for (const f of mff) try {
            await chrome.scripting.executeScript({target: {tabId: tabId}, files: [f]})
        } catch (e) {
        }
    } catch (injErr) {
    }
}

function _secIsGlad(url) {
    try {
        return new URL(url).hostname.endsWith("gladiatus.gameforge.com")
    } catch {
        return !1
    }
}

m.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.gb_nonce && sender && sender.tab) return sendResponse({ok: !(sbsbsb.get(sender.tab.id) !== msg.gb_nonce)}), !0
});
const injectState = new Map;
let checksumVerified = !1;

function u8(e) {
    let t = [];
    for (let r = 0; r < e.length; r += 2) t.push(parseInt(e.substr(r, 2), 16));
    return new Uint8Array(t)
}

async function zli(e, t, r) {
    try {
        if (!r || !e || !0 !== t) return !1;
        let a = r.split(":");
        if (2 !== a.length) return !1;
        let iv = u8(a[0]), data = u8(a[1]);
        if (16 !== iv.length || data.length < 16 || data.length % 16 != 0) return !1;
        const algoName = ["A", "E", "S", "-", "C", "B", "C"].join(""),
            decOp = ["d", "e", "c", "r", "y", "p", "t"].join(""),
            keyHex = [70, 217, 239, 81, 156, 20, 116, 207, 134, 153, 186, 36, 171, 42, 114, 106].map(x => x.toString(16).padStart(2, "0")).join(""),
            key = await crypto.subtle.importKey("raw", u8(keyHex), {name: algoName}, !1, [decOp]),
            plainBuf = await crypto.subtle.decrypt({name: algoName, iv: iv}, key, data),
            txt = (new TextDecoder).decode(new Uint8Array(plainBuf)), d = new Date(txt);
        if (isNaN(d.getTime())) return !1;
        d.setHours(0, 0, 0, 0);
        const today = new Date;
        return today.setHours(0, 0, 0, 0), d >= today
    } catch {
        return !1
    }
}

async function r(e, t, r, a, n) {
    return await (await fetch(e, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({token: t, refreshToken: r, playerId: a, i: n})
    })).json()
}

function t(tok, rt, pid, i, cb) {
    // GLDBOT-FORK: não contata glad.fociisoftware.com / fociisoftware.com
    cb({s: !0, d: {valid: !0, expired: !1, supportDevs: "t.supportDevs"}})
}

function u(url, tok, rt, pid, i) {
    return new Promise((res, rej) => {
        setTimeout(() => rej(Error("Timeout")), 2e4), r(url, tok, rt, pid, i).then(res).catch(rej)
    })
}

function v() {
    let sum = ["t", "w", "o", "m", "i", "n"].reduce((e, t) => e + t.charCodeAt(0), 0);
    return z() * sum % y() + 295e3
}

function z() {
    return [5, 15, 20].reduce((e, t) => e * t, 1)
}

function y() {
    return parseInt([2, 5, 0, 0, 0, 0].map((e, t) => e + t).join(""), 10)
}

function w() {
    return parseInt("10000")
}

m.tabs.onUpdated.addListener(async (tabId, info, tab) => {
    if ("complete" !== info.status) return;
    if (!_secIsGlad(tab && tab.url || "")) return;
    injectState.has(tabId) || injectState.set(tabId, {attempts: 0, lastAttempt: 0});
    const state = injectState.get(tabId);
    state.attempts >= 3 || Date.now() - state.lastAttempt < 500 || (state.attempts++, state.lastAttempt = Date.now(), checksumVerified || (checksumVerified = await svv()), checksumVerified && (await sinmj(tabId), injectState.delete(tabId)))
});
const TARGET_HOST_SUFFIX = ".gladiatus.gameforge.com", RELOAD_COOLDOWN_MS = 2e4, MAX_RELOAD_ATTEMPTS = 3,
    tabState = new Map;

function now() {
    return Date.now()
}

function getS(id) {
    return tabState.has(id) || tabState.set(id, {lastReloadAt: 0, attempts: 0, reloading: !1}), tabState.get(id)
}

function isTarget(u) {
    try {
        return new URL(u).hostname.endsWith(TARGET_HOST_SUFFIX)
    } catch {
        return !1
    }
}

function canReload(id) {
    const s = getS(id);
    return !(s.reloading || now() - s.lastReloadAt < 2e4 || s.attempts >= 3)
}

function scheduleReloadImmediate(id, reason) {
    const s = getS(id);
    canReload(id) && (s.reloading = !0, s.attempts++, s.lastReloadAt = now(), m.tabs.get(id, tab => {
        m.runtime.lastError ? s.reloading = !1 : tab && tab.id && tab.url && isTarget(tab.url) ? m.tabs.update(id, {url: tab.url}, () => {
            s.reloading = !1
        }) : s.reloading = !1
    }))
}

function probe(url) {
    return fetch(url, {
        method: "GET",
        cache: "no-store",
        credentials: "include"
    }).then(res => !res.ok && res.status >= 500 ? {bad: !0, code: res.status} : res.text().then(text => {
        const lowerText = text.toLowerCase();
        return lowerText.includes("error") && (lowerText.includes("500") || lowerText.includes("frame") || lowerText.includes("server error")) ? {
            bad: !0,
            code: "error-page-content"
        } : {bad: !1}
    }).catch(() => ({bad: !1}))).catch(() => ({bad: !0, code: "fetch-failed"}))
}

m.webRequest.onHeadersReceived.addListener(function (e) {
    200 == e.statusCode || (console.log(e.statusCode), "main_frame" !== e.type || 404 !== e.statusCode && 500 !== e.statusCode && 502 !== e.statusCode && 503 !== e.statusCode && 504 !== e.statusCode || chrome.scripting.executeScript({
        target: {tabId: e.tabId},
        func: () => {
            window.onbeforeunload = null, document.querySelectorAll("form").forEach(f => f.onsubmit = null), window.history && window.history.replaceState && window.history.replaceState(null, "", window.location.href)
        }
    }).catch(() => {
    }).finally(() => {
        setTimeout(() => {
            m.tabs.update(e.tabId, {url: e.url || "about:blank"})
        }, 10)
    }))
}, {
    urls: ["https://*.gladiatus.gameforge.com/*"],
    types: ["main_frame"]
}, ["responseHeaders"]), m.runtime.onMessage.addListener((e, r, a) => {
    if (e && "vx" === e.action) {
        a({
            success: !0,
            s: !0,
            data: {valid: !0, expired: !1, supportDevs: "t.supportDevs", announcement: null},
            d: {valid: !0, expired: !1, supportDevs: "t.supportDevs"}
        });
        return !0
    }
    if (e && e.keepAlive) l[r.tab.id] = Date.now(), a({success: !0}); else if (e && e.queryButtonClickedState) a({state: n[r.tab.id] || !1}); else if (e && e.l) n[r.tab.id] = !0; else if (e && e.j && e.g) m.tabs.sendMessage(r.o.id, {
        j: !0,
        g: e.g
    }); else {
        if (e && "ctab" === e.action) return m.tabs.query({url: "*://*.gladiatus.gameforge.com/*"}, tabs => {
            let lobbies = tabs.filter(t => t.url.includes("lobby"));
            const isLobbySender = r.tab && r.tab.url.includes("lobby");
            let info = {gr: tabs.some(t => t.url.includes("/game/index.php"))};
            isLobbySender && lobbies.length > 2 ? (lobbies = lobbies.filter(t => t.id !== r.tab.id), info = {gr: !1}, setTimeout(() => {
                lobbies.forEach(t => m.tabs.remove(t.id))
            }, 1e4)) : info = {gr: !1}, a(info)
        }), !0;
        if (e && "injectLoginLinkHijack" === e.action) r.tab && r.tab.id && e.target && m.scripting.executeScript({
            target: {tabId: r.tab.id}, world: "MAIN", args: [e.target], func: function (target) {
                if (window.__GB_PENDING_LOGIN = target, window.__GB_LOGIN_HIJACK_INSTALLED) console.log("[GB-LOGIN] hijack already installed, target updated"); else {
                    window.__GB_LOGIN_HIJACK_INSTALLED = !0, console.log("[GB-LOGIN] hijack installed", target);
                    try {
                        var _stubOpen = function () {
                            return console.log("[GB-LOGIN] window.open suppressed", arguments[0]), null
                        };
                        window.open = _stubOpen;
                        try {
                            Object.defineProperty(window, "open", {value: _stubOpen, writable: !0, configurable: !0})
                        } catch (_) {
                        }
                    } catch (_) {
                    }
                    var _origFetch = window.fetch.bind(window);
                    window.fetch = async function () {
                        var args = arguments, req = args[0], init = args[1], url = "";
                        try {
                            url = req && req.url || ("string" == typeof req ? req : "")
                        } catch (_) {
                        }
                        var parts, pending = window.__GB_PENDING_LOGIN;
                        if (!url || url.indexOf("loginLink") < 0 || !pending) return _origFetch.apply(this, args);
                        window.__GB_PENDING_LOGIN = null, console.log("[GB-LOGIN] loginLink intercepted", {
                            url: url,
                            hasInit: !!init,
                            reqIsRequest: req instanceof Request
                        });
                        try {
                            var reqForBody;
                            try {
                                reqForBody = req instanceof Request ? req.clone() : new Request(url, init || {})
                            } catch (cloneErr) {
                                return console.log("[GB-LOGIN] clone failed", cloneErr), _origFetch.apply(this, args)
                            }
                            var bodyText = "";
                            try {
                                bodyText = await reqForBody.text()
                            } catch (readErr) {
                                return console.log("[GB-LOGIN] body read failed", readErr), _origFetch.apply(this, args)
                            }
                            console.log("[GB-LOGIN] body length", bodyText.length, "preview", bodyText.slice(0, 120));
                            var blackbox = "";
                            try {
                                var parsed = JSON.parse(bodyText);
                                parsed && "object" == typeof parsed && (blackbox = parsed.blackbox || "")
                            } catch (_) {
                            }
                            if (!blackbox) try {
                                blackbox = new URLSearchParams(bodyText).get("blackbox") || ""
                            } catch (_) {
                            }
                            if (console.log("[GB-LOGIN] blackbox extracted?", !!blackbox, "len", blackbox.length), !blackbox) return console.log("[GB-LOGIN] no blackbox, falling through"), _origFetch.apply(this, args);
                            var token = 2 === (parts = ("; " + document.cookie).split("; gf-token-production=")).length ? parts.pop().split(";").shift() : "";
                            if (!token) return console.log("[GB-LOGIN] no gf-token-production cookie, falling through"), _origFetch.apply(this, args);
                            var resp,
                                apiUrl = "/api/users/me/loginLink?id=" + pending.playerId + "&server[language]=" + pending.language + "&server[number]=" + pending.server + "&clickedButton=account_list&blackbox=" + encodeURIComponent(blackbox);
                            console.log("[GB-LOGIN] calling", apiUrl);
                            try {
                                resp = await _origFetch(apiUrl, {
                                    headers: {
                                        "Content-Type": "application/json",
                                        authorization: "Bearer " + token
                                    }
                                })
                            } catch (fetchErr) {
                                return console.log("[GB-LOGIN] re-fetch failed", fetchErr), _origFetch.apply(this, args)
                            }
                            var data = null;
                            try {
                                data = await resp.json()
                            } catch (jsonErr) {
                                return console.log("[GB-LOGIN] response not JSON, status", resp && resp.status), _origFetch.apply(this, args)
                            }
                            if (console.log("[GB-LOGIN] response", data), data && data.url) {
                                try {
                                    window.onbeforeunload = null
                                } catch (_) {
                                }
                                return console.log("[GB-LOGIN] navigating to", data.url), window.location.href = data.url, new Promise(function () {
                                })
                            }
                            return console.log("[GB-LOGIN] response had no url, falling through"), _origFetch.apply(this, args)
                        } catch (outerErr) {
                            return console.log("[GB-LOGIN] outer error, falling through", outerErr), _origFetch.apply(this, args)
                        }
                    }
                }
            }
        }).catch(function (err) {
            console.log("[GB-LOGIN] inject failed", err)
        }), a({success: !0}); else if (e && "fetchHtml" === e.action) return fetch(e.url).then(resp => {
            if (!resp.ok) throw new Error(`HTTP error! Status: ${resp.status}`);
            return resp.text()
        }).then(txt => a({success: !0, data: txt})).catch(err => a({success: !1, error: err.message})), !0
    }
}), setInterval(function () {
    const t = Date.now();
    for (let k in l) t - l[k] > 5e3 && (l[k] = t, n[k] || (n[k] = !1))
}, 1e4), m.tabs.onRemoved.addListener(id => {
    tabState.delete(id), injectState.delete(id), l[id] && delete l[id], n[id] && delete n[id]
});