/**
 * GladiusBot Auto-Forge
 * Porta da aba Forja (auto-forge) para o layout do GladiusBot.
 * Roda depois do contentScript; não altera o fluxo existente de fundição/reparo
 * além de pular itens registrados em GldForgeProtect.
 */
(function () {
    "use strict";
    if (window.__GLD_FORGE_LOADED) return;
    window.__GLD_FORGE_LOADED = true;

    const K = {
        enabled: "EnableForge",
        infos: "gld_forge_infos",
        rules: "gld_forge_rules",
        protected: "gld_forge_protected",
        matPrefs: "gld_forge_mat_prefs",
        toolPrefs: "gld_forge_tool_prefs",
        qFilter: "gld_forge_quality_filter",
        pauseUw: "gld_forge_pause_uw",
        minGold: "gld_forge_min_gold",
        checkTime: "gld_forge_checking_time",
        minQuality: "gld_forge_accepted_quality"
    };

    const BASIS_LEVELS = {
        "1-1": 1, "1-2": 1, "1-3": 1, "1-4": 2, "1-5": 3, "1-6": 3,
        "1-7": 4, "1-8": 4, "1-9": 4, "1-10": 5, "1-11": 6, "1-12": 6,
        "1-13": 2, "1-14": 7, "1-15": 8, "1-16": 9, "1-17": 8, "1-18": 9,
        "1-19": 5, "1-20": 7,
        "2-1": 1, "2-2": 2, "2-3": 3, "2-4": 4, "2-5": 5, "2-6": 6,
        "2-7": 7, "2-8": 8, "2-9": 9, "2-10": 10, "2-11": 3, "2-12": 5,
        "3-1": 1, "3-2": 1, "3-3": 2, "3-4": 3, "3-5": 4, "3-6": 5,
        "3-7": 6, "3-8": 7, "3-9": 8, "3-10": 9, "3-11": 10, "3-12": 4,
        "4-1": 1, "4-2": 1, "4-3": 2, "4-4": 2, "4-5": 3, "4-6": 4,
        "4-7": 6, "4-8": 7, "4-9": 9, "4-10": 10, "4-11": 5, "4-12": 8, "4-13": 7,
        "5-1": 1, "5-2": 2, "5-3": 3, "5-4": 4, "5-5": 5, "5-6": 6,
        "5-7": 7, "5-8": 8, "5-9": 9,
        "6-1": 1, "6-2": 1, "6-3": 1, "6-4": 1, "6-5": 1, "6-6": 1,
        "6-7": 1, "6-8": 1,
        "8-1": 1, "8-2": 2, "8-3": 3, "8-4": 4, "8-5": 5, "8-6": 6,
        "8-7": 7, "8-8": 8, "8-9": 9, "8-10": 10,
        "9-1": 1, "9-2": 1, "9-3": 1, "9-4": 1, "9-5": 1, "9-6": 1,
        "9-7": 1, "9-8": 1, "9-9": 1, "9-10": 1
    };

    const CONTAINERS = { material: 384, tool: 769, lootBox: 801 };
    const TOOL_Y = { anvil: 1, bellows: 2, clover: 3, hammer: 4 };
    const TOOL_BASIS = {
        anvil: { bronze: "19-1", silver: "19-2", golden: "19-3" },
        bellows: { bronze: "19-4", silver: "19-5", golden: "19-6" },
        clover: { bronze: "19-7", silver: "19-8", golden: "19-9" },
        hammer: { bronze: "19-10", silver: "19-11", golden: "19-12" }
    };
    const TOOL_FX = {
        clover: { bronze: 1.2, silver: 1.5, golden: 2 },
        bellows: { bronze: 0.85, silver: 0.7, golden: 0.5 },
        anvil: { bronze: 10, silver: 20, golden: 30 },
        hammer: { bronze: 0.85, silver: 0.7, golden: 0.5 }
    };
    const Q_DEFS = [
        { idx: 0, q: -1, color: "#aaa", key: "white" },
        { idx: 1, q: 0, color: "#4CAF50", key: "green" },
        { idx: 2, q: 1, color: "#5159F7", key: "blue" },
        { idx: 3, q: 2, color: "#E303E0", key: "purple" },
        { idx: 4, q: 3, color: "#FF6A00", key: "orange" },
        { idx: 5, q: 4, color: "#FF0000", key: "red" }
    ];
    const MAT_NAMES = {
        1: "Wood", 2: "Copper", 3: "Leather", 4: "Iron", 5: "Pelt", 6: "Bone chip",
        7: "Scale", 8: "Linen", 9: "Bronze", 10: "Coal", 11: "Steel", 12: "Silk",
        13: "Silver", 14: "Gold", 15: "Ruby", 16: "Diamond", 17: "Mithril", 18: "Adamantium",
        19: "Obsidian", 20: "Dragon scale",
        21: "Topaz", 22: "Amethyst", 23: "Amber", 24: "Ruby gem", 25: "Sapphire", 26: "Emerald",
        27: "Diamond gem", 28: "Onyx", 29: "Opal", 30: "Turquoise", 31: "Jade", 32: "Garnet",
        33: "Aquamarine", 34: "Pearl", 35: "Moonstone", 36: "Sunstone",
        45: "Essence", 46: "Dust", 47: "Crystal", 48: "Rune", 49: "Shard", 50: "Core",
        51: "Fragment", 52: "Relic",
        54: "Almandine", 55: "UW ore", 56: "UW gem", 57: "UW hide", 58: "UW bone",
        60: "UW dust", 61: "UW crystal", 62: "UW essence", 63: "UW shard", 64: "UW core"
    };

    const I18N = {
        EN: {
            Forge: "Forge", title: "Auto Forge",
            refresh: "Refresh scrolls", pauseUw: "Pause while in Underworld",
            recipe: "Select recipe", itemType: "Item type", basis: "Base item",
            prefix: "Prefix", suffix: "Suffix", qualities: "Qualities to count",
            materials: "Materials to use", prefQ: "Preferred quality", minQ: "Minimum quality",
            tools: "Tools (optional)", anvil: "Anvil", bellows: "Bellows", clover: "Clover",
            hammer: "Hammer (Bag I)", details: "Recipe details", forgeNow: "Forge now",
            saveRule: "Save as rule", auto: "Auto-forge rules", addRule: "+ Add empty rule",
            tickNow: "Run now", stock: "Horreum stock", openForge: "Open forge page",
            prot: "Forged items (protected from smelting)",
            protNote: "Items created by Auto-Forge are never smelted, even if they match a smelt rule. Remove protection to smelt them again.",
            protEmpty: "No protected forged items yet.", protRemove: "remove", protClear: "Clear list",
            howMany: "How many:", dest: "Destination:", destInv: "Inventory", destPkg: "Packages",
            slots: "Allowed slots:", minGold: "Min gold to forge",
            noScrolls: "No scrolls cached. Open the Forge or click Refresh.",
            loading: "Loading…", noRecipe: "Select a recipe first.",
            noSlot: "No free forge slot.", missing: "Missing materials: {name} ({have}/{need})",
            started: "Forge started in slot {n}", failed: "Forge failed: {msg}",
            bronze: "Bronze", silver: "Silver", golden: "Gold",
            all: "All", none: "None", noneOpt: "-- none --", status: "Status",
            enabled: "On", disabled: "Off", delete: "Delete", edit: "Use recipe",
            duration: "Duration", chance: "Success chance", needed: "Needed",
            white: "White", green: "Green", blue: "Blue", purple: "Purple", orange: "Orange", red: "Red",
            pickType: "-- type --", pickItem: "-- item --",
            ruleName: "Rule", complete: "done", forging: "forging",
            tickOk: "Auto-forge tick finished", pausedUw: "Paused in Underworld",
            lowGold: "Not enough gold", botOff: "Forge is off — turn on the Forja switch",
            skipBusy: "Skipped: another inventory page is open (smelt/repair/packages).",
            tickHelp: "Runs one cycle now: collects finished items and starts active rules. The Forja toggle must be on. With the bot running, cycles also happen automatically until each rule's counter is done.",
            tickBusy: "A forge cycle is already running.",
            tickNoRules: "No active auto-forge rules.",
            tickIdle: "Auto-forge: nothing to do (no free slot or rules already done).",
            tickSummary: "Forge: {started} started, {collected} collected, {failed} failed",
            logForgeStart: "Forge: starting \"{name}\" in slot {n}",
            logForgeStarted: "Forge: \"{name}\" started in slot {n}",
            logForgeFail: "Forge failed in slot {n} ({name})",
            logForgeComplete: "Forge complete: {name} ({c}/{total})",
            logForgeNoMats: "Forge: \"{name}\" missing materials ({mat}: {have}/{need}) — retry in 5 min",
            logForgeCollect: "Forge: collected {name}",
            noRules: "No rules yet. Use \"Save as rule\".",
            rename: "Click to rename",
            renamePrompt: "Rule name:",
            resetCounters: "Reset counters",
            statusActive: "Active",
            statusInactive: "Inactive",
            statusForging: "Forging ({n})",
            statusDone: "Done",
            statusPending: "Waiting",
            fails: "fails",
            confirmDelete: "Delete rule \"{name}\"?",
            editRecipe: "Edit:",
            destBag: "Destination bag:",
            bagI: "Bag I (preferred)",
            bagII: "Bag II",
            bagIII: "Bag III",
            bagIV: "Bag IV",
            bagNote: "(uses another if full)",
            prefShort: "Pref:",
            minShort: "Min:",
            toolOff: "off",
            loadPlanner: "Load in planner",
            autoHelp: "With Forja ON and the bot running, active rules keep forging until success count reaches the target. Then they stop. Reset counters or raise the target to continue."
        },
        BR: {
            Forge: "Forja", title: "Auto Forja",
            refresh: "Atualizar pergaminhos", pauseUw: "Pausar no Submundo",
            recipe: "Selecionar receita", itemType: "Tipo do item", basis: "Item base",
            prefix: "Prefixo", suffix: "Sufixo", qualities: "Qualidades a contar",
            materials: "Materiais a usar", prefQ: "Qualidade preferida", minQ: "Qualidade mínima",
            tools: "Ferramentas (opcional)", anvil: "Bigorna", bellows: "Fole", clover: "Trevo",
            hammer: "Martelo (Bag I)", details: "Detalhes da receita", forgeNow: "Forjar agora",
            saveRule: "Salvar como regra", auto: "Regras de auto-forja", addRule: "+ Adicionar regra vazia",
            tickNow: "Executar agora", stock: "Estoque do Horreum", openForge: "Abrir página da Forja",
            prot: "Itens forjados (protegidos da fundição)",
            protNote: "Itens criados pela forja nunca são fundidos, mesmo que casem uma regra. Remova a proteção para fundir de novo.",
            protEmpty: "Nenhum item forjado protegido ainda.", protRemove: "remover", protClear: "Limpar lista",
            howMany: "Quantas vezes:", dest: "Destino:", destInv: "Inventário", destPkg: "Pacotes",
            slots: "Slots permitidos:", minGold: "Ouro mínimo para forjar",
            noScrolls: "Nenhum pergaminho em cache. Abra a Forja ou clique em Atualizar.",
            loading: "Carregando…", noRecipe: "Selecione uma receita primeiro.",
            noSlot: "Nenhum slot livre na forja.", missing: "Faltam materiais: {name} ({have}/{need})",
            started: "Forja iniciada no slot {n}", failed: "Falha na forja: {msg}",
            bronze: "Bronze", silver: "Prata", golden: "Ouro",
            all: "Tudo", none: "Nenhuma", noneOpt: "-- nenhum --", status: "Status",
            enabled: "Ativa", disabled: "Off", delete: "Excluir", edit: "Usar receita",
            duration: "Duração", chance: "Chance de sucesso", needed: "Necessário",
            white: "Branco", green: "Verde", blue: "Azul", purple: "Roxo", orange: "Laranja", red: "Vermelho",
            pickType: "-- tipo --", pickItem: "-- item --",
            ruleName: "Regra", complete: "concluídas", forging: "forjando",
            tickOk: "Ciclo de auto-forja concluído", pausedUw: "Pausado no Submundo",
            lowGold: "Ouro insuficiente", botOff: "Forja desligada — ligue o interruptor da aba Forja",
            skipBusy: "Pulado: outra página de inventário está aberta (fundição/reparo/pacotes).",
            tickHelp: "Dispara um ciclo agora: colhe itens prontos e inicia regras ativas. O interruptor da Forja precisa estar ligado. Com o bot ligado, o ciclo também roda sozinho até cada regra completar o contador.",
            tickBusy: "Já tem um ciclo de forja em andamento.",
            tickNoRules: "Nenhuma regra de auto-forja ativa.",
            tickIdle: "Auto-forja: nada a fazer (sem slot livre ou regras já concluídas).",
            tickSummary: "Forja: {started} iniciadas, {collected} colhidas, {failed} falhas",
            logForgeStart: "Forja: iniciando \"{name}\" no slot {n}",
            logForgeStarted: "Forja: \"{name}\" iniciada no slot {n}",
            logForgeFail: "Forja falhou no slot {n} ({name})",
            logForgeComplete: "Forja completa: {name} ({c}/{total})",
            logForgeNoMats: "Forja: \"{name}\" sem materiais ({mat}: {have}/{need}) — nova tentativa em 5 min",
            logForgeCollect: "Forja: recolhido {name}",
            noRules: "Nenhuma regra. Use \"Salvar como regra\".",
            rename: "Clique para renomear",
            renamePrompt: "Nome da regra:",
            resetCounters: "Zerar contadores",
            statusActive: "Ativa",
            statusInactive: "Inativa",
            statusForging: "Forjando ({n})",
            statusDone: "Concluída",
            statusPending: "Pendente",
            fails: "falhas",
            confirmDelete: "Excluir a regra \"{name}\"?",
            editRecipe: "Editar:",
            destBag: "Bag de destino:",
            bagI: "Bag I (preferida)",
            bagII: "Bag II",
            bagIII: "Bag III",
            bagIV: "Bag IV",
            bagNote: "(usa outra se estiver cheia)",
            prefShort: "Pref:",
            minShort: "Mín:",
            toolOff: "não",
            loadPlanner: "Carregar no planejador",
            autoHelp: "Com a Forja ligada e o bot ligado, as regras ativas forjam sozinhas até o contador (ex.: 3/10) completar. Depois param. Zere o contador ou aumente a quantidade para continuar."
        },
        PL: {
            Forge: "Kuźnia", title: "Auto-kucie",
            refresh: "Odśwież zwoje", pauseUw: "Wstrzymaj w Podziemiach",
            recipe: "Wybierz recepturę", itemType: "Typ przedmiotu", basis: "Przedmiot bazowy",
            prefix: "Przedrostek", suffix: "Przyrostek", qualities: "Jakości do liczenia",
            materials: "Materiały", prefQ: "Preferowana jakość", minQ: "Minimalna jakość",
            tools: "Narzędzia (opcjonalne)", anvil: "Kowadło", bellows: "Miech", clover: "Koniczyna",
            hammer: "Młot (Torba I)", details: "Szczegóły receptury", forgeNow: "Kuj teraz",
            saveRule: "Zapisz jako regułę", auto: "Reguły auto-kucia", addRule: "+ Dodaj pustą regułę",
            tickNow: "Uruchom teraz", stock: "Zapas Horreum", openForge: "Otwórz kuźnię",
            prot: "Wykute przedmioty (chronione przed przetapianiem)",
            protNote: "Przedmioty z auto-kuźni nie są przetapiane. Usuń ochronę, aby znów je przetapiać.",
            protEmpty: "Brak chronionych przedmiotów.", protRemove: "usuń", protClear: "Wyczyść listę",
            howMany: "Ile razy:", dest: "Cel:", destInv: "Ekwipunek", destPkg: "Paczki",
            slots: "Dozwolone sloty:", minGold: "Min. złoto do kucia",
            noScrolls: "Brak zwojów. Otwórz kuźnię lub kliknij Odśwież.",
            loading: "Ładowanie…", noRecipe: "Najpierw wybierz recepturę.",
            noSlot: "Brak wolnego slotu.", missing: "Brak materiałów: {name} ({have}/{need})",
            started: "Kucie w slocie {n}", failed: "Błąd kucia: {msg}",
            bronze: "Brąz", silver: "Srebro", golden: "Złoto",
            all: "Wszystko", none: "Żadne", noneOpt: "-- brak --", status: "Status",
            enabled: "Wł", disabled: "Wył", delete: "Usuń", edit: "Użyj receptury",
            duration: "Czas", chance: "Szansa", needed: "Potrzeba",
            white: "Biały", green: "Zielony", blue: "Niebieski", purple: "Fioletowy", orange: "Pomarańczowy", red: "Czerwony",
            pickType: "-- typ --", pickItem: "-- przedmiot --",
            ruleName: "Reguła", complete: "ukończone", forging: "kucie",
            tickOk: "Cykl auto-kucia zakończony", pausedUw: "Wstrzymano w Podziemiach",
            lowGold: "Za mało złota", botOff: "Bot wyłączony",
            skipBusy: "Pominięto: otwarta inna strona ekwipunku.",
            tickHelp: "Uruchamia cykl teraz. Przełącznik Kuźni musi być włączony. Przy włączonym bocie cykle idą same, aż licznik reguły się wypełni.",
            tickBusy: "Cykl kucia już trwa.",
            tickNoRules: "Brak aktywnych reguł auto-kucia.",
            tickIdle: "Auto-kucie: nic do zrobienia.",
            tickSummary: "Kuźnia: {started} rozpoczęte, {collected} zebrane, {failed} porażek",
            logForgeStart: "Kuźnia: start \"{name}\" w slocie {n}",
            logForgeStarted: "Kuźnia: \"{name}\" w slocie {n}",
            logForgeFail: "Kucie nieudane w slocie {n} ({name})",
            logForgeComplete: "Kucie ukończone: {name} ({c}/{total})",
            logForgeNoMats: "Kuźnia: \"{name}\" brak materiałów ({mat}: {have}/{need}) — ponów za 5 min",
            logForgeCollect: "Kuźnia: zebrano {name}",
            noRules: "Brak reguł. Użyj \"Zapisz jako regułę\".",
            rename: "Kliknij, aby zmienić nazwę",
            renamePrompt: "Nazwa reguły:",
            resetCounters: "Zeruj liczniki",
            statusActive: "Aktywna",
            statusInactive: "Nieaktywna",
            statusForging: "Kucie ({n})",
            statusDone: "Ukończona",
            statusPending: "Oczekuje",
            fails: "porażki",
            confirmDelete: "Usunąć regułę \"{name}\"?",
            editRecipe: "Edytuj:",
            destBag: "Torba docelowa:",
            bagI: "Torba I (preferowana)",
            bagII: "Torba II",
            bagIII: "Torba III",
            bagIV: "Torba IV",
            bagNote: "(inna, jeśli pełna)",
            prefShort: "Pref:",
            minShort: "Min:",
            toolOff: "nie",
            loadPlanner: "Wczytaj do planera",
            autoHelp: "Przy włączonej Kuźni i bocie aktywne reguły kują same, aż licznik (np. 3/10) się wypełni. Zeruj liczniki lub zwiększ cel, aby kontynuować.",
            botOff: "Kuźnia wyłączona — włącz przełącznik Kuźni"
        },
        ES: {
            Forge: "Forja", title: "Auto forja",
            refresh: "Actualizar pergaminos", pauseUw: "Pausar en Inframundo",
            recipe: "Seleccionar receta", itemType: "Tipo de objeto", basis: "Ítem base",
            prefix: "Prefijo", suffix: "Sufijo", qualities: "Calidades a contar",
            materials: "Materiales", prefQ: "Calidad preferida", minQ: "Calidad mínima",
            tools: "Herramientas (opcional)", anvil: "Yunque", bellows: "Fuelle", clover: "Trébol",
            hammer: "Martillo (Bolsa I)", details: "Detalles", forgeNow: "Forjar ahora",
            saveRule: "Guardar como regla", auto: "Reglas de auto-forja", addRule: "+ Añadir regla vacía",
            tickNow: "Ejecutar ahora", stock: "Stock del Horreum", openForge: "Abrir forja",
            prot: "Ítems forjados (protegidos de fundición)",
            protNote: "Los ítems de la forja no se funden. Quita la protección para fundirlos.",
            protEmpty: "Ningún ítem protegido.", protRemove: "quitar", protClear: "Vaciar lista",
            howMany: "Cuántas veces:", dest: "Destino:", destInv: "Inventario", destPkg: "Paquetes",
            slots: "Huecos permitidos:", minGold: "Oro mínimo",
            noScrolls: "Sin pergaminos. Abre la Forja o pulsa Actualizar.",
            loading: "Cargando…", noRecipe: "Elige una receta.",
            noSlot: "No hay hueco libre.", missing: "Faltan materiales: {name} ({have}/{need})",
            started: "Forja iniciada en hueco {n}", failed: "Error: {msg}",
            bronze: "Bronce", silver: "Plata", golden: "Oro",
            all: "Todo", none: "Ninguna", noneOpt: "-- ninguno --", status: "Estado",
            enabled: "On", disabled: "Off", delete: "Borrar", edit: "Usar receta",
            duration: "Duración", chance: "Éxito", needed: "Necesario",
            white: "Blanco", green: "Verde", blue: "Azul", purple: "Morado", orange: "Naranja", red: "Rojo",
            pickType: "-- tipo --", pickItem: "-- ítem --",
            ruleName: "Regla", complete: "hechas", forging: "forjando",
            tickOk: "Ciclo de auto-forja listo", pausedUw: "Pausado en Inframundo",
            lowGold: "Oro insuficiente", botOff: "Bot apagado",
            skipBusy: "Omitido: otra página de inventario está abierta.",
            tickHelp: "Lanza un ciclo ahora. El interruptor de Forja debe estar activo. Con el bot encendido, sigue solo hasta completar el contador.",
            tickBusy: "Ya hay un ciclo de forja en curso.",
            tickNoRules: "No hay reglas de auto-forja activas.",
            tickIdle: "Auto-forja: nada que hacer.",
            tickSummary: "Forja: {started} iniciadas, {collected} recogidas, {failed} fallos",
            logForgeStart: "Forja: iniciando \"{name}\" en el hueco {n}",
            logForgeStarted: "Forja: \"{name}\" iniciada en el hueco {n}",
            logForgeFail: "Forja fallida en hueco {n} ({name})",
            logForgeComplete: "Forja completa: {name} ({c}/{total})",
            logForgeNoMats: "Forja: \"{name}\" sin materiales ({mat}: {have}/{need}) — reintento en 5 min",
            logForgeCollect: "Forja: recogido {name}",
            noRules: "No hay reglas. Usa \"Guardar como regla\".",
            rename: "Clic para renombrar",
            renamePrompt: "Nombre de la regla:",
            resetCounters: "Reiniciar contadores",
            statusActive: "Activa",
            statusInactive: "Inactiva",
            statusForging: "Forjando ({n})",
            statusDone: "Completada",
            statusPending: "Pendiente",
            fails: "fallos",
            confirmDelete: "¿Borrar la regla \"{name}\"?",
            editRecipe: "Editar:",
            destBag: "Bolsa de destino:",
            bagI: "Bolsa I (preferida)",
            bagII: "Bolsa II",
            bagIII: "Bolsa III",
            bagIV: "Bolsa IV",
            bagNote: "(usa otra si está llena)",
            prefShort: "Pref:",
            minShort: "Mín:",
            toolOff: "no",
            loadPlanner: "Cargar en el planificador",
            autoHelp: "Con Forja y bot encendidos, las reglas activas forjan solas hasta completar el contador (p. ej. 3/10). Reinicia o sube la cantidad para continuar.",
            botOff: "Forja apagada — activa el interruptor de Forja"
        },
        TR: {
            Forge: "Demirhane", title: "Oto demirhane",
            refresh: "Parşömenleri yenile", pauseUw: "Yeraltı Dünyasında duraklat",
            recipe: "Tarif seç", itemType: "Eşya tipi", basis: "Temel eşya",
            prefix: "Önek", suffix: "Sonek", qualities: "Sayılacak kaliteler",
            materials: "Malzemeler", prefQ: "Tercih edilen kalite", minQ: "Minimum kalite",
            tools: "Aletler (isteğe bağlı)", anvil: "Örs", bellows: "Körük", clover: "Yonca",
            hammer: "Çekiç (Çanta I)", details: "Tarif detayı", forgeNow: "Şimdi işle",
            saveRule: "Kural olarak kaydet", auto: "Oto-işleme kuralları", addRule: "+ Boş kural ekle",
            tickNow: "Şimdi çalıştır", stock: "Horreum stoğu", openForge: "Demirhaneyi aç",
            prot: "İşlenen eşyalar (eritmeden korumalı)",
            protNote: "Oto-demirhane eşyaları eritilmez. Korumayı kaldırırsanız eritilebilir.",
            protEmpty: "Korumalı eşya yok.", protRemove: "kaldır", protClear: "Listeyi temizle",
            howMany: "Kaç kez:", dest: "Hedef:", destInv: "Envanter", destPkg: "Paketler",
            slots: "İzinli yuvalar:", minGold: "Minimum altın",
            noScrolls: "Önbellekte parşömen yok. Demirhaneyi açın veya Yenile.",
            loading: "Yükleniyor…", noRecipe: "Önce tarif seçin.",
            noSlot: "Boş yuva yok.", missing: "Malzeme yok: {name} ({have}/{need})",
            started: "Yuva {n} başladı", failed: "Hata: {msg}",
            bronze: "Bronz", silver: "Gümüş", golden: "Altın",
            all: "Hepsi", none: "Hiçbiri", noneOpt: "-- yok --", status: "Durum",
            enabled: "Açık", disabled: "Kapalı", delete: "Sil", edit: "Tarifi kullan",
            duration: "Süre", chance: "Şans", needed: "Gerekli",
            white: "Beyaz", green: "Yeşil", blue: "Mavi", purple: "Mor", orange: "Turuncu", red: "Kırmızı",
            pickType: "-- tip --", pickItem: "-- eşya --",
            ruleName: "Kural", complete: "bitti", forging: "işleniyor",
            tickOk: "Oto-demirhane turu bitti", pausedUw: "Yeraltı Dünyasında duraklatıldı",
            lowGold: "Yetersiz altın", botOff: "Bot kapalı",
            skipBusy: "Atlandı: başka envanter sayfası açık.",
            tickHelp: "Şimdi bir tur çalıştırır. Demirhane anahtarı açık olmalı. Bot açıkken kurallar sayaç dolana kadar kendi kendine işler.",
            tickBusy: "Demirhane turu zaten çalışıyor.",
            tickNoRules: "Aktif oto-işleme kuralı yok.",
            tickIdle: "Oto-demirhane: yapılacak iş yok.",
            tickSummary: "Demirhane: {started} başladı, {collected} toplandı, {failed} başarısız",
            logForgeStart: "Demirhane: \"{name}\" yuva {n} başlıyor",
            logForgeStarted: "Demirhane: \"{name}\" yuva {n} başladı",
            logForgeFail: "Yuva {n} başarısız ({name})",
            logForgeComplete: "Tamamlandı: {name} ({c}/{total})",
            logForgeNoMats: "Demirhane: \"{name}\" malzeme yok ({mat}: {have}/{need}) — 5 dk sonra tekrar",
            logForgeCollect: "Demirhane: {name} toplandı",
            noRules: "Kural yok. \"Kural olarak kaydet\" kullanın.",
            rename: "Yeniden adlandırmak için tıklayın",
            renamePrompt: "Kural adı:",
            resetCounters: "Sayaçları sıfırla",
            statusActive: "Aktif",
            statusInactive: "Kapalı",
            statusForging: "İşleniyor ({n})",
            statusDone: "Tamamlandı",
            statusPending: "Bekliyor",
            fails: "başarısız",
            confirmDelete: "\"{name}\" kuralı silinsin mi?",
            editRecipe: "Düzenle:",
            destBag: "Hedef çanta:",
            bagI: "Çanta I (tercih)",
            bagII: "Çanta II",
            bagIII: "Çanta III",
            bagIV: "Çanta IV",
            bagNote: "(doluysa diğerini kullanır)",
            prefShort: "Tercih:",
            minShort: "Min:",
            toolOff: "yok",
            loadPlanner: "Planlayıcıya yükle",
            autoHelp: "Demirhane ve bot açıkken aktif kurallar sayaç (örn. 3/10) dolana kadar kendi işler. Devam etmek için sayaçları sıfırlayın veya hedefi artırın.",
            botOff: "Demirhane kapalı — Demirhane anahtarını açın"
        },
        FR: {
            Forge: "Forge", title: "Auto-forge",
            refresh: "Actualiser les parchemins", pauseUw: "Pause dans les Enfers",
            recipe: "Choisir une recette", itemType: "Type d'objet", basis: "Objet de base",
            prefix: "Préfixe", suffix: "Suffixe", qualities: "Qualités à compter",
            materials: "Matériaux", prefQ: "Qualité préférée", minQ: "Qualité minimale",
            tools: "Outils (optionnel)", anvil: "Enclume", bellows: "Soufflet", clover: "Trèfle",
            hammer: "Marteau (Sac I)", details: "Détails", forgeNow: "Forger maintenant",
            saveRule: "Enregistrer comme règle", auto: "Règles d'auto-forge", addRule: "+ Règle vide",
            tickNow: "Lancer maintenant", stock: "Stock du Horreum", openForge: "Ouvrir la forge",
            prot: "Objets forgés (protégés de la fonte)",
            protNote: "Les objets de l'auto-forge ne sont jamais fondus. Retirez la protection pour les fondre.",
            protEmpty: "Aucun objet protégé.", protRemove: "retirer", protClear: "Vider la liste",
            howMany: "Combien de fois :", dest: "Destination :", destInv: "Inventaire", destPkg: "Colis",
            slots: "Emplacements autorisés :", minGold: "Or minimum",
            noScrolls: "Aucun parchemin. Ouvrez la Forge ou Actualiser.",
            loading: "Chargement…", noRecipe: "Choisissez une recette.",
            noSlot: "Aucun emplacement libre.", missing: "Matériaux manquants : {name} ({have}/{need})",
            started: "Forge lancée à l'emplacement {n}", failed: "Échec : {msg}",
            bronze: "Bronze", silver: "Argent", golden: "Or",
            all: "Tout", none: "Aucune", noneOpt: "-- aucun --", status: "Statut",
            enabled: "On", disabled: "Off", delete: "Supprimer", edit: "Utiliser la recette",
            duration: "Durée", chance: "Chance", needed: "Nécessaire",
            white: "Blanc", green: "Vert", blue: "Bleu", purple: "Violet", orange: "Orange", red: "Rouge",
            pickType: "-- type --", pickItem: "-- objet --",
            ruleName: "Règle", complete: "terminées", forging: "en cours",
            tickOk: "Cycle d'auto-forge terminé", pausedUw: "En pause dans les Enfers",
            lowGold: "Pas assez d'or", botOff: "Bot arrêté",
            skipBusy: "Ignoré : une autre page d'inventaire est ouverte.",
            tickHelp: "Lance un cycle maintenant. L'interrupteur Forge doit être activé. Avec le bot allumé, les cycles continuent jusqu'au compteur.",
            tickBusy: "Un cycle de forge est déjà en cours.",
            tickNoRules: "Aucune règle d'auto-forge active.",
            tickIdle: "Auto-forge : rien à faire.",
            tickSummary: "Forge : {started} lancées, {collected} récupérées, {failed} échecs",
            logForgeStart: "Forge : démarrage de \"{name}\" emplacement {n}",
            logForgeStarted: "Forge : \"{name}\" lancée emplacement {n}",
            logForgeFail: "Échec emplacement {n} ({name})",
            logForgeComplete: "Forge terminée : {name} ({c}/{total})",
            logForgeNoMats: "Forge : \"{name}\" matériaux manquants ({mat}: {have}/{need}) — nouvel essai dans 5 min",
            logForgeCollect: "Forge : {name} récupéré",
            noRules: "Aucune règle. Utilisez \"Enregistrer comme règle\".",
            rename: "Cliquer pour renommer",
            renamePrompt: "Nom de la règle :",
            resetCounters: "Réinitialiser les compteurs",
            statusActive: "Active",
            statusInactive: "Inactive",
            statusForging: "En cours ({n})",
            statusDone: "Terminée",
            statusPending: "En attente",
            fails: "échecs",
            confirmDelete: "Supprimer la règle \"{name}\" ?",
            editRecipe: "Modifier :",
            destBag: "Sac de destination :",
            bagI: "Sac I (préféré)",
            bagII: "Sac II",
            bagIII: "Sac III",
            bagIV: "Sac IV",
            bagNote: "(un autre si plein)",
            prefShort: "Préf :",
            minShort: "Min :",
            toolOff: "non",
            loadPlanner: "Charger dans le planificateur",
            autoHelp: "Forge et bot allumés : les règles actives forgent seules jusqu'au compteur (ex. 3/10). Réinitialisez ou augmentez le nombre pour continuer.",
            botOff: "Forge désactivée — activez l'interrupteur Forge"
        },
        HG: {
            Forge: "Kovács", title: "Auto-kovácsolás",
            refresh: "Tekercsek frissítése", pauseUw: "Szünet az Alvilágban",
            recipe: "Recept választása", itemType: "Tárgytípus", basis: "Alaptárgy",
            prefix: "Előtag", suffix: "Utótag", qualities: "Számított minőségek",
            materials: "Anyagok", prefQ: "Előnyben részesített minőség", minQ: "Minimum minőség",
            tools: "Eszközök (opcionális)", anvil: "Üllő", bellows: "Fújtató", clover: "Lóhere",
            hammer: "Kalapács (I. táska)", details: "Recept részletei", forgeNow: "Kovácsolás most",
            saveRule: "Mentés szabályként", auto: "Auto-kovácsolás szabályok", addRule: "+ Üres szabály",
            tickNow: "Futtatás most", stock: "Horreum készlet", openForge: "Kovács megnyitása",
            prot: "Kovácsolt tárgyak (olvasztás ellen védve)",
            protNote: "Az auto-kovács tárgyait nem olvasztjuk. Vedd le a védelmet, ha olvasztani akarod.",
            protEmpty: "Nincs védett tárgy.", protRemove: "eltávolít", protClear: "Lista törlése",
            howMany: "Hányszor:", dest: "Cél:", destInv: "Leltár", destPkg: "Csomagok",
            slots: "Engedélyezett slotok:", minGold: "Minimum arany",
            noScrolls: "Nincs gyorsítótárazott tekercs. Nyisd meg a kovácsot.",
            loading: "Betöltés…", noRecipe: "Előbb válassz receptet.",
            noSlot: "Nincs szabad slot.", missing: "Hiányzó anyag: {name} ({have}/{need})",
            started: "Kovácsolás a(z) {n}. slotban", failed: "Hiba: {msg}",
            bronze: "Bronz", silver: "Ezüst", golden: "Arany",
            all: "Mind", none: "Egyik sem", noneOpt: "-- nincs --", status: "Állapot",
            enabled: "Be", disabled: "Ki", delete: "Törlés", edit: "Recept használata",
            duration: "Idő", chance: "Esély", needed: "Szükséges",
            white: "Fehér", green: "Zöld", blue: "Kék", purple: "Lila", orange: "Narancs", red: "Piros",
            pickType: "-- típus --", pickItem: "-- tárgy --",
            ruleName: "Szabály", complete: "kész", forging: "kovácsol",
            tickOk: "Auto-kovács ciklus kész", pausedUw: "Szünet az Alvilágban",
            lowGold: "Nincs elég arany", botOff: "Bot kikapcsolva",
            skipBusy: "Kihagyva: másik leltár oldal nyitva.",
            tickHelp: "Most futtat egy ciklust. A Kovács kapcsolónak be kell lennie. Bot mellett a szabályok a számlálóig maguktól kovácsolnak.",
            tickBusy: "Már fut egy kovácsciklus.",
            tickNoRules: "Nincs aktív auto-kovács szabály.",
            tickIdle: "Auto-kovács: nincs teendő.",
            tickSummary: "Kovács: {started} indítva, {collected} begyűjtve, {failed} hiba",
            logForgeStart: "Kovács: \"{name}\" indítása a(z) {n}. slotban",
            logForgeStarted: "Kovács: \"{name}\" a(z) {n}. slotban",
            logForgeFail: "Sikertelen a(z) {n}. slotban ({name})",
            logForgeComplete: "Kész: {name} ({c}/{total})",
            logForgeNoMats: "Kovács: \"{name}\" nincs anyag ({mat}: {have}/{need}) — 5 perc múlva újra",
            logForgeCollect: "Kovács: {name} begyűjtve",
            noRules: "Nincs szabály. Használd a \"Mentés szabályként\" gombot.",
            rename: "Kattints az átnevezéshez",
            renamePrompt: "Szabály neve:",
            resetCounters: "Számlálók nullázása",
            statusActive: "Aktív",
            statusInactive: "Inaktív",
            statusForging: "Kovácsol ({n})",
            statusDone: "Kész",
            statusPending: "Várakozik",
            fails: "hiba",
            confirmDelete: "Törlöd a(z) \"{name}\" szabályt?",
            editRecipe: "Szerkesztés:",
            destBag: "Cél táska:",
            bagI: "I. táska (elsődleges)",
            bagII: "II. táska",
            bagIII: "III. táska",
            bagIV: "IV. táska",
            bagNote: "(másikat használ, ha tele)",
            prefShort: "Előny:",
            minShort: "Min:",
            toolOff: "nem",
            loadPlanner: "Betöltés a tervezőbe",
            autoHelp: "Bekapcsolt Kovács és bot mellett az aktív szabályok a számlálóig (pl. 3/10) maguktól mennek. Folytatáshoz nullázd vagy emeld a célt.",
            botOff: "Kovács ki — kapcsold be a Kovács kapcsolót"
        }
    };

    const TYPE_ICON = {
        "1": "sword-image", "2": "shield-image", "3": "chest-image", "4": "helmet-image",
        "5": "gloves-image", "6": "ring1-image", "8": "shoes-image", "9": "necklace-image"
    };
    const TOOL_SPRITE = {
        anvil: { bronze: "19-1", silver: "19-2", golden: "19-3" },
        bellows: { bronze: "19-4", silver: "19-5", golden: "19-6" },
        clover: { bronze: "19-7", silver: "19-8", golden: "19-9" },
        hammer: { bronze: "19-10", silver: "19-11", golden: "19-12" }
    };

    function lang() {
        let v = (localStorage.getItem("settings.language") || "EN").toUpperCase();
        if (v === "GB" || v === "EN-GB") v = "EN";
        if (v === "HU" || v === "HUN") v = "HG";
        if (v === "PT" || v === "PT-BR" || v === "PTBR") v = "BR";
        const pack = I18N[v] || I18N.EN;
        return Object.assign({}, I18N.EN, pack);
    }
    function t(key, vars) {
        let s = lang()[key] || I18N.EN[key] || key;
        if (vars) Object.keys(vars).forEach(k => { s = s.split("{" + k + "}").join(vars[k]); });
        return s;
    }
    function lsGet(key, def) {
        try {
            const v = localStorage.getItem(key);
            return v == null ? def : v;
        } catch (e) { return def; }
    }
    function lsJson(key, def) {
        try {
            const v = JSON.parse(lsGet(key, "") || "null");
            return v == null ? def : v;
        } catch (e) { return def; }
    }
    function lsSet(key, val) {
        try { localStorage.setItem(key, typeof val === "string" ? val : JSON.stringify(val)); } catch (e) {}
    }
    function forgeLog(msg) {
        if (!msg) return;
        try { if (typeof window.gldLog === "function") { window.gldLog(msg); return; } } catch (e) {}
        const box = document.querySelector("#logEntriesContainer");
        if (!box) return;
        const a = new Date();
        const hh = String(a.getHours()).padStart(2, "0");
        const mm = String(a.getMinutes()).padStart(2, "0");
        const p = document.createElement("p");
        p.style.cssText = "margin:0;padding:0;font-size:12px";
        p.textContent = "[" + hh + ":" + mm + "] " + msg;
        box.prepend(p);
        while (box.childElementCount > 30) box.removeChild(box.lastChild);
        try {
            const n = JSON.parse(localStorage.getItem("savedLogs") || "[]");
            n.unshift(p.textContent);
            if (n.length > 30) n.pop();
            localStorage.setItem("savedLogs", JSON.stringify(n));
        } catch (e) {}
    }
    function csrf() { return document.querySelector('meta[name="csrf-token"]')?.content || ""; }
    function sh() { return new URLSearchParams(location.search).get("sh") || ""; }
    function ajaxLink(p) {
        const q = new URLSearchParams(Object.assign({}, p, { sh: sh() }));
        return location.origin + "/game/ajax.php?" + q.toString();
    }
    function pageLink(p) {
        const q = new URLSearchParams(Object.assign({}, p, { sh: sh() }));
        return location.origin + "/game/index.php?" + q.toString();
    }
    async function httpGet(url) {
        const r = await fetch(url, { credentials: "include", headers: { "x-csrf-token": csrf() } });
        return r.text();
    }
    async function httpPost(url, body) {
        const r = await fetch(url, {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "x-csrf-token": csrf()
            },
            body: new URLSearchParams(Object.assign({ a: String(Date.now()), csrf_token: csrf() }, body || {}))
        });
        return r.text();
    }

    function hashDecode(e) {
        const t = "0123456789abcdefghijklmnopqrstuvwxyz";
        return [...String(e)].reduce((a, o, i, arr) => a + t.indexOf(o) * Math.pow(t.length, arr.length - i - 1), 0);
    }
    function itemPrefixSuffix(el) {
        const hash = el.getAttribute && el.getAttribute("data-hash");
        if (!hash) return { prefix: 0, suffix: 0 };
        const p = hash.split("-");
        if (p.length < 7) return { prefix: 0, suffix: 0 };
        return { prefix: hashDecode(p[5]) || 0, suffix: hashDecode(p[6]) || 0 };
    }

    const PROTECT_TTL = 7 * 24 * 60 * 60 * 1000;
    function protectLoad() {
        const arr = lsJson(K.protected, []);
        if (!Array.isArray(arr)) return [];
        const cut = Date.now() - PROTECT_TTL;
        return arr.filter(e => e && e.at > cut);
    }
    function protectSave(arr) { lsSet(K.protected, arr.slice(-200)); }
    function sameKey(e, item) {
        return e.basis === (item.basis || "") &&
            Number(e.prefix || 0) === Number(item.prefix || 0) &&
            Number(e.suffix || 0) === Number(item.suffix || 0) &&
            Number(e.quality) === Number(item.quality != null ? item.quality : -1);
    }
    window.GldForgeProtect = {
        register(item) {
            const arr = protectLoad().filter(e => !sameKey(e, item));
            arr.push({
                basis: item.basis || "",
                prefix: item.prefix || 0,
                suffix: item.suffix || 0,
                quality: item.quality != null ? item.quality : -1,
                name: item.name || "",
                at: Date.now()
            });
            protectSave(arr);
        },
        isProtected(el) {
            if (!el || !el.getAttribute) return false;
            const basis = el.getAttribute("data-basis") || "";
            const quality = parseInt(el.getAttribute("data-quality") || "-1", 10);
            const ps = itemPrefixSuffix(el);
            return protectLoad().some(e => sameKey(e, { basis, prefix: ps.prefix, suffix: ps.suffix, quality }));
        },
        list: protectLoad,
        remove(item) {
            const before = protectLoad();
            const after = before.filter(e => !sameKey(e, item));
            protectSave(after);
            return after.length < before.length;
        },
        clear() { try { localStorage.removeItem(K.protected); } catch (e) {} }
    };

    const Api = {
        async getForgePage() { return httpGet(pageLink({ mod: "forge", submod: "forge" })); },
        storeInfos(html) {
            const doc = new DOMParser().parseFromString(html, "text/html");
            const basics = [...doc.querySelectorAll("#basic0 optgroup")];
            const prefixSel = doc.querySelector("#prefix0") || doc.querySelector("#forge_formula_prefix");
            const suffixSel = doc.querySelector("#suffix0") || doc.querySelector("#forge_formula_suffix");
            const basisSel = doc.querySelector("#forge_formula_basis") || doc.querySelector("#basic0");
            const LVL_RE = /\(\d+lvl\)/gi;
            const infos = {
                prefixes: prefixSel ? [...prefixSel.options].map(opt => {
                    const lvl = parseInt(opt.getAttribute("data-level") || "0", 10);
                    const v = parseInt(opt.value, 10) || 0;
                    return { value: v, text: v === 0 ? t("noneOpt") : (lvl ? `(${lvl}lvl) ` : "") + opt.text.replace(LVL_RE, "").trim(), level: lvl };
                }) : [],
                suffixes: suffixSel ? [...suffixSel.options].map(opt => {
                    const lvl = parseInt(opt.getAttribute("data-level") || "0", 10);
                    const v = parseInt(opt.value, 10) || 0;
                    return { value: v, text: v === 0 ? t("noneOpt") : (lvl ? `(${lvl}lvl) ` : "") + opt.text.replace(LVL_RE, "").trim(), level: lvl };
                }) : [],
                basics: basics.length ? basics.map(og => {
                    const items = [...og.querySelectorAll("option")].map(opt => {
                        const v = opt.value;
                        const lvl = BASIS_LEVELS[v] || 0;
                        return { value: v, text: `(${lvl}lvl) ${opt.text.replace(LVL_RE, "").trim()}`, level: lvl };
                    }).sort((a, b) => a.level - b.level);
                    return { group: og.getAttribute("label") || "", items };
                }) : []
            };
            if (!infos.basics.length && basisSel) {
                const groups = {};
                [...basisSel.options].forEach(opt => {
                    if (!opt.value) return;
                    const grp = opt.parentElement.tagName === "OPTGROUP" ? opt.parentElement.getAttribute("label") : "Items";
                    groups[grp] = groups[grp] || [];
                    const lvl = BASIS_LEVELS[opt.value] || 0;
                    groups[grp].push({ value: opt.value, text: opt.text.replace(LVL_RE, "").trim(), level: lvl });
                });
                infos.basics = Object.keys(groups).map(g => ({ group: g, items: groups[g] }));
            }
            lsSet(K.infos, infos);
            return infos;
        },
        async refreshScrolls() {
            const html = await this.getForgePage();
            return this.storeInfos(html);
        },
        loadInfos() { return lsJson(K.infos, { prefixes: [], suffixes: [], basics: [] }); },
        async getPreview(prefix, basis, suffix) {
            const raw = await httpPost(ajaxLink({ mod: "forge", submod: "getPreview" }), {
                mod: "forge", submod: "getPreview", slot: 0, item: basis, prefix: prefix || 0, suffix: suffix || 0
            });
            let parsed;
            try { parsed = JSON.parse(raw); } catch (e) { return null; }
            if (!parsed || parsed.mode !== "forging") return null;
            const formula = parsed.formula || {};
            if (parsed.item) {
                formula.name = parsed.item.name;
                if (parsed.item.data) {
                    formula.level = parsed.item.data.level;
                    formula.tooltip = parsed.item.data.tooltip;
                }
            }
            if (parsed.header && parsed.header.gold) formula._currentGold = parsed.header.gold.value;
            return formula;
        },
        async getSlots() {
            const html = await this.getForgePage();
            const m = String(html).match(/slotsData\s*=\s*(\[[\s\S]*?\])\s*;/);
            if (!m) return null;
            let arr;
            try { arr = JSON.parse(m[1]); } catch (e) { return null; }
            return arr.map((s, i) => {
                const state = s["forge_slots.state"] || "closed";
                const itemData = s.item ? s.item.data : null;
                if (itemData) itemData.containerNumber = s["items.posi"] || (CONTAINERS.lootBox + i);
                return {
                    index: i,
                    state,
                    isClosed: state === "closed",
                    isOpened: state === "opened",
                    isCrafting: state === "crafting",
                    isFinished: String(state).indexOf("finished") > -1,
                    isFailed: state === "finished-failed",
                    duration: s["forge_slots.finishedIn"] || -1,
                    itemData,
                    itemHash: (itemData && itemData.hash) || (s.item && s.item.hash) || s["items.hash"] || null
                };
            });
        },
        async rentSlot(slot, prefix, suffix, basis) {
            return httpPost(ajaxLink({ mod: "forge", submod: "rent" }), {
                mod: "forge", submod: "rent", mode: "forging", slot, rent: "2",
                item: basis, prefix: prefix || 0, suffix: suffix || 0
            });
        },
        async startForging(slot) {
            return httpPost(ajaxLink({ mod: "forge", submod: "start" }), {
                mod: "forge", submod: "start", mode: "forging", slot
            });
        },
        async cancelForge(slot) {
            return httpPost(ajaxLink({ mod: "forge", submod: "cancel" }), {
                mod: "forge", submod: "cancel", mode: "forging", slot
            });
        },
        async freeFailed(slot) {
            return httpPost(ajaxLink({ mod: "forge", submod: "lootbox" }), {
                mod: "forge", submod: "lootbox", mode: "forging", slot
            });
        },
        async storageOut(matId, quality, amount) {
            return httpPost(ajaxLink({ mod: "forge", submod: "storageOut" }), {
                type: matId, quality, amount
            });
        },
        async storageToWarehouse(slot, quality) {
            return httpPost(ajaxLink({ mod: "forge", submod: "storageToWarehouse" }), {
                mod: "forge", submod: "storageToWarehouse", mode: "forging", slot, quality
            });
        },
        async toWarehouse(slot, iid, amount) {
            return httpPost(ajaxLink({ mod: "forge", submod: "toWarehouse" }), {
                mod: "forge", submod: "toWarehouse", mode: "forging", slot, iid, amount
            });
        },
        async getBag(bagId) {
            return httpGet(ajaxLink({ mod: "inventory", submod: "loadBag", bag: bagId, shopType: 0 }));
        },
        parseBag(html) {
            if (!html) return [];
            const doc = new DOMParser().parseFromString("<div>" + html + "</div>", "text/html");
            return [...doc.querySelectorAll("[data-content-type][data-item-id]")].map(el => ({
                basis: el.getAttribute("data-basis") || "",
                quality: parseInt(el.getAttribute("data-quality") || "-1", 10),
                x: parseInt(el.getAttribute("data-position-x") || "0", 10),
                y: parseInt(el.getAttribute("data-position-y") || "0", 10),
                measurementX: parseInt(el.getAttribute("data-measurement-x") || "1", 10),
                measurementY: parseInt(el.getAttribute("data-measurement-y") || "1", 10),
                amount: parseInt(el.getAttribute("data-amount") || "1", 10),
                itemId: parseInt(el.getAttribute("data-item-id") || "0", 10)
            }));
        },
        async moveInv(from, fromX, fromY, to, toX, toY, amount) {
            const raw = await httpPost(ajaxLink({
                mod: "inventory", submod: "move", from, fromX, fromY, to, toX, toY, amount: amount || 1, doll: 1
            }), {});
            try {
                const parsed = JSON.parse(raw);
                return parsed && parsed.to && parsed.to.data ? parsed.to.data : parsed;
            } catch (e) { return false; }
        },
        async findItem(basis, quality) {
            for (const bag of [512, 513, 514, 515, 516, 517, 518, 519]) {
                let items = [];
                try { items = this.parseBag(await this.getBag(bag)); } catch (e) { continue; }
                const found = items.find(it => it.basis === basis && (quality == null || it.quality === quality));
                if (found) return { bagId: bag, x: found.x, y: found.y, amount: found.amount, itemId: found.itemId };
            }
            return null;
        },
        async findFreeSpot(w, h, preferBag) {
            const bags = preferBag ? [preferBag, 512, 513, 514, 515].filter((v, i, a) => a.indexOf(v) === i) : [512, 513, 514, 515];
            w = w || 1; h = h || 1;
            for (const bag of bags) {
                let items = [];
                try { items = this.parseBag(await this.getBag(bag)); } catch (e) { continue; }
                const occ = {};
                items.forEach(it => {
                    for (let yy = 0; yy < (it.measurementY || 1); yy++)
                        for (let xx = 0; xx < (it.measurementX || 1); xx++)
                            occ[(it.x + xx) + "," + (it.y + yy)] = true;
                });
                for (let y = 1; y <= 6; y++) {
                    for (let x = 1; x <= 8; x++) {
                        let ok = true;
                        for (let yy = 0; yy < h && ok; yy++)
                            for (let xx = 0; xx < w && ok; xx++)
                                if (x + xx > 8 || y + yy > 5 || occ[(x + xx) + "," + (y + yy)]) ok = false;
                        if (ok) return { bagId: bag, x, y };
                    }
                }
            }
            return null;
        },
        async loadHorreum() {
            const html = await httpGet(pageLink({ mod: "forge", submod: "storage" }));
            let m = html.match(/<input[^>]*class="resource-amount"[^>]*data-max="([^"]+)"/i)
                || html.match(/data-max="([^"]+)"[^>]*class="resource-amount"/i)
                || html.match(/<input id="resource-amount"[^>]*data-max="([^"]+)"/i);
            if (!m) return null;
            let raw;
            try { raw = JSON.parse(m[1].replace(/&quot;/g, '"')); } catch (e) { return null; }
            const out = {};
            for (const id in raw) {
                out[id] = [0, 0, 0, 0, 0, 0];
                for (const q in raw[id]) {
                    const idx = parseInt(q, 10) + 1;
                    if (idx >= 0 && idx < 6) out[id][idx] = raw[id][q];
                }
            }
            return out;
        },
        async packagesLoadMore(f, fq, page) {
            return httpGet(ajaxLink({ mod: "packages", submod: "loadMore", f, fq, qry: "", page: page || 1 }));
        }
    };

    function distributeMaterials(needed, available, preferida, minima) {
        if (preferida < minima) { const tmp = preferida; preferida = minima; minima = tmp; }
        const out = [];
        for (const k in needed) {
            const matId = parseInt(String(k).substring(2), 10);
            const need = parseInt((needed[k] && typeof needed[k] === "object") ? needed[k].amount : needed[k], 10) || 0;
            if (!isFinite(matId) || need <= 0) continue;
            const stock = available[matId];
            if (!stock) return { ok: false, missing: { matId, name: (needed[k] && needed[k].name) || ("id " + matId), need, have: 0 } };
            let acc = 0;
            for (let q = preferida; q >= minima; q--) {
                if (acc >= need) break;
                const have = stock[q] || 0;
                if (have <= 0) continue;
                const take = Math.min(need - acc, have);
                out.push({ matId, quality: q - 1, amount: take });
                acc += take;
            }
            if (acc < need) return { ok: false, missing: { matId, name: (needed[k] && needed[k].name) || ("id " + matId), need, have: acc } };
        }
        return { ok: true, plan: out };
    }

    function findPackId(resp, matId) {
        if (!resp) return null;
        let source = resp;
        if (typeof resp === "string") {
            const tr = resp.trim();
            if (tr[0] === "{" || tr[0] === "[") {
                try {
                    const j = JSON.parse(tr);
                    if (j && Array.isArray(j.newPackages)) source = j.newPackages.join("");
                } catch (e) {}
            }
        }
        const doc = new DOMParser().parseFromString("<div>" + source + "</div>", "text/html");
        const items = [...doc.querySelectorAll(".packageItem")];
        for (const it of items) {
            const ct = it.querySelector("[data-content-type]");
            if (!ct) continue;
            const basis = ct.getAttribute("data-basis") || "";
            if (basis !== "18-" + matId) continue;
            const input = it.querySelector('input[name="packages[]"]') || it.querySelector("input");
            if (input && input.value) return input.value;
            const cn = it.querySelector("[data-container-number]") || it.closest("[data-container-number]");
            if (cn) return String(cn.getAttribute("data-container-number") || "").replace(/^-/, "");
        }
        return null;
    }

    async function addMaterialToSlot(matId, quality, amount, slotIdx) {
        await Api.storageOut(matId, quality, amount);
        let packId = null;
        const fqTries = quality === -1 ? [-1] : [quality, -1];
        for (const fq of fqTries) {
            if (packId) break;
            packId = findPackId(await Api.packagesLoadMore(18, fq, 1), matId);
        }
        if (!packId) throw new Error("package not found for material " + matId);
        const spot = await Api.findFreeSpot(1, 1, 512);
        if (!spot) throw new Error("no bag space");
        const movePkg = await Api.moveInv("-" + packId, 1, 1, spot.bagId, spot.x, spot.y, amount);
        const invItemId = movePkg && (movePkg.itemId || movePkg.iid);
        if (!invItemId) throw new Error("no itemId after pack->inv");
        const tw = await Api.toWarehouse(slotIdx, invItemId, amount);
        if (!tw) throw new Error("toWarehouse failed");
    }

    async function runForgeOnce(rule, slotIdx) {
        const preview = await Api.getPreview(rule.prefix || 0, rule.basis, rule.suffix || 0);
        if (!preview) return { ok: false, stage: "preview", error: new Error("no recipe") };
        const mats = await Api.loadHorreum();
        if (!mats) return { ok: false, stage: "horreum", error: new Error("horreum") };
        const dist = distributeMaterials(preview.needed || {}, mats, rule.materials.preferida, rule.materials.minima);
        if (!dist.ok) return { ok: false, stage: "materials", missingMat: dist.missing, error: new Error("materials") };

        const sameQ = rule.materials.preferida === rule.materials.minima;
        await Api.rentSlot(slotIdx, rule.prefix || 0, rule.suffix || 0, rule.basis);
        const afterRent = await Api.getSlots();
        const slotNow = afterRent && afterRent[slotIdx];
        if (!slotNow || !slotNow.isOpened) return { ok: false, stage: "rent", error: new Error("rent") };

        try {
            if (sameQ) {
                const q = Q_DEFS[rule.materials.preferida] ? Q_DEFS[rule.materials.preferida].q : -1;
                await Api.storageToWarehouse(slotIdx, q);
            } else {
                for (const item of dist.plan) await addMaterialToSlot(item.matId, item.quality, item.amount, slotIdx);
            }
            const tools = rule.tools || {};
            for (const tk of ["anvil", "bellows", "clover", "hammer"]) {
                const qlvl = tools[tk];
                if (!qlvl) continue;
                const basis = TOOL_BASIS[tk] && TOOL_BASIS[tk][qlvl];
                if (!basis) continue;
                const found = tk === "hammer" ? await (async () => {
                    const items = Api.parseBag(await Api.getBag(512));
                    const it = items.find(i => i.basis === basis);
                    return it ? { bagId: 512, x: it.x, y: it.y } : await Api.findItem(basis, null);
                })() : await Api.findItem(basis, null);
                if (!found) continue;
                try { await Api.moveInv(found.bagId, found.x, found.y, CONTAINERS.tool, slotIdx + 1, TOOL_Y[tk], 1); } catch (e) {}
            }
            await Api.startForging(slotIdx);
            const finalSlots = await Api.getSlots();
            const finalSlot = finalSlots && finalSlots[slotIdx];
            if (!finalSlot || !finalSlot.isCrafting) return { ok: false, stage: "start", error: new Error("not crafting") };
            return { ok: true, slot: slotIdx, durationSec: finalSlot.duration || preview.duration || 0, itemName: preview.name || rule.basis, preview };
        } catch (e) {
            try { await Api.cancelForge(slotIdx); } catch (e2) {}
            return { ok: false, stage: "exec", error: e };
        }
    }

    function loadRules() {
        const arr = lsJson(K.rules, []);
        return Array.isArray(arr) ? arr : [];
    }
    function saveRules(arr) {
        lsSet(K.rules, arr);
        lsSet(K.checkTime, "0");
    }
    function updateRule(id, mutator) {
        const rules = loadRules();
        const r = rules.find(x => x.id === id);
        if (!r) return;
        mutator(r);
        saveRules(rules);
    }
    function currentRecipeState() {
        const mat = lsJson(K.matPrefs, { preferida: 0, minima: 0 });
        const tools = lsJson(K.toolPrefs, {});
        const toolOut = {};
        ["anvil", "bellows", "clover", "hammer"].forEach(k => {
            toolOut[k] = tools[k] && tools[k].use ? (tools[k].quality || "golden") : null;
        });
        return { mat, toolOut };
    }

    function getSlotRecipe(slot) {
        const data = slot && slot.itemData;
        if (!data || !data.basis) return null;
        let prefix = 0, suffix = 0;
        const h = data.hash ? String(data.hash).split("-") : [];
        if (h.length >= 7) {
            const pp = parseInt(h[5], 36), ss = parseInt(h[6], 36);
            if (isFinite(pp) && pp > 0) prefix = pp;
            if (isFinite(ss) && ss > 0) suffix = ss;
        }
        return { basis: data.basis, prefix, suffix };
    }
    function findRuleForSlot(rules, slot) {
        const recipe = getSlotRecipe(slot);
        if (recipe) {
            const byRecipe = rules.find(r =>
                (r.prefix || 0) == recipe.prefix &&
                (r.suffix || 0) == recipe.suffix &&
                r.basis == recipe.basis
            );
            if (byRecipe) return byRecipe;
        }
        return rules.find(r => Array.isArray(r.boundSlots) && r.boundSlots.indexOf(slot.index) > -1) || null;
    }

    let ticking = false;
    async function reconcile(slots, rules) {
        let collected = 0, failed = 0;
        for (const slot of slots) {
            if (!slot.isFinished) continue;
            const matched = findRuleForSlot(rules, slot);
            const ruleName = (matched && (matched.name || matched.basis)) || (slot.itemData && (slot.itemData.itemName || slot.itemData.name)) || ("#" + (slot.index + 1));
            if (slot.isFailed) {
                if (matched) matched.failCount = (matched.failCount || 0) + 1;
                try { await Api.freeFailed(slot.index); } catch (e) {}
                if (matched) matched.boundSlots = (matched.boundSlots || []).filter(i => i !== slot.index);
                forgeLog(t("logForgeFail", { n: slot.index + 1, name: ruleName }));
                failed++;
                continue;
            }
            const itemData = slot.itemData || {};
            const itemCn = itemData.containerNumber || (CONTAINERS.lootBox + slot.index);
            const itemQuality = typeof itemData.quality === "number" ? itemData.quality : -1;
            const w = Math.max(1, parseInt(itemData.measurementX, 10) || 1);
            const h = Math.max(1, parseInt(itemData.measurementY, 10) || 1);
            const dest = matched ? (matched.sendItemTo || "inventory") : "inventory";
            const prefer = matched && matched.sendItemToBag ? matched.sendItemToBag : 512;
            const spot = await Api.findFreeSpot(w, h, prefer);
            if (!spot) continue;
            const moved = await Api.moveInv(itemCn, 1, 1, spot.bagId, spot.x, spot.y, 1);
            if (!moved) continue;
            if (dest === "package") {
                try { await Api.moveInv(spot.bagId, spot.x, spot.y, -1, 1, 1, 1); } catch (e) {}
            }
            if (matched) {
                matched.successCount = (matched.successCount || 0) + 1;
                matched.boundSlots = (matched.boundSlots || []).filter(i => i !== slot.index);
                forgeLog(t("logForgeComplete", { name: ruleName, c: matched.successCount, total: matched.count || 0 }));
            } else {
                forgeLog(t("logForgeCollect", { name: ruleName }));
            }
            window.GldForgeProtect.register({
                basis: itemData.basis || (matched && matched.basis) || "",
                prefix: matched ? (matched.prefix || 0) : 0,
                suffix: matched ? (matched.suffix || 0) : 0,
                quality: itemQuality,
                name: itemData.itemName || itemData.name || (matched && matched.name) || ""
            });
            collected++;
        }
        return { collected, failed };
    }

    function inUnderworld() {
        try {
            return !!(document.querySelector(".quest-type.underworld") && location.href.toLowerCase().includes("underworld"))
                || /loc=9|underworld/i.test(location.href);
        } catch (e) { return false; }
    }
    function pageBusy() {
        const u = location.href;
        return /submod=smeltery|submod=workbench|mod=packages/i.test(u);
    }
    function botOn() { return sessionStorage.getItem("autoGoActive") === "true"; }
    function forgeOn() { return lsGet(K.enabled, "false") === "true"; }

    async function tick(opts) {
        const force = !!(opts && opts.force);
        const out = { started: 0, collected: 0, failed: 0, message: "" };
        if (ticking) { out.message = t("tickBusy"); return out; }
        if (!forgeOn()) { out.message = t("botOff"); return out; }
        if (!force && !botOn()) return out;
        if (pageBusy()) {
            out.message = t("skipBusy");
            if (force) forgeLog(out.message);
            return out;
        }
        if (lsGet(K.pauseUw, "false") === "true" && inUnderworld()) {
            out.message = t("pausedUw");
            if (force) forgeLog(out.message);
            return out;
        }
        const minGold = parseInt(lsGet(K.minGold, "0"), 10) || 0;
        const goldEl = document.getElementById("sstat_gold_val") || document.getElementById("sstat_gold_text");
        if (minGold > 0 && goldEl) {
            const g = parseInt(String(goldEl.textContent || "0").replace(/\D/g, ""), 10) || 0;
            if (g < minGold) {
                out.message = t("lowGold");
                if (force) forgeLog(out.message);
                return out;
            }
        }
        const due = parseInt(lsGet(K.checkTime, "0"), 10) || 0;
        if (!force && Date.now() < due) return out;
        ticking = true;
        try {
            const slots = await Api.getSlots();
            if (!slots) {
                out.message = t("failed", { msg: "slots" });
                if (force) forgeLog(out.message);
                return out;
            }
            const rules = loadRules();
            const recon = await reconcile(slots, rules);
            out.collected = recon.collected;
            out.failed = recon.failed;
            rules.forEach(r => { r.forgingCount = 0; });
            const freeIdx = {};
            slots.forEach(s => { if (s.isClosed || s.isOpened) freeIdx[s.index] = true; });
            rules.forEach(r => {
                if (Array.isArray(r.boundSlots)) r.boundSlots = r.boundSlots.filter(i => !freeIdx[i]);
            });
            slots.forEach(s => {
                if (!s.isCrafting) return;
                const m = findRuleForSlot(rules, s);
                if (m) m.forgingCount = (m.forgingCount || 0) + 1;
            });
            const fresh = recon.collected + recon.failed > 0 ? await Api.getSlots() : slots;
            const free = (fresh || []).filter(s => s.isClosed || s.isOpened);
            const activeRules = rules.filter(r => r.active && r.basis);
            if (force && !activeRules.length && !out.collected && !out.failed) {
                out.message = t("tickNoRules");
                forgeLog(out.message);
                saveRules(rules);
                return out;
            }
            for (const rule of rules) {
                if (!rule.active || !rule.basis) continue;
                const target = parseInt(rule.count, 10) || 0;
                const done = (rule.successCount || 0) + (rule.forgingCount || 0);
                if (target > 0 && done >= target) continue;
                if (rule.pendingUntil && Date.now() < rule.pendingUntil) continue;
                const allowed = rule.slots || { 0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1 };
                const slot = free.find(s => allowed[s.index]);
                if (!slot) continue;
                const ruleName = rule.name || rule.basis;
                forgeLog(t("logForgeStart", { name: ruleName, n: slot.index + 1 }));
                const result = await runForgeOnce(rule, slot.index);
                if (result.ok) {
                    rule.boundSlots = rule.boundSlots || [];
                    if (rule.boundSlots.indexOf(slot.index) < 0) rule.boundSlots.push(slot.index);
                    rule.forgingCount = (rule.forgingCount || 0) + 1;
                    free.splice(free.indexOf(slot), 1);
                    out.started++;
                    forgeLog(t("logForgeStarted", { name: result.itemName || ruleName, n: result.slot + 1 }));
                } else if (result.stage === "materials") {
                    rule.pendingUntil = Date.now() + 5 * 60 * 1000;
                    const miss = result.missingMat || {};
                    forgeLog(t("logForgeNoMats", { name: ruleName, mat: miss.name || "?", have: miss.have, need: miss.need }));
                } else {
                    forgeLog(t("failed", { msg: (result.error && result.error.message) || result.stage || "?" }));
                }
            }
            saveRules(rules);
            const next = Math.min(...(fresh || []).filter(s => s.isCrafting && s.duration > 0).map(s => s.duration * 1000), 2 * 60 * 1000);
            lsSet(K.checkTime, String(Date.now() + Math.max(30000, next || 120000)));
            if (out.started || out.collected || out.failed) {
                out.message = t("tickSummary", { started: out.started, collected: out.collected, failed: out.failed });
            } else if (force) {
                out.message = t("tickIdle");
            } else {
                out.message = t("tickOk");
            }
            if (out.message) forgeLog(out.message);
        } catch (e) {
            out.message = t("failed", { msg: e.message || e });
            forgeLog(out.message);
            console.warn("[gld-forge] tick", e);
        } finally { ticking = false; }
        return out;
    }

    window.GldForgeRuntime = {
        tick,
        tickNow(opts) {
            lsSet(K.checkTime, "0");
            return tick(Object.assign({ force: true }, opts || {}));
        }
    };

    function el(tag, attrs, kids) {
        const n = document.createElement(tag);
        if (attrs) Object.keys(attrs).forEach(k => {
            if (k === "text") n.textContent = attrs[k];
            else if (k === "html") n.innerHTML = attrs[k];
            else if (k === "css") n.style.cssText = attrs[k];
            else if (k.slice(0, 2) === "on") n.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
            else n.setAttribute(k, attrs[k]);
        });
        (kids || []).forEach(c => c && n.appendChild(c));
        return n;
    }
    function row(label, child) {
        const r = el("div", { class: "setting-row gld-forge-row" });
        r.appendChild(el("span", { class: "gld-forge-label", text: label }));
        if (child) r.appendChild(child);
        return r;
    }
    function header(txt) {
        return el("div", { class: "settings_tab_title", text: txt });
    }
    function typeIconEl(basis) {
        const t = String(basis || "").split("-")[0];
        return el("div", { class: "gld-forge-type-icon " + (TYPE_ICON[t] || "") });
    }
    function itemSprite(basis, size) {
        if (!basis) return null;
        return el("div", {
            class: "item-i-" + basis + " gld-forge-item-sprite" + (size === "lg" ? " gld-forge-item-sprite--lg" : "")
        });
    }
    function matSprite(id) {
        return el("span", { class: "item-i-18 item-i-18-" + id });
    }
    function fmtDur(sec) {
        if (!sec || sec <= 0) return "?";
        const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = Math.floor(sec % 60);
        const p = [];
        if (h) p.push(h + "h");
        if (m) p.push(m + "min");
        if (!h && m < 5) p.push(s + "s");
        return p.join(" ") || "0s";
    }

    function renderUI() {
        const box = document.getElementById("auto_forge_settings");
        if (!box) return;
        box.dataset.gldForgeUi = "1";
        box.innerHTML = "";
        const L = lang();
        const state = {
            basis: null, prefix: 0, suffix: 0,
            mat: lsJson(K.matPrefs, { preferida: 0, minima: 0 }),
            tools: lsJson(K.toolPrefs, {
                anvil: { use: false, quality: "golden" },
                bellows: { use: false, quality: "golden" },
                clover: { use: false, quality: "golden" },
                hammer: { use: false, quality: "golden" }
            }),
            qFilter: lsJson(K.qFilter, [true, true, true, true, true, true]),
            lastPreview: null
        };
        if (!Array.isArray(state.qFilter) || state.qFilter.length !== 6) state.qFilter = [true, true, true, true, true, true];

        box.appendChild(header(L.title));

        const statusText = el("span", { class: "gld-forge-status", text: "" });
        const refreshBtn = el("button", { class: "gld-btn", text: L.refresh });
        const statusRow = row(L.status, el("div", { css: "display:flex;gap:8px;align-items:center;flex-wrap:wrap" }, [statusText, refreshBtn]));
        box.appendChild(statusRow);

        const pauseCb = el("input", { type: "checkbox", id: "gldForgePauseUw" });
        pauseCb.checked = lsGet(K.pauseUw, "false") === "true";
        pauseCb.addEventListener("change", () => lsSet(K.pauseUw, pauseCb.checked ? "true" : "false"));
        box.appendChild(row(L.pauseUw, pauseCb));

        const minGoldInp = el("input", { type: "number", min: "0", css: "width:90px" });
        minGoldInp.value = lsGet(K.minGold, "0");
        minGoldInp.addEventListener("change", () => lsSet(K.minGold, String(parseInt(minGoldInp.value, 10) || 0)));
        box.appendChild(row(L.minGold, minGoldInp));

        box.appendChild(header(L.recipe));
        const groupDrop = el("select", { css: "min-width:180px" });
        const basisDrop = el("select", { css: "min-width:220px" });
        const prefixDrop = el("select", { css: "min-width:220px" });
        const suffixDrop = el("select", { css: "min-width:220px" });
        const typeIcon = el("div", { class: "gld-forge-type-icon" });
        const basisIconWrap = el("div", { class: "gld-forge-sprite-slot" });
        const typeRow = el("div", { css: "display:flex;align-items:center;gap:8px;flex:1" }, [typeIcon, groupDrop]);
        const basisRow = el("div", { css: "display:flex;align-items:center;gap:8px;flex:1" }, [basisIconWrap, basisDrop]);
        box.appendChild(row(L.itemType, typeRow));
        box.appendChild(row(L.basis, basisRow));
        box.appendChild(row(L.prefix, prefixDrop));
        box.appendChild(row(L.suffix, suffixDrop));
        function refreshTypeIcons() {
            const g = Api.loadInfos().basics[parseInt(groupDrop.value, 10)];
            const sample = (g && g.items && g.items[0] && g.items[0].value) || basisDrop.value;
            typeIcon.className = "gld-forge-type-icon " + (TYPE_ICON[String(sample || "").split("-")[0]] || "");
            basisIconWrap.innerHTML = "";
            const sp = itemSprite(basisDrop.value);
            if (sp) basisIconWrap.appendChild(sp);
        }

        box.appendChild(header(L.qualities));
        const qWrap = el("div", { css: "display:flex;flex-wrap:wrap;gap:6px;padding:4px 0" });
        Q_DEFS.forEach(q => {
            const lbl = el("label", { css: "display:inline-flex;align-items:center;gap:4px;font-size:11px;cursor:pointer" });
            const cb = el("input", { type: "checkbox" });
            cb.checked = !!state.qFilter[q.idx];
            cb.addEventListener("change", () => {
                state.qFilter[q.idx] = cb.checked;
                lsSet(K.qFilter, state.qFilter);
                schedulePreview();
            });
            lbl.appendChild(cb);
            lbl.appendChild(el("span", { css: "width:10px;height:10px;border-radius:50%;background:" + q.color, text: "" }));
            lbl.appendChild(el("span", { text: L[q.key] }));
            qWrap.appendChild(lbl);
        });
        box.appendChild(el("div", { class: "setting-row" }, [qWrap]));

        box.appendChild(header(L.materials));
        const matPref = el("select");
        const matMin = el("select");
        Q_DEFS.forEach(q => {
            matPref.appendChild(el("option", { value: String(q.idx), text: L[q.key] }));
            matMin.appendChild(el("option", { value: String(q.idx), text: L[q.key] }));
        });
        matPref.value = String(state.mat.preferida);
        matMin.value = String(state.mat.minima);
        function saveMat() {
            state.mat.preferida = parseInt(matPref.value, 10);
            state.mat.minima = parseInt(matMin.value, 10);
            lsSet(K.matPrefs, state.mat);
            schedulePreview();
        }
        matPref.addEventListener("change", saveMat);
        matMin.addEventListener("change", saveMat);
        box.appendChild(row(L.prefQ, matPref));
        box.appendChild(row(L.minQ, matMin));

        box.appendChild(header(L.tools));
        [["anvil", L.anvil], ["bellows", L.bellows], ["clover", L.clover], ["hammer", L.hammer]].forEach(([key, lab]) => {
            if (!state.tools[key]) state.tools[key] = { use: false, quality: "golden" };
            const wrap = el("div", { css: "display:flex;align-items:center;gap:8px" });
            const cb = el("input", { type: "checkbox" });
            cb.checked = !!state.tools[key].use;
            const drop = el("select");
            [["bronze", L.bronze], ["silver", L.silver], ["golden", L.golden]].forEach(([v, tx]) => drop.appendChild(el("option", { value: v, text: tx })));
            drop.value = state.tools[key].quality || "golden";
            drop.disabled = !cb.checked;
            const toolSlot = el("div", { class: "gld-forge-sprite-slot" });
            const toolSpr = el("div", { class: "item-i-" + (TOOL_SPRITE[key][drop.value] || TOOL_SPRITE[key].golden) + " gld-forge-item-sprite" });
            toolSlot.appendChild(toolSpr);
            function syncToolSprite() {
                toolSpr.className = "item-i-" + (TOOL_SPRITE[key][drop.value] || TOOL_SPRITE[key].golden) + " gld-forge-item-sprite";
            }
            cb.addEventListener("change", () => {
                state.tools[key].use = cb.checked;
                drop.disabled = !cb.checked;
                lsSet(K.toolPrefs, state.tools);
                schedulePreview();
            });
            drop.addEventListener("change", () => {
                state.tools[key].quality = drop.value;
                lsSet(K.toolPrefs, state.tools);
                syncToolSprite();
                schedulePreview();
            });
            wrap.appendChild(cb);
            wrap.appendChild(toolSlot);
            wrap.appendChild(drop);
            box.appendChild(row(lab, wrap));
        });

        const details = el("div", { class: "gld-forge-details", text: L.noRecipe });
        box.appendChild(header(L.details));
        box.appendChild(el("div", { class: "setting-row" }, [details]));

        const countInp = el("input", { type: "number", min: "1", value: "1", css: "width:70px" });
        const destSel = el("select");
        destSel.appendChild(el("option", { value: "inventory", text: L.destInv }));
        destSel.appendChild(el("option", { value: "package", text: L.destPkg }));
        const slotWrap = el("div", { css: "display:flex;gap:6px;flex-wrap:wrap" });
        const slotCbs = [];
        for (let i = 0; i < 6; i++) {
            const lb = el("label", { css: "font-size:11px" });
            const cb = el("input", { type: "checkbox" });
            cb.checked = true;
            slotCbs.push(cb);
            lb.appendChild(cb);
            lb.appendChild(document.createTextNode(" " + (i + 1)));
            slotWrap.appendChild(lb);
        }
        box.appendChild(row(L.howMany, countInp));
        box.appendChild(row(L.dest, destSel));
        box.appendChild(row(L.slots, slotWrap));

        const forgeBtn = el("button", { class: "gld-btn", text: L.forgeNow });
        const saveBtn = el("button", { class: "gld-btn", text: L.saveRule });
        box.appendChild(el("div", { class: "setting-row", css: "gap:8px;flex-wrap:wrap" }, [forgeBtn, saveBtn]));

        box.appendChild(header(L.auto));
        box.appendChild(el("p", { class: "gld-forge-note", text: L.autoHelp }));
        const rulesPanel = el("div", { class: "gld-forge-rules" });
        box.appendChild(el("div", { class: "setting-row" }, [rulesPanel]));
        const addRuleBtn = el("button", { class: "gld-btn", text: L.addRule });
        const tickBtn = el("button", { class: "gld-btn", text: L.tickNow });
        box.appendChild(el("div", { class: "setting-row", css: "gap:8px" }, [addRuleBtn, tickBtn]));
        box.appendChild(el("p", { class: "gld-forge-note", text: L.tickHelp }));

        box.appendChild(header(L.prot));
        box.appendChild(el("p", { class: "gld-forge-note", text: L.protNote }));
        const protPanel = el("div", { class: "gld-forge-prot" });
        box.appendChild(el("div", { class: "setting-row" }, [protPanel]));

        box.appendChild(header(L.stock));
        const horreumRow = el("div", { class: "gld-forge-horreum", text: L.loading });
        box.appendChild(el("div", { class: "setting-row" }, [horreumRow]));

        const openA = el("a", { href: pageLink({ mod: "forge", submod: "forge" }), class: "gld-btn", text: L.openForge });
        openA.style.display = "inline-block";
        box.appendChild(el("div", { class: "setting-row" }, [openA]));

        function fillSelects(infos) {
            groupDrop.innerHTML = "";
            groupDrop.appendChild(el("option", { value: "", text: L.pickType }));
            (infos.basics || []).forEach((g, i) => groupDrop.appendChild(el("option", { value: String(i), text: g.group || ("#" + (i + 1)) })));
            function fillBasis() {
                basisDrop.innerHTML = "";
                basisDrop.appendChild(el("option", { value: "", text: L.pickItem }));
                const g = infos.basics[parseInt(groupDrop.value, 10)];
                (g && g.items || []).forEach(it => basisDrop.appendChild(el("option", { value: it.value, text: it.text })));
            }
            groupDrop.onchange = () => { fillBasis(); refreshTypeIcons(); schedulePreview(); };
            fillBasis();
            prefixDrop.innerHTML = "";
            (infos.prefixes || []).forEach(p => prefixDrop.appendChild(el("option", { value: String(p.value), text: p.text })));
            suffixDrop.innerHTML = "";
            (infos.suffixes || []).forEach(p => suffixDrop.appendChild(el("option", { value: String(p.value), text: p.text })));
            prefixDrop.onchange = schedulePreview;
            suffixDrop.onchange = schedulePreview;
            basisDrop.onchange = () => { refreshTypeIcons(); schedulePreview(); };
            refreshTypeIcons();
        }

        let prevTimer = 0;
        function schedulePreview() {
            clearTimeout(prevTimer);
            prevTimer = setTimeout(updatePreview, 250);
        }
        async function updatePreview() {
            const basis = basisDrop.value;
            if (!basis) { details.textContent = L.noRecipe; return; }
            details.textContent = L.loading;
            try {
                const p = await Api.getPreview(parseInt(prefixDrop.value, 10) || 0, basis, parseInt(suffixDrop.value, 10) || 0);
                state.lastPreview = p;
                if (!p) { details.textContent = L.noRecipe; return; }
                const tools = {};
                ["anvil", "bellows", "clover", "hammer"].forEach(k => { if (state.tools[k] && state.tools[k].use) tools[k] = state.tools[k].quality; });
                let pct = p.chance_of_success;
                let dur = p.duration || 0;
                if (tools.clover && TOOL_FX.clover[tools.clover] && typeof pct === "number") pct = Math.min(100, Math.round(pct * TOOL_FX.clover[tools.clover]));
                if (tools.hammer && TOOL_FX.hammer[tools.hammer]) dur = Math.max(1, Math.ceil(dur * TOOL_FX.hammer[tools.hammer]));
                const need = p.needed || {};
                let stock = null;
                try { stock = await Api.loadHorreum(); } catch (e) {}
                details.innerHTML = "";
                const head = el("div", { class: "gld-forge-preview-head" });
                const spr = itemSprite(basis, "lg");
                if (spr) head.appendChild(spr);
                const info = el("div");
                info.appendChild(el("b", { text: p.name || basis }));
                info.appendChild(el("div", { css: "font-size:12px;margin-top:4px", html:
                    L.chance + ": <b>" + (pct != null ? pct + "%" : "?") + "</b> · " +
                    L.duration + ": <b>" + fmtDur(dur) + "</b>"
                }));
                head.appendChild(info);
                details.appendChild(head);
                const matsBox = el("div", { class: "gld-forge-mats" });
                Object.keys(need).forEach(k => {
                    const n = need[k];
                    const amt = (n && typeof n === "object") ? n.amount : n;
                    const matId = parseInt(String(k).slice(2), 10);
                    const name = (n && n.name) || MAT_NAMES[matId] || k;
                    const have = (isFinite(matId) && stock && stock[matId])
                        ? stock[matId].reduce((a, b, i) => a + (state.qFilter[i] ? b : 0), 0)
                        : null;
                    const line = el("div", { class: "gld-forge-mat" });
                    if (isFinite(matId)) line.appendChild(matSprite(matId));
                    const label = el("span", { text: amt + "× " + name + (have == null ? "" : " (" + have + ")") });
                    if (have != null && have < amt) label.style.color = "#a83030";
                    line.appendChild(label);
                    matsBox.appendChild(line);
                });
                if (!matsBox.childNodes.length) matsBox.appendChild(el("span", { text: "—" }));
                details.appendChild(el("div", { css: "margin-top:6px;font-size:11px;opacity:.85", text: L.needed }));
                details.appendChild(matsBox);
            } catch (e) {
                details.textContent = t("failed", { msg: e.message || e });
            }
        }

        function recipeObj() {
            const slots = {};
            slotCbs.forEach((cb, i) => { if (cb.checked) slots[i] = 1; });
            const tools = {};
            ["anvil", "bellows", "clover", "hammer"].forEach(k => {
                tools[k] = state.tools[k] && state.tools[k].use ? state.tools[k].quality : null;
            });
            return {
                prefix: parseInt(prefixDrop.value, 10) || 0,
                basis: basisDrop.value,
                suffix: parseInt(suffixDrop.value, 10) || 0,
                materials: { preferida: state.mat.preferida, minima: state.mat.minima },
                tools,
                slots,
                count: parseInt(countInp.value, 10) || 1,
                sendItemTo: destSel.value === "package" ? "package" : "inventory",
                name: (state.lastPreview && state.lastPreview.name) || basisDrop.options[basisDrop.selectedIndex]?.text || t("ruleName")
            };
        }

        function slotOn(rule, i) {
            const s = rule.slots || {};
            return s[i] === 1 || s[i] === true || s[String(i)] === 1 || s[String(i)] === true;
        }
        function ruleBadge(rule) {
            const badge = el("span", { class: "gld-forge-badge" });
            if (rule.pendingUntil && rule.pendingUntil > Date.now()) {
                badge.className += " gld-forge-badge-wait";
                badge.textContent = L.statusPending;
                badge.title = Math.ceil((rule.pendingUntil - Date.now()) / 60000) + " min";
            } else if ((rule.successCount || 0) >= (rule.count || 0) && (rule.count || 0) > 0) {
                badge.className += " gld-forge-badge-done";
                badge.textContent = L.statusDone;
            } else if (rule.active) {
                if ((rule.forgingCount || 0) > 0) {
                    badge.className += " gld-forge-badge-forge";
                    badge.textContent = t("statusForging", { n: rule.forgingCount });
                } else {
                    badge.className += " gld-forge-badge-on";
                    badge.textContent = L.statusActive;
                }
            } else {
                badge.className += " gld-forge-badge-off";
                badge.textContent = L.statusInactive;
            }
            return badge;
        }
        function loadRuleIntoPlanner(r) {
            const infos = Api.loadInfos();
            const gi = (infos.basics || []).findIndex(g => (g.items || []).some(it => it.value === r.basis));
            if (gi >= 0) {
                groupDrop.value = String(gi);
                groupDrop.dispatchEvent(new Event("change"));
            }
            basisDrop.value = r.basis || "";
            prefixDrop.value = String(r.prefix || 0);
            suffixDrop.value = String(r.suffix || 0);
            countInp.value = String(r.count || 1);
            destSel.value = r.sendItemTo === "package" ? "package" : "inventory";
            if (r.materials) {
                matPref.value = String(r.materials.preferida);
                matMin.value = String(r.materials.minima);
            }
            slotCbs.forEach((cb, i) => { cb.checked = slotOn(r, i); });
            refreshTypeIcons();
            schedulePreview();
        }
        function buildRuleRecipe(rule) {
            const infos = Api.loadInfos();
            const wrap = el("div", { class: "gld-forge-rule-row" });
            wrap.appendChild(el("span", { class: "gld-forge-k", text: L.editRecipe }));
            const groupDropR = el("select", { css: "min-width:120px;font-size:11px" });
            const basisDropR = el("select", { css: "min-width:180px;font-size:11px" });
            let gi = 0;
            (infos.basics || []).forEach((g, i) => {
                groupDropR.appendChild(el("option", { value: String(i), text: g.group || ("#" + (i + 1)) }));
                if ((g.items || []).some(it => it.value === rule.basis)) gi = i;
            });
            groupDropR.value = String(gi);
            function fillBasisR() {
                basisDropR.innerHTML = "";
                const g = infos.basics && infos.basics[parseInt(groupDropR.value, 10)];
                (g && g.items || []).forEach(it => basisDropR.appendChild(el("option", { value: it.value, text: it.text })));
                if ((g && g.items || []).some(it => it.value === rule.basis)) basisDropR.value = rule.basis;
            }
            fillBasisR();
            groupDropR.addEventListener("change", () => {
                fillBasisR();
                if (basisDropR.value) {
                    updateRule(rule.id, x => { x.basis = basisDropR.value; });
                    renderRules();
                }
            });
            basisDropR.addEventListener("change", () => updateRule(rule.id, x => { x.basis = basisDropR.value; }));
            const prefixDropR = el("select", { css: "min-width:140px;font-size:11px" });
            prefixDropR.appendChild(el("option", { value: "0", text: L.noneOpt }));
            (infos.prefixes || []).forEach(p => {
                if (!p.value) return;
                prefixDropR.appendChild(el("option", { value: String(p.value), text: p.text }));
            });
            prefixDropR.value = String(rule.prefix || 0);
            prefixDropR.addEventListener("change", () => updateRule(rule.id, x => { x.prefix = parseInt(prefixDropR.value, 10) || 0; }));
            const suffixDropR = el("select", { css: "min-width:140px;font-size:11px" });
            suffixDropR.appendChild(el("option", { value: "0", text: L.noneOpt }));
            (infos.suffixes || []).forEach(p => {
                if (!p.value) return;
                suffixDropR.appendChild(el("option", { value: String(p.value), text: p.text }));
            });
            suffixDropR.value = String(rule.suffix || 0);
            suffixDropR.addEventListener("change", () => updateRule(rule.id, x => { x.suffix = parseInt(suffixDropR.value, 10) || 0; }));
            wrap.appendChild(groupDropR);
            wrap.appendChild(basisDropR);
            wrap.appendChild(prefixDropR);
            wrap.appendChild(suffixDropR);
            return wrap;
        }
        function buildRuleMats(rule) {
            const wrap = el("div", { class: "gld-forge-rule-row" });
            wrap.appendChild(el("span", { class: "gld-forge-k", text: L.materials }));
            const pref = el("select", { css: "min-width:110px;font-size:11px" });
            const min = el("select", { css: "min-width:110px;font-size:11px" });
            Q_DEFS.forEach(q => {
                pref.appendChild(el("option", { value: String(q.idx), text: L.prefShort + " " + L[q.key] }));
                min.appendChild(el("option", { value: String(q.idx), text: L.minShort + " " + L[q.key] }));
            });
            pref.value = String((rule.materials && rule.materials.preferida) || 0);
            min.value = String((rule.materials && rule.materials.minima) || 0);
            pref.addEventListener("change", () => updateRule(rule.id, x => {
                x.materials = x.materials || { preferida: 0, minima: 0 };
                x.materials.preferida = parseInt(pref.value, 10);
            }));
            min.addEventListener("change", () => updateRule(rule.id, x => {
                x.materials = x.materials || { preferida: 0, minima: 0 };
                x.materials.minima = parseInt(min.value, 10);
            }));
            wrap.appendChild(pref);
            wrap.appendChild(min);
            return wrap;
        }
        function buildRuleTools(rule) {
            const wrap = el("div", { class: "gld-forge-rule-row" });
            wrap.appendChild(el("span", { class: "gld-forge-k", text: L.tools }));
            [["anvil", L.anvil], ["bellows", L.bellows], ["clover", L.clover], ["hammer", L.hammer]].forEach(([key, lab]) => {
                const sel = el("select", { css: "min-width:110px;font-size:11px" });
                sel.appendChild(el("option", { value: "", text: lab + ": " + L.toolOff }));
                sel.appendChild(el("option", { value: "bronze", text: lab + ": " + L.bronze }));
                sel.appendChild(el("option", { value: "silver", text: lab + ": " + L.silver }));
                sel.appendChild(el("option", { value: "golden", text: lab + ": " + L.golden }));
                sel.value = (rule.tools && rule.tools[key]) || "";
                sel.addEventListener("change", () => updateRule(rule.id, x => {
                    x.tools = x.tools || {};
                    x.tools[key] = sel.value || null;
                }));
                wrap.appendChild(sel);
            });
            return wrap;
        }
        function buildRuleSlots(rule) {
            const wrap = el("div", { class: "gld-forge-rule-row" });
            wrap.appendChild(el("span", { class: "gld-forge-k", text: L.slots }));
            for (let i = 0; i < 6; i++) {
                const lb = el("label", { css: "font-size:11px;display:inline-flex;align-items:center;gap:3px" });
                const cb = el("input", { type: "checkbox" });
                cb.checked = slotOn(rule, i);
                cb.addEventListener("change", () => updateRule(rule.id, x => {
                    x.slots = x.slots || {};
                    x.slots[i] = cb.checked ? 1 : 0;
                }));
                lb.appendChild(cb);
                lb.appendChild(document.createTextNode(" " + (i + 1)));
                wrap.appendChild(lb);
            }
            return wrap;
        }
        function renderRules() {
            const rules = loadRules();
            rulesPanel.innerHTML = "";
            if (!rules.length) {
                rulesPanel.appendChild(el("div", { css: "font-size:12px;opacity:.8;padding:8px;text-align:center", text: L.noRules }));
                return;
            }
            rules.forEach(rule => {
                const card = el("div", { class: "gld-forge-rule-card" });
                const header = el("div", { class: "gld-forge-rule-h" });
                const on = el("input", { type: "checkbox" });
                on.checked = !!rule.active;
                on.addEventListener("change", () => {
                    updateRule(rule.id, x => {
                        x.active = on.checked;
                        if (x.active) { delete x.pendingUntil; delete x.stopReason; }
                    });
                    renderRules();
                });
                const spr = itemSprite(rule.basis);
                const name = el("span", { class: "gld-forge-rule-name", text: rule.name || L.ruleName });
                name.title = L.rename;
                name.addEventListener("click", () => {
                    const n = prompt(L.renamePrompt, rule.name || "");
                    if (n != null && n.trim()) {
                        updateRule(rule.id, x => { x.name = n.trim(); });
                        renderRules();
                    }
                });
                const countSpan = el("span", { class: "gld-forge-rule-count",
                    text: (rule.successCount || 0) + "/" + (rule.count || 0) + " · " + (rule.failCount || 0) + " " + L.fails
                });
                const collapse = el("span", { class: "gld-forge-rule-toggle", text: rule.collapsed ? "▶" : "▼" });
                collapse.addEventListener("click", () => {
                    updateRule(rule.id, x => { x.collapsed = !x.collapsed; });
                    renderRules();
                });
                const del = el("span", { class: "gld-forge-rule-del", text: "×", title: L.delete });
                del.addEventListener("click", () => {
                    if (!confirm(t("confirmDelete", { name: rule.name || L.ruleName }))) return;
                    saveRules(loadRules().filter(x => x.id !== rule.id));
                    renderRules();
                });
                header.appendChild(on);
                if (spr) header.appendChild(spr);
                header.appendChild(name);
                header.appendChild(ruleBadge(rule));
                header.appendChild(countSpan);
                header.appendChild(collapse);
                header.appendChild(del);
                card.appendChild(header);
                if (!rule.collapsed) {
                    const body = el("div", { class: "gld-forge-rule-b" });
                    body.appendChild(buildRuleRecipe(rule));
                    body.appendChild(buildRuleMats(rule));
                    body.appendChild(buildRuleTools(rule));
                    body.appendChild(buildRuleSlots(rule));
                    const countRow = el("div", { class: "gld-forge-rule-row" });
                    countRow.appendChild(el("span", { class: "gld-forge-k", text: L.howMany }));
                    const countIn = el("input", { type: "number", min: "1", css: "width:80px" });
                    countIn.value = String(rule.count || 1);
                    countIn.addEventListener("change", () => {
                        const n = Math.max(1, parseInt(countIn.value, 10) || 1);
                        updateRule(rule.id, x => { x.count = n; });
                        renderRules();
                    });
                    countRow.appendChild(countIn);
                    body.appendChild(countRow);
                    const destRow = el("div", { class: "gld-forge-rule-row" });
                    destRow.appendChild(el("span", { class: "gld-forge-k", text: L.dest }));
                    const destR = el("select", { css: "min-width:140px;font-size:11px" });
                    destR.appendChild(el("option", { value: "inventory", text: L.destInv }));
                    destR.appendChild(el("option", { value: "package", text: L.destPkg }));
                    destR.value = rule.sendItemTo === "package" ? "package" : "inventory";
                    destR.addEventListener("change", () => updateRule(rule.id, x => { x.sendItemTo = destR.value; }));
                    destRow.appendChild(destR);
                    body.appendChild(destRow);
                    const bagRow = el("div", { class: "gld-forge-rule-row" });
                    bagRow.appendChild(el("span", { class: "gld-forge-k", text: L.destBag }));
                    const bag = el("select", { css: "min-width:160px;font-size:11px" });
                    [[512, L.bagI], [513, L.bagII], [514, L.bagIII], [515, L.bagIV]].forEach(([v, tx]) => {
                        bag.appendChild(el("option", { value: String(v), text: tx }));
                    });
                    bag.value = String(rule.sendItemToBag || 512);
                    bag.addEventListener("change", () => updateRule(rule.id, x => { x.sendItemToBag = parseInt(bag.value, 10) || 512; }));
                    bagRow.appendChild(bag);
                    bagRow.appendChild(el("span", { css: "font-size:11px;opacity:.75;font-style:italic", text: L.bagNote }));
                    body.appendChild(bagRow);
                    const act = el("div", { class: "gld-forge-rule-row" });
                    const reset = el("button", { class: "gld-btn", text: L.resetCounters });
                    reset.addEventListener("click", () => {
                        updateRule(rule.id, x => {
                            x.successCount = 0;
                            x.failCount = 0;
                            x.forgingCount = 0;
                            delete x.pendingUntil;
                            delete x.stopReason;
                        });
                        renderRules();
                    });
                    const load = el("button", { class: "gld-btn", text: L.loadPlanner });
                    load.addEventListener("click", () => loadRuleIntoPlanner(rule));
                    act.appendChild(reset);
                    act.appendChild(load);
                    body.appendChild(act);
                    card.appendChild(body);
                }
                rulesPanel.appendChild(card);
            });
        }

        function renderProt() {
            const list = window.GldForgeProtect.list();
            protPanel.innerHTML = "";
            if (!list.length) {
                protPanel.appendChild(el("div", { css: "font-size:12px;opacity:.8", text: L.protEmpty }));
                return;
            }
            list.forEach(e => {
                const line = el("div", { class: "gld-forge-prot-item" });
                const when = new Date(e.at).toLocaleString();
                const spr = itemSprite(e.basis);
                if (spr) line.appendChild(spr);
                line.appendChild(el("span", { text: (e.name || L.Forge) + " · " + when }));
                const rm = el("button", { class: "gld-btn", text: L.protRemove });
                rm.addEventListener("click", () => { window.GldForgeProtect.remove(e); renderProt(); });
                line.appendChild(rm);
                protPanel.appendChild(line);
            });
            const clr = el("button", { class: "gld-btn", text: L.protClear });
            clr.addEventListener("click", () => { window.GldForgeProtect.clear(); renderProt(); });
            protPanel.appendChild(clr);
        }

        async function renderHorreum() {
            horreumRow.textContent = L.loading;
            try {
                const mats = await Api.loadHorreum();
                if (!mats) { horreumRow.textContent = "—"; return; }
                horreumRow.innerHTML = "";
                const wrap = el("div", { class: "gld-forge-horreum-grid" });
                let n = 0;
                Object.keys(mats).forEach(id => {
                    const arr = mats[id];
                    const sum = arr.reduce((a, b, i) => a + (state.qFilter[i] ? b : 0), 0);
                    if (sum <= 0) return;
                    n++;
                    const cell = el("div", { class: "gld-forge-mat", title: (MAT_NAMES[id] || ("#" + id)) + ": " + sum });
                    cell.appendChild(matSprite(id));
                    cell.appendChild(el("span", { text: String(sum) }));
                    wrap.appendChild(cell);
                });
                if (!n) horreumRow.textContent = "—";
                else horreumRow.appendChild(wrap);
            } catch (e) { horreumRow.textContent = "—"; }
        }

        refreshBtn.addEventListener("click", async () => {
            statusText.textContent = L.loading;
            try {
                const infos = await Api.refreshScrolls();
                fillSelects(infos);
                statusText.textContent = (infos.basics || []).length ? "OK" : L.noScrolls;
                renderHorreum();
            } catch (e) { statusText.textContent = t("failed", { msg: e.message || e }); }
        });
        saveBtn.addEventListener("click", () => {
            if (!basisDrop.value) { statusText.textContent = L.noRecipe; return; }
            const rules = loadRules();
            const rec = recipeObj();
            rec.id = "r" + Date.now();
            rec.active = true;
            rec.collapsed = false;
            rec.successCount = 0;
            rec.failCount = 0;
            rec.forgingCount = 0;
            rec.boundSlots = [];
            rec.sendItemToBag = rec.sendItemToBag || 512;
            rules.push(rec);
            saveRules(rules);
            renderRules();
            statusText.textContent = rec.name;
        });
        addRuleBtn.addEventListener("click", () => {
            const rules = loadRules();
            rules.push({
                id: "r" + Date.now(), name: L.ruleName + " " + (rules.length + 1), active: false,
                prefix: 0, basis: "", suffix: 0,
                materials: { preferida: 0, minima: 0 }, tools: {},
                slots: { 0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1 },
                count: 1, sendItemTo: "inventory", sendItemToBag: 512, collapsed: false,
                successCount: 0, failCount: 0, forgingCount: 0, boundSlots: []
            });
            saveRules(rules);
            renderRules();
        });
        tickBtn.addEventListener("click", async () => {
            if (!forgeOn()) { statusText.textContent = L.botOff; forgeLog(L.botOff); return; }
            tickBtn.disabled = true;
            statusText.textContent = L.loading;
            try {
                const result = await window.GldForgeRuntime.tickNow();
                statusText.textContent = (result && result.message) || L.tickOk;
                renderRules();
                renderProt();
            } catch (e) {
                statusText.textContent = t("failed", { msg: e.message || e });
                forgeLog(statusText.textContent);
            } finally { tickBtn.disabled = false; }
        });
        forgeBtn.addEventListener("click", async () => {
            if (!basisDrop.value) { statusText.textContent = L.noRecipe; return; }
            forgeBtn.disabled = true;
            statusText.textContent = L.loading;
            try {
                const slots = await Api.getSlots();
                if (!slots) throw new Error("slots");
                const allowed = {};
                slotCbs.forEach((cb, i) => { if (cb.checked) allowed[i] = 1; });
                const free = slots.find(s => (s.isClosed || s.isOpened) && allowed[s.index]);
                if (!free) { statusText.textContent = L.noSlot; return; }
                const rec = recipeObj();
                const result = await runForgeOnce(rec, free.index);
                if (!result.ok) {
                    if (result.missingMat) statusText.textContent = t("missing", { name: result.missingMat.name, have: result.missingMat.have, need: result.missingMat.need });
                    else statusText.textContent = t("failed", { msg: (result.error && result.error.message) || result.stage });
                    forgeLog(statusText.textContent);
                } else {
                    statusText.textContent = t("started", { n: result.slot + 1 });
                    forgeLog(t("logForgeStarted", { name: result.itemName || rec.name || rec.basis, n: result.slot + 1 }));
                    rec.id = "manual" + Date.now();
                    rec.boundSlots = [result.slot];
                    rec.active = false;
                    const rules = loadRules();
                    const live = rules.find(r => r.basis === rec.basis && r.prefix === rec.prefix && r.suffix === rec.suffix);
                    if (live) {
                        live.boundSlots = live.boundSlots || [];
                        if (live.boundSlots.indexOf(result.slot) < 0) live.boundSlots.push(result.slot);
                        saveRules(rules);
                    }
                }
            } catch (e) {
                statusText.textContent = t("failed", { msg: e.message || e });
            } finally { forgeBtn.disabled = false; }
        });

        const infos = Api.loadInfos();
        if ((infos.basics || []).length) {
            fillSelects(infos);
            statusText.textContent = "OK";
        } else statusText.textContent = L.noScrolls;
        renderRules();
        renderProt();
        renderHorreum();
        if (!box._gldRulesTimer) {
            box._gldRulesTimer = setInterval(() => {
                if (!document.body.contains(rulesPanel)) {
                    clearInterval(box._gldRulesTimer);
                    box._gldRulesTimer = 0;
                    return;
                }
                renderRules();
                renderProt();
            }, 10000);
        }
    }

    let tickStarted = false;
    function bindSwitch() {
        const cb = document.getElementById("activateForge");
        if (cb && !cb.dataset.gldForgeBound) {
            cb.dataset.gldForgeBound = "1";
            cb.checked = lsGet(K.enabled, "false") === "true";
            cb.addEventListener("change", () => lsSet(K.enabled, cb.checked ? "true" : "false"));
        }
    }
    function boot() {
        bindSwitch();
        const box = document.getElementById("auto_forge_settings");
        if (!box) return;
        if (!box.dataset.gldForgeUi) renderUI();
        if (!tickStarted) {
            tickStarted = true;
            setTimeout(tick, 10000);
            setInterval(tick, 60000);
        }
    }

    const mo = new MutationObserver(() => boot());
    mo.observe(document.documentElement, { childList: true, subtree: true });
    if (document.readyState === "complete") setTimeout(boot, 400);
    else window.addEventListener("load", () => setTimeout(boot, 400));
})();
