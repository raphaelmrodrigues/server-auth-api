/*
 * events-calendar.js — Calendário de eventos/microeventos do Gladiatus
 *
 * Fonte: a thread oficial "Microevents <ano>" da board de Notícias do fórum
 * (forum.gladiatus.gameforge.com). NÃO existe API/feed de eventos — só prosa no fórum
 * (ver memória reference-gladiatus-events-source). Buscamos via relay do SW
 * (fetchCrossDomain; host_permissions cobre *.gladiatus.gameforge.com), parseamos o
 * post (inglês) em {start,end,serverClass,bonuses[]}, cacheamos em localStorage (6h) e
 * desenhamos um calendário mensal + lista num modal aberto pela seção "Menus decimvs.io".
 *
 * Robusto ao ano: acha o link `thread/<id>-microevents-<ano>` na board de notícias
 * (pega o ano mais novo); fallback pra thread 13005 (2026). Dedupe por data+classe de
 * servidor mata as repetições de idioma (inglês vem primeiro na ordem do documento).
 */
(function () {
    'use strict';
    if (window.__GLD_NEWS_LOADED) return;
    window.__GLD_NEWS_LOADED = true;

    var BOARD_URL = 'https://forum.gladiatus.gameforge.com/forum/board/2-news-and-announcements/';
    var THREAD_FALLBACK = 'https://forum.gladiatus.gameforge.com/forum/thread/13005-microevents-2026/';
    var CACHE_KEY = 'gld_events_cal';
    var NEWS_CACHE_KEY = 'gld_forum_news';
    var SCHEMA = 1;
    var TTL_MS = 6 * 3600 * 1000;

    var MONTHS = {
        EN: ['January','February','March','April','May','June','July','August','September','October','November','December'],
        BR: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
        PL: ['Styczeń','Luty','Marzec','Kwiecień','Maj','Czerwiec','Lipiec','Sierpień','Wrzesień','Październik','Listopad','Grudzień'],
        ES: ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
        TR: ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'],
        FR: ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'],
        HG: ['Január','Február','Március','Április','Május','Június','Július','Augusztus','Szeptember','Október','November','December']
    };
    var MON_ABBR = {
        EN: ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'],
        BR: ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'],
        PL: ['sty','lut','mar','kwi','maj','cze','lip','sie','wrz','paź','lis','gru'],
        ES: ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'],
        TR: ['oca','şub','mar','nis','may','haz','tem','ağu','eyl','eki','kas','ara'],
        FR: ['jan','fév','mar','avr','mai','juin','juil','aoû','sep','oct','nov','déc'],
        HG: ['jan','feb','már','ápr','máj','jún','júl','aug','szep','okt','nov','dec']
    };
    var WD = {
        EN: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
        BR: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'],
        PL: ['Nd','Pn','Wt','Śr','Cz','Pt','So'],
        ES: ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'],
        TR: ['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'],
        FR: ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'],
        HG: ['V','H','K','Sze','Cs','P','Szo']
    };

    var I18N = {
        EN: { News:'News', evt_title:'News & Micro-events', evt_refresh:'↻ Update', evt_refreshing:'⏳ Updating…', evt_loading:'Fetching events from the forum…', evt_fail:'Could not read the forum. Try ↻ Update.', evt_none:'No events this month.', evt_active:'🟢 active now', evt_soon:'soon', evt_past:'ended', evt_new:'New servers', evt_old:'Old servers', evt_utc:'times in UTC', evt_threads:'Latest announcements', evt_open_forum:'Open forum', evt_events:'Events this month' },
        BR: { News:'Notícias', evt_title:'Notícias & Microeventos', evt_refresh:'↻ Atualizar', evt_refreshing:'⏳ Atualizando…', evt_loading:'Buscando eventos no fórum…', evt_fail:'Não consegui ler o fórum. Tente ↻ Atualizar.', evt_none:'Sem eventos neste mês.', evt_active:'🟢 ativo agora', evt_soon:'em breve', evt_past:'encerrado', evt_new:'Servidores novos', evt_old:'Servidores antigos', evt_utc:'horários em UTC', evt_threads:'Últimos anúncios', evt_open_forum:'Abrir fórum', evt_events:'Eventos deste mês' },
        PL: { News:'Aktualności', evt_title:'Aktualności i mikroeventy', evt_refresh:'↻ Odśwież', evt_refreshing:'⏳ Odświeżanie…', evt_loading:'Pobieranie wydarzeń z forum…', evt_fail:'Nie udało się odczytać forum. Spróbuj ↻ Odśwież.', evt_none:'Brak wydarzeń w tym miesiącu.', evt_active:'🟢 aktywne', evt_soon:'wkrótce', evt_past:'zakończone', evt_new:'Nowe serwery', evt_old:'Stare serwery', evt_utc:'czas UTC', evt_threads:'Ostatnie ogłoszenia', evt_open_forum:'Otwórz forum', evt_events:'Wydarzenia w tym miesiącu' },
        ES: { News:'Noticias', evt_title:'Noticias y microeventos', evt_refresh:'↻ Actualizar', evt_refreshing:'⏳ Actualizando…', evt_loading:'Buscando eventos en el foro…', evt_fail:'No pude leer el foro. Prueba ↻ Actualizar.', evt_none:'Sin eventos este mes.', evt_active:'🟢 activo ahora', evt_soon:'pronto', evt_past:'terminado', evt_new:'Servidores nuevos', evt_old:'Servidores antiguos', evt_utc:'horarios en UTC', evt_threads:'Últimos anuncios', evt_open_forum:'Abrir foro', evt_events:'Eventos de este mes' },
        TR: { News:'Haberler', evt_title:'Haberler ve mikro etkinlikler', evt_refresh:'↻ Güncelle', evt_refreshing:'⏳ Güncelleniyor…', evt_loading:'Forumdan etkinlikler alınıyor…', evt_fail:'Forum okunamadı. ↻ Güncelle dene.', evt_none:'Bu ay etkinlik yok.', evt_active:'🟢 şimdi aktif', evt_soon:'yakında', evt_past:'bitti', evt_new:'Yeni sunucular', evt_old:'Eski sunucular', evt_utc:'saatler UTC', evt_threads:'Son duyurular', evt_open_forum:'Forumu aç', evt_events:'Bu ayın etkinlikleri' },
        FR: { News:'Actualités', evt_title:'Actualités et micro-événements', evt_refresh:'↻ Mettre à jour', evt_refreshing:'⏳ Mise à jour…', evt_loading:'Récupération des événements du forum…', evt_fail:'Impossible de lire le forum. Essayez ↻ Mettre à jour.', evt_none:'Aucun événement ce mois-ci.', evt_active:'🟢 actif maintenant', evt_soon:'bientôt', evt_past:'terminé', evt_new:'Nouveaux serveurs', evt_old:'Anciens serveurs', evt_utc:'horaires en UTC', evt_threads:'Dernières annonces', evt_open_forum:'Ouvrir le forum', evt_events:'Événements du mois' },
        HG: { News:'Hírek', evt_title:'Hírek és mikroesemények', evt_refresh:'↻ Frissítés', evt_refreshing:'⏳ Frissítés…', evt_loading:'Események lekérése a fórumról…', evt_fail:'A fórumot nem sikerült olvasni. Próbáld ↻ Frissítés.', evt_none:'Nincs esemény ebben a hónapban.', evt_active:'🟢 most aktív', evt_soon:'hamarosan', evt_past:'véget ért', evt_new:'Új szerverek', evt_old:'Régi szerverek', evt_utc:'időpontok UTC', evt_threads:'Legutóbbi bejelentések', evt_open_forum:'Fórum megnyitása', evt_events:'E havi események' }
    };
    function langCode() {
        var v = String(localStorage.getItem('settings.language') || 'EN').toUpperCase();
        if (v === 'GB') v = 'EN';
        return I18N[v] ? v : 'EN';
    }
    function t(k, fb) {
        var pack = I18N[langCode()] || I18N.EN;
        return pack[k] || I18N.EN[k] || fb || k;
    }
    function months() { return MONTHS[langCode()] || MONTHS.EN; }
    function monAbbr() { return MON_ABBR[langCode()] || MON_ABBR.EN; }
    function weekDays() { return WD[langCode()] || WD.EN; }

    function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

    function relayFetch(url) {
        return new Promise(function (resolve) {
            try {
                if (!window.chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
                    return fetch(url).then(function (r) { return r.ok ? r.text() : null; }).then(resolve).catch(function () { resolve(null); });
                }
                chrome.runtime.sendMessage({ type: 'gldFetch', url: url }, function (resp) {
                    if (chrome.runtime.lastError) return resolve(null);
                    resolve(resp && resp.ok && resp.html ? resp.html : null);
                });
            } catch (_) { resolve(null); }
        });
    }

    function findThreadUrl(boardHtml) {
        if (!boardHtml) return THREAD_FALLBACK;
        var re = /thread\/(\d+)-microevents-(\d+)/gi, m, best = null;
        while ((m = re.exec(boardHtml))) {
            var year = parseInt(m[2], 10);
            if (!best || year > best.year) best = { year: year, url: 'https://forum.gladiatus.gameforge.com/forum/thread/' + m[1] + '-microevents-' + m[2] + '/' };
        }
        return best ? best.url : THREAD_FALLBACK;
    }

    function parseBoardThreads(html) {
        if (!html) return [];
        var out = [], seen = {};
        var re = /href="(?:https:\/\/forum\.gladiatus\.gameforge\.com)?\/forum\/thread\/(\d+)-([^"'/?#]+)\/"[^>]*>([^<]{3,160})</gi;
        var m;
        while ((m = re.exec(html))) {
            var id = m[1], slug = m[2], title = decodeEntities(m[3]).replace(/\s+/g, ' ').trim();
            if (!title || seen[id]) continue;
            if (/^page-\d+$/i.test(title) || /^(next|previous|próxim|poprzed|siguiente)/i.test(title)) continue;
            seen[id] = 1;
            out.push({
                id: id,
                title: title,
                url: 'https://forum.gladiatus.gameforge.com/forum/thread/' + id + '-' + slug + '/'
            });
            if (out.length >= 18) break;
        }
        return out;
    }

    function fetchAll() {
        return relayFetch(BOARD_URL).then(function (boardHtml) {
            var threads = parseBoardThreads(boardHtml);
            var url = findThreadUrl(boardHtml);
            return relayFetch(url).then(function (threadHtml) {
                return { events: threadHtml ? parseEvents(threadHtml) : null, threads: threads, threadUrl: url };
            });
        });
    }

    // ===================== parser =====================
    var START_RE = /^(\d{1,2}):(\d{2}):(\d{2})\s+(\d{2})\.(\d{2})\.(\d{4})$/;
    var END_RE = /^-\s*(\d{1,2}):(\d{2}):(\d{2})\s+(\d{2})\.(\d{2})\.(\d{4})$/;
    var COMBO_RE = /^(\d{1,2}):(\d{2}):(\d{2})\s+(\d{2})\.(\d{2})\.(\d{4})\s*-\s*(\d{1,2}):(\d{2}):(\d{2})\s+(\d{2})\.(\d{2})\.(\d{4})$/;
    var SVR_RE = /(ALL SERVERS|NEW SERVERS ONLY|OLD SERVERS ONLY)/i;
    var TERM_RE = /(Ave Gladiator|Your Gladiatus Team|Have fun|The gods look|The Roman people)/i;

    function decodeEntities(s) { var ta = document.createElement('textarea'); ta.innerHTML = s; return ta.value; }
    function blockLines(block) {
        block = block.replace(/<br\s*\/?>/gi, '\n')
            .replace(/<\/(p|li|div|h[1-6]|tr|td|blockquote)>/gi, '\n')
            .replace(/<li[^>]*>/gi, '\n• ')
            .replace(/<[^>]+>/g, '');
        return decodeEntities(block).split('\n').map(function (s) { return s.replace(/ /g, ' ').trim(); }).filter(Boolean);
    }
    function utc(hh, mm, ss, DD, MM, YY) { return Date.UTC(+YY, +MM - 1, +DD, +hh, +mm, +ss); }

    function parseBlock(block, out) {
        var lines = blockLines(block);
        var serverClass = 'ALL';
        for (var i = 0; i < lines.length; i++) {
            var ln = lines[i];
            var sv = ln.match(SVR_RE);
            if (sv && ln.length < 42) { serverClass = /new/i.test(sv[1]) ? 'NEW' : /old/i.test(sv[1]) ? 'OLD' : 'ALL'; continue; }
            if (TERM_RE.test(ln)) { serverClass = 'ALL'; continue; }
            var startTs, endTs, bonusFrom;
            var cm = ln.match(COMBO_RE);
            if (cm) {
                startTs = utc(cm[1], cm[2], cm[3], cm[4], cm[5], cm[6]);
                endTs = utc(cm[7], cm[8], cm[9], cm[10], cm[11], cm[12]);
                bonusFrom = i + 1;
            } else {
                var s = ln.match(START_RE);
                if (!s) continue;
                var e = (i + 1 < lines.length) ? lines[i + 1].match(END_RE) : null;
                if (!e) continue;
                startTs = utc(s[1], s[2], s[3], s[4], s[5], s[6]);
                endTs = utc(e[1], e[2], e[3], e[4], e[5], e[6]);
                bonusFrom = i + 2;
            }
            var bonuses = [], j = bonusFrom;
            for (; j < lines.length; j++) {
                var b = lines[j];
                if (COMBO_RE.test(b) || START_RE.test(b) || TERM_RE.test(b) || (SVR_RE.test(b) && b.length < 42)) break;
                var clean = b.replace(/^[\s•·▪◦●【】•·*]+/, '').trim();
                if (clean) bonuses.push(clean);
            }
            if (bonuses.length && endTs >= startTs && endTs - startTs < 40 * 86400000) {
                out.push({ start: startTs, end: endTs, serverClass: serverClass, bonuses: bonuses });
            }
            i = j - 1;
        }
    }

    function parseEvents(html) {
        var idxs = [], re = /class="messageText"/g, m;
        while ((m = re.exec(html))) idxs.push(m.index);
        if (!idxs.length) idxs = [0];
        var raw = [];
        idxs.forEach(function (start, k) {
            var end = (k + 1 < idxs.length) ? idxs[k + 1] : Math.min(html.length, start + 80000);
            parseBlock(html.slice(start, end), raw);
        });
        var seen = {}, out = [];
        raw.forEach(function (e) {
            var key = e.start + '|' + e.end + '|' + e.serverClass;
            if (seen[key]) return; seen[key] = 1; out.push(e);
        });
        out.sort(function (a, b) { return a.start - b.start; });
        return out;
    }

    // ===================== bônus: ícone + tradução PT =====================
    function bonusIcon(text) {
        var s = text.toLowerCase();
        if (/forging success|forge success/.test(s)) return '🔨';
        if (/forg|smelt|fundi|forja/.test(s)) return '⏱️';
        if (/expediti|expedi/.test(s)) return '🗺️';
        if (/dungeon|masmorra|calabou/.test(s)) return '🏰';
        if (/arena|provinciarum|circus|circo/.test(s)) return '⚔️';
        if (/gold|ouro/.test(s)) return '💰';
        if (/finding an item|item|drop|achar/.test(s)) return '🎁';
        if (/resource|scroll|recurso|pergaminho/.test(s)) return '📜';
        if (/ruby|rubies|rubi/.test(s)) return '💎';
        if (/training|treino/.test(s)) return '🏋️';
        if (/durability|durabilidade/.test(s)) return '🛡️';
        if (/pantheon|quest|grace|honou?r|experience|\bxp\b|panteão|missã|graça|honra/.test(s)) return '✨';
        if (/cooldown|recarga|espera/.test(s)) return '⏳';
        return '•';
    }
    // Tradução PT dos padrões recorrentes (fallback = texto original do fórum, em inglês).
    function toPt(text) {
        var reps = [
            [/(-?\d+%?)\s*forging success/i, '$1 de sucesso na forja'],
            [/-?(\d+%)\s*forge duration/i, '-$1 de tempo de forja'],
            [/-?(\d+%)\s*Forging time \(and smelting\)/i, '-$1 de tempo de forja (e fundição)'],
            [/(\d+%)\s*forge-?helper drop chance/i, '$1 de chance de dropar ferramenta de forja'],
            [/No durability loss/i, 'Sem perda de durabilidade'],
            [/(\d+%)\s*gold loot on expeditions?\s*&?\s*(and)?\s*dungeons?\.?/i, '$1 de ouro em expedições e masmorras'],
            [/(\d+%)\s*gold loot on expeditions?\.?/i, '$1 de ouro em expedições'],
            [/(\d+%)\s*chance of finding an item/i, '$1 de chance de achar um item'],
            [/(\d+%)\s*chance of a resource\s*\/?\s*scroll/i, '$1 de chance de recurso/pergaminho'],
            [/-?(\d+%)\s*ruby costs for auction house/i, '-$1 no custo de rubi do leilão'],
            [/-?(\d+%)\s*ruby costs? (for|at) (the )?malefica/i, '-$1 no custo de rubi na Maléfica'],
            [/-?(\d+%)\s*training costs?/i, '-$1 no custo de treino'],
            [/(\d+%)\s*more expedition points/i, '+$1 de pontos de expedição'],
            [/(\d+%)\s*expedition points/i, '$1 de pontos de expedição'],
            [/(\d+%)\s*dungeon points/i, '$1 de pontos de masmorra'],
            [/(\d+%)\s*expedition xp/i, '$1 de XP de expedição'],
            [/(\d+%)\s*dungeon xp/i, '$1 de XP de masmorra'],
            [/(\d+%)\s*arena xp/i, '$1 de XP de arena'],
            [/-?(\d+%)\s*cooldown for quests/i, '-$1 de recarga das missões'],
            [/(\d+%)\s*Pantheon quest gold, experience, grace, honou?r/i, '$1 de ouro/XP/graça/honra nas missões do Panteão'],
            [/ruby on expedition/i, 'rubi em expedição']
        ];
        for (var i = 0; i < reps.length; i++) if (reps[i][0].test(text)) return text.replace(reps[i][0], reps[i][1]);
        return text;
    }
    function bonusLabel(text) { return langCode() === 'BR' ? toPt(text) : text; }

    function loadNewsCache() {
        try { var c = JSON.parse(localStorage.getItem(NEWS_CACHE_KEY) || 'null'); if (c && c.v === SCHEMA && Array.isArray(c.threads) && (Date.now() - c.at) < TTL_MS) return c.threads; } catch (_) {}
        return null;
    }
    function saveNewsCache(threads) { try { localStorage.setItem(NEWS_CACHE_KEY, JSON.stringify({ v: SCHEMA, at: Date.now(), threads: threads })); } catch (_) {} }

    // ===================== cache =====================
    function loadCache() {
        try { var c = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null'); if (c && c.v === SCHEMA && c.at && (Date.now() - c.at) < TTL_MS && Array.isArray(c.events)) return c.events; } catch (_) {}
        return null;
    }
    function loadStale() { try { var c = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null'); if (c && c.v === SCHEMA && Array.isArray(c.events)) return c.events; } catch (_) {} return null; }
    function saveCache(events) { try { localStorage.setItem(CACHE_KEY, JSON.stringify({ v: SCHEMA, at: Date.now(), events: events })); } catch (_) {} }

    // ===================== modal =====================
    var _events = null, _threads = [], _vy, _vm, _root = null, _busy = false;

    function fmtRange(a, b) {
        var da = new Date(a), db = new Date(b);
        var d1 = da.getUTCDate(), m1 = da.getUTCMonth(), d2 = db.getUTCDate(), m2 = db.getUTCMonth();
        var abbr = monAbbr();
        if (m1 === m2 && da.getUTCFullYear() === db.getUTCFullYear())
            return (d1 === d2 ? d1 : d1 + '–' + d2) + ' ' + abbr[m1];
        return d1 + ' ' + abbr[m1] + ' – ' + d2 + ' ' + abbr[m2];
    }

    function calendarHtml() {
        var y = _vy, mo = _vm;
        var startWd = new Date(Date.UTC(y, mo, 1)).getUTCDay();
        var daysIn = new Date(Date.UTC(y, mo + 1, 0)).getUTCDate();
        var now = Date.now(), td = new Date();
        var isThis = td.getUTCFullYear() === y && td.getUTCMonth() === mo, todayD = td.getUTCDate();
        var h = '<div class="evt-cal-head"><button class="evt-nav" data-nav="-1">◀</button>'
            + '<span class="evt-cal-title">' + months()[mo] + ' ' + y + '</span>'
            + '<button class="evt-nav" data-nav="1">▶</button></div><div class="evt-cal-grid">';
        weekDays().forEach(function (w) { h += '<div class="evt-wd">' + w + '</div>'; });
        for (var b = 0; b < startWd; b++) h += '<div class="evt-cell evt-empty"></div>';
        for (var d = 1; d <= daysIn; d++) {
            var s0 = Date.UTC(y, mo, d, 0, 0, 0), s1 = Date.UTC(y, mo, d, 23, 59, 59);
            var cov = (_events || []).filter(function (e) { return e.start <= s1 && e.end >= s0; });
            var cls = 'evt-cell';
            if (cov.length) cls += ' evt-has';
            if (cov.some(function (e) { return e.start <= now && now <= e.end; })) cls += ' evt-active';
            if (isThis && d === todayD) cls += ' evt-today';
            h += '<div class="' + cls + '" data-day="' + d + '">' + d + (cov.length ? '<span class="evt-dot"></span>' : '') + '</div>';
        }
        return h + '</div>';
    }

    function listHtml() {
        var y = _vy, mo = _vm;
        var mStart = Date.UTC(y, mo, 1, 0, 0, 0), mEnd = Date.UTC(y, mo + 1, 0, 23, 59, 59);
        var list = (_events || []).filter(function (e) { return e.start <= mEnd && e.end >= mStart; });
        if (!list.length) return '<div class="evt-empty-msg">' + esc(t('evt_none', 'Sem eventos neste mês.')) + '</div>';
        var now = Date.now();
        return list.map(function (e) {
            var active = e.start <= now && now <= e.end, soon = e.start > now;
            var badge = active ? '<span class="evt-b evt-b-active">' + esc(t('evt_active', '🟢 ativo agora')) + '</span>'
                : soon ? '<span class="evt-b evt-b-soon">' + esc(t('evt_soon', 'em breve')) + '</span>'
                    : '<span class="evt-b evt-b-past">' + esc(t('evt_past', 'encerrado')) + '</span>';
            var sc = e.serverClass !== 'ALL'
                ? '<span class="evt-b evt-sc-' + e.serverClass.toLowerCase() + '">' + esc(e.serverClass === 'NEW' ? t('evt_new', 'Servidores novos') : t('evt_old', 'Servidores antigos')) + '</span>' : '';
            var bonuses = e.bonuses.map(function (b) {
                return '<div class="evt-bonus"><span class="evt-bi">' + bonusIcon(b) + '</span><span>' + esc(bonusLabel(b)) + '</span></div>';
            }).join('');
            return '<div class="evt-item' + (active ? ' active' : (soon ? '' : ' past')) + '" id="evt-d' + e.start + '">'
                + '<div class="evt-item-h"><span class="evt-range">' + esc(fmtRange(e.start, e.end)) + '</span>' + badge + sc + '</div>'
                + bonuses + '</div>';
        }).join('');
    }

    function threadsHtml() {
        var list = _threads || [];
        if (!list.length) return '';
        var items = list.map(function (th) {
            return '<a class="evt-thread" href="' + esc(th.url) + '" target="_blank" rel="noopener">' + esc(th.title) + '</a>';
        }).join('');
        return '<div class="evt-threads"><div class="evt-threads-h"><span>' + esc(t('evt_threads', 'Últimos anúncios')) + '</span>'
            + '<a class="evt-forum-link" href="' + BOARD_URL + '" target="_blank" rel="noopener">' + esc(t('evt_open_forum', 'Abrir fórum')) + '</a></div>'
            + '<div class="evt-threads-list">' + items + '</div></div>';
    }

    function renderBody() {
        if (!_root) return;
        var body = _root.querySelector('.evt-body');
        if (!body) return;
        if (_events === null && !(_threads && _threads.length)) {
            body.innerHTML = '<div class="evt-loading">' + esc(t('evt_loading', 'Buscando eventos no fórum…')) + '</div>';
            return;
        }
        var eventsPart = (!_events || !_events.length)
            ? '<div class="evt-loading">' + esc(t('evt_fail', 'Não consegui ler o fórum. Tente ↻ Atualizar.')) + '</div>'
            : '<div class="evt-cal">' + calendarHtml() + '<div class="evt-utc">' + esc(t('evt_utc', 'horários em UTC')) + '</div></div>'
                + '<div class="evt-list">' + listHtml() + '</div>';
        body.innerHTML = threadsHtml() + '<div class="evt-events-wrap">' + eventsPart + '</div>';
        Array.prototype.forEach.call(body.querySelectorAll('.evt-nav'), function (b) {
            b.addEventListener('click', function () {
                _vm += parseInt(b.getAttribute('data-nav'), 10);
                if (_vm < 0) { _vm = 11; _vy--; } else if (_vm > 11) { _vm = 0; _vy++; }
                renderBody();
            });
        });
        Array.prototype.forEach.call(body.querySelectorAll('.evt-cell.evt-has'), function (c) {
            c.addEventListener('click', function () {
                var d = parseInt(c.getAttribute('data-day'), 10);
                var s0 = Date.UTC(_vy, _vm, d, 0, 0, 0), s1 = Date.UTC(_vy, _vm, d, 23, 59, 59);
                var hit = (_events || []).filter(function (e) { return e.start <= s1 && e.end >= s0; })[0];
                if (!hit) return;
                var el = body.querySelector('#evt-d' + hit.start);
                if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('flash'); setTimeout(function () { el.classList.remove('flash'); }, 1400); }
            });
        });
    }

    function setBusy(b) {
        _busy = b;
        var btn = _root && _root.querySelector('.evt-refresh');
        if (btn) { btn.disabled = b; btn.textContent = b ? t('evt_refreshing', '⏳ Atualizando…') : t('evt_refresh', '↻ Atualizar'); }
    }
    function refresh() {
        if (_busy) return;
        setBusy(true);
        fetchAll().then(function (res) {
            setBusy(false);
            if (res && res.events && res.events.length) { _events = res.events; saveCache(res.events); }
            else if (_events === null) { _events = loadStale() || []; }
            if (res && res.threads && res.threads.length) { _threads = res.threads; saveNewsCache(res.threads); }
            renderBody();
        }).catch(function () { setBusy(false); if (_events === null) _events = loadStale() || []; renderBody(); });
    }

    function shellHtml() {
        return '<div class="evt-dialog">'
            + '<div class="evt-header"><h2>' + esc(t('evt_title', 'Notícias & Microeventos')) + '</h2>'
            + '<div class="evt-header-r"><button type="button" class="evt-refresh">' + esc(t('evt_refresh', '↻ Atualizar')) + '</button></div></div>'
            + '<div class="evt-body"></div></div>';
    }

    function mountTab() {
        var box = document.getElementById('news_settings');
        if (!box || box.dataset.gldNewsUi) return;
        injectStyles();
        box.dataset.gldNewsUi = '1';
        box.innerHTML = shellHtml();
        _root = box;
        var now = new Date(); _vy = now.getUTCFullYear(); _vm = now.getUTCMonth();
        var btn = box.querySelector('.evt-refresh');
        if (btn) btn.addEventListener('click', refresh);
        var cached = loadCache();
        _threads = loadNewsCache() || [];
        if (cached && cached.length) { _events = cached; renderBody(); }
        else { _events = null; renderBody(); }
        refresh();
    }

    // ===================== estilos =====================
    function injectStyles() {
        var css = ''
            + '.evt-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:var(--z-overlay,99999);display:flex;align-items:center;justify-content:center;}'
            + '.evt-dialog{background:#f5e9c8;border:3px solid #5a3e1a;border-radius:8px;width:96%;max-width:860px;height:90vh;display:flex;flex-direction:column;font-family:Tahoma,Verdana,sans-serif;color:#3a2410;box-shadow:0 8px 32px rgba(0,0,0,.7);}'
            + '.evt-header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#5a3e1a;border-radius:5px 5px 0 0;}'
            + '.evt-header h2{margin:0;font-size:16px;color:#f5e9c8;}'
            + '.evt-header-r{display:flex;gap:8px;align-items:center;}'
            + '.evt-refresh{background:#8a5a24;border:1px solid #b3843f;color:#f5e9c8;border-radius:4px;font-size:12px;font-weight:bold;padding:4px 10px;cursor:pointer;}'
            + '.evt-refresh:hover{filter:brightness(1.12);} .evt-refresh:disabled{opacity:.6;cursor:default;}'
            + '.evt-close{background:transparent;border:none;color:#f5e9c8;font-size:18px;cursor:pointer;line-height:1;padding:0 4px;}'
            + '.evt-body{flex:1;overflow-y:auto;padding:12px 14px;display:flex;flex-direction:column;gap:12px;}'
            + '.evt-loading,.evt-empty-msg{padding:24px;text-align:center;color:#8a6a3a;font-style:italic;font-size:13px;}'
            + '.evt-cal{background:#fff8e7;border:1px solid #d9c69b;border-radius:5px;padding:8px;}'
            + '.evt-cal-head{display:flex;align-items:center;justify-content:center;gap:14px;margin-bottom:6px;}'
            + '.evt-cal-title{font-weight:bold;color:#5a3e1a;font-size:14px;min-width:150px;text-align:center;}'
            + '.evt-nav{background:#ede0bc;border:1px solid #c9a66b;border-radius:4px;cursor:pointer;font-size:12px;color:#5a3e1a;padding:2px 9px;}'
            + '.evt-nav:hover{background:#e0d4ad;}'
            + '.evt-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;}'
            + '.evt-wd{text-align:center;font-size:10px;font-weight:bold;color:#8a6a3a;padding:2px 0;text-transform:uppercase;}'
            + '.evt-cell{position:relative;aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;font-size:12px;color:#3a2410;border-radius:4px;background:#faf2de;border:1px solid transparent;}'
            + '.evt-cell.evt-empty{background:transparent;}'
            + '.evt-cell.evt-has{background:#f0e2bb;cursor:pointer;font-weight:bold;}'
            + '.evt-cell.evt-has:hover{background:#e6d29a;}'
            + '.evt-cell.evt-active{background:#cfe6c9;color:#1f5c22;}'
            + '.evt-cell.evt-today{border-color:#a83030;box-shadow:inset 0 0 0 1px #a83030;}'
            + '.evt-dot{position:absolute;bottom:3px;left:50%;transform:translateX(-50%);width:5px;height:5px;border-radius:50%;background:#c2621a;}'
            + '.evt-cell.evt-active .evt-dot{background:#2a7d32;}'
            + '.evt-utc{font-size:9px;color:#8a6a3a;font-style:italic;text-align:right;margin-top:4px;}'
            + '.evt-list{display:flex;flex-direction:column;gap:8px;}'
            + '.evt-item{background:#fff8e7;border:1px solid #d9c69b;border-left:4px solid #c9a66b;border-radius:5px;padding:8px 10px;}'
            + '.evt-item.active{border-left-color:#2a7d32;background:#f3faef;}'
            + '.evt-item.past{opacity:.6;}'
            + '.evt-item.flash{animation:evtflash 1.4s ease;}'
            + '@keyframes evtflash{0%,100%{background:#fff8e7;}30%{background:#fff0c0;}}'
            + '.evt-item-h{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:5px;}'
            + '.evt-range{font-weight:bold;color:#5a3e1a;font-size:13px;}'
            + '.evt-b{font-size:10px;font-weight:bold;border-radius:8px;padding:1px 7px;}'
            + '.evt-b-active{background:rgba(46,125,50,.16);color:#2a7d32;}'
            + '.evt-b-soon{background:rgba(180,134,42,.16);color:#9a6a2a;}'
            + '.evt-b-past{background:rgba(0,0,0,.06);color:#8a6a3a;}'
            + '.evt-sc-new{background:rgba(42,106,176,.16);color:#2a6ab0;}'
            + '.evt-sc-old{background:rgba(138,58,176,.16);color:#8a3ab0;}'
            + '.evt-bonus{display:flex;align-items:flex-start;gap:7px;font-size:12px;color:#3a2410;padding:2px 0;}'
            + '.evt-bi{flex:0 0 auto;width:18px;text-align:center;}'
            + '.evt-threads{flex:0 0 auto;min-height:170px;max-height:240px;display:flex;flex-direction:column;background:#fff8e7;border:1px solid #d9c69b;border-radius:5px;padding:8px 6px 8px 10px;overflow:hidden;}'
            + '.evt-threads-h{font-weight:bold;color:#5a3e1a;font-size:12px;margin:0 4px 6px 0;display:flex;justify-content:space-between;gap:8px;align-items:center;flex:0 0 auto;}'
            + '.evt-threads-list{flex:1 1 auto;min-height:0;overflow-y:auto;padding-right:6px;scrollbar-width:thin;scrollbar-color:#8a5a24 #e7ddba;}'
            + '.evt-threads-list::-webkit-scrollbar{width:8px;}'
            + '.evt-threads-list::-webkit-scrollbar-track{background:#e7ddba;border-radius:6px;}'
            + '.evt-threads-list::-webkit-scrollbar-thumb{background:#8a5a24;border:2px solid #e7ddba;border-radius:6px;}'
            + '.evt-threads-list::-webkit-scrollbar-thumb:hover{background:#6e4a1f;}'
            + '.evt-thread{display:block;font-size:12px;color:#3a2410;text-decoration:none;padding:5px 0;border-bottom:1px solid rgba(201,166,107,.3);}'
            + '.evt-thread:hover{color:#8a5a24;}'
            + '.evt-forum-link{font-weight:normal;font-size:11px;color:#8a5a24;}'
            + '.evt-events-wrap{display:flex;flex-direction:column;gap:12px;}'
            + '#news_settings.popup-box{padding:0!important;}'
            + '#news_settings .evt-dialog{width:100%;max-width:none;height:100%;min-height:460px;border:none;box-shadow:none;border-radius:8px;}'
            + '@media(min-width:560px){.evt-events-wrap{flex-direction:row;align-items:flex-start;} .evt-cal{flex:0 0 280px;position:sticky;top:0;} .evt-list{flex:1;}}';
        var st = document.getElementById('insanos-evt-styles');
        if (!st) { st = document.createElement('style'); st.id = 'insanos-evt-styles'; document.head.appendChild(st); }
        st.textContent = css;
    }

    function boot() { mountTab(); }
    var mo = new MutationObserver(function () { boot(); });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    if (document.readyState === 'complete') setTimeout(boot, 400);
    else window.addEventListener('load', function () { setTimeout(boot, 400); });
    window.GldEventsNews = { mount: mountTab, refresh: refresh };
})();
