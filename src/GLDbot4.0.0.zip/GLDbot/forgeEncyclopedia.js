/*
 * forge-encyclopedia.js
 * Enciclopédia de Fundição — entrada no menu "Menus decimvs.io" + modal navegável.
 *
 * Fonte: snapshot bundlado do fansite (window.InsanosForgeEncRaw de forge-enc-data.js,
 * gerado por tools/gen-forge-enc-data.mjs). O botão "Atualizar" re-fetcha os JSONs do
 * fansite via relay do SW (fetchCrossDomain) e substitui o snapshot (cache localStorage).
 *
 * Telas:
 *   - LISTA: Prefixos / Sufixos, busca por nome, FILTRO por material, badge SUBMUNDO,
 *     botão Atualizar. Linha clicável → afixo. Ícone de material clicável → material.
 *   - AFIXO: nome + badge + nível + materiais (clicáveis → material).
 *   - MATERIAL: nome + ícone + descrição + escassez + "Dropa de" (mob/%/local) +
 *     "Prefixos/Sufixos com o material" (grid, clicável → afixo). Igual à página do site.
 */
(function () {
    'use strict';
    if (window.__GLD_ENC_LOADED) return;
    window.__GLD_ENC_LOADED = true;

    var I18N = {
        EN: {
            enc_menu: 'Encyclopedia', enc_title: 'Smelting Encyclopedia',
            enc_search: 'Search prefix or suffix…', enc_prefixes: 'Prefixes', enc_suffixes: 'Suffixes',
            enc_empty: 'Nothing found.', enc_note: 'Quantities are reference values — the exact amount varies per item.',
            enc_unknown_mat: 'Material {n}', enc_filter_all: 'All materials', enc_filter_stat_all: 'All stats', enc_filter: 'Filter by material:', enc_dd_search: 'Filter…',
            enc_update: '↻ Update', enc_updating: '⏳ Updating…', enc_updated: '✓ Updated', enc_update_fail: '⚠ Failed',
            enc_uw: 'Underworld', enc_uw_title: 'Underworld affix', enc_back: '← Back', enc_level: 'Level {n}',
            enc_scarcity: 'Scarcity', enc_drops: 'Drops from', enc_no_drops: 'No known drops (bought/crafted).',
            enc_pre_with: 'Prefixes with {m}', enc_suf_with: 'Suffixes with {m}', enc_mats: 'Materials',
            enc_proj: 'Quality projection (Ceres × multiplier)', enc_expand: 'Open larger view'
        },
        BR: {
            enc_menu: 'Enciclopédia', enc_title: 'Enciclopédia de Fundição',
            enc_search: 'Buscar prefixo ou sufixo…', enc_prefixes: 'Prefixos', enc_suffixes: 'Sufixos',
            enc_empty: 'Nada encontrado.', enc_note: 'Quantidades são de referência — o valor exato varia por item (prefixo + sufixo + base).',
            enc_unknown_mat: 'Material {n}', enc_filter_all: 'Todos os materiais', enc_filter_stat_all: 'Todos os stats', enc_filter: 'Filtrar por material:', enc_dd_search: 'Filtrar…',
            enc_update: '↻ Atualizar', enc_updating: '⏳ Atualizando…', enc_updated: '✓ Atualizado', enc_update_fail: '⚠ Falhou',
            enc_uw: 'Submundo', enc_uw_title: 'Afixo do Submundo', enc_back: '← Voltar', enc_level: 'Nível {n}',
            enc_scarcity: 'Escassez', enc_drops: 'Dropa de', enc_no_drops: 'Sem drops conhecidos (comprado/craftado).',
            enc_pre_with: 'Prefixos com {m}', enc_suf_with: 'Sufixos com {m}', enc_mats: 'Materiais',
            enc_proj: 'Projeção por qualidade (Ceres × multiplicador)', enc_expand: 'Abrir em tela cheia'
        },
        PL: {
            enc_menu: 'Encyklopedia', enc_title: 'Encyklopedia Przetapiania',
            enc_search: 'Szukaj przedrostka lub przyrostka…', enc_prefixes: 'Przedrostki', enc_suffixes: 'Przyrostki',
            enc_empty: 'Nic nie znaleziono.', enc_note: 'Ilości są orientacyjne — dokładna wartość zależy od przedmiotu.',
            enc_unknown_mat: 'Materiał {n}', enc_filter_all: 'Wszystkie materiały', enc_filter_stat_all: 'Wszystkie statystyki', enc_filter: 'Filtruj wg materiału:', enc_dd_search: 'Filtruj…',
            enc_update: '↻ Aktualizuj', enc_updating: '⏳ Aktualizacja…', enc_updated: '✓ Zaktualizowano', enc_update_fail: '⚠ Błąd',
            enc_uw: 'Podziemia', enc_uw_title: 'Afiks Podziemi', enc_back: '← Wstecz', enc_level: 'Poziom {n}',
            enc_scarcity: 'Rzadkość', enc_drops: 'Wypada z', enc_no_drops: 'Brak znanych dropów.',
            enc_pre_with: 'Przedrostki z {m}', enc_suf_with: 'Przyrostki z {m}', enc_mats: 'Materiały',
            enc_proj: 'Projekcja wg jakości (Ceres × mnożnik)', enc_expand: 'Otwórz większy widok'
        },
        ES: {
            enc_menu: 'Enciclopedia', enc_title: 'Enciclopedia de Fundición',
            enc_search: 'Buscar prefijo o sufijo…', enc_prefixes: 'Prefijos', enc_suffixes: 'Sufijos',
            enc_empty: 'Nada encontrado.', enc_note: 'Las cantidades son de referencia — el valor exacto varía por ítem.',
            enc_unknown_mat: 'Material {n}', enc_filter_all: 'Todos los materiales', enc_filter_stat_all: 'Todos los stats', enc_filter: 'Filtrar por material:', enc_dd_search: 'Filtrar…',
            enc_update: '↻ Actualizar', enc_updating: '⏳ Actualizando…', enc_updated: '✓ Actualizado', enc_update_fail: '⚠ Falló',
            enc_uw: 'Inframundo', enc_uw_title: 'Afijo del Inframundo', enc_back: '← Volver', enc_level: 'Nivel {n}',
            enc_scarcity: 'Escasez', enc_drops: 'Cae de', enc_no_drops: 'Sin drops conocidos (comprado/crafteado).',
            enc_pre_with: 'Prefijos con {m}', enc_suf_with: 'Sufijos con {m}', enc_mats: 'Materiales',
            enc_proj: 'Proyección por calidad (Ceres × multiplicador)', enc_expand: 'Abrir vista grande'
        },
        TR: {
            enc_menu: 'Ansiklopedi', enc_title: 'Eritme Ansiklopedisi',
            enc_search: 'Önek veya sonek ara…', enc_prefixes: 'Önekler', enc_suffixes: 'Sonekler',
            enc_empty: 'Sonuç yok.', enc_note: 'Miktarlar referanstır — tam değer eşyaya göre değişir.',
            enc_unknown_mat: 'Malzeme {n}', enc_filter_all: 'Tüm malzemeler', enc_filter_stat_all: 'Tüm statlar', enc_filter: 'Malzemeye göre filtre:', enc_dd_search: 'Filtrele…',
            enc_update: '↻ Güncelle', enc_updating: '⏳ Güncelleniyor…', enc_updated: '✓ Güncellendi', enc_update_fail: '⚠ Başarısız',
            enc_uw: 'Yeraltı', enc_uw_title: 'Yeraltı eki', enc_back: '← Geri', enc_level: 'Seviye {n}',
            enc_scarcity: 'Nadirlik', enc_drops: 'Düşüren', enc_no_drops: 'Bilinen drop yok.',
            enc_pre_with: '{m} içeren önekler', enc_suf_with: '{m} içeren sonekler', enc_mats: 'Malzemeler',
            enc_proj: 'Kalite projeksiyonu (Ceres × çarpan)', enc_expand: 'Büyük görünüm'
        },
        FR: {
            enc_menu: 'Encyclopédie', enc_title: 'Encyclopédie de Fonte',
            enc_search: 'Chercher préfixe ou suffixe…', enc_prefixes: 'Préfixes', enc_suffixes: 'Suffixes',
            enc_empty: 'Rien trouvé.', enc_note: 'Les quantités sont indicatives — la valeur exacte varie selon l’objet.',
            enc_unknown_mat: 'Matériau {n}', enc_filter_all: 'Tous les matériaux', enc_filter_stat_all: 'Tous les stats', enc_filter: 'Filtrer par matériau :', enc_dd_search: 'Filtrer…',
            enc_update: '↻ Mettre à jour', enc_updating: '⏳ Mise à jour…', enc_updated: '✓ Mis à jour', enc_update_fail: '⚠ Échec',
            enc_uw: 'Enfers', enc_uw_title: 'Affixe des Enfers', enc_back: '← Retour', enc_level: 'Niveau {n}',
            enc_scarcity: 'Rareté', enc_drops: 'Drop de', enc_no_drops: 'Aucun drop connu.',
            enc_pre_with: 'Préfixes avec {m}', enc_suf_with: 'Suffixes avec {m}', enc_mats: 'Matériaux',
            enc_proj: 'Projection par qualité (Cérès × multiplicateur)', enc_expand: 'Ouvrir en grand'
        },
        HG: {
            enc_menu: 'Enciklopédia', enc_title: 'Olvasztás enciklopédia',
            enc_search: 'Előtag vagy utótag keresése…', enc_prefixes: 'Előtagok', enc_suffixes: 'Utótagok',
            enc_empty: 'Nincs találat.', enc_note: 'A mennyiségek tájékoztató jellegűek.',
            enc_unknown_mat: 'Anyag {n}', enc_filter_all: 'Minden anyag', enc_filter_stat_all: 'Minden stat', enc_filter: 'Szűrés anyag szerint:', enc_dd_search: 'Szűrés…',
            enc_update: '↻ Frissítés', enc_updating: '⏳ Frissítés…', enc_updated: '✓ Frissítve', enc_update_fail: '⚠ Hiba',
            enc_uw: 'Alvilág', enc_uw_title: 'Alvilági toldalék', enc_back: '← Vissza', enc_level: '{n}. szint',
            enc_scarcity: 'Ritkaság', enc_drops: 'Erről esik', enc_no_drops: 'Nincs ismert drop.',
            enc_pre_with: 'Előtagok {m} anyaggal', enc_suf_with: 'Utótagok {m} anyaggal', enc_mats: 'Anyagok',
            enc_proj: 'Minőségi vetítés (Ceres × szorzó)', enc_expand: 'Nagy nézet'
        }
    };
    function langCode() {
        var v = String(localStorage.getItem('settings.language') || 'EN').toUpperCase();
        if (v === 'GB') v = 'EN';
        return I18N[v] ? v : 'EN';
    }
    function t(k, fb, vars) {
        var pack = I18N[langCode()] || I18N.EN;
        var s = pack[k] || I18N.EN[k] || fb || k;
        if (vars) for (var p in vars) s = s.split('{' + p + '}').join(vars[p]);
        return s;
    }
    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }
    function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ`']/g, ''); }

    // ===================== dados / modelo =====================
    var RAW_CACHE_KEY = 'gld_forge_enc_raw';
    var SCHEMA = 2;            // bump quando o shape do raw muda (2 = com `stats`). Cache de
                              // schema != atual é IGNORADO → cai no bundle (evita cache velho
                              // sem stats sobrescrever o snapshot novo).
    var MAT_ALIAS = { 'Hydra Scales': 'Hydra Scale' };
    var _rawOverride = null;   // vindo do Atualizar (localStorage)
    var _model = null;         // memoizado
    try { var c = JSON.parse(localStorage.getItem(RAW_CACHE_KEY) || 'null'); if (c && c.v === SCHEMA && c.raw) _rawOverride = c.raw; } catch (_) {}

    function getRaw() { return _rawOverride || window.InsanosForgeEncRaw || window.GldForgeEncRaw || null; }

    function buildModel() {
        if (_model) return _model;
        var raw = getRaw();
        if (!raw || !raw.goods) return null;
        var byName = {}, byId = {};
        raw.goods.forEach(function (g) {
            var idx = g.sprite ? parseInt(String(g.sprite).split('-')[1], 10) : g.id;
            var m = { id: g.id, sprite: idx, name: g.name, type: g.type || '', description: g.description || '',
                      scarcity: g.scarcity || '', drops: g.drops || [] };
            byName[norm(g.name)] = m; byId[g.id] = m;
        });
        function matOf(name) { var n = MAT_ALIAS[name] || name; return byName[norm(n)]; }
        function mapAffix(a, kind) {
            var mats = [];
            for (var mn in (a.materials || {})) {
                var m = matOf(mn); if (!m) continue;
                mats.push({ matId: m.id, sprite: m.sprite, name: m.name, qty: a.materials[mn] });
            }
            mats.sort(function (x, y) { return y.qty - x.qty; });
            return { id: a.id, kind: kind, name: a.name, level: a.level || 0, underworld: !!a.underworld, mats: mats, stats: a.stats || {} };
        }
        var byNm = function (a, b) { return a.name.localeCompare(b.name); };
        var P = (raw.prefixes || []).map(function (a) { return mapAffix(a, 'p'); }).filter(function (a) { return a.mats.length; }).sort(byNm);
        var S = (raw.suffixes || []).map(function (a) { return mapAffix(a, 's'); }).filter(function (a) { return a.mats.length; }).sort(byNm);
        var matToPre = {}, matToSuf = {}, usedIds = {};
        P.forEach(function (a) { a.mats.forEach(function (m) { (matToPre[m.matId] = matToPre[m.matId] || []).push({ a: a, qty: m.qty }); usedIds[m.matId] = 1; }); });
        S.forEach(function (a) { a.mats.forEach(function (m) { (matToSuf[m.matId] = matToSuf[m.matId] || []).push({ a: a, qty: m.qty }); usedIds[m.matId] = 1; }); });
        var usedMats = Object.keys(usedIds).map(function (id) { return byId[id]; }).filter(Boolean).sort(byNm);
        _model = { prefixes: P, suffixes: S, byId: byId, matToPre: matToPre, matToSuf: matToSuf, usedMats: usedMats };
        return _model;
    }

    // ===================== relay (Atualizar) =====================
    function relayFetch(url) {
        return new Promise(function (resolve) {
            try {
                if (!window.chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
                    return fetch(url).then(function (r) { return r.ok ? r.text() : null; }).then(resolve).catch(function () { resolve(null); });
                }
                chrome.runtime.sendMessage({ type: 'gldFetch', url: url }, function (resp) {
                    if (chrome.runtime.lastError) return resolve(null);
                    resolve(resp && resp.ok && resp.html ? resp.html : null);
                });
            } catch (_) { resolve(null); }
        });
    }
    function trimRaw(goods, prefixes, suffixes) {
        var clean = function (s) { return String(s || '').replace(/`+$/, '').replace(/`/g, "'").trim(); };
        var og = goods.map(function (g) {
            return { id: g.id, name: g.name, sprite: g.spriteId || ('18-' + g.id), type: g.type || '',
                     description: g.description || '', scarcity: g.scarcity || '',
                     drops: (g.drops || []).map(function (d) { return { mob: d.mob, pct: d.percentage, loc: d.location }; }) };
        });
        var ta = function (a) { return { id: a.id, name: clean(a.name), level: a.level || 0, underworld: !!a.underworld, materials: a.materials || {}, stats: a.stats || {} }; };
        var f = function (a) { return a.materials && Object.keys(a.materials).length; };
        return { goods: og, prefixes: prefixes.filter(f).map(ta), suffixes: suffixes.filter(f).map(ta) };
    }
    function fetchFreshRaw() {
        var base = 'https://raw.githubusercontent.com/Djongov/gladiatus-fansite/main/static/data/items/';
        return Promise.all(['forging-goods.json', 'prefixes.json', 'suffixes.json'].map(function (f) { return relayFetch(base + f); }))
            .then(function (arr) {
                if (arr.some(function (x) { return !x; })) return null;
                try { return trimRaw(JSON.parse(arr[0]), JSON.parse(arr[1]), JSON.parse(arr[2])); } catch (_) { return null; }
            });
    }

    // ===================== estilos =====================
    function injectStyles() {
        if (document.getElementById('insanos-enc-styles')) return;
        var css = ''
            + '.insanos-enc-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:var(--z-overlay,99999);display:flex;align-items:center;justify-content:center;}'
            + '.insanos-enc-dialog{background:#f5e9c8;border:3px solid #5a3e1a;border-radius:8px;width:96%;max-width:1000px;height:90vh;display:flex;flex-direction:column;font-family:Tahoma,Verdana,sans-serif;color:#3a2410;box-shadow:0 8px 32px rgba(0,0,0,.7);}'
            + '.insanos-enc-header{padding:10px 14px;background:#6e4a1f;color:#f5e9c8;display:flex;align-items:center;gap:10px;border-radius:5px 5px 0 0;}'
            + '.insanos-enc-header h2{margin:0;font-size:16px;font-weight:bold;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}'
            + '.insanos-enc-hbtn{cursor:pointer;background:#8a5a24;border:1px solid #b3843f;color:#f5e9c8;border-radius:4px;font-size:12px;font-weight:bold;padding:4px 10px;}'
            + '.insanos-enc-hbtn:hover{filter:brightness(1.12);} .insanos-enc-hbtn:disabled{opacity:.6;cursor:default;}'
            + '.insanos-enc-header .close{cursor:pointer;font-size:22px;line-height:1;background:transparent;border:none;color:#f5e9c8;padding:0 4px;}'
            + '.insanos-enc-content{flex:1;display:flex;flex-direction:column;min-height:0;}'
            + '.insanos-enc-toolbar{padding:8px 12px;background:#ede0bc;border-bottom:1px solid #c9a66b;display:flex;flex-direction:column;gap:6px;}'
            + '.insanos-enc-toolrow{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}'
            + '.insanos-enc-toolbar input,.insanos-enc-toolbar select{padding:5px 8px;border:1px solid #b39060;border-radius:3px;font-size:13px;background:#fff8e7;color:#3a2410;}'
            + '.insanos-enc-search{flex:1;min-width:180px;}'
            + '.insanos-enc-filter{max-width:220px;}'
            + '.insanos-enc-note{font-size:10px;color:#8a6a3a;font-style:italic;}'
            + '.insanos-enc-body{flex:1;display:flex;min-height:0;gap:1px;background:#c9a66b;}'
            + '.insanos-enc-col{flex:1;display:flex;flex-direction:column;background:#faf2de;min-width:0;}'
            + '.insanos-enc-col-head{padding:6px 12px;background:#ede0bc;border-bottom:1px solid #c9a66b;font-size:12px;font-weight:bold;color:#5a3e1a;text-transform:uppercase;letter-spacing:.4px;}'
            + '.insanos-enc-list{flex:1;overflow-y:auto;padding:4px 0;}'
            + '.insanos-enc-row{display:flex;align-items:center;gap:8px;padding:4px 12px;border-bottom:1px solid rgba(201,166,107,.35);cursor:pointer;}'
            + '.insanos-enc-row:hover{background:#fff5da;}'
            + '.insanos-enc-name{flex:0 0 36%;font-size:12px;font-weight:bold;color:#3a2410;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;align-items:center;gap:5px;}'
            + '.insanos-enc-uw{display:inline-block;font-size:9px;font-weight:bold;color:#fff;background:#8a1f12;border:1px solid #c0392b;border-radius:3px;padding:0 4px;line-height:14px;text-transform:uppercase;letter-spacing:.3px;}'
            + '.insanos-enc-mats{flex:1;display:flex;flex-wrap:wrap;align-items:center;gap:2px;}'
            + '.insanos-enc-mat{display:inline-flex;align-items:center;position:relative;cursor:pointer;}'
            + '.insanos-enc-mat:hover{filter:brightness(1.15);}'
            + '.insanos-enc-mat > .item-i-18{display:inline-block;width:32px;height:32px;transform:scale(.62);transform-origin:left center;margin:-6px -8px -6px 0;}'
            + '.insanos-enc-qty{font-size:10px;color:#6e4a1f;font-weight:bold;}'
            + '.insanos-enc-empty{padding:16px;text-align:center;color:#8a6a3a;font-size:12px;}'
            // Detalhe (afixo/material)
            + '.insanos-enc-detail{flex:1;overflow-y:auto;padding:14px 18px;}'
            + '.insanos-enc-back{cursor:pointer;background:#8a5a24;border:1px solid #b3843f;color:#f5e9c8;border-radius:4px;font-size:12px;font-weight:bold;padding:4px 10px;}'
            + '.insanos-enc-back:hover{filter:brightness(1.12);}'
            + '.insanos-enc-dtitle{display:flex;align-items:center;gap:10px;margin:0 0 4px;}'
            + '.insanos-enc-dtitle .big-icon > .item-i-18{display:inline-block;width:32px;height:32px;transform:scale(1.6);transform-origin:center;margin:8px 12px 8px 8px;filter:drop-shadow(0 1px 2px rgba(0,0,0,.4));}'
            + '.insanos-enc-dtitle h3{margin:0;font-size:20px;color:#5a3e1a;}'
            + '.insanos-enc-dmeta{font-size:12px;color:#6e4a1f;margin:2px 0 12px;}'
            + '.insanos-enc-dmeta .sc{font-weight:bold;}'
            + '.insanos-enc-sec-title{font-size:13px;font-weight:bold;color:#5a3e1a;text-transform:uppercase;letter-spacing:.4px;border-bottom:1px solid #c9a66b;padding-bottom:3px;margin:14px 0 8px;}'
            + '.insanos-enc-drop{display:flex;align-items:center;gap:6px;padding:5px 8px;margin:3px 0;background:#fff8e7;border:1px solid #e0cfa0;border-radius:4px;font-size:12px;}'
            + '.insanos-enc-pct{font-weight:bold;min-width:38px;}'
            + '.insanos-enc-mob{font-weight:bold;color:#8a4a1a;} .insanos-enc-loc{color:#5a3e1a;font-style:italic;}'
            + '.insanos-enc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:6px;}'
            + '.insanos-enc-card{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:6px 10px;background:#fff8e7;border:1px solid #d8c290;border-radius:4px;font-size:12px;font-weight:bold;color:#3a2410;cursor:pointer;}'
            + '.insanos-enc-card:hover{background:#fff5da;border-color:#b3843f;}'
            + '.insanos-enc-card .q{font-size:11px;color:#fff;background:#4a7a2a;border-radius:3px;padding:0 6px;line-height:16px;}'
            + '.insanos-enc-affmats{display:flex;flex-wrap:wrap;gap:10px;}'
            + '.insanos-enc-affmat{display:inline-flex;flex-direction:column;align-items:center;gap:2px;cursor:pointer;padding:6px;border:1px solid #d8c290;border-radius:5px;background:#fff8e7;min-width:70px;}'
            + '.insanos-enc-affmat:hover{background:#fff5da;border-color:#b3843f;}'
            + '.insanos-enc-affmat > .icn > .item-i-18{display:inline-block;width:32px;height:32px;transform:scale(1.05);transform-origin:center;}'
            + '.insanos-enc-affmat .nm{font-size:10px;color:#5a3e1a;text-align:center;} .insanos-enc-affmat .q{font-size:11px;font-weight:bold;color:#4a7a2a;}'
            // Dropdown pesquisável de material (botão + painel-portal no body)
            + '.insanos-enc-dd{position:relative;display:inline-block;}'
            + '.insanos-enc-dd-btn{display:flex;align-items:center;gap:6px;min-width:190px;max-width:250px;padding:4px 8px;border:1px solid #b39060;border-radius:3px;background:#fff8e7;color:#3a2410;font-size:13px;cursor:pointer;}'
            + '.insanos-enc-dd-btn:hover{border-color:#8a5a24;}'
            + '.insanos-enc-dd-ic{display:inline-flex;width:18px;height:18px;overflow:hidden;flex:0 0 auto;}'
            + '.insanos-enc-dd-ic > .item-i-18{width:32px;height:32px;transform:scale(.56);transform-origin:left top;margin:-6px 0 0 -1px;}'
            + '.insanos-enc-dd-txt{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}'
            + '.insanos-enc-dd-caret{color:#8a6a3a;font-size:10px;}'
            + '.insanos-enc-dd-panel{position:fixed;display:none;flex-direction:column;z-index:var(--z-popover,100001);background:#fff8e7;border:1px solid #8a5a24;border-radius:4px;box-shadow:0 6px 20px rgba(0,0,0,.45);max-height:340px;overflow:hidden;}'
            + '.insanos-enc-dd-search{margin:6px;padding:5px 8px;border:1px solid #b39060;border-radius:3px;font-size:12px;background:#fffdf5;color:#3a2410;}'
            + '.insanos-enc-dd-list{overflow-y:auto;padding:2px 0;}'
            + '.insanos-enc-dd-item{display:flex;align-items:center;gap:6px;padding:4px 10px;font-size:12px;color:#3a2410;cursor:pointer;white-space:nowrap;}'
            + '.insanos-enc-dd-item:hover{background:#fff0cc;} .insanos-enc-dd-item.sel{background:#ffe6a8;font-weight:bold;}'
            + '.insanos-enc-dd-item > .item-i-18{width:32px;height:32px;transform:scale(.56);transform-origin:left center;margin:-6px -8px -6px 0;flex:0 0 auto;}'
            // Tabela de projeção por qualidade
            + '.insanos-enc-proj-wrap{overflow-x:auto;margin-top:4px;}'
            + '.insanos-enc-proj{border-collapse:collapse;font-size:12px;}'
            + '.insanos-enc-proj th,.insanos-enc-proj td{padding:4px 12px;border:1px solid #e0cfa0;text-align:right;white-space:nowrap;}'
            + '.insanos-enc-proj th:first-child,.insanos-enc-proj td:first-child{text-align:left;color:#3a2410;font-weight:normal;}'
            + '.insanos-enc-proj thead th{background:#ede0bc;font-weight:bold;}'
            + '.insanos-enc-proj tbody tr:nth-child(even){background:#fff8e7;}'
            + '.insanos-enc-proj td.val{font-weight:bold;}'
            + '#encyclopedia_settings.popup-box{padding:0!important;}'
            + '#encyclopedia_settings .insanos-enc-dialog{width:100%;max-width:none;height:100%;min-height:460px;border:none;border-radius:8px;box-shadow:none;}'
            + '.insanos-enc-overlay .insanos-enc-dialog{z-index:100000;}';
        var st = document.createElement('style'); st.id = 'insanos-enc-styles'; st.textContent = css;
        document.head.appendChild(st);
    }

    function scarcityColor(s) {
        var k = String(s || '').toLowerCase();
        if (k.indexOf('common') > -1) return '#4a7a2a';
        if (k.indexOf('medium') > -1) return '#b8860b';
        if (k.indexOf('rare') > -1 || k.indexOf('very') > -1) return '#8a1f12';
        return '#5a3e1a';
    }
    function pctColor(p) { p = +p || 0; return p >= 60 ? '#2e7d32' : p >= 30 ? '#b8860b' : '#8a4a1a'; }
    function matIcon(sprite) { return '<span class="item-i-18 item-i-18-' + sprite + '"></span>'; }

    // ===================== projeção por qualidade =====================
    // Multiplicadores = os do nosso Planejador (equipment-planner.js:122-126), que batem
    // com a projeção do fansite: Ceres(base)×1.0, Neptune×1.3, Mars×1.5, Jupiter×1.75,
    // Olympus×2.0. Valor = floor(base × mul). O `stats` do fansite é a base Ceres.
    var QUALITIES = [
        { name: 'Ceres', color: '#5a8a3a', mul: 1.00 },
        { name: 'Neptune', color: '#2a6ab0', mul: 1.30 },
        { name: 'Mars', color: '#8a3ab0', mul: 1.50 },
        { name: 'Jupiter', color: '#d08030', mul: 1.75 },
        { name: 'Olympus', color: '#a83030', mul: 2.00 }
    ];
    // Ordem canônica (STAT_ORDER do fansite + health, que ele omite). Nomes = tooltips do jogo.
    var STAT_ORDER = ['damage', 'armour', 'health', 'strength', 'dexterity', 'agility', 'constitution',
        'charisma', 'intelligence', 'healing', 'critical_hit', 'double_hit', 'avoid_critical_hit',
        'avoid_double_hit', 'block_chance', 'critical_healing_value', 'critical_attack_value',
        'block_value', 'blocking_value', 'hardening_value', 'threat'];
    var STAT_I18N = {
        EN: { damage: 'Damage', armour: 'Armour', health: 'Health', strength: 'Strength', dexterity: 'Dexterity', agility: 'Agility', constitution: 'Constitution', charisma: 'Charisma', intelligence: 'Intelligence', healing: 'Healing', critical_hit: 'Critical hit', double_hit: 'Double hit', avoid_critical_hit: 'Avoid critical', avoid_double_hit: 'Avoid double hit', block_chance: 'Block chance', critical_healing_value: 'Critical healing', critical_attack_value: 'Critical attack', block_value: 'Block value', blocking_value: 'Blocking', hardening_value: 'Hardening', threat: 'Threat' },
        BR: { damage: 'Dano', armour: 'Armadura', health: 'Saúde', strength: 'Força', dexterity: 'Destreza', agility: 'Agilidade', constitution: 'Constituição', charisma: 'Carisma', intelligence: 'Inteligência', healing: 'Cura', critical_hit: 'Golpe crítico', double_hit: 'Golpe duplo', avoid_critical_hit: 'Evitar crítico', avoid_double_hit: 'Evitar golpe duplo', block_chance: 'Chance de bloqueio', critical_healing_value: 'Valor de cura crítica', critical_attack_value: 'Valor de dano crítico', block_value: 'Valor de bloqueio', blocking_value: 'Bloqueio', hardening_value: 'Valor de endurecimento', threat: 'Ameaça' }
    };
    function statLabel(key) {
        var pack = STAT_I18N[langCode()] || STAT_I18N.EN;
        return pack[key] || STAT_I18N.EN[key] || key.replace(/_/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); });
    }
    function fmtVal(v, pct) { return (v >= 0 ? '+' : '') + v + (pct ? '%' : ''); }
    // Uma linha por componente flat/percent não-zero, cada uma projetada nas 5 qualidades.
    function projRows(stats) {
        var rows = [], keys = STAT_ORDER.slice();
        for (var k in stats) if (keys.indexOf(k) < 0) keys.push(k);
        keys.forEach(function (key) {
            var s = stats[key]; if (!s) return;
            [['flat', false], ['percent', true]].forEach(function (pair) {
                var base = s[pair[0]]; if (!base) return;
                rows.push({ label: statLabel(key), pct: pair[1], cells: QUALITIES.map(function (q) { return Math.floor(base * q.mul); }) });
            });
        });
        return rows;
    }

    // Dropdown pesquisável com sprites — mesmo padrão do createMaterialDropdown do
    // smeltery-rebuild.js (botão + lista PORTAL no body pra escapar do overflow do modal,
    // outside-click, reposiciona no scroll/resize), MAIS um input de busca no topo.
    // items: [{id, name, sprite|null}] (id '' = "todos", sprite null). onChange(item).
    function createMatDropdown(items, currentValue, onChange) {
        var wrap = document.createElement('div'); wrap.className = 'insanos-enc-dd';
        var btn = document.createElement('div'); btn.className = 'insanos-enc-dd-btn'; btn.setAttribute('role', 'button'); btn.tabIndex = 0;
        var selIc = document.createElement('span'); selIc.className = 'insanos-enc-dd-ic';
        var selTx = document.createElement('span'); selTx.className = 'insanos-enc-dd-txt';
        var caret = document.createElement('span'); caret.className = 'insanos-enc-dd-caret'; caret.textContent = '▾';
        btn.appendChild(selIc); btn.appendChild(selTx); btn.appendChild(caret); wrap.appendChild(btn);

        var panel = document.createElement('div'); panel.className = 'insanos-enc-dd-panel';
        var search = document.createElement('input'); search.type = 'search'; search.className = 'insanos-enc-dd-search';
        search.placeholder = t('enc_dd_search', 'Filtrar…');
        var listEl = document.createElement('div'); listEl.className = 'insanos-enc-dd-list';
        panel.appendChild(search); panel.appendChild(listEl);

        var curVal = currentValue == null ? '' : String(currentValue), isOpen = false;
        function iconHtml(it) { return it.sprite != null ? matIcon(it.sprite) : ''; }
        function applySel() {
            var it = items.filter(function (x) { return String(x.id) === curVal; })[0] || items[0];
            selIc.innerHTML = iconHtml(it); selTx.textContent = it ? it.name : '';
        }
        function drawList(q) {
            q = norm(q || ''); listEl.innerHTML = '';
            items.filter(function (it) { return !q || norm(it.name).indexOf(q) > -1; }).forEach(function (it) {
                var row = document.createElement('div');
                row.className = 'insanos-enc-dd-item' + (String(it.id) === curVal ? ' sel' : '');
                row.innerHTML = iconHtml(it) + '<span>' + esc(it.name) + '</span>';
                row.addEventListener('click', function (ev) { ev.stopPropagation(); curVal = String(it.id); applySel(); close(); if (onChange) onChange(it); });
                listEl.appendChild(row);
            });
        }
        function position() {
            if (!wrap.isConnected) { close(); return; }
            var r = btn.getBoundingClientRect(), h = panel.offsetHeight || 300, w = panel.offsetWidth || r.width;
            var up = (window.innerHeight - r.bottom) < h + 8 && r.top > h + 8;
            var left = r.left; if (left + w > window.innerWidth - 8) left = Math.max(8, window.innerWidth - w - 8);
            panel.style.left = left + 'px'; panel.style.top = (up ? r.top - h - 2 : r.bottom + 2) + 'px'; panel.style.minWidth = r.width + 'px';
        }
        function onDown(ev) { if (wrap.contains(ev.target) || panel.contains(ev.target)) return; close(); }
        function onWin() { if (isOpen) position(); }
        function open() {
            if (isOpen) return;
            search.value = ''; drawList('');
            panel.style.position = 'fixed'; panel.style.display = 'flex'; position();
            document.body.appendChild(panel); isOpen = true; wrap.classList.add('open'); position();
            document.addEventListener('mousedown', onDown, true);
            window.addEventListener('scroll', onWin, true); window.addEventListener('resize', onWin);
            setTimeout(function () { try { search.focus(); } catch (_) {} }, 10);
        }
        function close() {
            if (!isOpen) return; isOpen = false; wrap.classList.remove('open');
            panel.style.display = 'none'; if (panel.parentNode === document.body) panel.remove();
            document.removeEventListener('mousedown', onDown, true);
            window.removeEventListener('scroll', onWin, true); window.removeEventListener('resize', onWin);
        }
        btn.addEventListener('click', function (ev) { ev.preventDefault(); isOpen ? close() : open(); });
        search.addEventListener('input', function () { drawList(search.value); });
        search.addEventListener('click', function (ev) { ev.stopPropagation(); });
        applySel();
        return wrap;
    }

    // ===================== views (nav stack) =====================
    var nav = [];         // pilha de {view:'list'|'affix'|'material', ...}
    var _updating = false;
    var _search = '', _filterMat = '', _filterStat = '';  // _filterStat = "statKey|flat" | "statKey|percent"
    var _root = null;     // .insanos-enc-content

    function go(v) { nav.push(v); render(); }
    function back() { if (nav.length > 1) { nav.pop(); render(); } }

    function render() {
        if (!_root) return;
        var top = nav[nav.length - 1] || { view: 'list' };
        var titleEl = _root.parentNode.querySelector('.insanos-enc-header h2');
        var backBtn = _root.parentNode.querySelector('.insanos-enc-backbtn');
        var updBtn = _root.parentNode.querySelector('.insanos-enc-updbtn');
        if (backBtn) backBtn.style.display = nav.length > 1 ? '' : 'none';
        if (updBtn) { updBtn.style.display = top.view === 'list' ? '' : 'none'; updBtn.disabled = _updating; updBtn.textContent = _updating ? t('enc_updating', '⏳ Atualizando…') : t('enc_update', '↻ Atualizar'); }
        if (top.view === 'material') { renderMaterial(top.mat); if (titleEl) titleEl.textContent = top.mat.name; }
        else if (top.view === 'affix') { renderAffix(top.affix); if (titleEl) titleEl.textContent = top.affix.name; }
        else { renderList(); if (titleEl) titleEl.textContent = t('enc_title', '📖 Enciclopédia de Fundição'); }
    }

    function affixRowHtml(a) {
        var mats = '';
        for (var i = 0; i < a.mats.length; i++) {
            var m = a.mats[i];
            mats += '<span class="insanos-enc-mat" data-mat="' + m.matId + '" title="' + esc(m.name + ' ×' + m.qty) + '">'
                + matIcon(m.sprite) + '<span class="insanos-enc-qty">' + m.qty + '</span></span>';
        }
        var uw = a.underworld ? '<span class="insanos-enc-uw" title="' + esc(t('enc_uw_title', 'Afixo do Submundo')) + '">' + esc(t('enc_uw', 'Submundo')) + '</span>' : '';
        return '<div class="insanos-enc-row" data-affix="' + a.kind + ':' + a.id + '" data-name="' + esc(norm(a.name)) + '">'
            + '<span class="insanos-enc-name" title="' + esc(a.name) + '">' + esc(a.name) + uw + '</span>'
            + '<span class="insanos-enc-mats">' + mats + '</span></div>';
    }
    function listColHtml(list) {
        var f = _filterMat ? parseInt(_filterMat, 10) : 0;
        var q = _search;
        var sfKey = '', sfMode = '';
        if (_filterStat) { var sp = _filterStat.split('|'); sfKey = sp[0]; sfMode = sp[1]; }
        var rows = list.filter(function (a) {
            if (q && norm(a.name).indexOf(q) < 0) return false;
            if (f && !a.mats.some(function (m) { return m.matId === f; })) return false;
            if (sfKey && !(a.stats && a.stats[sfKey] && a.stats[sfKey][sfMode])) return false;
            return true;
        });
        if (!rows.length) return '<div class="insanos-enc-empty">' + esc(t('enc_empty', 'Nada encontrado.')) + '</div>';
        return rows.map(affixRowHtml).join('');
    }

    // Itens do filtro de stat = só os pares (stat, flat/percent) que EXISTEM nos dados
    // (evita opção que não filtra nada). Ex: "Carisma (%)", "Força (flat)".
    function statFilterItems(model) {
        var seen = {};
        function scan(list) {
            (list || []).forEach(function (a) {
                var st = a.stats || {};
                for (var k in st) { var s = st[k]; if (!s) continue; if (s.flat) seen[k + '|flat'] = 1; if (s.percent) seen[k + '|percent'] = 1; }
            });
        }
        scan(model.prefixes); scan(model.suffixes);
        function lbl(key, mode) { return statLabel(key) + (mode === 'percent' ? ' (%)' : ' (flat)'); }
        var items = [];
        STAT_ORDER.forEach(function (k) {
            if (seen[k + '|flat']) { items.push({ id: k + '|flat', name: lbl(k, 'flat'), sprite: null }); delete seen[k + '|flat']; }
            if (seen[k + '|percent']) { items.push({ id: k + '|percent', name: lbl(k, 'percent'), sprite: null }); delete seen[k + '|percent']; }
        });
        Object.keys(seen).forEach(function (id) { var p = id.split('|'); items.push({ id: id, name: lbl(p[0], p[1]), sprite: null }); });
        return [{ id: '', name: t('enc_filter_stat_all', 'Todos os stats'), sprite: null }].concat(items);
    }

    function renderList() {
        var model = buildModel();
        if (!model) { _root.innerHTML = '<div class="insanos-enc-empty">' + esc(t('enc_empty', 'Nada encontrado.')) + '</div>'; return; }
        _root.innerHTML = ''
            + '<div class="insanos-enc-toolbar">'
            + '  <div class="insanos-enc-toolrow">'
            + '    <input type="search" class="insanos-enc-search" placeholder="' + esc(t('enc_search', 'Buscar…')) + '" value="' + esc(_search) + '">'
            + '    <span class="insanos-enc-dd-holder"></span>'
            + '    <span class="insanos-enc-dd-holder2"></span>'
            + '  </div>'
            + '  <div class="insanos-enc-note">' + esc(t('enc_note', '')) + '</div>'
            + '</div>'
            + '<div class="insanos-enc-body">'
            + '  <div class="insanos-enc-col"><div class="insanos-enc-col-head">' + esc(t('enc_prefixes', 'Prefixos')) + ' (' + model.prefixes.length + ')</div>'
            + '    <div class="insanos-enc-list" data-col="p">' + listColHtml(model.prefixes) + '</div></div>'
            + '  <div class="insanos-enc-col"><div class="insanos-enc-col-head">' + esc(t('enc_suffixes', 'Sufixos')) + ' (' + model.suffixes.length + ')</div>'
            + '    <div class="insanos-enc-list" data-col="s">' + listColHtml(model.suffixes) + '</div></div>'
            + '</div>';
        var search = _root.querySelector('.insanos-enc-search');
        var reflow = function () {
            _root.querySelector('[data-col="p"]').innerHTML = listColHtml(model.prefixes);
            _root.querySelector('[data-col="s"]').innerHTML = listColHtml(model.suffixes);
        };
        search.addEventListener('input', function () { _search = norm(search.value.trim()); reflow(); });
        // Filtro por material = dropdown pesquisável COM sprites (reusa o padrão do
        // createMaterialDropdown do smeltery-rebuild + input de busca no topo).
        var ddItems = [{ id: '', name: t('enc_filter_all', 'Todos os materiais'), sprite: null }]
            .concat(model.usedMats.map(function (m) { return { id: m.id, name: m.name, sprite: m.sprite }; }));
        _root.querySelector('.insanos-enc-dd-holder').appendChild(
            createMatDropdown(ddItems, _filterMat, function (it) { _filterMat = (it.id === '' ? '' : String(it.id)); reflow(); })
        );
        // Filtro por TIPO DE STAT (reusa o mesmo dropdown pesquisável, sem sprites).
        _root.querySelector('.insanos-enc-dd-holder2').appendChild(
            createMatDropdown(statFilterItems(model), _filterStat, function (it) { _filterStat = (it.id === '' ? '' : String(it.id)); reflow(); })
        );
    }

    function affixByKey(kind, id) {
        var model = buildModel(); if (!model) return null;
        var list = kind === 'p' ? model.prefixes : model.suffixes;
        for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
        return null;
    }
    function renderAffix(a) {
        var uw = a.underworld ? ' <span class="insanos-enc-uw" title="' + esc(t('enc_uw_title', '')) + '">' + esc(t('enc_uw', 'Submundo')) + '</span>' : '';
        var mats = a.mats.map(function (m) {
            return '<span class="insanos-enc-affmat" data-mat="' + m.matId + '" title="' + esc(m.name) + '">'
                + '<span class="icn">' + matIcon(m.sprite) + '</span>'
                + '<span class="nm">' + esc(m.name) + '</span><span class="q">×' + m.qty + '</span></span>';
        }).join('');
        // Projeção por qualidade (stats base × multiplicador), igual à página do site.
        var rows = projRows(a.stats || {});
        var proj = '';
        if (rows.length) {
            var head = '<tr><th></th>' + QUALITIES.map(function (q) { return '<th style="color:' + q.color + '">' + esc(q.name) + '</th>'; }).join('') + '</tr>';
            var body = rows.map(function (r) {
                return '<tr><td>' + esc(r.label) + '</td>' + r.cells.map(function (v, i) {
                    return '<td class="val" style="color:' + QUALITIES[i].color + '">' + esc(fmtVal(v, r.pct)) + '</td>';
                }).join('') + '</tr>';
            }).join('');
            proj = '<div class="insanos-enc-sec-title">' + esc(t('enc_proj', 'Projeção por qualidade (Ceres × multiplicador)')) + '</div>'
                + '<div class="insanos-enc-proj-wrap"><table class="insanos-enc-proj"><thead>' + head + '</thead><tbody>' + body + '</tbody></table></div>';
        }
        _root.innerHTML = '<div class="insanos-enc-detail">'
            + '<div class="insanos-enc-dtitle"><h3>' + esc(a.name) + uw + '</h3></div>'
            + '<div class="insanos-enc-dmeta">' + esc(t('enc_level', 'Nível {n}', { n: a.level })) + ' · ' + (a.kind === 'p' ? esc(t('enc_prefixes', 'Prefixo')) : esc(t('enc_suffixes', 'Sufixo'))) + '</div>'
            + '<div class="insanos-enc-sec-title">' + esc(t('enc_mats', 'Materiais')) + '</div>'
            + '<div class="insanos-enc-affmats">' + mats + '</div>'
            + proj + '</div>';
    }

    function renderMaterial(m) {
        var model = buildModel();
        var pre = (model.matToPre[m.id] || []).slice().sort(function (a, b) { return b.qty - a.qty; });
        var suf = (model.matToSuf[m.id] || []).slice().sort(function (a, b) { return b.qty - a.qty; });
        var dropsHtml = m.drops && m.drops.length ? m.drops.map(function (d) {
            return '<div class="insanos-enc-drop"><span class="insanos-enc-pct" style="color:' + pctColor(d.pct) + '">' + (d.pct != null ? d.pct + '%' : '?') + '</span>'
                + '<span class="insanos-enc-mob">' + esc(d.mob || '?') + '</span><span class="insanos-enc-loc">— ' + esc(d.loc || '?') + '</span></div>';
        }).join('') : '<div class="insanos-enc-note">' + esc(t('enc_no_drops', 'Sem drops conhecidos.')) + '</div>';
        var cardHtml = function (e) {
            return '<div class="insanos-enc-card" data-affix="' + e.a.kind + ':' + e.a.id + '"><span>' + esc(e.a.name)
                + (e.a.underworld ? ' <span class="insanos-enc-uw">' + esc(t('enc_uw', 'Submundo')) + '</span>' : '') + '</span><span class="q">×' + e.qty + '</span></div>';
        };
        var gridPre = pre.length ? '<div class="insanos-enc-sec-title">' + esc(t('enc_pre_with', 'Prefixos com {m}', { m: m.name })) + ' (' + pre.length + ')</div><div class="insanos-enc-grid">' + pre.map(cardHtml).join('') + '</div>' : '';
        var gridSuf = suf.length ? '<div class="insanos-enc-sec-title">' + esc(t('enc_suf_with', 'Sufixos com {m}', { m: m.name })) + ' (' + suf.length + ')</div><div class="insanos-enc-grid">' + suf.map(cardHtml).join('') + '</div>' : '';
        _root.innerHTML = '<div class="insanos-enc-detail">'
            + '<div class="insanos-enc-dtitle"><span class="big-icon">' + matIcon(m.sprite) + '</span><h3>' + esc(m.name) + '</h3></div>'
            + (m.description ? '<div class="insanos-enc-dmeta">' + esc(m.description) + '</div>' : '')
            + (m.scarcity ? '<div class="insanos-enc-dmeta">' + esc(t('enc_scarcity', 'Escassez')) + ': <span class="sc" style="color:' + scarcityColor(m.scarcity) + '">' + esc(m.scarcity) + '</span></div>' : '')
            + '<div class="insanos-enc-sec-title">' + esc(t('enc_drops', 'Dropa de')) + '</div>' + dropsHtml
            + gridPre + gridSuf + '</div>';
    }

    // ===================== modal shell =====================
    function openModal() {
        if (document.querySelector('.insanos-enc-overlay')) return;
        injectStyles();
        if (!buildModel()) { alert('Base da enciclopédia ainda não carregou. Tente de novo em instantes.'); return; }
        nav = [{ view: 'list' }]; _search = ''; _filterMat = ''; _filterStat = '';

        var overlay = document.createElement('div');
        overlay.className = 'insanos-enc-overlay';
        overlay.innerHTML = '<div class="insanos-enc-dialog" role="dialog" aria-modal="true">'
            + '<div class="insanos-enc-header">'
            + '  <button class="insanos-enc-hbtn insanos-enc-backbtn" style="display:none">' + esc(t('enc_back', '← Voltar')) + '</button>'
            + '  <h2>' + esc(t('enc_title', '📖 Enciclopédia de Fundição')) + '</h2>'
            + '  <button class="insanos-enc-hbtn insanos-enc-updbtn" title="Baixa a base mais recente do fansite">' + esc(t('enc_update', '↻ Atualizar')) + '</button>'
            + '  <button type="button" class="close" title="Fechar">×</button>'
            + '</div>'
            + '<div class="insanos-enc-content"></div></div>';
        _root = overlay.querySelector('.insanos-enc-content');

        function close() {
            overlay.remove();
            document.querySelectorAll('.insanos-enc-dd-panel').forEach(function (p) { p.remove(); });
            document.removeEventListener('keydown', onKey);
            var tab = document.getElementById('encyclopedia_settings');
            _root = tab ? tab.querySelector('.insanos-enc-content') : null;
            if (_root) render();
        }
        function onKey(e) { if (e.key === 'Escape') { if (nav.length > 1) back(); else close(); } }
        overlay.querySelector('.close').addEventListener('click', close);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
        overlay.querySelector('.insanos-enc-backbtn').addEventListener('click', back);
        overlay.querySelector('.insanos-enc-updbtn').addEventListener('click', doUpdate);
        document.addEventListener('keydown', onKey);

        // Delegação: clique em linha (afixo), ícone de material, card de afixo, affmat.
        _root.addEventListener('click', function (e) {
            var matEl = e.target.closest && e.target.closest('[data-mat]');
            if (matEl) { e.stopPropagation(); var mm = buildModel().byId[parseInt(matEl.getAttribute('data-mat'), 10)]; if (mm) go({ view: 'material', mat: mm }); return; }
            var affEl = e.target.closest && e.target.closest('[data-affix]');
            if (affEl) { var parts = affEl.getAttribute('data-affix').split(':'); var aa = affixByKey(parts[0], parseInt(parts[1], 10)); if (aa) go({ view: 'affix', affix: aa }); return; }
        });

        document.body.appendChild(overlay);
        render();
    }

    function doUpdate() {
        if (_updating) return;
        _updating = true; render();
        fetchFreshRaw().then(function (raw) {
            _updating = false;
            if (!raw) { var b = document.querySelector('.insanos-enc-updbtn'); if (b) { b.textContent = t('enc_update_fail', '⚠ Falhou'); setTimeout(render, 1800); } return; }
            _rawOverride = raw; _model = null;
            try { localStorage.setItem(RAW_CACHE_KEY, JSON.stringify({ v: SCHEMA, raw: raw })); } catch (_) {}
            nav = [{ view: 'list' }]; _search = ''; _filterMat = ''; _filterStat = '';
            render();
            var b2 = document.querySelector('.insanos-enc-updbtn'); if (b2) { b2.textContent = t('enc_updated', '✓ Atualizado'); setTimeout(render, 1500); }
        });
    }

    function mountTab() {
        var box = document.getElementById('encyclopedia_settings');
        if (!box || box.dataset.gldEncUi) return;
        injectStyles();
        box.dataset.gldEncUi = '1';
        nav = [{ view: 'list' }]; _search = ''; _filterMat = ''; _filterStat = '';
        box.innerHTML = '<div class="insanos-enc-dialog" role="dialog">'
            + '<div class="insanos-enc-header">'
            + '  <button type="button" class="insanos-enc-hbtn insanos-enc-backbtn" style="display:none">' + esc(t('enc_back', '← Voltar')) + '</button>'
            + '  <h2>' + esc(t('enc_title', 'Enciclopédia de Fundição')) + '</h2>'
            + '  <button type="button" class="insanos-enc-hbtn insanos-enc-expand" title="' + esc(t('enc_expand', 'Abrir em tela cheia')) + '">⛶</button>'
            + '  <button type="button" class="insanos-enc-hbtn insanos-enc-updbtn">' + esc(t('enc_update', '↻ Atualizar')) + '</button>'
            + '</div>'
            + '<div class="insanos-enc-content"></div></div>';
        _root = box.querySelector('.insanos-enc-content');
        var backBtn = box.querySelector('.insanos-enc-backbtn');
        if (backBtn) backBtn.addEventListener('click', back);
        var upd = box.querySelector('.insanos-enc-updbtn');
        if (upd) upd.addEventListener('click', doUpdate);
        var exp = box.querySelector('.insanos-enc-expand');
        if (exp) exp.addEventListener('click', openModal);
        _root.addEventListener('click', function (e) {
            var matEl = e.target.closest && e.target.closest('[data-mat]');
            if (matEl) { e.stopPropagation(); var mm = buildModel() && buildModel().byId[parseInt(matEl.getAttribute('data-mat'), 10)]; if (mm) go({ view: 'material', mat: mm }); return; }
            var affEl = e.target.closest && e.target.closest('[data-affix]');
            if (affEl) { var parts = affEl.getAttribute('data-affix').split(':'); var aa = affixByKey(parts[0], parseInt(parts[1], 10)); if (aa) go({ view: 'affix', affix: aa }); }
        });
        render();
    }

    function boot() { mountTab(); }
    var mo = new MutationObserver(function () { boot(); });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    if (document.readyState === 'complete') setTimeout(boot, 400);
    else window.addEventListener('load', function () { setTimeout(boot, 400); });

    window.GldForgeEncyclopedia = { open: openModal, mount: mountTab };
})();
